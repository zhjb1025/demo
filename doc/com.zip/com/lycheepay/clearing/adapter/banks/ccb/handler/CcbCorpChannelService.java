/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-2-28 下午3:24:31
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.handler;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.processor.CcbCorpDirectProcess;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.processor.CcbCorpNoticeProcessor;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.channel.param.NoticeParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.BankCardVerifyType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行银企清算服务入口服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午4:37:20
 */
@Service(ClearingAdapterAnnotationName.CCB_CORP_CHANNEL_SERVICE)
public class CcbCorpChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CORP_DIRECT_PROCESS)
	public CcbCorpDirectProcess ccbCorpDirectProcess;
	@Autowired
	public CcbCorpNoticeProcessor ccbCorpNoticeProcessor;

	public final static String channelId = ChannelIdEnum.CCB_CORP.getCode();

	/**
	 * PS.银企实时代收/扣
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) {
		Log4jUtil.setLogClass("CCB", "corp");
		Log4jUtil.info(deductDTO);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCorpDirectProcess.directDeduct(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * PS.实时代付
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directPay(com.lycheepay.clearing.common.dto.trade.PayOutDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directPay(final PayOutDTO pay) {
		Log4jUtil.setLogClass("CCB", "corp");
		Log4jUtil.info(pay);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		param.setSn(pay.getTxnId());
		param.setCardType(pay.getBankCardType());
		param.setBorc(pay.getAccountType());
		param.setBizBean(pay);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCorpDirectProcess.directPay(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * PS.报文验证
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#accountVerify(com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO accountVerify(final BankCardVerifyDTO accountVerify) {
		Log4jUtil.setLogClass("CCB", "corp");
		Log4jUtil.info(accountVerify);
		ClearingResultDTO dto = null;
		if (BankCardVerifyType.DONT_VERIFY_CERTIF == accountVerify.getVerifyType()
				|| (BankCardVerifyType.PRIORITY_VERIFY_CERTIF == accountVerify.getVerifyType() && StringUtils
						.isBlank(accountVerify.getCertificateNo()))) {// 只验证卡号户名
			dto = ccbCorpDirectProcess.accountVerify(accountVerify);
		} else {// 只验证卡号户名身份证、暂不支持
			final Param param = new Param();
			param.setChannelId(channelId);
			param.setClearingTransType(ClearingTransType.MSG_ACCOUNT_VERIFY);
			param.setBizBean(accountVerify);
			try {
				dto = new ClearingResultDTO();
				dto = ChannelResultUtil.covertResultDTO(ccbCorpDirectProcess.accountVerify(param), dto);
			} catch (final Exception e) {
				return ChannelResultUtil.exceptionToResult(e, dto);
			}
		}
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.MSG_ACCOUNT_VERIFY);
		Log4jUtil.info(dto);
		return dto;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#processBatch(java.util.List, boolean)
	 * @author 李斌(13665100450)
	 */
	@Override
	public BatchSendResult processBatch(String channelBatchId, final List<ChannelTempBill> payList,
			final boolean repeatSend) {
		Log4jUtil.setLogClass("CCB", "corp");
		BatchSendResult batchSendResult = null;
		try {
			batchSendResult = ccbCorpDirectProcess.processBatch(channelBatchId, payList, repeatSend);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, batchSendResult);
		}
		return batchSendResult;
	}

	/**
	 * <p>批量交易结果查询 定时任务处理 </p>
	 * 
	 * @throws ClearingAdapterBizCheckedException
	 * @author 张凯锋(13816608861)
	 */
	@Override
	public void timeQueryBatchTransResult() {
		Log4jUtil.setLogClass("CCB", "BatchQueryResult");

		try {
			ccbCorpDirectProcess.batchRetProcess();
		} catch (BizException e) {
			Log4jUtil.error(e);
		}
	}

	public void notice(final String date) {
		Log4jUtil.setLogClass("CCB", "notice");

		final NoticeParam noticeParam = new NoticeParam();
		noticeParam.setChannelId(ChannelIdEnum.CCB_CORP.getCode()); // 建行银企的渠道
		noticeParam.setNoticeDate(date);

		try {
			ccbCorpNoticeProcessor.deal(noticeParam);
		} catch (BizException e) {
			Log4jUtil.error(e);
		}
	}

	@Override
	public int getMaxNum() {
		return 100000;
	}
	
	/**
	 * 获取账户余额
	 * @return
	 * @author 张凯锋
	 */
	public Balance queryBanlance() {
		Balance balance = null;
		try {
			balance = ccbCorpDirectProcess.queryBanlance(null);
		} catch (BizException e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}
	
	public Balance queryBanlance(String accountNo) {
		Balance balance = null;
		try {
			balance = ccbCorpDirectProcess.queryBanlance(accountNo);
		} catch (BizException e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}

	/**
	 * 获取账户历史明细
	 * 
	 * @param date 查询日期
	 * @param accountNo 账号 ，如果过没有，默认为该渠道结算账户
	 * @param filePath 明细文件保存路径,比如//home/admin/sharedata/recon/historyDetail/
	 * @return
	 * @author 张凯锋
	 */
	public String queryAccountHistoryTransDetail(String date, String accountNo, String filePath) {
		String queryResult = null;
		try {
			queryResult = ccbCorpDirectProcess.queryAccountHistoryTransDetail(date, accountNo, filePath);
		} catch (BizException e) {
			Log4jUtil.error(e);
			queryResult = e.getMessage();
		}
		return queryResult;
	}
}
