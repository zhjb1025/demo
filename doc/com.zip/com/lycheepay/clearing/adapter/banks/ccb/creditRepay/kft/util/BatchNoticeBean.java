package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util;


/**
 * 
 * <P>批量还款子文件实体类</P>
 * 
 * @author 汤兴友 xytang
 */
public class BatchNoticeBean {
	private String payFlag;// 支付标志
	private String transReqDate;// 交易请求日期
	private String transReqTime;// 交易请求时间
	private String fileNumber;// 文件序号
	private double fileSize;// 文件大小
	private int totalNum;// 总笔数
	private double totalAmt;// 总金额
	private String fileName;// 文件名

	
	public BatchNoticeBean() {

	}
	
	public BatchNoticeBean(String transReqDate, String transReqTime) {
		super();
		this.transReqDate = transReqDate;
		this.transReqTime = transReqTime;
	}

	public String getPayFlag() {
		return payFlag;
	}

	public void setPayFlag(String payFlag) {
		this.payFlag = payFlag;
	}

	public String getTransReqDate() {
		return transReqDate;
	}

	public void setTransReqDate(String transReqDate) {
		this.transReqDate = transReqDate;
	}

	public String getTransReqTime() {
		return transReqTime;
	}

	public void setTransReqTime(String transReqTime) {
		this.transReqTime = transReqTime;
	}

	public String getFileNumber() {
		return fileNumber;
	}

	public void setFileNumber(String fileNumber) {
		this.fileNumber = fileNumber;
	}

	public double getFileSize() {
		return fileSize;
	}

	public void setFileSize(double fileSize) {
		this.fileSize = fileSize;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}

	public double getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(double totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}
