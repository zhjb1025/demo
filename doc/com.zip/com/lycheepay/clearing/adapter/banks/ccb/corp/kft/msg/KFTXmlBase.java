package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg;

/**
 * <p>Title: </p>
 * <p>Description:快付通报文基类</p>
 * <p>Copyright: Copyright (c) 2010.12</p>
 * <p>Company: 雁联</p>
 * @author 赵明才
 * @version 1.0
 */

import java.io.File;
import java.nio.charset.Charset;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Element;
import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.util.DateUtil;


abstract public class KFTXmlBase {
	private static Log log = LogFactory.getLog(KFTXmlBase.class);
	protected Dom4jXMLMessage dom4jxml = null;
	protected KFTXmlHead head = null;
	protected String kftXML = "";

	public KFTXmlBase() {
		head = new KFTXmlHead();
	}

	public void parsexmlfile(final String fileName) throws BizException {
		final File f = new File(fileName);
		dom4jxml = Dom4jXMLMessage.parse(f);
		parsexmlhead();
		parsexmlbody();

	}

	public void parsexml(final String xmlStr) throws BizException {
		dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes());
		parsexmlhead();
		parsexmlbody();
	}

	public void parsexml(final String xmlStr, final Charset charset) throws BizException {
		dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(charset));
		parsexmlhead();
		parsexmlbody();
	}

	public void parsexml(final byte[] xmlbyte) throws BizException {
		dom4jxml = Dom4jXMLMessage.parse(xmlbyte);
		kftXML = new String(xmlbyte);
		parsexmlhead();
		parsexmlbody();
	}

	protected void parsexmlhead() throws BizException {
		final String workDate = dom4jxml.getNodeText("/KFT/HEAD/WorkDate", 8, 8);
		final String timeStamp = dom4jxml.getNodeText("/KFT/HEAD/TimeStamp", 6, 6);
		final String msgID = dom4jxml.getNodeText("/KFT/HEAD/MsgID", 1, 20);
		final String ver = dom4jxml.getNodeText("/KFT/HEAD/VER", 1, 3);
		head.setVer(ver);
		head.setSrc(dom4jxml.getNodeText("/KFT/HEAD/SRC", 1, 20));
		head.setDes(dom4jxml.getNodeText("/KFT/HEAD/DES", 1, 20));
		head.setMsgCode(dom4jxml.getNodeText("/KFT/HEAD/MsgCode", 1, 4));
		head.setMsgID(msgID);
		head.setMsgRef(dom4jxml.getNodeText("/KFT/HEAD/MsgRef", 0, 20));
		head.setWorkDate(workDate);
		head.setTimeStamp(timeStamp);
		head.setReserve(dom4jxml.getNodeText("/KFT/HEAD/Reserve"));

		if (!ver.equals("1.0")) {
			throw new BizException("9303", "报文Ver应该是1.0");
		}

		AssertUtils.checkLength(workDate, "9102", "报文WorkDate区", 8);
		AssertUtils.checkLength(timeStamp, "9102", "报文TimeStamp区", 6);
		AssertUtils.checkNChar(msgID, "9303", "报文MsgID区");
		if (!DateUtil.isValidDate(workDate, "yyyyMMdd")) {
			throw new BizException("9303", "报文WorkDate区格式非法！");
		}
		if (!DateUtil.isValidDate(timeStamp, "HHmmss")) {
			throw new BizException("9303", "报文TimeStamp区格式非法！");
		}

		final String sinfo = String.format("收到报文[code=%s,src=%s,msgid=%s,time=%s]", head.getMsgCode(), head.getSrc(),
				head.getMsgID(), head.getTimeStamp());
		log.info(sinfo);

	}

	abstract protected void parsexmlbody() throws BizException;

	public void buildxml() {
		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("KFT");
		buildxmlhead();
		buildxmlbody();
	}

	protected void buildxmlhead() {

		final Element newElement = dom4jxml.addNode(dom4jxml.getRoot(), "HEAD", "");
		dom4jxml.addNode(newElement, "VER", head.getVer());
		dom4jxml.addNode(newElement, "SRC", head.getSrc());
		dom4jxml.addNode(newElement, "DES", head.getDes());
		dom4jxml.addNode(newElement, "MsgCode", head.getMsgCode());
		dom4jxml.addNode(newElement, "MsgID", head.getMsgID());
		dom4jxml.addNode(newElement, "MsgRef", head.getMsgRef());
		dom4jxml.addNode(newElement, "WorkDate", head.getWorkDate());
		dom4jxml.addNode(newElement, "TimeStamp", head.getTimeStamp());
		dom4jxml.addNode(newElement, "Reserve", head.getReserve());

	}

	abstract protected void buildxmlbody();

	@Override
	public String toString() {
		return dom4jxml.toString();
	}

	public void printFormatString() {
		dom4jxml.printFormatString("GBK");
	}

	public KFTXmlHead getHead() {
		return head;
	}

	public void setHead(final KFTXmlHead head) {
		this.head = head;
	}

	public Node getNode(final String xpath) throws BizException {
		final Node node = dom4jxml.getNode(xpath);
		return node;

	}
}
