package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.processor;

import java.util.List;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.BatchBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.Status;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.ChannelBatch;
import com.lycheepay.clearing.common.model.ChannelBatchId;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.StringUtil;


/**
 * 
 * <P>建行信用卡还款请求处理类</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDITREPAY_DIRECT_PROCESS)
public class CcbCreditRepayDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_REPAY_SERVICE)
	private CcbRepayService ccbRepayService = new CcbRepayService();

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_REPAY_MSGDEAL)
	private CcbRepayMsgDeal ccbRepayMsgDeal = new CcbRepayMsgDeal();

	public final static String channelId = ChannelIdEnum.CCB_CREDIT_REPAY.getCode();

	private String line = System.getProperty("line.separator"); // 回车换行符

	public BatchSendResult processBatch(List<ChannelTempBill> payList, boolean repeatSend, String channelBatchId,
			String transType)
			throws BizException {
		BatchSendResult result = new BatchSendResult();
		if (repeatSend) {
			result = this.send_batch_ReSend(payList, channelBatchId, transType);
		} else {
			result = this.batchDistributeSend(payList, channelBatchId, transType);
		}
		return result;
	}

	/**
	 * 批量交易
	 * 
	 * @param param
	 * @param trantype
	 * @return
	 * @throws BizException
	 */
	private BatchSendResult batchDistributeSend(List<ChannelTempBill> payList, String channelBatchId, String transType)
			throws BizException {

		// 此批次号的交易记录数为0
		if (payList == null || payList.size() == 0)
			return this.makeFailReturn();

		// 发送交易(生成批量处理文件，FTP到服务器,保存记录到 billnoSn表并发送交易。)
		BatchBean batchBean = ccbRepayService.sendBatch(transType, payList, channelBatchId);
		// 更新交易结果
		// ccbRepayService.updateBatchSend(batchBean.getTrantype(), batchBean.getChannelBatchNo(),
		// batchBean.getReturnState());

		BatchSendResult rs = this.convertResult(batchBean.getReturnState());

		return rs;
	}

	/**
	 * 
	 * <p>将对象ReturnState加载到BatchSendResult</p>
	 * 
	 * @param returnState
	 * @return
	 * @author 汤兴友 xytang
	 */
	private BatchSendResult convertResult(ReturnState returnState) {

		/**
		 * TODO BatchSendResult对象的字段有待改善于完善
		 */
		BatchSendResult rs = new BatchSendResult();
		rs.setStatus(returnState.getReturnState());
		rs.setBankReturnCode(returnState.getChannelCode());
		rs.setBankReturnMsg(returnState.getReturnMsg());
		return rs;
	}

	/**
	 * 
	 * <p>创建默认失败下的BatchSendResult</p>
	 * 
	 * @return
	 * @author 汤兴友 xytang
	 */
	private BatchSendResult makeFailReturn() {
		BatchSendResult rs = new BatchSendResult();
		rs.setStatus(Status.FAIL);
		return rs;
	}

	/**
	 * 批量交易重发
	 * 
	 * @param channelBatchId
	 * @param trantype
	 * @return
	 * @throws BizException
	 */
	private BatchSendResult send_batch_ReSend(List<ChannelTempBill> payList, String channelBatchId, String transType)
			throws BizException {

		// 次批次号的交易记录数为0
		if (payList == null || payList.size() == 0)
			return this.makeFailReturn();

		// 发送交易(生成批量处理文件，FTP到服务器,保存记录到 billnoSn表并发送交易。)
		BatchBean batchBean = ccbRepayService.sendBatch(transType, payList, channelBatchId);
		// 更新交易结果
		// ccbRepayService.updateBatchSend(batchBean.getTrantype(), batchBean.getChannelBatchNo(),
		// batchBean.getReturnState());
		// 将state转换为BatchSendResult
		BatchSendResult rs = this.convertResult(batchBean.getReturnState());

		return rs;
	}

	/**
	 * 建行信用卡还款批量交易结果处理 -- 批量交易结果文件下载,并更新批量交易记录
	 * 
	 * @throws BizException
	 */
	public void batchRetProcess() throws BizException {
		Log4jUtil.info("建行信用卡还款结果处理 batchRetProcess");

		List<String> batchIdList = channelBatchService.getCorpBatchIdList(channelId);

		Log4jUtil.info(line + "建行信用卡还款要查询的批理业务交易结果的批次号start");
		for (int i = 0; i < batchIdList.size(); i++) {
			Log4jUtil.info(line + "批次号 " + (i + 1) + " : " + batchIdList.get(i));
		}
		Log4jUtil.info(line + "建行信用卡还款要查询的批处理业务交易结果的批次号end");

		// 2、根据的批次号list，做结果 处理
		Log4jUtil.info(line + "建行信用卡还款批理交易结果处理开始");
		String channelBatchId = "";

		for (int i = 0; i < batchIdList.size(); i++) {
			channelBatchId = batchIdList.get(i);
			try {
				Log4jUtil.info("----------开始处理渠道批次：" + channelBatchId);
				// 事务处理批量返回数据
				ChannelBatch channelBatch = (ChannelBatch) channelBatchService.findById(new ChannelBatchId(channelId,
						channelBatchId));
				AssertUtils.notNull(channelBatch, StringUtil.r("渠道批次{?}不存在！", channelBatchId));
				AssertUtils.notNull(channelBatch.getSendTime(), StringUtil.r("渠道批次{?}的发送日期为空", channelBatchId));

				String tranDate = DateUtil.getDate(channelBatch.getSendTime());

				/**
				 * 按规则组结果文件名字
				 */
				String retFileName = ccbRepayMsgDeal.createFileName("RepayResult", tranDate, channelBatchId, null);

				/**
				 * 下载结果文件，返回全路径
				 */
				String fileNameRcvPath = ccbRepayMsgDeal.batRetDeal(retFileName);

				/**
				 * 解析结果文件，并业务处理
				 */
				ccbRepayService.predeal(channelBatchId, fileNameRcvPath, tranDate);

				Log4jUtil.info("渠道批次为:【{}】的交易结果处理完成", channelBatchId);
			} catch (BizException e) {
				Log4jUtil.error("建行信用卡还款批次号{}取结果文件处理出错!", channelBatchId);
				Log4jUtil.error(e);
			}
		}
		Log4jUtil.info(line + "建行信用卡还款批理交易结果处理完成");
	}

	/**
	 * 密钥申请
	 * 
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealKeyApply() {
		ReturnState rs = null;
		try {
			rs = ccbRepayService.dealKeyApply();
		} catch (Exception e) {
			Log4jUtil.error(e);
		}

		int num = 1;
		while (rs == null || !TransReturnCode.code_0000.equals(rs.getChannelCode())) {
			Log4jUtil.info("-密钥同步失败！5 秒后重发密钥同步交易，这是第{}次重发！", num);
			num++;
			try {
				Thread.sleep(5000);
				rs = ccbRepayService.dealKeyApply();
			} catch (Exception e) {
				Log4jUtil.error(e);
			}
		}

		return rs;
	}

	/**
	 * 
	 * <p>信用卡还款用户信息验证</p>
	 * 
	 * @param accountVerify
	 * @author 汤兴友 xytang
	 */
	public ClearingResultDTO accountVerify(BankCardVerifyDTO accountVerify) throws BizException {
		ReturnState rs = ccbRepayService.accountVerify(accountVerify);

		// 密钥重新申请 TODO
		if ("xxx".equals(rs.getBankRetCode())) {
			this.dealKeyApply();
			rs = ccbRepayService.accountVerify(accountVerify);
		}

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setTxnStatus(rs.getReturnState());
		dto.setChannelResponseCode(rs.getChannelCode());
		dto.setChannelResponseMsg(rs.getReturnMsg());

		return dto;
	}

}
