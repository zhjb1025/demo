package com.lycheepay.clearing.adapter.banks.ccb.credit.kft.processor;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCancelDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompleteDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompletionCancelDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行信用卡银企直连处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午5:21:51
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDIT_DIRECT_PROCESS)
public class CcbCreditDirectProcess extends BaseWithoutAuditLogService {

	// 清算交易记录
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	// 渠道参数
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	// 清算交易工具
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CREDIT_SERVICE)
	private CcbCreditService ccbCreditService;

	private static final String channelId = ChannelIdEnum.CCB_CREDIT_CARD.getCode();

	/**
	 * <p>预授权交易</p>
	 * 
	 */
	public ReturnState preAuth(final Param param) throws BizException {
		ReturnState returnState = new ReturnState();
		final String bankSendSn = sequenceManagerService.getCcbCreditSN();// 渠道发送流水
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);
		// 发送处理
		returnState = ccbCreditService.signProcess(false);// 仿Pos签到
		returnState = ccbCreditService.dealGrant(param, bankSendSn);// 业务处理
		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		return returnState;
	}

	/**
	 * <p> 预授权撤销交易</p>
	 * 
	 */
	public ReturnState preAuthCancel(final Param param) throws BizException {
		ReturnState returnState = new ReturnState();
		final String bankSendSn = sequenceManagerService.getCcbCreditSN();// 渠道发送流水
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);

		PreAuthCancelDTO dto = (PreAuthCancelDTO) param.getBizBean();
		AssertUtils.notNull(dto.getOrgTransTxnId(), TransReturnCode.code_9108, "参数BizBean.的原交易OrgTransTxnId不能为空");

		// 查询原业务渠道流水
		BillnoSn bs = billnoSnService.findBillnoSn(channelId, dto.getOrgTransTxnId());
		AssertUtils.notNull(bs.getBankSendSn(), TransReturnCode.code_9108,
				"渠道流水对照表中没有找到原业务流水号:" + dto.getOrgTransTxnId());

		returnState = ccbCreditService.signProcess(false);// 仿Pos签到
		returnState = ccbCreditService.dealGrantCancel(bankSendSn, bs);// 业务处理
		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		return returnState;
	}

	/**
	 * <p>预授权完成交易</p>
	 * 
	 */
	public ReturnState preAuthComplete(final Param param) throws BizException {
		ReturnState returnState = new ReturnState();

		final String bankSendSn = sequenceManagerService.getCcbCreditSN();// 渠道发送流水
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);

		PreAuthCompleteDTO dto = (PreAuthCompleteDTO) param.getBizBean();
		AssertUtils.notNull(dto.getOrgTransTxnId(), TransReturnCode.code_9108, "参数BizBean.的原交易OrgTransTxnId不能为空");

		// 查询原业务渠道流水
		BillnoSn bs = billnoSnService.findBillnoSn(channelId, dto.getOrgTransTxnId());
		String orgBs = bs.getBankSendSn();
		AssertUtils.notNull(orgBs, TransReturnCode.code_9108, "渠道流水对照表中没有找到原业务流水号:" + dto.getOrgTransTxnId());

		// 保存otherAccNo到预授权完成交易的交易流水表中，以提供给完成撤销交易使用
		String otherAccNo = bs.getOtheracctno();
		BillnoSn bsNew = billnoSnService.getBillnoSn(channelId, bankSendSn);
		bsNew.setOtheracctno(otherAccNo);
		billnoSnService.update(bsNew);

		// 发送处理
		returnState = ccbCreditService.signProcess(false);// 仿Pos签到
		returnState = ccbCreditService.dealGrantFinish(param, orgBs);// 业务处理
		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		return returnState;
	}

	/**
	 * <p>预授权完成撤销</p>
	 * 
	 */
	public ReturnState preAuthCompleteCancel(final Param param) throws BizException {
		ReturnState returnState = new ReturnState();

		final String bankSendSn = sequenceManagerService.getCcbCreditSN();// 渠道发送流水
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);

		PreAuthCompletionCancelDTO dto = (PreAuthCompletionCancelDTO) param.getBizBean();
		AssertUtils.notNull(dto.getOrgTransTxnId(), TransReturnCode.code_9108, "参数BizBean.的原交易OrgTransTxnId不能为空");

		// 查询原业务渠道流水
		BillnoSn bs = billnoSnService.findBillnoSn(channelId, dto.getOrgTransTxnId());
		String orgBs = bs.getBankSendSn();
		AssertUtils.notNull(orgBs, TransReturnCode.code_9108, "渠道流水对照表中没有找到原业务流水号:" + dto.getOrgTransTxnId());

		// 发送处理
		returnState = ccbCreditService.signProcess(false);// 仿Pos签到
		returnState = ccbCreditService.dealGrantFinishCancel(param, orgBs);// 业务处理
		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		return returnState;
	}

	/**
	 * <p>建行信用卡实时代扣</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午6:03:58
	 */
	public ReturnState directDeduct(final Param param) throws BizException {
		Log4jUtil.info("渠道ID【{}】,渠道业务【{}】开始处理", channelId, param.getClearingTransType());
		final String bankSendSn = sequenceManagerService.getCcbCreditSN();// 渠道发送流水
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);
		// 发送处理
		ccbCreditService.signProcess(false);// 仿Pos签到
		ReturnState returnState = ccbCreditService.deal(param, bankSendSn);// 业务处理
		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		return returnState;
	}

	/**
	 * <p>自适应退款</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午6:08:44
	 */
	public ReturnState autoRealtimeRefund(final Param param) throws BizException { // 自适应实时退款 -
		final AutoRealTimeRefund autoRealTimeRefund = channelTransUtilService.getAutoRealTimeRefund(param);
		AssertUtils.notTrue(autoRealTimeRefund.getRefundAmount().compareTo(autoRealTimeRefund.getOrgAmount()) == 1,
				TransReturnCode.code_9108, "退款金额不能大于原交易金额");
		// 通过param来判断是走撤销或是走交易退款
		final BillnoSn billnoSnOrg = billnoSnService.findBillnoSn(autoRealTimeRefund.getOrgTransChannelId(),
				autoRealTimeRefund.getOrgPaySn());
		AssertUtils.notNull(billnoSnOrg, TransReturnCode.code_9108,
				"渠道流水对照表中没有找到原流水号:" + autoRealTimeRefund.getOrgPaySn());
		final String batchNo = billnoSnOrg.getCreditbatchno(); // 仿pos中的POS中心批次号
		final ChannelParm batchNoParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		AssertUtils.notNull(batchNo, TransReturnCode.code_9108, "batchNo批次号不能为空");
		AssertUtils.notNull(batchNoParm, TransReturnCode.code_9108, "batchNoParm批次号不能为空");
		if (batchNoParm.getParvalue().equals(batchNo)) {
			return this.dealRevoke(param, autoRealTimeRefund, billnoSnOrg);
		} else {
			return this.dealRealTimeRefund(param, autoRealTimeRefund, billnoSnOrg);
		}
	}

	/**
	 * <p> 交易撤销</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午6:09:42
	 */
	public ReturnState dealRevoke(final Param param, final AutoRealTimeRefund realTimeRefund, final BillnoSn billnoSn)
			throws BizException {
		// 写Billno_sn表
		final String newBankSendSn = sequenceManagerService.getCcbCreditSN();
		billnoSnService.saveBillnoSn(newBankSendSn, param);
		ReturnState rs = ccbCreditService.dealRevoke(newBankSendSn, realTimeRefund, billnoSn);
		rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_CANCLE);
		// 更新billno_sn
		billnoSnService.updateBillnoSn(param, rs, newBankSendSn);

		// =============增加预授权撤销，作用：解冻金额=============
		try {
			if (TransReturnCode.code_0000.equals(rs.getChannelCode())) {
				ReturnState grantCancel = ccbCreditService.dealGrantCancel(sequenceManagerService.getCcbCreditSN(), billnoSn);
				Log4jUtil.info("grantCancel Result:{}", grantCancel);
			}
		} catch (Exception e) {
			Log4jUtil.error("grantCancel error", e);
		}
		// ==========================
		return rs;
	}

	/**
	 * <p>实时退款</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午6:09:50
	 */
	private ReturnState dealRealTimeRefund(final Param param, final AutoRealTimeRefund realTimeRefund,
			final BillnoSn billnoSn) throws BizException {
		// 写Billno_sn表
		final String newBankSendSn = sequenceManagerService.getCcbCreditSN();
		billnoSnService.saveBillnoSn(newBankSendSn, param);
		final ReturnState rs = ccbCreditService.RealTimeRefund(newBankSendSn, realTimeRefund, billnoSn);
		rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_REFUND);
		billnoSnService.updateBillnoSn(param, rs, newBankSendSn);
		return rs;
	}

	/**
	 * @param batchId 联机批结算及重签到
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealBatSettle() throws BizException {
		final ReturnState rs = ccbCreditService.dealBatSettle();
		ccbCreditService.signProcess(true);// 重签到
		return rs;
	}

}
