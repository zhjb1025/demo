package com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.ByteUtils;
import com.lycheepay.clearing.adapter.common.util.security.JDES;
import com.lycheepay.clearing.util.Log4jUtil;


public class MacUtil {
	/**
	 * 
	 * @param orgByteDate
	 * @param mkey
	 * @return
	 */
	public static String getMacDate(byte[] orgByteDate, final String mkey) {
		final byte[] mackey = LoUtils.hexStr2Bytes(mkey);

		// 补为8的整数倍
		if (orgByteDate.length % 8 != 0) {
			orgByteDate = ArrayUtils.addAll(orgByteDate, new byte[8 - orgByteDate.length % 8]);
		}

		// 源数据转换成int数组
		final int[] orgIntDate = new int[orgByteDate.length];
		for (int i = 0; i < orgByteDate.length; i++) {
			orgIntDate[i] = orgByteDate[i];
		}

		// 创建BLOCK数组MAB
		final int[][] mabBlock = new int[orgByteDate.length / 8][8];

		// 赋值
		for (int i = 0; i < mabBlock.length; i++) {
			for (int j = 0; j < 8; j++) {
				mabBlock[i][j] = orgByteDate[i * 8 + j];
			}
		}

		// b. 对MAB，按每8个字节做异或（不管信息中的字符格式），如果最后不满8个字节，则添加“0X00”
		final int[] tempBlock = new int[8];
		for (int j = 0; j < mabBlock.length - 1; j++) {
			for (int i = 0; i < 8; i++) {
				if (j == 0) {
					tempBlock[i] = mabBlock[j][i] ^ mabBlock[j + 1][i];
				} else {
					tempBlock[i] = tempBlock[i] ^ mabBlock[j + 1][i];
				}
			}
		}

		// C.将异或运算后的最后8个字节（RESULT BLOCK）转换成16 个HEXDECIMAL：
		final byte[] resultBlock = new byte[8];
		for (int j = 0; j < 8; j++) {
			resultBlock[j] = (byte) tempBlock[j];
		}
		final String resHexStr = LoUtils.byte2HexStr(resultBlock);

		// d.取前8个字节用MAK加密
		final String covertStr = resHexStr.substring(0, 8);
		// byte[] encblock = J2DES.trides_crypt(mackey, covertStr.getBytes());
		final byte[] encblock = J2DES.des_crypt(mackey, covertStr.getBytes());

		// e.将加密后的结果与后8个字节异或：
		final String resHexStr2 = resHexStr.substring(8);
		final byte[] tempByte = resHexStr2.getBytes();
		final byte[] tempBlock2 = new byte[8];
		for (int i = 0; i < 8; i++) {
			tempBlock2[i] = (byte) (encblock[i] ^ tempByte[i]);
		}

		// f.用异或的结果TEMP BLOCK 再进行一次单倍长密钥算法运算。
		final byte[] encblock2 = J2DES.des_crypt(mackey, tempBlock2);
		// byte[] encblock2 = J2DES.trides_crypt(mackey, tempBlock2);

		// g.将运算后的结果（ENC BLOCK2）转换成16 个HEXDECIMAL：
		final String resHexStr3 = LoUtils.byte2HexStr(encblock2);
		final String macstr = resHexStr3.substring(0, 8);
		final String macHex = LoUtils.byte2HexStr(macstr.getBytes());
		Log4jUtil.info("生成的mac值为：{}, mac的byte2HexStr值：{}", macstr, macHex);
		// h.取前8个字节作为MAC值
		return macHex;
	}

	/*
	 * 把16进制字符串转换成字节数组 @param hex 要求两位，不足左补0 @return
	 */
	public static byte[] hexStringToByte(final String hex) {
		final int len = (hex.length() / 2);
		final byte[] result = new byte[len];
		final char[] achar = hex.toCharArray();
		for (int i = 0; i < len; i++) {
			final int pos = i * 2;
			result[i] = (byte) (toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
		}
		return result;
	}

	/**
	 * 参数说明: key-8个字符的des密钥 value-密文
	 */
	public static byte[] decrypt(final byte[] key, final byte[] value) {
		try {
			// SecretKey securekey = new SecretKeySpec(key, "DES");
			// Cipher cipher = Cipher.getInstance(ALGORITHM);
			// cipher.init(Cipher.DECRYPT_MODE, securekey);
			// return cipher.doFinal(value);
			final JDES des = new JDES();
			des.SetKey(key);
			return des.doECBDecryptNoPadding(value, value.length);
		} catch (final Exception e) {
			Log4jUtil.error(e);
		}

		return null;
	}

	private static byte toByte(final char c) {
		final byte b = (byte) "0123456789ABCDEF".indexOf(c);
		return b;
	}

	public static void main(final String[] args) {
		final String mkey = "f1842d9f23573dc4"; // 3130304643314641
		final String orgBcdData = "005f600000000002007024068000c0001516404117555501319500a0000000000010220000530327012010505131324a30303330393130333434303335333131303031310005a0020100000012303030303132303030303032ab3ee920b7805d51";
		// String mkey = "2AE968078C5DE623"; // 银行的结果：1B7E730DC9A39AC8
		// String orgBcdData =
		// "01006024048000C08014156225887839451260030000001221131000100630303031393238333130353538343037333939303133383135360008140000010003303836";
		final byte[] orgByteDate = ByteUtils.strToBcd(orgBcdData);
		final String str = MacUtil.getMacDate(orgByteDate, mkey);
		System.out.println(str);
		// System.out.println("算法是否成功:" + "1B7E730DC9A39AC8".equals(str));
		System.out.println("算法是否成功:" + "4638394331313243".equals(str));
		System.out.println();
	}

}
