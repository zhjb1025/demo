package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean;

/**
 * 
 * <P>还款用户信息验证Response信息</P>
 * 
 * @author 汤兴友 xytang
 */
public class AccVerifyRsp {
	String msgno;// 消息号
	String cmd;// 接口命令字
	String retcode;// 返回码
	String name;// 还款人姓名
	String cardid;// 还款人卡号
	String sign;// 签名值
	String desc;// 描述

	public String getMsgno() {
		return msgno;
	}

	public void setMsgno(String msgno) {
		this.msgno = msgno;
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	public String getRetcode() {
		return retcode;
	}

	public void setRetcode(String retcode) {
		this.retcode = retcode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCardid() {
		return cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public String toString() {
		return "AccVerifyRsp [msgno=" + msgno + ", cmd=" + cmd + ", retcode=" + retcode + ", name=" + name
				+ ", cardid=" + cardid + ", desc=" + desc + ", sign=" + sign + "]";
	}

}
