/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-7-4 下午3:24:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.handler;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.processor.CcbCreditRepayDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <P>建设信用卡还款清算服务入口服务类</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDITREPAY_CHANNEL_SERVICE)
public class CcbCreditRepayChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CREDITREPAY_DIRECT_PROCESS)
	private CcbCreditRepayDirectProcess ccbCreditRepayDirectProcess;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	public final static String channelId = ChannelIdEnum.CCB_CREDIT_REPAY.getCode();

	@Override
	public int getMaxNum() {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String limitNum = channelParms.get("100010");
		return Integer.parseInt(limitNum);// 一般为 3000笔
	}

	/**
	 * 批量交易
	 */
	@Override
	public BatchSendResult processBatch(final String channelBatchId, final List<ChannelTempBill> payList,
			final boolean repeatSend) {
		Log4jUtil.setLogClass("CCB_CREDIT_REPAY", "batch");

		final String transType = payList.get(0).getTransType().toString();
		BatchSendResult batchSendResult = null;
		try {
			batchSendResult = ccbCreditRepayDirectProcess.processBatch(payList, repeatSend, channelBatchId, transType);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, batchSendResult);
		}
		return batchSendResult;
	}

	/**
	 * 信用卡还款用户信息验证接口 (只对持卡人姓名,和卡号的验证)
	 */
	@Override
	public ClearingResultDTO accountVerify(BankCardVerifyDTO accountVerify) {
		Log4jUtil.setLogClass("CCB_CREDIT_REPAY", "accountVerify");
		ClearingResultDTO dto = new ClearingResultDTO();
		try {
			dto = ccbCreditRepayDirectProcess.accountVerify(accountVerify);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 建行信用卡还款批量交易结果查询 定时任务处理
	 */
	@Override
	public void timeQueryBatchTransResult() {
		Log4jUtil.setLogClass("CCB_CREDIT_REPAY", "batchQuery");
		try {
			ccbCreditRepayDirectProcess.batchRetProcess();
		} catch (BizException e) {
			Log4jUtil.error(e);
		}
	}

	/**
	 * 建行信用卡还款密钥同步
	 */
	public void timeKeyApply() {
		Log4jUtil.setLogClass("CCB_CREDIT_REPAY", "keyApply");
		ccbCreditRepayDirectProcess.dealKeyApply();
	}

}
