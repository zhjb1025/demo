//package paycore.channel.banks.CcbCorp;
//
//import java.nio.charset.Charset;
//import java.util.Date;
//import java.util.List;
//
//import org.dom4j.Node;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util.CcbCorpProcessXmlService;
//import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.common.model.BillnoSn;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelBatch;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelBatchId;
//import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
//import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
//import com.lycheepay.clearing.adapter.common.service.channel.CallBizAdapter;
//import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
//import com.lycheepay.clearing.util.Log4jUtil;
//
//
///**
// * 建行银企批量结果下载（CMP029)
// * 
// * @author aps-lfm
// * 
// */
//public class CorpCcbCMP029Service {
//
//	@Autowired
//	private CallBizAdapter callBizAdapter;
//	private static BillnoSnDao billnoSnDao = (BillnoSnDao) SpringContext.getService("billnoSnDao");
//	private static BillnoSnService billnoSnService = (BillnoSnService) SpringContext.getService("billnoSnService");
//	private static ChannelBatchDao channelBatchDao = (ChannelBatchDao) SpringContext.getService("channelBatchDao");
//	private static BatchService channelBatchService = (BatchService) SpringContext.getService("batchService");
//
//	/**
//	 * 建行银企6W2104批量交易结果下载处理
//	 * 
//	 * @param xmlStr 报文字符串
//	 * @param param
//	 * @return ReturnState
//	 * @throws BizException
//	 */
//	public ReturnState deal6W2104(final Param param) throws BizException {
//		final ReturnState returnState = new ReturnState();
//		BillnoSn billnoSn = new BillnoSn();
//		Dom4jXMLMessage dom4jxml = null;
//		final CcbCorpProcessXmlService comProcessXml = new CcbCorpProcessXmlService();
//		final String sendXml = comProcessXml.create6W2104XML(param);// 创建请求
//		Log4jUtil.debug(sendXml);
//		final String xmlStr = comProcessXml.sendXML(sendXml);// 发送请求
//		Log4jUtil.debug(xmlStr);
//		dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));// 解析xml
//		final Node nodeItemHead = dom4jxml.getNode("/TX");// 获取xml中TX节点的数据
//		// 组返回的实体
//		if (dom4jxml.getNodeText(nodeItemHead, "RETURN_CODE").equals("00000")) {// 查询成功
//			final Node nodeItem = dom4jxml.getNode("/TX/TX_INFO");
//			// String sumNum =dom4jxml.getNodeText(nodeItem,"TOTAL_NUM");//总笔数
//			// String sumAmount = dom4jxml.getNodeText(nodeItem,"TOTAL_AMOUNT");//总金额
//			final String sucessNum = dom4jxml.getNodeText(nodeItem, "SUCCESS_AMOUNT");// 成功笔数
//			final String sucessAmount = dom4jxml.getNodeText(nodeItem, "SUCCESS_NUM");// 成功金额
//			final String unSucessNum = dom4jxml.getNodeText(nodeItem, "FAIL_AMOUNT");// 失败金额
//			final String unSucessAmount = dom4jxml.getNodeText(nodeItem, "FAIL_NUM");// 失败笔数
//			// 处理xml中节点中成功的记录
//			int i = 0;
//			int j = 0;
//			final List<Node> nodeItemSuccList = dom4jxml.getNodeList("/TX/SUCCESS_LIST");
//			j = nodeItemSuccList.size();// 循环处理
//			for (i = 0; i < j; i++) {
//				final Node nodeItemSucc = nodeItemSuccList.get(i);
//				final double amount = Double.parseDouble(dom4jxml.getNodeText(nodeItemSucc, "AMOUNT"));// 金额
//				final String id = dom4jxml.getNodeText(nodeItemSucc, "OID").toString();// 序列号
//				billnoSn = (BillnoSn) billnoSnDao.findById(id);
//				if (billnoSn == null) {
//					throw new BizException("建行银企批量结果查询通过序列号" + id + "反查billno_SN为空");
//				}
//				billnoSn.setChannelRtncode("00000"); // 渠道返回码
//				billnoSn.setChannelRtnnote("S-成功"); // 渠道返回附言
//				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
//				billnoSn.setRecvTime(new Date()); // 返回时间
//				billnoSn.setActualAmount(amount); // 渠道实际支付金额
//				billnoSnDao.update(billnoSn);
//			}// for
//				// 处理xml中节点失败记录
//			final List<Node> nodeItemFailList = dom4jxml.getNodeList("/TX/FAIL_LIST");
//			j = nodeItemFailList.size();// 循环处理
//			for (i = 0; i < j; i++) {
//				final Node nodeItemFail = nodeItemFailList.get(i);
//				final double amount = Double.parseDouble(dom4jxml.getNodeText(nodeItemFail, "AMOUNT"));// 金额
//				final String id = dom4jxml.getNodeText(nodeItemFail, "OID").toString();// 序列号
//				billnoSn = (BillnoSn) billnoSnDao.findById(id);
//				if (billnoSn == null) {
//					throw new BizException("建行银企批量结果查询通过序列号" + id + "反查billno_SN为空");
//				}
//				billnoSn.setChannelRtncode(TransReturnCode.code_9900); // 渠道返回码
//				billnoSn.setChannelRtnnote("E-失败"); // 渠道返回附言
//				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
//				billnoSn.setRecvTime(new Date()); // 返回时间
//				billnoSn.setActualAmount(amount); // 渠道实际支付金额
//				billnoSnDao.update(billnoSn);
//			}// for
//				// 批量更新流水对照表
//			final String channelBatchId = (String) param.getBizBean();// 渠道支付批次
//			billnoSnService.updateByChannelBatchId(channelBatchId, param.getChannelId(), BillnoSnState.billnoRecv);
//			// 更新channel_batch表
//			final ChannelBatchId ChannelBatchId = new ChannelBatchId();
//			ChannelBatchId.setChannelBatchid(channelBatchId);
//			ChannelBatchId.setChannelid(param.getChannelId());
//			final ChannelBatch channelBatch = (ChannelBatch) channelBatchDao.findById(ChannelBatchId);
//			if (null != channelBatch) {
//				channelBatch.setSucessnum(Long.parseLong(sucessNum));
//				channelBatch.setSucessamount(Double.parseDouble(sucessAmount));
//				channelBatch.setUnsucessnum(Long.parseLong(unSucessNum));
//				channelBatch.setUnsucessamount(Double.parseDouble(unSucessAmount));
//				channelBatch.setRetcode(returnState.getBankRetCode());
//				channelBatch.setRetdesc(channelBatch.getRetdesc());
//				channelBatchService.update(channelBatch);
//			} else {
//				throw new BizException("建行银企批量代收付结果时，更新channel_batch表异常，查找channel_batch为空，channelid="
//						+ ChannelBatchId.getChannelid() + "渠道批次：" + ChannelBatchId.getChannelBatchid());
//			}
//			// 调用基础平台处理接口
//			CallBizAdapter.dealBatchQuery(param.getChannelId(), param.getTransType(), channelBatchId);
//		} else {// 查询失败
//			returnState.setReturnState(PayState.FAILED_TRN);
//			returnState.setReturnMsg(dom4jxml.getNodeText(nodeItemHead, "RETURN_MSG"));
//		}
//		return returnState;
//	}
//
// }
