package com.lycheepay.clearing.adapter.banks.ccb.credit.kft.processor;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util.CcbCreditMsgUtilService;
import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util.J2DES;
import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util.LoUtils;
import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgPackUtils;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.DcFlag;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.RefundBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompletionCancelDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行信用卡交易服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午5:26:52
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDIT_SERVICE)
public class CcbCreditService extends BaseWithoutAuditLogService {

	// 清算交易记录
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	// 渠道参数
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	// 清算返回码处理
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	// 清算交易工具
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CREDIT_MSG_UTIL_SERVICE)
	private CcbCreditMsgUtilService ccbCreditMsgUtilService;

	private static final String channelId = ChannelIdEnum.CCB_CREDIT_CARD.getCode();


	/**
	 * 
	 * <p>预授权交易</p>
	 * 
	 * @param param
	 * @param bankSendSn
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public ReturnState dealGrant(final Param param, final String bankSendSn) throws BizException {
		final ReturnState returnState = new ReturnState();
		MsgPack grantMsgPack = new MsgPack();// 预授权包
		MsgPack retGrantMsgPack = new MsgPack();// 预授权返回包
		ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		String workKey = workKeyParm.getParvalue();

		Log4jUtil.info("---------------预授权 start...");
		// 创建预授权并发送,发送超时，则发预授权冲正，并返回失败信息
		try {
			grantMsgPack = ccbCreditMsgUtilService.createPreAuth(param, bankSendSn, workKey);
			retGrantMsgPack = ccbCreditMsgUtilService.sendMsg(grantMsgPack, workKey);
		} catch (final BizException e) {
			Log4jUtil.info("预授权发送与回执出错,开始预授权冲正处理！渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
			try {
				Log4jUtil.info("---------------预授权冲正 start...");
				ccbCreditMsgUtilService
						.sendMsg(
								ccbCreditMsgUtilService.createGrantRush(param, grantMsgPack, retGrantMsgPack, workKey),
								workKey);// 预授权冲正
				Log4jUtil.info("---------------预授权冲正 end...");
			} catch (final Exception e1) {
				Log4jUtil.info("预授权冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn,
					"预授权发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
		}

		if (retGrantMsgPack.getFieldContent39().equals("A0") || retGrantMsgPack.getFieldContent39().equals("77")) { // 重签到，仿Pos签到
			Log4jUtil.info("---------------重签到 start...");
			this.signProcess(true);
			Log4jUtil.info("---------------重签到 end...");
			workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
			workKey = workKeyParm.getParvalue();

			try {
				Log4jUtil.info("---------------预授权 重发 start...");
				grantMsgPack = ccbCreditMsgUtilService.createPreAuth(param, bankSendSn, workKey);
				retGrantMsgPack = ccbCreditMsgUtilService.sendMsg(grantMsgPack, workKey);
				Log4jUtil.info("---------------预授权 重发 end...");
			} catch (final BizException e) {
				Log4jUtil.info("预授权发送与回执出错,开始预授权冲正处理！渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
				try {
					Log4jUtil.info("---------------预授权冲正 start...");
					ccbCreditMsgUtilService.sendMsg(
							ccbCreditMsgUtilService.createGrantRush(param, grantMsgPack, retGrantMsgPack, workKey),
							workKey);// 预授权冲正
					Log4jUtil.info("---------------预授权冲正 end...");
				} catch (final Exception e1) {
					Log4jUtil.info("预授权冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
				}
				return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn,
						"预授权发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
			}
		}
		// 组数据returnState给调用者（基础平台）
		final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(),
				retGrantMsgPack.getRspCode()));
		String retMsg = "";
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
			retMsg = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		// 预授权失败的处理
		if (!retGrantMsgPack.getFieldContent39().equals("00")) {
			Log4jUtil.info("预授权失败,开始预授权冲正处理！渠道流水号：" + bankSendSn);
			try {
				Log4jUtil.info("---------------预授权冲正 start...");
				ccbCreditMsgUtilService
						.sendMsg(
								ccbCreditMsgUtilService.createGrantRush(param, grantMsgPack, retGrantMsgPack, workKey),
								workKey);// 预授权冲正
				Log4jUtil.info("---------------预授权冲正 end...");
			} catch (final Exception e) {
				Log4jUtil.info("预授权冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e.getMessage());
			}

			// 组数据returnState给调用者（基础平台）
			final ChannelRtncode channelRtncode_ = channelRtncodeService.findById(new ChannelRtncodeId(param
					.getChannelId(), retGrantMsgPack.getRspCode()));
			String retMsg_ = "";
			if (null == channelRtncode_) {
				returnState.setChannelCode(TransReturnCode.code_9900);
			} else {
				returnState.setChannelCode(channelRtncode_.getKftRtncode());// 快付通银行返回对照码
				retMsg_ = StringUtils.substring(channelRtncode_.getChannelReamrk(), 0, 100);
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, retMsg_,
					returnState.getChannelCode(), DcFlag.Debit, retGrantMsgPack.getFieldContent39());
		}

		Log4jUtil.info("---------------预授权 end...");

		returnState.setBankRetCode(retGrantMsgPack.getRspCode());// 银行返回代码
		returnState.setBankPostScript(retMsg);// 银行返回信息
		returnState.setReturnMsg(retMsg);

		BillnoSn billnoSn = new BillnoSn();
		billnoSn = billnoSnService.getBillnoSn(param.getChannelId(), bankSendSn);
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(param.getCardType());  // 卡类型
		returnState.setCreditNo(retGrantMsgPack.getFieldContent11() + "#" + retGrantMsgPack.getFieldContent37() + "#"
				+ retGrantMsgPack.getFieldContent38() + "#" + retGrantMsgPack.getFieldContent13());// 检索参考号

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		String authCode = retGrantMsgPack.getFieldContent38();// 授权响应码
		returnState.setPreAuthCode(authCode);
		returnState.setBankRetBatchId(batchNo);
		returnState.setCheckDate(DateUtil.getCurrentDate());

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}

		return returnState;
	}

	/**
	 * 
	 * <p>预授权撤销交易</p>
	 * 
	 * @param param
	 * @param bankSendSn 流水
	 * @param orgBankSendSn 原交易
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public ReturnState dealGrantCancel(final String bankSendSn, BillnoSn billnoSn) throws BizException {
		final ReturnState returnState = new ReturnState();
		MsgPack grantCancelMsgPack = new MsgPack();// 预授权撤销包
		MsgPack retGrantCancelMsgPack = new MsgPack();// 预授权撤销返回包
		ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		String workKey = workKeyParm.getParvalue();

		/**
		 * 查库数据组装实体类
		 */
		String accountNo = billnoSn.getOtheracctno();
		Double amount = billnoSn.getActualAmount().doubleValue();
		String field60_2 = billnoSn.getCreditbatchno();
		String field13 = StringUtils.substring(billnoSn.getTranDate(), 4, 8);// 20120505
		String field38 = "";
		String field11 = billnoSn.getBankSendSn();

		String bankRecvSn = billnoSn.getBankRecvSn();
		Log4jUtil.info("预授权交易中的POS中心返回的参数:{}", bankRecvSn);
		if (bankRecvSn != null && bankRecvSn.contains("#")) {
			final String[] item = bankRecvSn.split("#");
			// field11 = item[0];
			field38 = item[2];
			// field13 = item[3];
			Log4jUtil.info("field11:{},field13:{},field38:{}", field11, field13, field38);
		}

		Log4jUtil.info("-预授权撤销 start...");
		// 创建预授权并发送,发送超时，则发预授权冲正，并返回失败信息
		try {
			grantCancelMsgPack = ccbCreditMsgUtilService.createGrantCancel(accountNo, amount, field38, field60_2,
					field11, field13, workKey, bankSendSn);// 预授权撤销
			retGrantCancelMsgPack = ccbCreditMsgUtilService.sendMsg(grantCancelMsgPack, workKey);
		} catch (final BizException e) {
			Log4jUtil.error("预授权撤销发送与回执出错,开始预授权撤销冲正处理！渠道流水号：" + billnoSn.getBankSendSn(), e);
			try {
				Log4jUtil.info("-预授权撤销 冲正 start...");
				ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createGrantCancelRush(grantCancelMsgPack, workKey), workKey);// 预授权撤销冲正
				Log4jUtil.info("-预授权撤销 冲正 end...");
			} catch (final Exception e1) {
				Log4jUtil.error("预授权撤销冲正失败！渠道流水号：" + billnoSn.getBankSendSn(), e1);
			}
			return channelTransUtilService.makeReturnState(channelId, billnoSn.getBankSendSn(),
					"预授权撤销发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
		}

		if (retGrantCancelMsgPack.getFieldContent39().equals("A0")
				|| retGrantCancelMsgPack.getFieldContent39().equals("77")) { // 重签到，仿Pos签到
			Log4jUtil.info("-重签到 start...");
			this.signProcess(true);
			Log4jUtil.info("-重签到 end...");
			workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
			workKey = workKeyParm.getParvalue();

			try {
				Log4jUtil.info("-预授权撤销 重发 start...");
				grantCancelMsgPack = ccbCreditMsgUtilService.createGrantCancel(accountNo, amount, field38, field60_2,
						field11, field13, workKey, bankSendSn);
				retGrantCancelMsgPack = ccbCreditMsgUtilService.sendMsg(grantCancelMsgPack, workKey);
				Log4jUtil.info("-预授权撤销 重发  end...");
			} catch (final BizException e) {
				Log4jUtil.error("预授权撤销发送与回执出错,开始预授权撤销冲正处理！渠道流水号：" + billnoSn.getBankSendSn(), e);
				try {
					Log4jUtil.info("-预授权撤销 冲正 start...");
					ccbCreditMsgUtilService.sendMsg(
							ccbCreditMsgUtilService.createGrantCancelRush(grantCancelMsgPack, workKey), workKey);// 预授权撤销冲正
					Log4jUtil.info("-预授权撤销 冲正 end...");
				} catch (final Exception e1) {
					Log4jUtil.error("预授权撤销冲正失败！渠道流水号：" + billnoSn.getBankSendSn(), e1);
				}
				return channelTransUtilService.makeReturnState(channelId, billnoSn.getBankSendSn(),
						"预授权撤销发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
			}
		}

		// 组数据returnState给调用者（基础平台）
		final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				retGrantCancelMsgPack.getRspCode()));
		String retMsg = "";
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
			retMsg = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		Log4jUtil.info("-预授权撤销 end...");

		// 预授权撤销失败的处理
		if (!retGrantCancelMsgPack.getFieldContent39().equals("00")) {
			return channelTransUtilService.makeReturnState(channelId, billnoSn.getBankSendSn(), retMsg,
					returnState.getChannelCode(), DcFlag.Debit, retGrantCancelMsgPack.getFieldContent39());
		}


		returnState.setBankRetCode(retGrantCancelMsgPack.getRspCode());// 银行返回代码
		returnState.setBankPostScript(retMsg);// 银行返回信息
		returnState.setReturnMsg(retMsg);

		// returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		// returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(BankCardType.CREDIT_CARD);  // 卡类型
		returnState.setCreditNo(retGrantCancelMsgPack.getFieldContent11() + "#"
				+ retGrantCancelMsgPack.getFieldContent37() + "#" + retGrantCancelMsgPack.getFieldContent38() + "#"
				+ retGrantCancelMsgPack.getFieldContent13());// 检索参考号

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		returnState.setBankRetBatchId(batchNo);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		return returnState;
	}

	/**
	 * 
	 * <p>预授权完成交易</p>
	 * 
	 * @param param
	 * @param bankSendSn
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public ReturnState dealGrantFinish(final Param param, final String bankSendSn) throws BizException {
		Log4jUtil.info("---------------预授权完成交易 start...");
		final ReturnState returnState = new ReturnState();
		MsgPack grantFinishMsgPack = new MsgPack();// 预授权完成包
		MsgPack retFinishMsgPack = new MsgPack();// 预授权完成返回包
		ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		String workKey = workKeyParm.getParvalue();

		/**
		 * 查库数据组装实体类
		 */
		BillnoSn billnoSn = new BillnoSn();
		billnoSn = billnoSnService.getBillnoSn(param.getChannelId(), bankSendSn);
		String accountNo = billnoSn.getOtheracctno();
		Double amount = billnoSn.getActualAmount().doubleValue();
		String field60_2 = billnoSn.getCreditbatchno();
		String field13 = "";
		String field38 = "";
		String field11 = "";

		String bankRecvSn = billnoSn.getBankRecvSn();
		Log4jUtil.info("-------预授权交易中的POS中心返回的参数:" + bankRecvSn);
		if (bankRecvSn != null && bankRecvSn.contains("#")) {
			final String[] item = bankRecvSn.split("#");
			field11 = item[0];
			field38 = item[2];
			field13 = item[3];
			Log4jUtil.info("-------受卡方系统跟踪号截取为:" + field11);
			Log4jUtil.info("-------授权标识应答码截取为:" + field38);
			Log4jUtil.info("-------受卡方所在地日期截取为:" + field13);
		}

		// 创建预授权完成并发送,预授权完成发送超时，则发预授权完成冲正和预授权撤销，并返回失败信息
		try {
			grantFinishMsgPack = ccbCreditMsgUtilService.createGrantFinish(param, accountNo, amount, field38,
					field60_2, field11, field13, workKey);
			retFinishMsgPack = ccbCreditMsgUtilService.sendMsg(grantFinishMsgPack, workKey);
		} catch (final BizException e) {
			Log4jUtil.info(param.getChannelId() + ": 预授权完成发送超时,渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
			try {
				Log4jUtil.info("---------------预授权完成 冲正 start...");
				ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createGrantFinishRush(param,
						grantFinishMsgPack, retFinishMsgPack, workKey), workKey);// 预授权完成冲正
				Log4jUtil.info("---------------预授权完成 冲正 end...");
			} catch (final Exception e1) {
				Log4jUtil.info("预授权完成冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, e.getMessage(),
					e.getErrorCode());
		}

		if (retFinishMsgPack.getFieldContent39().equals("A0") || retFinishMsgPack.getFieldContent39().equals("77")) { // 重签到，仿Pos签到
			Log4jUtil.info("---------------重签到 start...");
			this.signProcess(true);
			Log4jUtil.info("---------------重签到 end...");
			workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
			workKey = workKeyParm.getParvalue();

			try {
				Log4jUtil.info("---------------预授权完成 重发 start...");
				grantFinishMsgPack = ccbCreditMsgUtilService.createGrantFinish(param, accountNo, amount, field38,
						field60_2, field11, field13, workKey);
				retFinishMsgPack = ccbCreditMsgUtilService.sendMsg(grantFinishMsgPack, workKey);
				Log4jUtil.info("---------------预授权完成 重发 end...");
			} catch (final BizException e) {
				Log4jUtil.info(param.getChannelId() + ": 预授权完成发送超时,渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
				try {
					Log4jUtil.info("---------------预授权完成 冲正 start...");
					ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createGrantFinishRush(param,
							grantFinishMsgPack, retFinishMsgPack, workKey), workKey);// 预授权完成冲正
					Log4jUtil.info("---------------预授权完成 冲正 end...");
				} catch (final Exception e1) {
					Log4jUtil.info("预授权完成冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
				}
				return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, e.getMessage(),
						e.getErrorCode());
			}
		}

		// 组数据returnState给调用者（基础平台）
		final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(),
				retFinishMsgPack.getRspCode()));
		String retMsg = "";
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
			retMsg = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		// 预授权完成失败的处理
		if (!retFinishMsgPack.getFieldContent39().equals("00")) {
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, retMsg, TransReturnCode.code_9900,
					DcFlag.Debit, retFinishMsgPack.getFieldContent39());
		}

		Log4jUtil.info("---------------预授权完成交易 end...");

		returnState.setBankRetCode(retFinishMsgPack.getRspCode());// 银行返回代码
		returnState.setBankPostScript(retMsg);// 银行返回信息
		returnState.setReturnMsg(retMsg);

		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(param.getCardType());  // 卡类型
		returnState.setCreditNo(retFinishMsgPack.getFieldContent11() + "#" + retFinishMsgPack.getFieldContent37() + "#"
				+ retFinishMsgPack.getFieldContent38() + "#" + retFinishMsgPack.getFieldContent13());// 检索参考号

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		returnState.setBankRetBatchId(batchNo);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		return returnState;
	}

	/**
	 * 
	 * <p>预授权完成撤销</p>
	 * 
	 * @param param
	 * @param bankSendSn
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public ReturnState dealGrantFinishCancel(final Param param, final String bankSendSn) throws BizException {
		final ReturnState returnState = new ReturnState();
		MsgPack grantFinishCancelMsgPack = new MsgPack();// 预授权完成撤销包
		MsgPack retGrantFinishCancelMsgPack = new MsgPack();// 预授权完成撤销返回包
		ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		String workKey = workKeyParm.getParvalue();
		/**
		 * 查库数据组装实体类
		 */
		BillnoSn billnoSn = new BillnoSn();
		billnoSn = billnoSnService.getBillnoSn(param.getChannelId(), bankSendSn);
		PreAuthCompletionCancelDTO dto = (PreAuthCompletionCancelDTO) param.getBizBean();
		String accountNo = billnoSn.getOtheracctno();
		Double amount = dto.getCancleAmount().doubleValue();

		String field60_2 = billnoSn.getCreditbatchno();
		String field13 = "";
		String field37 = "";
		String field38 = "";
		String field11 = "";

		String bankRecvSn = billnoSn.getBankRecvSn();
		Log4jUtil.info("-------预授权完成交易中的POS中心返回的参数:" + bankRecvSn);
		if (bankRecvSn != null && bankRecvSn.contains("#")) {
			final String[] item = bankRecvSn.split("#");
			field11 = item[0];
			field37 = item[1];
			field38 = item[2];
			field13 = item[3];
			Log4jUtil.info("-------受卡方系统跟踪号截取为:" + field11);
			Log4jUtil.info("-------检索参考号为:" + field37);
			Log4jUtil.info("-------授权标识应答码截取为:" + field38);
			Log4jUtil.info("-------受卡方所在地日期截取为:" + field13);
		}

		Log4jUtil.info("---------------预授权完成撤销 start...");
		// 创建预授权完成并发送,发送超时，则发预授权完成冲正，并返回失败信息
		try {
			grantFinishCancelMsgPack = ccbCreditMsgUtilService.createGrantFinishCancel(param, accountNo, amount,
					field37, field38, field60_2, field11, field13, workKey);// 预授权完成撤销
			retGrantFinishCancelMsgPack = ccbCreditMsgUtilService.sendMsg(grantFinishCancelMsgPack, workKey);
		} catch (final BizException e) {
			Log4jUtil.info("预授权完成撤销发送与回执出错,开始预授权完成撤销冲正处理！渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
			try {
				Log4jUtil.info("---------------预授权完成撤销 冲正 start...");
				ccbCreditMsgUtilService.sendMsg(
						ccbCreditMsgUtilService.createGrantFinishCancelRush(param, grantFinishCancelMsgPack, workKey),
						workKey);// 预授权完成撤销冲正
				Log4jUtil.info("---------------预授权完成撤销 冲正 end...");
			} catch (final Exception e1) {
				Log4jUtil.info("预授权完成撤销冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn,
					"预授权完成撤销发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
		}

		if (retGrantFinishCancelMsgPack.getFieldContent39().equals("A0")
				|| retGrantFinishCancelMsgPack.getFieldContent39().equals("77")) { // 重签到，仿Pos签到
			Log4jUtil.info("---------------重签到 start...");
			this.signProcess(true);
			Log4jUtil.info("---------------重签到 end...");
			workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
			workKey = workKeyParm.getParvalue();

			try {
				Log4jUtil.info("---------------预授权完成撤销 重发 start...");
				grantFinishCancelMsgPack = ccbCreditMsgUtilService.createGrantFinishCancel(param, accountNo, amount,
						field37, field38, field60_2, field11, field13, workKey);
				retGrantFinishCancelMsgPack = ccbCreditMsgUtilService.sendMsg(grantFinishCancelMsgPack, workKey);
				Log4jUtil.info("---------------预授权完成撤销 重发 end...");
			} catch (final BizException e) {
				Log4jUtil.info("预授权完成撤销发送与回执出错,开始预授权完成撤销冲正处理！渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
				try {
					Log4jUtil.info("---------------预授权完成撤销 冲正 start...");
					ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createGrantFinishCancelRush(param,
							grantFinishCancelMsgPack, workKey), workKey);// 预授权完成撤销冲正
					Log4jUtil.info("---------------预授权完成撤销 冲正 end...");
				} catch (final Exception e1) {
					Log4jUtil.info("预授权完成撤销冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
				}
				return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, "预授权完成撤销发送与回执出错,错误描述："
						+ e.getMessage(), e.getErrorCode());
			}
		}

		// 组数据returnState给调用者（基础平台）
		final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(),
				retGrantFinishCancelMsgPack.getRspCode()));
		String retMsg = "";
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
			retMsg = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		// 预授权完成撤销失败的处理
		if (!retGrantFinishCancelMsgPack.getFieldContent39().equals("00")) {
			// 组数据returnState给调用者（基础平台）
			final ChannelRtncode channelRtncode_ = channelRtncodeService.findById(new ChannelRtncodeId(param
					.getChannelId(), retGrantFinishCancelMsgPack.getRspCode()));
			String retMsg_ = "";
			if (null == channelRtncode_) {
				returnState.setChannelCode(TransReturnCode.code_9900);
			} else {
				returnState.setChannelCode(channelRtncode_.getKftRtncode());// 快付通银行返回对照码
				retMsg_ = StringUtils.substring(channelRtncode_.getChannelReamrk(), 0, 100);
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, retMsg_,
					returnState.getChannelCode(), DcFlag.Debit, retGrantFinishCancelMsgPack.getFieldContent39());
		}

		Log4jUtil.info("---------------预授权完成撤销 end...");

		returnState.setBankRetCode(retGrantFinishCancelMsgPack.getRspCode());// 银行返回代码
		returnState.setBankPostScript(retMsg);// 银行返回信息
		returnState.setReturnMsg(retMsg);

		billnoSn = billnoSnService.getBillnoSn(param.getChannelId(), bankSendSn);
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(param.getCardType());  // 卡类型
		returnState.setCreditNo(retGrantFinishCancelMsgPack.getFieldContent11() + "#"
				+ retGrantFinishCancelMsgPack.getFieldContent37() + "#"
				+ retGrantFinishCancelMsgPack.getFieldContent38() + "#"
				+ retGrantFinishCancelMsgPack.getFieldContent13());// 检索参考号

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		returnState.setBankRetBatchId(batchNo);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		return returnState;
	}

	/**
	 * 建行信用卡代扣处理---- 分两步完成： 1.预授权 2.预授权完成
	 * 
	 * @param param
	 * @param bankSendSn 渠道流水
	 * @return ReturnState
	 * @throws BizException
	 */
	public ReturnState deal(final Param param, final String bankSendSn) throws BizException {
		final ReturnState returnState = new ReturnState();
		MsgPack grantMsgPack = new MsgPack();// 预授权包
		MsgPack grantFinishMsgPack = new MsgPack();// 预授权完成包
		MsgPack retGrantMsgPack = new MsgPack();// 预授权返回包
		MsgPack retFinishMsgPack = new MsgPack();// 预授权完成返回包
		ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		String workKey = workKeyParm.getParvalue();

		Log4jUtil.info("步骤1：预授权 start...");
		// 创建预授权并发送,发送超时，则发预授权冲正，并返回失败信息
		try {
			grantMsgPack = ccbCreditMsgUtilService.createGrant(param, bankSendSn, workKey);
			retGrantMsgPack = ccbCreditMsgUtilService.sendMsg(grantMsgPack, workKey);
		} catch (final BizException e) {
			Log4jUtil.info("预授权发送与回执出错,开始预授权冲正处理！渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
			try {
				ccbCreditMsgUtilService
						.sendMsg(
								ccbCreditMsgUtilService.createGrantRush(param, grantMsgPack, retGrantMsgPack, workKey),
								workKey);// 预授权冲正
			} catch (final Exception e1) {
				Log4jUtil.info("预授权冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn,
					"预授权发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
		}

		if (retGrantMsgPack.getFieldContent39().equals("A0") || retGrantMsgPack.getFieldContent39().equals("77")) { // 重签到，仿Pos签到
			this.signProcess(true);
			workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
			workKey = workKeyParm.getParvalue();

			try {
				grantMsgPack = ccbCreditMsgUtilService.createGrant(param, bankSendSn, workKey);
				retGrantMsgPack = ccbCreditMsgUtilService.sendMsg(grantMsgPack, workKey);
			} catch (final BizException e) {
				Log4jUtil.info("预授权发送与回执出错,开始预授权冲正处理！渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
				try {
					ccbCreditMsgUtilService.sendMsg(
							ccbCreditMsgUtilService.createGrantRush(param, grantMsgPack, retGrantMsgPack, workKey),
							workKey);// 预授权冲正
				} catch (final Exception e1) {
					Log4jUtil.info("预授权冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
				}
				return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn,
						"预授权发送与回执出错,错误描述：" + e.getMessage(), e.getErrorCode());
			}
		}

		// 预授权失败的处理
		if (!retGrantMsgPack.getFieldContent39().equals("00")) {
			Log4jUtil.info("预授权失败,开始预授权冲正处理！渠道流水号：" + bankSendSn);
			try {
				ccbCreditMsgUtilService
						.sendMsg(
								ccbCreditMsgUtilService.createGrantRush(param, grantMsgPack, retGrantMsgPack, workKey),
								workKey);// 预授权冲正
			} catch (final Exception e) {
				Log4jUtil.info("预授权冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e.getMessage());
			}

			// 组数据returnState给调用者（基础平台）
			final ChannelRtncode channelRtncode_ = channelRtncodeService.findById(new ChannelRtncodeId(param
					.getChannelId(), retGrantMsgPack.getRspCode()));
			String retMsg_ = "";
			if (null == channelRtncode_) {
				returnState.setChannelCode(TransReturnCode.code_9900);
			} else {
				returnState.setChannelCode(channelRtncode_.getKftRtncode());// 快付通银行返回对照码
				retMsg_ = StringUtils.substring(channelRtncode_.getChannelReamrk(), 0, 100);
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, retMsg_,
					returnState.getChannelCode(), DcFlag.Debit, retGrantMsgPack.getFieldContent39());
		}

		Log4jUtil.info("步骤2：预授权完成 start...");
		// 创建预授权完成并发送,预授权完成发送超时，则发预授权完成冲正和预授权撤销，并返回失败信息
		try {
			grantFinishMsgPack = ccbCreditMsgUtilService.createGrantFinish(param, retGrantMsgPack, workKey);
			retFinishMsgPack = ccbCreditMsgUtilService.sendMsg(grantFinishMsgPack, workKey);
		} catch (final BizException e) {
			Log4jUtil.info(param.getChannelId() + ": 预授权完成发送超时,渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
			try {
				ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createGrantFinishRush(param,
						grantFinishMsgPack, retFinishMsgPack, workKey), workKey);// 预授权完成冲正
				ccbCreditMsgUtilService.sendMsg(
						ccbCreditMsgUtilService.createGrantCancel(param, retGrantMsgPack, workKey), workKey);// 预授权撤销
			} catch (final Exception e1) {
				Log4jUtil.info("预授权完成冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e1.getMessage());
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, e.getMessage(),
					e.getErrorCode());
		}

		// 组数据returnState给调用者（基础平台）
		final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(),
				retFinishMsgPack.getRspCode()));
		String retMsg = null;
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
			retMsg = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		// 预授权完成失败的处理
		if (!retFinishMsgPack.getFieldContent39().equals("00")) {
			Log4jUtil.info(param.getChannelId() + ":预授权完成失败,渠道流水号：" + bankSendSn + "错误信息：预授权完成失败");
			try {
				ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createGrantFinishRush(param,
						grantFinishMsgPack, retFinishMsgPack, workKey), workKey);// 预授权完成冲正
				ccbCreditMsgUtilService.sendMsg(
						ccbCreditMsgUtilService.createGrantCancel(param, retGrantMsgPack, workKey), workKey);// 预授权撤销
			} catch (final Exception e) {
				Log4jUtil.info("预授权完成冲正失败！渠道流水号：" + bankSendSn + ",错误信息为：" + e.getMessage());
			}
			return channelTransUtilService.makeReturnState(param.getChannelId(), bankSendSn, retMsg, TransReturnCode.code_9900,
					DcFlag.Debit, retFinishMsgPack.getFieldContent39());
		}

		returnState.setBankRetCode(retFinishMsgPack.getRspCode());// 银行返回代码
		returnState.setBankPostScript(retMsg);// 银行返回信息
		returnState.setReturnMsg(retMsg);

		BillnoSn billnoSn = new BillnoSn();
		billnoSn = billnoSnService.getBillnoSn(param.getChannelId(), bankSendSn);
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(param.getCardType());  // 卡类型
		returnState.setCreditNo(retFinishMsgPack.getFieldContent11() + "#" + retFinishMsgPack.getFieldContent37() + "#"
				+ retFinishMsgPack.getFieldContent38());// 检索参考号

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		returnState.setBankRetBatchId(batchNo);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		return returnState;
	}

	/**
	 * 仿pos签到处理
	 * 
	 * @param param
	 * @param reSetFlag 是否重新签到 是：true 否:false
	 * @throws BizException
	 */
	public ReturnState signProcess(final boolean reSetFlag) throws BizException {
		final ReturnState returnState = new ReturnState();
		// 判断是否已经签到，未签则执行签到 --------------签到标志 1- 已签 0-未签
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String signFlag = channelParms.get("100011");
		if ((!reSetFlag) && signFlag.equals("1")) {// 已签到
			returnState.setReturnState(PayState.SUCCEED_STR);
			returnState.setChannelCode(TransReturnCode.code_0000);
			return returnState;
		}

		final String bankSendSn = sequenceManagerService.getCcbCreditSN();

		// 签到并发送
		MsgPack signMsgPack = new MsgPack();// 签到包
		MsgPack retMsgPack = new MsgPack();// 签到返回包

		final ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		final String workKey = workKeyParm.getParvalue();

		try {
			signMsgPack = ccbCreditMsgUtilService.createSign(bankSendSn);
			retMsgPack = ccbCreditMsgUtilService.sendMsg(signMsgPack, workKey);
		} catch (final BizException e) {// 发送超时,签到失败
			return channelTransUtilService.makeReturnState(channelId, bankSendSn, e.getMessage(), e.getErrorCode());
		}
		// 签到失败
		if (!retMsgPack.getFieldContent39().equals("00")) {
			return channelTransUtilService.makeReturnState(channelId, bankSendSn, "建行信用卡签到失败",
					TransReturnCode.code_9900, DcFlag.Debit,
					retMsgPack.getFieldContent39());
		}
		// 更新channel_parm表中的信息包括批次号和返回版本号
		String batchNo;

		try {
			batchNo = retMsgPack.get60_2();
		} catch (BizException e) {
			throw new BizException(TransReturnCode.code_9109, e.getMessage());
		}

		ChannelParm channelParm = new ChannelParm();
		// 更新批次号
		channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		channelParm.setParvalue(batchNo);
		channelParmService.update(channelParm);

		// 更新签到标志为已签到
		channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100011"));
		channelParm.setParvalue("1");
		channelParmService.update(channelParm);

		// 更新工作密钥与工作密钥的checkValue
		final String[] keys = MsgPackUtils.getKey(retMsgPack);
		Log4jUtil.debug("keys:" + ArrayUtils.toString(keys));
		if (keys == null || keys.length != 4) {
			Log4jUtil.debug("无key,不需保存");
		} else {
			channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));

			// 用主密钥解工作密钥，形成明文密钥用于后期第64域生成
			final ChannelParm mainKeyParm = channelParmService
					.queryByPrimaryKey(new ChannelParmId(channelId, "100012"));
			AssertUtils.notNull(mainKeyParm, TransReturnCode.code_9109, "未得到主密钥");
			channelParm.setParvalue(decryptWorkkey(mainKeyParm.getParvalue(), keys[2], keys[3]));// 工作密钥
			channelParmService.update(channelParm);

			channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100014"));
			channelParm.setParvalue(keys[3]);// 工作密钥checkValue
			channelParmService.update(channelParm);
		}

		returnState.setReturnState(PayState.SUCCEED_STR);
		returnState.setChannelCode(TransReturnCode.code_0000);
		return returnState;
	}

	/**
	 * 
	 * 用主密钥解工作密钥，形成明文密钥用于后期第64域生成
	 * 
	 * @param mainKey
	 * @param workKey
	 * @return workKey
	 * @throws BizException
	 */
	public String decryptWorkkey(final String mainKey, final String workKey, final String checkValue)
			throws BizException {
		final byte[] workKeyCrypt = J2DES.trides_decrypt(LoUtils.hexStr2Bytes(mainKey), LoUtils.hexStr2Bytes(workKey));
		final String key = LoUtils.byte2HexStr(workKeyCrypt);
		Log4jUtil.info("工作密钥:{}双倍长密钥Des解码后明文：{}", workKey, key);

		// 对8个数值0做单倍长密钥算法，取结果的前四位与checkvalue的值比较应该是一致的
		// 检查是否解码正确。
		final byte[] check = J2DES.des_crypt(LoUtils.hexStr2Bytes(key), LoUtils.hexStr2Bytes("0000000000000000"));

		if (!checkValue.equals(LoUtils.byte2HexStr(check).substring(0, 8))) {
			final String error = StringUtil.r("工作密钥:{?}双倍长密钥Des解码后明文：{?} 不正确！", workKey, key);
			Log4jUtil.info(error);
			throw new BizException(error, TransReturnCode.code_9109);
		}
		return key;
	}

	/**
	 * 实时退款
	 * 
	 * @param realTimeRefund
	 * @param billnoSnOrg
	 * @return
	 * @throws BizException
	 */
	public ReturnState RealTimeRefund(final String newBankSendSn, final AutoRealTimeRefund realTimeRefund,
			final BillnoSn billnoSnOrg) throws BizException {

		final RefundBean bizBean = new RefundBean();
		final String accountNo = realTimeRefund.getRevBankCardNo();
		bizBean.setAmount(realTimeRefund.getRefundAmount());
		bizBean.setRefundType("01");

		bizBean.setBankSendSn(billnoSnOrg.getBankSendSn());

		Log4jUtil.info("-------pos中的POS中心流水号:" + billnoSnOrg.getBankRecvSn());
		String field37 = billnoSnOrg.getBankRecvSn();
		if (field37 != null && field37.contains("#")) {
			final String[] item = field37.split("#");
			field37 = item[1];
			Log4jUtil.info("-------pos中的POS中心流水号截取为:" + field37);
		}

		bizBean.setBankRecvSn(field37);
		bizBean.setTranDate(billnoSnOrg.getTranDate());
		bizBean.setBillnosnSeq(billnoSnOrg.getBillnosnSeq());
		bizBean.setCreditbatchno(billnoSnOrg.getCreditbatchno());

		ReturnState rs = dealPayRefund(bizBean, realTimeRefund.getSn(), accountNo, newBankSendSn);
		return rs;
	}

	/**
	 * 发送退货报文
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealPayRefund(final RefundBean bizBean, final String RefundSn, final String accountNo,
			final String newBankSendSn) throws BizException {
		// 发送退货请求
		MsgPack retMsgPack = new MsgPack();

		final ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		final String workKey = workKeyParm.getParvalue();

		retMsgPack = ccbCreditMsgUtilService.sendMsg(
				ccbCreditMsgUtilService.createReturn(bizBean, accountNo, workKey, newBankSendSn), workKey);
		// 处理返回
		final ReturnState rs = new ReturnState();
		if (retMsgPack.getFieldContent39().equals("00")) {
			rs.setCreditNo(retMsgPack.getFieldContent11() + "#" + retMsgPack.getFieldContent37());
			rs.setReturnState(PayState.SUCCEED_STR);
			rs.setChannelCode(TransReturnCode.code_0000);
			rs.setBankRetCode("00");
			rs.setBankPostScript("退款成功");
			rs.setReturnMsg("退款成功");
			Log4jUtil.info("建行信用卡退款处理成功,退款的[BillnosnSeq]为:" + bizBean.getBillnosnSeq());
		} else {
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
					retMsgPack.getRspCode()));
			String retMsg = "";
			if (null == channelRtncode) {
				rs.setChannelCode(TransReturnCode.code_9900);
			} else {
				rs.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
				retMsg = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
			}

			rs.setReturnState(PayState.FAILED_STR);
			rs.setBankRetCode(retMsgPack.getRspCode());
			rs.setBankPostScript(retMsg);
			rs.setReturnMsg(retMsg);

			Log4jUtil.info("建行信用卡退款处理失败,应答码为：{},描述为：{}", retMsgPack.getFieldContent39(), retMsg);
		}

		if (bizBean.getRefundType().equals("01")) {
			rs.setSn(RefundSn);
		} else if (bizBean.getRefundType().equals("02")) {
			rs.setSn(bizBean.getBillnosnSeq());
		}
		// 增加原交易的批次号
		rs.setBankRetBatchId(bizBean.getCreditbatchno());
		return rs;
	}


	/**
	 * 批结算
	 * 
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealBatSettle() throws BizException {
		final ReturnState rs = new ReturnState();
		String msg = "";

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		AssertUtils.notNull(batchNo, TransReturnCode.code_9108, "自动联机批结算的批次号不能为空");

		// 1.联机批结算
		MsgPack batSettleReq = new MsgPack();

		String jtotalAmt = "0";
		String jtotalNum = "0";
		String dtotalAmt = "0";
		String dtotalNum = "0";

		final Map<String, Object> jmap = billnoSnService.findBillnoSnByCreditbatchno(channelId, batchNo, "J");
		if (jmap != null && jmap.size() > 0) {
			jtotalAmt = jmap.get("TOTALAMT").toString();
			jtotalNum = jmap.get("TOTALNUM").toString();
		}
		Log4jUtil.info("自动联机批结算jmap:" + jmap);
		final Map<String, Object> dmap = billnoSnService.findBillnoSnByCreditbatchno(channelId, batchNo, "D");
		if (dmap != null && dmap.size() > 0) {
			dtotalAmt = dmap.get("TOTALAMT").toString();
			dtotalNum = dmap.get("TOTALNUM").toString();
		}
		Log4jUtil.info("自动联机批结算dmap:" + dmap);
		batSettleReq = ccbCreditMsgUtilService.createBatchSettle(batchNo, jtotalAmt, jtotalNum, dtotalAmt, dtotalNum);
		final MsgPack batSettleRsp = ccbCreditMsgUtilService.sendMsg(batSettleReq, null);
		if (batSettleRsp.getMsgType().equals("0510")) {
			// 更新签到标志为未签到，类似于签退
			final ChannelParm channelParm = channelParmService
					.queryByPrimaryKey(new ChannelParmId(channelId, "100011"));
			channelParm.setParvalue("0");
			channelParmService.update(channelParm);

			rs.setChannelCode(TransReturnCode.code_0000);
			msg = "联机批结算成功;";
		} else {
			rs.setChannelCode(TransReturnCode.code_9900);
			msg = "联机批结算失败,请稍后重试;";
		}
		Log4jUtil.info("自动联机批结算msg:" + msg);
		if (TransReturnCode.code_0000.equals(rs.getChannelCode())) { // 0000 为 ‘交易成功’
			rs.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			rs.setReturnState(PayState.FAILED_STR);
		}
		rs.setReturnMsg(msg);
		return rs;
	}

	/**
	 * 
	 * @Description: 7.2.7. 预授权完成撤销
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealRevoke(final String newBankSendSn, final AutoRealTimeRefund autoRealTimeRefund,
			final BillnoSn billnoSnOrg) throws BizException {
		// 发送撤销请求
		MsgPack reqMsgPack = new MsgPack();
		MsgPack retMsgPack = new MsgPack();

		final ChannelParm workKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
		final String workKey = workKeyParm.getParvalue();

		final String bankCardNo = autoRealTimeRefund.getRevBankCardNo();
		final BigDecimal refundAmount = autoRealTimeRefund.getRefundAmount();

		final String bankSendSn = billnoSnOrg.getBankSendSn(); // 发往银行流水
		final String tranDate = billnoSnOrg.getTranDate(); // 原流水的交易日期
		final String bankRecvSn = billnoSnOrg.getBankRecvSn(); // 仿pos中的POS中心流水号
		final String creditbatchno = billnoSnOrg.getCreditbatchno(); // 仿pos中的POS中心批次号

		Log4jUtil.info("-------pos中的POS中心流水号:" + bankRecvSn);
		String field37 = bankRecvSn;
		if (bankRecvSn != null && bankRecvSn.contains("#")) {
			final String[] item = bankRecvSn.split("#");
			field37 = item[1];
			Log4jUtil.info("-------pos中的POS中心流水号截取为:" + field37);
		}

		// 处理返回
		reqMsgPack = ccbCreditMsgUtilService.createRevoke(bankCardNo, refundAmount, workKey, bankSendSn, tranDate,
				field37, creditbatchno, newBankSendSn);
		try {
			retMsgPack = ccbCreditMsgUtilService.sendMsg(reqMsgPack, workKey);
		} catch (final BizException e) {
			// 需要冲正的情况
			Log4jUtil.error("撤销出错,开始撤销冲正处理！撤销流水号：" + autoRealTimeRefund.getSn() + "错误信息：", e);
			try {
				ccbCreditMsgUtilService.sendMsg(ccbCreditMsgUtilService.createRevokeRush(reqMsgPack, null, workKey),
						workKey);// 撤销冲正
			} catch (final BizException e1) {
				Log4jUtil.error("撤销出错,开始撤销冲正处理！撤销流水号：" + autoRealTimeRefund.getSn(), e1);
			}

			throw e;
		}

		final ReturnState rs = new ReturnState();

		if ("00".equals(retMsgPack.getFieldContent39())) {
			rs.setCreditNo(retMsgPack.getFieldContent11() + "#" + field37);
			rs.setReturnState(PayState.SUCCEED_STR);
			rs.setChannelCode(TransReturnCode.code_0000);
			rs.setBankRetCode("00");
			rs.setBankPostScript("撤销成功");
			rs.setReturnMsg("撤销成功");
			Log4jUtil.info("建行信用卡撤销处理成功,撤销的流水号为:" + autoRealTimeRefund.getSn());
		} else {
			final ChannelRtncode channelRtncode_ = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
					retMsgPack.getRspCode()));
			String retMsg_ = "";
			if (null == channelRtncode_) {
				rs.setChannelCode(TransReturnCode.code_9900);
			} else {
				rs.setChannelCode(channelRtncode_.getKftRtncode());// 快付通银行返回对照码
				retMsg_ = StringUtils.substring(channelRtncode_.getChannelReamrk(), 0, 100);
			}

			rs.setReturnState(PayState.FAILED_STR);
			rs.setBankRetCode(retMsgPack.getRspCode());
			rs.setBankPostScript(retMsg_);
			rs.setReturnMsg(retMsg_);

			Log4jUtil.info("建行信用卡撤销处理失败,应答码为：{},描述为：{}", retMsgPack.getFieldContent39(), retMsg_);
		}

		rs.setSn(autoRealTimeRefund.getSn());

		return rs;
	}
}
