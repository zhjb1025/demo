package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean;

/**
 * 
 * <P>信用卡还款批量授权入账接口信息</P>
 * 
 * @author 汤兴友 xytang
 */
public class BatchTrasNoticeRsp {
	String msgno;// 消息号
	String cmd;// 接口命令字 [BRCP]
	String retcode;// 返回码
	String orgcode;// 机构代码
	String subfiles;// 子文件数
	String totalrcd;// 总金额
	String totalamount;// 总笔数
	public String getMsgno() {
		return msgno;
	}
	public void setMsgno(String msgno) {
		this.msgno = msgno;
	}
	public String getCmd() {
		return cmd;
	}
	public void setCmd(String cmd) {
		this.cmd = cmd;
	}
	public String getRetcode() {
		return retcode;
	}
	public void setRetcode(String retcode) {
		this.retcode = retcode;
	}
	public String getOrgcode() {
		return orgcode;
	}
	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}
	public String getSubfiles() {
		return subfiles;
	}
	public void setSubfiles(String subfiles) {
		this.subfiles = subfiles;
	}
	public String getTotalrcd() {
		return totalrcd;
	}
	public void setTotalrcd(String totalrcd) {
		this.totalrcd = totalrcd;
	}
	public String getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(String totalamount) {
		this.totalamount = totalamount;
	}

}
