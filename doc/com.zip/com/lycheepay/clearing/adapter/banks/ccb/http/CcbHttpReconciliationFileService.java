/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.http;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.soofa.tx.service.BaseService;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行B2C/B2B对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.CCB_HTTP_RECONCILIATION_FILE_SERVICE)
public class CcbHttpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param targetFilePath 对账目标文件路径
	 * @param channelId 渠道ID
	 * @param reconciliationDate 对账日期
	 * @author 李斌(13665100450)
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String targetFilePath,
			final String channelId, final String reconciliationDate) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		BufferedReader bufferedReader = null;
		try {
			// 循环对文本逐行处理
			int currLine = 0;
			String data = null;
			final InputStreamReader reader = new InputStreamReader(new FileInputStream(targetFilePath),
					Charset.forName("GBK"));
			bufferedReader = new BufferedReader(reader);
			int i = 0; // ArrayList 记录数
			BigDecimal amount = BigDecimal.ZERO;
			while ((data = bufferedReader.readLine()) != null) {
				final ReconciliationFileDTO accBean = new ReconciliationFileDTO();
				currLine++; // 对账文件 行循环
				Log4jUtil.info(logPrefix + "对账文件第 " + currLine + " 行文件内容为：" + data);
				if (0 < data.trim().length()) {
					// 交易时间 定单号 付款方账号 支付金额 退款金额 柜台号 备注1 备注2 付款方式 订单状态 记账日期
					// 2011-05-13 10:47:53 2011051300000221 ***************1078 0.01 0.00 969968895
					// -- -- 本地 成功 20110513
					final String[] currentLineData = data.split("\t");
					if (1 < currentLineData.length) {
						String tradeDate = currentLineData[0].trim();// 交易日期时间
						if (!DateUtil.isValidDate(tradeDate, "yyyy-MM-dd HH:mm:ss")) {
							// 若不是合法交易时间，则直接跳过该行
							Log4jUtil.info(logPrefix + "该行不是合法的交易数据。");
							continue;
						} else {
							final Format format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
							try {
								tradeDate = DateUtil.getDate((Date) format.parseObject(tradeDate));
							} catch (final ParseException e) {
								throw new ClearingAdapterBizCheckedException(
										BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, e.getMessage());
							}
						}
						final String orderNo = currentLineData[1].trim();// 订单号
						final String amtTrade = currentLineData[3].trim();// 交易金额
						final BigDecimal tradeAmount = new BigDecimal(amtTrade);
						amount = amount.add(tradeAmount);
						final String retCode = currentLineData[9].trim();// 响应码
						accBean.setCheckDate(reconciliationDate);
						accBean.setBankSendId(orderNo); // 订单号
						accBean.setTransDate(tradeDate); // 交易日期
						accBean.setAmount(tradeAmount);// 交易金额
						accBean.setChannelId(channelId);
						if (tradeAmount.compareTo(BigDecimal.ZERO) > 0) {
							accBean.setPayGet(STR_GET);
						} else {
							accBean.setPayGet(STR_PAY);
						}
						// 交易状态 00-支付成功；01-支付失败；02-超时
						if (retCode.equals("成功")) {
							accBean.setBankTransState("00");
						} else {
							accBean.setBankTransState("01");
						}
						i++;
						String logMsg = logPrefix + "将对账文件中第" + currLine + "行数据构造accBean，添加到accBeanList的第" + i + "条记录:";
						logMsg = logMsg + " checkDate:" + accBean.getCheckDate() + " BankSendSn:"
								+ accBean.getBankSendId();
						logMsg = logMsg + " TranDate:" + accBean.getTransDate() + " TradeAmount:" + accBean.getAmount();
						Log4jUtil.info(logMsg);
						reconciliationFileDTOList.add(accBean);
					}
				}
			}// while
			Log4jUtil.info(logPrefix + "本次共成功生成 " + i + "行对账明细。总金额为：" + String.format("%1$.2f", amount));
		} catch (final IOException e) {
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix + "网银对账失败,文件:["
					+ targetFilePath + "]" + e, e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();
				}// 关闭文件
			} catch (final IOException e) {
				Log4jUtil.error(logPrefix + "关闭文件流出错:" + e);
				throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix + "网银对账失败,文件:["
						+ targetFilePath + "]" + e, e);
			}
		}
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix,
				targetFilePath, channelId, queryDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

}
