package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg.KFTPayXml6102;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg.KFTPayXml6112;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg.SocketMsg;
import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util.SendBySocket4Ccb;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.NoticeParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReceiveParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelBatchId;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建行银企处理xml公用服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午4:52:33
 */
@Service(ClearingAdapterAnnotationName.CCB_CORP_PROCESS_XML_SERVICE)
public class CcbCorpProcessXmlService extends BaseWithoutAuditLogService {
	// 清算交易记录
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	// 渠道参数
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	// 银行备付金账户
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	// 清算返回码处理
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	// 清算证件类型服务
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;

	@Value(value = "${verifyFlag}")
	private String verifyFlag;

	private static String channelId = ChannelIdEnum.CCB_CORP.getCode();
	private static final String singlePay = "6W1303";// 建行银企外联平台单笔代扣代付交易代码
	private static final String singleQuery = "6W1503";// 建行银企外联平台单笔代扣代付交易查询
	private static final String batchFileUpload = "6W2102";// 全国代发代扣文件上传
	private static final String batchPay = "6W2100";// 全国批量代发代扣交易
	private static final String batchQuery = "6W2104";// 全国批量代发代扣结果明细查询
	private static final String tranQuery = "6W0400";// 当日明细查询交易
	private static final String tranHisQuery = "6W0300";// 历史明细查询交易
	private static final String accountQuery = "6WY101";// 一点接入活期账户明细查询

	/**
	 * 向建行银企外联平台发送业务请求
	 * 
	 * @param sendXML
	 * @return
	 * @throws BizException
	 */
	public String sendXML(final String sendXML) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String socketIp = channelParms.get("100011").trim(); // socket的IP地址
		final String socketPort = channelParms.get("100012").trim(); // socket的端口

		final SendBySocket4Ccb sendBySocket = new SendBySocket4Ccb();
		return sendBySocket.sendAndRecv(socketIp, socketPort, sendXML);
	}

	/**
	 * 创建建行6W0400到账通知请求xml报文
	 */
	public String create6W0400XML(final NoticeParam nparam) throws BizException {

		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, tranQuery, sequenceManagerService.getCorpCCBSN(new Date()));
		// 创建子节点TX_INFO,并增加元素
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element ACC_NO = CorpElement.addElement("ACC_NO");// 快付通签约账号 必输
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(nparam
				.getChannelId());
		ACC_NO.setText(bankaccountBalance.getAccountNo());
		final Element STARTPAGE = CorpElement.addElement("STARTPAGE"); // 起始页次
		STARTPAGE.setText("1");
		final Element POSTSTR = CorpElement.addElement("POSTSTR"); // 查询定位串 (252定位串)可为空
		POSTSTR.setText("");
		final Element REM1 = CorpElement.addElement("REM1"); // 备注1
		REM1.setText("建行银企到账通知");
		final Element REM2 = CorpElement.addElement("REM2"); // 备注2
		REM2.setText(DateUtil.getCurrentDate());
		// 生成xml字符串
		return document.asXML();
	}

	/**
	 * 创建建行6W0300历史到账通知请求xml报文
	 */
	public String create6W0300XML(String pageNo, String account, String date) throws BizException {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, tranHisQuery, sequenceManagerService.getCorpCCBSN(new Date()));
		// 创建子节点TX_INFO,并增加元素
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element ACC_NO = CorpElement.addElement("ACC_NO");// 快付通签约账号 必输
		if (StringUtils.isBlank(account)) {
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
			ACC_NO.setText(bankaccountBalance.getAccountNo());
		} else {
			ACC_NO.setText(account);
		}
		final Element START_DATE = CorpElement.addElement("START_DATE"); // 起始日期
		START_DATE.setText(date);
		final Element END_DATE = CorpElement.addElement("END_DATE"); // 结束日期
		END_DATE.setText(date);
		final Element STARTPAGE = CorpElement.addElement("START_PAGE"); // 起始页次
		STARTPAGE.setText(pageNo);
		// final Element POSTSTR = CorpElement.addElement("POSTSTR"); // 查询定位串 (252定位串)可为空
		// POSTSTR.setText("");
		// final Element REM1 = CorpElement.addElement("REM1"); // 备注1
		// REM1.setText("建行银企历史交易明细");
		// final Element REM2 = CorpElement.addElement("REM2"); // 备注2
		// REM2.setText("到账通知");

		return document.asXML();
	}

	/**
	 * 创建建行外联平台单笔代收代扣请求xml报文
	 * 
	 * @param param 调用传递
	 * @param bankSendSn 渠道发送流水
	 * @param tranNo 交易类型 01-代收 02-代付
	 */
	public String create6W1303XML(final Param param, final String bankSendSn, final String tranNo) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);

		String corpAccID_JJ = channelParms.get("100034").trim();// 系统中配置好的基金平台企业账户ID
		String settleAcc_JJ = channelParms.get("100035").trim();// 系统中配置好的渠道基金结算户账号
		String settleAccName_JJ = channelParms.get("100036").trim();// 渠道基金结算户账号名称
		String settleAccBankNo_JJ = channelParms.get("100037").trim();// 渠道基金结算户账号行别
		AssertUtils.notNull(corpAccID_JJ, TransReturnCode.code_9108, "没有获取到系统配置的基金平台企业账户ID");
		AssertUtils.notNull(settleAcc_JJ, TransReturnCode.code_9108, "没有获取到系统配置的渠道基金结算户账号");
		AssertUtils.notNull(settleAccName_JJ, TransReturnCode.code_9108, "没有获取到系统配置的渠道基金结算户账号名称");
		AssertUtils.notNull(settleAccBankNo_JJ, TransReturnCode.code_9108, "没有获取到系统配置的渠道基金结算户行别");

		boolean isFundAcc = false;
		String useOfPay = "", useOfRev = "", billCodePay = "", billCodeRev = "", corpAccID = "", msg = "", remark = "";

		// 获取请求中传来的企业ID
		if (tranNo.equals("01")) {
			final DeductDTO deduct = (DeductDTO) param.getBizBean();
			corpAccID = deduct.getCorpAccountId();
			remark = deduct.getOrderNote();
		} else {
			final PayOutDTO pay = (PayOutDTO) param.getBizBean();
			corpAccID = pay.getCorpAccountId();
			remark = pay.getOrderNote();
		}

		isFundAcc = corpAccID_JJ.equals(corpAccID);

		if (!isFundAcc) {
			// 基础户参数
			useOfPay = channelParms.get("100002").trim(); // 用途编号：网银代发
			useOfRev = channelParms.get("100003").trim(); // 用途编号：网银代扣
			billCodePay = channelParms.get("100006").trim(); // 项目编号 ：代付项目编号
			billCodeRev = channelParms.get("100007").trim(); // 项目编号 ：代扣项目编号
			msg = "基础户";
		} else {
			// 基金户参数
			useOfPay = channelParms.get("100030").trim(); // 用途编号：网银代发
			useOfRev = channelParms.get("100031").trim(); // 用途编号：网银代扣
			billCodePay = channelParms.get("100032").trim(); // 项目编号 ：代付项目编号
			billCodeRev = channelParms.get("100033").trim(); // 项目编号 ：代扣项目编号
			msg = "基金户";
		}

		// 写渠道流水对照表(billno_sn)
		if (isFundAcc) {
			billnoSnService.saveBillnoSn(bankSendSn, param, settleAcc_JJ, settleAccName_JJ, settleAccBankNo_JJ);
		} else {
			billnoSnService.saveBillnoSn(bankSendSn, param);
		}
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, singlePay, bankSendSn);
		// 获取交易数据信息
		String accNo1 = "";// 转出帐户
		String accNo2 = "";// 转入帐户
		String amount = "";// 交易金额
		String otherName = "";// 对方姓名
		String billCode = "";// 代发代扣项目编号
		String userOfCode = "";// 用途编号

		// 渠道基金结算户账号不放在bankAccountBalance中，而是单独配置在channelParam中
		if (isFundAcc) {
			accNo1 = settleAcc_JJ;
		} else {
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(param
					.getChannelId());// 快付通绑定账号
			accNo1 = bankaccountBalance.getAccountNo();// 快付通账号
		}
		if (tranNo.equals("01")) { // 代收
			Log4jUtil.info("获取【{}-代扣】参数为：用途编号 {}，项目编号 {}，结算户 {}", msg, useOfRev, billCodeRev, accNo1);
		} else { // 代付
			Log4jUtil.info("获取【{}-代付】参数为：用途编号 {}，项目编号 {}，结算户 {}", msg, useOfPay, billCodePay, accNo1);
		}

		if (tranNo.equals("01")) {// 代收
			final DeductDTO deduct = (DeductDTO) param.getBizBean();
			otherName = deduct.getCardHolderName();
			accNo2 = deduct.getBankCardNo();
			amount = String.format("%1$.2f", deduct.getAmount());
			billCode = billCodeRev;
			userOfCode = useOfRev;
		} else {// 代付
			final PayOutDTO pay = (PayOutDTO) param.getBizBean();
			otherName = pay.getCardHolderName();
			accNo2 = pay.getBankCardNo();
			amount = String.format("%1$.2f", pay.getAmount());
			billCode = billCodePay;
			userOfCode = useOfPay;
		}
		// 交易数据信息创建子节点TX_INFO,并增加元素
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element ACC_NO1 = CorpElement.addElement("ACC_NO1"); // 转出帐户
		ACC_NO1.setText(accNo1);
		final Element BILL_CODE = CorpElement.addElement("BILL_CODE"); // 代发代扣编号
		BILL_CODE.setText(billCode);
		final Element ACC_NO2 = CorpElement.addElement("ACC_NO2"); // 转入帐户
		ACC_NO2.setText(accNo2);
		final Element OTHER_NAME = CorpElement.addElement("OTHER_NAME"); // 对方姓名
		OTHER_NAME.setText(otherName);
		final Element AMOUNT = CorpElement.addElement("AMOUNT"); // 金额
		AMOUNT.setText(amount);
		final Element USEOF_CODE = CorpElement.addElement("USEOF_CODE"); // 用途编号
		USEOF_CODE.setText(userOfCode);
		final Element FLOW_FLAG = CorpElement.addElement("FLOW_FLAG"); // 网银审批标识 空或0.不需审批 1.网银审批
		FLOW_FLAG.setText("0");
		final Element REM1 = CorpElement.addElement("REM1"); // 备注1
		REM1.setText(StringUtil.cutString(remark, 30));
		final Element REM2 = CorpElement.addElement("REM2"); // 备注2
		REM2.setText(DateUtil.getCurrentDate());
		// 签名信息段
		createSignXml(apElement);
		return document.asXML();
	}

	/**
	 * 解析建行外联平台单笔代收代付应答报文
	 * 
	 * @param xmlStr 报文字符串
	 * @param channelId param
	 * @param bankSendSn 渠道发送流水
	 * @return ReturnState
	 * @throws BizException
	 */
	public ReturnState parse6W1303XML(final String xmlStr, final Param param, final String bankSendSn, String tranNo)
			throws BizException {
		Log4jUtil.debug(xmlStr);
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));
		// 获取TX节点的数据
		final Node nodeItem = dom4jxml.getNode("/TX");
		final Node nodeDetail = dom4jxml.getNode("/TX/TX_INFO");
		String returnCode = dom4jxml.getNodeText(nodeItem, "RETURN_CODE");
		String returnMsg = dom4jxml.getNodeText(nodeItem, "RETURN_MSG");
		String creditNo = "";
		ReturnState returnState = new ReturnState();
		returnState.setBankRetCode(returnCode);// 银行返回代码
		returnState.setReturnMsg(returnMsg);// 银行返回信息
		// 组返回的实体
		if ("000000".equals(returnCode)) {
			creditNo = dom4jxml.getNodeText(nodeDetail, "CREDIT_NO");// 凭证号码
			returnState.setCheckDate(DateUtil.getCurrentDate()); // 备注发送时填写的当前日期
		}
		// 通过对照表查找建行银企返回码的平台对照码，如果找不到，则返回 9109 给平台
		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(),
				returnCode));
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9109);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		}
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) {
			returnState.setReturnState(PayState.SUCCEED_STR);
		} else if (TransReturnCode.code_9109.equals(returnState.getChannelCode())) {
			returnState.setReturnState(PayState.UNKNOW_STR);
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		returnState.setCreditNo(creditNo);// 保存银行返回凭证号码
		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		if (null != channelRtncode) {
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
		}
		return returnState;
	}

	/**
	 * 一点接入活期账户明细查询(6WY101)请求xml报文 ，结果用于对账
	 * 
	 * @param checkDate对账日期
	 * @param accountNo 账号
	 * @throws Exception,BizException
	 */
	public String create6WY101XML(final String checkDate, final String accountNo) throws BizException {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, accountQuery, sequenceManagerService.getCorpCCBSN(new Date()));
		// 交易体
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element ACCNO1 = CorpElement.addElement("ACCNO1");// 帐号
		ACCNO1.setText(accountNo);
		final Element STARTDATE = CorpElement.addElement("STARTDATE");// <STARTDATE>开始时间</STARTDATE>
		STARTDATE.setText(checkDate);
		final Element ENDDATE = CorpElement.addElement("ENDDATE");// <ENDDATE>结束时间</ENDDATE>
		ENDDATE.setText(checkDate);
		final Element BARGAIN_FLAG = CorpElement.addElement("BARGAIN_FLAG");// <>交易方向</BARGAIN_FLAG>
		BARGAIN_FLAG.setText("");
		final Element CHECK_ACC_NO = CorpElement.addElement("CHECK_ACC_NO");// <CHECK_ACC_NO>对方账户</CHECK_ACC_NO>
		CHECK_ACC_NO.setText("");
		final Element CHECK_ACC_NAME = CorpElement.addElement("CHECK_ACC_NAME");// <CHECK_ACC_NAME>对方帐户名称</CHECK_ACC_NAME>
		CHECK_ACC_NAME.setText("");
		final Element REMARK = CorpElement.addElement("REMARK");// <REMARK>摘要</REMARK>
		REMARK.setText("");
		final Element LOW_AMT = CorpElement.addElement("LOW_AMT");// <LOW_AMT>最小金额</LOW_AMT>
		LOW_AMT.setText("");
		final Element HIGH_AMT = CorpElement.addElement("HIGH_AMT");// <HIGH_AMT>最大金额</HIGH_AMT>
		HIGH_AMT.setText("");
		final Element PAGE = CorpElement.addElement("PAGE");// <PAGE>起始页</PAGE>
		PAGE.setText("");
		final Element POSTSTR = CorpElement.addElement("POSTSTR");// <POSTSTR>定位串</POSTSTR>
		POSTSTR.setText("");
		final Element TOTAL_RECORD = CorpElement.addElement("TOTAL_RECORD");// <TOTAL_RECORD>每页记录数</TOTAL_RECORD>
		TOTAL_RECORD.setText("");
		return document.asXML();
	}

	/**
	 * 创建建行建行外联平台单笔交易查询(6W1503)请求xml报文
	 * 
	 * @param param
	 */
	public String create6W1503XML(final Param param) throws BizException {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		final BillnoSn billNoSn = billnoSnService.findById(param.getSn());// FIXME
		if (billNoSn == null) {
			throw new BizException(param.getChannelId() + ":单笔查询查找billno_sn为空！");
		}
		createHeadXml(apElement, singleQuery, billNoSn.getBankSendSn());
		// 获取交易数据信息
		final String bankSendSn = billNoSn.getBankSendSn();
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element REQUEST_SN1 = CorpElement.addElement("REQUEST_SN1");// 原交易流水号
		REQUEST_SN1.setText(bankSendSn);
		return document.asXML();
	}

	/**
	 * 创建建行建行外联平台代发代扣流水查询(6W0501)请求xml报文
	 * 
	 * @param param
	 */
	public String create6W0501XML(final Param param) throws BizException {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, "6W0501", sequenceManagerService.getCorpCCBSN(new Date()));
		// 获取交易数据信息
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element ACC_NO = CorpElement.addElement("ACC_NO");// 付款帐户
		ACC_NO.setText("");
		final Element START_DATE = CorpElement.addElement("START_DATE");// 起始日期
		START_DATE.setText("");
		final Element END_DATE = CorpElement.addElement("END_DATE");// <>截止日期
		END_DATE.setText("");
		final Element CREDIT_NO = CorpElement.addElement("CREDIT_NO");// CREDIT_NO
		CREDIT_NO.setText("000031849779");
		final Element TRANTYPE = CorpElement.addElement("TRANTYPE");// TRANTYPE
		TRANTYPE.setText("1");
		final Element COMPLETED = CorpElement.addElement("COMPLETED");// <>单据状态
		COMPLETED.setText("0");
		final Element REM1 = CorpElement.addElement("REM1"); // 备注1
		REM1.setText("");
		final Element REM2 = CorpElement.addElement("REM2"); // 备注2
		REM2.setText(DateUtil.getCurrentDate());

		outXmlFile(document, "D:/6W0501");
		return document.asXML();
	}

	/**
	 * 向建行(分行线路)发送账号验证请求
	 * 
	 * @param param
	 * @return xml串
	 */
	public String createFundXML6102(final Param param) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String bankId = channelParms.get("100017").trim();// 监管行行别
		final String fundCustId = channelParms.get("100018").trim();// 快付通监管行客户号
		final String hostname = channelParms.get("100019").trim();// 监管行socketIP
		final Integer hostport = Integer.parseInt(channelParms.get("100020").toString());// 监管行socket端口
		final String certFile = channelParms.get("100021");// 签名文件（包含路径)
		final String certPassword = channelParms.get("100022");// 签名密码
		final String bankCertFile = channelParms.get("100023");// 监管银行证书（包含路径)

		// 获取验证要素
		final BankCardVerifyDTO accountVerfy = (BankCardVerifyDTO) param.getBizBean();
		AssertUtils.notNull(accountVerfy, TransReturnCode.code_9108, "建行报文方式的账户验证数据实体bean不能为空!");
		String sn = accountVerfy.getTxnId();// 验证流水
		String acctNo = accountVerfy.getBankCardNo();// 账号
		String acctName = accountVerfy.getCardHolderName();// 户名
		AssertUtils.notNull(acctNo, TransReturnCode.code_9108, "建行银企身份验证请求的银行账号不能为空!");
		AssertUtils.notNull(acctName, TransReturnCode.code_9108, "建行银企持卡人身份验证请求的户名不能为空!");
		String idType = accountVerfy.getCertificateType();// 证件类型
		String idNo = accountVerfy.getCertificateNo();// 证件号码
		// 组报文头和报文体
		final String msgID = sequenceManagerService.getMsgId(DateUtil.getCurrentDate());
		final KFTPayXml6102 xml6102 = new KFTPayXml6102(false, sequenceManagerService.getMsgId(DateUtil
				.getCurrentDate()));
		xml6102.getHead().setMsgID(msgID);
		xml6102.getHead().setMsgCode("6102");
		xml6102.getHead().setSrc(fundCustId);
		xml6102.getHead().setDes(bankId);
		xml6102.getHead().setMsgRef(msgID);
		xml6102.setSn(sn);
		xml6102.setAcctNo(acctNo);
		xml6102.setAcctName(acctName);
		if (StringUtils.isNotBlank(idNo) && StringUtils.isNotBlank(idType)) {
			idType = channelCertTypeService.getCertType(param.getChannelId(), idType);// 转换成渠道的证件类型
			xml6102.setIdType(idType);
			xml6102.setIdNo(idNo);
		} else {
			xml6102.setIdType("");
			xml6102.setIdNo("");
		}
		xml6102.buildxml();
		Log4jUtil.info("xml6102====" + xml6102.toString());
		Log4jUtil.info("verifyFlag:" + verifyFlag);
		// 发送验证请求，返回验证结果
		// 因为总行没有验证接口，所以走的是深圳分行的接口
		final SocketMsg socketMsg = new SocketMsg();
		String respXml = socketMsg.sendXMLToBank(hostname, hostport, fundCustId, "6102", xml6102.toString(), certFile,
				certPassword, bankCertFile, verifyFlag);
		return respXml;
	}

	/**
	 * 解析账号验证报文
	 * 
	 * @param param
	 * @return xml串
	 */
	public ReturnState parseFundXML6112(final String respXml, final Param param) throws BizException {
		final KFTPayXml6112 fundXML6112 = new KFTPayXml6112();
		fundXML6112.parsexml(respXml, Charset.forName("GBK"));
		final ReceiveParam receiveParam = new ReceiveParam();
		receiveParam.setReturnMsg(fundXML6112.getResultNote());// 交易错误信息
		receiveParam.setBankRetCode(fundXML6112.getResultCode());// 得到交易返回码
		receiveParam.setBankPostScript(fundXML6112.getResultNote());
		// receiveParam.setBankPostScript(fundXML6112.getOldSN());
		if ("0000".equals(fundXML6112.getChkResult()) && "0000".equals(fundXML6112.getResultCode())) {// 账户验证成功
			receiveParam.setChannelCode(TransReturnCode.code_0000);
			receiveParam.setReturnState(PayState.SUCCEED_STR);
		} else if ("9101".equals(fundXML6112.getChkResult())) {
			receiveParam.setChannelCode(TransReturnCode.code_2005);
			receiveParam.setReturnState(PayState.FAILED_STR);
		} else {
			receiveParam.setChannelCode(TransReturnCode.code_9900);
			receiveParam.setReturnState(PayState.FAILED_STR);
		}
		return receiveParam;
	}

	/**
	 * 解析6W1503XML单笔交易查询
	 * 
	 * @param xmlStr 报文字符串
	 * @param param
	 * @return ReturnState
	 * @throws BizException
	 */
	public ReturnState parse6W1503XML(final String xmlStr, final Param param) throws BizException {
		final ReturnState returnState = new ReturnState();
		Dom4jXMLMessage dom4jxml = null;
		// 解析xml报文
		dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));
		// 获取xml中TX节点的数据
		final Node nodeItem = dom4jxml.getNode("/TX");
		// 组返回的实体
		if (dom4jxml.getNodeText(nodeItem, "RETURN_CODE").equals("000000")) {// 原交易处理结果
			returnState.setReturnState(PayState.SUCCEED_STR);
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		final Node nodeDetail = dom4jxml.getNode("/TX/DEAL_RESULT");
		ChannelRtncode channelRtncode = null; // 通过对照表查找建行银企返回码的平台对照码，如果找不到，则返回 9900 给平台
		channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(), dom4jxml
				.getNodeText(nodeDetail, "DEAL_RESULT")));
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		}
		final String bankSendSn = dom4jxml.getNodeText(nodeItem, "REQUEST_SN"); // 渠道发送流水
		final BillnoSn billnoSn = billnoSnService.getBillnoSn(param.getChannelId(), bankSendSn);
		if (billnoSn == null) {
			throw new BizException("建行银企外联平台单笔代收代扣回执处理，通过渠道流水查找billno_SN	为空");
		}
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		returnState.setSn(billnoSn.getSn());
		// XXX By:Leon.Qiu 待完善 单笔查询用到此方法 用于基金
		// final Paybill paybill = payBillDao.findById(billnoSn.getSn());
		// if (paybill.equals(null)) {
		// throw new BizException("建行银企外联平台单笔代收代扣回执处理，通过sn查找paybill为空");
		// }
		// returnState.setRelTranAmount(paybill.getChannelAmount()); // 实际扣款金额
		returnState.setCardType(BankCardType.CREDIT_CARD);  // 暂用贷记卡表示
		return returnState;
	}

	/**
	 * 创建建行外联平台代发代扣文件上传(6W2102)请求xml报文
	 * 
	 * @param fileName
	 */
	public String create6W2102XML(final String fileName) throws BizException {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, batchFileUpload, sequenceManagerService.getCorpCCBSN(new Date()));
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element SEND_FILE = CorpElement.addElement("SEND_FILE");// 原交易流水号
		SEND_FILE.setText(fileName);
		return document.asXML();
	}

	/**
	 * 解析6W2102全国代发代扣文件上传返回文件名
	 * 
	 * @param xmlStr
	 * @return
	 * @throws BizException
	 */
	public String parse6W2102XML(final String xmlStr) throws BizException {
		String sendFile = "";// 网银上传文件名
		Dom4jXMLMessage dom4jxml = null;
		// 解析xml报文
		dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));
		// 获取xml中TX节点的数据
		final Node nodeRoot = dom4jxml.getNode("/TX");
		// 组返回的实体
		if (dom4jxml.getNodeText(nodeRoot, "RETURN_CODE").equals("000000")) {// 原交易处理结果
			final Node nodeItem = dom4jxml.getNode("/TX/TX_INFO");
			sendFile = dom4jxml.getNodeText(nodeItem, "SEND_FILE");
		} else {
			throw new BizException("解析6W2102全国代发代扣文件上传返回文件名出错" + dom4jxml.getNodeText(nodeRoot, "RETURN_MSG"));
		}
		return sendFile;
	}

	/**
	 * 全国批量代发代扣结果明细查询(6W2104)请求xml报文
	 * 
	 * @param param
	 */
	public String create6W2104XML(final String channelBatchId) throws BizException {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		final Element apElement = document.addElement("TX");// 创建根节点TX
		createHeadXml(apElement, batchQuery, sequenceManagerService.getCorpCCBSN(new Date()));// 创建公共头信息
		final Element CorpElement = apElement.addElement("TX_INFO");// 创建TX下的子结点TX_INFO
		// String bankBatchId = channelBatchService.findBankBatchNo(param.getChannelId(),
		// (String)param.getBizBean());
		final Element REQUEST_SN1 = CorpElement.addElement("REQUEST_SN1");// 原请求序列号
		REQUEST_SN1.setText(channelBatchId);
		return document.asXML();// 生成xml字符串
	}

	/**
	 * 创建建行6W2100批量代扣 代付请求xml报文
	 * 
	 * @param param 调用传递
	 * @param batchId //渠道发送批次号
	 * @param batchFileName 批量文件名
	 * @param repeatSend 重发标志
	 */
	public String create6W2100XML(final List<ChannelTempBill> payList, final String batchId,
			final String batchFileName, final boolean repeatSend) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);

		String corpAccID_JJ = channelParms.get("100034").trim();// 系统中配置好的基金平台企业账户ID
		String settleAcc_JJ = channelParms.get("100035").trim();// 系统中配置好的渠道基金结算户账号
		String settleAccName_JJ = channelParms.get("100036").trim();// 渠道基金结算户账号名称
		String settleAccBankNo_JJ = channelParms.get("100037").trim();// 渠道基金结算户账号行别
		AssertUtils.notNull(corpAccID_JJ, TransReturnCode.code_9108, "没有获取到系统配置的基金平台企业账户ID");
		AssertUtils.notNull(settleAcc_JJ, TransReturnCode.code_9108, "没有获取到系统配置的渠道基金结算户账号");
		AssertUtils.notNull(settleAccName_JJ, TransReturnCode.code_9108, "没有获取到系统配置的渠道基金结算户账号名称");
		AssertUtils.notNull(settleAccBankNo_JJ, TransReturnCode.code_9108, "没有获取到系统配置的渠道基金结算户行别");

		// 判断企业编号
		String corpNo = payList.get(0).getCorpNo();
		boolean isFundAcc = corpAccID_JJ.equals(corpNo);
		String useOfPay = "", useOfRev = "", billCodePay = "", billCodeRev = "", msg = "";

		if (!isFundAcc) {
			// 基础户参数
			useOfPay = channelParms.get("100002").trim(); // 用途编号：网银代发
			useOfRev = channelParms.get("100003").trim(); // 用途编号：网银代扣
			billCodePay = channelParms.get("100006").trim(); // 项目编号 ：代付项目编号
			billCodeRev = channelParms.get("100007").trim(); // 项目编号 ：代扣项目编号
			msg = "基础户";
		} else {
			// 基金户参数
			useOfPay = channelParms.get("100030").trim(); // 用途编号：网银代发
			useOfRev = channelParms.get("100031").trim(); // 用途编号：网银代扣
			billCodePay = channelParms.get("100032").trim(); // 项目编号 ：代付项目编号
			billCodeRev = channelParms.get("100033").trim(); // 项目编号 ：代扣项目编号
			msg = "基金户";
		}

		final String batchFilePath = channelParms.get("100005"); // 批量代收付文件存放路径
		final String ftpAdd = channelParms.get("100013").trim(); // 前置客户端ftp的地址
		final String ftpUser = channelParms.get("100014").trim(); // ftp的用户
		final String ftpPwd = channelParms.get("100015"); // ftp的密码
		final String ftpDir = channelParms.get("100016").trim(); // ftp默认目录

		String retNumAmt = "0|0";// 总记录数|总金额
		String userOfCode = "";// 用途编号
		String useName = "";// 用途
		String billCode = "";// 代发代扣项目编号
		String billName = "";// 代发代扣项目名称
		String billflag = "";// 代发代扣标志
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, batchPay, batchId);
		// 创建子节点TX_INFO,并增加元素
		final ChannelTempBill channelTempBill = payList.get(0);
		if (channelTempBill.getTransType().equals(ClearingTransType.BATCH_DEDUCT)) {// 批量代收
			billflag = "1";
			billCode = billCodeRev;
			billName = "深圳快付通代扣";
			userOfCode = useOfRev;
			useName = "网银代扣";
		} else {
			billflag = "0"; // 批量代付 批量提现
			billCode = billCodePay;
			billName = "深圳快付通代付";
			userOfCode = useOfPay;
			useName = "网银代发";
		}
		final Element CorpElement = apElement.addElement("TX_INFO");//
		final Element BILL_CODE = CorpElement.addElement("BILL_CODE");// 代发代扣编号
		BILL_CODE.setText(billCode);
		final Element BILLDESC = CorpElement.addElement("BILLDESC");// 代发代扣项目名称
		BILLDESC.setText(billName);
		final Element BILL_FLAG = CorpElement.addElement("BILL_FLAG");// 代发代扣标志
		BILL_FLAG.setText(billflag);
		final Element USEOF_CODE = CorpElement.addElement("USEOF_CODE");// 用途编号
		USEOF_CODE.setText(userOfCode);
		final Element USE = CorpElement.addElement("USE");// 用途
		USE.setText(useName);

		// 渠道基金结算户账号不放在bankAccountBalance中，而是单独配置在channelParam中
		BankaccountBalance bankaccountBalance = null;
		if (isFundAcc) {
			bankaccountBalance = new BankaccountBalance();
			bankaccountBalance.setAccountNo(settleAcc_JJ);
			bankaccountBalance.setAccountName(settleAccName_JJ);
			bankaccountBalance.setBankNo(settleAccBankNo_JJ);
		} else {
			bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelTempBill.getChannelId());// 快付通绑定账号
		}

		// Log4jUtil 输出
		if (billflag.equals("1")) { // 代收
			Log4jUtil.info("---获取【{}-批量代扣】参数为：用途编号 {}，项目编号 {}，结算户 {}", msg, useOfRev, billCodeRev,
					bankaccountBalance.getAccountName() + bankaccountBalance.getAccountNo());
		} else { // 代付
			Log4jUtil.info("---获取【{}-批量代付】参数为：用途编号 {}，项目编号 {}，结算户 {}", msg, useOfPay, billCodePay,
					bankaccountBalance.getAccountName() + bankaccountBalance.getAccountNo());
		}

		// 生成批量文件到指定目录 并返回 ：总记录数|总金额
		// if (repeatSend) {//TODO Terry 批量重发
		// retNumAmt = createBatchFileAgain(param, batchFileName, batchId);
		// } else {
		retNumAmt = createBatchFile(payList, batchFileName, batchId, bankaccountBalance);
		// }
		Log4jUtil.info("retNumAmt====总记录数|总金额" + retNumAmt);
		if (retNumAmt.substring(0, retNumAmt.indexOf("|")).equals("0")) {// 总笔数为0
			final String netNo = channelTempBill.getTaskId();// 支付场次
			Log4jUtil.info("建行银企渠道批次为：" + netNo + "总笔数为0");
			throw new BizException("建行银企渠道批次为：" + netNo + "总笔数为0");
		}
		// ftp上传文件到前置机
		final FtpManager ftpManager = new FtpManager();
		ftpManager.setServer(ftpAdd);
		ftpManager.setUser(ftpUser);
		ftpManager.setPassword(ftpPwd);
		ftpManager.setPath("");// 前置客户端ftp目录
		ftpManager.setLocalPath(batchFilePath);// 本地路径
		ftpManager.setFilename(batchFileName);// 文件名
		ftpManager.putMyFile_actionPerformed();// 上传文件
		// 发送请求
		String create6w2102xml = create6W2102XML(ftpDir + batchFileName);

		String sendFile = "";
		try {
			sendFile = parse6W2102XML(sendXML(create6w2102xml));
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e1) {
				Log4jUtil.error(e1.getMessage(), e1);
			}
			sendFile = parse6W2102XML(sendXML(create6w2102xml));
		}
		Log4jUtil.info("sendFile====" + sendFile);
		final Element SEND_FILE = CorpElement.addElement("SEND_FILE");// 上传文件名
		SEND_FILE.setText(sendFile);
		final Element ORI_FILE = CorpElement.addElement("ORI_FILE");// 原文件名
		ORI_FILE.setText(batchFileName);
		final Element ACC_NO = CorpElement.addElement("ACC_NO");// 账号
		ACC_NO.setText(bankaccountBalance.getAccountNo());
		final Element AMOUNT = CorpElement.addElement("AMOUNT");// 总金额
		AMOUNT.setText(retNumAmt.substring(retNumAmt.indexOf("|") + 1, retNumAmt.length()));
		final Element COUNT = CorpElement.addElement("COUNT");// 总笔数
		final String count = retNumAmt.substring(0, retNumAmt.indexOf("|"));
		COUNT.setText(count);
		final Element ASYN_FLAG = CorpElement.addElement("ASYN_FLAG");// 异步处理标识
		if (Double.parseDouble(count) > 50000) {
			ASYN_FLAG.setText("1");
		} else {
			ASYN_FLAG.setText("0");
		}
		// 签名段
		createSignXml(apElement);
		return document.asXML();
	}

	/**
	 * 创建建行银企外联平台请求报文的HEAD
	 * 
	 * @param Element
	 * @param txCode 银企交易代码 如：6W1303
	 * @param bankSendSn 渠道发送流水
	 */
	public void createHeadXml(final Element apElement, final String txCode, final String bankSendSn) {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String userId = channelParms.get("100009").trim(); // 建行银企前置客户端登录用户号
		final String userPwd = channelParms.get("100010"); // 建行银企前置客户端登录用密码

		final Element REQUEST_SN = apElement.addElement("REQUEST_SN");// 请求序列码
		REQUEST_SN.setText(bankSendSn);
		final Element CUST_ID = apElement.addElement("CUST_ID");// 客户号
		CUST_ID.setText(channelParms.get("100024"));
		final Element USER_ID = apElement.addElement("USER_ID");// 操作员号
		USER_ID.setText(userId);
		final Element PASSWORD = apElement.addElement("PASSWORD");// 密码
		PASSWORD.setText(userPwd);
		final Element TX_CODE = apElement.addElement("TX_CODE");// 交易代码
		TX_CODE.setText(txCode);
		final Element LANGUAGE = apElement.addElement("LANGUAGE");// 语言
		LANGUAGE.setText("CN");

	}

	/**
	 * 创建建行银企外联平台请求报文的签名信息
	 * 
	 * @param Element
	 */
	private void createSignXml(final Element apElement) {

		final Element SIGN_INFO = apElement.addElement("SIGN_INFO"); // 签名信息
		SIGN_INFO.setText("");
		final Element SIGNCERT = apElement.addElement("SIGNCERT"); // 签名CA信息
		SIGNCERT.setText("");

	}

	/**
	 * 生成批量处理文件--重发
	 * 
	 * @param param 调用传递对象
	 * @param batchFileName 批量文件名
	 * @param batchId 渠道批次号
	 * @return 返回值为 "总记录数|总金额"
	 * @throws BizException
	 */
	private String createBatchFileAgain(final Param param, final String batchFileName, final String batchId)
			throws BizException {
		String retNumAmt = "0|0"; // 返回值,格式为 "总记录数|总金额"
		final String channelBatch = (String) param.getBizBean(); // 渠道支付批次
		Log4jUtil.info("param.getChannelId()=======" + param.getChannelId());
		Log4jUtil.info("channelBatch===========" + channelBatch);
		Log4jUtil.info("param.getTransType()===========" + param.getClearingTransType());
		final List<BillnoSn> billnoSnList = billnoSnService.findByChanneiIdAndchannelBatchIdAndTranType(
				param.getChannelId(), channelBatch, param.getClearingTransType());// 批量记录集
		if (billnoSnList.size() > 0) {
			retNumAmt = String.valueOf(billnoSnList.size()) + "|"
					+ create_BatchFile_again(billnoSnList, batchFileName, param);// "总记录数|总金额"
		}
		Log4jUtil.info("retNumAmt==========================" + retNumAmt);
		Log4jUtil.info("建行行银企批量重发文件:" + batchFileName + "已生成");
		return retNumAmt;
	}

	/**
	 * 从billnoSn表里面取出交易数据，生产批量代收业务文件，并返回总金额
	 * 
	 * @param billnoSnList 批量业务的 list
	 * @param fileName 批量业务文件名
	 * @param batchId 渠道发送批次
	 * @return String 批量业务的总金额
	 * @throws BizException
	 */
	private String create_BatchFile_again(final List<BillnoSn> billnoSnList, final String fileName, final Param param)
			throws BizException {

		String cardName;// 对方户名
		String cardNo;// 对方账号
		String channelAmount;// 金额
		String fileStr;// 保存文件内容
		final StringBuffer sbStr = new StringBuffer("");
		BigDecimal dAmtTotal = BigDecimal.ZERO;
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService
				.getBankaccountBean(param.getChannelId());
		if (param.getClearingTransType().toString().equals(ClearingTransType.BATCH_DEDUCT)) {// 批量代收
			// 循环处理从billnoSn表里面取出来的数据
			for (int i = 0; i < billnoSnList.size(); i++) {
				cardNo = billnoSnList.get(i).getOtheracctno(); // 对方账号
				cardName = billnoSnList.get(i).getOtheracctname();// 对方户名
				channelAmount = String.format("%1$.2f", billnoSnList.get(i).getAmount());// 金额
				// 总金额
				dAmtTotal = dAmtTotal.add(billnoSnList.get(i).getAmount());
				// 付款账号,金额,收款人账号,付款人姓名,收款银行名称,摘要(这里填写渠道发送流水)
				final String split = ",";
				final String billnoSeq = billnoSnList.get(i).getBillnosnSeq();
				sbStr.append(cardNo).append(split).append(channelAmount).append(split)
						.append(bankaccountBalance.getAccountNo()).append(split).append(cardName).append(split)
						.append("建行").append(split).append(billnoSeq).append("\n");
			}
		} else {// 代付 提现等
			for (int i = 0; i < billnoSnList.size(); i++) {
				cardNo = billnoSnList.get(i).getOtheracctno(); // 对方账号
				cardName = billnoSnList.get(i).getOtheracctname();// 对方户名
				channelAmount = String.format("%1$.2f", billnoSnList.get(i).getAmount());// 金额
				final String bankName = String.valueOf(billnoSnList.get(i).getOtherbankno());// 收款银行名称
				// 总金额
				dAmtTotal = dAmtTotal.add(billnoSnList.get(i).getAmount());
				// 付款账号,金额,收款人账号,收款人姓名,收款银行名称,摘要”
				final String split = ",";
				final String billnoSeq = billnoSnList.get(i).getBillnosnSeq();
				sbStr.append(bankaccountBalance.getAccountNo()).append(split).append(channelAmount).append(split)
						.append(cardNo).append(split).append(cardName).append(split).append("建行").append(split)
						.append(billnoSeq).append("\n");
			}
		}
		// 将文件写到本地
		fileStr = sbStr.toString();
		try {
			createBatchFile(fileName, fileStr); // 文件名+文件内容
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException("生成建行银企批量重发文件异常：" + e.getMessage());
		}
		// 组返回结果，并返回给调用者
		return String.format("%1$.2f", dAmtTotal);
	}

	/**
	 * 生成文件
	 * 
	 * @param filePath 文件所在的文件夹
	 * @param fileName 文件名称
	 * @param fileValue文件内容
	 * @return 文件名（含相对路径文件夹）
	 * @throws BizException
	 */
	private String createBatchFile(final String fileName, final String fileValue) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String batchFilePath = channelParms.get("100005"); // 批量代收付文件存放路径
		// PrintWriter pw=null;
		FileProcess.createDir(batchFilePath); // 如果文件夹不存在，创建文件夹
		final String AccFile = batchFilePath + File.separator + fileName; // 含相对路径的文件名
		try {
			// pw = new PrintWriter(AccFile);
			// pw.write(fileValue);
			// pw.flush();
			// pw.close();
			FileUtils.writeStringToFile(new File(AccFile), fileValue, "GBK");
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException("生成文件出错！！" + e.getMessage());
		}
		return AccFile;
	}

	/**
	 * 将xml串以文件形式输出
	 * 
	 * @param document
	 * @param fileName
	 */
	public void outXmlFile(final Document document, final String fileName) {
		XMLWriter output;
		// 输出格式化
		final OutputFormat format = OutputFormat.createPrettyPrint();
		format.setEncoding("GBK");
		try {
			output = new XMLWriter(new FileWriter(fileName), format);
			output.write(document);
			output.close();
		} catch (final IOException e) {
			Log4jUtil.error(e);
		}
	}

	// /**
	// * 渠道锁定渠道清算表的相应记录，根据支付场次、渠道编号、交易类型在渠道批次表中查找是否已经有该批次记录 如果有（说明已经往清算行发送过交易了）则直接返回处理成功
	// *
	// * @param param
	// * @return 处理结果
	// * @throws BizException
	// */
	// @SuppressWarnings("unchecked")
	// public ReturnState batchFront(final Param param) throws BizException {
	// final ChannelSettleCmdId channelSettleCmdId = (ChannelSettleCmdId) param.getBizBean();
	// final String netNO = channelSettleCmdId.getNetNo();// 支付场次
	// // 渠道锁定渠道清算表的相应记录
	// channelSettleCmdDao.getByIdForLock(netNO, param.getChannelId(), param.getTransType());
	// // 据支付场次、渠道编号、交易类型在渠道批次表中查找是否已经有该批次记录
	// final List list = channelBatchDao.getList(netNO, param.getChannelId(), param.getTransType());
	// final ReturnState returnState = new ReturnState();
	// if (list.size() > 0) {
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// } else {
	// returnState.setReturnState(PayState.FAILED_TRN);
	// }
	// return returnState;
	// }
	//
	/**
	 * 生成批量处理文件
	 * 
	 * @param payList 调用传递对象
	 * @param batchFileName 批量文件名
	 * @param batchId 渠道批次号
	 * @param bankaccountBalance
	 * @return 返回值为 "总记录数|总金额"
	 * @throws BizException
	 */
	private String createBatchFile(final List<ChannelTempBill> payList, final String batchFileName,
			final String batchId, final BankaccountBalance bankaccountBalance) throws BizException {
		String retNumAmt = "0|0"; // 返回值,格式为 "总记录数|总金额"

		final String transType = payList.get(0).getTransType();
		if (ClearingTransType.BATCH_PAY.equals(transType)) {
			retNumAmt = createPay_Batch_File(payList, batchFileName, batchId, bankaccountBalance);// "总记录数|总金额"
		} else if (ClearingTransType.BATCH_DEDUCT.equals(transType)) {
			retNumAmt = createDebit_Batch_File(payList, batchFileName, batchId, bankaccountBalance);// "总记录数|总金额"
		} else {
			final String logText = "错误的交易类型：" + transType;
			Log4jUtil.error(logText);
			throw new BizException(TransReturnCode.code_9108, logText);
		}

		Log4jUtil.info("建行银企批量文件:" + batchFileName + "已生成");
		return retNumAmt;
	}

	/**
	 * 解析6W2100批量代收付应答报文
	 * 
	 * @param xmlStr 报文字符串
	 * @param channelTempBill 调用传递
	 * @param batchId 渠道批次
	 * @param repeatSend
	 * @return ReturnState
	 * @throws BizException
	 */
	public BatchSendResult parse6W2100XML(final String xmlStr, final ChannelTempBill channelTempBill,
			final String batchId, final boolean repeatSend) throws BizException {
		// 解析xml报文
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));
		// 获取xml中TX节点的数据
		final Node nodeItem = dom4jxml.getNode("/TX");
		final BatchSendResult batchSendResult = new BatchSendResult();
		batchSendResult.setBankReturnCode(dom4jxml.getNodeText(nodeItem, "RETURN_CODE"));// 银行返回代码
		batchSendResult.setBankReturnMsg(dom4jxml.getNodeText(nodeItem, "RETURN_MSG"));
		final String BkTxStatus = dom4jxml.getNodeText(nodeItem, "RETURN_CODE");
		// ChannelRtncode channelRtncode = channelRtncodeService.findById(new
		// ChannelRtncodeId(channelTempBill
		// .getChannelId(), BkTxStatus));
		// if (null == channelRtncode) {
		// returnState.setChannelCode(TransReturnCode.code_9900);
		// } else {
		// returnState.setChannelCode(channelRtncode.getKftRtncode());
		// }
		// String crditNo = batchId;// 银行返回的凭证号 组返回
		if ("000000".equals(BkTxStatus)) {// 收到银行确认的响应
			batchSendResult.setStatus(PayState.SUCCEED_STR);
			// final Node nodeTx = dom4jxml.getNode("/TX/TX_INFO");
			// crditNo = dom4jxml.getNodeText(nodeTx, "CREDIT_NO");// 银行返回的凭证号
			billnoSnService.updateByChannelBatchId(batchId, channelTempBill.getChannelId(),
						BillnoSnState.billnoResp);
		} else {
			batchSendResult.setStatus(PayState.FAILED_STR);
		}
		// 更新批量交易渠道批次表
		final ChannelBatchId channelBatchId = new ChannelBatchId();
		channelBatchId.setChannelid(channelTempBill.getChannelId());
		channelBatchId.setChannelBatchid(batchId);
		return batchSendResult;
	}

	/**
	 * 生产批量代收业务文件，并返回总金额
	 * 
	 * @param paybillList 批量业务的 list
	 * @param fileName 批量业务文件名
	 * @param batchId 渠道发送批次
	 * @param bankaccountBalance
	 * @param param 调用传递
	 * @return String 批量业务的总金额
	 * @throws BizException
	 */
	private String createDebit_Batch_File(final List<ChannelTempBill> paybillList, final String fileName,
			final String batchId, final BankaccountBalance bankaccountBalance) throws BizException {

		String payerBankCardName;// 付方户名
		String payerBankCardNo;// 付方账户
		String channelAmount;// 金额
		final StringBuffer sbStr = new StringBuffer("");
		BigDecimal dAmtTotal = BigDecimal.ZERO;
		// 循环处理从paybill表里面取出来的数据
		for (int i = 0; i < paybillList.size(); i++) {
			final ChannelTempBill channelTempBill = paybillList.get(i);
			payerBankCardName = channelTempBill.getBankAccountHolder();
			payerBankCardNo = channelTempBill.getBankAccountNo();
			final BigDecimal amount = channelTempBill.getAmount();
			channelAmount = String.format("%1$.2f", amount);
			// 总金额
			dAmtTotal = dAmtTotal.add(amount);
			// 付款账号,金额,收款人账号,付款人姓名,收款银行名称,摘要(这里填写billnoSeq)
			final String split = ",";
			final Date date = new Date();
			final String bankSendSn = sequenceManagerService.getCorpCCBSN(date);
			final String billnoSeq = sequenceManagerService.getBillnoSnSeq();
			sbStr.append(payerBankCardNo).append(split).append(channelAmount).append(split)
					.append(bankaccountBalance.getAccountNo()).append(split).append(payerBankCardName).append(split)
					.append("建行").append(split).append(billnoSeq).append("\n");
			// 写交易流水和渠道流水对照表
			final BillnoSn billnoSn = new BillnoSn();
			billnoSn.setBillnosnSeq(billnoSeq);
			billnoSn.setSn(channelTempBill.getBizBillSn());
			billnoSn.setChannelid(channelTempBill.getChannelId());
			billnoSn.setBankSendSn(bankSendSn);  // 银行流水
			billnoSn.setTranDate(DateUtil.getDate(date));
			billnoSn.setTranType(channelTempBill.getTransType());
			billnoSn.setState(BillnoSnState.billnoSend);	// 00：已发送
			billnoSn.setSendTime(date);
			billnoSn.setRecvTime(date);
			billnoSn.setBankType(channelTempBill.getBankType());// 行别
			billnoSn.setSrccustId(channelTempBill.getCustomerId());// 发起方客户编号
			billnoSn.setOrderid(channelTempBill.getBizTxnId());// 商户订单号
			billnoSn.setAmount(amount);
			billnoSn.setChannelDetail(String.valueOf(i));// 渠道明细序号
			billnoSn.setBatchid(channelTempBill.getTaskId());// 批次号(对应于原交易).
			billnoSn.setDetailid(channelTempBill.getId().toString());// 批量业务明细序号 对应于原交易
			billnoSn.setChannelBatchno(batchId);// 渠道发送批次号
			billnoSn.setOtheracctno(payerBankCardNo);// 对方账号
			billnoSn.setOtheracctname(payerBankCardName);// 对方户名
			billnoSn.setCorpacctno(bankaccountBalance.getAccountNo());// 对应渠道绑定的帐号
			billnoSn.setCorpacctname(bankaccountBalance.getAccountName());// 对应渠道绑定的帐号名
			billnoSn.setCorpbankno(bankaccountBalance.getBankNo());// 对应渠道绑定帐号所属的行号
			billnoSn.setBankCardType(channelTempBill.getCardType() != null ? channelTempBill.getCardType().toString()
					: BankCardType.UNDISTINGUISH);
			billnoSnService.save(billnoSn);
		}
		// 将文件写到本地
		createBatchFile(fileName, sbStr.toString()); // 文件名+文件内容
		// 组返回结果，并返回给调用者
		return String.valueOf(paybillList.size()) + "|" + String.format("%1$.2f", dAmtTotal);
	}

	/**
	 * 生产批量代付文件，并返回总金额
	 * 
	 * @param paybillList 批量业务的 list
	 * @param fileName 批量业务文件名
	 * @param batchId 渠道发送批次
	 * @param bankaccountBalance
	 * @param param 调用传递
	 * @return String 批量业务的总金额
	 * @throws BizException
	 */
	private String createPay_Batch_File(final List<ChannelTempBill> payList, final String fileName,
			final String batchId, final BankaccountBalance bankaccountBalance) throws BizException {
		String payeebankcardname;// 收方户名
		String payeebankcardno;// 收方账户
		String channelAmount;// 金额
		String fileStr;// 保存文件内容
		final StringBuffer sbStr = new StringBuffer("");
		BigDecimal dAmtTotal = BigDecimal.ZERO;// 总金额
		// 循环处理从paybill表里面取出来的数据
		List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>(payList.size());
		for (int i = 0; i < payList.size(); i++) {
			final ChannelTempBill channelTempBill = payList.get(i);
			payeebankcardname = channelTempBill.getBankAccountHolder();
			payeebankcardno = channelTempBill.getBankAccountNo();
			final BigDecimal amount = channelTempBill.getAmount();
			channelAmount = String.format("%1$.2f", amount);
			// 总金额
			dAmtTotal = dAmtTotal.add(amount);
			// 付款账号,金额,收款人账号,收款人姓名,收款银行名称,摘要”
			final String split = ",";
			final Date date = new Date();
			final String bankSendSn = sequenceManagerService.getCorpCCBSN(date);
			final String billnoSeq = sequenceManagerService.getBillnoSnSeq();
			sbStr.append(bankaccountBalance.getAccountNo()).append(split).append(channelAmount).append(split)
					.append(payeebankcardno).append(split).append(payeebankcardname).append(split).append("建行")
					.append(split).append(billnoSeq).append("\n");
			// 写交易流水和渠道流水对照表
			final BillnoSn billnoSn = new BillnoSn();
			billnoSn.setBillnosnSeq(billnoSeq);
			billnoSn.setSn(channelTempBill.getBizBillSn());
			billnoSn.setChannelid(channelTempBill.getChannelId());
			billnoSn.setBankSendSn(bankSendSn);  // 银行流水
			billnoSn.setTranDate(DateUtil.getDate(date));
			billnoSn.setTranType(channelTempBill.getTransType());
			billnoSn.setState(BillnoSnState.billnoSend);	// 00：已发送
			billnoSn.setSendTime(date);
			billnoSn.setRecvTime(date);
			billnoSn.setBankType(channelTempBill.getBankType());// 行别
			billnoSn.setSrccustId(channelTempBill.getCustomerId());// 发起方客户编号
			billnoSn.setOrderid(channelTempBill.getBizTxnId());// 商户订单号
			billnoSn.setAmount(amount);// 金额
			billnoSn.setChannelDetail(String.valueOf(i));// 渠道明细序号
			billnoSn.setBatchid(channelTempBill.getTaskId());// 批次号(对应于原交易).
			billnoSn.setDetailid(channelTempBill.getId().toString());// 批量业务明细序号 对应于原交易
			billnoSn.setChannelBatchno(batchId);// 渠道发送批次号
			billnoSn.setOtheracctno(payeebankcardno);// 对方账号
			billnoSn.setOtheracctname(payeebankcardname);// 对方户名
			billnoSn.setCorpacctno(bankaccountBalance.getAccountNo());// 对应渠道绑定的帐号
			billnoSn.setCorpacctname(bankaccountBalance.getAccountName());// 对应渠道绑定的帐号名
			billnoSn.setCorpbankno(bankaccountBalance.getBankNo());// 对应渠道绑定帐号所属的行号
			billnoSn.setBankCardType(channelTempBill.getCardType() != null ? channelTempBill.getCardType().toString()
					: BankCardType.UNDISTINGUISH);
			billNoSnList.add(billnoSn);
		}
		billnoSnService.batchSave(billNoSnList);
		// 将文件写到本地
		fileStr = sbStr.toString();
		try {
			createBatchFile(fileName, fileStr); // 文件名+文件内容
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException("生成建行银企批量代付文件异常：" + e.getMessage());
		}
		// 组返回结果，并返回给调用者
		return String.valueOf(payList.size()) + "|" + String.format("%1$.2f", dAmtTotal);
	}

	/**
	 * 创建 余额查询交易 报文
	 * @author 张凯锋
	 */
	public String create6W0100XML(String bankSendSn,String accountNo) {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, "6W0100", bankSendSn);
		// 创建交易数据信息
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element ACC_NO = CorpElement.addElement("ACC_NO");// 账号

		String actacn = accountNo;// 账号
		if (StringUtils.isBlank(accountNo)) {
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
			actacn = bankaccountBalance.getAccountNo();
		}
		
		ACC_NO.setText(actacn);
		// 生成xml字符串
		return document.asXML();
	}

	/**
	 * 创建 账号、户名是否匹配校验交易 报文
	 * 
	 * @author 张凯锋
	 * @param accNamne
	 * @param accNo
	 */
	public String create6W1101XML(String bankSendSn, String accNo, String accName) {
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		Element apElement = document.addElement("TX");
		// 创建公共头信息
		createHeadXml(apElement, "6W1101", bankSendSn);
		// 创建交易数据信息
		Element CorpElement = apElement.addElement("TX_INFO");
		Element ACC_NO = CorpElement.addElement("ACC_NO");// 账号
		ACC_NO.setText(accNo);
		Element ACC_NAME = CorpElement.addElement("ACC_NAME");// 账户名称
		ACC_NAME.setText(accName);
		return document.asXML();
	}
}
