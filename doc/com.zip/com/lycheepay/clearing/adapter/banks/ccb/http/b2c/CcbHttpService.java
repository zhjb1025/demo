package com.lycheepay.clearing.adapter.banks.ccb.http.b2c;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;


/**
 * <P>建设银行HTTP(不区分B2B\B2C) 部分服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午4:22:29
 */
@Service(ClearingAdapterAnnotationName.CCB_HTTP_SERVICE)
public class CcbHttpService extends BaseWithoutAuditLogService {
	// private static String logMsg = "";
	// private static ChannelRefundDao channelRefundDao = (ChannelRefundDao)
	// SpringContext.getService("channelRefundDao");
	// private static ChannelBatchRefundDao channelBatchRefundDao = (ChannelBatchRefundDao)
	// SpringContext
	// .getService("channelBatchRefundDao");
	// private static BillnoSnDao billnoSnDao = (BillnoSnDao)
	// SpringContext.getService("billnoSnDao");
	// private static SysParmService sysParmDao = (SysParmService)
	// SpringContext.getService("sysParmDao");
	// private static String line = System.getProperty("line.separator"); // 回车换行符
	//
	// /**
	// * 生成文件失败时，把状态更改为09.描述为错误前250位
	// *
	// * @param channelBatchId
	// * @param returnState
	// * @throws BizException
	// */
	// public void updateChannelBatchRefundToFail(final String logPrefix, final String
	// channelBatchId) throws BizException {
	// try {
	// final ChannelBatchRefund cbr = (ChannelBatchRefund)
	// channelBatchRefundDao.findByIdWithLock(channelBatchId);
	// if (cbr == null) {
	// throw new BizException(logPrefix + "获取到的渠道批量退款表对象为NULL。channelBatchId为：" + channelBatchId);
	// }
	// if (cbr.getState().equals("00")) {
	// cbr.setState("09");
	// cbr.setRemark("生成文件失败。");
	// channelBatchRefundDao.update(cbr);
	// }
	// } catch (final Exception e) {
	// Log4jUtil.error(logPrefix + "更新ChannelBatchRefund表出错。", e);
	// }
	// }
	//
	// /**
	// * 根据channelBatchid由表ChannelBatchRefund获取到相关记录，用Refund_net_no、Refund_type、
	// * Channel_Id结合表channel_Refund获取到相关明细，组向银行发送的批量退款文件
	// *
	// * @param channelBatchid
	// * @return 文件路径及名称 -1为失败
	// * @throws BizException
	// */
	// public String creatBatchRefundFile(final String logPrefix, final String channelId, final
	// String channelBatchid)
	// throws BizException {
	// logMsg = logPrefix + "开始组Channel_BatchId为：" + channelBatchid + "的批量退款批次文件。";
	// Log4jUtil.info(logMsg);
	// final ChannelBatchRefund channelBatchRefund = (ChannelBatchRefund) channelBatchRefundDao
	// .findById(channelBatchid);
	// if (channelBatchRefund == null) {
	// throw new BizException(logPrefix + "从channel_Batch_Refund表中无法获取Channel_BatchId为：" +
	// channelBatchid + "的记录。");
	// }
	// if (!channelBatchRefund.getState().equals("00") &&
	// !channelBatchRefund.getState().equals("09")) {
	// throw new BizException(logPrefix + "根据参数channelBatchid" + channelBatchid +
	// "在表channel_Batch_Refund中得到的状态为："
	// + channelBatchRefund.getState() + ",非00：已发送和09: 交易失败。不能再次触发，处理中止。");
	// }
	// final List<ChannelRefund> channelRefundList =
	// channelRefundDao.getListByChannelBatchId(channelBatchid);
	// logMsg = logPrefix + "开始生成B2C批量退款文件。";
	// Log4jUtil.info(logMsg);
	// Double iTotalAmount = 0.00;
	// int iTotalCount = 0;
	// String refundFileName = "";
	// String path = "";
	// path = sysParmDao.getParmValue(SysparmConst.REFUND_FILE_PATH);
	// if (path == null || path.length() < 1) {
	// logMsg = logPrefix + "无法获取存放路径。";
	// Log4jUtil.error(logMsg);
	// return "-1";
	// }
	// refundFileName = FileProcess.getRefundBatchFileName(path, channelId,
	// DateUtil.getCurrentDate(), 4, "TXT");
	// if (refundFileName == null || refundFileName.length() < 1) {
	// logMsg = logPrefix + "获取文件路径出错。";
	// Log4jUtil.error(logMsg);
	// return "-1";
	// }
	// // 生成文件内容
	// final StringBuffer stringBuffer = new StringBuffer("");
	// // 明细序号(4位以内的自然数)|订单号|支付账号|手续费(默认为0)|退款金额|(注：上传文件请删除该行标题，且不有空行)
	// for (int j = 0; j < channelRefundList.size(); j++) {
	// String banSendSN;// 原业务发往银行的记录
	// final String bILLNoSeq = channelRefundList.get(j).getBillnoSeq();
	// final BillnoSn billnoSn = (BillnoSn) billnoSnDao.findById(bILLNoSeq);
	// if (billnoSn == null) {
	// logMsg = logPrefix + "在渠道流水对照表中没有记录bILLNoSeq:" + bILLNoSeq;
	// Log4jUtil.info(logMsg);
	// continue;
	// }
	// banSendSN = billnoSn.getBankSendSn();
	// // 0001|2011052000000261||0|0.70|
	// stringBuffer.append(j + 1).append("|").append(banSendSN).append("||").append("0").append("|")
	// .append(String.format("%1$.2f", channelRefundList.get(j).getRefundAmount())).append("|");
	// if (j != (channelRefundList.size() - 1)) {
	// stringBuffer.append(line);
	// }
	// iTotalCount++;
	// logMsg = logPrefix + "添加退款明细：BankSendSn:" + banSendSN;
	// logMsg = logMsg + " Amount:" + String.format("%1$.2f",
	// channelRefundList.get(j).getRefundAmount());
	// Log4jUtil.info(logMsg);
	// iTotalAmount = AmountUtils.add(iTotalAmount, channelRefundList.get(j).getRefundAmount());
	// }
	// try {
	// PrintWriter pw = null;
	// pw = new PrintWriter(refundFileName);
	// pw.write(stringBuffer.toString());
	// pw.flush();
	// pw.close();
	// } catch (final Exception e) {
	// Log4jUtil.error(e);
	// logMsg = logPrefix + "生成批量退款对账文件出错。";
	// Log4jUtil.info(logMsg);
	// return "-1";
	// }
	// logMsg = logPrefix + "生成批量退款文件。总笔数为：" + iTotalCount + " 总金额：" + String.format("%1$.2f",
	// iTotalAmount);
	// Log4jUtil.info(logMsg);
	// channelBatchRefund.setState("01");
	// channelBatchRefund.setFilefullpath(refundFileName);
	// channelBatchRefundDao.update(channelBatchRefund);
	// return refundFileName;
	// }

}
