package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.Charset;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.security.PfxSignVerify;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


public class SocketMsg {
	int msgLength = 0;
	String sender = "";
	String tranCode = "";
	String flag = "";
	String fileName = "";
	String checkValue = "";
	String xmlmsg = "";
	String filepath = "";

	public void buildMsg(final OutputStream os) throws BizException {
		final StringBuilder sb = new StringBuilder();
		sb.append(String.format("%010d", msgLength));
		sb.append(String.format("%-12s", sender));
		sb.append(String.format("%-4s", tranCode));
		sb.append(String.format("%s", flag));
		sb.append(String.format("%-80s", fileName));
		sb.append(String.format("%-256s", checkValue));
		try {
			if (flag.equals("C")) {
				sb.append(xmlmsg);
				os.write(sb.toString().getBytes("GBK"));
				os.flush();
			} else {
				os.write(sb.toString().getBytes());
				os.flush();
				final BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filepath));
				final DataInputStream dis = new DataInputStream(bis);

				// 发送文件内容
				writeFileContent(dis, os, msgLength);
			}
		} catch (final IOException e) {
			throw new BizException(TransReturnCode.code_9108, e.getMessage());
		}

	}

	public void parseMsg(final InputStream is) throws IOException {
		final String msglen = readString(is, 10);
		msgLength = Integer.valueOf(msglen);
		sender = readString(is, 12).trim();
		tranCode = readString(is, 4);
		flag = readString(is, 1);
		fileName = readString(is, 80).trim();
		checkValue = readString(is, 256);

		Log4jUtil.info("接收到监管银行发送的报文");
		Log4jUtil.info("通讯头:[" + msgLength + "][" + sender + "][" + tranCode + "]flag=[" + flag + "]+fileName=["
				+ fileName + "]checkValue=[" + checkValue + "]");

		if (flag.equals("C")) {
			Log4jUtil.info("接收到报文，读取报文");
			xmlmsg = readString(is, msgLength);
			Log4jUtil.info("读取到报文:" + xmlmsg);
		} else {
			String filePath = "";
			if (filepath.endsWith(File.separator)) {
				filePath = filepath + fileName;
			} else {
				filePath = filepath + File.separator + fileName;
			}
			readAndSaveFileContent(is, filePath, msgLength);
			Log4jUtil.info("读取到的文件:[" + filePath + "]");
		}
	}

	private String readString(final InputStream is, final int len) throws IOException {
		final byte[] bytes = new byte[len];
		is.read(bytes);
		return new String(bytes);
	}

	private void readAndSaveFileContent(final InputStream is, final String path, final int file_len) throws IOException {
		Log4jUtil.info("读取并保存文件：" + path);
		final FileOutputStream os = getFileOS(path);
		readAndWrite(is, os, file_len);
		os.close();
	}

	// 创建文件并返回输出流
	private FileOutputStream getFileOS(final String path) throws IOException {
		final File file = new File(path);
		if (!file.exists()) {
			file.createNewFile();
		}
		return new FileOutputStream(file);
	}

	// 边读边写，直到读取 size 个字节
	private void readAndWrite(final InputStream is, final FileOutputStream os, final int size) throws IOException {
		final byte[] buffer = new byte[8192];
		int count = 0;
		while (count < size) {
			final int n = is.read(buffer);
			// 这里没有考虑 n = -1 的情况
			os.write(buffer, 0, n);
			count += n;
		}
	}

	// 输出文件内容
	private void writeFileContent(final InputStream is, final OutputStream os, final int length) throws IOException {
		final byte[] buffer = new byte[2048];
		int size;
		while ((size = is.read(buffer)) != -1) {
			Log4jUtil.info("size=" + size);
			os.write(buffer, 0, size);
			os.flush();
		}
	}

	public String sendXMLToBank(final String hostname, final Integer port, final String sender, final String tranCode,
			final String xmlmsg, final String certFile, final String certPassword, final String bankCertFile,
			String verifyFlag) throws BizException {
		Socket socket = null;
		BufferedInputStream bufferedInputStream = null;
		DataInputStream inputStream = null;
		try {
			socket = new Socket(hostname, port);
			SocketMsg socketmsg = new SocketMsg();
			String base64Msg = new String(Base64.encodeBase64(xmlmsg.getBytes(Charset.forName("GBK"))));
			socketmsg.setMsgLength(base64Msg.length());
			socketmsg.setSender(sender);
			socketmsg.setTranCode(tranCode);
			socketmsg.setFlag("C");// F：文件 C：消息报文
			socketmsg.setFileName(" ");
			String checkValue = "";
			if ("Y".equals(verifyFlag))// Y:验签
				checkValue = PfxSignVerify.signMsg_Base64(base64Msg, certFile, certPassword);
			socketmsg.setCheckValue(checkValue);
			socketmsg.setFilepath(" ");
			socketmsg.setXmlmsg(base64Msg);
			Log4jUtil.info("sendXMLToBank向监管银行发送报文");
			socketmsg.buildMsg(socket.getOutputStream());
			Log4jUtil.info("通讯头:{},{},{}", sender, tranCode, checkValue);
			// 解析返回报文
			bufferedInputStream = new BufferedInputStream(socket.getInputStream());
			inputStream = new DataInputStream(bufferedInputStream);
			SocketMsg recvMsg = new SocketMsg();
			recvMsg.parseMsg(inputStream);
			// 处理返回消息
			String xml = dealRetMsg(bankCertFile, recvMsg.getCheckValue(), recvMsg.getXmlmsg(), verifyFlag);
			return xml;
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
		} finally {
			IOUtils.closeQuietly(inputStream);
			IOUtils.closeQuietly(bufferedInputStream);
			IOUtils.closeQuietly(socket);
		}
	}

	public String dealRetMsg(final String certFile, final String checkValue, final String xmlmsg, String verifyFlag)
			throws Exception {
		String msg = new String(Base64.decodeBase64(xmlmsg), Charset.forName("GBK"));
		Log4jUtil.info("银行返回xml明文为：{}", msg);
		// 验证签名
		boolean bFlag;
		if (!"Y".equals(verifyFlag))// Y:验签
			return msg;
		try {
			bFlag = PfxSignVerify.verifySign_Base64(xmlmsg, checkValue, certFile);
		} catch (final Exception e) {
			Log4jUtil.error("验证签名失败，" + e.getMessage(), e);
			return null;
		}
		if (!bFlag) {
			throw new BizException(TransReturnCode.code_9109, "验证签名失败");
		}

		return msg;
	}

	public int getMsgLength() {
		return msgLength;
	}

	public void setMsgLength(final int msgLength) {
		this.msgLength = msgLength;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(final String sender) {
		this.sender = sender;
	}

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(final String tranCode) {
		this.tranCode = tranCode;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(final String flag) {
		this.flag = flag;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(final String fileName) {
		this.fileName = fileName;
	}

	public String getCheckValue() {
		return checkValue;
	}

	public void setCheckValue(final String checkValue) {
		this.checkValue = checkValue;
	}

	public String getXmlmsg() {
		return xmlmsg;
	}

	public void setXmlmsg(final String xmlmsg) {
		this.xmlmsg = xmlmsg;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(final String filepath) {
		this.filepath = filepath;
	}
}