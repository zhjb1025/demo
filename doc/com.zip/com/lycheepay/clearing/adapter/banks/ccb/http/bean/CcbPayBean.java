package com.lycheepay.clearing.adapter.banks.ccb.http.bean;

public class CcbPayBean {
	String sn = "";
	String payUrl = "";

	String merchantid = "";
	String posid = "";
	String branchid = "";
	String orderid = "";
	String payment = "";
	String curcode = "";
	String remark1 = "";
	String remark2 = "";
	String txcode = "";
	String mac = "";

	public String getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(final String merchantid) {
		this.merchantid = merchantid;
	}

	public String getPosid() {
		return posid;
	}

	public void setPosid(final String posid) {
		this.posid = posid;
	}

	public String getBranchid() {
		return branchid;
	}

	public void setBranchid(final String branchid) {
		this.branchid = branchid;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(final String orderid) {
		this.orderid = orderid;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(final String payment) {
		this.payment = payment;
	}

	public String getCurcode() {
		return curcode;
	}

	public void setCurcode(final String curcode) {
		this.curcode = curcode;
	}

	public String getRemark1() {
		return remark1;
	}

	public void setRemark1(final String remark1) {
		if (remark1 == null) {
			this.remark1 = "";
		} else {
			this.remark1 = remark1;
		}
	}

	public String getRemark2() {
		return remark2;
	}

	public void setRemark2(final String remark2) {
		if (remark2 == null) {
			this.remark2 = "";
		} else {
			this.remark2 = remark2;
		}
	}

	public String getTxcode() {
		return txcode;
	}

	public void setTxcode(final String txcode) {
		this.txcode = txcode;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(final String mac) {
		this.mac = mac;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(final String sn) {
		this.sn = sn;
	}

	public String getPayUrl() {
		return payUrl;
	}

	public void setPayUrl(final String payUrl) {
		this.payUrl = payUrl;
	}

	public CcbPayBean() {
		super();
	}

	public CcbPayBean(final String sn, final String payUrl, final String merchantid, final String posid,
			final String branchid, final String orderid, final String payment, final String curcode,
			final String remark1, final String remark2, final String txcode, final String mac) {
		super();
		this.sn = sn;
		this.payUrl = payUrl;
		this.merchantid = merchantid;
		this.posid = posid;
		this.branchid = branchid;
		this.orderid = orderid;
		this.payment = payment;
		this.curcode = curcode;
		this.remark1 = remark1;
		this.remark2 = remark2;
		this.txcode = txcode;
		this.mac = mac;
	}
}
