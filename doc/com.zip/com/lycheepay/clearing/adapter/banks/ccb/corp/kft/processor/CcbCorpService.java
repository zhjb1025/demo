package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.processor;

import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.dom4j.Node;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util.CcbCorpProcessXmlService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 建行银企批量代收付处理
 * 
 * @author aps-lfm
 * 
 */
@Service
public class CcbCorpService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CORP_PROCESS_XML_SERVICE)
	private CcbCorpProcessXmlService ccbCorpProcessXmlService;

	/**
	 * 建行银企6W2104批量交易结果下载处理
	 * 
	 * @param xmlStr 报文字符串
	 * @param param
	 * @return ReturnState
	 * @throws BizException
	 */
	public void deal6W2104(String channelBatchId) throws BizException {

		String sendXml = ccbCorpProcessXmlService.create6W2104XML(channelBatchId);// 创建请求
		Log4jUtil.debug(sendXml);
		String xmlStr = ccbCorpProcessXmlService.sendXML(sendXml);// 发送请求
		Log4jUtil.debug(xmlStr);
		Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));// 解析xml
		Node nodeItemHead = dom4jxml.getNode("/TX");// 获取xml中TX节点的数据

		String returnCode = dom4jxml.getNodeText(nodeItemHead, "RETURN_CODE");
		Log4jUtil.info("RETURN_CODE:" + returnCode);
		// 组返回的实体
		if (("000000").equals(returnCode)) {// 查询成功
			List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>();
			String fStatus = dom4jxml.getNodeText("/TX/TX_INFO/F_STATUS");
			if ("2".equals(fStatus))// 0：处理失败 1：处理完成 2：处理中
				return;// 处理中直接返回，不作处理

			// Node nodeItem= dom4jxml.getNode("/TX/TX_INFO");
			// String sumNum =dom4jxml.getNodeText(nodeItem,"TOTAL_NUM");//总笔数
			// String sumAmount = dom4jxml.getNodeText(nodeItem,"TOTAL_AMOUNT");//总金额
			// String sucessNum =dom4jxml.getNodeText(nodeItem,"SUCCESS_NUM");//成功笔数
			// String sucessAmount = dom4jxml.getNodeText(nodeItem,"SUCCESS_AMOUNT");//成功金额
			// String unSucessNum =dom4jxml.getNodeText(nodeItem,"FAIL_NUM");//失败金额
			// String unSucessAmount = dom4jxml.getNodeText(nodeItem,"FAIL_AMOUNT");//失败笔数
			long kftSucessNum = 0;
			double kftSucessAmount = 0.00;
			long kftUnSucessNum = 0;
			double kftUnSucessAmount = 0.00;
			BillnoSn billnoSn = null;
			// 处理xml中交易成功的记录
			List<Node> nodeItemSuccList = dom4jxml.getNodeList("/TX/TX_INFO/SUCCESS_LIST");
			int j = nodeItemSuccList.size();// 循环处理
			for (int i = 0; i < j; i++) {
				Node nodeItemSucc = nodeItemSuccList.get(i);
				String amount = dom4jxml.getNodeText(nodeItemSucc, "AMOUNT");// 金额
				String billno_seq = dom4jxml.getNodeText(nodeItemSucc, "USEOF").toString();// USEOF存放的是批量文件里面的摘要，对应billno_sn里面BILLNOSN_SEQ
				billnoSn = billnoSnService.findById(billno_seq);
				if (billnoSn == null) {
					Log4jUtil.info("建行银企批量结果查询通过批量结果中返回的流水：" + billno_seq + "反查billno_SN为空");
					continue;
				}
				billnoSn.setChannelRtncode("000000"); // 渠道返回码
				billnoSn.setChannelRtnnote("成功"); // 渠道返回附言
				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
				billnoSn.setRecvTime(new Date()); // 返回时间
				billnoSn.setActualAmount(new BigDecimal(amount)); // 渠道实际支付金额
				billnoSn.setCheckDate(DateUtil.getCurrentDate());
				billnoSn.setPayState("1");// 成功1
				billNoSnList.add(billnoSn);
				kftSucessNum++;
				kftSucessAmount = kftSucessAmount + Double.valueOf(amount);
			}
			// 处理xml中交易失败记录
			List<Node> nodeItemFailList = dom4jxml.getNodeList("/TX/TX_INFO/FAIL_LIST");
			j = nodeItemFailList.size();// 循环处理
			for (int i = 0; i < j; i++) {
				Node nodeItemFail = nodeItemFailList.get(i);
				String amount2 = dom4jxml.getNodeText(nodeItemFail, "AMOUNT");// 金额
				String id = dom4jxml.getNodeText(nodeItemFail, "USEOF").toString();// USEOF存放的是批量文件里面的摘要，对应billno_sn里面BILLNOSN_SEQ
				String remark = dom4jxml.getNodeText(nodeItemFail, "REMARK");// 备注
				billnoSn = billnoSnService.findById(id);
				if (billnoSn == null) {
					Log4jUtil.info("建行银企批量结果查询通过批量结果中返回的流水：" + id + "反查billno_SN为空");
					continue;
				}
				billnoSn.setChannelRtncode("4"); // 渠道返回码
				billnoSn.setChannelRtnnote(remark); // 渠道返回附言
				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
				billnoSn.setRecvTime(new Date()); // 返回时间
				billnoSn.setActualAmount(new BigDecimal(amount2)); // 渠道实际支付金额
				billnoSn.setCheckDate(DateUtil.getCurrentDate());
				billnoSn.setPayState("2");// 失败2
				billNoSnList.add(billnoSn);
				kftUnSucessNum++;
				kftUnSucessAmount = kftUnSucessAmount + Double.valueOf(amount2);
			}
			billnoSnService.batchUpdateByPrimary(billNoSnList);
			batchProcessResultNotice.process(ChannelIdEnum.CCB_CORP.getCode(), channelBatchId, billnoSn.getTranType(),
					kftSucessNum, kftSucessAmount, kftUnSucessNum, kftUnSucessAmount);

		} else {// 查询失败
			Log4jUtil.info("建行银企批量" + channelBatchId + "结果查询结果失败:" + dom4jxml.getNodeText(nodeItemHead, "RETURN_MSG"));
		}
	}
}
