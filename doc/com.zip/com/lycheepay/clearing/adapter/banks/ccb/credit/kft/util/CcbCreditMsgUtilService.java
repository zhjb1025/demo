package com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.ByteUtils;
import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgField;
import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgFieldType;
import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgPackUtils;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.DeductPayReal;
import com.lycheepay.clearing.adapter.common.model.channel.RefundBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.adapter.common.util.security.JDES;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行(仅为信用卡调用)消息处理工具服务类
 * (严格区分Util与UtilsService,前者为简单的静态工具类,后者需要注入其他service，并且与数据库有交集;调用方可以明显区分,如果有Service,不允许new出该对象)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 上午3:59:36
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDIT_MSG_UTIL_SERVICE)
public class CcbCreditMsgUtilService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManager;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	// private static Map<String, String> channelParms = new Map<String,
	// String>();
	private static String channelId = ChannelIdEnum.CCB_CREDIT_CARD.getCode();

	@Value(value = "${verifyFlag}")
	private String verifyFlag;

	/**
	 * 创建签到报文
	 * 
	 * @param param
	 * @param bankSendSn
	 * @return
	 * @throws BizException
	 */
	public MsgPack createSign(final String bankSendSn) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String version = channelParms.get("100010");// 下载版本号

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		// 字域长度检查
		AssertUtils.checkLength(bankSendSn, TransReturnCode.code_9108, "建行签到报文[11域]bankSendSn", 6, 6);
		AssertUtils.checkLength(clinetCode, TransReturnCode.code_9108, "建行签到报文[41域]clinetCode", 8, 8);
		AssertUtils.checkLength(merchant, TransReturnCode.code_9108, "建行签到报文[42域]merchant", 15, 15);
		AssertUtils.checkLength(batchNo, TransReturnCode.code_9108, "建行签到报文[60.2域]batchNo", 6, 6);
		AssertUtils.checkLength(operator, TransReturnCode.code_9108, "建行签到报文[63.1域]operator", 3, 3);
		AssertUtils.checkLength(version, TransReturnCode.code_9108, "建行签到报文[63.2域]version", 36, 36);

		// 组报文
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0800");// 消息类型
		MsgPackUtils.createField11(msgPack, bankSendSn);// 受卡方系统跟踪号-流水号
		MsgPackUtils.createField41(msgPack, clinetCode); // 受卡机终端标识码-终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码

		byte[] field60B = ByteUtils.strToBcdRightSide("011");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("00"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcdLeftSide("003"));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码(00)+批次号 + 网络管理信息码(003)

		MsgPackUtils.createField63(msgPack, "040" + operator + version + "1");// 操作员代码(001)+下载版本号（36个空格)+软件交易类型(1)
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权请求 MsgPack
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道发送流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrant(final Param param, final String bankSendSn, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		// 获取渠道通用交易实体
		final DeductPayReal debiPayReal = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debiPayReal);

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		// 字域长度检查
		AssertUtils
				.checkLength(debiPayReal.getOut_Account(), TransReturnCode.code_9108, "建行预授权报文[2域]Out_Account", 1, 19);
		AssertUtils.checkLength(bankSendSn, TransReturnCode.code_9108, "建行预授权报文[11域]bankSendSn", 6, 6);
		AssertUtils.checkLength(inputCode, TransReturnCode.code_9108, "建行预授权报文[22域]inputCode", 3, 3);
		AssertUtils.checkLength(clinetCode, TransReturnCode.code_9108, "建行预授权报文[41域]clinetCode", 8, 8);
		AssertUtils.checkLength(merchant, TransReturnCode.code_9108, "建行预授权报文[42域]merchant", 15, 15);
		AssertUtils.checkLength(currency, TransReturnCode.code_9108, "建行预授权报文[49域]currency", 3, 3);
		AssertUtils.checkLength(batchNo, TransReturnCode.code_9108, "建行预授权报文[60.2域]batchNo", 6, 6);

		// 组 报文
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0100");// 消息类型
		MsgPackUtils.createAccountField(msgPack, debiPayReal.getOut_Account());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "030000");// 交易处理码
		MsgPackUtils.createField4(msgPack, debiPayReal.getAmount_Num());// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 受卡方系统跟踪号-流水号
		MsgPackUtils.createField14(msgPack, debiPayReal.getExpdate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, "06");// 服务点条件码
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("14"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		MsgPackUtils.createField62(msgPack, debiPayReal.getCvv2().getBytes());// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		MsgPackUtils.mac(msgPack, workKey);
		return msgPack;
	}

	/**
	 * 
	 * 预授权请求 MsgPack
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道发送流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createPreAuth(final Param param, final String bankSendSn, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		// 获取渠道通用交易实体
		final PreAuthDTO dto = (PreAuthDTO) param.getBizBean();

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();
		// 字域长度检查
		AssertUtils.checkLength(dto.getBankCardNo(), TransReturnCode.code_9108, "建行签到报文[2域]Out_Account", 1, 19);
		AssertUtils.checkLength(bankSendSn, TransReturnCode.code_9108, "建行签到报文[11域]bankSendSn", 6, 6);
		AssertUtils.checkLength(inputCode, TransReturnCode.code_9108, "建行签到报文[22域]inputCode", 3, 3);
		AssertUtils.checkLength(clinetCode, TransReturnCode.code_9108, "建行签到报文[41域]clinetCode", 8, 8);
		AssertUtils.checkLength(merchant, TransReturnCode.code_9108, "建行签到报文[42域]merchant", 15, 15);
		AssertUtils.checkLength(currency, TransReturnCode.code_9108, "建行签到报文[49域]currency", 3, 3);
		AssertUtils.checkLength(batchNo, TransReturnCode.code_9108, "建行签到报文[60.2域]batchNo", 6, 6);

		// 组 报文
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0100");// 消息类型
		MsgPackUtils.createAccountField(msgPack, dto.getBankCardNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "030000");// 交易处理码
		MsgPackUtils.createField4(msgPack, dto.getAmount().doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 受卡方系统跟踪号-流水号
		MsgPackUtils.createField14(msgPack, dto.getCreditCardEndDate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, "06");// 服务点条件码
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("14"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		MsgPackUtils.createField62(msgPack, dto.getCvv2().getBytes());// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		MsgPackUtils.mac(msgPack, workKey);
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权冲正 MsgPack
	 * 
	 * @param param
	 * @param grantMsgPack 预授权
	 * @param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantRush(final Param param, final MsgPack grantMsgPack, final MsgPack retGrantMsgPack,
			final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final MsgPack msgPack = new MsgPack();
		// 组预授权冲正报文
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, grantMsgPack.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, grantMsgPack.getFieldContent3());// 交易处理码(同原交易)
		MsgPackUtils.createField4(msgPack, grantMsgPack.getAmount());// 交易金额(同原预授权交易)
		MsgPackUtils.createField11(msgPack, grantMsgPack.getFieldContent11());// 受卡方系统跟踪号-原流水号
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		if (retGrantMsgPack != null) {
			MsgPackUtils.createField39(msgPack, retGrantMsgPack.getFieldContent39());// 应答码-请求时为冲正原因
		} else {
			MsgPackUtils.createField39(msgPack, "98");// 应答码-请求时为冲正原因
		}
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码 同原交易
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码 同原交易
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("14"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	public MsgPack createGrantRush(final String accountNo, final String fieldContent3, final Double amount,
			final String fieldContent11, final MsgPack retGrantMsgPack, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final MsgPack msgPack = new MsgPack();

		createHeadMsg(msgPack);
		MsgPackUtils.createMsgType(msgPack, "0400");
		MsgPackUtils.createAccountField(msgPack, accountNo);
		MsgPackUtils.createField3(msgPack, fieldContent3);
		MsgPackUtils.createField4(msgPack, amount);
		MsgPackUtils.createField11(msgPack, fieldContent11);
		MsgPackUtils.createField22(msgPack, inputCode);
		MsgPackUtils.createField25(msgPack, conCode);

		if (retGrantMsgPack != null) {
			MsgPackUtils.createField39(msgPack, retGrantMsgPack.getFieldContent39());
		} else {
			MsgPackUtils.createField39(msgPack, "98");
		}
		MsgPackUtils.createField41(msgPack, clinetCode);
		MsgPackUtils.createField42(msgPack, merchant);
		MsgPackUtils.createField49(msgPack, currency);

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("14"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);

		MsgPackUtils.mac(msgPack, workKey);
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权撤销 MsgPack
	 * 
	 * @param param
	 * @param grantRetMsgPack 预授权
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantCancel(final Param param, final MsgPack grantRetMsgPack, final String workKey)
			throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0100");// 消息类型

		MsgPackUtils.createAccountField(msgPack, grantRetMsgPack.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200000");// 交易处理码
		MsgPackUtils.createField4(msgPack, grantRetMsgPack.getAmount());// 交易金额
		MsgPackUtils.createField11(msgPack, grantRetMsgPack.getFieldContent11());// 原流水号
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (grantRetMsgPack.getField(MsgFieldType.FIELD_38.getNo()) != null
				&& grantRetMsgPack.getFieldContent38().length() == 6) {
			field_38 = grantRetMsgPack.getFieldContent38();
		}

		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码 同原交易
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码 同原交易
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("11"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(batchNo));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(grantRetMsgPack.getFieldContent11()));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(grantRetMsgPack.getFieldContent13()));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权撤销 MsgPack
	 * 
	 * @param param
	 * @param grantRetMsgPack 预授权
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantCancel(final String accountNo, final double amount, final String fieldContent38,
			final String field60_2, final String fieldContent11, final String fieldContent13, final String workKey,
			String bankSendSn) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0100");// 消息类型

		MsgPackUtils.createAccountField(msgPack, accountNo);// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200000");// 交易处理码
		MsgPackUtils.createField4(msgPack, amount);// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 原流水号
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (fieldContent38 != null && fieldContent38.length() == 6) {
			field_38 = fieldContent38;
		}

		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码 同原交易
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码 同原交易
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("11"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(batchNo));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(fieldContent11));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(fieldContent13));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权撤销冲正 MsgPack
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantCancelRush(final MsgPack grantCancelMsgPack,
			final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final MsgPack msgPack = new MsgPack();
		// 组预授权冲正报文
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, grantCancelMsgPack.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, grantCancelMsgPack.getFieldContent3());// 交易处理码(同原交易)
		MsgPackUtils.createField4(msgPack, grantCancelMsgPack.getAmount());// 交易金额(同原预授权交易)
		MsgPackUtils.createField11(msgPack, grantCancelMsgPack.getFieldContent11());// 受卡方系统跟踪号-原流水号
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		MsgPackUtils.createField38(msgPack, grantCancelMsgPack.getFieldContent38());// 应答码-请求时为冲正原因
		MsgPackUtils.createField39(msgPack, "98");// 应答码-请求时为冲正原因
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码 同原交易
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码 同原交易
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("11"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		MsgPackUtils.createField61(msgPack, grantCancelMsgPack.getFieldContent61().getBytes());// 原始信息域:
																								// 原批号+原POS流水号+原交易日期
		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权完成 MsgPack
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantFinish(final Param param, final MsgPack retMsgBack, final String workKey)
			throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		MsgPackUtils.createAccountField(msgPack, retMsgBack.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "000000");// 交易处理码
		MsgPackUtils.createField4(msgPack, retMsgBack.getAmount());// 交易金额.
		MsgPackUtils.createField11(msgPack, sequenceManager.getCcbCreditSN());// POS终端交易流水
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (retMsgBack.getField(MsgFieldType.FIELD_38.getNo()) != null && retMsgBack.getFieldContent38().length() == 6) {
			field_38 = retMsgBack.getFieldContent38();
		}

		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("20"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");

		if (retMsgBack.getField(MsgFieldType.FIELD_60.getNo()) != null && retMsgBack.get60_2() != null
				&& retMsgBack.get60_2().length() == 6) {
			batchNo = retMsgBack.get60_2();
		}

		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(batchNo));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(retMsgBack.getFieldContent11()));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(retMsgBack.getFieldContent13()));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权完成 MsgPack
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantFinish(final Param param, final String accountNo, final double amount,
			final String fieldContent38, final String field60_2, final String fieldContent11,
			final String fieldContent13, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		MsgPackUtils.createAccountField(msgPack, accountNo);// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "000000");// 交易处理码
		MsgPackUtils.createField4(msgPack, amount);// 交易金额.
		MsgPackUtils.createField11(msgPack, sequenceManager.getCcbCreditSN());// POS终端交易流水
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (fieldContent38.length() == 6) {
			field_38 = fieldContent38;
		}

		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("20"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");

		if (field60_2 != null && field60_2.length() == 6) {
			batchNo = field60_2;
		}

		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(batchNo));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(fieldContent11));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(fieldContent13));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权完成 冲正MsgPack
	 * 
	 * @param param
	 * @param grantFinshMsg 预授权完成请求包
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantFinishRush(final Param param, final MsgPack grantFinshMsg,
			final MsgPack retFinishMsgPack, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, grantFinshMsg.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "000000");// 交易处理码
		MsgPackUtils.createField4(msgPack, grantFinshMsg.getAmount());// 交易金额
		MsgPackUtils.createField11(msgPack, grantFinshMsg.getFieldContent11());// 同原交易
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (grantFinshMsg.getField(MsgFieldType.FIELD_38.getNo()) != null
				&& grantFinshMsg.getFieldContent38().length() == 6) {
			field_38 = grantFinshMsg.getFieldContent38();
		}

		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField39(msgPack, retFinishMsgPack.getFieldContent39());// 应答码-请求时为冲正原因
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("20"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(batchNo));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(grantFinshMsg.getFieldContent11()));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(retFinishMsgPack.getFieldContent13()));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建预授权完成撤销 MsgPack
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantFinishCancel(final Param param, final String accountNo, final double amount,
			final String fieldContent37,
			final String fieldContent38, final String field60_2, final String fieldContent11,
			final String fieldContent13, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型

		MsgPackUtils.createAccountField(msgPack, accountNo);// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200000");// 交易处理码
		MsgPackUtils.createField4(msgPack, amount);// 交易金额
		MsgPackUtils.createField11(msgPack, fieldContent11);// 原流水号
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (fieldContent38 != null && fieldContent38.length() == 6) {
			field_38 = fieldContent38;
		}

		MsgPackUtils.createField37(msgPack, fieldContent37);// 检索参考号
		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码 同原交易
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码 同原交易
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("11"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(batchNo));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(fieldContent11));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(fieldContent13));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}


	/**
	 * 
	 * 创建预授权完成撤销冲正 MsgPack
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createGrantFinishCancelRush(final Param param, final MsgPack grantCancelMsgPack, final String workKey)
			throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final MsgPack msgPack = new MsgPack();
		// 组预授权冲正报文
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, grantCancelMsgPack.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, grantCancelMsgPack.getFieldContent3());// 交易处理码(同原交易)
		MsgPackUtils.createField4(msgPack, grantCancelMsgPack.getAmount());// 交易金额(同原预授权交易)
		MsgPackUtils.createField11(msgPack, grantCancelMsgPack.getFieldContent11());// 受卡方系统跟踪号-原流水号
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		MsgPackUtils.createField38(msgPack, grantCancelMsgPack.getFieldContent38());// 应答码-请求时为冲正原因
		MsgPackUtils.createField39(msgPack, "98");// 应答码-请求时为冲正原因
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码-终端代码 同原交易
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码-商户代码 同原交易
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("11"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		MsgPackUtils.createField61(msgPack, grantCancelMsgPack.getFieldContent61().getBytes());// 原始信息域:
																								// 原批号+原POS流水号+原交易日期
		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建退货 MsgPack
	 * 
	 * @param bizBean 退货的bean 主要是根据银行在代扣交易时候返回的检索参考号来退货
	 * @return
	 * @throws BizException
	 */
	public MsgPack createReturn(final RefundBean bizBean, final String accountNo, final String workKey,
			final String newBankSendSn) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码

		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0220");// 消息类型
		MsgPackUtils.createAccountField(msgPack, accountNo);// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200000");// 交易处理码
		MsgPackUtils.createField4(msgPack, bizBean.getAmount().doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, newBankSendSn);// POS终端交易流水
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, "00");// 服务点条件码
		MsgPackUtils.createField37(msgPack, bizBean.getBankRecvSn());// 检索参考号
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("25"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(bizBean.getCreditbatchno()));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(bizBean.getBankSendSn()));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(bizBean.getTranDate().substring(4)));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期
		// MsgPackUtils.createField63(msgPack, "003CUP");
		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * 批结算 MsgPack
	 * 
	 * @param
	 * @return
	 * @throws BizException
	 */
	public MsgPack createBatchSettle(final String batNo, final String jtotalAmt, final String jtotalNum,
			final String dtotalAmt, final String dtotalNum) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String version = channelParms.get("100010");// 下载版本号
		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0500");// 消息类型
		MsgPackUtils.createField11(msgPack, sequenceManager.getCcbCreditSN());// POS终端交易流水
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码

		// 借记总金额 N12
		// 借记总笔数 N3
		// 贷记总金额 N12
		// 贷记总笔数 N3
		// 对账应答代码 N1
		int length = 0;
		final StringBuffer sbuf = new StringBuffer();
		sbuf.append(FormatTransfer.setLStrFormat(jtotalAmt, 12));
		sbuf.append(FormatTransfer.setLStrFormat(jtotalNum, 3));
		sbuf.append(FormatTransfer.setLStrFormat(dtotalAmt, 12));
		sbuf.append(FormatTransfer.setLStrFormat(dtotalNum, 3));
		sbuf.append("0");
		sbuf.append("0000000000000000000000000000000");

		final String settleAmt = sbuf.toString();
		length = settleAmt.getBytes().length;

		byte[] bytes = ByteUtils.strToBcdRightSide(FormatTransfer.setLStrFormat(String.valueOf(length), 3));
		bytes = ArrayUtils.addAll(bytes, ByteUtils.strToBcdLeftSide(settleAmt));

		MsgPackUtils.createField48(msgPack, bytes);// 结算总额

		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		byte[] field60B = ByteUtils.strToBcdRightSide("011");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("00"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batNo));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcdLeftSide("201"));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号+网络管理信息码
		MsgPackUtils.createField63(msgPack, "039" + operator + version);// 操作员代码(001)+下载版本号（36个空格)
		return msgPack;
	}

	/**
	 * 创建公共的8583报文头信息
	 * 
	 * @param msgPack
	 * @throws BizException
	 */
	public void createHeadMsg(final MsgPack msgPack) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String tpdu_10 = channelParms.get("100030");// Tpdu
		final String head_12 = channelParms.get("100031");// head
		// MsgPackUtils.createTpduField(msgPack,
		// ByteUtils.strToBcd("6000000000"));//5个字节
		// MsgPackUtils.createHeadField(msgPack,
		// ByteUtils.strToBcd("600113000000"));
		// MsgPackUtils.createTpduField(msgPack,ByteUtils.strToBcd("6006011123"));//5个字节
		// MsgPackUtils.createHeadField(msgPack, ByteUtils.strToBcd("600100023245"));

		MsgPackUtils.createTpduField(msgPack, ByteUtils.strToBcd(tpdu_10));// 5个字节
		MsgPackUtils.createHeadField(msgPack, ByteUtils.strToBcd(head_12));
	}

	/**
	 * POS终端采用ＥＣＢ的加密，加密消息类型（MTI）到63域之间的部分
	 * 
	 * @param msg 消息类型（MTI）到63域之间的部分
	 * @return
	 * @throws BizException
	 */
	public String macMsg(final String msg) throws BizException {
		String rtnMsg = "";
		try {
			final JDES jdes = new JDES();
			// jdes.SetKey(MacUtil.getMacDate(pwdKey,
			// workKey.getBytes()));//用主密钥解密工作密钥，形成明文密钥用于第64域生成
			rtnMsg = jdes.doECBEncryptZeroPadding(msg.getBytes(), msg.length()).toString();
		} catch (final Exception e) {
			Log4jUtil.info("建行信用卡DES-ECB加密出错：" + e.getMessage());
			throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
		}
		return rtnMsg;
	}

	/**
	 * 
	 * 向目标地址发送信息
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public MsgPack sendMsg(final MsgPack msgPack, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String socketIP = channelParms.get("100001"); // 建行socketIP
		final String socketPort = channelParms.get("100002");// 建行socketPort
		final SendBySocket4Ccb SendBySocket4Ccb = new SendBySocket4Ccb();
		Log4jUtil.info("调用公共的 socket 方法发送到建行信用卡渠道的报文数据:" + ByteUtils.bcdToStr(msgPack.getBytes()));
		final MsgPack rspMsg = SendBySocket4Ccb.sendAndRecv(socketIP, socketPort, msgPack.getBytes());

		if (rspMsg == null || rspMsg.getFields().size() == 0) {
			Log4jUtil.error("接收信息为空");
			throw new BizException(TransReturnCode.code_9109, TransReturnCode.getNameByValue(TransReturnCode.code_9109)
					+ "接收信息为空，银行服务异常，请联系银行");
		}

		// MAC校验 （当银行回执签名失败的时候，不进行MaC校验，以方便后续做重签到）
		if (!"A0".equals(rspMsg.getFieldContent39()) && !"77".equals(rspMsg.getFieldContent39()))
			if (!this.validateMac(rspMsg, workKey)) {
				Log4jUtil.error("响应报文中的MAC校验错误");
				if ("Y".equals(verifyFlag))// Y:验签
					throw new BizException(TransReturnCode.code_9109,
							TransReturnCode.getNameByValue(TransReturnCode.code_9109) + "响应报文中的MAC校验错误,报文被篡改。");
			}

		return rspMsg;
	}

	/**
	 * 
	 * 响应报文中的MAC校验
	 * 
	 * @param rspMsg
	 * @param workKey2
	 * @return
	 * @throws BizException
	 */
	private boolean validateMac(final MsgPack rspMsg, final String workKey) throws BizException {
		Log4jUtil.info("响应报文中的MAC校验,start...");
		boolean result = false;
		final MsgField macField = rspMsg.getField(MsgFieldType.FIELD_64.getNo());
		if (macField == null || macField.getStringValue() == null || "".equals(macField.getStringValue())) {
			Log4jUtil.info("响应报文中不存在MAC域，不进行mac检验。");
			return true;
		}

		if (macField.getStringValue().length() != 8) {
			throw new BizException("响应报文MAC域长度不为8位。", TransReturnCode.code_9109);
		}

		byte[] orgbytes = null;
		try {
			orgbytes = rspMsg.getBytes();
		} catch (BizException e) {
			throw new BizException(TransReturnCode.code_9109, e.getMessage());
		}

		final byte[] macData = ArrayUtils.subarray(orgbytes, 13, orgbytes.length - 8); // 从第14个字节开始
		Log4jUtil.info("参与mac加密的数据为：{}", LoUtils.byte2HexStr(macData));
		final String macStr = MacUtil.getMacDate(macData, workKey);
		AssertUtils.isTrue(macStr != null && macStr.length() == 16, TransReturnCode.code_9109, "消息校验错:" + macStr);

		if (macStr.equalsIgnoreCase(LoUtils.byte2HexStr(macField.getOrigMsg()))) {
			result = true;
		}

		Log4jUtil.info("响应报文中的MAC校验成功。");
		return result;
	}

	/**
	 * 
	 * 向目标地址发送信息 加密
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public MsgPack sendMsgEncrypt(final MsgPack msgPack, final String workKey) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String socketIP = channelParms.get("100001"); // 建行socketIP
		final String socketPort = channelParms.get("100002");// 建行socketPort
		final SendBySocket4Ccb SendBySocket4Ccb = new SendBySocket4Ccb();

		final JDES des = new JDES();
		des.SetKey(MacUtil.hexStringToByte(workKey));

		try {
			final byte[] sendMsgEncrypt = des.doECBDecryptNoPadding(msgPack.getBytes(), msgPack.getBytes().length);
			Log4jUtil.info("调用公共的 socket 方法发送到建行信用卡渠道的报文数据:" + ByteUtils.bcdToStr(msgPack.getBytes()));
			Log4jUtil.info("调用公共的 socket 方法发送到建行信用卡渠道的报文数据(加密后):" + ByteUtils.bcdToStr(sendMsgEncrypt));
			final MsgPack rspMsg = SendBySocket4Ccb.sendAndRecv(socketIP, socketPort, sendMsgEncrypt);
			return rspMsg;
		} catch (final Exception e) {
			Log4jUtil.error(e);
		}
		return null;
	}

	/**
	 * 
	 * 解析应答并处理
	 * 
	 * @param rspMsg
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState parseMsg(final MsgPack rspMsg, final Param param) throws BizException {
		MsgPack msgPack = new MsgPack();
		msgPack = this.unpackMsg(msgPack, rspMsg.getBytes());
		// msg=msgPack.getXXX
		return null;
	}

	/**
	 * 解包.
	 * 
	 * @param pack 未完成的包.
	 * @param msg 网络一次读到的字节流,可能为多个消息包(包括不完整的)
	 * @throws BizException
	 */
	private MsgPack unpackMsg(final MsgPack pack, final byte[] msg) throws BizException {
		final int msgLen = msg.length;
		int unpackedLen = 0;

		while (unpackedLen < msgLen) {
			unpackedLen += pack.unpack(msg);
		}
		return pack;
	}

	/**
	 * 
	 * @Description: 7.2.7. 预授权完成撤销
	 * @param bizBean
	 * @param workKey
	 * @param creditbatchno
	 * @param bankRecvSn
	 * @param tranDate
	 * @param bankSendSn
	 * @return
	 * @throws BizException
	 */
	public MsgPack createRevoke(final String bankCardNo, final BigDecimal refundAmount, final String workKey,
			final String bankSendSn, final String tranDate, final String bankRecvSn, final String creditbatchno,
			final String newBankSendSn) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		MsgPackUtils.createAccountField(msgPack, bankCardNo);// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200000");// 交易处理码
		MsgPackUtils.createField4(msgPack, refundAmount.doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, newBankSendSn);// POS终端交易流水
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, "06");// 服务点条件码
		MsgPackUtils.createField37(msgPack, bankRecvSn);// 检索参考号
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final ChannelParm batchIdParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100009"));
		final String batchNo = batchIdParm.getParvalue();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("25"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		byte[] field61B = ByteUtils.strToBcdRightSide("016");
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(creditbatchno));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(bankSendSn));
		field61B = ArrayUtils.addAll(field61B, ByteUtils.strToBcd(tranDate.substring(4)));
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域:
														// 原批号+原POS流水号+原交易日期
		// MsgPackUtils.createField63(msgPack, "003CUP");
		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

	/**
	 * 
	 * @param reqMsgPack
	 * @param retMsgPack
	 * @param workKey
	 * @return
	 * @throws BizException
	 */
	public MsgPack createRevokeRush(final MsgPack reqMsgPack, final MsgPack retMsgPack, final String workKey)
			throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 受卡机终端标识码-终端代码
		final String merchant = channelParms.get("100006");// 受卡方标识码-商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final MsgPack msgPack = new MsgPack();
		// 预授权
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, reqMsgPack.getAccountNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "000000");// 交易处理码
		MsgPackUtils.createField4(msgPack, reqMsgPack.getAmount());// 交易金额
		MsgPackUtils.createField11(msgPack, reqMsgPack.getFieldContent11());// 同原交易
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		String field_38 = "000000";
		if (reqMsgPack.getField(MsgFieldType.FIELD_38.getNo()) != null && reqMsgPack.getFieldContent38().length() == 6) {
			field_38 = reqMsgPack.getFieldContent38();
		}

		MsgPackUtils.createField38(msgPack, field_38);// 授权标识应答码，同原预授权交易

		if (retMsgPack != null && retMsgPack.getFieldContent39() != null
				&& retMsgPack.getFieldContent39().length() == 2) {
			MsgPackUtils.createField39(msgPack, retMsgPack.getFieldContent39());// 应答码-请求时为冲正原因
		} else {
			MsgPackUtils.createField39(msgPack, "98");
		}

		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		final String batchNo = reqMsgPack.get60_2();

		byte[] field60B = ByteUtils.strToBcdRightSide("008");
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd("20"));
		field60B = ArrayUtils.addAll(field60B, ByteUtils.strToBcd(batchNo));
		MsgPackUtils.createField60(msgPack, field60B);// 交易类型码+批次号

		final byte[] field61B = reqMsgPack.getFieldContent61().getBytes();
		MsgPackUtils.createField61(msgPack, field61B);// 原始信息域: 原批号+原POS流水号+原交易日期

		MsgPackUtils.mac(msgPack, workKey);// FIELD_64 MAC
		return msgPack;
	}

}
