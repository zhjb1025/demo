package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;

public class MD5 {
	private static final Logger logger = Logger.getLogger(MD5.class);
	public static final String ENCODE = "GBK"; // 编码格式 GBK；
	public String str;

	public String md5s(String plainText) throws BizException {

		try {
			plainText = new String(plainText.getBytes(Charset.forName("GBK")), ENCODE);
		} catch (UnsupportedEncodingException e1) {
			logger.error("把要加密的字符串转为[" + ENCODE + "]码出错！");
			e1.printStackTrace();
			throw new BizException("把要加密的字符串转为GBK码出错！");
		}

		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(plainText.getBytes(Charset.forName("GBK")));
			byte b[] = md.digest();
			int i;
			StringBuffer buf = new StringBuffer("");
			for (int offset = 0; offset < b.length; offset++) {
				i = b[offset];
				if (i < 0)
					i += 256;
				if (i < 16)
					buf.append("0");
				buf.append(Integer.toHexString(i));
			}
			str = buf.toString();
		} catch (NoSuchAlgorithmException e) {
			Log4jUtil.error(e);
		}
		return str;
	}

	public static void main(String agrs[]) {
		MD5 m = new MD5();
		try {
			System.out.println(m.md5s("1234567678"));
		} catch (BizException e) {
			Log4jUtil.error(e);
		}
	}
}