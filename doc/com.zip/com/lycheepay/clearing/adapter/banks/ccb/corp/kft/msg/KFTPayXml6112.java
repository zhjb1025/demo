package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg;

import org.dom4j.Element;
import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


public class KFTPayXml6112 extends KFTPayXmlBase {

	private String resultCode = "";
	private String chkResult = "";
	private String resultNote = "";
	private String oldSN = "";
	private String acctNo = "";
	private String acctName = "";
	private String idType = "";
	private String idNo = "";

	public KFTPayXml6112() {
		super();
	}

	public KFTPayXml6112(final boolean init, final String msgSeqId) {
		super(init, msgSeqId);
	}

	@Override
	protected void buildxmlbody() {
		// TODO Auto-generated method stub
		Element newElement = dom4jxml.addNode(dom4jxml.getRoot(), "MSG", "");
		newElement = dom4jxml.addNode(newElement, "AcctVerifyResult6112", "");
		dom4jxml.addNode(newElement, "ResultCode", resultCode);
		dom4jxml.addNode(newElement, "ChkResult", chkResult);
		dom4jxml.addNode(newElement, "ResultNote", resultNote);
		dom4jxml.addNode(newElement, "OldSN", oldSN);
		dom4jxml.addNode(newElement, "AcctNo", acctNo);
		dom4jxml.addNode(newElement, "AcctName", acctName);
		dom4jxml.addNode(newElement, "IDType", idType);
		dom4jxml.addNode(newElement, "IDNo", idNo);

	}

	@Override
	protected void parsexmlbody() throws BizException {
		// TODO Auto-generated method stub
		if (!this.getHead().getMsgCode().equals("6112")) {
			throw new BizException("MsgCode不为6112");
		}
		final Node node = dom4jxml.getNode("/KFT/MSG/AcctVerifyResult6112");
		if (node == null) {
			throw new BizException("9102", "报文格式错！");
		}
		resultCode = dom4jxml.getNodeText(node, "ResultCode", 4, 4, "N");
		chkResult = dom4jxml.getNodeText(node, "ChkResult", 0, 4, "N");
		resultNote = dom4jxml.getNodeText(node, "ResultNote", 0, 80, "G");
		oldSN = dom4jxml.getNodeText(node, "OldSN", 0, 20, "X");
		acctNo = dom4jxml.getNodeText(node, "AcctNo", 0, 32, "X");
		acctName = dom4jxml.getNodeText(node, "AcctName", 0, 80, "G");
		idType = dom4jxml.getNodeText(node, "IDType", 0, 1, "X");
		idNo = dom4jxml.getNodeText(node, "IDNo", 0, 60, "X");

		AssertUtils.notEmpty(resultCode, "9303", "报文ResultCode区为空，请检查");
		AssertUtils.notEmpty(oldSN, "9303", "报文OldSN区为空，请检查");
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(final String resultCode) {
		this.resultCode = resultCode;
	}

	public String getChkResult() {
		return chkResult;
	}

	public void setChkResult(final String chkResult) {
		this.chkResult = chkResult;
	}

	public String getResultNote() {
		return resultNote;
	}

	public void setResultNote(final String resultNote) {
		this.resultNote = resultNote;
	}

	public String getOldSN() {
		return oldSN;
	}

	public void setOldSN(final String oldSN) {
		this.oldSN = oldSN;
	}

	public String getAcctNo() {
		return acctNo;
	}

	public void setAcctNo(final String acctNo) {
		this.acctNo = acctNo;
	}

	public String getAcctName() {
		return acctName;
	}

	public void setAcctName(final String acctName) {
		this.acctName = acctName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(final String idType) {
		this.idType = idType;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(final String idNo) {
		this.idNo = idNo;
	}

}
