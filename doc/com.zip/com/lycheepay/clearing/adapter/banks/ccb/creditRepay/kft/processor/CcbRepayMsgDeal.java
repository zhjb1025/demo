package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.processor;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean.AccVerifyRsp;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean.BatchTrasNoticeRsp;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean.KeyApplyRsp;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.util.TranProcess;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.BatchBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.Status;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.SftpUtilByPass;
import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;
import com.lycheepay.clearing.util.StringUtil;


/**
 * 
 * <P>信息处理及sftp处理方法</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.CCB_REPAY_MSGDEAL)
public class CcbRepayMsgDeal {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	public final static String channelId = ChannelIdEnum.CCB_CREDIT_REPAY.getCode();

	/**
	 * Tenpay_CreditRepay_20100312_201003121234567890_003.csv Tenpay_RepayTotal
	 * _20100312_201003121234567890.csv RepayResult _20100312_201003121234567890.csv
	 * 
	 * @param trantype
	 * @return
	 */
	public String createFileName(final String flag, final String rePayDate, final String channelBatchId,
			final String fileNumber) {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String merchantCode = channelParms.get("100021");

		final StringBuffer fname = new StringBuffer("");

		if ("CreditRepay".equals(flag)) {
			fname.append(merchantCode).append("_CreditRepay_").append(rePayDate).append("_").append(channelBatchId)
					.append("_");
			fname.append(fileNumber).append(".csv");
		} else if ("RepayTotal".equals(flag)) {
			fname.append(merchantCode).append("_RepayTotal_").append(rePayDate).append("_").append(channelBatchId)
					.append(".csv");
		} else if ("RepayResult".equals(flag)) {
			fname.append("Kftpay").append("_Result_").append(rePayDate).append("_").append(channelBatchId)
					.append(".csv");
		}
		return fname.toString();
	}

	/**
	 * 
	 * @param batchFileName
	 * @throws BizException
	 */
	public void uploadFile(final String batchFileName) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String ftpServer = channelParms.get("100004");
		final String ftpKeyPath = channelParms.get("100005");
		final String ftpUser = channelParms.get("100006");
		final String batchFilepath = channelParms.get("100007");// 批量交易ftp银行端路径
		final String batchLocalFilepath = channelParms.get("100008");// 批量交易ftp本地端路径

		final FtpManager ftpManager = new FtpManager();
		ftpManager.setServer(ftpServer);
		ftpManager.setPassword(ftpKeyPath);
		ftpManager.setUser(ftpUser);
		ftpManager.setFilename(batchFileName);

		ftpManager.setLocalPath(batchLocalFilepath); // 本地文件夹（相对路径的目录）
		ftpManager.setPath(batchFilepath); // 远程目录，不用设置，FTP 用户默认的目录就是要上传文件的目录

		Log4jUtil.info("待发送文件本地路径：{} ", batchLocalFilepath);
		Log4jUtil.info("ftp服务器IP：{}，账号：{}，密码：{}，相对目录：{}", ftpServer, ftpUser, ftpKeyPath, batchFilepath);

		try {
			ftpManager.putMyFile_actionPerformed_binary();
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "上传文件" + batchFileName + "出错！！");
		}
		Log4jUtil.info("建行信用卡还款:{}已上传到服务器", batchFileName);
	}

	/**
	 * 上传到Sftp服务器
	 * 
	 * @param batchFileName
	 * @throws BizException
	 */
	public void uploadFileToSftp(final String batchFileName) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String ftpServer = channelParms.get("100004");
		final String ftpKeyPath = channelParms.get("100005");
		final String ftpUser = channelParms.get("100006");
		final String batchFilepath = channelParms.get("100007");// 批量交易ftp银行端路径
		final String batchLocalFilepath = channelParms.get("100008");// 批量交易ftp本地端路径
		final SftpUtilByPass sf = new SftpUtilByPass(ftpServer, ftpUser, ftpKeyPath, "", 22);
		final ChannelSftp sftp = sf.connectByKeyFile();

		// 创建目录
		String remotePath = this.mkdirSftp(batchFilepath, batchFileName, sftp);

		sf.upload(remotePath, batchLocalFilepath + File.separator + batchFileName, sftp);
		sf.disconnect(sftp);

		Log4jUtil.info("----待发送文件本地路径：{} ", batchLocalFilepath);
		Log4jUtil.info("----Sftp服务器IP：{}，账号：{}，密码：{}，相对目录：{}", ftpServer, ftpUser, ftpKeyPath, remotePath);
		Log4jUtil.info("----建行信用卡还款系统报文:" + batchFileName + "已上传到服务器");
	}


	/**
	 * 
	 * <p>sftp服务器创建目录</p>
	 * 
	 * @param batchFilepath
	 * @param batchFileName
	 * @param sftp
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public String mkdirSftp(String batchFilepath, String batchFileName, ChannelSftp sftp) throws BizException {
		// 创建目录
		// String remoteDir = batchFilepath;
		// String[] em = batchFileName.replace(".csv", "").split("_");
		// String dir_0 = remoteDir;
		// String dir_1 = remoteDir + File.separator + em[2].substring(0, 6);
		// String dir_2 = dir_1 + File.separator + em[2].substring(6);
		// String dir_3 = dir_2 + File.separator + em[3];
		// remoteDir = dir_3;
		Log4jUtil.info("batchFilepath:" + batchFilepath);
		// 首先查看下目录，如果不存在，系统会被错，捕获这个错，生成新的目录。
		// 不能多级创建
		try {
			try {
				sftp.ls(batchFilepath);
			} catch (Exception e) {
				sftp.mkdir(batchFilepath);
			}
			// try {
			// sftp.ls(dir_1);
			// } catch (Exception e) {
			// sftp.mkdir(dir_1);
			// }
			// try {
			// sftp.ls(dir_2);
			// } catch (Exception e) {
			// sftp.mkdir(dir_2);
			// }
			// try {
			// sftp.ls(dir_3);
			// } catch (Exception e) {
			// sftp.mkdir(dir_3);
			// }
		} catch (SftpException e) {
			Log4jUtil.error(e);
			sftp.disconnect();
			throw new BizException(TransReturnCode.code_9108, "sftp服务器创建目录失败");
		}

		return batchFilepath;
	}

	/**
	 * 生成文件
	 * 
	 * @param filePath 文件所在的文件夹
	 * @param fileName 文件名称
	 * @param fileValue文件内容
	 * @return 文件名（含相对路径文件夹）
	 * @throws BizException
	 */
	private String createBatchFile(final String filePath, final String fileName, final String fileValue)
			throws BizException {
		// PrintWriter pw=null;
		// FileProcess.createDir(filePath); // 如果文件夹不存在，创建文件夹
		final String AccFile = filePath + File.separator + fileName; // 含相对路径的文件名
		try {
			// pw = new PrintWriter(AccFile);
			FileUtils.writeStringToFile(new File(AccFile), fileValue, "GBK");
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "生成文件出错！！" + e.getMessage());
		}
		// pw.write(fileValue);
		// pw.flush();
		// pw.close();
		return AccFile;
	}

	/**
	 * 
	 * @param fileName
	 * @param fileStr
	 * @return
	 * @throws BizException
	 */
	public String createBatchFile(final String fileName, final String fileStr) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String batchLocalFilepath = channelParms.get("100008");// 批量交易ftp本地端路径
		Log4jUtil.info("batchLocalFilepath：" + batchLocalFilepath + "; fileName：" + fileName);
		return createBatchFile(batchLocalFilepath, fileName, fileStr);
	}

	/**
	 * 批量文件结果文件下载
	 * 
	 * @param param
	 * @throws BizException
	 */
	public String batRetDeal(final String batchFileRcv) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String batchLocalFilepath = channelParms.get("100008");// 批量交易ftp本地端路径
		// 从银行FTP服务器获取批量结果文件
		// 如果文件夹不存在，创建文件夹
		if (FileProcess.createDir(batchLocalFilepath) == false) {
			throw new BizException(TransReturnCode.code_9109, "创建文件夹【" + batchLocalFilepath + "】 出错！！");
		}

		// 下载
		this.downloadFileFromSftp(batchFileRcv);

		final String fullFileName = batchLocalFilepath + File.separator + batchFileRcv;
		Log4jUtil.info("返回的文件（含相对路径）为：" + fullFileName);

		return fullFileName;
	}

	/**
	 * 下载Sftp服务器文件
	 * 
	 * @param rcvFileName
	 * @throws BizException
	 */
	public void downloadFileFromSftp(final String rcvFileName) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String ftpServer = channelParms.get("100004");
		final String ftpKeyPath = channelParms.get("100005");
		final String ftpUser = channelParms.get("100006");
		final String resultFilepath = channelParms.get("100022");// 批量交易结果文件ftp银行端路径
		final String batchLocalFilepath = channelParms.get("100008");// 批量交易ftp本地端路径
		final String listFiles_sftp = channelParms.get("100023");// 批量交易ftp本地端路径

		final SftpUtilByPass sf = new SftpUtilByPass(ftpServer, ftpUser, ftpKeyPath, "", 22);
		final ChannelSftp sftp = sf.connectByKeyFile();

		// 目录
		// String remoteDir = resultFilepath;
		// String separator = "/";
		// String[] em = rcvFileName.replace(".csv", "").split("_");
		// String dir_1 = remoteDir + separator + em[2].substring(0, 6);
		// String dir_2 = dir_1 + separator + em[2].substring(6);
		// String dir_3 = dir_2 + separator + em[3];
		// remoteDir = dir_3;

		/**
		 * 列举(Sftp下该目录)文件列表并打印到日志,为空时将不读取.为 "/" 为列出根目录.
		 */
		if (!StringUtil.isBlank(listFiles_sftp)) {
			try {
				Vector v = sf.listFiles(resultFilepath, sftp);
				Log4jUtil.info("----列举 SFTP服务器 目录{}下的文件:", resultFilepath);
				for (int i = 0; i < v.size(); i++) {
					Log4jUtil.info(v.get(i));
				}
			} catch (SftpException e) {
				Log4jUtil.error("--列举 SFTP服务器 目录{}下的文件失败", resultFilepath);
				Log4jUtil.error(e);
			}
		}


		sf.download(resultFilepath, rcvFileName, batchLocalFilepath + File.separator + rcvFileName, sftp);
		sf.disconnect(sftp);

		Log4jUtil.info("----Sftp服务器IP：{}，账号：{}，密码：{}，相对目录：{} ,下载文件：{}", ftpServer, ftpUser,				ftpKeyPath, resultFilepath, rcvFileName);
		Log4jUtil.info("----保存到本地路径：{} ", batchLocalFilepath);
		Log4jUtil.info("----建行信用卡还款系统批量结果文件:【{}】已下载到本地", rcvFileName);
	}

	/**
	 * 信用卡还款批量授权入账接口
	 * 
	 * @param batchBean
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendBatchTrasNotice(final BatchBean batchBean) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String batchLocalFilepath = channelParms.get("100008"); // batchLocalFilepath
		final String socketPort = channelParms.get("100011");// socketPort
		final String socketIP = channelParms.get("100012"); // socketIP
		final String workKey = channelParms.get("100013"); // workKey
		final String iSK = channelParms.get("100014"); // iSK
		final String bankCode = channelParms.get("100015"); // bankCode
		final String orgCode = channelParms.get("100016"); // orgCode
		BatchTrasNoticeRsp rsp = new BatchTrasNoticeRsp();
		final TranProcess tranProcess = new TranProcess();

		batchBean.setOrgcode(orgCode);

		Log4jUtil.info("-----------批量代付通知请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, batchBean);
		final String applyNo = sequenceManagerService.getCcbCreditRepaySN(DateUtil.getCurrentDate());
		rsp = tranProcess.transNotice(socketIP, socketPort, batchBean, workKey, iSK, bankCode, applyNo,
				batchLocalFilepath);

		final ReturnState rs = new ReturnState();
		if (rsp.getRetcode().equals("00000")) {
			rs.setReturnState(Status.SUCC); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			rs.setReturnState(Status.FAIL); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回
		channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, rsp.getRetcode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		rs.setBankRetCode(rsp.getRetcode()); // 银行返回代码
		rs.setReturnMsg(respInfo); // 银行响应信息
		rs.setBankPostScript(respInfo);
		rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
		rs.setReturnObj(rsp);
		return rs;
	}

	/**
	 * 密钥申请
	 * 
	 * @param batchBean
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendKeyApply() throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String socketPort = channelParms.get("100011");// socketPort
		final String socketIP = channelParms.get("100012"); // socketIP
		final String workKey = channelParms.get("100013"); // workKey
		final String iSK = channelParms.get("100014"); // iSK
		final String bankCode = channelParms.get("100015"); // bankCode
		final String orgCode = channelParms.get("100016"); // orgCode
		final String dAK = channelParms.get("100017"); // dAK
		final TranProcess tranProcess = new TranProcess();

		Log4jUtil.info("密钥申请开始");
		final String applyNo = sequenceManagerService.getCcbCreditRepaySN(DateUtil.getCurrentDate());
		KeyApplyRsp rsp = tranProcess.keyApply(socketIP, socketPort, workKey, dAK, iSK, bankCode, orgCode, applyNo);

		final ReturnState rs = new ReturnState();
		if (rsp.getRetcode().equals("00000")) {
			rs.setReturnState(Status.SUCC); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			rs.setReturnState(Status.FAIL); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = channelRtncodeService
				.findById(new ChannelRtncodeId(channelId, rsp.getRetcode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		rs.setBankRetCode(rsp.getRetcode()); // 银行返回代码
		rs.setReturnMsg(respInfo); // 银行响应信息
		rs.setBankPostScript(rsp.getDesc());
		rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
		rs.setReturnObj(rsp.getDck());
		return rs;
	}

	/**
	 * 
	 * <p>账号验证</p>
	 * 
	 * @return
	 * @author 汤兴友 xytang
	 */
	public ReturnState accountVerify(BankCardVerifyDTO accountVerify) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String socketPort = channelParms.get("100011");// socketPort
		final String socketIP = channelParms.get("100012"); // socketIP
		final String workKey = channelParms.get("100013"); // workKey
		final String iSK = channelParms.get("100014"); // iSK
		final String bankCode = channelParms.get("100015"); // bankCode
		final String orgCode = channelParms.get("100016"); // orgCode
		final String dAK = channelParms.get("100017"); // dAK

		String name = accountVerify.getCardHolderName();
		String cardid = accountVerify.getBankCardNo();

		final TranProcess tranProcess = new TranProcess();

		Log4jUtil.info("-----------账号验证发往到银行 start...");
		final String verifySn = sequenceManagerService.getCcbCreditRepaySN(DateUtil.getCurrentDate());
		AccVerifyRsp rsp = tranProcess.accVerify(socketIP, socketPort, workKey, dAK, iSK, bankCode, orgCode, verifySn, name, cardid);

		final ReturnState rs = new ReturnState();
		if ("00000".equals(rsp.getRetcode())) {
			rs.setReturnState(Status.SUCC); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			rs.setReturnState(Status.FAIL); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = channelRtncodeService
				.findById(new ChannelRtncodeId(channelId, rsp.getRetcode()));
		String channelCode, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
			respInfo = "卡信息验证失败";
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}
		rs.setBankRetCode(rsp.getRetcode()); // 银行返回代码
		if (StringUtils.isNotBlank(rsp.getDesc())) {
			rs.setReturnMsg(rsp.getDesc());
		} else {
			rs.setReturnMsg(respInfo);
		}
		rs.setBankPostScript(rsp.getDesc());
		rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
		return rs;
	}
}
