---建行银企增加 基金的支付归集分账户 的代收付更新。
---注：其中的 渠道基金结算户账号  KFTJJ20121010 数据是测试用的，生产环境上请注意替换。   
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100030', 'useOfCode_JJ', '0000053', 'Y', null, null, '网银代发【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100031', 'useOfCode_JJ', '0000053', 'Y', null, null, '网银代扣【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100032', 'billCode_JJ', 'qgdf206623002', 'Y', null, null, '代付项目编号【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100033', 'billCode_JJ', 'qgdk20663', 'Y', null, null, '代收项目编号【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100034', 'corpAccountID_JJ', 'KFTJJ20121010', 'Y', null, null, '基金平台企业账户ID，用于判断交易的发起源【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100035', 'settleAcc_JJ', '44201530300052515682', 'Y', null, null, '渠道基金结算户账号【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100036', 'settleAccName_JJ', '深圳市快付通金融网络科技服务有限公司', 'Y', null, null, '渠道基金结算户账号名称【基金专用】');
insert into CHANNEL_PARM (CHANNELID, CODE, PARNAME, PARVALUE, IFMODIFY, USERCODE, UPDATETIME, REMARK)
values ('3001050000', '100037', 'settleAccBankNo_JJ', '105584000001', 'Y', null, null, '渠道基金结算户行别【基金专用】');
commit;