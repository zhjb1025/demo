package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util;

import java.util.ArrayList;
import java.util.List;

import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;


/**
 * 
 * <P>批量还款汇总实体类</P>
 * 
 * @author 汤兴友 xytang
 */
public class BatchBean {
	private String channelBatchNo;
	private int subFileNum;// 子文件数
	private int totalNum;// 总笔数
	private double totalAmt;// 总金额
	private String currency = "RMB";// 币种
	private String payDate = "";// 付款日期 20100311
	private String payTime = "";// 付款日期 14:30:05
	private String des = "信用卡还款";// 描述 XX行信用卡还款
	private String note = "";// 备注
	
	List<BatchNoticeBean> beans = new ArrayList<BatchNoticeBean>(); // 子文件信息
	private String summaryFile = "";// 汇总文件名
	
	private String trantype;
	private ReturnState returnState;
	
	private String orgcode; // 机构代码

	public String getOrgcode() {
		return orgcode;
	}

	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}

	public String getTrantype() {
		return trantype;
	}

	public void setTrantype(String trantype) {
		this.trantype = trantype;
	}

	public ReturnState getReturnState() {
		return returnState;
	}

	public void setReturnState(ReturnState returnState) {
		this.returnState = returnState;
	}

	public String getChannelBatchNo() {
		return channelBatchNo;
	}

	public void setChannelBatchNo(String channelBatchNo) {
		this.channelBatchNo = channelBatchNo;
	}

	public int getSubFileNum() {
		return subFileNum;
	}

	public void setSubFileNum(int subFileNum) {
		this.subFileNum = subFileNum;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}

	public double getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(double totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPayDate() {
		return payDate;
	}

	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	public String getDes() {
		return des;
	}

	public void setDes(String des) {
		this.des = des;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public List<BatchNoticeBean> getBeans() {
		return beans;
	}

	public void setBeans(List<BatchNoticeBean> beans) {
		this.beans = beans;
	}

	public String getSummaryFile() {
		return summaryFile;
	}

	public void setSummaryFile(String summaryFile) {
		this.summaryFile = summaryFile;
	}
}
