/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-3-1 下午4:56:36
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.processor.CcbCreditDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCancelDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompleteDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompletionCancelDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行信用卡银企直连渠道服务</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午5:17:15
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDIT_CHANNEL_SERVICE)
public class CcbCreditChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CREDIT_DIRECT_PROCESS)
	private CcbCreditDirectProcess ccbCreditDirectProcess;

	private static final String channelId = ChannelIdEnum.CCB_CREDIT_CARD.getCode();

	/**
	 * 预授权交易
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	public ClearingResultDTO preAuth(final PreAuthDTO bizDto) {
		Log4jUtil.setLogClass("CCB", "preAuthTrans");
		Log4jUtil.info(bizDto);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.PRE_AUTH);
		param.setSn(bizDto.getTxnId());
		param.setCardType(BankCardType.CREDIT_CARD);
		param.setBorc(bizDto.getAccountType());
		param.setBizBean(bizDto);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setClearingTransType(ClearingTransType.PRE_AUTH);
		dto.setChannelId(channelId);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCreditDirectProcess.preAuth(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 预授权撤销交易
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	public ClearingResultDTO preAuthCancel(final PreAuthCancelDTO bizDto) {
		Log4jUtil.setLogClass("CCB", "preAuthTrans");
		Log4jUtil.info(bizDto);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.PRE_AUTH_CANCLE);
		param.setSn(bizDto.getTxnId());
		param.setCardType(BankCardType.CREDIT_CARD);
		param.setBizBean(bizDto);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.PRE_AUTH_CANCLE);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCreditDirectProcess.preAuthCancel(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 预授权完成交易
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	public ClearingResultDTO preAuthComplete(final PreAuthCompleteDTO bizDto) {
		Log4jUtil.setLogClass("CCB", "preAuthTrans");
		Log4jUtil.info(bizDto);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.PRE_AUTH_COMPLETE);
		param.setSn(bizDto.getTxnId());
		param.setCardType(BankCardType.CREDIT_CARD);
		param.setBizBean(bizDto);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.PRE_AUTH_COMPLETE);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCreditDirectProcess.preAuthComplete(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 预授权完成撤销交易
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO preAuthCompletionCancel(PreAuthCompletionCancelDTO bizDto) {
		Log4jUtil.setLogClass("CCB", "preAuthTrans");
		Log4jUtil.info(bizDto);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.PRE_AUTH_COMPLETITON_CANCLE);
		param.setSn(bizDto.getTxnId());
		param.setCardType(BankCardType.CREDIT_CARD);
		param.setBizBean(bizDto);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.PRE_AUTH_COMPLETITON_CANCLE);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCreditDirectProcess.preAuthCompleteCancel(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * PS.实时代扣
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) {
		Log4jUtil.setLogClass("CCB", "credit");
		Log4jUtil.info(deductDTO);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCreditDirectProcess.directDeduct(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * PS.自适应退款
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#autoRealtimeRefund(com.lycheepay.clearing.common.dto.trade.RefundDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO autoRealtimeRefund(final RefundDTO refund) {
		Log4jUtil.setLogClass("CCB", "credit");
		Log4jUtil.info(refund);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		param.setSn(refund.getTxnId());
		param.setBorc(refund.getBankCardType());
		param.setBizBean(refund);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_PAY);

		try {
			dto = ChannelResultUtil.covertResultDTO(ccbCreditDirectProcess.autoRealtimeRefund(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * <p>联机批结算及重签到 定时任务处理</p>
	 * 
	 * @author 张凯锋(13816608861) @
	 * @throws BizException
	 */
	public void dealBatSettle() {
		Log4jUtil.setLogClass("CCB", "creditDealBatSettle");

		ReturnState returnState = new ReturnState();
		try {
			returnState = ccbCreditDirectProcess.dealBatSettle();
		} catch (final BizException e) {
			Log4jUtil.error(e);
		}

		if (returnState.getChannelCode().equals(TransReturnCode.code_0000)) {
			Log4jUtil.info("03 处理成功。");
		} else {
			Log4jUtil.info("04处理失败" + returnState.getReturnMsg());
		}
	}
}
