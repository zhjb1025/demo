package com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AmountUtils;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 消息包.
 * 
 * @author aps-mhc
 */
public class MsgPack {
	// 消息所有者,主要为客户端连接的sessionId或与服务端连接的sessionId.
	private String ownerId;

	// 两个字节消息长度,表达的值不包括本身长度.
	private byte[] msgLenByte = new byte[0];

	// 二进制位图, 长度64.
	private byte[] bitmapBit = new byte[0];

	// 各域.
	private final Map<String, MsgField> fields = new HashMap<String, MsgField>();

	// 60域,61域
	private Field60 field60;
	private Field61 field61;
	private Field63 field63;

	/**
	 * 取60.1域值
	 * 
	 * @return
	 * @throws BizException
	 */
	public String get60_1() throws BizException {
		if (field60 == null) {
			field60 = new Field60(fields.get(MsgFieldType.FIELD_60.getNo()).getOrigValue());
		}

		return field60.get60_1();
	}

	/**
	 * 取60.2域值
	 * 
	 * @return
	 * @throws BizException
	 */
	public String get60_2() throws BizException {
		if (field60 == null) {
			field60 = new Field60(fields.get(MsgFieldType.FIELD_60.getNo()).getOrigValue());
		}

		return field60.get60_2();
	}

	/**
	 * 取61.1域值
	 * 
	 * @return
	 * @throws BizException
	 */
	public String get61_1() throws BizException {
		if (field61 == null) {
			field61 = new Field61(fields.get(MsgFieldType.FIELD_61.getNo()).getOrigValue());
		}

		return field61.get61_1();
	}

	/**
	 * 取61.2域值
	 * 
	 * @return
	 * @throws BizException
	 */
	public String get61_2() throws BizException {
		if (field61 == null) {
			field61 = new Field61(fields.get(MsgFieldType.FIELD_61.getNo()).getOrigValue());
		}

		return field61.get61_2();
	}

	/**
	 * 取63.1域值
	 * 
	 * @return
	 * @throws BizException
	 */
	public String get63_1() throws BizException {
		if (field63 == null) {
			field63 = new Field63(fields.get(MsgFieldType.FIELD_63.getNo()).getOrigValue());
		}

		return field63.get63_1();
	}

	/**
	 * 取63.2域值
	 * 
	 * @return
	 * @throws BizException
	 */
	public String get63_2() throws BizException {
		if (field63 == null) {
			field63 = new Field63(fields.get(MsgFieldType.FIELD_63.getNo()).getOrigValue());
		}

		return field63.get63_2();
	}

	/**
	 * 调换tpdu的目标和源地址.
	 */
	public void exchangeTpduAddress() throws BizException {
		final MsgField tpduField = getField(MsgFieldType.TPDU.getNo());
		final Tpdu tpdu = new Tpdu(tpduField.getOrigMsg());

		tpdu.exchangeAddress();
		tpduField.setOrigMsg(tpdu.getBcdValue());
	}

	public Tpdu getTpdu() throws BizException {
		final MsgField tpduField = getField(MsgFieldType.TPDU.getNo());
		return new Tpdu(tpduField.getOrigMsg());
	}

	public void setTpdu(final Tpdu tpdu) throws BizException {
		final MsgField tpduField = getField(MsgFieldType.TPDU.getNo());
		final byte[] bcdTpdu = tpdu.getBcdValue();
		tpduField.setOrigMsg(bcdTpdu);
	}

	/**
	 * 取第4金额域.
	 * 
	 * @param msgPack
	 * @return
	 */
	public Double getAmount() {
		final MsgField field = getField(MsgFieldType.FIELD_4.getNo());

		if (field == null) {
			return null;
		}

		return AmountUtils.format(field.getDoubleValue() / 100);
	}

	/**
	 * 取主账号.
	 */
	public String getAccountNo() {
		class AccountReader {
			public String getAccountNo() {
				String accountNo = getFromField2();
				if (accountNo != null) {
					return accountNo;
				}

				accountNo = getFromField35();
				if (accountNo != null) {
					return accountNo;
				}

				accountNo = getFromField36();
				if (accountNo != null) {
					return accountNo;
				}

				return null;
			}

			private String getFromField2() {
				final MsgField field = getField(MsgFieldType.FIELD_2.getNo());
				return field == null ? null : field.getStringValue();
			}

			private String getFromField35() {
				final MsgField field = getField(MsgFieldType.FIELD_35.getNo());

				if (field == null) {
					return null;
				}

				// 第35域第二磁道中取账号.
				final String track = field.getStringValue();
				final String[] trackElement = track.split("\\D");

				return trackElement[0];
			}

			private String getFromField36() {
				final MsgField field = getField(MsgFieldType.FIELD_36.getNo());

				if (field == null) {
					return null;
				}

				// 第36域第三磁道中取账号.
				final String track = field.getStringValue();
				final String[] trackElement = track.split("\\D");

				// 过滤2位的格式代码("99")
				return trackElement[0].substring(2);
			}
		}

		return new AccountReader().getAccountNo();
	}

	/**
	 * 取3域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent3() {
		final MsgField field = getField(MsgFieldType.FIELD_3.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取11域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent11() {
		final MsgField field = getField(MsgFieldType.FIELD_11.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取13域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent13() {
		final MsgField field = getField(MsgFieldType.FIELD_13.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取37域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent37() {
		final MsgField field = getField(MsgFieldType.FIELD_37.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取38域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent38() {
		final MsgField field = getField(MsgFieldType.FIELD_38.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取39域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent39() {
		final MsgField field = getField(MsgFieldType.FIELD_39.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取44域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent44() {
		final MsgField field = getField(MsgFieldType.FIELD_44.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取62域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent62() {
		final MsgField field = getField(MsgFieldType.FIELD_62.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取第39返回码域.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getRspCode() {
		final MsgField field = getField(MsgFieldType.FIELD_39.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取57域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getFieldContent57() {
		final MsgField field = getField(MsgFieldType.FIELD_57.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	/**
	 * 取消息类别域内容.
	 * 
	 * @param msgPack
	 * @return
	 */
	public String getMsgType() {
		final MsgField field = getField(MsgFieldType.MSG_TYPE.getNo());

		if (field == null) {
			return null;
		}

		return field.getStringValue();
	}

	public MsgField getField(final String fieldNo) {
		return fields.get(fieldNo);
	}

	public MsgField removeField(final String fieldNo) {
		// 位图中对应的域清零.
		final int bitmapIndex = MsgFieldType.valueOf(fieldNo).getBitmapIndex();
		if (bitmapIndex >= 0) {
			bitmapBit[bitmapIndex] = 0;
		}

		return fields.remove(fieldNo);
	}

	public boolean isFull() {
		if (!isFullBitmapBit()) {
			return false;
		}

		final MsgField lastField = getLastField();

		if (lastField == null) {
			return false;
		}

		return MsgFieldType.valueOf(lastField.getNo()).getParser().isDone(lastField);
	}

	private boolean isFullBitmapBit() {
		return bitmapBit != null && bitmapBit.length == 64;
	}

	private MsgField getLastField() {
		for (int i = bitmapBit.length - 1; i >= 2; i--) {
			if (bitmapBit[i] == 1) {
				return fields.get(String.valueOf(i + 1));
			}
		}

		return null;
	}

	/**
	 * @param msg
	 */
	public int unpack(final byte[] msg) {
		if (ArrayUtils.isEmpty(msg)) {
			return 0;
		}

		// 解析每域获取的字节长度.
		int startPos = 0;

		// 取消息长度.
		startPos += parseMsgLen(msg);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取tpdu.
		startPos += MsgFieldType.TPDU.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取head.
		startPos += MsgFieldType.HEAD.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取msgtype.
		startPos += MsgFieldType.MSG_TYPE.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取bitmap.
		startPos += MsgFieldType.BITMAP.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 设置位图二进制.
		setBitmapBit();

		// 解析从第2域开始的各域.
		startPos += parseFieldsFrom2(msg, startPos);
		return startPos;
	}

	/**
	 * 解析消息长度.
	 * 
	 * @param msg 不为空,最少1个字节.
	 * @return
	 */
	private int parseMsgLen(final byte[] msg) {
		final int parsedLen = msgLenByte.length;

		// 2个字节的消息长度.
		if (parsedLen == 2) {
			return 0;
		}

		// 差1个字节.
		if (parsedLen == 1) {
			msgLenByte = ArrayUtils.add(msgLenByte, msg[0]);

			return 1;
		}

		// 差2个字节.
		if (parsedLen == 0) {
			if (msg.length == 1) {
				msgLenByte = ArrayUtils.add(msgLenByte, msg[0]);

				return 1;
			} else {
				msgLenByte = ArrayUtils.addAll(msgLenByte, new byte[] { msg[0], msg[1] });

				return 2;
			}
		}

		// never execute here.
		return 0;
	}

	/**
	 * 取消息长度,不包括最开始的标识的2个字节.
	 * 
	 * @return
	 */
	public int getMsgLenValue() {
		final String first = Integer.toHexString(msgLenByte[0] & 0xFF);
		final String second = Integer.toHexString(msgLenByte[1] & 0xFF);

		return Integer.valueOf(first.concat(second), 16);
	}

	/**
	 * 解析从第2域开始的各域, 子域不解析. 前提: 二进制位图已生成.
	 */
	private int parseFieldsFrom2(final byte[] msg, final int startPos) {
		if (bitmapBit == null || bitmapBit.length != 64) {
			return 0;
		}

		// 已读出的字节数.
		int readedLen = 0;
		for (int i = 0; i < bitmapBit.length; i++) {

			if (bitmapBit[i] == 0) {
				continue;
			}

			if (isEofMsg(msg, startPos)) {
				return startPos;
			}

			final String fieldKey = String.valueOf(i + 1);
			Log4jUtil.info("解析Fields=============" + fieldKey);
			final MsgFieldType type = MsgFieldType.valueOf(fieldKey);
			readedLen += type.getParser().parse(fields, msg, startPos + readedLen);
		}

		return readedLen;
	}

	private boolean isEofMsg(final byte[] msg, final int index) {
		return index == msg.length - 1;
	}

	private void setBitmapBit() {
		final boolean isDone = MsgFieldType.BITMAP.getParser().isDone(fields);

		if (!isDone) {
			return;
		}

		final byte[] bitmap = fields.get(MsgFieldType.BITMAP.getNo()).getOrigMsg();
		bitmapBit = ByteUtils.byteToBinary(bitmap);
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(final String clientId) {
		this.ownerId = clientId;
	}

	public byte[] getBytes() throws BizException {
		byte[] bytes = null;

		resetMsgLenByte();
		bytes = ArrayUtils.addAll(bytes, msgLenByte);
		bytes = ArrayUtils.addAll(bytes, fields.get(MsgFieldType.TPDU.getNo()).getOrigMsg());
		bytes = ArrayUtils.addAll(bytes, fields.get(MsgFieldType.HEAD.getNo()).getOrigMsg());
		bytes = ArrayUtils.addAll(bytes, fields.get(MsgFieldType.MSG_TYPE.getNo()).getOrigMsg());
		bytes = ArrayUtils.addAll(bytes, fields.get(MsgFieldType.BITMAP.getNo()).getOrigMsg());

		if (!isFullBitmapBit()) {
			return bytes;
		}

		// 加入各域.
		for (int i = 0; i < bitmapBit.length; i++) {
			if (bitmapBit[i] == 0) {
				continue;
			}

			final String fieldKey = String.valueOf(i + 1);
			bytes = ArrayUtils.addAll(bytes, fields.get(fieldKey).getOrigMsg());
		}

		return bytes;
	}

	/**
	 * 打包, 新包或修改过的旧包要重新算mac.
	 * 
	 * @return
	 * @throws BizException
	 */
	public byte[] pack() throws BizException {
		return getBytes();
	}

	/**
	 * 位图中的域, 更新域或新建域, 存在无位图情况.
	 * 
	 * @param field
	 * @param fieldIndex
	 */
	public void putBitmapField(final MsgField field) {
		if (field == null) {
			return;
		}

		// 无位图时创建位图域.
		if (ArrayUtils.isEmpty(bitmapBit)) {
			bitmapBit = new byte[64];
			fields.put(MsgFieldType.BITMAP.getNo(), createBitmap(bitmapBit));
		}

		final String fieldNo = field.getNo();
		final boolean hasOrigField = fields.get(fieldNo) != null;
		fields.put(fieldNo, field);

		// 原本含有该域, 不再设置bitmap.
		if (hasOrigField) {
			return;
		}

		// 原本不含有该域时设置bitmap.
		final int fieldIndex = MsgFieldType.valueOf(field.getNo()).getBitmapIndex();
		bitmapBit[fieldIndex] = 1;

		final MsgField bitmap = fields.get(MsgFieldType.BITMAP.getNo());
		bitmap.setOrigMsg(ByteUtils.binaryToByte(bitmapBit));
	}

	/**
	 * 非位图中的域.
	 * 
	 * @param field
	 */
	public void put(final MsgField field) {
		final String fieldNo = field.getNo();
		fields.put(fieldNo, field);
	}

	private MsgField createBitmap(final byte[] bitmapBit) {
		final byte[] value = ByteUtils.binaryToByte(bitmapBit);
		final MsgField field = MsgField.create(MsgFieldType.BITMAP.getNo());
		field.setOrigMsg(value);

		return field;
	}

	/**
	 * 取消息长度,从TPDU开始到最后,不包括LEN域.
	 * 
	 * @return
	 * @throws BizException
	 */
	private int resetMsgLenByte() throws BizException {
		int len = 0;
		len += fields.get(MsgFieldType.TPDU.getNo()).getOrigMsgLength();
		len += fields.get(MsgFieldType.HEAD.getNo()).getOrigMsgLength();
		len += fields.get(MsgFieldType.MSG_TYPE.getNo()).getOrigMsgLength();
		len += fields.get(MsgFieldType.BITMAP.getNo()).getOrigMsgLength();

		if (!isFullBitmapBit()) {
			return len;
		}

		// 加入各域.
		for (int i = 0; i < bitmapBit.length; i++) {
			if (bitmapBit[i] == 0) {
				continue;
			}

			final String fieldKey = String.valueOf(i + 1);
			final MsgField bitField = fields.get(fieldKey);
			AssertUtils.notNull(bitField, TransReturnCode.code_9108, "无域:" + fieldKey);
			len += bitField.getOrigMsgLength();
		}
		// 重新赋值长度字节.
		msgLenByte = new byte[] { (byte) ((len & 0xff00) >>> 8), (byte) (len & 0xff) };

		return len;
	}

	/**
	 * @param msg unpack for Abc
	 */
	public int unpack4Abc(final byte[] msg) {
		if (ArrayUtils.isEmpty(msg)) {
			return 0;
		}

		// 解析每域获取的字节长度.
		int startPos = 0;

		// 取消息长度.
		startPos += parseMsgLen(msg);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取tpdu.
		startPos += MsgFieldType.TPDU.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取head.
		// startPos += MsgFieldType.HEAD.getParser().parse(fields, msg, startPos);
		// if (isEofMsg(msg, startPos)) {
		// return startPos;
		// }

		// 取msgtype.
		startPos += MsgFieldType.MSG_TYPE.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 取bitmap.
		startPos += MsgFieldType.BITMAP.getParser().parse(fields, msg, startPos);
		if (isEofMsg(msg, startPos)) {
			return startPos;
		}

		// 设置位图二进制.
		setBitmapBit();

		// 解析从第2域开始的各域.
		startPos += parseFieldsFrom2(msg, startPos);
		return startPos;
	}

	public Map<String, MsgField> getFields() {
		return fields;
	}

	public String getFieldContent61() {
		final MsgField field = getField(MsgFieldType.FIELD_61.getNo());
		if (field == null) {
			return null;
		}
		return field.getStringValue();
	}
}
