package com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util.LoUtils;
import com.lycheepay.clearing.adapter.banks.ccb.credit.kft.util.MacUtil;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AmountUtils;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.security.JDES;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 消息包工具.
 * 
 * @author aps-mhc
 */
public abstract class MsgPackUtils {
	/**
	 * 创建tpdu域.
	 */
	public static void createTpduField(final MsgPack msgPack, final byte[] b) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.TPDU;
		final MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(b);
		msgPack.put(field);
	}

	/**
	 * 创建head域.
	 */
	public static void createHeadField(final MsgPack msgPack, final byte[] b) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.HEAD;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(b);
		msgPack.put(field);
	}

	public static void resetMsgType(final MsgPack msgPack, final String newMsgType) {
		final MsgField field = msgPack.getField(MsgFieldType.MSG_TYPE.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
	}

	public static void createMsgType(final MsgPack msgPack, final String newMsgType) {
		final MsgFieldType fieldType = MsgFieldType.MSG_TYPE;
		final MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
		msgPack.put(field);
	}

	public static void createAccountField(final MsgPack msgPack, final String accountNo) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.FIELD_2;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		final int valueLen = accountNo.getBytes().length;
		final byte[] bcdAccountNo = ByteUtils.strToBcdLeftSide(accountNo);
		final byte[] bcdLen = ByteUtils.intToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bcdAccountNo));

		msgPack.putBitmapField(field);
	}

	/**
	 * 交易处理码.
	 * 
	 * @param msgPack
	 * @param tradeDealCode
	 */
	public static void createField3(final MsgPack msgPack, final String tradeDealCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_3;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(tradeDealCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 创建第4域交易金额
	 * 
	 * @param msgPack
	 * @param amount 交易金额, 单位:元
	 */
	public static void createField4(final MsgPack msgPack, final Double amount) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_4;

		final long cent = (long) AmountUtils.format(amount * 100);
		String strAmount = Long.toString(cent);
		strAmount = StringUtils.leftPad(strAmount, fieldType.getMaxLength() * 2, '0'); // 补足编码前12位长度.
		final MsgField field = MsgField.create(fieldType.getNo());
		// 设置bcd编码的交易金额.
		final byte[] bcdAmount = ByteUtils.strToBcd(strAmount);
		field.setOrigMsg(bcdAmount);
		msgPack.putBitmapField(field);
	}

	/**
	 * 重置第4域交易金额
	 * 
	 * @param msgPack
	 * @param amount 交易金额, 单位:元
	 */
	public static void resetField4(final MsgPack msgPack, final Double amount) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_4;

		final long cent = (long) AmountUtils.format(amount * 100);
		String strAmount = Long.toString(cent);
		strAmount = StringUtils.leftPad(strAmount, fieldType.getMaxLength() * 2, '0'); // 补足编码前12位长度.
		final MsgField field = msgPack.getField(fieldType.getNo());

		// 设置bcd编码的交易金额.
		final byte[] bcdAmount = ByteUtils.strToBcd(strAmount);
		field.setOrigMsg(bcdAmount);
	}

	/**
	 * 受卡方系统跟踪号.
	 * 
	 * @param msgPack
	 * @param trackeCode
	 */
	public static void createField11(final MsgPack msgPack, final String trackeCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_11;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(trackeCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 卡有效期
	 * 
	 * @param msgPack
	 * @param trackeCode
	 */
	public static void createField14(final MsgPack msgPack, final String effectiveDate) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_14;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(effectiveDate));
		msgPack.putBitmapField(field);
	}

	public static void createDefaultField12(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_12.getNo());
		final byte[] bcd = ByteUtils.strToBcd("000000");
		field.setOrigMsg(bcd);

		msgPack.putBitmapField(field);
	}

	public static void createDefaultField13(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_13.getNo());
		final byte[] bcd = ByteUtils.strToBcd("0000");
		field.setOrigMsg(bcd);

		msgPack.putBitmapField(field);
	}

	public static void createDefaultField15(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_15.getNo());
		final byte[] bcd = ByteUtils.strToBcd("0000");
		field.setOrigMsg(bcd);

		msgPack.putBitmapField(field);
	}

	/**
	 * 服务点输入方式码.
	 * 
	 * @param msgPack
	 * @param inputModeCode
	 */
	public static void createField22(final MsgPack msgPack, final String inputModeCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_22;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(inputModeCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 服务点条件码.
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField25(final MsgPack msgPack, final String conditionCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_25;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(conditionCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 服务点条件码.
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField25Abc(final MsgPack msgPack, final String conditionCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_25;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(conditionCode));
		msgPack.putBitmapField(field);
	}

	public static void createDefaultField32(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_32.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("01");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		msgPack.putBitmapField(field);
	}

	public static void createDefaultField37(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_37.getNo());
		field.setOrigMsg("000000000000".getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成37检索参考号,加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField37(final MsgPack msgPack, final String rspCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_37;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成38授权标识应答码, 请求时，同原预授权交易,加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField38(final MsgPack msgPack, final String rspCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_38;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成39应答码域, 加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField39(final MsgPack msgPack, final String rspCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_39;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡机终端标识码.
	 * 
	 * @param msgPack
	 * @param terminalCode
	 */
	public static void createField41(final MsgPack msgPack, final String terminalCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_41;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(terminalCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡方标识码.
	 * 
	 * @param msgPack
	 * @param merchantNo
	 */
	public static void createField42(final MsgPack msgPack, final String merchantNo) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_42;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(merchantNo.getBytes());
		msgPack.putBitmapField(field);
	}

	public static void createDefaultField44(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_44.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("01");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		msgPack.putBitmapField(field);
	}

	/**
	 * 交易货币代码.
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField49(final MsgPack msgPack, final String currencyCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_49;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(currencyCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 生成57自定义域, 加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField57(final MsgPack msgPack, final byte[] bytes) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_57;

		final MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		// 设置值.
		final int lenSize = field.getLenOfLeaderLength() * 2;
		final String lengthValue = StringUtils.leftPad(String.valueOf(bytes.length), lenSize, '0');
		final byte[] bcdLen = ByteUtils.strToBcd(lengthValue);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bytes));

		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域.
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField60(final MsgPack msgPack, final String customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_60;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(customValue));
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域.
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField60(final MsgPack msgPack, final byte[] customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_60;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue);
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域61:交易类型码+批次号
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField61(final MsgPack msgPack, final String customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_61;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域61:交易类型码+批次号
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField61(final MsgPack msgPack, final byte[] customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_61;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue);
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域:身份证ID或贷记卡（或准贷记卡）的3位校验位.
	 * 
	 * @param msgPack TODO
	 * @param customValue
	 */
	public static void createField62(final MsgPack msgPack, final byte[] bytes) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_62;

		final MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		// 设置值.
		final int lenSize = field.getLenOfLeaderLength() * 2;
		final String lengthValue = StringUtils.leftPad(String.valueOf(bytes.length), lenSize, '0');
		final byte[] bcdLen = ByteUtils.strToBcd(lengthValue);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bytes));

		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域:63
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField63(final MsgPack msgPack, final String customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_63;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域:63
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField63(final MsgPack msgPack, final byte[] bytes) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_63;

		final MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		// 设置值.
		final int lenSize = field.getLenOfLeaderLength() * 2;
		final String lengthValue = StringUtils.leftPad(String.valueOf(bytes.length), lenSize, '0');
		final byte[] bcdLen = ByteUtils.strToBcd(lengthValue);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bytes));

		msgPack.putBitmapField(field);
	}

	public static void createDefaultField63(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_63.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("0001");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		msgPack.putBitmapField(field);
	}

	/**
	 * MAC.
	 * 
	 * @param msgPack
	 * @param macValue
	 */
	public static void createField64(final MsgPack msgPack, final String macValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_64;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(macValue.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 计算mac.
	 * 
	 * @param msgPack
	 * @param posIdPrefix 终端标识前置,用于加密机中识别终端密钥数据
	 * @throws BizException
	 */
	public static void mac(final MsgPack msgPack, final String workKey) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.FIELD_64;
		MsgField macField = msgPack.getField(fieldType.getNo());

		// 创建mac域.
		if (macField == null) {
			macField = MsgField.create(fieldType.getNo());
			msgPack.putBitmapField(macField);
		}

		// 取删除mac域后的报文数据.
		final byte[] msg = msgPack.pack();
		final byte[] macData = ArrayUtils.subarray(msg, 13, msg.length); // 从第14个字节开始
		Log4jUtil.info("参与mac加密的数据为：{};workKey数据为：{}", LoUtils.byte2HexStr(macData), workKey);

		final String macStr = MacUtil.getMacDate(macData, workKey);
		final byte[] macbs = LoUtils.hexStr2Bytes(macStr);
		AssertUtils.isTrue(macbs != null && macbs.length == 8, TransReturnCode.code_9108, "消息校验错:" + macbs);
		// 设置值.
		macField.setOrigMsg(macbs);
		msgPack.putBitmapField(macField);
	}

	public static void resetTpduFrom(final MsgPack msgPack, final String from) throws BizException {
		if (StringUtils.isEmpty(from)) {
			return;
		}

		final Tpdu tpdu = msgPack.getTpdu();
		tpdu.setFrom(from);
		msgPack.setTpdu(tpdu);
	}

	public static void resetTpduTo(final MsgPack msgPack, final String to) throws BizException {
		if (StringUtils.isEmpty(to)) {
			return;
		}

		final Tpdu tpdu = msgPack.getTpdu();
		tpdu.setTo(to);
		msgPack.setTpdu(tpdu);
	}

	/**
	 * 复制源包中的域到目标包, 源包无指定域则不复制.
	 */
	public static void copyField(final MsgPack destPack, final MsgPack srcPack, final MsgFieldType fieldType) {
		final MsgField srcField = srcPack.getField(fieldType.getNo());

		if (srcField == null) {
			return;
		}

		final MsgField newField = srcField.clone();
		final int bitmapIndex = fieldType.getBitmapIndex();

		if (bitmapIndex >= 0) {
			destPack.putBitmapField(newField);
		} else {
			destPack.put(newField);
		}
	}

	/**
	 * 取终端zak密钥存到加密机中.
	 * 
	 * @throws BizException
	 */
	public static void saveKey(final MsgPack msgPack, final String posIdPrefix) throws BizException {
		final String posId = getPosId(msgPack, posIdPrefix);
		Log4jUtil.debug("posId:" + posId);

		final String[] keys = getKey(msgPack);
		Log4jUtil.debug("keys:" + ArrayUtils.toString(keys));

		if (keys == null || keys.length != 4) {
			Log4jUtil.debug("无key,不需保存");
			return;
		}

		// 保存zak.
		// TODO
		// int saveResult = new MpsMsgEncrypt().saveZAK(posId, keys[2], keys[3]);
		// //XXX Leon AssertisTrue(saveResult == 0, "密钥保存失败:" + saveResult);
	}

	private static String getPosId(final MsgPack msgPack, final String posIdPrefix) {
		MsgField field = msgPack.getField(MsgFieldType.FIELD_42.getNo());
		final String merchantNo = field.getStringValue();
		field = msgPack.getField(MsgFieldType.FIELD_41.getNo());
		final String terminalNo = field.getStringValue();

		return posIdPrefix + merchantNo + terminalNo;
	}

	/**
	 * 取终端密钥.
	 * 
	 * @param msgPack
	 * @return 0:ZPK, 1:ZPK校验值, 2:ZAK, 3:ZAK校验值
	 */
	public static String[] getKey(final MsgPack msgPack) {
		final MsgField field = msgPack.getField(MsgFieldType.FIELD_62.getNo());

		if (field == null) {
			return null;
		}

		final byte[] keyByte = field.getOrigValue();

		Log4jUtil.info("签到响应报文数据60域的ToStr:" + LoUtils.byte2HexStr(keyByte));
		Log4jUtil.info("签到响应报文数据60域的ToStr:" + LoUtils.byte2HexStr(keyByte));
		Log4jUtil.info("签到响应报文数据60域的ToStr:" + toHexString(keyByte, false));

		final int length = keyByte.length;
		final int[] FIELD_LEN = new int[] { 24, 40, 56 };

		// 错误的长度.
		if (!ArrayUtils.contains(FIELD_LEN, length)) {
			Log4jUtil.debug("密钥总长度错误:" + length);
			return null;
		}

		// 密钥长度为24,40,56时校验值长度都为4.
		// zpk和zak只取前8个字节.
		final int KEY_LEN = 8;
		final int CHECK_LEN = 4;
		final byte[] zpkByte = ArrayUtils.subarray(keyByte, 0, length / 2);
		final byte[] zpkKeyByte = ArrayUtils.subarray(zpkByte, 0, KEY_LEN);
		final byte[] zpkCheckByte = ArrayUtils.subarray(zpkByte, zpkByte.length - CHECK_LEN, zpkByte.length);

		final byte[] zakByte = ArrayUtils.subarray(keyByte, length / 2, length);
		final byte[] zakKeyByte = ArrayUtils.subarray(zakByte, 0, KEY_LEN);
		final byte[] zakCheckByte = ArrayUtils.subarray(zakByte, zakByte.length - CHECK_LEN, zakByte.length);

		return new String[] { toHexString(zpkKeyByte, false), toHexString(zpkCheckByte, false),
				toHexString(zakKeyByte, false), toHexString(zakCheckByte, false) };
	}

	public static String toHexString(final MsgPack msgPack) throws BizException {
		return toHexString(msgPack.getBytes());
	}

	public static String toHexString(final byte[] bytes) {
		final StringBuilder sb = new StringBuilder();

		for (final byte b : bytes) {
			final String hexByte = ByteUtils.toHexString(b & 0xff, 2);
			sb.append("[").append(hexByte.toUpperCase()).append("]");
		}
		return sb.toString();
	}

	public static String toHexString(final byte[] bytes, final boolean hasSeparator) {
		final StringBuilder sb = new StringBuilder();

		for (final byte b : bytes) {
			final String hexByte = ByteUtils.toHexString(b & 0xff, 2);

			if (hasSeparator) {
				sb.append("[");
			}

			sb.append(hexByte.toUpperCase());

			if (hasSeparator) {
				sb.append("]");
			}
		}
		return sb.toString();
	}

	/**
	 * POS终端采用ＥＣＢ的加密，加密消息类型（MTI）到63域之间的部分
	 * 
	 * @param msg 消息类型（MTI）到63域之间的部分
	 * @return
	 * @throws BizException
	 */
	public static byte[] macMsg(byte[] macData, final String pwdKey, final String workKey) throws BizException {
		try {
			final JDES jdes = new JDES();
			jdes.SetKey(LoUtils.hexStr2Bytes(workKey));// 明文密钥用于第64域生成
			// 填充到8的整数位.
			if (macData.length % 8 != 0) {
				macData = ArrayUtils.addAll(macData, new byte[8 - macData.length % 8]);
			}
			Log4jUtil.info("workKey：" + workKey);
			Log4jUtil.info("参与mac加密的数据：" + ByteUtils.bcdToStr(macData));
			final byte[] encyrData = jdes.doECBEncryptNoPadding(macData, macData.length);
			final byte[] macbs = ArrayUtils.subarray(encyrData, 0, 8);
			Log4jUtil.info("MAC：" + LoUtils.byte2HexStr(macbs));
			return macbs;
		} catch (final Exception e) {
			Log4jUtil.info("建行信用卡DES-ECB加密出错：" + e.getMessage());
			throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
		}
	}

	/**
	 * 
	 * @param msgPack
	 * @param msg
	 */
	public static void createField48(final MsgPack msgPack, final byte[] msg) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_48;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(msg);
		msgPack.putBitmapField(field);
	}

}
