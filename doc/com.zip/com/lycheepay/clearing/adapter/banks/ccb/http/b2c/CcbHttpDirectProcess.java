package com.lycheepay.clearing.adapter.banks.ccb.http.b2c;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;


/**
 * <P>建设银行HTTP(不区分B2B\B2C,后台直接交互)请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午4:16:53
 */
@Service(ClearingAdapterAnnotationName.CCB_HTTP_DIRECT_PROCESS)
public class CcbHttpDirectProcess extends BaseWithoutAuditLogService {

	// /**
	// * B2C批量退款、包括批量退款重发
	// *
	// * @param param
	// * @return ReturnState
	// * @throws BizException
	// */
	// private ReturnState batchRefund(Param param) throws BizException {
	// CreatBatchRefundFile creatBatchRefundFile = new CreatBatchRefundFile();
	// String fileNamePrefix = param.getChannelId();
	// ReturnState returnState = creatBatchRefundFile.batchRefund(param, fileNamePrefix, 4, "TXT",
	// 0);
	// return returnState;
	// }
}
