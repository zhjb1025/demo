/*******************************************************************************
 * Project Key : ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.credit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.SysparmConst;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ClearParamsService;
import com.lycheepay.clearing.adapter.common.util.SftpUtilByPass;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;


/**
 * <P>建设银行信用卡对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.CCB_CREDIT_RECONCILIATION_FILE_SERVICE)
public class CcbCreditReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CLEAR_PARAMS_SERVICE)
	private ClearParamsService sysParmService;

	/**
	 * <p>下载对账文件</p>
	 * 
	 * @param checkDate
	 * @return
	 * @author 张凯锋(13816608861)
	 * @param channelParam
	 * @throws ClearingAdapterBizCheckedException
	 */
	private String downloadCheckFile(final String channelId, final String workDate, Map<String, String> channelParam)
			throws ClearingAdapterBizCheckedException {
		final String sftpIp = channelParam.get("100016");
		final String sftpCertPsw = channelParam.get("100017");
		final String sftpUser = channelParam.get("100018");
		final String sftpPath = channelParam.get("100019");
		final String keyFile = channelParam.get("100020"); // id_rsa 文件路径
		final String filePrefix = channelParam.get("100021"); // 文件前缀
		final String fileSuffix = channelParam.get("100022"); // 文件后缀

		Assert.notNull(sftpIp, "sftp服务器sftpIp不能为空");
		Assert.notNull(sftpCertPsw, "sftp客户端sftpCertPsw不能为空");
		Assert.notNull(sftpUser, "sftp服务器sftpUser不能为空");
		Assert.notNull(sftpPath, "sftp服务器sftpPath不能为空");
		Assert.notNull(keyFile, "sftp客户端keyFile不能为空");
		Assert.notNull(filePrefix, "对账文件的前缀不能为空");
		Assert.notNull(fileSuffix, "对账文件的后缀不能为空");

		String s = "";
		try {
			// 对账文件命名为今天，但是文件内容为昨天的
			s = DateUtil.getDate(DateUtil.addDays(DateUtil.getDate(workDate, "yyyyMMdd"), 1));
		} catch (final Exception e) {
			Log4jUtil.error(e);
		}

		final String fileName = filePrefix + s + fileSuffix;
		// String fileName = filePrefix + workDate + fileSuffix;
		Log4jUtil.info("请求下载的对账文件名为：" + fileName);

		final String accPath = sysParmService.getParmValue(SysparmConst.CHANNEL_RECON_FILE_DIR) + "accPath" + channelId + File.separator;
		final SftpUtilByPass sf = new SftpUtilByPass(sftpIp, sftpUser, keyFile, sftpCertPsw, 22);
		final ChannelSftp sftp = sf.connectByKeyFile();
		sf.download(sftpPath, fileName, accPath + fileName, sftp);
		sf.disconnect(sftp);

		return accPath + fileName;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CCB", "check");
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);
		final Map<String, String> channelParam = channelParmService.queryCodeParamsMapByChannelId(channelId);
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try{
			final String fileFullPathName = downloadCheckFile(channelId, queryDate, channelParam);
			Log4jUtil.info(logPrefix + "下载对账文件完成,路径为：" + fileFullPathName);
	
			reconciliationFileDTOList = buildTransactionDataList(channelId, queryDate,
					fileFullPathName, channelParam.get("100006"));
			
			Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		}catch(Exception e){
			Log4jUtil.error(e);
		}
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param channelId 渠道ID
	 * @param reconciliationDate 对账日期
	 * @param billnoSnList 文件保存路径
	 * @author 李斌(13665100450)
	 * @param string
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String channelId,
			final String reconciliationDate, final String fileFullPathName, String merChantNo)
			throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		Assert.notNull(merChantNo, "建行信用卡对账请求中商户号不能为空!");
		// 对账
		int currLine = 0;
		BufferedReader in = null;
		InputStreamReader reader = null;
		String errMsg = "";
		try {
			reader = new InputStreamReader(new FileInputStream(fileFullPathName), Charset.forName("GBK"));
			in = new BufferedReader(reader);
			// in.readLine(); // 跳过第一行汇总中文描述
			String data = null;

			String checkDate = "";
			String mechantName = "";
			String tradeDate = "";
			String amtTrade = "";
			String bankRecvSn = "";
			String bankSendSn = "";
			String batchno = "";

			/**
			 * 预取库中待对账的消费记录
			 */
			Map<String, String> awaitBillMap = this.queryAwaitCheckRecode(channelId, reconciliationDate,
					ClearingTransType.REAL_TIME_DEDUCT);
			/**
			 * 预取库中待对账的退款记录
			 */
			Map<String, String> awaitRefundBillMap = this.queryAwaitCheckRecode(channelId, reconciliationDate,
					ClearingTransType.AUTO_REAL_TIME_REFUND);
			Date theDayBeforyesterday,nextDay ;
			try {
				theDayBeforyesterday = DateUtil.addDays(DateUtil.getDate(reconciliationDate, "yyyyMMdd"), -1);
				nextDay = DateUtil.addDays(DateUtil.getDate(reconciliationDate, "yyyyMMdd"), 1);
			} catch (Exception e) {
				theDayBeforyesterday = DateUtil.addDays(new Date(), -2);nextDay=new Date();
				Log4jUtil.error("format出错", e);
			}// 前天，缩小查询范围
			
			String startCheckDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(theDayBeforyesterday);
			String endCheckDate = new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(nextDay);
			while ((data = in.readLine()) != null) {
				// 空行跳过
				if (287 < data.getBytes(Charset.forName("GBK")).length) {
					currLine++; // 行循环
					checkDate = new String(data.getBytes(Charset.forName("GBK")), 40, 10).trim();// 结算日期
																									// //
																									// old--
																									// 40,
																									// 8
					mechantName = new String(data.getBytes(Charset.forName("GBK")), 138, 15).trim();// 商户编号
																									// //old--
																									// 134
					tradeDate = new String(data.getBytes(Charset.forName("GBK")), 315, 10).trim();// 交易日期
																									// //old
																									// --232,
																									// 8
					amtTrade = new String(data.getBytes(Charset.forName("GBK")), 220, 14).trim();// 交易金额
																									// //old
																									// --207,
																									// 8
					bankRecvSn = new String(data.getBytes(Charset.forName("GBK")), 287, 7).trim();// 发往银行的序列
																									// //old
																									// --
																									// 249,
																									// 9
					// bankRecvSn = new String(data.getBytes(), 325, 6).trim();// 发往银行的序列 //old --
					// 249, 9
					batchno = new String(data.getBytes(Charset.forName("GBK")), 294, 7).trim();// pos批次

					if (StringUtil.isBlank(bankRecvSn)) {
						errMsg = "明细的第" + currLine + "的信息存疑: 交易序列号为空，有可能是平台外退款,请人工核实!";
						Log4jUtil.info("对账明细" + errMsg);
						continue;
					}

					if (bankRecvSn == null || bankRecvSn.length() != 6) {
						errMsg = errMsg + "明细的第" + currLine + "的信息有误: 对账文件中的pos交易授权号应为6位序列";
						throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED,
								errMsg);
					}

					if (!merChantNo.equals(mechantName)) {
						errMsg = errMsg + "明细的第" + currLine + "的信息有误: 商户号不一致，快付通的建行信用卡商户号为[" + merChantNo + "],明细["
								+ mechantName + "] \n";
						throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED,
								errMsg);
					}

					if (!reconciliationDate.equals(tradeDate)) {
						errMsg = errMsg + "明细的第" + currLine + "的信息有误: 交易日期不一致，要求对账的交易日期[" + reconciliationDate
								+ "],明细[" + tradeDate + "] \n";
						throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED,
								errMsg);
					}

					// 过滤为负数的交易
					if (!MoneyUtil.isValidMoney(amtTrade)) {
						errMsg = errMsg + "明细的第" + currLine + "的交易金额信息有误:" + amtTrade + "] \n";
						throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED,
								errMsg);
					}

					final Double d = new Double(Double.parseDouble(amtTrade));
					final ReconciliationFileDTO accBean = new ReconciliationFileDTO();
					if (d < 0) {
						// 先从预取库中待对账的退款记录取值，取不到得再单独读取数据库
						if (awaitRefundBillMap.containsKey(bankRecvSn)) {
							bankSendSn = awaitRefundBillMap.get(bankRecvSn);
						} else {
							// 通过bankRecvSn来查询渠道发往银行端的流水号
							bankSendSn = billnoSnService.findByBankRecvSnAndCreditbatchno(channelId, bankRecvSn,
									FormatTransfer.setLStrFormat(batchno, 6), startCheckDate,endCheckDate,
									ClearingTransType.AUTO_REAL_TIME_REFUND);
						}
						// Edit By:Leon.Qiu 2012-10-22 需要区分PayGet 1.消费为deduct 为正值get;2.退货、消费撤销为负值
						// pay; 需要納入對賬
						accBean.setPayGet(STR_PAY);
						accBean.setAmount(new BigDecimal(new String(amtTrade)).negate());// 交易金额
					} else {
						// 先从预取库中待对账的消费记录取值，取不到得再单独读取数据库
						if (awaitBillMap.containsKey(bankRecvSn)) {
							bankSendSn = awaitBillMap.get(bankRecvSn);
						} else {
							// 通过bankRecvSn来查询渠道发往银行端的流水号
							bankSendSn = billnoSnService.findByBankRecvSnAndCreditbatchno(channelId, bankRecvSn,
									FormatTransfer.setLStrFormat(batchno, 6), startCheckDate,endCheckDate,
									ClearingTransType.REAL_TIME_DEDUCT);
						}

						accBean.setPayGet(STR_GET);
						accBean.setAmount(new BigDecimal(amtTrade));// 交易金额
					}

					if (bankSendSn == null) {
						accBean.setBankSendId("xxx" + currLine); // 渠道发往银行流水号
					} else {
						accBean.setBankSendId(bankSendSn); // 渠道发往银行流水号
					}

					accBean.setCheckDate(reconciliationDate);// 结算日期
					accBean.setBankRecvSN(bankRecvSn); // pos中心返回的流水号
					accBean.setTransDate(tradeDate); // 交易日期
					accBean.setBankTransState("00");
					accBean.setChannelId(channelId);

					Log4jUtil.info("--建行信用卡--AccBean信息为:授权序列号bankRecvSn [" + accBean.getBankRecvSN() + "]bankSendSn["
							+ accBean.getBankSendId() + "]tradeAmount[" + accBean.getAmount() + "]TranDate["
							+ accBean.getTransDate() + "]CheckDate[" + accBean.getCheckDate() + "]BankTradestate["
							+ accBean.getBankTransState() + "]");
					reconciliationFileDTOList.add(accBean);
				}
			}

		} catch (final FileNotFoundException e) {
			Log4jUtil.error("指定建行信用卡对账文件不存在!请检查此文件:[" + fileFullPathName + "]是否存在?", e);
			throw new ClearingAdapterBizCheckedException(BusinessCode.FILE_NOT_FOUND, "指定建行信用卡对账文件不存在!请检查此文件:["
					+ fileFullPathName + "]是否存在?");
		} catch (final IOException e) {
			Log4jUtil.error("IOException", e);
		} finally {
			IOUtils.closeQuietly(in);
			IOUtils.closeQuietly(reader);
		}
		Log4jUtil.error("对账明细" + errMsg);
		return reconciliationFileDTOList;
	}


	/**
	 * 
	 * <p>预取库中待对账的消费记录 ，组装在map中 (key:BankRecvSn , value:BankSendSn)</p>
	 * 
	 * 建行查询（ checkDate 的上一天 21:00:00 到checkDate 这天的 23:59:59里的数据 ）
	 * 
	 * @param checkDate
	 * @return
	 * @author 汤兴友 xytang
	 * @throws ClearingAdapterBizCheckedException
	 */
	private Map<String, String> queryAwaitCheckRecode(String channelId, String checkDate, String trantype)
			throws ClearingAdapterBizCheckedException {
		String startTime = null;
		String endTime = null;
		try {
			Date yesterday = DateUtil.addDays(DateUtil.getDate(checkDate, "yyyyMMdd"), -1);
			String yesdayFormat = DateUtil.getDate(yesterday);

			startTime = yesdayFormat + " 21:00:00";
			endTime = checkDate + " 23:59:59";
		} catch (Exception e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.TRANSACTION_QUERY_FAILED, e.getMessage());
		}

		Log4jUtil.info("开始预取库中建行信用卡待对账的记录，开始时间【{}】,结束时间【{}】,交易类型【{}】,交易状态【{}】", startTime, endTime, trantype, "02");

		final List<BillnoSn> awaitBills = billnoSnService.selectBillByChannelIdAndDatetimeAndTranTypeAndState(
				channelId, startTime, endTime, ClearingTransType.REAL_TIME_DEDUCT, "02");

		Log4jUtil.info("待对账的记录读取结束,总共{}条记录", awaitBills.size());

		final Map<String, String> billMap = new HashMap<String, String>(awaitBills.size());

		/**
		 * (key:BankRecvSn , value:BankSendSn)
		 */
		String key = "", msg = "";
		for (final BillnoSn billnosn : awaitBills) {
			key = billnosn.getBankRecvSn();
			if (StringUtils.length(key) < 19) {
				Log4jUtil.info("渠道流水sn:{}的记录recvSn：{} 的长度小于19，属于异常的记录", billnosn.getSn(), billnosn.getBankRecvSn());
				continue;
			}

			if (billMap.containsKey(key)) {
				msg = StringUtil.r("渠道流水表中同一交易类型交易序号{?}重复！属于异常的记录，请人工处理！", key);
				throw new ClearingAdapterBizCheckedException(BusinessCode.TRANSACTION_QUERY_FAILED, msg);
			}

			billMap.put(StringUtils.substring(key, 13, 19), billnosn.getBankSendSn());
		}
		return billMap;
	}


	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CCB", "check");
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final Map<String, String> channelParam = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(channelId, queryDate,
				targetFilePath, channelParam.get("100006"));
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}
}
