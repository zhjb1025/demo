//package com.lycheepay.clearing.adapter.banks.ccb.corp;
//
//import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util.CcbCorpProcessXmlService;
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelSettleCmd;
//import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
//
//
///**
// * 建行银企批量代收付处理（CMP021)
// * 
// * @author aps-lfm
// * 
// */
//public class CorpCcbCMP021Service {
//	@SuppressWarnings("unused")
//	private static ChannelSettleCmdDao channelSettleCmdDao = (ChannelSettleCmdDao) SpringContext
//			.getService("channelSettleCmdDao");
//
//	/**
//	 * 批量代收代付6W2100
//	 * 
//	 * @param param
//	 * @param batchId 渠道发送批次
//	 * @param batchFileName 批量发送文件名
//	 * @throws BizException
//	 */
//	public String deal6W2100(final Param param, final String batchId, final String batchFileName) throws BizException {
//		final CcbCorpProcessXmlService comProcessXml = new CcbCorpProcessXmlService();
//		// 不是重发，则根据支付场次、渠道号、交易类型在渠道批次表中查找是否已经有记录
//		if (param.getRepeatFlag().equals("Y") == false) {
//			ReturnState returnState = new ReturnState();
//			returnState = comProcessXml.batchFront(param);
//			if (returnState.getReturnState().equals("S")) {
//				throw new BizException("渠道批次表(channel_batch)中,根据支付场次、渠道编号、交易类型在渠道批次表中查找是否已经有该批次记录");
//			}
//		}
//		// 创建请求
//		final String sendXml = comProcessXml.create6W2100XML(param, batchId, batchFileName);
//		// 不是重发，则更新渠道清算记录状态为“处理成功”
//		if (param.getRepeatFlag().equals("Y") == false) {
//			final String netNo = (String) param.getBizBean();// 支付场次
//			final ChannelSettleCmd channelSettleCmd = (ChannelSettleCmd) channelSettleCmdDao.getChannelSettleCmd(netNo,
//					param.getChannelId(), param.getTransType());
//			if (channelSettleCmd != null) {
//				channelSettleCmd.setState(ChannelSettleCmdState.sucPro);
//				channelSettleCmd.setRemark("处理成功");
//				channelSettleCmdDao.update(channelSettleCmd);
//			}
//		}
//		return sendXml;
//	}
//
//	/**
//	 * 处理批量代收代付6W2100回执
//	 * 
//	 * @param param 调用传递
//	 * @param respXml 银行返回报文
//	 * @param batchId 渠道发送批次
//	 * @return 处理结果
//	 * @throws BizException
//	 */
//	public ReturnState parse6W2100(final Param param, final String respXml, final String batchId) throws BizException {
//		final CcbCorpProcessXmlService comProcessXml = new CcbCorpProcessXmlService();
//		return comProcessXml.parse6W2100XML(respXml, param, batchId);
//
//	}
// }
