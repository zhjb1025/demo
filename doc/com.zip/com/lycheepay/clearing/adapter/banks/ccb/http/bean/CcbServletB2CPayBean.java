package com.lycheepay.clearing.adapter.banks.ccb.http.bean;

public class CcbServletB2CPayBean {
	String posid = "";
	String branchid = "";
	String orderid = "";
	String payment = "";
	String curcode = "";
	String remark1 = "";
	String remark2 = "";
	String acc_type = "";
	String success = "";
	String sign = "";
	String accDate = "";// 回执的记账日期

	public String getPosid() {
		return posid;
	}

	public void setPosid(final String posid) {
		this.posid = posid;
	}

	public String getBranchid() {
		return branchid;
	}

	public void setBranchid(final String branchid) {
		this.branchid = branchid;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(final String orderid) {
		this.orderid = orderid;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(final String payment) {
		this.payment = payment;
	}

	public String getCurcode() {
		return curcode;
	}

	public void setCurcode(final String curcode) {
		this.curcode = curcode;
	}

	public String getRemark1() {
		return remark1;
	}

	public void setRemark1(final String remark1) {
		this.remark1 = remark1;
	}

	public String getRemark2() {
		return remark2;
	}

	public void setRemark2(final String remark2) {
		this.remark2 = remark2;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(final String acc_type) {
		this.acc_type = acc_type;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(final String success) {
		this.success = success;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(final String sign) {
		this.sign = sign;
	}

	public String getAccDate() {
		return accDate;
	}

	public void setAccDate(final String accDate) {
		this.accDate = accDate;
	}
}
