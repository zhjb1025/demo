/*******************************************************************************
 * Project Key : ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.corp;

import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util.CcbCorpProcessXmlService;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行银企对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.CCB_CORP_RECONCILIATION_FILE_SERVICE)
public class CcbCorpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CORP_PROCESS_XML_SERVICE)
	private CcbCorpProcessXmlService ccbCorpProcessXmlService;

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CCB", "check");
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try{
			final List<BillnoSn> billnoSnList = billnoSnService.findBillnoSnBySendTime(channelId, queryDate);
			Log4jUtil.info("建行银企自动对账查询流水表billnoSn记录数为" + String.valueOf(billnoSnList.size()));

			reconciliationFileDTOList = buildTransactionDataList(billnoSnList, channelId,
					queryDate);

			Log4jUtil.info("招商对账处理类[按结帐日查询已结帐定单]结束,单笔对账处理bean总共有:" + reconciliationFileDTOList.size() + "条.");

			Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		}catch(Exception e){
			Log4jUtil.error(e);
		}

		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param billnoSnList 对账数据信息
	 * @param channelId 渠道ID
	 * @param reconciliationDate 对账日期
	 * @author 李斌(13665100450)
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final List<BillnoSn> billnoSnList,
			final String channelId, final String reconciliationDate) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		// 循环查询交易结果并生成对账beanList
		int i;
		final int j = billnoSnList.size();
		String respXml = "";
		for (i = 0; i < j; i++) {
			try {
				respXml = ccbCorpProcessXmlService.sendXML(create6W1503XML(billnoSnList.get(i).getBankSendSn()));
			} catch (final BizException e) {
				throw new ClearingAdapterBizCheckedException(BusinessCode.TRANSACTION_QUERY_FAILED, "发送对账查询报文失败", e);
			}// 发送请求，查询单笔交易状态
			Log4jUtil.info("建行银企通过单笔交易查询对账返回respXml====" + respXml);
			final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respXml.getBytes(Charset.forName("GBK")));// 解析应答报文
			final Node nodeRoot = dom4jxml.getNode("/TX");
			if (dom4jxml.getNodeText(nodeRoot, "RETURN_CODE").equals("000000")) {// 查询成功
				// 获取TX节点的数据,组accbean添加到List
				final Node nodeItem = dom4jxml.getNode("/TX/TX_INFO");
				final ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
				reconciliationFileDTO.setTransDate(DateUtil.getDate(billnoSnList.get(i).getSendTime()));// 交易日期
				reconciliationFileDTO.setCheckDate(reconciliationDate);// 对账日期
				reconciliationFileDTO.setBankSendId(billnoSnList.get(i).getBankSendSn());	// 订单号
				final String amtTrade = String.format("%1$.2f", billnoSnList.get(i).getAmount());// 交易金额
				reconciliationFileDTO.setAmount(new BigDecimal(amtTrade));
				final String dealResult = dom4jxml.getNodeText(nodeItem, "DEAL_RESULT"); // 交易处理结果"3：失败 4：成功；6：不确定"
				if (dealResult.equals("4")) {
					reconciliationFileDTO.setBankTransState("00");// 交易状态 00-支付成功；01-支付失败；02-超时
				} else {
					reconciliationFileDTO.setBankTransState("01");
				}
				reconciliationFileDTO.setPayGet(getPayGet(billnoSnList.get(i).getTranType()));
				reconciliationFileDTO.setChannelId(channelId);
				reconciliationFileDTOList.add(reconciliationFileDTO);
			} else {
				Log4jUtil.info("建行银企对账查询交易流水：" + billnoSnList.get(i).getBankSendSn() + "的交易结果失败");
			}
		}
		return reconciliationFileDTOList;
	}

	/**
	 * <p>判断收付状态</p>
	 * 
	 * @param tranType 交易类型
	 * @return 收/付
	 * @author 李斌(13665100450)
	 */
	private String getPayGet(final String tranType) {
		String payGet;
		// 收款交易
		if (tranType.equals(ClearingTransType.REAL_TIME_PAY) || tranType.equals(ClearingTransType.BATCH_PAY)) {
			payGet = STR_PAY;
		} else {
			payGet = STR_GET;
		}
		return payGet;
	}

	/**
	 * 创建建行建行外联平台单笔交易查询(6W1503)请求xml报文
	 * 
	 * @param param
	 */
	private String create6W1503XML(final String bankSendSn) {
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GB2312");
		// 创建根节点TX
		final Element apElement = document.addElement("TX");
		// 创建公共头信息
		ccbCorpProcessXmlService.createHeadXml(apElement, "6W1503", bankSendSn);
		// 创建交易数据信息
		final Element CorpElement = apElement.addElement("TX_INFO");
		final Element REQUEST_SN1 = CorpElement.addElement("REQUEST_SN1");// 原交易流水号
		REQUEST_SN1.setText(bankSendSn);
		// 生成xml字符串
		return document.asXML();
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

}
