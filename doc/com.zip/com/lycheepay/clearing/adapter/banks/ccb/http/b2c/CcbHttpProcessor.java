package com.lycheepay.clearing.adapter.banks.ccb.http.b2c;

import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.http.CcbUtil;
import com.lycheepay.clearing.adapter.banks.ccb.http.bean.CcbB2CAccountVerifyBean;
import com.lycheepay.clearing.adapter.banks.ccb.http.bean.CcbPayBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.common.constant.AccountType;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


/**
 * <P>建设银行网银HTTP(不区分B2B\B2C)请求处理器</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午3:34:14
 */
@Service(ClearingAdapterAnnotationName.CCB_HTTP_PROCESSOR)
public class CcbHttpProcessor extends BaseWithoutAuditLogService {

	// 清算交易记录
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	// 渠道参数
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	private final static String channelId = ChannelIdEnum.CCB_INTERNET.getCode();

	/**
	 * <p>网银代扣(不区分B2C/B2B)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午3:42:00
	 */
	public HttpReturnParam onlineDeduct(final HttpParam httpParam) throws BizException {
		final Map<String, String> channelParam = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String logPrefix = httpParam.getChannelId() + ChannelId.getNameByValue(httpParam.getChannelId());
		String logMsg = "进入 " + logPrefix + " 渠道Http业务处理。";
		Log4jUtil.info(logMsg);
		if (channelParam == null) {
			throw new BizException("无法获取 " + logPrefix + " 渠道参数配置。");
		}
		return pay(logPrefix, httpParam, channelParam);// 支付或担保支付、充值
	}

	/**
	 * <p>网银支付</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午3:42:41
	 */
	private HttpReturnParam pay(String logPrefix, final HttpParam httpParam, Map<String, String> channelParam)
			throws BizException {
		if (httpParam.getCustomerType() == null) {
			throw new BizException("支付类型为空。");
		}
		if (AccountType.COMPANY.equals(httpParam.getCustomerType())) {
			logPrefix = logPrefix + "B2B";
		} else {
			logPrefix = logPrefix + "B2C";
		}
		String logMsg = "进入 " + logPrefix + " 支付业务处理。";
		Log4jUtil.info(logMsg);
		final CcbUtil ccbUtil = new CcbUtil();
		channelParam = ccbUtil.checkChannelParam(logPrefix, ClearingTransType.NET_DEDUCT, channelParam);
		final String merchantid = channelParam.get("100013");
		final CcbPayBean ccbPayBean = ccbUtil.createCcbPayBean(logPrefix, merchantid, httpParam, channelParam,
				sequenceManagerService.getCcbChannelSN(DateUtil.getCurrentDate()));
		final HttpReturnParam hrp = ccbUtil.getPayHttpReturnParam(ccbPayBean);
		billnoSnService.save(logPrefix, ccbPayBean.getOrderid(), httpParam);
		logMsg = logPrefix + "向银行发起支付请求。流水号为：" + ccbPayBean.getSn() + "订单号为：" + ccbPayBean.getOrderid();
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, hrp);
		return hrp;
	}

	/**
	 * <p>网银账户验证(不区分B2B\B2C)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午4:11:14
	 */
	public HttpReturnParam onlineAccountVerify(final HttpParam httpParam) throws BizException {
		final String logPrefix = httpParam.getChannelId() + ChannelId.getNameByValue(httpParam.getChannelId());
		final String logMsg = "进入 " + logPrefix + " 渠道Http业务处理。";
		Log4jUtil.info(logMsg);
		final Map<String, String> channelParam = channelParmService.queryCodeParamsMapByChannelId(channelId);
		return accountVerify(logPrefix, httpParam, channelParam);
	}

	/**
	 * <p>帐户验证</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午4:12:32
	 */
	private HttpReturnParam accountVerify(final String logPrefix, final HttpParam httpParam,
			final Map<String, String> channelParam) throws BizException {
		String logMsg = "进入" + logPrefix + " 账户验证业务处理。";
		Log4jUtil.info(logMsg);
		final CcbUtil ccbUtil = new CcbUtil();
		final String merId = channelParam.get("100013");
		if (merId == null || merId.length() < 1) {
			throw new BizException(logPrefix + "根据支付渠道获取的商户代码非法；");
		}
		final CcbB2CAccountVerifyBean ccbB2CAccountVerifyBean = ccbUtil.createAccountBean(logPrefix, merId, httpParam,
				channelParam);
		if (ccbB2CAccountVerifyBean == null) {
			throw new BizException(logPrefix + "生成账户验证对象为NULL。处理中止。");
		}
		final HttpReturnParam hrp = ccbUtil.getAccountVerifyHttpReturnParam(ccbB2CAccountVerifyBean);
		logMsg = logPrefix + " 导向账户验证页面。";
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, hrp);
		return hrp;
	}

}
