package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.processor;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.BatchBean;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.BatchNoticeBean;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.CryptorJKS;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.constant.biz.Status;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.adapter.common.util.security.Base64;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.AmountUtils;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;
import com.lycheepay.clearing.util.StringUtil;


/**
 * 
 * <P>信用卡还款服务实现类</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.CCB_REPAY_SERVICE)
public class CcbRepayService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_REPAY_MSGDEAL)
	private final CcbRepayMsgDeal ccbRepayMsgDeal = new CcbRepayMsgDeal();

	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;

	public final static String channelId = ChannelIdEnum.CCB_CREDIT_REPAY.getCode();

	private final String line = System.getProperty("line.separator"); // 回车换行符

	// private Map<String, String> channelParms = new Map<String,
	// String>();

	private final String dot = ","; // 分隔符

	/**
	 * 
	 * @param trantype
	 * @param bizObjectList
	 * @param channelBatchid
	 * @return
	 * @throws BizException
	 */
	public BatchBean sendBatch(final String trantype, final List<?> bizObjectList, final String channelBatchid)
			throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String limitNum = channelParms.get("100010");

		// 取得平台的账户信息
		final BankaccountBalance acc = bankAccountBalanceService.getBankaccountBean(channelId);
		AssertUtils.notNull(acc, TransReturnCode.code_9108, "建行信用卡还款取得平台的账户信息失败！channelBankAccount的交易类型为：" + trantype);
		final String CorpAcctNo = acc.getAccountNo();
		final String CorpAcctName = acc.getAccountName();
		final String CorpBankNo = acc.getBankNo();

		// 拆分的文件数
		final int maxNum = Integer.parseInt(limitNum);
		final int bizListSize = bizObjectList.size();
		final int fileNum = (int) Math.ceil((double) bizListSize / maxNum);
		List<?> bizList = null;
		String batchFileName = "";
		BatchNoticeBean b = null;

		// 本批次的汇总实体类
		final BatchBean batchBean = new BatchBean();
		batchBean.setTrantype(trantype); // 类型
		batchBean.setChannelBatchNo(channelBatchid); // 批次
		batchBean.setSubFileNum(fileNum); // 子文件数目

		final List<BatchNoticeBean> beans = new ArrayList<BatchNoticeBean>();

		// 循环要用到的临时变量
		int totalNum = 0; // 本批次的代付笔数
		double totalAmt = 0.0; // 本批次的代付总金额

		final String payDate = DateUtil.getCurrentDate();
		final String payTime = DateUtil.getTime1(new Date());

		// 循环的处理
		for (int i = 0; i < fileNum; i++) {
			final String fileNumStr = FormatTransfer.setLStrFormat(String.valueOf(i + 1), 3);

			b = new BatchNoticeBean(payDate, payTime);
			b.setFileNumber(fileNumStr);
			b.setFileName(ccbRepayMsgDeal.createFileName("CreditRepay", payDate, channelBatchid, fileNumStr));

			bizList = bizObjectList
					.subList(i * maxNum, (i + 1) * maxNum > bizListSize ? bizListSize : (i + 1) * maxNum);
			batchFileName = b.getFileName();

			// 生成批量子文件，保存记录到 billnoSn表。
			b = this.createFtpSend(b, channelBatchid, trantype, bizList, batchFileName, fileNumStr, CorpAcctNo,
					CorpAcctName, CorpBankNo); // 返回值为 "总记录数|总金额"

			// 统计子文件的代付笔数和总金额
			totalNum += b.getTotalNum();
			totalAmt += b.getTotalAmt();

			beans.add(b); // 用于汇总
		}

		// 更新本批次的汇总的实体类
		batchBean.setTotalNum(totalNum); // 代付笔数
		batchBean.setTotalAmt(totalAmt); // 代付总金额
		batchBean.setPayDate(payDate);
		batchBean.setPayTime(DateUtil.getTime1(new Date()));

		// 预装载数据，供后续使用
		batchBean.setBeans(beans);
		batchBean.setSummaryFile(ccbRepayMsgDeal.createFileName("RepayTotal", payDate, channelBatchid, null));

		/**
		 * 生成批量汇总文件
		 */
		this.createSummaryFile(batchBean);

		// 子文件上传到服务器
		for (final BatchNoticeBean be : beans) {
			ccbRepayMsgDeal.uploadFileToSftp(be.getFileName());
		}
		// 汇总文件上传到ftp
		ccbRepayMsgDeal.uploadFileToSftp(batchBean.getSummaryFile());

		/**
		 * 签到(公钥同步)
		 */
		ReturnState keyApplyRs = this.dealKeyApply();
		if (!keyApplyRs.getChannelCode().equals(TransReturnCode.code_0000)) {
			throw new BizException(TransReturnCode.code_9108, "建行信用卡还款(签到)Dck密钥同步失败!");
		}
		// 汇总文件数也计算在内
		batchBean.setSubFileNum(batchBean.getSubFileNum() + 1);

		/**
		 * 信用卡还款批量授权入账接口
		 */
		final ReturnState noticeRs = this.sendBatchNotice(batchBean);

		final ReturnState rs = new ReturnState();
		rs.setReturnState(Status.SUCC);
		rs.setReturnState(noticeRs.getReturnState());
		rs.setChannelCode(noticeRs.getChannelCode());

		batchBean.setReturnState(rs);

		return batchBean;
	}

	/**
	 * 信用卡还款批量授权入账接口
	 * 
	 * @param batchBean
	 * @return
	 * @throws BizException
	 */
	private ReturnState sendBatchNotice(final BatchBean batchBean) throws BizException {
		return ccbRepayMsgDeal.sendBatchTrasNotice(batchBean);
	}

	/**
	 * 
	 * @param batchBean
	 * @param beans
	 * @throws BizException
	 */
	private void createSummaryFile(final BatchBean batchBean) throws BizException {

		// 装载数据
		final List<BatchNoticeBean> beans = batchBean.getBeans();
		final String summaryFile = batchBean.getSummaryFile();
		final String channelBatchNo = batchBean.getChannelBatchNo();

		String fileStr;// 保存文件内容
		Double dAmtTotal = 0.0;

		final StringBuffer sbContent = new StringBuffer("");// 临时内容变量

		BatchNoticeBean bean = null;
		for (int i = 0; i < beans.size(); i++) {
			bean = beans.get(i);
			dAmtTotal = dAmtTotal + bean.getTotalAmt();

			// 明细记录
			sbContent.append("D").append(dot)// 记录类型
					.append(channelBatchNo).append(dot)// 付款批次
					.append(bean.getFileNumber()).append(dot)// 文件序号
					.append(MoneyUtil.getFenString(BigDecimal.valueOf(bean.getTotalAmt()))).append(dot)// 付款金额
					.append(bean.getTotalNum())// 付款笔数
					.append(line);
		}

		// 汇总记录
		sbContent.append("T").append(dot)// 记录类型
				.append(channelBatchNo).append(dot)// 付款批次
				.append(batchBean.getSubFileNum()).append(dot)// 子文件数
				.append(MoneyUtil.getFenString(BigDecimal.valueOf(batchBean.getTotalAmt()))).append(dot)// 付款总金额
				.append(batchBean.getTotalNum()).append(dot)// 付款总笔数
				.append("RMB").append(dot)// 付款总笔数
				.append(batchBean.getPayDate()).append(dot)// 汇总生成日期
				.append(batchBean.getPayTime()).append(dot)// 汇总生成时间
				.append(batchBean.getDes()).append(dot)// 描述
				.append(batchBean.getNote());// 备注
		// .append(line);

		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String operator = channelParms.get("100009");

		// 签名记录
		final StringBuffer signData = new StringBuffer();
		signData.append("S").append(dot)// 记录类型
				.append(DateUtil.getCurrentDate()).append(dot)// 签名日期
				.append(DateUtil.getTime(new Date())).append(dot)// 签名时间
				.append(System.currentTimeMillis()).append(dot)// 签名时间戳
				.append(operator).append(dot)// 操作者
				.append(this.enCrypt(sbContent.toString() + line));// 签名
		// .append(line);

		// 明细记录文件
		fileStr = sbContent.append(line).append(signData).toString();

		Log4jUtil.info("批量业务的汇总文件内容:");
		Log4jUtil.info(fileStr);

		try {
			Log4jUtil.info("汇总文件文件名:" + summaryFile);
			// CreateAccFile方法生成文件，返回文件名(含上级文件夹)，返回参数这里用不着
			ccbRepayMsgDeal.createBatchFile(summaryFile, fileStr); // 文件名+文件内容
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "汇总代收文件 [" + summaryFile + "] 异常：" + e.getMessage());
		}
	}

	/**
	 * 
	 * @param channelBatchNo
	 * @param trantype
	 * @param objectList
	 * @param batchFileName
	 * @param corpAcctNo
	 * @param corpAcctName
	 * @param corpBankNo
	 * @return
	 * @throws BizException
	 */
	@SuppressWarnings("unchecked")
	private BatchNoticeBean createFtpSend(final BatchNoticeBean b, final String channelBatchNo, final String trantype,
			final List objectList, final String batchFileName, final String fileNum, final String corpAcctNo,
			final String corpAcctName, final String corpBankNo) throws BizException {

		final double[] rs = this.createBillnosnBatchFile(channelBatchNo, trantype, objectList, batchFileName, fileNum,
				corpAcctNo, corpAcctName, corpBankNo);

		// 1、 生成批量代收业务文件，保存记录到 billnoSn表，返回总金额
		b.setTotalNum(objectList.size()); // 返回总记录数
		b.setTotalAmt(rs[0]);
		b.setFileSize(rs[1]);

		return b;
	}

	/**
	 * 
	 * 生产批量付款明细文件,并将明细信息保存到渠道流水表.
	 * 
	 * @param channelBatchNo
	 * @param trantype
	 * @param paybillList
	 * @param batchFileName
	 * @param corpAcctNo
	 * @param corpAcctName
	 * @param corpBankNo
	 * @return
	 * @throws BizException
	 */
	private double[] createBillnosnBatchFile(final String channelBatchNo, final String trantype,
			final List<ChannelTempBill> objectList, final String fileName, final String fileNum,
			final String corpAcctNo, final String corpAcctName, final String corpBankNo) throws BizException {

		String banckSendSn;// 流水号
		String otherBankCardNo;// 客户账号
		String channelAmount;// 交易金额
		String otherBankCardName;// 客户姓名

		String fileStr = "";// 保存文件内容
		Double dAmtTotal = 0.0;

		final StringBuffer sbContent = new StringBuffer("");// 临时内容变量

		final List<ChannelTempBill> paybillList = objectList;
		ChannelTempBill paybill = null;
		for (int i = 0; i < paybillList.size(); i++) {
			paybill = paybillList.get(i);

			banckSendSn = sequenceManagerService.getCcbCreditRepaySN(DateUtil.getCurrentDate());// 流水号
			otherBankCardNo = paybill.getBankAccountNo();// 账号
			channelAmount = MoneyUtil.getFenString(paybill.getAmount());// 金额
			otherBankCardName = paybill.getBankAccountHolder();// 户名

			dAmtTotal = dAmtTotal + paybill.getAmount().doubleValue();

			// 明细记录
			sbContent.append("R").append(dot)// 记录类型
					.append(banckSendSn).append(dot)// 付款单号
					.append(channelBatchNo).append(dot)// 付款批次
					.append(fileNum).append(dot)// 文件序号
					.append(DateUtil.getCurrentDate()).append(dot)// 付款日期
					.append(DateUtil.getCurrentDate()).append(dot)// 交易日期
					.append(dot)// 结算日期
					.append(DateUtil.getTime1(new Date())).append(dot)// 付款时间
					.append(dot)// 交易时间
					.append(dot)// 结算时间
					.append(otherBankCardNo).append(dot)// 信用卡号
					.append(dot)// 本他行标记
					.append(otherBankCardName).append(dot)// 持卡人姓名
					.append(dot)// 支付方式
					.append(dot)// 开户网点名称
					.append(dot)// 开户省份
					.append(dot)// 开户地区
					.append(channelAmount).append(dot)// 付款金额
					.append("还款").append(dot)// 用途
					.append("RMB").append(dot)// 币种
					.append(corpAcctNo).append(dot)// 付款帐号
					.append(dot)// 描述
					.append("");// 备注
			if (i == paybillList.size() - 1) {
			} else {
				sbContent.append(line);
			}

			saveBillnoSn(banckSendSn.trim(), channelBatchNo, trantype, paybill, i, corpAcctNo, corpAcctName, corpBankNo);
		}
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String operator = channelParms.get("100009");

		// 签名记录
		final StringBuffer signData = new StringBuffer();
		signData.append("S").append(dot)// 记录类型
				.append(DateUtil.getCurrentDate()).append(dot)// 签名日期
				.append(DateUtil.getTime1(new Date())).append(dot)// 签名时间
				.append(System.currentTimeMillis()).append(dot)// 签名时间戳
				.append(operator).append(dot)// 操作者
				.append(this.enCrypt(sbContent.toString() + line));// 签名
		// .append(line);

		// 明细记录文件
		fileStr = sbContent.append(line).append(signData).toString();

		Log4jUtil.info("批量业务的批量文件内容:");
		Log4jUtil.info(fileStr);

		try {
			Log4jUtil.info("批量业务的批量文件文件名:" + fileName);
			// CreateAccFile方法生成文件，返回文件名(含上级文件夹)，返回参数这里用不着
			ccbRepayMsgDeal.createBatchFile(fileName, fileStr); // 文件名+文件内容
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "生成批量代收文件 [" + fileName + "] 异常：" + e.getMessage());
		}

		final double[] rs = new double[2];
		rs[0] = dAmtTotal;
		rs[1] = fileStr.getBytes(Charset.forName("GBK")).length;
		return rs;
	}

	/**
	 * 需要调整为 RSA_SIGN( TenpayCert_PrivateKey , MD5( DATA ) )
	 * 
	 * @param data
	 * @return
	 * @throws BizException
	 */
	private String enCrypt(final String data) throws BizException {
		final ChannelParm passwd = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		AssertUtils.notNull(passwd, "未得到私钥的password");
		final ChannelParm alias = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100020"));
		AssertUtils.notNull(alias, "未得到JKS的alias");
		final ChannelParm keyFile = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100018"));
		AssertUtils.notNull(keyFile, "未得到私钥的证书文件路径");
		String signValue = "";
		try {
			signValue = CryptorJKS.sign(data, keyFile.getParvalue(), passwd.getParvalue(), alias.getParvalue());
		} catch (IOException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "签名失败" + e.getMessage());
		}

		return signValue;
	}

	/**
	 * 
	 * @param banckSendSn
	 * @param channelBatchNo
	 * @param tranType
	 * @param object
	 * @param i
	 * @param corpAcctNo
	 * @param corpAcctName
	 * @param corpBankNo
	 * @throws BizException
	 */
	private void saveBillnoSn(final String banckSendSn, final String channelBatchNo, final String tranType,
			final ChannelTempBill bill, final int i, final String corpAcctNo, final String corpAcctName,
			final String corpBankNo) throws BizException {

		String sn = ""; // 平台业务流水
		String otherAcctNo = ""; // 对方帐号
		String otherAcctName = ""; // 对方账户名
		String otherBankNo = ""; // 对方行号
		String otherCust_Id = ""; // 对方客户编号
		String otherBankAddrNo = "";// 对方开户行地区代码
		String createTime = ""; // 交易的平台交易日期
		// String orderid = ""; // 订单号
		String bank_Type = ""; // 行别
		Double dTranAmt = 0.0; // 平台的交易金额Double类型
		String batchID = ""; // 批次号
		String detailID = ""; // 明细序号

		// bill付款交易
		sn = bill.getBizBillSn();
		otherAcctNo = bill.getBankAccountNo();
		otherAcctName = bill.getBankAccountHolder();
		otherBankNo = bill.getBankCode();
		otherCust_Id = bill.getCustomerId();
		otherBankAddrNo = bill.getBankAreaCode();
		createTime = DateUtil.getDate(bill.getCreateTime());
		bank_Type = bill.getBankType();
		dTranAmt = bill.getAmount().doubleValue();
		batchID = bill.getChannelBatchId(); // 批次号
		detailID = String.valueOf(i + 1); // 明细序号

		// 写交易流水和渠道流水对照表
		final BillnoSn billnoSn = new BillnoSn();
		billnoSn.setBillnosnSeq(sequenceManagerService.getBillnoSnSeq());
		billnoSn.setSn(sn);
		billnoSn.setChannelid(channelId);
		billnoSn.setBankSendSn(banckSendSn); // 银行订单号，这里填场次号
		billnoSn.setTranDate(createTime);
		// billnoSn.setCheckDate(DateUtil.getCurrentDate()); //轧差日期 收到回执报文后更新
		billnoSn.setChannelBatchno(channelBatchNo);// 渠道批次 批量交易使用
		billnoSn.setChannelDetail(StringUtil.formatSeq((i + 1), 8));// 渠道明细
		// 批量交易使用
		// billnoSn.setBankRecvSn(returnState.getSn()); // 接收流水
		billnoSn.setAmount(new BigDecimal(dTranAmt)); // 平台交易金额
		// billnoSn.setActualAmount(returnState.getRelTranAmount());//实际交易金额
		billnoSn.setTranType(tranType);
		billnoSn.setState(BillnoSnState.billnoSend); // 00：已发送 01: 已收到中心确认 02：业务回执已返回
		billnoSn.setBatchid(batchID); // 批次号 对应于原交易
		billnoSn.setDetailid(detailID);// 批量业务明细序号 对应于原交易
		// billnoSn.setChannelRtncode(returnState.getBankRetCode()); //渠道返回码
		// billnoSn.setChannelRtnnote(returnState.getReturnMsg()); //渠道返回附言
		billnoSn.setSendTime(new Date());
		// billnoSn.setRecvTime(new Date()); //返回时间

		billnoSn.setCorpacctno(corpAcctNo); // 企业帐号 对应渠道绑定的帐号
		billnoSn.setCorpacctname(corpAcctName);// 企业户名 对应渠道绑定的帐号名
		billnoSn.setCorpbankno(corpBankNo);// 企业行号

		billnoSn.setOtheracctno(otherAcctNo);// 对方帐号
		billnoSn.setOtheracctname(otherAcctName);// 对方户名
		billnoSn.setOtherbankno(otherBankNo);// 对方行号
		billnoSn.setOtherbankaddrno(otherBankAddrNo);// 对方开户行地区代码
		billnoSn.setOthercustId(otherCust_Id);// 对方客户编号

		billnoSn.setBankType(bank_Type);// 行别(非空）
		// billnoSn.setSrccustId(srcCust_Id);// 发起方客户编号
		// billnoSn.setFeecode("");//费项代码(只有同城用到)
		// billnoSn.setFeedesc("");//费项说明(只有同城用到)
		billnoSn.setOrderid(bill.getBizTxnId());// 订单号 转账交易无；打款账户验证时为账户验证流水的ID
		billnoSn.setBankCardType(bill.getCardType() != null ? bill.getCardType().toString()
				: BankCardType.UNDISTINGUISH);
		billnoSnService.save(billnoSn);
	}

	/**
	 * 处理批量业务查询返回的交易
	 * 
	 * @param channelBatchId 请求渠道批次ID
	 * @param fileNameRcvPath 批量结果文件（含相对路径）
	 * @param tranDate
	 * @throws BizException
	 */
	public void predeal(final String channelBatchId, final String fileNameRcvPath, final String checkDate)
			throws BizException {
		// 统计合计数据，用于保存到 表
		Long totalNumSuc = 0L; // 成功总笔数
		Double totalAmtSuc = 0.0; // 成功总金额
		Long totalNumFail = 0L; // 失败总笔数
		Double totalAmtFail = 0.0; // 失败总金额
		String tranType = ""; // 平台业务类型

		// 汇总信息：记录类型，付款批次，子文件数，付款总金额，付款总笔数，币种，付款日期，汇总生成时间，描述，备注，成功总金额，成功总笔数，还款时间

		String batchIdR = ""; // 付款批次
		int subFileNumR = 0; // 子文件数
		double totalAmtR = 0.0; // 付款总金额
		int totalNumR = 0;// 付款总笔数
		double amtSucR = 0.0; // 成功总金额
		int numSucR = 0; // 成功总笔数

		// 明细信息：记录类型,付款单号,付款批次,文件序号,付款日期,交易日期,结算日期,付款时间,交易时间,结算时间,
		// 信用卡号,本他行标记,持卡人姓名,支付方式,开户网点名称,开户省份,开户地区,付款金额,币种,用途,付款帐号,描述,备注,还款日期,还款时间,还款状态,还款描述,

		String bankSn = "";// 付款单号
		String batchIdR_e = ""; // 付款批次
		String accountR_e = "";// 账号
		double amtR_e = 0.0;// 交易金额
		String sucRetDate = ""; // 还款日期
		String sucRetTime = ""; // 还款时间
		String retCodeR_e = "";// 还款状态
		String retMsgR_e = "";// 还款描述

		// this.verifyRetData(fileNameRcvPath);

		BillnoSn billnoSn = null;
		String s = null; // 判断文件是否读完
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(fileNameRcvPath),
					Charset.forName("GBK")));
		} catch (final FileNotFoundException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "错误：找不到批量文件：" + fileNameRcvPath);
		}

		// 文件体
		try {
			int n = 0;
			while ((s = bufferedReader.readLine()) != null) {
				n++;
				final String[] es = s.split(dot);

				// 按记录类型处理
				if ("R".equalsIgnoreCase(es[0].trim())) {

					// 过滤字段数不合格记录
					if (es.length < 27)
						continue;

					// 明细信息：记录类型,付款单号,付款批次2,文件序号,付款日期,交易日期,结算日期,付款时间,交易时间,结算时间,
					// 信用卡号10,本他行标记,持卡人姓名,支付方式,开户网点名称,开户省份,开户地区,付款金额17,币种,用途,付款帐号,描述,备注,还款日期23,还款时间,还款状态,还款描述,

					bankSn = es[1].trim();// 付款单号
					batchIdR_e = es[2].trim();// 付款批次
					accountR_e = es[10].trim();// 账号
					amtR_e = Double.valueOf(es[17].trim()) / 100;// 交易金额
					sucRetDate = es[23].trim(); // 还款日期
					sucRetTime = es[24].trim(); // 还款时间
					retCodeR_e = es[25].trim();// 还款状态
					retMsgR_e = es[26].trim();// 还款描述

					if (!channelBatchId.equals(batchIdR_e)) {
						throw new BizException(TransReturnCode.code_9109, StringUtil.r(
								"第{?}行的明细的付款批次{?}与原批次{?}不符，请核实！", n, batchIdR_e, channelBatchId));
					}

					Log4jUtil
							.info(StringUtil
									.r("-----------第{?}行的明细-----bankSn:{?} batchId:{?} account:{?} amt:{?} sucRetDate:{?} sucRetTime:{?} retCode:{?} retMsg:{?}",
											n, bankSn, batchIdR_e, accountR_e, amtR_e, sucRetDate, sucRetTime,
											retCodeR_e, retMsgR_e));

					// 更新billnoSn表;Channel_Batch表
					billnoSn = billnoSnService.getBillnoSn(channelId, bankSn);
					AssertUtils.notNull(billnoSn, "在表 billnoSn 中找不到批量返回的交易记录，交易记录详细信息如下：" + "渠道ID：" + channelId
							+ "渠道批次：" + channelBatchId + "对方客户编号：" + bankSn + "对方帐号：" + accountR_e + "交易金额：" + amtR_e);

					// 给 ChannelBatch 表做记录汇总
					if ("0".equals(retCodeR_e) || "成功".equals(retMsgR_e)) {
						totalNumSuc = totalNumSuc + 1; // SucessNum 成功总笔数
						totalAmtSuc = totalAmtSuc + amtR_e; // 成功总金额
						billnoSn.setChannelRtncode(retCodeR_e); // 渠道返回码
						billnoSn.setChannelRtnnote(retMsgR_e); // 渠道返回附言
						billnoSn.setPayState("1");// 成功1
					} else {
						totalNumFail = totalNumFail + 1; // UnSucessNum 失败总笔数
						totalAmtFail = totalAmtFail + amtR_e; // 失败总金额
						billnoSn.setChannelRtncode(retCodeR_e); // 渠道返回码
						billnoSn.setChannelRtnnote(retMsgR_e); // 渠道返回附言
						billnoSn.setPayState("2");// 失败2
					}

					// b2.更新billnoSn表的STATE字段
					billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
					billnoSn.setRecvTime(new Date()); // 返回时间
					billnoSn.setActualAmount(new BigDecimal(amtR_e)); // 渠道实际支付金额
					billnoSn.setCheckDate(checkDate); // 收到回执报文后更新
					billnoSn.setBankRecvSn(bankSn);// 银行返回的流水号
					billnoSnService.update(billnoSn);

				} else if ("T".equalsIgnoreCase(es[0].trim())) {
					// 过滤字段数不合格记录
					if (es.length < 12)
						continue;

					// 汇总信息：记录类型，付款批次，子文件数2，付款总金额，付款总笔数4，币种，付款日期，汇总生成时间，描述，备注，成功总金额10，成功总笔数，还款时间

					batchIdR = es[1].trim(); // 付款批次
					subFileNumR = Integer.valueOf(es[2].trim()); // 子文件数
					totalAmtR = Double.valueOf(es[3].trim()) / 100; // 付款总金额
					totalNumR = Integer.valueOf(es[4].trim());// 付款总笔数
					amtSucR = Double.valueOf(es[10].trim()); // 成功总金额
					numSucR = Integer.valueOf(es[11].trim()); // 成功总笔数

					if (!channelBatchId.equals(batchIdR)) {
						throw new BizException(TransReturnCode.code_9109, StringUtil.r("第{?}行的汇总的批次{?}与原批次{?}不符，请核实！",
								n, batchIdR, channelBatchId));
					}

					Log4jUtil
							.info(StringUtil
									.r("-----------第{?}行的汇总-----batchIdR:{?} subFileNumR:{?} totalAmtR:{?} totalNumR:{?} amtSucR:{?} numSucR:{?}",
											n, batchIdR, subFileNumR, totalAmtR, totalNumR, amtSucR, numSucR));
				}
			}

			// 循环结束,检查数据
			if (Long.valueOf(totalNumR) == (totalNumSuc + totalNumFail) && AmountUtils.et(amtSucR, totalAmtSuc)
					&& AmountUtils.et(totalAmtR, totalAmtSuc + totalAmtFail)) {
			} else {
				Log4jUtil.info("批量交易结果文件中的文件头与文件体不笔数或金额不相符，请人工检查结果文件是否正确。");
				throw new BizException(BusinessCode.TRANSACTION_QUERY_FAILED,
						"批量交易结果文件中的文件头与文件体不笔数或金额不相符，请人工检查结果文件是否正确。");
			}

			// 更新ChannelBatch多个字段 TODO 需要打开
			batchProcessResultNotice.process(channelId, channelBatchId, billnoSn.getTranType(), totalNumSuc,
					totalAmtSuc, totalNumFail, totalAmtFail);

		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException("错误：读文件’" + fileNameRcvPath + "‘出错！");
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (final IOException e) {
					Log4jUtil.error("文件关闭异常！", e);
					throw new BizException("错误：文件’" + fileNameRcvPath + "关闭异常！");
				}
			}
		}
	}

	/**
	 * 
	 * <p>验签</p>
	 * 
	 * @param fileNameRcvPath
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	private void verifyRetData(String fileNameRcvPath) throws BizException {

		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(fileNameRcvPath),
					Charset.forName("GBK")));
		} catch (final FileNotFoundException e) {
			Log4jUtil.error(e);
			throw new BizException(BusinessCode.FILE_NOT_FOUND, "错误：找不到批量文件：" + fileNameRcvPath);
		}

		StringBuffer sb = new StringBuffer(); // 待加签的数据: R标识明细+T标识汇总
		StringBuffer sbSign = new StringBuffer();// 签名记录: S标识签名

		String s = "";
		try {
			int i = 0;
			while ((s = bufferedReader.readLine()) != null) {
				if (s.trim().startsWith("R") || s.trim().startsWith("T")) {
					if (i == 0) {
						sb.append(s);
					} else {
						sb.append(line).append(s);
					}
				} else if (s.trim().startsWith("S")) {
					sbSign.append(s);
				}
				i++;
			}
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "错误：读文件’" + fileNameRcvPath + "‘出错！");
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (final IOException e) {
					Log4jUtil.error("文件关闭异常！", e);
					throw new BizException("错误：文件’" + fileNameRcvPath + "关闭异常！");
				}
			}
		}

		AssertUtils.notNull(sbSign, "签名记录不能为空!");

		final ChannelParm bankPubKey = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100019"));
		AssertUtils.notNull(bankPubKey, "未得到银行的证书文件");

		boolean b = false;
		String[] temp = sbSign.toString().split(dot);
		String signStr = temp[5];
		if (temp.length < 6)
			throw new BizException(TransReturnCode.code_9109, "验签失败：签名记录不合规范：" + sbSign.toString());

		char[] cs = signStr.toCharArray();
		byte[] org = Base64.decode(cs);
		String signMsg2 = CryptorJKS.bytesToHexString(org);

		try {
			Log4jUtil.error("银行给的sign:" + signStr);
			b = CryptorJKS.verify(bankPubKey.getParvalue(), sb.toString() + line, signMsg2);
		} catch (CertificateException e) {
			Log4jUtil.error(e);
		}

		if (!b)
			throw new BizException(TransReturnCode.code_9109, "验签失败：批量文件：" + fileNameRcvPath);
	}

	/**
	 * 
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealKeyApply() throws BizException {
		final ReturnState rs = ccbRepayMsgDeal.sendKeyApply();

		/**
		 * 更新dck密钥 工作加密密钥：DCK (Dynamic Cryptic Key)
		 */
		if (rs.getChannelCode().equals(TransReturnCode.code_0000)) {
			final String dck = (String) rs.getReturnObj();
			AssertUtils.checkLength(dck, TransReturnCode.code_9109, "工作加密密钥dck", 32, 32);

			final ChannelParm dckParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100013"));
			AssertUtils.notNull(dckParm, "dck密钥 ");
			dckParm.setParvalue(dck);// 工作密钥
			channelParmService.update(dckParm);
		}
		return rs;
	}

	/**
	 * 
	 * <p>信用卡还款用户信息验证</p>
	 * 
	 * @param accountVerify
	 * @return
	 * @author 汤兴友 xytang
	 * @throws BizException
	 */
	public ReturnState accountVerify(BankCardVerifyDTO accountVerify) throws BizException {
		return ccbRepayMsgDeal.accountVerify(accountVerify);
	}
}
