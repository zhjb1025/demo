package com.lycheepay.clearing.adapter.banks.ccb.http;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import netpay.merchant.crypto.ABAProvider;
import netpay.merchant.crypto.RSAPrivKeyCrt;
import netpay.merchant.crypto.RSAPubKey;

import com.ccb.servlet.EnByPubKey;
import com.ccb.servlet.Escape;
import com.lycheepay.clearing.adapter.banks.ccb.http.bean.CcbB2CAccountVerifyBean;
import com.lycheepay.clearing.adapter.banks.ccb.http.bean.CcbPayBean;
import com.lycheepay.clearing.adapter.banks.ccb.http.bean.CcbServletB2BPayBean;
import com.lycheepay.clearing.adapter.banks.ccb.http.bean.CcbServletB2CPayBean;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.PayRspParam;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelParamUtil;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelServletUtil;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.adapter.common.util.security.JDigest;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.CcbIcbcBankCodePrefix;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


public class CcbUtil {
	private String priKey;
	private String pubKey;

	public String getPublicKey() {
		return pubKey;
	}

	public String getPrivateKey() {
		return priKey;
	}

	public void setPublicKey(final String pkey) {
		pubKey = pkey;
	}

	public void setPrivateKey(final String pkey) {
		priKey = pkey;
	}

	public boolean generateKeys() {
		PublicKey keyPub;
		PrivateKey keyPri;
		SecureRandom rand;
		Security.addProvider(new ABAProvider());
		rand = new SecureRandom();
		rand.setSeed(System.currentTimeMillis());
		try {
			KeyPairGenerator fact;
			KeyPair keyPair;
			fact = KeyPairGenerator.getInstance("RSA", "ABA");
			fact.initialize(1024, rand);
			keyPair = fact.generateKeyPair();
			keyPub = keyPair.getPublic();
			keyPri = keyPair.getPrivate();
			pubKey = bytesToHexStr(keyPub.getEncoded());
			priKey = bytesToHexStr(keyPri.getEncoded());
		} catch (final Exception e) {
			return false;
		}
		return true;
	}

	public String generateSigature(final String src) {
		try {
			Security.addProvider(new ABAProvider());
			final Signature sigEng = Signature.getInstance("MD5withRSA", "ABA");

			final byte[] pribyte = hexStrToBytes(priKey.trim());
			sigEng.initSign(new RSAPrivKeyCrt(pribyte));
			sigEng.update(src.getBytes());

			final byte[] signature = sigEng.sign();
			return bytesToHexStr(signature);
		} catch (final Exception e) {
			return null;
		}
	}

	public boolean verifySigature(final String logPrefix, final String sign, final String src) {
		String logMsg = "";
		logMsg = logPrefix + "开始验签：sign为：" + sign + " 串为：" + src;
		Log4jUtil.info(logMsg);
		try {
			Security.addProvider(new ABAProvider());
			final Signature sigEng = Signature.getInstance("MD5withRSA", "ABA");
			final byte[] pubbyte = hexStrToBytes(pubKey.trim());
			sigEng.initVerify(new RSAPubKey(pubbyte));
			sigEng.update(src.getBytes());
			final byte[] sign1 = hexStrToBytes(sign);
			if (sigEng.verify(sign1)) {
				Log4jUtil.info(logPrefix + "验签成功。");
				return true;
			} else {
				Log4jUtil.info(logPrefix + "验签失败！");
				return false;
			}
		} catch (final Exception e) {
			return false;
		}
	}

	/**
	 * 验签
	 * 
	 * @param logPrefix
	 * @param sign
	 * @param src
	 * @param pubKey
	 * @return
	 */
	public boolean verifySigature(final String logPrefix, final String sign, final String src, final String pubKey) {
		String logMsg = "";
		logMsg = logPrefix + "开始验签：sign为：" + sign + " 串为：" + src;
		Log4jUtil.info(logMsg);
		try {
			Security.addProvider(new ABAProvider());
			final Signature sigEng = Signature.getInstance("MD5withRSA", "ABA");
			final byte[] pubbyte = hexStrToBytes(pubKey.trim());
			sigEng.initVerify(new RSAPubKey(pubbyte));
			sigEng.update(src.getBytes());
			final byte[] sign1 = hexStrToBytes(sign);
			if (sigEng.verify(sign1)) {
				Log4jUtil.info(logPrefix + "验签成功。");
				return true;
			} else {
				Log4jUtil.info(logPrefix + "验签失败！");
				return false;
			}
		} catch (final Exception e) {
			return false;
		}
	}

	/**
	 * Transform the specified byte into a Hex String form.
	 */
	public final String bytesToHexStr(final byte[] bcd) {
		final StringBuffer s = new StringBuffer(bcd.length * 2);
		for (final byte element : bcd) {
			s.append(bcdLookup[(element >>> 4) & 0x0f]);
			s.append(bcdLookup[element & 0x0f]);
		}
		return s.toString();
	}

	/**
	 * Transform the specified Hex String into a byte array.
	 */
	public final byte[] hexStrToBytes(final String s) {
		byte[] bytes;
		bytes = new byte[s.length() / 2];
		for (int i = 0; i < bytes.length; i++) {
			bytes[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
		}
		return bytes;
	}

	private final char[] bcdLookup = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	public String getPubKeyByFile(final String logPrefix, final String fileName) throws BizException {
		String logMsg = "";
		logMsg = "获取 " + logPrefix + " 公钥。";
		Log4jUtil.info(logMsg);
		BufferedReader bufferedReader = null;
		String pubKey = "";
		try {
			String data = null;
			// bufferedReader = new BufferedReader(new BufferedReader(new FileReader(fileName)));
			final InputStreamReader reader = new InputStreamReader(new FileInputStream(fileName),
					Charset.forName("GBK"));
			bufferedReader = new BufferedReader(reader);
			while ((data = bufferedReader.readLine()) != null) {
				if (0 < data.trim().length()) {
					pubKey = pubKey + data;
				}
			}
		} catch (final FileNotFoundException e) {
			Log4jUtil.error(logPrefix + "出错:", e);
			throw new BizException(e);
		} catch (final IOException e) {
			Log4jUtil.error(logPrefix + "出错:", e);
			throw new BizException(e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();// 关闭文件
				}
			} catch (final Exception e) {
				Log4jUtil.error(logPrefix + "关闭文件流出错:", e);
				throw new BizException(e);
			}
		}
		return pubKey;
	}

	public String getPriKeyByFile(final String fileName, final String password) throws BizException {
		FileInputStream fis;
		KeyStore ks;
		final String pwd = password;
		PrivateKey prk = null;
		String alias;
		final String prikey = "";
		try {
			ks = KeyStore.getInstance("pkcs12");
			fis = new FileInputStream(fileName);
			ks.load(fis, null);
			alias = ks.aliases().nextElement().toString();
			prk = (PrivateKey) ks.getKey(alias, pwd.toCharArray());
		} catch (final KeyStoreException e) {
			Log4jUtil.error("出错:", e);
			throw new BizException(e);
		} catch (final FileNotFoundException e) {
			Log4jUtil.error("出错:", e);
			throw new BizException(e);
		} catch (final NoSuchAlgorithmException e) {
			Log4jUtil.error("出错:", e);
			throw new BizException(e);
		} catch (final CertificateException e) {
			Log4jUtil.error("出错:", e);
			throw new BizException(e);
		} catch (final IOException e) {
			Log4jUtil.error("出错:", e);
			throw new BizException(e);
		} catch (final UnrecoverableKeyException e) {
			Log4jUtil.error("出错:", e);
			throw new BizException(e);
		}
		return prikey;
	}

	public String bintoascii(final byte[] bySourceByte) {
		int len, i;
		byte tb;
		char high, tmp, low;
		String result = new String();
		len = bySourceByte.length;
		for (i = 0; i < len; i++) {
			tb = bySourceByte[i];
			tmp = (char) ((tb >>> 4) & 0x000f);
			if (tmp >= 10) {
				high = (char) ('a' + tmp - 10);
			} else {
				high = (char) ('0' + tmp);
			}
			result += high;
			tmp = (char) (tb & 0x000f);
			if (tmp >= 10) {
				low = (char) ('a' + tmp - 10);
			} else {
				low = (char) ('0' + tmp);
			}
			result += low;
		}
		return result;
	}

	/**
	 * 字符串转换成十六进制值
	 * 
	 * @param bin String 我们看到的要转换成十六进制的字符串
	 * @return
	 */
	public String bin2hex(final String bin) {
		final char[] digital = "0123456789ABCDEF".toCharArray();
		final StringBuffer sb = new StringBuffer("");
		final byte[] bs = bin.getBytes();
		int bit;
		for (final byte element : bs) {
			bit = (element & 0x0f0) >> 4;
			sb.append(digital[bit]);
			bit = element & 0x0f;
			sb.append(digital[bit]);
		}
		return sb.toString();
	}

	public String escape(final String src) {
		int i;
		char j;
		final StringBuffer tmp = new StringBuffer();
		tmp.ensureCapacity(src.length() * 6);
		for (i = 0; i < src.length(); i++) {
			j = src.charAt(i);
			if (Character.isDigit(j) || Character.isLowerCase(j) || Character.isUpperCase(j)) {
				tmp.append(j);
			} else if (j < 256) {
				tmp.append("%");
				if (j < 16) {
					tmp.append("0");
				}
				tmp.append(Integer.toString(j, 16));
			} else {
				tmp.append("%u");
				tmp.append(Integer.toString(j, 16));
			}
		}
		return tmp.toString();
	}

	public String unescape(final String src) {
		final StringBuffer tmp = new StringBuffer();
		tmp.ensureCapacity(src.length());
		int lastPos = 0, pos = 0;
		char ch;
		while (lastPos < src.length()) {
			pos = src.indexOf("%", lastPos);
			if (pos == lastPos) {
				if (src.charAt(pos + 1) == 'u') {
					ch = (char) Integer.parseInt(src.substring(pos + 2, pos + 6), 16);
					tmp.append(ch);
					lastPos = pos + 6;
				} else {
					ch = (char) Integer.parseInt(src.substring(pos + 1, pos + 3), 16);
					tmp.append(ch);
					lastPos = pos + 3;
				}
			} else {
				if (pos == -1) {
					tmp.append(src.substring(lastPos));
					lastPos = src.length();
				} else {
					tmp.append(src.substring(lastPos, pos));
					lastPos = pos;
				}
			}
		}
		return tmp.toString();
	}

	/**
	 * 检查参数配置
	 * 
	 * @param logPrefix
	 * @param type 1为充值、支付 2为账户验证 3为接收slervlet
	 * @param channelParam
	 * @return
	 * @throws BizException
	 */
	public Map<String, String> checkChannelParam(final String logPrefix, final String type,
			final Map<String, String> channelParam) throws BizException {
		String key = "";
		String defaultValue = "";
		String keyName = "";
		String logMsg = "";
		logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
		Log4jUtil.info(logMsg);
		// CCB建行网银不区分B2B B2C
		if (type.equals(ClearingTransType.NET_DEDUCT)) {
			// 网银支付
			key = "100002";
			keyName = "商户柜台代码";
			defaultValue = "";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100003";
			keyName = "分行代码";
			defaultValue = "";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100004";
			keyName = "公钥路径";
			defaultValue = "";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100005";
			keyName = "银行跳转地址";
			defaultValue = "";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100007";
			keyName = "企业支付交易码";
			defaultValue = "690401";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100008";
			keyName = "个人支付交易码";
			defaultValue = "520100";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100009";
			keyName = "交易币种";
			defaultValue = "01";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100010";
			keyName = "接口类型";
			defaultValue = "old";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		} else if (type.equals(ClearingTransType.ONLINE_ACCOUNT_VERIFY)) {
			// 网银验证

			key = "100002";
			keyName = "商户柜台代码";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100003";
			keyName = "分行代码";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100004";
			keyName = "公钥路径";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100005";
			keyName = "银行跳转地址";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100011";
			keyName = "账户验证支付交易码";
			defaultValue = "520400";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100012";
			defaultValue = "V5";
			keyName = "IBSVersion";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		} else if (type.equals("CcbServlet")) {
			// 支付回执
			key = "100001";
			keyName = "支付回执是否带回ACCDATE";
			defaultValue = "Y";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100004";
			keyName = "公钥路径";
			defaultValue = "";
			ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

			key = "100007";
			keyName = "企业支付交易码";
			defaultValue = "690401";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100008";
			keyName = "个人支付交易码";
			defaultValue = "520100";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100011";
			keyName = "账户验证支付交易码";
			defaultValue = "520400";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		}
		logMsg = logPrefix + "对渠道参数检查结束。";
		Log4jUtil.info(logMsg);
		return channelParam;
	}

	/**
	 * 获取回执业务类型
	 * 
	 * @param logPrefix
	 * @param channelParam
	 * @param request
	 * @return
	 */
	public String getServletTransType(final String logPrefix, final Map<String, String> channelParam,
			final HttpServletRequest request) {
		String logMsg = "";
		String transType = "";
		logMsg = logPrefix + "判断回执业务类型。";
		Log4jUtil.info(logMsg);
		final String txcode = request.getParameter("TXCODE");// 返回的业务编码 520400 账户验证
																// 支付业务没有该属性，获取后为NULL
		if (!(txcode == null)) {
			transType = txcode;
		} else if (txcode == null || txcode.trim().length() < 1) {
			// B2C、B2B
			if (!(request.getParameter("MPOSID") == null)) {
				// B2B
				transType = channelParam.get("100007").trim();
			} else {
				// B2C
				transType = channelParam.get("100008").trim();
			}
		}
		logMsg = logPrefix + "回执业务类型为：" + transType;
		Log4jUtil.error(logMsg);
		return transType;
	}

	/**
	 * 创建B2B支付回执实体
	 * 
	 * @param logPrefix
	 * @param request
	 * @return
	 */
	private CcbServletB2BPayBean getServletB2BPayBean(final String logPrefix, final HttpServletRequest request) {
		// http://payment.lycheepay.com/paycore/ccbHttpServlet?MPOSID=969968895&ORDER_NUMBER=2011061700000981&CUST_ID=P56705736-6%23&ACC_NO=44201503500052518186&ACC_NAME=深圳市宇商爱购网络科技有限公司&AMOUNT=.01&STATUS=2&REMARK1=&REMARK2=&TRAN_FLAG=N&TRAN_TIME=201106171635&BRANCH_NAME=深圳市&SIGNSTRING=943e41eac764a11a872590540b62a47093600535c95fcc507b783d7469b11a01cd44ec9071f2844452dcbbf0b55becee1ad708a0a16bf4966fbee284ee29fb18791e8f6a4f8c4fa0c366f31aea6d8667fe402fc6f9b54ba68f7853ec6977e43e101f8f779c20cf5a4f197207a2c6757ee7d765055d46d1ce8da90cea653a3b58&CHECKOK=1
		Log4jUtil.info(logPrefix + "获取回执参数。");
		final CcbServletB2BPayBean ccbServletB2BPayBean = new CcbServletB2BPayBean();
		ccbServletB2BPayBean.setMposid(request.getParameter("MPOSID"));
		ccbServletB2BPayBean.setOrder_number(request.getParameter("ORDER_NUMBER"));
		ccbServletB2BPayBean.setCust_id(request.getParameter("CUST_ID"));
		ccbServletB2BPayBean.setAcc_no(request.getParameter("ACC_NO"));
		ccbServletB2BPayBean.setAcc_name(request.getParameter("ACC_NAME"));
		ccbServletB2BPayBean.setAmount(request.getParameter("AMOUNT"));
		ccbServletB2BPayBean.setStatus(request.getParameter("STATUS"));    // 2：支付成功 3：支付成功 4：支付成功
																		// 5：交易失败 6：交易不确定
		ccbServletB2BPayBean.setRemark1(request.getParameter("REMARK1"));
		ccbServletB2BPayBean.setRemark2(request.getParameter("REMARK2"));
		ccbServletB2BPayBean.setTran_flag(request.getParameter("TRAN_FLAG"));
		ccbServletB2BPayBean.setTran_time(request.getParameter("TRAN_TIME"));
		ccbServletB2BPayBean.setBranch_name(request.getParameter("BRANCH_NAME"));
		ccbServletB2BPayBean.setSignstring(request.getParameter("SIGNSTRING"));
		ccbServletB2BPayBean.setCheckok(request.getParameter("CHECKOK"));
		ObjectUtil.printPropertyString(logPrefix, ccbServletB2BPayBean);
		return ccbServletB2BPayBean;
	}

	/**
	 * 创建B2B回执待签名明文串
	 * 
	 * @param logPrefix
	 * @param ccbServletB2BPayBean
	 * @return
	 */
	private String creatServletB2BSignSting(final String logPrefix, final CcbServletB2BPayBean ccbServletB2BPayBean) {
		Log4jUtil.info(logPrefix + "开始组待签名明文串。");
		final StringBuffer msgtmp = new StringBuffer("");
		msgtmp.append(ccbServletB2BPayBean.getMposid());
		msgtmp.append(ccbServletB2BPayBean.getOrder_number());
		msgtmp.append(ccbServletB2BPayBean.getCust_id());
		msgtmp.append(ccbServletB2BPayBean.getAcc_no());
		msgtmp.append(ccbServletB2BPayBean.getAcc_name());
		msgtmp.append(ccbServletB2BPayBean.getAmount());
		msgtmp.append(ccbServletB2BPayBean.getStatus());
		msgtmp.append(ccbServletB2BPayBean.getRemark1());
		msgtmp.append(ccbServletB2BPayBean.getRemark1());
		msgtmp.append(ccbServletB2BPayBean.getTran_flag());
		msgtmp.append(ccbServletB2BPayBean.getTran_time());
		msgtmp.append(ccbServletB2BPayBean.getBranch_name());
		return msgtmp.toString();
	}

	/**
	 * 创建回执实体，并且验签、返回PayRspParam
	 * 
	 * @param logPrefix
	 * @param request
	 * @param billnoSn
	 * @param pub32FileName 公钥路径
	 * @return
	 * @throws BizException
	 */
	public PayRspParam getB2BPayParm(final String logPrefix, final HttpServletRequest request, final BillnoSn billnoSn,
			final String pub32FileName) throws BizException {
		final String pub32 = this.getPubKeyByFile(logPrefix, pub32FileName);
		String logMsg = "";
		logMsg = logPrefix + "进行支付回执处理。";
		Log4jUtil.info(logMsg);
		final CcbServletB2BPayBean ccbServletB2BPayBean = this.getServletB2BPayBean(logPrefix, request);
		final String data = this.creatServletB2BSignSting(logPrefix, ccbServletB2BPayBean);
		if (!verifySigature(logPrefix, ccbServletB2BPayBean.getSignstring(), data, pub32)) {
			throw new BizException("验签失败，处理中止。");
		}
		String returnState = "";
		if (ccbServletB2BPayBean.getStatus().equals("2") || ccbServletB2BPayBean.getStatus().equals("3")
				|| ccbServletB2BPayBean.getStatus().equals("4")) {
			returnState = "S";
		} else {
			returnState = "F";
		}
		final PayRspParam param = new PayRspParam();
		if (DecimalUtil.ne(new BigDecimal(ccbServletB2BPayBean.getAmount()), billnoSn.getAmount())) {
			throw new BizException(logPrefix + "金额:"
					+ String.format("%1$.2f", Double.valueOf(ccbServletB2BPayBean.getAmount())) + " 与流水表金额:"
					+ String.format("%1$.2f", billnoSn.getAmount()) + "不匹配。处理中止");
		}
		ChannelServletUtil.getPayRspParam(param, ccbServletB2BPayBean.getOrder_number(),
				ccbServletB2BPayBean.getAmount(), "001",
				CcbIcbcBankCodePrefix.CCB_B2B_PAY + ccbServletB2BPayBean.getStatus(), BankCardType.CREDIT_CARD,
				returnState, billnoSn);
		ObjectUtil.printPropertyString(logPrefix, param);
		return param;
	}

	/**
	 * 创建B2C回执实体
	 * 
	 * @param logPrefix
	 * @param request
	 * @return
	 */
	private CcbServletB2CPayBean getServletB2CPayBean(final String logPrefix, final HttpServletRequest request) {
		/*	参与签名运算的字符及其顺序如下
		服务器返回，不带ACCDATE	POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000084&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&ACC_TYPE=12&SUCCESS=Y
		服务器返回，带ACCDATE		POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000085&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&ACC_TYPE=12&SUCCESS=Y&ACCDATE=20110427
		网页返回，不带ACCDATE		POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000085&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&SUCCESS=Y
		网页返回，带ACCDATE		POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000085&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&SUCCESS=Y&ACCDATE=20110427
			注：字符串中变量名必须是大写字母。*/
		Log4jUtil.info(logPrefix + "获取回执参数。");
		final CcbServletB2CPayBean ccbServletB2CPayBean = new CcbServletB2CPayBean();
		ccbServletB2CPayBean.setPosid(request.getParameter("POSID"));
		ccbServletB2CPayBean.setBranchid(request.getParameter("BRANCHID"));
		ccbServletB2CPayBean.setOrderid(request.getParameter("ORDERID"));
		ccbServletB2CPayBean.setPayment(request.getParameter("PAYMENT"));
		ccbServletB2CPayBean.setCurcode(request.getParameter("CURCODE"));
		ccbServletB2CPayBean.setRemark1(request.getParameter("REMARK1"));
		ccbServletB2CPayBean.setRemark2(request.getParameter("REMARK2"));
		ccbServletB2CPayBean.setAcc_type(request.getParameter("ACC_TYPE"));
		ccbServletB2CPayBean.setSuccess(request.getParameter("SUCCESS"));
		ccbServletB2CPayBean.setSign(request.getParameter("SIGN"));
		ccbServletB2CPayBean.setAccDate(request.getParameter("ACCDATE"));
		ObjectUtil.printPropertyString(logPrefix, ccbServletB2CPayBean);
		return ccbServletB2CPayBean;
	}

	/**
	 * 
	 * @param logPrefix
	 * @param ccbServletB2CPayBean
	 * @param ifACCDATE 是否带有ACCDATE
	 * @param flag 0 后台 1页面
	 * @return
	 */
	private String creatServletB2CSignSting(final String logPrefix, final CcbServletB2CPayBean ccbServletB2CPayBean,
			final String ifACCDATE, final String flag) {
		/*	参与签名运算的字符及其顺序如下
		服务器返回，不带ACCDATE	POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000084&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&ACC_TYPE=12&SUCCESS=Y
		服务器返回，带ACCDATE		POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000085&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&ACC_TYPE=12&SUCCESS=Y&ACCDATE=20110427
		网页返回，不带ACCDATE		POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000085&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&SUCCESS=Y
		网页返回，带ACCDATE		POSID=969968895&BRANCHID=442000000&ORDERID=2011042700000085&PAYMENT=0.01&CURCODE=01&REMARK1=&REMARK2=&SUCCESS=Y&ACCDATE=20110427
			注：字符串中变量名必须是大写字母。*/
		Log4jUtil.info(logPrefix + "开始组待签名明文串。");
		final StringBuffer msgtmp = new StringBuffer("");
		msgtmp.append("POSID=").append(ccbServletB2CPayBean.getPosid());
		msgtmp.append("&BRANCHID=").append(ccbServletB2CPayBean.getBranchid());
		msgtmp.append("&ORDERID=").append(ccbServletB2CPayBean.getOrderid());
		msgtmp.append("&PAYMENT=").append(ccbServletB2CPayBean.getPayment());
		msgtmp.append("&CURCODE=").append(ccbServletB2CPayBean.getCurcode());
		msgtmp.append("&REMARK1=").append(ccbServletB2CPayBean.getRemark1());
		msgtmp.append("&REMARK2=").append(ccbServletB2CPayBean.getRemark2());
		if (flag.equals("0")) {
			msgtmp.append("&ACC_TYPE=").append(ccbServletB2CPayBean.getAcc_type());
		}
		msgtmp.append("&SUCCESS=").append(ccbServletB2CPayBean.getSuccess());
		// String ifACCDATE = channelParam.get("100001");
		if (ifACCDATE.equals("Y")) {
			msgtmp.append("&ACCDATE=").append(ccbServletB2CPayBean.getAccDate());
		}
		return msgtmp.toString();
	}

	/**
	 * 根据回执，创建B2C支付回执实体
	 * 
	 * @param logPrefix 日志前缀
	 * @param request 请求
	 * @param ifACCDATE 是否带有 ACCDATE
	 * @param pub32FileName 公钥路径
	 * @param flag 0 后台 1页面
	 * @return
	 * @throws BizException
	 */
	public PayRspParam getB2CPayParm(final String logPrefix, final HttpServletRequest request, final String ifACCDATE,
			final String pub32FileName, final String flag, final BillnoSn billnoSn) throws BizException {
		final String pub32 = this.getPubKeyByFile(logPrefix, pub32FileName);
		String logMsg = "";
		logMsg = logPrefix + "进行支付回执处理。";
		Log4jUtil.info(logMsg);
		final CcbServletB2CPayBean ccbServletB2CPayBean = getServletB2CPayBean(logPrefix, request);
		final String data = creatServletB2CSignSting(logPrefix, ccbServletB2CPayBean, ifACCDATE, flag);
		if (!verifySigature(logPrefix, ccbServletB2CPayBean.getSign(), data, pub32)) {
			throw new BizException("验签失败，处理中止。");
		}
		String returnState = "";
		if (ccbServletB2CPayBean.getSuccess().equals("Y")) {
			returnState = "S";
		} else {
			returnState = "F";
		}
		PayRspParam param = new PayRspParam();
		if (DecimalUtil.ne(new BigDecimal(ccbServletB2CPayBean.getPayment()), billnoSn.getAmount())) {
			throw new BizException(logPrefix + "金额:"
					+ String.format("%1$.2f", Double.valueOf(ccbServletB2CPayBean.getPayment())) + " 与流水表金额:"
					+ String.format("%1$.2f", billnoSn.getAmount()) + "不匹配。处理中止");
		}
		param = ChannelServletUtil.getPayRspParam(param, ccbServletB2CPayBean.getOrderid(),
				ccbServletB2CPayBean.getPayment(), ccbServletB2CPayBean.getCurcode(), CcbIcbcBankCodePrefix.CCB_B2C_PAY
						+ ccbServletB2CPayBean.getSuccess(), BankCardType.CREDIT_CARD, returnState, billnoSn);
		ObjectUtil.printPropertyString(logPrefix, param);
		return param;
	}

	/**
	 * 根据回执，创建实体
	 * 
	 * @param logPrefix
	 * @param request
	 * @return
	 */
	private CcbB2CAccountVerifyBean getServletAccountVerifyBean(final String logPrefix, final HttpServletRequest request) {
		// MERCHANTID=105888888888888&POSID=100000888&BRANCHID=442000000&ACCOUNT=4367888888888888888&&IDNUM=110101888888888888&UNAME=%u5EFA%u8BBE%u94F6%u884C&IDTYPE=01&TXCODE=520400&REMARK=VALUE&SUCCESS=Y&SIGN=1ebd669f413d6159148fd7b8423a0b41ff2373db73ad8b9287bd979a9b16b290f8ab9b26b88217b7a72fe6c4b879261b5db9d8bd227449d85f69e0b062661b4293d5fdd1118c1b1e4d7c1aa2550182ad6b406674c785cf38cd26832508829b4462c7b7aef92875bbc81e61310e0a57089ecb2951064a620aaa9271b78187fe1f
		Log4jUtil.info(logPrefix + "获取回执参数。");
		final CcbB2CAccountVerifyBean ccbB2CAccountVerifyBean = new CcbB2CAccountVerifyBean();
		ccbB2CAccountVerifyBean.setMerchantid(request.getParameter("MERCHANTID"));
		ccbB2CAccountVerifyBean.setPosid(request.getParameter("POSID"));
		ccbB2CAccountVerifyBean.setBranchid(request.getParameter("BRANCHID"));
		ccbB2CAccountVerifyBean.setAccount(request.getParameter("ACCOUNT"));
		ccbB2CAccountVerifyBean.setIdnum(request.getParameter("IDNUM"));
		ccbB2CAccountVerifyBean.setUname(request.getParameter("UNAME"));
		ccbB2CAccountVerifyBean.setIdtype(request.getParameter("IDTYPE"));
		ccbB2CAccountVerifyBean.setTxcode(request.getParameter("TXCODE"));
		ccbB2CAccountVerifyBean.setRemark(request.getParameter("REMARK"));
		ccbB2CAccountVerifyBean.setSuccess(request.getParameter("SUCCESS"));
		ccbB2CAccountVerifyBean.setSign(request.getParameter("SIGN"));
		ObjectUtil.printPropertyString(logPrefix, ccbB2CAccountVerifyBean);
		return ccbB2CAccountVerifyBean;
	}

	/**
	 * 创建账户验证回执待签名明文串
	 * 
	 * @param logPrefix 日志前缀
	 * @param ccbB2CAccountVerifyBean 账户验证实体
	 * @return
	 */
	private String creatServletAccountVerifySignSting(final String logPrefix,
			final CcbB2CAccountVerifyBean ccbB2CAccountVerifyBean) {
		// 参与签名运算的字符及其顺序如下
		// MERCHANTID=105888888888888&POSID=100000888&BRANCHID=442000000&ACCOUNT=4367888888888888888&&IDNUM=110101888888888888&UNAME=%u5EFA%u8BBE%u94F6%u884C&IDTYPE=01&TXCODE=520400&REMARK=VALUE&SUCCESS=Y
		Log4jUtil.info(logPrefix + "开始组待签名明文串。");
		final StringBuffer msgtmp = new StringBuffer("");
		msgtmp.append("MERCHANTID=").append(ccbB2CAccountVerifyBean.getMerchantid());
		msgtmp.append("&POSID=").append(ccbB2CAccountVerifyBean.getPosid());
		msgtmp.append("&BRANCHID=").append(ccbB2CAccountVerifyBean.getBranchid());
		msgtmp.append("&ACCOUNT=").append(ccbB2CAccountVerifyBean.getAccount());
		msgtmp.append("&IDNUM=").append(ccbB2CAccountVerifyBean.getIdnum());
		msgtmp.append("&UNAME=").append(ccbB2CAccountVerifyBean.getUname());
		msgtmp.append("&IDTYPE=").append(ccbB2CAccountVerifyBean.getIdtype());
		msgtmp.append("&TXCODE=").append(ccbB2CAccountVerifyBean.getTxcode());
		msgtmp.append("&REMARK=").append(ccbB2CAccountVerifyBean.getRemark());
		msgtmp.append("&SUCCESS=").append(ccbB2CAccountVerifyBean.getSuccess());
		return msgtmp.toString();
	}

	/**
	 * 对账户验证回执进行验签，并获取账户验证回执实体
	 * 
	 * @param logPrefix 日志前缀
	 * @param request 接受到的请求
	 * @param channelParam 渠道参数
	 * @param pub32FileName 公钥路径
	 * @param channelId 渠道ID
	 * @return
	 * @throws BizException
	 */
	public PayRspParam getAccountVerifyPayParm(final String logPrefix, final HttpServletRequest request,
			final String pub32FileName, final String channelId) throws BizException {
		final String pub32 = this.getPubKeyByFile(logPrefix, pub32FileName);
		String logMsg = "";
		logMsg = logPrefix + "进行账户验证回执处理。";
		Log4jUtil.info(logMsg);
		final CcbB2CAccountVerifyBean ccbB2CAccountVerifyBean = this.getServletAccountVerifyBean(logPrefix, request);
		final String data = creatServletAccountVerifySignSting(logPrefix, ccbB2CAccountVerifyBean);
		if (!verifySigature(logPrefix, ccbB2CAccountVerifyBean.getSign(), data, pub32)) {
			throw new BizException("验签失败，处理中止。");
		}
		final PayRspParam param = new PayRspParam();
		param.setSn(ccbB2CAccountVerifyBean.getRemark());
		param.setTransType(ClearingTransType.ONLINE_ACCOUNT_VERIFY);
		param.setChannelId(channelId);
		param.setCardType(BankCardType.CREDIT_CARD);
		param.setTranResult(ccbB2CAccountVerifyBean.getTxcode() + ccbB2CAccountVerifyBean.getSuccess());// 给渠道核心类转换给渠道返回码回调业务使用
		if (ccbB2CAccountVerifyBean.getSuccess().equals("Y")) {// 给业务使用
			param.setReturnState(PayState.SUCCEED_STR);
			param.setReturnMsg("成功");
		} else {
			param.setReturnState(PayState.FAILED_STR);
			param.setReturnMsg("失败");
		}
		ObjectUtil.printPropertyString(logPrefix, param);
		return param;
	}

	/**
	 * 生成支付实体
	 * 
	 * @param logPrefix 日志前缀
	 * @param merID 商户号
	 * @param httpParam 参数
	 * @param channelParam 渠道参数
	 * @return
	 * @throws BizException
	 */
	public CcbPayBean createCcbPayBean(final String logPrefix, final String merID, final HttpParam httpParam,
			final Map<String, String> channelParam, final String paySeqSn) throws BizException {
		String logMsg = "";
		final CcbPayBean ccbPayBean = new CcbPayBean();
		ccbPayBean.setPayUrl(channelParam.get("100005").trim());
		ccbPayBean.setMerchantid(merID);
		ccbPayBean.setPosid(channelParam.get("100002").trim());
		ccbPayBean.setBranchid(channelParam.get("100003").trim());
		ccbPayBean.setOrderid(paySeqSn);
		if (ccbPayBean.getOrderid() == null || ccbPayBean.getOrderid().length() < 1) {
			throw new BizException(logPrefix + "获取的订单号为空；");
		}
		ccbPayBean.setCurcode(channelParam.get("100009").trim());
		if (httpParam.getCustomerType().equals("2")) {
			ccbPayBean.setTxcode(channelParam.get("100007").trim());// 企业支付交易码
		} else {
			ccbPayBean.setTxcode(channelParam.get("100008").trim());// 个人支付交易码
		}
		final NetDeductDTO deduct = (NetDeductDTO) httpParam.getBizBean();
		logMsg = "获取" + logPrefix + "充值、支付对象。";
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, deduct);
		ccbPayBean.setSn(deduct.getTxnId());
		ccbPayBean.setPayment(String.format("%1$.2f", deduct.getAmount()));// 交易金额
		ccbPayBean.setRemark1(deduct.getOrderRemark());
		final String srcMsg = creatPaySignSting(logPrefix, ccbPayBean, channelParam.get("100010").trim(), channelParam
				.get("100004").trim());
		try {
			logMsg = logPrefix + "对明文数据:" + ccbPayBean.getMac() + " 进行加密。";
			Log4jUtil.info(logMsg);
			ccbPayBean.setMac(this.bintoascii(JDigest.digestMD5(srcMsg.getBytes())));
			logMsg = "发往 " + logPrefix + " 支付的签名信息为：" + ccbPayBean.getMac();
			Log4jUtil.info(logMsg);
		} catch (final NoSuchAlgorithmException e) {
			throw new BizException(logPrefix + " MD5加密出错:" + e);
		}
		ObjectUtil.printPropertyString(logPrefix, ccbPayBean);
		return ccbPayBean;
	}

	/**
	 * 生成支付待签名的明文数据
	 * 
	 * @param logPrefix 日志前缀
	 * @param ccbPayBean 实体
	 * @param channelParam 渠道参数
	 * @return
	 * @throws BizException
	 */
	private String creatPaySignSting(final String logPrefix, final CcbPayBean ccbPayBean, final String interfaceType,
			final String fileName) throws BizException {
		Log4jUtil.info(logPrefix + " 组明文数据。");
		final StringBuffer msgtmp = new StringBuffer("");
		msgtmp.append("MERCHANTID=").append(ccbPayBean.getMerchantid());
		msgtmp.append("&POSID=").append(ccbPayBean.getPosid());
		msgtmp.append("&BRANCHID=").append(ccbPayBean.getBranchid());
		msgtmp.append("&ORDERID=").append(ccbPayBean.getOrderid());
		msgtmp.append("&PAYMENT=").append(ccbPayBean.getPayment());
		msgtmp.append("&CURCODE=").append(ccbPayBean.getCurcode());
		msgtmp.append("&TXCODE=").append(ccbPayBean.getTxcode());
		msgtmp.append("&REMARK1=").append(ccbPayBean.getRemark1());
		msgtmp.append("&REMARK2=").append(ccbPayBean.getRemark2());
		if (interfaceType.trim().equals("new")) {
			// 若为新接口
			final String pub32 = this.getPubKeyByFile(logPrefix, fileName.trim()).substring(0, 30);// 公钥前30位
			msgtmp.append("&PUB32=").append(pub32);
		}
		final String ss = msgtmp.toString();
		Log4jUtil.info(logPrefix + " 明文数据：" + ss);
		return ss;

	}

	/**
	 * 生成账户验证对象
	 * 
	 * @param logPrefix 日志前缀
	 * @param merId 商户号
	 * @param httpParam 参数
	 * @param channelParam 渠道参数
	 * @return
	 * @throws BizException
	 */
	public CcbB2CAccountVerifyBean createAccountBean(final String logPrefix, final String merId,
			final HttpParam httpParam, final Map<String, String> channelParam) throws BizException {
		String logMsg = "";
		checkChannelParam(logPrefix, ClearingTransType.ONLINE_ACCOUNT_VERIFY, channelParam);
		final CcbB2CAccountVerifyBean ccbB2CAccountVerifyBean = new CcbB2CAccountVerifyBean();
		final BankCardVerifyDTO accountVerifyBill = (BankCardVerifyDTO) httpParam.getBizBean();
		if (accountVerifyBill == null) {
			throw new BizException(logPrefix + "获取到账户验证对象为NULL。处理中止。");
		}
		final String posid = channelParam.get("100002").trim();// 商户柜台代码
		final String branchid = channelParam.get("100003").trim();// 分行代码
		final String pub32path = channelParam.get("100004").trim();// 公钥路径
		final String verifyUrl = channelParam.get("100005").trim();
		final String txcode = channelParam.get("100011").trim();// 交易码
		final String ccb_ibsversion = channelParam.get("100012").trim();// IBSVersion
		final String account = accountVerifyBill.getBankCardNo();
		final String idnum = accountVerifyBill.getCertificateNo();
		final Escape escape = new Escape();
		final String uname = escape.escape(accountVerifyBill.getCardHolderName());
		String idtype = "01";
		if (accountVerifyBill.getCertificateType().equals("0")) {
			idtype = "01";
		}
		final String remark = accountVerifyBill.getTxnId();// 放流水

		final StringBuffer msgtmp = new StringBuffer("");
		msgtmp.append("MERCHANTID=").append(merId);
		msgtmp.append("&POSID=").append(posid);
		msgtmp.append("&BRANCHID=").append(branchid);
		msgtmp.append("&ACCOUNT=").append(account);
		msgtmp.append("&IDNUM=").append(idnum);
		msgtmp.append("&UNAME=").append(uname);
		msgtmp.append("&IDTYPE=").append(idtype);
		msgtmp.append("&REMARK=").append(remark);
		msgtmp.append("&TXCODE=").append(txcode);
		String srcData = "";
		String sign = "";
		final String pubKey = getPubKeyByFile(logPrefix, pub32path);
		if (pubKey == null || pubKey.length() < 1) {
			throw new BizException(logPrefix + "根据路径 " + pub32path + " 获取到的公钥非法；");
		}
		try {
			logMsg = "发往" + logPrefix + "账户验证的待加密串为：" + msgtmp.toString();
			Log4jUtil.info(logMsg);
			srcData = this.bintoascii(JDigest.digestMD5(msgtmp.toString().getBytes()));
			final EnByPubKey enByPubKey = new EnByPubKey();
			sign = enByPubKey.encryptByPublicKey(srcData, pubKey);
			logMsg = "发往" + logPrefix + "账户验证的签名信息为：" + sign;
			Log4jUtil.info(logMsg);
		} catch (final NoSuchAlgorithmException e) {
			logMsg = logPrefix + "账户验证加密出错！";
			Log4jUtil.error(logMsg, e);
			throw new BizException(logMsg + e);
		} catch (final Exception e) {
			logMsg = logPrefix + "账户验证加密出错！";
			Log4jUtil.error(logMsg, e);
			throw new BizException(logMsg + e);
		}
		ccbB2CAccountVerifyBean.setAccount(account);
		ccbB2CAccountVerifyBean.setBranchid(branchid);
		ccbB2CAccountVerifyBean.setCcb_ibsversion(ccb_ibsversion);
		ccbB2CAccountVerifyBean.setIdnum(idnum);
		ccbB2CAccountVerifyBean.setIdtype(idtype);
		ccbB2CAccountVerifyBean.setMerchantid(merId);
		ccbB2CAccountVerifyBean.setPosid(posid);
		ccbB2CAccountVerifyBean.setRemark(remark);
		ccbB2CAccountVerifyBean.setSign(sign);
		ccbB2CAccountVerifyBean.setTxcode(txcode);
		ccbB2CAccountVerifyBean.setUname(uname);
		ccbB2CAccountVerifyBean.setVerifyUrl(verifyUrl);
		ObjectUtil.printPropertyString(logPrefix, ccbB2CAccountVerifyBean);
		return ccbB2CAccountVerifyBean;
	}

	/**
	 * 生成银行所需要的参数
	 * 
	 * @param ccbPayBean
	 * @return
	 * @throws BizException
	 */
	public HttpReturnParam getPayHttpReturnParam(final CcbPayBean ccbPayBean) throws BizException {
		final HttpReturnParam hrp = new HttpReturnParam();
		hrp.setAction(ccbPayBean.getPayUrl());
		final Map<String, String> params = new HashMap<String, String>();
		params.put("MERCHANTID", ccbPayBean.getMerchantid());
		params.put("POSID", ccbPayBean.getPosid());
		params.put("BRANCHID", ccbPayBean.getBranchid());
		params.put("ORDERID", ccbPayBean.getOrderid());
		params.put("PAYMENT", ccbPayBean.getPayment());
		params.put("CURCODE", ccbPayBean.getCurcode());
		params.put("TXCODE", ccbPayBean.getTxcode());
		params.put("REMARK1", ccbPayBean.getRemark1());
		params.put("REMARK2", ccbPayBean.getRemark2());
		params.put("MAC", ccbPayBean.getMac());
		hrp.setParams(params);
		return hrp;
	}

	/**
	 * 生成银行所需要的参数
	 * 
	 * @param ccbB2CAccountVerifyBean
	 * @return
	 * @throws BizException
	 */
	public HttpReturnParam getAccountVerifyHttpReturnParam(final CcbB2CAccountVerifyBean ccbB2CAccountVerifyBean)
			throws BizException {
		final HttpReturnParam hrp = new HttpReturnParam();
		hrp.setAction(ccbB2CAccountVerifyBean.getVerifyUrl());
		final Map<String, String> params = new HashMap<String, String>();
		params.put("CCB_IBSVersion", ccbB2CAccountVerifyBean.getCcb_ibsversion());
		params.put("MERCHANTID", ccbB2CAccountVerifyBean.getMerchantid());
		params.put("POSID", ccbB2CAccountVerifyBean.getPosid());
		params.put("BRANCHID", ccbB2CAccountVerifyBean.getBranchid());
		params.put("ACCOUNT", ccbB2CAccountVerifyBean.getAccount());
		params.put("IDNUM", ccbB2CAccountVerifyBean.getIdnum());
		params.put("UNAME", ccbB2CAccountVerifyBean.getUname());
		params.put("IDTYPE", ccbB2CAccountVerifyBean.getIdtype());
		params.put("REMARK", ccbB2CAccountVerifyBean.getRemark());
		params.put("TXCODE", ccbB2CAccountVerifyBean.getTxcode());
		params.put("SIGN", ccbB2CAccountVerifyBean.getSign());
		hrp.setParams(params);
		return hrp;
	}
}