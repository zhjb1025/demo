package com.lycheepay.clearing.adapter.banks.ccb.http.bean;

public class CcbServletB2BPayBean {
	String mposid = "";
	String order_number = "";
	String cust_id = "";
	String acc_no = "";
	String acc_name = "";
	String amount = "";
	String status = "";       // 2：支付成功 3：支付成功 4：支付成功 5：交易失败 6：交易不确定
	String remark1 = "";
	String remark2 = "";
	String tran_flag = "";
	String tran_time = "";
	String branch_name = "";
	String signstring = "";
	String checkok = "";

	public String getMposid() {
		return mposid;
	}

	public void setMposid(final String mposid) {
		this.mposid = mposid;
	}

	public String getOrder_number() {
		return order_number;
	}

	public void setOrder_number(final String order_number) {
		this.order_number = order_number;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(final String cust_id) {
		this.cust_id = cust_id;
	}

	public String getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(final String acc_no) {
		this.acc_no = acc_no;
	}

	public String getAcc_name() {
		return acc_name;
	}

	public void setAcc_name(final String acc_name) {
		this.acc_name = acc_name;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(final String amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public String getRemark1() {
		return remark1;
	}

	public void setRemark1(final String remark1) {
		this.remark1 = remark1;
	}

	public String getRemark2() {
		return remark2;
	}

	public void setRemark2(final String remark2) {
		this.remark2 = remark2;
	}

	public String getTran_flag() {
		return tran_flag;
	}

	public void setTran_flag(final String tran_flag) {
		this.tran_flag = tran_flag;
	}

	public String getTran_time() {
		return tran_time;
	}

	public void setTran_time(final String tran_time) {
		this.tran_time = tran_time;
	}

	public String getBranch_name() {
		return branch_name;
	}

	public void setBranch_name(final String branch_name) {
		this.branch_name = branch_name;
	}

	public String getSignstring() {
		return signstring;
	}

	public void setSignstring(final String signstring) {
		this.signstring = signstring;
	}

	public String getCheckok() {
		return checkok;
	}

	public void setCheckok(final String checkok) {
		this.checkok = checkok;
	}

}
