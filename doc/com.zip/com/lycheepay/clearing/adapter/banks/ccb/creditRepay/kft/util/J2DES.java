package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util;

import java.nio.charset.Charset;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import com.lycheepay.clearing.adapter.common.util.security.Base64;
import com.lycheepay.clearing.util.Log4jUtil;


  

/**
 * 双倍长密钥算法
 * 
 * @author aps-txy
 * @date 2011-11-1
 */
public class J2DES {  
  
    static String DES = "DES/ECB/NoPadding";  
    static String TriDes = "DESede/ECB/NoPadding";  
  
    public static byte[] des_crypt(byte key[], byte data[]) {  
  
        try {  
            KeySpec ks = new DESKeySpec(key);  
            SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");  
            SecretKey ky = kf.generateSecret(ks);  
  
            Cipher c = Cipher.getInstance(DES);  
            c.init(Cipher.ENCRYPT_MODE, ky);  
            return c.doFinal(data);  
        } catch (Exception e) {  
			Log4jUtil.error(e);
            return null;  
        }  
    }  
  
    public static byte[] des_decrypt(byte key[], byte data[]) {  
  
        try {  
            KeySpec ks = new DESKeySpec(key);  
            SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");  
            SecretKey ky = kf.generateSecret(ks);  
  
            Cipher c = Cipher.getInstance(DES);  
            c.init(Cipher.DECRYPT_MODE, ky);  
            return c.doFinal(data);  
        } catch (Exception e) {  
			Log4jUtil.error(e);
            return null;  
        }  
    }  
  
    /**
	 * 
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 */
    public static byte[] trides_crypt(byte key[], byte data[]) {  
        try {  
            byte[] k = new byte[24];  
  
            int len = data.length;  
            if(data.length % 8 != 0){  
                len = data.length - data.length % 8 + 8;  
            }  
            byte [] needData = null;  
            if(len != 0)  
                needData = new byte[len];  
              
            for(int i = 0 ; i< len ; i++){  
                needData[i] = 0x00;  
            }  
              
            System.arraycopy(data, 0, needData, 0, data.length);  
              
            if (key.length == 16) {  
                System.arraycopy(key, 0, k, 0, key.length);  
                System.arraycopy(key, 0, k, 16, 8);  
            } else {  
                System.arraycopy(key, 0, k, 0, 24);  
            }  
  
            KeySpec ks = new DESedeKeySpec(k);  
            SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");  
            SecretKey ky = kf.generateSecret(ks);  
  
            Cipher c = Cipher.getInstance(TriDes);  
            c.init(Cipher.ENCRYPT_MODE, ky);  
            return c.doFinal(needData);  
        } catch (Exception e) {  
			Log4jUtil.error(e);
            return null;  
        }  
  
    }  
  
    /**
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 */
    public static byte[] trides_decrypt(byte key[], byte data[]) {  
        try {  
            byte[] k = new byte[24];  
  
            int len = data.length;  
            if(data.length % 8 != 0){  
                len = data.length - data.length % 8 + 8;  
            }  
            byte [] needData = null;  
            if(len != 0)  
                needData = new byte[len];  
              
            for(int i = 0 ; i< len ; i++){  
                needData[i] = 0x00;  
            }  
              
            System.arraycopy(data, 0, needData, 0, data.length);  
              
            if (key.length == 16) {  
                System.arraycopy(key, 0, k, 0, key.length);  
                System.arraycopy(key, 0, k, 16, 8);  
            } else {  
                System.arraycopy(key, 0, k, 0, 24);  
            }  
            KeySpec ks = new DESedeKeySpec(k);  
            SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");  
            SecretKey ky = kf.generateSecret(ks);  
  
            Cipher c = Cipher.getInstance(TriDes);  
            c.init(Cipher.DECRYPT_MODE, ky);  
            return c.doFinal(needData);  
        } catch (Exception e) {  
			Log4jUtil.error(e);
            return null;  
        }  
  
    }  
  
	public static void main(String[] args) {
		String str = "<amount>100000</amount><billno>2032010092003015023122380100</billno><cardid>6270670259999100</cardid><cmd>CROQ</cmd><curtype>156</curtype><date>20</date><liquidate>20</liquidate><msgno>09201217430301502312238010000000</msgno><orgcode>0000</orgcode><payaccount></payaccount><time>2010-09-20 12:17:44</time><timestamp>1284956264</timestamp><validdate></validdate><verifycode></verifycode><verifytype></verifytype><sign>FA91D910F5789EBE19679185E1EE4757</sign>";
		byte[] org = J2DES.trides_crypt(J2DES.hexStr2Bytes("12345678901234567890123456789012"), str.getBytes(Charset.forName("GBK")));
		String enStr = "";
		try {
			enStr = String.valueOf(Base64.encode(org));
			System.out.println(enStr);
		} catch (Exception e) {
			Log4jUtil.error(e);
		}
	} 
  
    public static byte[] hexToBytes(String str) {  
        if (str == null) {  
            return null;  
        } else if (str.length() < 2) {  
            return null;  
        } else {  
            int len = str.length() / 2;  
            byte[] buffer = new byte[len];  
            for (int i = 0; i < len; i++) {  
                buffer[i] = (byte) Integer.parseInt(str.substring(i * 2,  
                        i * 2 + 2), 16);  
            }  
            return buffer;  
        }  
    }
    
	public static byte[] hexStr2Bytes(String src) {
		int m = 0, n = 0;
		int l = src.length() / 2;
		byte[] ret = new byte[l];
		for (int i = 0; i < l; i++) {
			m = i * 2 + 1;
			n = m + 1;
			ret[i] = uniteBytes(src.substring(i * 2, m), src.substring(m, n));
		}
		return ret;
	}
	
	
	private static byte uniteBytes(String src0, String src1) {
		byte b0 = Byte.decode("0x" + src0).byteValue();
		b0 = (byte) (b0 << 4);
		byte b1 = Byte.decode("0x" + src1).byteValue();
		byte ret = (byte) (b0 | b1);
		return ret;
	}
	
    /**
     * 
     * @param b
     * @return
     */
	public static String byte2hex(byte[] b) {
		String hs = "";
		String stmp = "";
		for (int i = 0; i < b.length; i++) {
			stmp = Integer.toHexString(b[i] & 0xFF);
			if (stmp.length() == 1) {
				hs += "0" + stmp;
			} else {
				hs += stmp;
			}
		}
		return hs.toUpperCase();
	}
}  
