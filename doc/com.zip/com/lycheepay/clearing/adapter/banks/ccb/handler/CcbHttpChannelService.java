/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-2-24 下午5:10:13
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccb.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.http.b2c.CcbHttpDirectProcess;
import com.lycheepay.clearing.adapter.banks.ccb.http.b2c.CcbHttpProcessor;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.common.dto.trade.NetResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行网银HTTP((不区分B2B\B2C))清算服务入口类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午3:32:34
 */
@Service(ClearingAdapterAnnotationName.CCB_HTTP_CHANNEL_SERVICE)
public class CcbHttpChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_HTTP_PROCESSOR)
	private CcbHttpProcessor ccbHttpProcessor;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_HTTP_DIRECT_PROCESS)
	private CcbHttpDirectProcess ccbHttpDirectProcess;
	public final static String channelId = ChannelIdEnum.CCB_INTERNET.getCode();

	/**
	 * PS.网银B2C代扣
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#onlineDeduct(com.lycheepay.clearing.common.dto.trade.NetDeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public NetResultDTO onlineDeduct(final NetDeductDTO deduct) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CCB", "online");
		final HttpParam httpParam = new HttpParam();
		httpParam.setChannelId(channelId);
		httpParam.setClearingTransType(ClearingTransType.NET_DEDUCT);
		httpParam.setCustomerType(deduct.getAccountType());
		httpParam.setBizBean(deduct);
		HttpReturnParam httpReturnParam;
		try {
			httpReturnParam = ccbHttpProcessor.onlineDeduct(httpParam);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}
		final NetResultDTO httpProcessChannelResult = new NetResultDTO();
		httpProcessChannelResult.setActionUrl(httpReturnParam.getAction());
		httpProcessChannelResult.setParams(httpReturnParam.getParams());
		return httpProcessChannelResult;
	}

	/**
	 * PS.网银账户验证
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#onlineAccountVerify(com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public NetResultDTO onlineAccountVerify(final BankCardVerifyDTO accountVerify)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CCB", "online");
		final HttpParam httpParam = new HttpParam();
		httpParam.setChannelId(channelId);
		httpParam.setClearingTransType(ClearingTransType.ONLINE_ACCOUNT_VERIFY);
		httpParam.setBizBean(accountVerify);
		HttpReturnParam httpReturnParam;
		try {
			httpReturnParam = ccbHttpProcessor.onlineAccountVerify(httpParam);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}

		final NetResultDTO httpProcessChannelResult = new NetResultDTO();
		httpProcessChannelResult.setActionUrl(httpReturnParam.getAction());
		httpProcessChannelResult.setParams(httpReturnParam.getParams());
		return httpProcessChannelResult;
	}

	// /**
	// * PS.批量退款
	// *
	// * @see
	// com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#batchRefund(com.lycheepay.clearing.common.dto.BatchRefundChannelDTO)
	// * @author 邱林 Leon.Qiu
	// */
	// @Override
	// public BatchRefundResultDTO batchRefund(final BatchRefundChannelDTO batchRefundDTO)
	// throws ClearingAdapterBizCheckedException {
	// Log4jUtil.setLogClass("CCB", "online");
	// final Param param = new Param();
	// param.setChannelId(batchRefundDTO.getChannelId());
	// param.setChannelTransType(ChannelTransType.PayRefund);
	// param.setTransType(batchRefundDTO.getTransType());
	// param.setRepeatFlag(batchRefundDTO.getRepeatFlag());
	// param.setRefundType(batchRefundDTO.getRefundType());
	//
	// final BatchRefund batchRefund = new BatchRefund();
	// batchRefund.setId(new BatchRefundId(batchRefundDTO.getRefundNetNo(),
	// batchRefundDTO.getRefundType(),
	// batchRefundDTO.getChannelId()));
	// param.setBizBean(batchRefund);
	//
	// ReturnState returnState;
	// try {
	// returnState = ccbHttpDirectProcess.batchRefund(param);
	// } catch (final BizException e) {
	// throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null,
	// e.getMessage());
	// }
	//
	// final BatchRefundResultDTO refundResultDTO = new BatchRefundResultDTO();
	// refundResultDTO.setChannelCode(returnState.getChannelCode());
	// refundResultDTO.setRefundType(batchRefundDTO.getRefundType());
	// refundResultDTO.setReturnState(returnState.getReturnState());
	// refundResultDTO.setSn(returnState.getSn());
	// final Object returnObj = returnState.getReturnObj();
	// if (returnObj != null && returnObj instanceof List) {
	// refundResultDTO.setFileNames((List<?>) returnObj);
	// }
	//
	// return refundResultDTO;
	// }

}
