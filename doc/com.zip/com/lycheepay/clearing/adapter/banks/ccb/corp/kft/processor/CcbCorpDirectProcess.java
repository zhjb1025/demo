package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.processor;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Node;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util.CcbCorpProcessXmlService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.biz.GeneratorAccountDetailFile;
import com.lycheepay.clearing.common.constant.AccountTransType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.AccountHistoryTransDetailDTO;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.ChannelBatch;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>建设银行银企直连请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-21 下午4:42:31
 */
@Service(ClearingAdapterAnnotationName.CCB_CORP_DIRECT_PROCESS)
public class CcbCorpDirectProcess extends BaseWithoutAuditLogService {

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	// 清算交易工具
	// @Autowired
	// @Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	// private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CORP_PROCESS_XML_SERVICE)
	private CcbCorpProcessXmlService ccbCorpProcessXmlService;

	// 银行备付金账户
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	private CcbCorpService ccbCorpService;

	public static final String recMoney = "01";// 快付通单笔实时收款
	public static final String payMoney = "02";// 快付通单笔实时付款

	private static final String channelId = ChannelIdEnum.CCB_CORP.getCode();

	/**
	 * <p>建设银行银企实时代扣/收</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午4:45:58
	 */
	public ReturnState directDeduct(final Param param) throws BizException {
		Log4jUtil.info(channelId + "ChannelTransType===" + param.getClearingTransType());
		return deal6W1303(param, recMoney);
	}

	/**
	 * <p>建设银行银企实时代付</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午4:49:51
	 */
	public ReturnState directPay(final Param param) throws BizException {
		Log4jUtil.info(channelId + "ChannelTransType===" + param.getClearingTransType());
		return deal6W1303(param, payMoney);
	}

	/**
	 * 单笔代扣代付处理6W1303
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	private ReturnState deal6W1303(final Param param, final String transType) throws BizException {
		final String bankSendSn = sequenceManagerService.getCorpCCBSN(new Date());// 渠道发送流水
		// 创建请求
		final String sendXml = ccbCorpProcessXmlService.create6W1303XML(param, bankSendSn, transType);
		// 发送请求
		String respXml = ccbCorpProcessXmlService.sendXML(sendXml);
		// 解析应答并处理
		return ccbCorpProcessXmlService.parse6W1303XML(respXml, param, bankSendSn, transType);
	}

	/**
	 * <p>建行银企账户验证(发送了6102报文,据注释应与同为基金验证方式)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-21 下午5:05:06
	 */
	public ReturnState accountVerify(final Param param) throws BizException {
		Log4jUtil.info(channelId + "ChannelTransType===" + param.getClearingTransType());
		// 创建请求，获取应答
		final String respXml = ccbCorpProcessXmlService.createFundXML6102(param);
		if (respXml == null) {
			throw new BizException(TransReturnCode.code_9109, "建行银企账号验证返回异常：" + respXml);
		}
		// 解析应答并处理
		return ccbCorpProcessXmlService.parseFundXML6112(respXml, param);
	}

	/**
	 * <p>批量业务处理(批量代付/批量代扣/批量退款)</p>
	 * 
	 * @param payList
	 * @param repeatSend
	 * @author 李斌(13665100450)
	 * @throws BizException
	 */
	public BatchSendResult processBatch(String batchId, final List<ChannelTempBill> payList, final boolean repeatSend)
			throws BizException {
		// final String batchId = sequenceManager.getCorpCCBSN(new Date());// 渠道发送批次号
		final String batchFileName = DateUtil.getCurrentDate() + "_" + batchId + ".TXT";// 本地批量文件名

		// 创建请求
		String sendXml = null;
		try {
			sendXml = ccbCorpProcessXmlService.create6W2100XML(payList, batchId, batchFileName, repeatSend);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "批量报文创建异常：");
		}
		Log4jUtil.debug(sendXml);
		// 发送请求获取应答
		final String respXml = ccbCorpProcessXmlService.sendXML(sendXml);
		Log4jUtil.debug(respXml);
		// 解析应答
		return ccbCorpProcessXmlService.parse6W2100XML(respXml, payList.get(0), batchId, repeatSend);
	}

	// /**
	// * 全国批量代发代扣交易6W2100
	// *
	// * @param param
	// * @return 处理结果
	// * @throws BizException
	// */
	// private ReturnState deal6W2100(final Param param) throws BizException {
	// final String batchId = sequenceManagerService.getCorpCCBSN(new Date());// 渠道发送批次号
	// final String batchFileName = DateUtil.getCurrentDate() + "_" + batchId + ".TXT";// 本地批量文件名
	// // 创建请求
	// final String sendXml = corpCcbService.deal6W2100(param, batchId, batchFileName);
	// Log4jUtil.debug(sendXml);
	// // 发送请求获取应答
	// final String respXml = ccbCorpProcessXmlService.sendXML(sendXml);
	// Log4jUtil.debug(respXml);
	// // 解析应答
	// return corpCcbService.parse6W2100(param, respXml, batchId);
	// }
	//
	// /**
	// * 单笔交易查询6W1503
	// *
	// * @param param
	// * @return
	// * @throws BizException
	// */
	// private ReturnState deal6W1503(final Param param) throws BizException {
	// // 创建请求
	// final String sendXml = ccbCorpProcessXmlService.create6W1503XML(param);
	// Log4jUtil.debug(sendXml);
	// // 发送请求,获取应答
	// final String respXml = ccbCorpProcessXmlService.sendXML(sendXml);
	// Log4jUtil.debug(respXml);
	// // 解析应答并处理
	// return ccbCorpProcessXmlService.parse6W1503XML(respXml, param);
	// }

	/**
	 * 批量交易结果查询
	 * 
	 * @throws BizException
	 */
	public void batchRetProcess() throws BizException {
		List<ChannelBatch> batchList = new ArrayList<ChannelBatch>();
		batchList = channelBatchService.getCorpBatchList(channelId);
		Log4jUtil.info("建行银企要查询的批理业务交易结果的批次号start");
		for (int i = 0; i < batchList.size(); i++) {
			Log4jUtil.info("批次号 " + (i + 1) + " : " + batchList.get(i).getId().getChannelBatchid());
		}
		Log4jUtil.info("建行银企要查询的批理业务交易结果的批次号end");
		Log4jUtil.info("建行银企批理交易结果处理开始");
		for (int i = 0, j = batchList.size(); i < j; i++) {
			Log4jUtil.info("批次号：" + batchList.get(i).getId().getChannelBatchid() + "的交易结果查询开始");
			ccbCorpService.deal6W2104(batchList.get(i).getId().getChannelBatchid());
			Log4jUtil.info("批次号：" + batchList.get(i).getId().getChannelBatchid() + "的交易结果查询结束");
		}
		Log4jUtil.info("建行银企批理交易结果处理完成");
	}

	/**
	 * 查询余额
	 * 
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 */
	public Balance queryBanlance(String accountNo) throws BizException {
		Balance balanceDTO = new Balance();
		final String bankSendSn = sequenceManagerService.getCorpCCBSN(new Date());// 渠道发送流水
		String reqXML = ccbCorpProcessXmlService.create6W0100XML(bankSendSn,accountNo);
		String respXml = ccbCorpProcessXmlService.sendXML(reqXML);
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respXml.getBytes(Charset.forName("GBK")));// 解析应答报文
		final Node nodeRoot = dom4jxml.getNode("/TX");
		String respCode = dom4jxml.getNodeText(nodeRoot, "RETURN_CODE");
		String respMsg = dom4jxml.getNodeText(nodeRoot, "RETURN_MSG");
		if ("000000".equals(respCode)) {// 查询成功
			final Node nodeItem = dom4jxml.getNode("/TX/TX_INFO");
			final String accNo = dom4jxml.getNodeText(nodeItem, "ACC_NO"); // 帐户号
			final String balance = dom4jxml.getNodeText(nodeItem, "BALANCE");// 余额
			final String availBanlace = dom4jxml.getNodeText(nodeItem, "BALANCE1"); // 可用余额
			Log4jUtil.info("建行银企账号:{}，余额:{},可用余额:{}", accNo, balance, availBanlace);
			balanceDTO.setAccNo(accNo);
			balanceDTO.setBalance(balance);
			balanceDTO.setAvailBanlace(availBanlace);
		} else {
			balanceDTO.setErrorMsg(respCode + ":" + respMsg);
			Log4jUtil.info("查询建行银企余额失败:{},{}", respCode, respMsg);
		}
		return balanceDTO;
	}

	public ClearingResultDTO accountVerify(BankCardVerifyDTO accountVerify) {
		ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
		final String bankSendSn = sequenceManagerService.getCorpCCBSN(new Date());// 渠道发送流水
		try {
			String reqXML = ccbCorpProcessXmlService.create6W1101XML(bankSendSn, accountVerify.getBankCardNo(),
					accountVerify.getCardHolderName());
			String respXml = ccbCorpProcessXmlService.sendXML(reqXML);
			final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respXml.getBytes(Charset.forName("GBK")));// 解析应答报文
			final Node nodeRoot = dom4jxml.getNode("/TX");
			String respCode = dom4jxml.getNodeText(nodeRoot, "RETURN_CODE");
			String respMsg = dom4jxml.getNodeText(nodeRoot, "RETURN_MSG");
			if ("000000".equals(respCode)) {// 查询成功
				final Node nodeItem = dom4jxml.getNode("/TX/TX_INFO");
				final String isRight = dom4jxml.getNodeText(nodeItem, "IS_RIGHT"); // 0-匹配 1-不匹配
				Log4jUtil.info("isRight:{}", isRight);
				if ("0".equals(isRight)) {
					clearingResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
					clearingResultDTO.setChannelResponseMsg("校验成功");
					clearingResultDTO.setTxnStatus(TxnStatus.SUCCEED);
				} else {
					clearingResultDTO.setChannelResponseCode(TransReturnCode.code_2005);
					clearingResultDTO.setChannelResponseMsg("账号户名不符");
					clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
				}
			} else {
				Log4jUtil.info("账号、户名是否匹配校验交易失败  :{},{}", respCode, respMsg);
				clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				clearingResultDTO.setChannelResponseMsg(respMsg);
				clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
			}
		} catch (Exception e) {
			Log4jUtil.error(e);
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			clearingResultDTO.setChannelResponseMsg("校验失败");
			clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
		}
		return clearingResultDTO;
	}

	/**
	 * 获取账户历史明细
	 * 
	 * @param date 查询日期
	 * @param accountNo 账号 ，如果过没有，默认为该渠道结算账户
	 * @param filePath 明细文件保存路径,比如//home/admin/sharedata/recon/historyDetail/
	 * @return
	 * @author 张凯锋
	 */
	public String queryAccountHistoryTransDetail(String date, String accountNo, String filePath)
			throws BizException {
		List<AccountHistoryTransDetailDTO> list = new ArrayList<AccountHistoryTransDetailDTO>();
		String queryDate = StringUtils.isBlank(date) ? DateUtil.getCurrentChnDateFront() : date;
		boolean hasNextPage = true;
		int pageCt = 0;
		int pageNo = 1;
		while (hasNextPage) {

			String sendXml = ccbCorpProcessXmlService.create6W0300XML(String.valueOf(pageNo++), accountNo, queryDate);
			Log4jUtil.info("查询{}请求xml:{}", queryDate, sendXml);
			String respXml = ccbCorpProcessXmlService.sendXML(sendXml);
			// 解析xml报文
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respXml.getBytes(Charset.forName("GBK")));
			String curPage = dom4jxml.getNodeText("/TX/TX_INFO/CUR_PAGE");// 当前页次
			String pageCount = dom4jxml.getNodeText("/TX/TX_INFO/PAGE_COUNT");// 总页次
			if (pageNo == 2) {
				pageCt = Integer.valueOf(pageCount).intValue();
			}
			if (pageCt == Integer.valueOf(curPage).intValue())
				hasNextPage = false;
			// 获取xml中节点的到账记录
			List<Node> nodeItemList = dom4jxml.getNodeList("/TX/TX_INFO/DETAIL");
			int size = nodeItemList.size();
			for (int i = 0; i < size; i++) {
				Node nodeItem = nodeItemList.get(i);
				String creditType = dom4jxml.getNodeText(nodeItem, "CREDIT_TYPE");// 凭证种类
				String creditNo = dom4jxml.getNodeText(nodeItem, "CREDIT_NO");// 凭证号码
				String tranDate = dom4jxml.getNodeText(nodeItem, "TRAN_DATE");// 交易时间
				String tranTime = dom4jxml.getNodeText(nodeItem, "TRAN_TIME");// 交易时间
				String amount =  dom4jxml.getNodeText(nodeItem, "AMOUNT") ;// 发生金额
				String balance =  dom4jxml.getNodeText(nodeItem, "BALANCE") ;// 余额
				String dORc = dom4jxml.getNodeText(nodeItem, "dORc").toString();//借贷标志 0:借 1:贷  
				String accNo1 = dom4jxml.getNodeText(nodeItem, "ACC_NO1");// 对方账号
				String accName1 = dom4jxml.getNodeText(nodeItem, "ACC_NAME1");// ACC_NAME1
				String individual1 = dom4jxml.getNodeText(nodeItem, "INDIVIDUAL1");// 自定义输出内容1
				String abstract_ = dom4jxml.getNodeText(nodeItem, "ABSTRACT");// 摘要
				String paySeqNum = dom4jxml.getNodeText(nodeItem, "PAY_SEQ_NUM");// 企业流水号
				AccountHistoryTransDetailDTO detailDTO = new AccountHistoryTransDetailDTO();
				detailDTO.setAccName1(accName1);
				detailDTO.setAccNo1(accNo1);
				detailDTO.setAmount(amount);
				detailDTO.setBalance(balance);
				detailDTO.setCreditNo(creditNo);
				detailDTO.setCreditType(creditType);
				detailDTO.setdORc("1".equals(dORc) ? GeneratorAccountDetailFile.GET : GeneratorAccountDetailFile.PAY);
				detailDTO.setIndividual1(individual1);
				detailDTO.setIndividual2(abstract_);
				detailDTO.setPaySeqNum(paySeqNum);
				detailDTO.setTranDate(StringUtils.replace(tranDate, "/", ""));
				detailDTO.setTranTime(StringUtils.replace(tranTime, ":", ""));
				if ("其他".equalsIgnoreCase(abstract_)) {
					detailDTO.setType(AccountTransType.single_trans.getCode());
				} else if (detailDTO.getAccName1().startsWith("手续费")) {
					detailDTO.setType(AccountTransType.fee.getCode());
				} else if ("结息".equalsIgnoreCase(abstract_)) {
					detailDTO.setType(AccountTransType.iint.getCode());
				} else {
					if (bankAccountBalanceService.selectAllSettlementAccountNo().containsKey(detailDTO.getAccNo1())) {
						detailDTO.setType(AccountTransType.zjdb.getCode());
					} else {
						detailDTO.setType(AccountTransType.others.getCode());
					}
				}
				list.add(detailDTO);
			}
		}
		String accNo = accountNo;
		if (StringUtils.isBlank(accountNo)) {
			BankaccountBalance bankaccountBean = bankAccountBalanceService.getBankaccountBean(channelId);
			accNo = bankaccountBean.getAccountNo();
		}
		GeneratorAccountDetailFile.createReconciliationFile(filePath, accNo, queryDate, list);
		return "S";
	}

	// /**
	// * 单笔交易查询6W1501单据处理
	// *
	// * @param param
	// * @return
	// * @throws BizException
	// */
	// private ReturnState deal6W0501(final Param param) throws BizException {
	// // 创建请求
	// final String sendXml = ccbCorpProcessXmlService.create6W0501XML(param);
	// Log4jUtil.debug(sendXml);
	// // 发送请求,获取应答
	// final String respXml = ccbCorpProcessXmlService.sendXML(sendXml);
	// Log4jUtil.debug(respXml);
	// // 解析应答并处理
	// return new ReturnState();
	// }

}
