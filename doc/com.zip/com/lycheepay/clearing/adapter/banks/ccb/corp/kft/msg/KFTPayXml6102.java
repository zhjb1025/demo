package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg;

import org.dom4j.Element;
import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


public class KFTPayXml6102 extends KFTPayXmlBase {

	private String sn = "";
	private String acctNo = "";
	private String acctName = "";
	private String idType = "";
	private String idNo = "";

	public KFTPayXml6102() {
		super();
	}

	/**
	 * <p>Method for constructor</p>
	 * 
	 * @param init
	 * @param msgSeqId(PS.By:Leon.Qiu
	 *            由于super方法中需要加入报文序列号,因此需要在调用方传入:sequenceManagerService.getMsgId(DateUtil
	 *            .getCurrentDate())
	 */
	public KFTPayXml6102(final boolean init, final String msgSeqId) {
		super(init, msgSeqId);
	}

	@Override
	protected void buildxmlbody() {
		// TODO Auto-generated method stub
		Element newElement = dom4jxml.addNode(dom4jxml.getRoot(), "MSG", "");
		newElement = dom4jxml.addNode(newElement, "AcctVerifyApply6102", "");
		dom4jxml.addNode(newElement, "SN", sn);
		dom4jxml.addNode(newElement, "AcctNo", acctNo);
		dom4jxml.addNode(newElement, "AcctName", acctName);
		dom4jxml.addNode(newElement, "IDType", idType);
		dom4jxml.addNode(newElement, "IDNo", idNo);
	}

	@Override
	protected void parsexmlbody() throws BizException {
		// TODO Auto-generated method stub

		if (!this.getHead().getMsgCode().equals("6102")) {
			throw new BizException("MsgCode不为6102");
		}
		final Node node = dom4jxml.getNode("/KFT/MSG/AcctVerifyApply6102");
		if (node == null) {
			throw new BizException("9102", "报文格式错！");
		}
		sn = dom4jxml.getNodeText(node, "SN");
		acctNo = dom4jxml.getNodeText(node, "AcctNo", 1, 32, "X");
		acctName = dom4jxml.getNodeText(node, "AcctName", 1, 80, "G");
		idType = dom4jxml.getNodeText(node, "IDType", 0, 1, "X");
		idNo = dom4jxml.getNodeText(node, "IDNo", 0, 60, "X");

		AssertUtils.notEmpty(sn, "9303", "报文SN区为空，请检查");
		AssertUtils.notEmpty(acctNo, "9303", "报文AcctNo区为空，请检查");
		AssertUtils.notEmpty(acctName, "9303", "报文AcctName区为空，请检查");

		AssertUtils.checkXChar(acctNo, "9303", "报文AcctNo区");

		/*List<String> certTypeList = new ArrayList<String>();
		certTypeList.add("0");
		AssertUtils.checkContain(certType, certTypeList, "9303", "报文CertType区");

		List<String> flagList = new ArrayList<String>();
		flagList.add("0");
		flagList.add("1");
		AssertUtils.checkContain(cmdFlag, flagList, "9303", "报文CmdFlag区");*/

	}

	public String getSn() {
		return sn;
	}

	public void setSn(final String sn) {
		this.sn = sn;
	}

	public String getAcctNo() {
		return acctNo;
	}

	public void setAcctNo(final String acctNo) {
		this.acctNo = acctNo;
	}

	public String getAcctName() {
		return acctName;
	}

	public void setAcctName(final String acctName) {
		this.acctName = acctName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(final String idType) {
		this.idType = idType;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(final String idNo) {
		this.idNo = idNo;
	}

}
