package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.util.TranProcess;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.security.Base64;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <p> Description:提供给JKS文件,和CRT证书文件的签名、验证 </p> <p> Copyright: Copyright (c) 2011 </p>
 * 
 * @author 加密、解密、签名、验证工具类
 */
public class CryptorJKS {

	private static final String alg = "MD5withRSA";// MD5withRSA SHA1withRSA

	private static PrivateKey privateKey = null;

	// MD5算法
	public static byte[] md5(byte[] input) {
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			return md.digest(input);
		} catch (Exception ex) {
			return null;
		}
	}

	public static void main(String[] args) throws BizException, IOException, CertificateException {
		String strJKS = "C:\\temp3\\kft.jks";
		String strCrt = "C:\\temp3\\kft.crt";

		TranProcess tp = new TranProcess();
		String msg = "";
		try {
			msg = tp.readFile("c:/temp1/kft_RepayTotal_20120814_2012081406.csv");
		} catch (Exception e) {
			Log4jUtil.error(e);
		}
		String signMsg = "";
		signMsg = sign(msg, strJKS, "000000", "kft");

		System.out.println(signMsg);
		char[] cs = signMsg.toCharArray();
		byte[] org = Base64.decode(cs);
		String signMsg2 = bytesToHexString(org);
		System.out.println(verify(strCrt, msg, signMsg2));
	}

	public static void main2(String[] args) {
		String strJKS = "C:\\temp2\\kft.keystore";
		String filePath = "c:/temp1/kft_RepayTotal_20120814_2012081402.csv";
		TranProcess tp = new TranProcess();
		String summaryFileData;
		try {
			summaryFileData = tp.readFile(filePath);
			System.out.println(summaryFileData);
			String signMsg = "";
			MD5 m = new MD5();

			signMsg = sign(m.md5s(summaryFileData), strJKS, "123456", "kft");
			System.out.println(signMsg);

		} catch (Exception e) {
			Log4jUtil.error(e);
		}
	}

	/**
	 * 
	 * @description：
	 * @param message
	 * @param resourcePath
	 * @param password
	 * @param alias .
	 * @return
	 * @throws BizException
	 * @version: 2012-6-18
	 * @throws IOException
	 * @See:
	 */
	public static String sign(String message, String resourcePath, String password, String alias) throws BizException,
			IOException {
		if (privateKey == null) {
			InputStream input = null;
			try {
				input = new FileInputStream(resourcePath);
				privateKey = getPrivateKey(input, password, alias);
			} finally {
				if (input != null) {
					input.close();
				}
			}
		}
		try {
			byte[] msg = sign(alg, privateKey, string2Bytes(message));
			return new String(Base64.encode(msg));
			// return bytesToHexString(msg);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 签名 message: 明文 keyFile: 私钥文件 passwd: 私钥密码 alias: 私钥别名
	 * 
	 * @throws BizException
	 */
	public static String sign(String message, InputStream inputStream, String passwd, String alias)
			throws InvalidKeyException, SignatureException, BizException {
		try {

			// Debug.out("message:"+message);
			PrivateKey key = getPrivateKey(inputStream, passwd, alias);
			String alg = "MD5withRSA";
			byte[] msg = string2Bytes(message);
			byte[] out = sign(alg, key, msg);
			return bytesToHexString(out);
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}

	/**
	 * 签名 alg: 签名算法 pk: 私钥对象 message: 明文
	 */
	public static byte[] sign(String alg, PrivateKey pk, byte[] message) throws InvalidKeyException,
			NoSuchAlgorithmException, SignatureException {
		Signature s = Signature.getInstance(alg);
		s.initSign(pk);
		s.update(message);

		return s.sign();
	}

	/**
	 * 验证签名 certData: 证书二进制数据 message: 明文 signature: 签名
	 */
	public static boolean verify(byte[] certData, String message, String signature) throws CertificateException {
		String alg = "MD5withRSA";
		Certificate cert = createCertificate(certData, true);
		byte[] msg = string2Bytes(message);
		return verify(alg, cert, msg, hexStringToBytes(signature));
	}

	/**
	 * 验证签名 certFile: 证书文件 message: 明文 signature: 签名
	 */
	public static boolean verify(String certFile, String message, String signature) throws CertificateException {
		String alg = "MD5withRSA";
		Certificate cert = createCertificate(certFile);
		byte[] msg = string2Bytes(message);
		return verify(alg, cert, msg, hexStringToBytes(signature));
	}

	/**
	 * 签名验证 alg: 签名算法 pk：公钥 message: 明文 signature: 签名
	 */
	public static boolean verify(String alg, PublicKey pk, byte[] message, byte[] signature) {
		try {
			Signature s = Signature.getInstance(alg);
			s.initVerify(pk);
			s.update(message);
			return s.verify(signature);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 根据证书文件返回证书对象
	 */
	public static Certificate createCertificate(String certfile) throws CertificateException {
		try {
			InputStream in = new FileInputStream(certfile);
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			X509Certificate cert = (X509Certificate) cf.generateCertificate(in);
			try {
				in.close();
			} catch (IOException e) {
			}
			cert.checkValidity();
			return cert;
		} catch (FileNotFoundException e) {
			throw new CertificateException("证书文件不存在");
		}
	}

	/**
	 * 返回X509证书
	 */
	public static X509Certificate createX509Certificate(byte[] certData, boolean check) throws CertificateException {
		InputStream in = new ByteArrayInputStream(certData);
		CertificateFactory cf = CertificateFactory.getInstance("X.509");
		X509Certificate cert = (X509Certificate) cf.generateCertificate(in);
		try {
			in.close();
		} catch (Exception e) {
		}
		if (check)
			cert.checkValidity();
		return cert;
	}

	/**
	 * 返回证书主题
	 */
	public static String getCertSubject(byte[] certData) throws CertificateException {
		return createX509Certificate(certData, false).getSubjectDN().getName();
	}

	/**
	 * 返回证书发行者
	 */
	public static String getCertificateIssuer(byte[] certData) throws CertificateException {
		return createX509Certificate(certData, false).getIssuerDN().getName();
	}

	/**
	 * 验证证书
	 */
	public static boolean verifyCert(byte[] certData, byte[] caData) {
		try {
			X509Certificate caCert = createX509Certificate(caData, false);
			X509Certificate cert = createX509Certificate(certData, true);
			cert.verify(caCert.getPublicKey());
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static Certificate createCertificate(byte[] certData, boolean check) throws CertificateException {
		return createX509Certificate(certData, check);
	}

	/**
	 * 验证签名 alg: 算法 cert: 证书对象 message: 明文 signature: 签名
	 */
	protected static boolean verify(String alg, Certificate cert, byte[] message, byte[] signature) {
		try {
			Signature s = Signature.getInstance(alg);
			s.initVerify(cert);
			s.update(message);
			return s.verify(signature);
		} catch (Exception e) {
			return false;
		}
	}

	public static byte[] string2Bytes(String message) {
		int cnt = 0;
		for (int i = 0; i < message.length(); i++) {
			if ((message.charAt(i) & 0xff00) != 0) {
				cnt++;
				Integer.toHexString(message.charAt(i) & 0xffff);
			}
		}
		// 2-byte presentation?
		if (cnt == 0) {
			return message.getBytes();
		}

		try {
			// Unicode presentation?
			byte[] msg = message.getBytes("GBK");
			// byte[] msg = message.getBytes();
			if (msg.length == (message.length() + cnt)) {
				return msg;
			}
		} catch (Exception e) {
		}

		// GBK presentation?
		byte[] msg = new byte[message.length() + cnt];
		for (int i = 0; i < msg.length;) {
			char c = message.charAt(i);
			if ((c & 0xff00) != 0) {
				msg[i++] = (byte) ((c >> 8) & 0xff);
			}
			msg[i++] = (byte) (c & 0xff);
		}
		return msg;
	}

	private final static byte[] hex = "0123456789ABCDEF".getBytes();

	private static int parse(char c) {
		if (c >= 'a') {
			return (c - 'a' + 10) & 0x0f;
		}
		if (c >= 'A') {
			return (c - 'A' + 10) & 0x0f;
		}
		return (c - '0') & 0x0f;
	}

	private static byte[] hexStringToBytes(String hexstr) {
		byte[] b = new byte[hexstr.length() / 2];
		int j = 0;
		for (int i = 0; i < b.length; i++) {
			char c0 = hexstr.charAt(j++);
			char c1 = hexstr.charAt(j++);
			b[i] = (byte) ((parse(c0) << 4) | parse(c1));
		}
		return b;
	}

	/*
	 * 返回私钥 file: 私钥文件(JKS格式) pass: 私钥文件密码 alias: 私钥别名
	 */
	public static PrivateKey getPrivateKey(String file, String pass, String alias) {
		try {
			char[] password = pass.toCharArray();
			KeyStore ks = KeyStore.getInstance("jks");

			ks.load(new FileInputStream(file), password);
			return (PrivateKey) ks.getKey(alias, password);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * @description：
	 * @param
	 * @return
	 * @version: 2010-5-10 下午05:02:56
	 * @throws KeyStoreException
	 * @throws IOException
	 * @throws CertificateException
	 * @throws NoSuchAlgorithmException
	 * @See:
	 */
	public static PrivateKey getPrivateKey(InputStream keyFileInput, String pass, String alias) throws BizException {
		if (StringUtils.isEmpty(pass) || StringUtils.isEmpty(alias)) {
			throw new BizException(TransReturnCode.code_9108, "获取私钥文件的传参不合法");
		}

		PrivateKey key = null;
		try {
			char[] password = pass.toCharArray();
			KeyStore ks = KeyStore.getInstance("jks");
			ks.load(keyFileInput, password);
			key = (PrivateKey) ks.getKey(alias, password);
		} catch (Exception ex) {
			throw new BizException(TransReturnCode.code_9108, "获取私钥文件异常,原因{" + ex.getMessage() + "}");
		}

		return key;
	}

	public static String bytesToHexString(byte[] b) {
		byte[] buff = new byte[2 * b.length];
		for (int i = 0; i < b.length; i++) {
			buff[2 * i] = hex[(b[i] >> 4) & 0x0f];
			buff[2 * i + 1] = hex[b[i] & 0x0f];
		}
		return new String(buff);
	}

	/**
	 * 
	 * @param b
	 * @return
	 */
	public static String byte2hex(byte[] b) {
		String hs = "";
		String stmp = "";
		for (int i = 0; i < b.length; i++) {
			stmp = Integer.toHexString(b[i] & 0xFF);
			if (stmp.length() == 1) {
				hs += "0" + stmp;
			} else {
				hs += stmp;
			}
		}
		return hs.toUpperCase();
	}

	public static String getCertID(InputStream is) {
		final String SEPS = ", ";
		final int COUNT = 7;
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			X509Certificate cert = (X509Certificate) cf.generateCertificate(is);
			String issuer = cert.getIssuerDN().toString();
			issuer = issuer.replaceFirst("EMAILADDRESS=", "E=");
			issuer = issuer.replaceFirst("ST=", "S=");
			String issuerbak = issuer;
			String[] elements = new String[COUNT];
			int i = 0;
			for (i = 0; i < COUNT; i++) {
				int index = issuerbak.indexOf(SEPS);
				if (index == -1) {
					elements[i] = issuerbak;
					break;
				}
				elements[i] = issuerbak.substring(0, index);
				issuerbak = issuerbak.substring(index + SEPS.length());
			}

			StringBuffer buffer = new StringBuffer(500);
			BigInteger sn = cert.getSerialNumber();
			buffer.append(sn.toString(16).toUpperCase());
			buffer.append("@");
			for (; i >= 0; i--) {
				buffer.append(elements[i]);
				if (i > 0) {
					buffer.append(SEPS);
				}
			}

			return new String(buffer);
		} catch (Exception e) {
			return "";
		}
	}
}
