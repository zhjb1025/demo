package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.util;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Node;

import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean.AccVerifyRsp;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean.BatchTrasNoticeRsp;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean.KeyApplyRsp;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.BatchBean;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.BatchNoticeBean;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.J2DES;
import com.lycheepay.clearing.adapter.banks.ccb.creditRepay.kft.util.MD5;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.adapter.common.util.net.SendBySocket;
import com.lycheepay.clearing.adapter.common.util.security.Base64;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;
import com.lycheepay.clearing.util.ObjectUtil;


/**
 * 
 * <P>交易收发处理类</P>
 * 
 * @author 汤兴友 xytang
 */
public class TranProcess {
	/**
	 * 信用卡还款批量授权入账接口
	 * 
	 * @param socketIP
	 * @param socketPort
	 * @param batchBean
	 * @param workKey
	 * @param iSK
	 * @param bankCode
	 * @return
	 * @throws BizException
	 */
	public BatchTrasNoticeRsp transNotice(String socketIP, String socketPort, BatchBean batchBean, String workKey,
			String iSK, String bankCode, String applyNo, String batchLocalFilepath)
			throws BizException {
		String revInfo; // 保存信用卡交易返回的数据
		revInfo = this.tranSendNotice_pay(socketIP, socketPort, batchBean, workKey, iSK, bankCode, applyNo, batchLocalFilepath);
		AssertUtils.notEmpty(revInfo, TransReturnCode.code_9900, "建行信用卡还款返回的信息为空，请联系银行");
		return this.tranNoticeResult_pay(revInfo, workKey, iSK);
	}

	/**
	 * 密钥申请
	 * 
	 * @param socketIP
	 * @param socketPort
	 * @param workKey
	 * @param iSK
	 * @return
	 * @throws BizException
	 */
	public KeyApplyRsp keyApply(String socketIP, String socketPort, String workKey, String dAK, String iSK,
			String bankCode, String orgCode, String applyNo) throws BizException {
		String revInfo;
		revInfo = this.keyApplySend(socketIP, socketPort, workKey, dAK, iSK, bankCode, orgCode, applyNo);
		AssertUtils.notEmpty(revInfo, TransReturnCode.code_9900, "密钥申请交易返回的信息为空，请联系银行！");
		return this.keyApplyRec(revInfo, workKey, dAK, iSK);
	}

	/**
	 * 文件接收通知交易
	 * 
	 * @param socketPort
	 * @param batchNoticeBean
	 * @param workKey
	 * @return
	 * @throws Exception
	 */
	private String tranSendNotice_pay(String socketIP, String socketPort, BatchBean batchBean, String workKey,
			String iSK, String bankCodeStr, String applySn, String batchLocalFilepath)
			throws BizException {

		/**
		 * msgno消息号 格式：
		 * 
		 * 消息号32位 MMDDHHMMSSATTTTXXXXXXXXKK0000000 尾补7个0待扩展 MMDD月日 HHMMSS时分秒 ATTTT流程发起者编号
		 * A为方向，1为银行，0为第三方，TTTT为银行代码 XXXXXXXX流程唯一性序号 KK流程中序号 同一个业务交换序列中，每对请求应答KK值递增；
		 */

		// String flowerNum = "";//流程发起者编号
		String directionFlag = "0";// 1为银行，0为第三方
		String bankCode = bankCodeStr;// 银行代码
		String uniqueSerialNum = applySn.substring(applySn.length() - 8);// 流程唯一性序号 取后八位
		String serialNum = applySn.substring(applySn.length() - 2);// 流程中序号

		StringBuffer msgno_ = new StringBuffer(new SimpleDateFormat("MMdd").format(new Date()));
		msgno_.append(DateUtil.getCurrentTime());
		// msgno_.append(flowerNum);
		msgno_.append(directionFlag);
		msgno_.append(bankCode);
		msgno_.append(uniqueSerialNum);
		msgno_.append(serialNum).append("0000000");

		/**
		 * 
		 * request节点 格式：
		 * 
		 * 1 msgno 消息号 MSGNO(32) M 2 cmd 接口命令字 [BRCQ] M 3 orgcode 机构代码 Vchar(32) M 4 subfiles 子文件数
		 * Vdigit (3) M 5 totalrcd 总金额 Vdigit(6) C 6 totalamount 总笔数 Vdigit(32) C 7 filemd5list 文件列表
		 * 所有文件名列表： File1:md51|file2:md52… Vchar(512) C 8 desc 描述 Vchar(256) C 9 sign 签名 Vchar(32) M
		 * 
		 */

		String msgno = msgno_.toString();
		String cmd = "BRCQ";
		String orgcode = batchBean.getOrgcode();
		int subfiles = batchBean.getSubFileNum();

		AssertUtils.checkLength(msgno, TransReturnCode.code_9108, "消息号", 32, 32);
		AssertUtils.checkLength(cmd, TransReturnCode.code_9108, "接口命令字", 4, 4);
		AssertUtils.checkLength(String.valueOf(subfiles), TransReturnCode.code_9108, "子文件数", 1, 3);
		AssertUtils.notNull(batchBean.getTotalAmt(), TransReturnCode.code_9108, "总金额");
		AssertUtils.notNull(batchBean.getTotalNum(), TransReturnCode.code_9108, "总笔数");
		AssertUtils.notNull(batchBean.getBeans(), TransReturnCode.code_9108, "文件列表");
		AssertUtils.checkLength(workKey, TransReturnCode.code_9108, "workKey", 32, 32);
		AssertUtils.checkLength(iSK, TransReturnCode.code_9108, "iSK", 32, 32);


		// 文件列表 File1:md51|file2:md52
		String subFiles = "";
		List<BatchNoticeBean> beans = batchBean.getBeans();
		BatchNoticeBean bean = null;
		
		try {
			String subFileData = "";
			String summaryFileData = this.readFile(batchLocalFilepath + File.separator + batchBean.getSummaryFile());
					
			subFiles += batchBean.getSummaryFile() + ":" + this.createSign(summaryFileData) + "|";

			for (int i = 0; i < beans.size(); i++) {
				bean = beans.get(i);
				subFileData = this.readFile(batchLocalFilepath + File.separator + bean.getFileName());
				subFiles += bean.getFileName() + ":" + this.createSign(subFileData);
				if (i != beans.size() - 1) {
					subFiles += "|";
				}
			}
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, e.getMessage());
		}


		/**
		 * sign
		 */
		String sign = ""; // 签名信息
		StringBuffer sb_ = new StringBuffer();
		sb_.append("<msgno>").append(msgno).append("</msgno>");
		sb_.append("<cmd>").append(cmd).append("</cmd>");
		sb_.append("<orgcode>").append(orgcode).append("</orgcode>");
		sb_.append("<subfiles>").append(subfiles).append("</subfiles>");
		sb_.append("<totalrcd>").append(batchBean.getTotalNum()).append("</totalrcd>");
		sb_.append("<totalamount>").append(MoneyUtil.getFenString(BigDecimal.valueOf(batchBean.getTotalAmt())))
				.append("</totalamount>");
		sb_.append("<filemd5list>").append(subFiles).append("</filemd5list>");
		sb_.append("<key>").append(iSK).append("</key>");

		sign = this.createSign(sb_.toString());
		AssertUtils.checkLength(sign, TransReturnCode.code_9108, "签名", 32, 32);

		/**
		 * requestMsg
		 */
		String requestMsg; // 交易发送的Request数据

		StringBuffer sb = new StringBuffer();
		sb.append("<msgno>").append(msgno).append("</msgno>");
		sb.append("<cmd>").append(cmd).append("</cmd>");
		sb.append("<orgcode>").append(orgcode).append("</orgcode>");
		sb.append("<subfiles>").append(subfiles).append("</subfiles>");
		sb.append("<totalrcd>").append(batchBean.getTotalNum()).append("</totalrcd>");
		sb.append("<totalamount>").append(MoneyUtil.getFenString(BigDecimal.valueOf(batchBean.getTotalAmt())))
				.append("</totalamount>");// TODO
		sb.append("<filemd5list>").append(subFiles).append("</filemd5list>");
		sb.append("<sign>").append(sign).append("</sign>");

		Log4jUtil.info("-----------发送到银行的request明文数据：" + sb.toString());
		requestMsg = this.Base64And3DES(sb.toString(), workKey);

		/**
		 * 完整的请求串信息
		 */
		String msg = "";
		StringBuffer msg_ = new StringBuffer();
		msg_.append("<root>");
		msg_.append("<cmd>").append(cmd).append("</cmd>");
		msg_.append("<msgno>").append(msgno).append("</msgno>");
		msg_.append("<orgcode>").append(orgcode).append("</orgcode>");
		msg_.append("<request>").append(requestMsg).append("</request>");
		msg_.append("</root>");

		msg = FormatTransfer.setLStrFormat(String.valueOf(msg_.toString().length() + 5), 5) + msg_.toString();

		Log4jUtil.info("-----------发送到银行的加密数据：" + msg);

		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, msg);
	}

	public String readFile(final String dataFileName) throws Exception {
		final File file = new File(dataFileName);
		final long length = file.length();
		if (length > 10 * 1204 * 1024) {
			throw new Exception("文件长度大于10M,拒绝");
		}
		final byte[] bytemem = new byte[(int) length];

		final FileInputStream fis = new FileInputStream(file);
		fis.read(bytemem);

		final String strData = new String(bytemem, Charset.forName("GBK"));
		return strData;
	}

	/**
	 * base64(3des(原字符串))
	 * 
	 * @param data
	 * @param workKey
	 * @return
	 */
	private String Base64And3DES(String data, String workKey) {
		byte[] org = J2DES.trides_crypt(J2DES.hexToBytes(workKey), data.getBytes(Charset.forName("GBK")));
		return String.valueOf(Base64.encode(org));
	}

	/**
	 * 
	 * @param data
	 * @param workKey
	 * @return
	 */
	private String parseResponse(String data, String workKey) {
		byte[] orgStr = Base64.decode(data.toCharArray());
		byte[] orgBytes = J2DES.trides_decrypt(J2DES.hexToBytes(workKey), orgStr);
		return new String(orgBytes, Charset.forName("GBK"));
	}

	/**
	 * MD5
	 * 
	 * @param orgMsg
	 * @return
	 * @throws BizException
	 */
	private String createSign(String orgMsg) throws BizException {
		String rs = "";
		try {
			MD5 md5 = new MD5();
			rs = md5.md5s(orgMsg);
		} catch (BizException e) {
			Log4jUtil.error(e);
			throw new BizException("MD5生成出错！");
		}
		return rs.toLowerCase();
	}

	/**
	 * 文件接收通知交易 返回信息
	 * 
	 * @param revInfo
	 * @param workKey
	 * @return
	 * @throws BizException
	 */
	private BatchTrasNoticeRsp tranNoticeResult_pay(String revInfo, String workKey, String iSK)
			throws BizException {
		/**
		 * 1 msgno 消息号 MSGNO(32) M 2 cmd 接口命令字 [BRCP] Char(4) M 3 retcode 返回码 Retcode(10) M 4
		 * orgcode 机构代码 Vchar(32) M 5 subfiles 子文件数 Vdigit (3) M 6 totalrcd 总金额 Vdigit(6) M 7
		 * totalamount 总笔数 Vdigit(32) M 8 sign 签名值 Vchar(32) M
		 * 
		 **/
		revInfo = Pattern.compile("[\n-\r]").matcher(revInfo.trim()).replaceAll("");
		Log4jUtil.info("-----------revInfo过滤空格和换行后为：" + revInfo);

		/**
		 * 长度解析，前5位
		 */
		int len = 0;
		try {
			String lenStr = (String) revInfo.substring(0, 5);
			len = Integer.parseInt(lenStr);
		} catch (Exception e) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息格式有误，解析前5位长度信息出错！");
		}

		if (revInfo.getBytes().length != len) {
			throw new BizException(TransReturnCode.code_9109, StringUtil.r("返回信息长度{?}与信息头长度的{?}不符！ ", revInfo.length(),
					len));
		}

		/**
		 * 解析父节点信息
		 */
		Dom4jXMLMessage dom4jxml = null;
		Dom4jXMLMessage resXml = null;
		dom4jxml = Dom4jXMLMessage.parse(("<?xml version='1.0' encoding='GBK'?>" + revInfo.substring(5)).getBytes());

		Node root = dom4jxml.getNode("/root");
		String msgno = dom4jxml.getNodeText(root, "msgno");
		String cmd = dom4jxml.getNodeText(root, "cmd");
		String orgcode = dom4jxml.getNodeText(root, "orgcode");
		String retcode = dom4jxml.getNodeText(root, "retcode");
		String response = dom4jxml.getNodeText(root, "response");

		// Log4jUtil.info("-----------msgno："+msgno);
		// Log4jUtil.info("-----------cmd："+cmd);
		// Log4jUtil.info("-----------orgcode："+orgcode);
		// Log4jUtil.info("-----------retcode："+retcode);
		// Log4jUtil.info("-----------response："+response);

		BatchTrasNoticeRsp bean = new BatchTrasNoticeRsp();
		String subfiles_ = "", totalrcd_ = "", totalamount_ = "";

		if (StringUtils.isNotBlank(response)) {
			/**
			 * 解析response信息
			 */
			String resOrg = this.parseResponse(response, workKey);

			resOrg = Pattern.compile("[\n-\r]").matcher(resOrg.trim()).replaceAll("");
			Log4jUtil.info("-----------response过滤空格和换行后为：" + resOrg);

			String resorg_ = resOrg;
			Log4jUtil.info("-----------response明文：" + resOrg);
			resOrg = "<?xml version='1.0' encoding='GBK'?><root>" + resOrg + "</root>";
			resXml = Dom4jXMLMessage.parse(resOrg.getBytes());
			Node r = resXml.getNode("/root");

			String msgno_ = resXml.getNodeText(r, "msgno");
			String cmd_ = resXml.getNodeText(r, "cmd");
			String orgcode_ = resXml.getNodeText(r, "orgcode");
			String retcode_ = resXml.getNodeText(r, "retcode");
			subfiles_ = resXml.getNodeText(r, "subfiles");
			totalrcd_ = resXml.getNodeText(r, "totalrcd");
			totalamount_ = resXml.getNodeText(r, "totalamount");
			String sign_ = resXml.getNodeText(r, "sign");

			/**
			 * 域值的检查
			 */
			this.checkData("BRCP", cmd, cmd_, retcode, retcode_, msgno, msgno_, orgcode, orgcode_);

			/**
			 * sign验证
			 */
			this.checkSign(resorg_, iSK, sign_);

			bean.setSubfiles(subfiles_);
			bean.setTotalamount(totalamount_);
			bean.setTotalrcd(totalrcd_);
		}

		AssertUtils.checkLength(retcode, TransReturnCode.code_9108, "返回码", 10, 10);

		String bankcode = retcode.substring(0, 5);
		String retCode = retcode.substring(5);

		Log4jUtil.info("-----------bankcode：" + bankcode);
		Log4jUtil.info("-----------retCode：" + retCode);

		bean.setRetcode(retCode);
		bean.setCmd(cmd);
		bean.setMsgno(msgno);
		bean.setOrgcode(orgcode);

		ObjectUtil.printPropertyString("授权入账BatchTrasNoticeRsp", bean);

		return bean;
	}

	private String keyApplySend(String socketIP, String socketPort, String workKey, String dAK, String iSK,
			String bankCodeStr, String orgCode, String applySn) throws BizException {

		/**
		 * msgno消息号 格式： 09201114540301502312217010000000 消息号32位 MMDDHHMMSSATTTTXXXXXXXXKK0000000
		 * 尾补7个0待扩展 MMDD月日 HHMMSS时分秒 ATTTT流程发起者编号 A为方向，1为银行，0为第三方，TTTT为银行代码 XXXXXXXX流程唯一性序号 KK流程中序号
		 * 同一个业务交换序列中，每对请求应答KK值递增；
		 */

		// String flowerNum = "";//流程发起者编号
		String directionFlag = "0";// 1为银行，0为第三方
		String bankCode = bankCodeStr;// 银行代码
		String uniqueSerialNum = applySn.substring(applySn.length() - 8);// 流程唯一性序号 取后八位
		String serialNum = applySn.substring(applySn.length() - 2);// 流程中序号

		StringBuffer msgno_ = new StringBuffer(new SimpleDateFormat("MMdd").format(new Date()));
		msgno_.append(DateUtil.getCurrentTime());
		// msgno_.append(flowerNum);
		msgno_.append(directionFlag);
		msgno_.append(bankCode);
		msgno_.append(uniqueSerialNum);
		msgno_.append(serialNum).append("0000000");

		/**
		 * 
		 * request节点 格式：
		 * 
		 * 1 msgno 消息号 MSGNO(32) M 2 cmd 接口命令字 [AKDQ] M 3 timestamp 还款时间戳 Timestamp M 4 orgcode 机构代码
		 * Vchar(32) M 5 sign 签名 Vchar(32) M
		 * 
		 */

		String msgno = msgno_.toString();
		String cmd = "AKDQ";
		String orgcode = orgCode;
		String timestamp = String.valueOf(System.currentTimeMillis());

		AssertUtils.checkLength(msgno, TransReturnCode.code_9108, "消息号", 32, 32);
		AssertUtils.checkLength(cmd, TransReturnCode.code_9108, "接口命令字", 4, 4);
		AssertUtils.checkLength(dAK, TransReturnCode.code_9108, "dAK", 32, 32);
		AssertUtils.checkLength(iSK, TransReturnCode.code_9108, "iSK", 32, 32);

		/**
		 * sign
		 */
		String sign = ""; // 签名信息
		StringBuffer sb_ = new StringBuffer();
		sb_.append("<msgno>").append(msgno).append("</msgno>");
		sb_.append("<cmd>").append(cmd).append("</cmd>");
		sb_.append("<timestamp>").append(timestamp).append("</timestamp>");
		sb_.append("<orgcode>").append(orgcode).append("</orgcode>");
		sb_.append("<key>").append(iSK).append("</key>");

		sign = this.createSign(sb_.toString());
		AssertUtils.checkLength(sign, TransReturnCode.code_9108, "签名", 32, 32);

		StringBuffer sb = new StringBuffer();
		sb.append("<msgno>").append(msgno).append("</msgno>");
		sb.append("<cmd>").append(cmd).append("</cmd>");
		sb.append("<timestamp>").append(timestamp).append("</timestamp>");
		sb.append("<orgcode>").append(orgcode).append("</orgcode>");
		sb.append("<sign>").append(sign).append("</sign>");

		String requestMsg = Base64.encode(sb.toString());// 交易发送的Request数据
		/**
		 * 完整的请求串信息
		 */
		StringBuffer msg_ = new StringBuffer();
		msg_.append("<root>");
		msg_.append("<cmd>").append(cmd).append("</cmd>");
		msg_.append("<msgno>").append(msgno).append("</msgno>");
		msg_.append("<orgcode>").append(orgcode).append("</orgcode>");
		msg_.append("<request>").append(requestMsg).append("</request>");
		msg_.append("</root>");

		String msg = FormatTransfer.setLStrFormat(String.valueOf(msg_.toString().length() + 5), 5) + msg_.toString();

		Log4jUtil.info("-----------发送到银行的request原始数据为：" + requestMsg);
		Log4jUtil.info("-----------发送到银行的数据为：" + msg);

		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, msg);
	}

	private KeyApplyRsp keyApplyRec(String revInfo, String workKey, String dAK, String iSK)
			throws BizException {
		/**
		 * 1 msgno 消息号 MSGNO(32) M 2 cmd 接口命令字 [AKDP] Char(4) M 3 retcode 返回码 Retcode(10) M 4 desc
		 * 返回描述 Vchar(256) M 5 key Key为DAK加密的DCK key key=encrypt( 3des, DCK, DAK ) Vchar(32) M 6
		 * valikey Valikey为DCK加密的ISK key=encrypt( 3des, ISK, DCK ) 7 timestamp 还款时间戳 Timestamp M 8
		 * orgcode 机构代码 Vchar(32) M 9 sign 签名值 Vchar(32) M
		 * 
		 **/

		revInfo = Pattern.compile("[\n-\r]").matcher(revInfo.trim()).replaceAll("");
		Log4jUtil.info("-----------过滤空格和换行后为：" + revInfo);

		/**
		 * 长度解析，前5位
		 */
		int len = 0;
		try {
			String lenStr = (String) revInfo.substring(0, 5);
			len = Integer.parseInt(lenStr);
		} catch (Exception e) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息格式有误，解析前5位长度信息出错！");
		}

		if (revInfo.getBytes().length != len) {
			throw new BizException(TransReturnCode.code_9109, StringUtil.r("返回信息长度{?}与信息头长度的{?}不符！ ", revInfo.length(),
					len));
		}

		/**
		 * 解析父节点信息
		 */
		Dom4jXMLMessage dom4jxml = null;
		Dom4jXMLMessage resXml = null;
		dom4jxml = Dom4jXMLMessage.parse(("<?xml version='1.0' encoding='GBK'?>" + revInfo.substring(5)).getBytes());

		Node root = dom4jxml.getNode("/root");
		String msgno = dom4jxml.getNodeText(root, "msgno");
		String orgcode = dom4jxml.getNodeText(root, "orgcode");
		String cmd = dom4jxml.getNodeText(root, "cmd");
		String retcode = dom4jxml.getNodeText(root, "retcode");
		String response = dom4jxml.getNodeText(root, "response");

		// Log4jUtil.info("-----------msgno："+msgno);
		// Log4jUtil.info("-----------orgcode："+orgcode);
		// Log4jUtil.info("-----------cmd："+cmd);
		// Log4jUtil.info("-----------retcode："+retcode);
		// Log4jUtil.info("-----------response："+response);

		String desc_ = "", key_ = "", valikey_ = "", dck = "", keyHex = "";

		if (StringUtils.isNotBlank(response)) {

			/**
			 * 解析response信息
			 */
			String resOrg = Base64.decode(response.trim());
			String resorg_ = resOrg;
			Log4jUtil.info("-----------response明文：" + resOrg);
			resOrg = "<?xml version='1.0' encoding='GBK'?><root>" + resOrg + "</root>";
			resXml = Dom4jXMLMessage.parse(resOrg.getBytes());
			Node r = resXml.getNode("/root");

			String msgno_ = resXml.getNodeText(r, "msgno");
			String cmd_ = resXml.getNodeText(r, "cmd");
			String orgcode_ = resXml.getNodeText(r, "orgcode");
			key_ = resXml.getNodeText(r, "key");
			valikey_ = resXml.getNodeText(r, "valikey");
			String retcode_ = resXml.getNodeText(r, "retcode");
			desc_ = resXml.getNodeText(r, "desc");
			String sign_ = resXml.getNodeText(r, "sign");

			/**
			 * 域值的检查
			 */
			this.checkData("AKDP", cmd, cmd_, retcode, retcode_, msgno, msgno_, orgcode, orgcode_);

			/**
			 * sign验证
			 */
			this.checkSign(resorg_, iSK, sign_);

			/**
			 * 解析出DCK key=encrypt( 3des, DCK, DAK )
			 */

			byte[] keyBs = Base64.decode(key_.toCharArray());
			// isK:8db4a013a8b515349c307f1e448ce836
			// Dak:333705661205A5E3D950933325240713 (32) 转成16位
			byte[] dCKs = J2DES.trides_decrypt(J2DES.hexToBytes(dAK), keyBs);
			keyHex = J2DES.byte2hex(keyBs);
			dck = J2DES.byte2hex(dCKs);

			Log4jUtil.info("-----------key-base64：" + key_);// aX7Ev7iLDuQvc7F92Zer1Q==
			Log4jUtil.info("-----------key-Hex：" + keyHex);// 697EC4BFB88B0EE42F73B17DD997ABD5
			Log4jUtil.info("-----------dCK-Hex：" + dck);// 0B4FE980869123086DADAD373D3D7546

			/**
			 * 用valikey_验证DCK Valikey为DCK加密的ISK key=encrypt( 3des, ISK, DCK )
			 */

			MD5 m = new MD5();
			String iskMd5 = "";
			try {
				iskMd5 = m.md5s(iSK);
			} catch (BizException e) {
				Log4jUtil.error(e);
			}

			byte[] valikeys = J2DES.trides_crypt(dCKs, iskMd5.getBytes());
			String valikey = String.copyValueOf(Base64.encode(valikeys));
			if (!valikey_.equals(valikey)) {
				throw new BizException("用valikey_验证DCK 失败，密钥同步失败！");
			}
		}

		String bankcode = retcode.substring(0, 5);
		String retCode = retcode.substring(5);

		Log4jUtil.info("-----------bankcode：" + bankcode);
		Log4jUtil.info("-----------retCode：" + retCode);

		KeyApplyRsp resBean = new KeyApplyRsp();
		resBean.setMsgno(msgno);
		resBean.setRetcode(retCode);
		resBean.setCmd(cmd);
		resBean.setDck(dck);
		resBean.setKey(key_);
		resBean.setValikey(valikey_);
		resBean.setDesc(desc_);

		ObjectUtil.printPropertyString("申请密钥的Response信息", resBean);

		return resBean;
	}

	/**
	 * 
	 * @param response
	 * @param iSK
	 * @param sign_
	 * @throws BizException
	 */
	private void checkSign(String response, String iSK, String sign_) throws BizException {
		String orgData = response.substring(0, response.indexOf("<sign>")) + "<key>" + iSK + "</key>";
		String sign = this.createSign(orgData);
		if (!sign.equals(sign_)) {
			throw new BizException(TransReturnCode.code_9109, "sign验证失败！");
		}
	}

	/**
	 * 
	 * 回执xml信息中父节点与response的值域的验证是否相同
	 * 
	 * @param cmdOrg
	 * @param cmd
	 * @param cmd2
	 * @param retcode
	 * @param retcode2
	 * @param orgcode2
	 * @param orgcode
	 * @param msgno2
	 * @param msgno
	 * @throws BizException
	 */
	private void checkData(String cmdOrg, String cmd, String cmd2, String retcode, String retcode2, String msgno,
			String msgno2, String orgcode, String orgcode2) throws BizException {
		AssertUtils.checkLength(retcode, TransReturnCode.code_9108, "返回码", 10, 10);

		if (!cmdOrg.equalsIgnoreCase(cmd)) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息有误，解析cmd信息应为:" + cmdOrg);
		}

		if (!cmd.equalsIgnoreCase(cmd2)) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息有误，解析cmd值与response域中的cmd值不同！");
		}

		if (!retcode.equalsIgnoreCase(retcode2)) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息有误，解析retcode值与response域中的retcode值不同！");
		}

		if (!msgno.equalsIgnoreCase(msgno2)) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息有误，解析msgno值与response域中的msgno值不同！");
		}

		if (!orgcode.equalsIgnoreCase(orgcode2)) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息有误，解析orgcode值与response域中的orgcode值不同！");
		}
	}

	/**
	 * 
	 * <p>还款信息人验证</p>
	 * 
	 * @param socketIP
	 * @param socketPort
	 * @param workKey
	 * @param dAK
	 * @param iSK
	 * @param bankCode
	 * @param orgCode
	 * @param verifySn
	 * @return
	 * @author 汤兴友 xytang
	 */
	public AccVerifyRsp accVerify(String socketIP, String socketPort, String workKey, String dAK, String iSK,
			String bankCode, String orgCode, String verifySn, String name, String cardid)
			throws BizException {
		String revInfo = this.accVerifySend(socketIP, socketPort, workKey, iSK, bankCode, orgCode, verifySn, name,
				cardid);
		AssertUtils.notEmpty(revInfo, TransReturnCode.code_9900, "账号验证交易返回的信息为空，请联系银行！");
		return this.accVerifyRec(revInfo, workKey, iSK, name, cardid);
	}

	private String accVerifySend(String socketIP, String socketPort, String workKey, String iSK, String bankCodeStr,
			String orgCode, String verfiySn, String name, String cardid) throws BizException {

		/**
		 * msgno消息号 格式： 09201114540301502312217010000000 消息号32位 MMDDHHMMSSATTTTXXXXXXXXKK0000000
		 * 尾补7个0待扩展 MMDD月日 HHMMSS时分秒 ATTTT流程发起者编号 A为方向，1为银行，0为第三方，TTTT为银行代码 XXXXXXXX流程唯一性序号 KK流程中序号
		 * 同一个业务交换序列中，每对请求应答KK值递增；
		 */

		// String flowerNum = "";//流程发起者编号
		String directionFlag = "0";// 1为银行，0为第三方
		String bankCode = bankCodeStr;// 银行代码
		String uniqueSerialNum = verfiySn.substring(verfiySn.length() - 8);// 流程唯一性序号 取后八位
		String serialNum = verfiySn.substring(verfiySn.length() - 2);// 流程中序号

		StringBuffer msgno_ = new StringBuffer(new SimpleDateFormat("MMdd").format(new Date()));
		msgno_.append(DateUtil.getCurrentTime());
		// msgno_.append(flowerNum);
		msgno_.append(directionFlag);
		msgno_.append(bankCode);
		msgno_.append(uniqueSerialNum);
		msgno_.append(serialNum).append("0000000");

		/**
		 * 
		 * request节点 格式：
		 * 1 msgno 消息号 MSGNO(32) M 2 cmd 接口命令字 [AKDQ] M 3 timestamp 还款时间戳 Timestamp M 4 orgcode 机构代码
		 * Vchar(32) M 5 sign 签名 Vchar(32) M
		 * 
		 */
		String msgno = msgno_.toString();
		String cmd = "CIVQ";
		String orgcode = orgCode;

		AssertUtils.checkLength(msgno, TransReturnCode.code_9108, "消息号", 32, 32);
		AssertUtils.checkLength(cmd, TransReturnCode.code_9108, "接口命令字", 4, 4);
		AssertUtils.checkLength(iSK, TransReturnCode.code_9108, "iSK", 32, 32);

		/**
		 * sign
		 */
		StringBuilder sb_ = new StringBuilder();
		sb_.append("<msgno>").append(msgno).append("</msgno>");
		sb_.append("<cmd>").append(cmd).append("</cmd>");
		sb_.append("<name>").append(name).append("</name>");
		sb_.append("<cardid>").append(cardid).append("</cardid>");
		sb_.append("<key>").append(iSK).append("</key>");

		String sign = this.createSign(sb_.toString());// 签名信息
		AssertUtils.checkLength(sign, TransReturnCode.code_9108, "签名", 32, 32);

		/**
		 * requestMsg
		 */
		StringBuilder sb = new StringBuilder();
		sb.append("<msgno>").append(msgno).append("</msgno>");
		sb.append("<cmd>").append(cmd).append("</cmd>");
		sb.append("<name>").append(name).append("</name>");
		sb.append("<cardid>").append(cardid).append("</cardid>");
		sb.append("<sign>").append(sign).append("</sign>");

		Log4jUtil.info("-----------明文数据：{}", sb.toString());
		String requestMsg = this.Base64And3DES(sb.toString(), workKey); // 交易发送的Request数据
		Log4jUtil.info("-----------加密数据：{}", requestMsg);
		/**
		 * 完整的请求串信息
		 */
		StringBuilder msg_ = new StringBuilder();
		msg_.append("<root>");
		msg_.append("<cmd>").append(cmd).append("</cmd>");
		msg_.append("<msgno>").append(msgno).append("</msgno>");
		msg_.append("<orgcode>").append(orgcode).append("</orgcode>");
		msg_.append("<request>").append(requestMsg).append("</request>");
		msg_.append("</root>");

		String msg = FormatTransfer.setLStrFormat(String.valueOf(msg_.toString().length() + 5), 5) + msg_.toString();

		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, msg);
	}

	private AccVerifyRsp accVerifyRec(String revInfo, String workKey, String iSK, String name_org, String cardid_org)
			throws BizException {
		revInfo = revInfo.trim().replaceAll("[\n-\r]", "");
		Log4jUtil.info("-----------过滤空格和换行后为：{}", revInfo);

		/**
		 * 长度解析，前5位
		 */
		int len = 0;
		try {
			String lenStr = revInfo.substring(0, 5);
			len = Integer.parseInt(lenStr);
		} catch (Exception e) {
			throw new BizException(TransReturnCode.code_9109, "返回的信息格式有误，解析前5位长度信息出错！");
		}

		if (revInfo.getBytes(Charset.forName("GBK")).length != len) {
			throw new BizException(TransReturnCode.code_9109, StringUtil.r("返回信息长度{?}与信息头长度的{?}不符！ ", revInfo.length(),
					len));
		}

		/**
		 * 解析父节点信息
		 */
		Dom4jXMLMessage dom4jxml = Dom4jXMLMessage
				.parse(("<?xml version='1.0' encoding='GBK'?>" + revInfo.substring(5)).getBytes(Charset.forName("GBK")));

		Node root = dom4jxml.getNode("/root");
		String msgno = dom4jxml.getNodeText(root, "msgno");
		String orgcode = dom4jxml.getNodeText(root, "orgcode");
		String cmd = dom4jxml.getNodeText(root, "cmd");
		String retcode = dom4jxml.getNodeText(root, "retcode");
		String response = dom4jxml.getNodeText(root, "response");

		String name = "";
		String cardid = "";
		String desc = "";

		if (StringUtils.isNotBlank(response)) {
			/**
			 * 解析response信息 先用base64转码,再用工作密钥对其解密. (密钥同步接口只需base64转码)
			 */
			String resOrg = this.parseResponse(response, workKey);

			resOrg = resOrg.trim().replaceAll("[\n-\r]", "");

			String resorg_ = resOrg;
			Log4jUtil.info("-----------滤空格和换行符后解密结果明文：{}", resOrg);
			resOrg = "<?xml version='1.0' encoding='GBK'?><root>" + resOrg + "</root>";
			Dom4jXMLMessage resXml = Dom4jXMLMessage.parse(resOrg.getBytes(Charset.forName("GBK")));
			Node r = resXml.getNode("/root");

			String msgno_ = resXml.getNodeText(r, "msgno");
			String cmd_ = resXml.getNodeText(r, "cmd");
			String retcode_ = resXml.getNodeText(r, "retcode");
			name = resXml.getNodeText(r, "name");
			cardid = resXml.getNodeText(r, "cardid");
			desc = resXml.getNodeText(r, "desc");
			String sign_ = resXml.getNodeText(r, "sign");

			/**
			 * sign验证
			 */
			this.checkSign(resorg_, iSK, sign_);

		}

		String bankcode = retcode.substring(0, 5);
		String retCode = retcode.substring(5);

		Log4jUtil.info(" --bankcode：{},retCode：{}", bankcode, retCode);

		AccVerifyRsp resBean = new AccVerifyRsp();
		resBean.setMsgno(msgno);
		resBean.setCmd(cmd);
		resBean.setRetcode(retCode);
		resBean.setName(name);
		resBean.setCardid(cardid);
		resBean.setDesc(desc);


		Log4jUtil.info("还款信息验证的resBean:{}", resBean);

		return resBean;
	}

	public static void main(String[] args) throws BizException {
		// String filePath =
		// // "C:\\Users\\tangxingyou\\Desktop\\kft_CreditRepay_20120807_2012080701_001.csv";
		// String filePath =
		// "C:\\Users\\tangxingyou\\Desktop\\kft_RepayTotal_20120807_2012080701.csv";
		// // String filePath =
		// // "C:\\Users\\tangxingyou\\Desktop\\kft_RepayTotal_20120730_2012073001.csv";
		// TranProcess tp = new TranProcess();
		// String summaryFileData;
		// try {
		// summaryFileData = tp.readFile(filePath);
		// System.out.println(summaryFileData);
		// System.out.println(summaryFileData.getBytes().length);
		// System.out.println(tp.createSign(summaryFileData));
		// // System.out.println(MD5_test.MD5(summaryFileData));
		// System.out.println("dc4a8c6a79ec257e4938dc74a42ccc16");
		// } catch (Exception e) {
		// Log4jUtil.error(e);
		// }
		// TranProcess tranProcess = new TranProcess();
		// String iSK = "Kft4a013a8b515349c307f1e448cepay";
		// String workKey = "BFDCEA9E497A37514CBA9EC4152AD5FB";
		// String revInfo =
		// "00175<root><ver></ver><cmd>CIVP</cmd><msgno>09061307040301500000037370000000</msgno><orgcode>105584099990035</orgcode><retcode>02验证失败</retcode><response></response></root>";
		// tranProcess.accVerifyRec(revInfo, workKey, iSK);
	}


}
