//package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.processor;
//
///**
// * 建行银企到账处理
// */
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.channel.param.NoticeParam;
//import com.lycheepay.clearing.common.constant.ChannelId;
//import com.lycheepay.clearing.util.Log4jUtil;
//
//
//public class CcbCorpNotifyAppServer extends BaseAppServerThread {
//
//	private static String channelId = ChannelId.ccb_corp.getValue();// 建行银企直连
//
//	/**
//	 * 建行银企到账轮询
//	 * 
//	 * @param groupNo 组号
//	 */
//	public void doProcess(final String groupNo) throws InterruptedException {
//		Log4jUtil.setLogClass("channelLog" + File.separator + channelId, channelId +
//		// "QNotice");
//		Log4jUtil.info(channelId + ChannelId.getNameByValue(channelId) + "到账通知轮询");
//		// 轮询
//		while (bRun) {
//			final ChnlCore chnlCore = new ChnlCore();
//			final NoticeParam noticeParam = new NoticeParam();
//			// ===============================================================
//			noticeParam.setChannelId(ChannelId.ccb_corp.getValue()); // 建行银企的渠道
//			noticeParam.setNoticeDate(Sysdate.getSysdate());// 要轮询的日期,8位字符串
//			// ===============================================================
//			try {
//				chnlCore.notice(noticeParam);
//			} catch (final BizException e) {
//				Log4jUtil.error(e.getStackTrace());
//			}
//			try {
//				Thread.sleep(300 * 1000);
//			} catch (final Exception e) {
//				Log4jUtil.error(e.getStackTrace());
//				break;
//			}
//		}// while020-83018920
//	}
// }
