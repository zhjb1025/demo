package com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.trade;

import com.lycheepay.clearing.adapter.banks.ccb.credit.pos8583.MsgField;


/**
 * 变长域解析器.
 * 
 * @author aps-mhc
 */
public class VarlenFieldParser extends FieldParser {
	// 长度标识.
	private final int lenOfLeaderLength;

	public VarlenFieldParser(final int lenOfLeaderLength) {
		this.lenOfLeaderLength = lenOfLeaderLength;
	}

	@Override
	protected boolean hasLeaderLength() {
		return true;
	}

	@Override
	public int getLenOfLeaderLength() {
		return lenOfLeaderLength;
	}

	/* (non-Javadoc)
	 * @see com.unibank.mp.trade.msg.parser.FieldParser#getNeedLength(com.unibank.mp.trade.msg.MsgField)
	 */
	@Override
	protected int getNeedLength(final MsgField field) {
		// 总长.
		final int origMsgLength = field.getOrigMsgLength();
		final int LEN_TAG = getLenOfLeaderLength();

		if (origMsgLength == 0) {
			return LEN_TAG;
		}

		// 先凑够长度标识.
		if (origMsgLength < LEN_TAG) {
			return LEN_TAG - origMsgLength;
		}

		// 已有完整的长度标识, 但无数据.
		if (origMsgLength == LEN_TAG) {
			return field.getShouldOrigValueLength();
		}

		// 有数据,但数据不全.
		final int shouldLength = LEN_TAG + field.getShouldOrigValueLength();
		if (origMsgLength < shouldLength) {
			return shouldLength - origMsgLength;
		}
		// 数据已接收完全, 不再需要.
		return 0;
	}
}
