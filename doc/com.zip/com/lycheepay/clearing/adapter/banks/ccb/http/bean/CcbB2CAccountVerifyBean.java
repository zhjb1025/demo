package com.lycheepay.clearing.adapter.banks.ccb.http.bean;

public class CcbB2CAccountVerifyBean {
	private String success = ""; // 回执时使用
	private String ccb_ibsversion = "v5";
	private String merchantid = "";
	private String posid = "";
	private String branchid = "";
	private String account = "";
	private String idnum = "";
	private String uname = "";
	private String idtype = "";
	private String remark = "";
	private String txcode = "";
	private String sign = "";
	private String verifyUrl = "";

	public String getVerifyUrl() {
		return verifyUrl;
	}

	public void setVerifyUrl(final String verifyUrl) {
		this.verifyUrl = verifyUrl;
	}

	public String getCcb_ibsversion() {
		return ccb_ibsversion;
	}

	public void setCcb_ibsversion(final String ccb_ibsversion) {
		this.ccb_ibsversion = ccb_ibsversion;
	}

	public String getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(final String merchantid) {
		this.merchantid = merchantid;
	}

	public String getPosid() {
		return posid;
	}

	public void setPosid(final String posid) {
		this.posid = posid;
	}

	public String getBranchid() {
		return branchid;
	}

	public void setBranchid(final String branchid) {
		this.branchid = branchid;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(final String account) {
		this.account = account;
	}

	public String getIdnum() {
		return idnum;
	}

	public void setIdnum(final String idnum) {
		this.idnum = idnum;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(final String uname) {
		this.uname = uname;
	}

	public String getIdtype() {
		return idtype;
	}

	public void setIdtype(final String idtype) {
		this.idtype = idtype;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(final String remark) {
		this.remark = remark;
	}

	public String getTxcode() {
		return txcode;
	}

	public void setTxcode(final String txcode) {
		this.txcode = txcode;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(final String sign) {
		this.sign = sign;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(final String success) {
		this.success = success;
	}

}
