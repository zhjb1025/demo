package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg;

import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.common.constant.biz.SysparmConst;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.DateUtil;


abstract public class KFTPayXmlBase extends KFTXmlBase {
	public KFTPayXmlBase() {
		head = new KFTXmlHead();

	}

	public KFTPayXmlBase(final boolean initMsgId, final String msgSeqId) {
		head = new KFTXmlHead();
		final String workdate = DateUtil.getCurrentDate();
		head.setVer("1.0");
		head.setWorkDate(workdate);
		head.setTimeStamp(DateUtil.getCurrentTime());
		if (initMsgId) {
			head.setSrc(SysparmConst.VIRTUALCUSTID_kft2001CustID);
			head.setMsgID(msgSeqId);
		}
	}

	public void checkAccountExtraData(final String accountExtraData) throws BizException {
		if (StringUtils.isEmpty(accountExtraData)) {
			return;
		}
		final String[] extraData = accountExtraData.split("#", -1);
		if (extraData.length != 5) {
			throw new BizException("帐户附加信息格式错(4个#号)");
		}

	}
}
