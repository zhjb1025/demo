package com.lycheepay.clearing.adapter.banks.ccb.creditRepay.bank.bean;

/**
 * 
 * <P>申请密钥的Response信息</P>
 * 
 * @author 汤兴友 xytang
 */
public class KeyApplyRsp {
	String msgno;// 消息号
	String cmd;// 接口命令字
	String retcode;// 返回码
	String desc;// 返回描述
	String key;// Key为DAK加密的DCK key
	String valikey;// Valikey为DCK加密的ISK
	String timestamp;// 还款时间戳
	String orgcode;// 机构代码
	String sign;// 签名
	
	String dck;

	public String getDck() {
		return dck;
	}

	public void setDck(String dck) {
		this.dck = dck;
	}

	public String getMsgno() {
		return msgno;
	}

	public void setMsgno(String msgno) {
		this.msgno = msgno;
	}

	public String getCmd() {
		return cmd;
	}

	public void setCmd(String cmd) {
		this.cmd = cmd;
	}

	public String getRetcode() {
		return retcode;
	}

	public void setRetcode(String retcode) {
		this.retcode = retcode;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValikey() {
		return valikey;
	}

	public void setValikey(String valikey) {
		this.valikey = valikey;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getOrgcode() {
		return orgcode;
	}

	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

}
