package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.processor;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccb.corp.kft.util.CcbCorpProcessXmlService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.corp.NoticeBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.NoticeParam;
import com.lycheepay.clearing.adapter.common.service.biz.CorpAccNoticeProcess;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 建行银企到账通知实现类 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-lfm
 * @version 1.0
 */
@Service
public class CcbCorpNoticeProcessor {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCB_CORP_PROCESS_XML_SERVICE)
	private CcbCorpProcessXmlService ccbCorpProcessXmlService;

	/**
	 * 主处理方法
	 */
	public void deal(NoticeParam nparam) throws BizException {
		try {
			// 生成到账明细beanList
			ArrayList<NoticeBean> noticeList = new ArrayList<NoticeBean>();
			makeBeanList(nparam, noticeList);
			// 处理到账
			if (noticeList.size() > 0) {
				CorpAccNoticeProcess.accNotice(noticeList);
			} else {
				Log4jUtil.info("建行银企：【" + nparam.getNoticeDate() + "】 日的到账记录数为0，无到账数据");
			}
		} catch (BizException e) {
			Log4jUtil.error(e);
			throw new BizException("建行银企到账通知处理出错: " + e);
		}
	}

	/**
	 * 解析6W0400应答报文,将应答报文中的到账记录循环取出, 存入元素为NoticeBean的ArrayList
	 * 
	 * @param nparam
	 * @return
	 * @throws BizException
	 */
	private ArrayList<NoticeBean> parseXML(String xmlStr, NoticeParam nparam, ArrayList<NoticeBean> noticeList)
			throws BizException {
		// 解析xml报文
		Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(xmlStr.getBytes(Charset.forName("GBK")));
		// 获取xml中节点的到账记录
		List<Node> nodeItemList = dom4jxml.getNodeList("/TX/TX_INFO/DETAIL");
		// 循环处理
		int noticeRecord = 0;// 到账记录数
		int j = nodeItemList.size();
		String creditNo;// 凭证号码
		String creditType;// 凭证类型
		String tranTime;// 交易时间
		for (int i = 0; i < j; i++) {
			Node nodeItem = nodeItemList.get(i);
			String dORc = dom4jxml.getNodeText(nodeItem, "dORc").toString();// 0:借 1:贷 这里只处理1的
			double amount = Double.parseDouble(dom4jxml.getNodeText(nodeItem, "AMOUNT"));// 贷方发生额
			if (dORc.equals("1") && amount > 0) {
				NoticeBean noticeBean = new NoticeBean();
				noticeBean.setPayerBankCardNo(dom4jxml.getNodeText(nodeItem, "ACC_NO1"));// 付款人帐号
				noticeBean.setPayerBankCardName(dom4jxml.getNodeText(nodeItem, "ACC_NAME1"));// 付款人户名
				noticeBean.setPayerBankCode("");// 付款人开户银行
				noticeBean.setTradeAmount(amount);// 交易金额
				creditNo = dom4jxml.getNodeText(nodeItem, "CREDIT_NO");// 凭证号码
				creditType = dom4jxml.getNodeText(nodeItem, "CREDIT_TYPE");// 凭证类型
				tranTime = dom4jxml.getNodeText(nodeItem, "TRAN_TIME");// 交易时间
				// 付款人账号+凭证号码+凭证类型 + 交易时间 ------------组成唯一流水
				noticeBean.setBankSn(dom4jxml.getNodeText(nodeItem, "ACC_NO1") + creditNo + creditType
						+ tranTime.replace(":", ""));// 凭证号码
				noticeList.add(noticeBean);
				noticeRecord++;
			}
		}// for
		Log4jUtil.info("建行银企：【" + nparam.getNoticeDate() + " 】日的到账记录数为:" + String.valueOf(noticeRecord));
		return noticeList;
	}

	/**
	 * 生成到账处理用的beanList
	 * 
	 * @param nparam
	 * @param noticeList
	 * @throws BizException
	 */
	private void makeBeanList(NoticeParam nparam, ArrayList<NoticeBean> noticeList) throws BizException {
		// 获取当前自然日到账查询
		Log4jUtil.info("当前自然日:" + nparam.getNoticeDate());
		String sendXml = ccbCorpProcessXmlService.create6W0400XML(nparam);
		Log4jUtil.debug("创建当前自然日到账查询请求xml:" + sendXml);
		String RespXml = ccbCorpProcessXmlService.sendXML(sendXml);
		Log4jUtil.debug("获取当前自然日到账查询响应xml:" + RespXml);
		parseXML(RespXml, nparam, noticeList);
		// 获取当前自然日前一天到账结果
		Log4jUtil.info("当前自然日前一天:" + DateUtil.getCurrentChnDateFront());
		sendXml = ccbCorpProcessXmlService.create6W0300XML("1", null, DateUtil.getCurrentChnDateFront());
		Log4jUtil.debug("创建当前自然日前一天到账到账查询请求xml:" + sendXml);
		RespXml = ccbCorpProcessXmlService.sendXML(sendXml);
		Log4jUtil.debug("获取当前自然日前一天到账到账查询响应xml:" + RespXml);
		parseXML(RespXml, nparam, noticeList);
	}
}
