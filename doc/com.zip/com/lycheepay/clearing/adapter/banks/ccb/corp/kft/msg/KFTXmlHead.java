package com.lycheepay.clearing.adapter.banks.ccb.corp.kft.msg;

public class KFTXmlHead {
	private String ver = "";
	private String src = "";
	private String des = "";
	private String msgID = "";
	private String msgCode = "";
	private String msgRef = "";
	private String workDate = "";
	private String timeStamp = "";
	private String reserve = "";

	public String getVer() {
		return ver;
	}

	public void setVer(final String ver) {
		this.ver = ver;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(final String src) {
		this.src = src;
	}

	public String getDes() {
		return des;
	}

	public void setDes(final String des) {
		this.des = des;
	}

	public String getMsgID() {
		return msgID;
	}

	public void setMsgID(final String msgID) {
		this.msgID = msgID;
	}

	public String getMsgRef() {
		return msgRef;
	}

	public void setMsgRef(final String msgRef) {
		this.msgRef = msgRef;
	}

	public String getWorkDate() {
		return workDate;
	}

	public void setWorkDate(final String workDate) {
		this.workDate = workDate;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(final String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(final String reserve) {
		this.reserve = reserve;
	}

	public String getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(final String msgCode) {
		this.msgCode = msgCode;
	}

}
