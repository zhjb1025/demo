package com.lycheepay.clearing.adapter.banks.cciticb.corp.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.soofa.core.exception.IllegalArgumentException;

import com.lycheepay.clearing.adapter.banks.cciticb.corp.config.FieldConfig.FieldDataType;
import com.lycheepay.clearing.util.Log4jUtil;


public class MessageConfig {
	public static String RESPONSE_SUCCESS_CODE = "AAAAAAA";
	public static String IS_DEDUCT_FLAG = "0";
	public static String IS_PAY_FLAG = "1";
	public static int MSG_HEAD_LENGTH = 5;
	public static int MSG_TAIL_LENGTH = 16;
	public static int MSG_TYPE_LENGTH = 4;
	public static int PROCESS_CODE_LENGTH = 4;
	
	private static Map<MessageType, List<FieldConfig>> configCache = new ConcurrentHashMap<MessageType, List<FieldConfig>>();

	static {
		try {
			URL resourcesUrl = MessageConfig.class.getResource("/cciticb/config");
			if(resourcesUrl.getFile().contains(".jar")) {
				JarFile jarFile = new JarFile(MessageConfig.class.getProtectionDomain().getCodeSource().getLocation().getPath());
				Enumeration<JarEntry> e = jarFile.entries();
				while(e.hasMoreElements()) {
					JarEntry entry = (JarEntry) e.nextElement();
					String s ="cciticb/config/(\\w*).xml";
					Pattern p = Pattern.compile(s);
					Matcher m = p.matcher(entry.getName());
					if(m.find()) {
						InputStream is = jarFile.getInputStream(entry);
						List<FieldConfig> configList = getFieldConfigList(is);
						//System.out.println(m.group(1));
						configCache.put(MessageType.valueOf(m.group(1)), configList);
					}
				}
			} else {
				File[] configFiles = new File(resourcesUrl.getFile()).listFiles();
				for (File file : configFiles) {
					String cfgType = file.getName().split("\\.")[0];
					List<FieldConfig> configList = getFieldConfigList(new FileInputStream(file));
					configCache.put(MessageType.valueOf(cfgType), configList);
				}
			}

		} catch (Exception e) {
			Log4jUtil.error("MessageConfig init error!", e);
		}
	}	

	private static List<FieldConfig> getFieldConfigList(InputStream is) {
		List<FieldConfig> cfgList = new ArrayList<FieldConfig>();
		SAXReader reader = new SAXReader();
		Document document;
		try {
			document = reader.read(is);
			is.close();
		} catch (Exception e) {
			throw new RuntimeException("Read configuration file error!" );
		}
		@SuppressWarnings("unchecked")
		List<Element> nodeList = document.selectNodes("//configuration//field");
		for (Element node : nodeList) {
			FieldConfig fieldConfig = new FieldConfig();
			fieldConfig.setType(FieldDataType.valueOf(node.attributeValue("type")));
			fieldConfig.setId(node.attributeValue("id"));
			fieldConfig.setLength(Integer.parseInt(node.attributeValue("length")));
			fieldConfig.setName(node.attributeValue("name"));
			fieldConfig.setRequired(Boolean.valueOf(node.attributeValue("required")));
			fieldConfig.setDefaultValue(node.attributeValue("defaultValue"));
			cfgList.add(fieldConfig);
		}
		return cfgList;
	}

	public static List<FieldConfig> getMessageConfig(MessageType messageType) {
		return Collections.unmodifiableList(configCache.get(messageType));
	}

	public enum MessageType {
		REAL_TRANSACTION_REQUEST("0200","0114"),REAL_TRANSACTION_RESPONSE("0210","0114"),
		UNDO_TRANSACTION_REQUEST("0200","0116"),UNDO_TRANSACTION_RESPONSE("0210","0116"),
		VERIFY_ACCOUNT_REQUEST("0100","0110"),VERIFY_ACCOUNT_RESPONSE("0110","0110"),
		QUERY_REQUEST("0100","0112"),QUERY_RESPONSE("0110","0112");		
		
		private String messageType;
		private String processCode;
		
		MessageType(String messageType,String processCode) {
			this.messageType = messageType;
			this.processCode = processCode;
		}		
		
		public String getMessageType() {
			return messageType;
		}

		public String getProcessCode() {
			return processCode;
		}
		
		public static MessageType valueOf(String messageType,String processCode) {
			for (MessageType type : MessageType.values()) {
				if (type.getMessageType().equals(messageType) && type.getProcessCode().equals(processCode)) {
					return type;
				}
			}
			throw new IllegalArgumentException("cannot find any type matched! messageType=" + messageType+",processCode="+processCode);
		}
		
		public static MessageType getResponseMessageType(MessageType requestType) {
			String type = requestType.toString();
			if (!type.contains("REQUEST")) {
				throw new IllegalArgumentException("wrong request message type!type=" + type);
			}
			int i = type.lastIndexOf("_");
			return MessageType.valueOf(type.substring(0, i) + "_RESPONSE");
		}
	}

}
