package com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util;

import java.security.Security;
import java.util.Map;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * @author txy
 * 
 */
public class SendUtil {
	private static Call call = null;

	public static synchronized Call getCallInstance(String optionName, Map<String, String> channelParms)
			throws BizException {
		String endpoint = channelParms.get("100020");
		String soapActionURI = channelParms.get("100021");

		if (call == null) {
			Log4jUtil.info("-----------创建new的Call对象-------------");
			setSSLProperty(channelParms);
			try {
				Service service = new Service();
				call = (Call) service.createCall();
				call.setTargetEndpointAddress(endpoint);
				call.setMaintainSession(true);
				// call.setOperationName(optionName);
				call.addParameter("paraXML", org.apache.axis.Constants.XSD_STRING, javax.xml.rpc.ParameterMode.IN);
				call.setReturnType(org.apache.axis.Constants.XSD_STRING);
				call.setUseSOAPAction(true);
				call.setSOAPActionURI(soapActionURI);

			} catch (Exception e) {
				Log4jUtil.error("-----------转换Call对象出错-------------", e);
				throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
			}
		} else {
			Log4jUtil.info("-----------已经存在Call对象,无需创建-------------");
		}

		call.setOperationName(optionName);
		Log4jUtil.info("-----------当前的报文的Operation名称为:" + optionName);
		return call;
	}

	/**
	 * setSSLProperty
	 */
	private static void setSSLProperty(Map<String, String> channelParms) {
		String keyStore_pfx_path = channelParms.get("100022");
		String truststore_path = channelParms.get("100023");
		String trustStorePassword = channelParms.get("100024");
		String keyStorePassword = channelParms.get("100025");
		String keyStoreType = channelParms.get("100026");
		String trustStoreType = channelParms.get("100027");

		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		System.setProperty("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
		System.setProperty("javax.net.ssl.keyStore", keyStore_pfx_path);
		System.setProperty("javax.net.ssl.trustStore", truststore_path);
		System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
		System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);
		System.setProperty("javax.net.ssl.keyStoreType", keyStoreType);
		System.setProperty("javax.net.ssl.trustStoreType", trustStoreType);
	}
}
