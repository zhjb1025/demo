package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

import java.util.ArrayList;
import java.util.List;


/**
 * 
 * <P>对帐接口实体类</P>
 * 
 * @author 汤兴友
 */
public class CheckAccount {
	private String infoType; // 信息类型
	private String posTime; // POS交易时间
	private String posID; // POS本地流水号
	private String transTime; // 交易时间
	private String transDate; // 交易日期
	private String retCode; // 返回码
	private String terminalID; // 终端号
	private String merchantID; // 商户号
	private String merchantName; // 商户名称
	private String batchNo; // 批次号
	private List<CheckAccountRecord> records = new ArrayList<CheckAccountRecord>(); // 明细交易记录
	private String terminalFlag; // 对帐终止符号
	private String commentRes; // 附加响应
	private String reserved; // 保留域

	public String getInfoType() {
		return infoType;
	}

	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}

	public String getPosTime() {
		return posTime;
	}

	public void setPosTime(String posTime) {
		this.posTime = posTime;
	}

	public String getPosID() {
		return posID;
	}

	public void setPosID(String posID) {
		this.posID = posID;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}

	public String getTerminalID() {
		return terminalID;
	}

	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}

	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public List<CheckAccountRecord> getRecords() {
		return records;
	}

	public void setRecords(List<CheckAccountRecord> records) {
		this.records = records;
	}

	public String getTerminalFlag() {
		return terminalFlag;
	}

	public void setTerminalFlag(String terminalFlag) {
		this.terminalFlag = terminalFlag;
	}

	public String getCommentRes() {
		return commentRes;
	}

	public void setCommentRes(String commentRes) {
		this.commentRes = commentRes;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}
}
