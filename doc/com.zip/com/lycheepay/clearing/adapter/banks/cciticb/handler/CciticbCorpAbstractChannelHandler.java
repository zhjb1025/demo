package com.lycheepay.clearing.adapter.banks.cciticb.handler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.lycheepay.clearing.adapter.banks.cciticb.constant.AccountNoState;
import com.lycheepay.clearing.adapter.banks.cciticb.corp.CiticbCorpProcessCallback;
import com.lycheepay.clearing.adapter.banks.cciticb.corp.config.FieldConfig;
import com.lycheepay.clearing.adapter.banks.cciticb.corp.config.MessageConfig;
import com.lycheepay.clearing.adapter.banks.cciticb.corp.config.MessageConfig.MessageType;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.biz.ClearingResult;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.net.SendBySocket;
import com.lycheepay.clearing.adapter.common.util.security.MACUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


public abstract class CciticbCorpAbstractChannelHandler extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	protected SequenceManagerService sequenceManager;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	protected String channelId = ChannelIdEnum.CNCB_CORP.getCode();

	public <K> ClearingResultDTO processRealTransaction(final K k, CiticbCorpProcessCallback<K> callBack)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CiticbCorp", "direct");
		Log4jUtil.debug("dto:" + k);
		ClearingResultDTO result = null;
		try {
			Map<String, String> channelParms = channelParamService.queryNameParamsMapByChannelId(channelId);
			Map<String, String> request = callBack.buildMessage(k);
			BillnoSn billnosn = billnoSnService.saveBillnoSn(request.get("bankSendSn"), channelId, k);
			String responseString = sendMessage(request, MessageType.REAL_TRANSACTION_REQUEST, channelParms);
			Map<String, String> response = parseResponseMessage(responseString, channelParms);
			billnosn.setPayState(MessageConfig.RESPONSE_SUCCESS_CODE.equals(response.get("returnCode"))?"1":"2");
			billnosn.setBankRecvSn(response.get("preposeSn"));
			try {
				billnoSnService.updateBillnoSn(billnosn, response.get("returnCode"), response.get("returnInfo"));
				result = getClearingResult(MessageType.REAL_TRANSACTION_REQUEST,response);
			} catch (Exception e) {
				Log4jUtil.error("Error occured! Begin to undo the transaction...",e);				
				ClearingResultDTO undoResult = undoTransaction(request, response);
				result = new ClearingResult();
				result.setTxnStatus(TxnStatus.FAILED);
				if (undoResult.getTxnStatus() == TxnStatus.SUCCEED) {
					result.setChannelResponseMsg("交易处理失败,后续的冲正交易已成功！");
				} else {
					Log4jUtil.debug("冲正失败:{}", undoResult.getChannelResponseMsg());
					throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
				}
				result.setChannelResponseCode(TransReturnCode.code_9900);
			}
			result.setChannelId(channelId);
			result.setClearingTransType(callBack.getTransType().getKey());
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, result);
		}
		return result;
	}

	public <K> ClearingResultDTO processQuery(final K k, CiticbCorpProcessCallback<K> callBack)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.debug("dto:" + k);
		ClearingResultDTO result = null;
		try {
			Map<String, String> channelParms = channelParamService.queryNameParamsMapByChannelId(channelId);
			Map<String, String> message = callBack.buildMessage(k);
			MessageType requestType = MessageType.valueOf(message.get("msgID"));
			String responseString = sendMessage(message, requestType, channelParms);
			Map<String, String> response = parseResponseMessage(responseString, channelParms);
			result = getClearingResult(requestType,response);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, result);
		}
		return result;
	}

	private ClearingResultDTO undoTransaction(Map<String, String> requestMessage, Map<String, String> responseMessage)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.debug("requestMessage:" + requestMessage);
		Log4jUtil.debug("responseMessage:" + responseMessage);
		ClearingResultDTO result = null;
		try {
			Map<String, String> channelParms = channelParamService.queryNameParamsMapByChannelId(channelId);
			Map<String, String> undoMessage = new HashMap<String, String>();
			undoMessage.put("transactionDate", DateUtil.getCurrentDate());
			undoMessage.put("transactionTime", DateUtil.getCurrentTime());
			undoMessage.put("bankSendSn", sequenceManager.getCiticbCorpSN());
			undoMessage.put("undoPreposeDate", responseMessage.get("preposeDate"));
			undoMessage.put("undoPreposeSn", responseMessage.get("preposeSn"));
			undoMessage.put("payerAccountNo", requestMessage.get("payerAccountNo"));
			undoMessage.put("amount", requestMessage.get("transactionAmount"));
			String responseString = sendMessage(undoMessage, MessageType.UNDO_TRANSACTION_REQUEST, channelParms);
			Map<String, String> response = parseResponseMessage(responseString, channelParms);
			result = getClearingResult(MessageType.UNDO_TRANSACTION_REQUEST,response);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, result);
		}
		return result;
	}

	private String sendMessage(Map<String, String> message, MessageType type, Map<String, String> channelParms)
			throws BizException {
		String socketIP = channelParms.get("socketIP");
		String socketPort = channelParms.get("socketPort");
		String macKey = channelParms.get("macKey");
		Log4jUtil.debug(type.toString() + " message:" + message);
		StringBuilder sendInfo = new StringBuilder();
		List<FieldConfig> fieldConfigs = MessageConfig.getMessageConfig(type);
		int msgContentLength = 0;
		for (FieldConfig config : fieldConfigs) {
			String value = message.get(config.getId());
			if (value == null) {
				value = config.getDefaultValue();
			}
			sendInfo.append(config.toMsgString(value));
			msgContentLength += config.getLength();
		}
		sendInfo.append(MACUtils.macX99(macKey, sendInfo.toString()));
		sendInfo.insert(0, StringUtil.fillNumberWithZeroOnLeft(
				String.valueOf(msgContentLength + MessageConfig.MSG_TAIL_LENGTH), MessageConfig.MSG_HEAD_LENGTH));

		SendBySocket sendBySocket = new SendBySocket();
		Log4jUtil.debug("send message:{}", sendInfo.toString());
		return sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo.toString());
	}

	private Map<String, String> parseResponseMessage(String response, Map<String, String> channelParms)
			throws BizException {
		Log4jUtil.debug("receive message:{}", response);
		validateMessage(response, channelParms.get("macKey"));

		MessageType messageType = getMessageType(response);
		Log4jUtil.debug("We got a new {} message!", messageType.toString());

		List<FieldConfig> fieldConfigs = MessageConfig.getMessageConfig(messageType);
		Map<String, String> message = new HashMap<String, String>(fieldConfigs.size());
		int startPos = MessageConfig.MSG_HEAD_LENGTH;
		try {
			for (FieldConfig fieldConfig : fieldConfigs) {
				String fieldMsgString = StringUtil.subGBKString(response, startPos, fieldConfig.getLength());
				String fieldValue = fieldConfig.toFieldValue(fieldMsgString);
				message.put(fieldConfig.getId(), fieldValue);
				startPos += fieldConfig.getLength();
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "parse response message error! Message=" + response);
		}
		Log4jUtil.debug("message content:" + message);
		return message;
	}

	private ClearingResultDTO getClearingResult(MessageType messageType,Map<String, String> response) {
		Log4jUtil.info("messageType:{}, response:{}", messageType, response);
		ClearingResultDTO result = new ClearingResultDTO();
		result.setChannelId(channelId);
		String returnInfo = response.get("returnInfo");
		String returnCode = response.get("returnCode");

		if (MessageConfig.RESPONSE_SUCCESS_CODE.equals(returnCode)) {
			result.setTxnStatus(TxnStatus.SUCCEED);
		} else {
			result.setTxnStatus(TxnStatus.FAILED);
		}
		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, returnCode));
		if (channelRtncode != null) {
			result.setChannelResponseCode(channelRtncode.getKftRtncode());
			returnInfo = channelRtncode.getChannelReamrk();
		} else {
			result.setChannelResponseCode(TransReturnCode.code_9900);
		}

		if (MessageConfig.RESPONSE_SUCCESS_CODE.equals(returnCode) && messageType == MessageType.VERIFY_ACCOUNT_REQUEST) {
			// 如果输入账号：正常：01;部分冻结：02;全部冻结：03;挂失：04;暂禁：05;看管：06;如果输入卡号：正常：01;部分冻结：02;全部冻结：03;挂失：04;
			String accountState = response.get("accountState");
			Log4jUtil.info("accountState:{} ", accountState);
			if ("01".equals(accountState)) {
				result.setTxnStatus(TxnStatus.SUCCEED);
				result.setChannelResponseCode(TransReturnCode.code_0000);
				returnInfo = "验证成功,账户状态：正常";
			} else {
				result.setTxnStatus(TxnStatus.FAILED);
				result.setChannelResponseCode(TransReturnCode.code_2005);
				returnInfo = "验证失败,账户状态:" + AccountNoState.getDescByKeyCode(accountState).getDesc();
			}
		} else if (MessageConfig.RESPONSE_SUCCESS_CODE.equals(returnCode)
				&& messageType == MessageType.QUERY_REQUEST) {
			// 0：成功 1：冲正成功 2：自动冲正成功 3：交易未结束，单边已扣帐 4：交易正在处理 5：失败 其他：交易失败
			String transactionState = response.get("transactionState");
			if ("0".equals(transactionState)) {
				result.setTxnStatus(TxnStatus.SUCCEED);
				result.setChannelResponseCode(TransReturnCode.code_0000);
				returnInfo = "交易成功";
			} else if ("1".equals(transactionState) || "2".equals(transactionState) || "5".equals(transactionState)) {
				result.setTxnStatus(TxnStatus.FAILED);
				result.setChannelResponseCode(TransReturnCode.code_9900);
				returnInfo = "交易失败";
			} else if ("3".equals(transactionState) || "4".equals(transactionState)) {
				result.setTxnStatus(TxnStatus.UNKNOW);
				result.setChannelResponseCode("");
				returnInfo = "交易处理中";
			}else{
				result.setTxnStatus(TxnStatus.FAILED);
				result.setChannelResponseCode(TransReturnCode.code_9900);
				returnInfo = "交易失败";
			}
		}  
		Log4jUtil.debug("returnInfo:{}", returnInfo);
		result.setChannelResponseMsg(returnInfo);
		
		return result;
	}

	private void validateMessage(String response, String macKey) throws BizException {
		int indexOfSign = response.length() - MessageConfig.MSG_TAIL_LENGTH;
		String responseSign = response.substring(indexOfSign);
		String macSign = MACUtils.macX99(macKey, response.substring(MessageConfig.MSG_HEAD_LENGTH, indexOfSign));
		if (!responseSign.equals(macSign)) {
			throw new BizException(TransReturnCode.code_9109, "verify mac sign error! Message=" + response);
		}
		Log4jUtil.debug("message validate successfully!");
	}

	private MessageType getMessageType(String message) {
		String messageType = message.substring(MessageConfig.MSG_HEAD_LENGTH, MessageConfig.MSG_HEAD_LENGTH
				+ MessageConfig.MSG_TYPE_LENGTH);
		String processCode = message.substring(MessageConfig.MSG_HEAD_LENGTH + MessageConfig.MSG_TYPE_LENGTH,
				MessageConfig.MSG_HEAD_LENGTH + MessageConfig.MSG_TYPE_LENGTH + MessageConfig.PROCESS_CODE_LENGTH);
		return MessageType.valueOf(messageType, processCode);
	}

}
