package com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.processor;

import java.io.File;
import java.rmi.RemoteException;
import java.util.Map;

import org.apache.axis.client.Call;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccount;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogin;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogout;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPayment;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPaymentReversal;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Download;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.HirePurchaseReturn;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.MaintainSession;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Settlement;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.CiticChannelParm;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.CiticUtil;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.SendAndRecXmlUtil;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.SendUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.StringUtil;


/**
 * 
 * <P>发送报文和接受返回访问的类</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.CCITICB_SENDANDREC_SERVICE)
public class CciticbSendAndRecService {
	private static String channelId = ChannelIdEnum.ECITIC_CREDIT_CARD.getCode();

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	/**
	 * 
	 * <p>WebService通信类</p>
	 * 
	 * @param call
	 * @param xmlSend
	 * @param xmlReceive
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public Object invoke(Call call, String xmlSend) throws BizException {
		Object xmlReceive = null;
		try {
			xmlReceive = call.invoke(new Object[] { xmlSend });
		} catch (RemoteException e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		}
		return xmlReceive;
	}

	/**
	 * 
	 * <p>获取参数</p>
	 * 
	 * @return
	 * @author 汤兴友 xytang
	 */
	private Map<String, String> getProperty() {
		Map<String, String> channelParms = (Map<String, String>) channelParmService
				.queryCodeParamsMapByChannelId(channelId);
		return channelParms;
	}

	/**
	 * 
	 * <p>Failed ReturnState</p>
	 * 
	 * @return
	 * @author 汤兴友 xytang
	 */
	private ReturnState mkFailRs(String msg) {
		ReturnState rs = new ReturnState();
		rs.setReturnState(PayState.UNKNOW_STR);
		rs.setChannelCode(TransReturnCode.code_9109);
		rs.setCheckDate(DateUtil.getCurrentDate());
		rs.setReturnMsg(msg);
		return rs;
	}

	/**
	 * 发送登录报文和接受回执的方法
	 * 
	 * @param creditLogin 登录报文发送实体
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecLogin(CiticChannelParm p, String channelId) throws BizException {
		Log4jUtil.info("----------开始进入发送登陆报文与接受登录结果的方法----------");

		CreditLogin loginRsp = this.login(p);
		if (loginRsp == null) {
			throw new BizException(TransReturnCode.code_9109, "登录失败，返回的报文是空的，交易时间是" + DateUtil.getCurrentDateTime());
		}
		return this.getLoginReturnState(loginRsp, channelId);
	}

	/**
	 * 签到
	 * 
	 * @param loginReq
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public CreditLogin login(CiticChannelParm p) throws BizException {
		CiticUtil citicUtil = new CiticUtil();
		CreditLogin loginReq = citicUtil.getCreitLogin(p.getTerminalID(), p.getMerchantId(), p.getPassword());

		// 调用生成登录报文的方法
		String xmlSend = SendAndRecXmlUtil.createCreditLoginXml(loginReq);

		Log4jUtil.info("----------登录 请求报文是：" + xmlSend);
		Call call = SendUtil.getCallInstance("login", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------登录 回执报文是：" + xmlReceive);

		return SendAndRecXmlUtil.parseCreditLoginXml(xmlReceive);
	}

	/**
	 * 发送和接受登出报文的方法
	 * 
	 * @param creditLogout // 登出报文发送实体
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecLogout(CreditLogout creditLogout, String channelId) throws BizException {
		Log4jUtil.info("----------开始进入发送登出报文与接受登出结果的方法----------");

		ReturnState returnState = new ReturnState();
		String xmlSend = SendAndRecXmlUtil.createCreditLogoutXML(creditLogout);

		Log4jUtil.info("----------登出 请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("logout", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------登出 回执报文是：" + xmlReceive);

		if (xmlReceive != null && !"".equals(xmlReceive.toString())) {
			// 调用解析返回报文的方法
			CreditLogout credit = SendAndRecXmlUtil.parseCreditLogoutXml(xmlReceive.toString());

			returnState = this.getLogoutReturnState(credit, channelId);
		} else {
			return mkFailRs("登出超时");
		}
		return returnState;
	}

	/**
	 * 发送分期支付报文并接受回执的方法
	 * 
	 * @param collection
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecDividedPayment(CiticChannelParm p, DividedPayment dividedPayment, Param param,
			BillnoSn billnoSn) throws BizException {
		Log4jUtil.info("----------开始进入发送分期支付报文与接受分期支付结果的方法----------");

		// 调用组建分期支付报文的方法
		String xmlSend = SendAndRecXmlUtil.createDividedPaymentXML(dividedPayment);
		ReturnState returnState = new ReturnState();

		Log4jUtil.info("----------支付报文 请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("dividedPayment", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------支付报文 响应报文是：" + xmlReceive);

		if (xmlReceive == null || "".equals(xmlReceive.toString())) {
			// 调用发送分期支付冲正报文的方法
			sendAndRecDividedPaymentReversal(dividedPayment);

			Log4jUtil.info("中信银行信用卡分期支付超时，执行时间是：" + DateUtil.getCurrentDateTime());
			return mkFailRs("分期支付交易超时");
		}

		// 调用解析返回报文的方法
		DividedPayment payment = SendAndRecXmlUtil.parseDividedPaymentXML(xmlReceive.toString());

		// 如果出现"未登陆"的情况，将做重签到交易,然后再重做交易
		if (payment.getRetCode().equals("6666661")) {
			// 1.重签到交易
			this.login(p);

			// 2.重做交易
			Log4jUtil.info("----------重发支付 请求报文是：" + xmlSend);
			call = SendUtil.getCallInstance("dividedPayment", getProperty());
			xmlReceive = this.invoke(call, xmlSend);
			Log4jUtil.info("----------重发支付 响应报文是：" + xmlReceive);

			// 调用解析返回报文的方法
			payment = SendAndRecXmlUtil.parseDividedPaymentXML(xmlReceive.toString());
		}

		// 调用封装ReturnState的方法
		returnState = this.getDividedPaymentReturnState(payment, billnoSn, param);

		return returnState;
	}

	/**
	 * 发送分期支付冲正对象的方法
	 * 
	 * @param dividedPayment
	 * @return
	 * @throws BizException
	 */
	public void sendAndRecDividedPaymentReversal(DividedPayment dividedPayment) throws BizException {
		Log4jUtil.info("----------开始进入发送分期支付冲正报文与接受分期支付结果的方法----------");

		// 调用实例化分期支付冲正对象的方法
		CiticUtil citicUtil = new CiticUtil();
		DividedPaymentReversal dividedPaymentReversal = citicUtil.getDividedPaymentReversal(dividedPayment);
		// 调用组建分期支付冲正对象的方法
		String xmlSend = SendAndRecXmlUtil.createDividedPaymentReversalXML(dividedPaymentReversal);

		Log4jUtil.info("中信银行信用卡：组建好的分期支付报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("dividedPaymentReversal", getProperty());
		this.invoke(call, xmlSend);
	}

	/**
	 * 发送分期支付冲正对象的方法(实时)
	 * 
	 * @param dividedPayment
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecDividedPaymentReversal2(Param param, DividedPaymentReversal dividedPaymentReversal)
			throws BizException {
		Log4jUtil.info("----------开始进入发送分期支付冲正报文与接受分期支付结果的方法----------");

		// 调用组建分期支付冲正对象的方法
		String xmlSend = SendAndRecXmlUtil.createDividedPaymentReversalXML(dividedPaymentReversal);
		ReturnState returnState = new ReturnState();

		Log4jUtil.info("----------撤销或冲正，请求报文是:" + xmlSend);

		Call call = SendUtil.getCallInstance("dividedPaymentReversal", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------撤销或冲正，响应报文是:" + xmlReceive);

		if (xmlReceive != null && !("".equals(xmlReceive.toString()))) {
			// 调用解析返回报文的方法
			DividedPaymentReversal paymentReversal = SendAndRecXmlUtil.parseDividedPaymentReversalXML(xmlReceive
					.toString());
			// 调用封装ReturnState的方法
			returnState = this.getDividedPaymentReversalReturnState(paymentReversal, param);
		} else {
			Log4jUtil.info("中信银行信用卡分期支付冲正超时，执行时间是：" + DateUtil.getCurrentDateTime());
			return mkFailRs("分期支付冲正交易超时");
		}

		return returnState;
	}

	/**
	 * 发送分期支付退款交易报文与接受回执的方法(实时)
	 * 
	 * @param hirePurchaseReturn 退款交易实体
	 * @param channelBatchId 渠道批次号
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecHirePurchaseReturn2(Param param, HirePurchaseReturn hirePurchaseReturn,
			BillnoSn billnoSn) throws BizException {
		Log4jUtil.info("----------开始进入发送分期支付退款报文与接受分期支付结果的方法----------");

		// 调用组建分期支付退款报文的方法
		String xmlSend = SendAndRecXmlUtil.createHirePurchaseReturnXML(hirePurchaseReturn);
		ReturnState returnState = new ReturnState();

		Log4jUtil.info("----------退款，请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("hirePurchaseReturn", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------退款，响应报文是：" + xmlReceive);

		if (xmlReceive != null && !"".equals(xmlReceive.toString())) {
			// 调用解析报文的方法
			HirePurchaseReturn purchaseReturn = SendAndRecXmlUtil.parseHirePurchaseReturnXML(xmlReceive.toString());
			// 调用封装分期支付退款returnState的方法
			returnState = this.getHirePurchaseReturnReturnState(purchaseReturn, billnoSn, param);
		} else {
			return mkFailRs("分期支付退款交易超时");
		}
		return returnState;
	}

	/**
	 * 发送维护连接报文并接受回执的方法
	 * 
	 * @param param
	 * @param maintainSession
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecMaintainSession(Param param, MaintainSession maintainSession) throws BizException {
		Log4jUtil.setLogClass("channelLog" + File.separator + param.getChannelId(), param.getChannelId() + "QTimer");
		Log4jUtil.info("-----------开始进入发送维护连接报文与接受分期支付结果的方法-----------");

		// 调用组建维护连接报文的方法
		String xmlSend = SendAndRecXmlUtil.createMainSessionXML(maintainSession);
		ReturnState returnState = new ReturnState();

		// 发送报文并接受回执
		Log4jUtil.info("----------维护连接，请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("maintainSession", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------维护连接，响应报文是：" + xmlReceive);

		// 调用解析报文回执的方法
		MaintainSession maintainsession = SendAndRecXmlUtil.parseMainSessionXML(xmlReceive.toString(), param);

		// 调用封装ReturnState的方法
		returnState = this.getMainSessionReturnState(maintainsession, param);
		return returnState;
	}

	/**
	 * 发送结算接口报文并接受回执的方法
	 * 
	 * @param param
	 * @param terminalID 终端号
	 * @param merchantID 客户号
	 * @param batchId 批次号
	 * @param totalTrsCnt 交易总条数
	 * @param traSumAmt 交易总金额
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecSettlement(String channelId, Settlement settlement) throws BizException {
		Log4jUtil.info("-----------开始进入发送结算接口报文与接受分期支付结果的方法-----------");

		// 调用组建结算接口报文的方法
		String xmlSend = SendAndRecXmlUtil.createSettlementXML(settlement);
		ReturnState returnState = new ReturnState();

		Log4jUtil.info("----------结算接口，请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("settltment", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------结算接口，响应报文是：" + xmlReceive);

		if (xmlReceive != null && !("".equals(xmlReceive.toString()))) {
			// 调用解析回执的方法
			Settlement st = SendAndRecXmlUtil.parseSettlementXML(xmlReceive.toString());
			// 调用封装ReturnState的方法
			returnState = this.getSettlementReturnState(st, channelId);
		} else {
			return mkFailRs("结算接口调用失败");
		}

		return returnState;
	}

	/**
	 * 
	 * <p>发送明细请款报文与接受结果</p>
	 * 
	 * @param channelId
	 * @param CheckAccount
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendAndRecCheckAccount(String channelId, CheckAccount checkAccount) throws BizException {
		Log4jUtil.info("-----------开始进入发送明细请款报文与接受结果的方法-----------");
		ReturnState returnState = new ReturnState();

		// 调用组建明细请款报文的方法
		String xmlSend = SendAndRecXmlUtil.createCheckAccountXML(checkAccount);

		Log4jUtil.info("----------明细请款，请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("checkAccount", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------明细请款，响应报文是：" + xmlReceive);

		if (xmlReceive != null && !"".equals(xmlReceive.toString())) {
			// 调用解析回执的方法
			CheckAccount ca = SendAndRecXmlUtil.parseCheckAccountXML(xmlReceive.toString());
			// 调用封装ReturnState的方法
			returnState = this.getCheckAccountReturnState(ca, channelId);
		} else {
			return mkFailRs("明细请款调用失败");
		}
		return returnState;
	}

	/**
	 * 发送流水文件下载接口报文并接受回执的方法
	 * 
	 * @param download
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public Download sendAndrecDownload(Download download, String channelId) throws BizException {
		Log4jUtil.info("-----------开始进入发送流水文件下载接口报文与接受分期支付结果的方法-----------");

		// 调用流水文件下载接口报文的方法
		String xmlSend = SendAndRecXmlUtil.createDownloadXML(download);

		Log4jUtil.info("----------流水文件下载接口，请求报文是：" + xmlSend);

		Call call = SendUtil.getCallInstance("download", getProperty());
		Object xmlReceive = this.invoke(call, xmlSend);
		Log4jUtil.info("----------流水文件下载接口，响应报文是：" + xmlReceive);

		if (xmlReceive == null || "".equals(xmlReceive.toString())) {
			throw new BizException(TransReturnCode.code_9109, "流水文件下载接口调用失败，请重发");
		}
		Download dld = SendAndRecXmlUtil.parseDownload(xmlReceive.toString());

		return dld;
	}

	/**
	 * 封装登录交易的ReturnState的方法
	 * 
	 * @param creditLogin 登录报文返回对象
	 * @return
	 */
	private ReturnState getLoginReturnState(CreditLogin creditLogin, String channelId) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());
		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				creditLogin.getRetCode()));

		if (channelRtncode != null) {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
		}

		returnState.setBankRetCode(creditLogin.getRetCode());
		returnState.setBillnosnSeq(creditLogin.getPosID());
		returnState.setReturnObj(creditLogin);

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}

		return returnState;
	}

	/**
	 * 封装登出交易的ReturnState的方法
	 * 
	 * @param creditLogout 封装登出回执的信息的对象
	 * @param param
	 * @return
	 */
	private ReturnState getLogoutReturnState(CreditLogout creditLogout, String channelId) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());

		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				creditLogout.getRetCode()));

		if (channelRtncode != null) {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
		}

		returnState.setBankRetCode(creditLogout.getRetCode());
		returnState.setBillnosnSeq(creditLogout.getPosID());
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		return returnState;
	}

	/**
	 * 封装分期支付ReturnState的方法
	 * 
	 * @param d
	 * @param param
	 * @return
	 */
	private ReturnState getDividedPaymentReturnState(DividedPayment d, BillnoSn billnoSn, Param param) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());

		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(param
				.getChannelId(), d.getRetCode()));

		if (channelRtncode != null) {
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
			returnState.setBankPostScript(d.getCommentRes());
		}

		returnState.setBankRetCode(d.getRetCode());
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		returnState.setSn(param.getSn());
		returnState.setCreditNo(d.getPosID() + "#" + d.getAuthorizeCode());// 流水号#授权码
		returnState.setBankRetBatchId(d.getBatchNo());

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}

		return returnState;
	}

	/**
	 * 封装分期支付ReturnState的方法
	 * 
	 * @param dividedPayment
	 * @param param
	 * @return
	 */
	private ReturnState getDividedPaymentReversalReturnState(DividedPaymentReversal drs, Param param) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());

		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(param
				.getChannelId(), drs.getRetCode()));

		if (channelRtncode != null) {
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
		}

		returnState.setBankRetCode(drs.getRetCode());
		returnState.setReturnObj(drs.getAuthorizeCode());// 授权码
		returnState.setSn(param.getSn());

		returnState.setBankRetBatchId(drs.getBatchNo());
		
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setCreditNo(drs.getOrderID() + "#0#S");// 原订单号orderId#0；(其中数字0标示为撤销)
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setCreditNo(drs.getOrderID() + "#0#F");// 原订单号orderId#0；(其中数字0标示为撤销)
			returnState.setReturnState(PayState.FAILED_STR);
		}

		return returnState;
	}

	/**
	 * 封装分期支付退款returnState的方法
	 * 
	 * @param h 分期支付退款返回对象
	 * @return
	 */
	private ReturnState getHirePurchaseReturnReturnState(HirePurchaseReturn h, BillnoSn billnoSn,
			Param param) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());

		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(param
				.getChannelId(), h.getRetCode()));

		if (channelRtncode != null) {
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
		}

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}

		returnState.setBankRetBatchId(h.getBatchNo());
		returnState.setCreditNo(h.getOrderID() + "#1#" + h.getPosID());// 原订单号orderId#1#Pos流水号；(其中1标示为撤销)

		returnState.setBankRetCode(h.getRetCode());
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		returnState.setSn(param.getSn());

		return returnState;
	}

	/**
	 * 封装维护连接ReturnState的方法
	 * 
	 * @param maintainSession
	 * @return
	 */
	private ReturnState getMainSessionReturnState(MaintainSession maintainSession, Param param) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());

		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(param
				.getChannelId(), maintainSession.getRetCode()));

		if (channelRtncode != null) {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
		}

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		returnState.setBankRetCode(maintainSession.getRetCode());

		return returnState;
	}

	/**
	 * 封装结算接口ReturnState的方法
	 * 
	 * @param st
	 * @return
	 */
	private ReturnState getSettlementReturnState(Settlement st, String channelId) {
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());

		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				st.getRetCode()));

		if (channelRtncode != null) {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
		}

		returnState.setBankPostScript(st.getCommentRes());
		returnState.setReturnMsg(st.getCommentRes());
		returnState.setBankRetCode(st.getRetCode());

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}

		/**
		 * retCode为“00000000”，但是SuccessFlag不成功时，将查successFlag的值
		 */
		String flag = st.getSuccessFlag();
		if ("0000000".equals(st.getRetCode()) && !StringUtil.isBlank(flag)) {
			channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId, flag));
			if (channelRtncode != null) {
				returnState.setChannelCode(channelRtncode.getKftRtncode());
				returnState.setBankPostScript(channelRtncode.getChannelReamrk());
				returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			} else {
				returnState.setChannelCode(TransReturnCode.code_9900);
				returnState.setBankPostScript("核对失败");
				returnState.setReturnMsg("核对失败");
			}
		}

		return returnState;
	}

	/**
	 * 封装结算接口ReturnState的方法
	 * 
	 * @param ca
	 * @return
	 */
	private ReturnState getCheckAccountReturnState(CheckAccount ca, String channelId) {
		ReturnState returnState = new ReturnState();
		returnState.setReturnObj(ca);
		returnState.setCheckDate(DateUtil.getCurrentDate());

		// 根据银行返回码和渠道编号查询渠道
		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				ca.getRetCode()));

		if (channelRtncode != null) {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
		} else {
			returnState.setChannelCode(TransReturnCode.code_9900);
			returnState.setBankPostScript(ca.getCommentRes());
			returnState.setReturnMsg(ca.getCommentRes());
		}

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) { // 0000 为 ‘交易成功’
			returnState.setReturnState(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		returnState.setBankRetCode(ca.getRetCode());

		return returnState;
	}

}
