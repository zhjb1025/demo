package com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccount;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccountRecord;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogin;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogout;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPayment;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPaymentReversal;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.HirePurchaseReturn;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.MaintainSession;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Settlement;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.CiticChannelParm;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.CiticUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;
import com.lycheepay.clearing.util.ObjectUtil;


/**
 * <p>中信银行信用卡 业务处理类</p>
 * 
 * @version 1.0 Date：2011-12-28
 */

@Service(ClearingAdapterAnnotationName.CCITICB_CREDIT_DIRECT_PROCESS)
public class CciticbCreditDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCITICB_SENDANDREC_SERVICE)
	private CciticbSendAndRecService cciticbSendAndRecService;

	private static String channelId = ChannelIdEnum.ECITIC_CREDIT_CARD.getCode();

	private Boolean isSign = false;// 用于请款时标识是否签到

	/**
	 * 渠道参数
	 * 
	 * @return
	 * @throws BizException
	 */
	public CiticChannelParm getChannelParm() throws BizException {
		Map<String, String> map = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String terminalID = map.get("100002"); // 终端号
		String merchantId = map.get("100003"); // 商户号
		String password = map.get("100004"); // 商户登录密码
		String token = map.get("100006"); // 交易验证码
		String batchId = map.get("100007"); // 批次号
		String inputType = map.get("100009");  // POS输入方式
		String posCoditionCode = map.get("100010"); // 服务点条件码

		AssertUtils.notNull(terminalID, TransReturnCode.code_9108, "终端号");
		AssertUtils.notNull(merchantId, TransReturnCode.code_9108, "商户号");
		AssertUtils.notNull(password, TransReturnCode.code_9108, "商户登录密码");
		AssertUtils.notNull(token, TransReturnCode.code_9108, "交易验证码");
		AssertUtils.notNull(batchId, TransReturnCode.code_9108, "批次号");
		AssertUtils.notNull(inputType, TransReturnCode.code_9108, "POS输入方式");
		AssertUtils.notNull(posCoditionCode, TransReturnCode.code_9108, "服务点条件码");

		CiticChannelParm p = new CiticChannelParm();
		p.setTerminalID(terminalID);
		p.setMerchantId(merchantId);
		p.setPassword(password);
		p.setToken(token);
		p.setBatchId(batchId);
		p.setInputType(inputType);
		p.setPosCoditionCode(posCoditionCode);
		return p;
	}

	/**
	 * 登录
	 * 
	 * @return
	 * @throws BizException
	 */
	public ReturnState login() throws BizException {
		Log4jUtil.info("--进入中信银行信用卡登录方法----");

		// 调用发送登录报文并接收回执的方法
		ReturnState rs = cciticbSendAndRecService.sendAndRecLogin(this.getChannelParm(), channelId);
		ObjectUtil.printPropertyString("", rs);

		// 保存交易验证码Token
		if (rs.getChannelCode().equals(TransReturnCode.code_0000)) {
			CreditLogin login_ = (CreditLogin) rs.getReturnObj();

			ChannelParm pm = new ChannelParm();
			pm = (ChannelParm) channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100006"));
			String oldToken = pm.getParvalue();
			pm.setParvalue(login_.getToken());
			channelParmService.update(pm);
			Log4jUtil.info("----登录成功! 更新旧Token【{}】为新Token【{}】", oldToken, login_.getToken());
		} else {
			Log4jUtil.info("----登录失败! ");
		}

		return rs;
	}

	/**
	 * 登出
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState logout() throws BizException {
		Log4jUtil.info("---进入中信银行信用卡登出方法----");
		String logPrefix = "中信银行信用卡登出";

		// 调用查询中信银行信用卡的渠道参数的方法
		CiticChannelParm cp = this.getChannelParm();

		// 调用实例化登出对象的方法
		CreditLogout creditLogout = new CiticUtil().getCreditLogout(cp.getTerminalID(), cp.getMerchantId(),
				cp.getPassword());
		ObjectUtil.printPropertyString(logPrefix, creditLogout);

		// 调用发送登出报文并接受回执的方法
		ReturnState rs = cciticbSendAndRecService.sendAndRecLogout(creditLogout, channelId);
		ObjectUtil.printPropertyString(logPrefix, rs);

		return rs;
	}

	/**
	 * 分期支付 -- 实时代扣
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState directDeduct(Param param) throws BizException {
		Log4jUtil.info("--渠道ID【{}】,渠道业务【{}】开始处理--", channelId, param.getClearingTransType());

		DeductDTO directDeduct = (DeductDTO) param.getBizBean();
		AssertUtils.notNull(directDeduct, TransReturnCode.code_9108, "实时代扣请求数据中的交易业务bean[DeductDTO]不能为空!");

		if (directDeduct.getCvv2() == null) {
			directDeduct.setCvv2("");
		}

		// 调用组建分期支付交易对象的方法
		String bankSendSn = sequenceManagerService.getCciticbCreditSN();
		String posID = DateUtil.getCurrentTime();
		CiticChannelParm p = this.getChannelParm();

		CiticUtil citicUtil = new CiticUtil();
		DividedPayment payment = citicUtil.getDividedPayment(param, directDeduct, p, bankSendSn, posID);
		ObjectUtil.printPropertyString("", payment);

		// 保存到渠道流水表中
		BillnoSn billnoSn = billnoSnService.saveBillnoSn(bankSendSn, param);

		// 调用发送报文并接受回执的方法

		ReturnState returnState = cciticbSendAndRecService.sendAndRecDividedPayment(p, payment, param, billnoSn);

		/**
		 * 异常处理后可以重发 （ MBCH011 该批次号已被退货交易占用）
		 */
		if ("MBCH011".equalsIgnoreCase(returnState.getBankRetCode())) {

			String newBatchId = this.updateBachId(p.getBatchId());

			/**
			 * 重发交易
			 */
			Log4jUtil.info("--重发代扣交易-{}-{}-", p.getBatchId(), newBatchId);
			p.setBatchId(newBatchId);
			payment = citicUtil.getDividedPayment(param, directDeduct, p, bankSendSn, posID);
			returnState = cciticbSendAndRecService.sendAndRecDividedPayment(p, payment, param, billnoSn);
		}

		ObjectUtil.printPropertyString("", returnState);

		// 更新流水对照表
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);

		Log4jUtil.info("----渠道ID【{}】,渠道业务【{}】处理完成--", channelId, param.getClearingTransType());
		return returnState;
	}

	/**
	 * 批次号
	 * 
	 * @param batchId
	 * @return
	 */
	private String updateBachId(String batchId) {
		/**
		 * 更新批次号
		 */
		String newBatchId = FormatTransfer.setLStrFormat(sequenceManagerService.getCciticbCreditBatchSN(), 6);
		ChannelParm channelParm = new ChannelParm();
		channelParm = (ChannelParm) channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100007"));
		channelParm.setParvalue(newBatchId);
		channelParmService.update(channelParm);
		Log4jUtil.info("----更新批次号【{}】为新批次【{}】----", batchId, newBatchId);
		return newBatchId;
	}

	/**
	 * 维护连接
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState maintainSession(Param param) throws BizException {
		Log4jUtil.info("---进入中信银行信用卡维护连接方法----");
		String logPrefix = "中信银行信用卡维护Session";
		// 取出系统参数
		CiticChannelParm cp = this.getChannelParm();
		// 调用实例化维护连接对象的方法
		MaintainSession maintainSession = new CiticUtil().getMaintainSession(param, cp.getMerchantId(), cp.getToken());
		ObjectUtil.printPropertyString(logPrefix, maintainSession);

		// 调用发送维护连接报文并接受回执的方法
		ReturnState rs = cciticbSendAndRecService.sendAndRecMaintainSession(param, maintainSession);
		ObjectUtil.printPropertyString(logPrefix, rs);

		return rs;
	}

	/**
	 * 
	 * <p>批结算</p>
	 * 
	 * @param yesterday
	 * @return
	 * @author 汤兴友 xytang
	 */
	public ReturnState dealBatSettle(Date yesterday) throws BizException {

		// 查询符合条件的批次
		String tradeDate = DateUtil.getDate(yesterday);
		List<String> batchNoList = billnoSnService.findBatchIDsByTradeDateAndTradeTypeAndStateAndRtncode(channelId,
				tradeDate, ClearingTransType.REAL_TIME_DEDUCT, "02", "0000000");

		if (CollectionUtils.isEmpty(batchNoList)) {
			Log4jUtil.info("--结算日:{} 中没有成功的代扣交易,不需要做批结算!", tradeDate);

			ReturnState rs_ = new ReturnState();
			rs_.setChannelCode(TransReturnCode.code_0000);
			return rs_;
		}

		Log4jUtil.info("--结算日:{} 中存在{}个批次需要做结算!", tradeDate, batchNoList.size());


		ChannelParm settledRecodeParm = (ChannelParm) channelParmService.queryByPrimaryKey(new ChannelParmId(channelId,
				"100028"));
		// 迭代处理
		for (String batchNo : batchNoList) {
			/**
			 * 增加判断是否已经结算过
			 */
			if (settledRecodeParm != null && settledRecodeParm.getParvalue() != null
					&& settledRecodeParm.getParvalue().contains(batchNo)) {
				Log4jUtil.info("--批次:{} 批结算已经处理过,无需再次处理!", batchNo);
				continue;
			}

			try {
				dealBatSettle(batchNo);
			} catch (BizException e) {
				Log4jUtil.info("--批次:{} 批结算处理异常!信息如下:{}", batchNo, e.getMessage());
				Log4jUtil.error(e);
			}
		}

		// 登出
		if (isSign) {
			this.logout();
		}

		ReturnState returnState = new ReturnState();
		returnState.setChannelCode(TransReturnCode.code_0000);
		return returnState;
	}

	/**
	 * 批结算
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState dealBatSettle(String batchId) throws BizException {
		Log4jUtil.info("===========开始批结算，批次号:{} ==========", batchId);

		String logPrefix = "中信银行,请款结算";
		AssertUtils.notNull(batchId, TransReturnCode.code_9108, "结账接口的批次号不能为空！");

		CiticChannelParm cp = this.getChannelParm();
		// 调用根据渠道编号和信用卡批次号查询渠道流水列表的方法
		List<BillnoSn> list = billnoSnService.findByChannelIdAndCreditBatchno(channelId, batchId, "02", "0000000");

		if (list == null || list.isEmpty()) {
			Log4jUtil.info("批次{}成功的交易记录数：【0】条,无需批结算", batchId);
			return null;
		}
		Log4jUtil.info("批次{}成功的交易记录数：【{}】条", batchId, list.size());

		List<BillnoSn> listReversa = new ArrayList<BillnoSn>();
		listReversa.addAll(list);

		/**
		 * 过滤出撤销记录
		 */
		CollectionUtils.filter(listReversa, new FilterPredicateReversal());
		StringBuilder reversalOrderIds = new StringBuilder();
		for (BillnoSn billnoSn : listReversa) {
			reversalOrderIds.append(billnoSn.getBankRecvSn().split("#")[0]).append(",");
		}
		Log4jUtil.info("批次{}中成功撤销的订单号：【{}】", batchId, reversalOrderIds.toString());

		/**
		 * 过滤出实时代扣的记录（不包含已经撤销交易）
		 */
		CollectionUtils.filter(list, new FilterPredicate("1001", reversalOrderIds.toString()));
		Log4jUtil.info("过滤出批次{}中实时代扣(不含已撤销的消费)的记录数：【{}】条", batchId, list.size());

		if (list.size() == 0) {
			Log4jUtil.info("过滤出批次{}中实时代扣(不含已撤销的消费)的记录数：【{0}】条,无需批结算", batchId);
			return null;
		}

		// 签到放到此处
		if (!isSign) {
			// 1.签到
			ReturnState rs = this.login();
			if (!rs.getChannelCode().equals(TransReturnCode.code_0000)) {
				if (!rs.getBankRetCode().equals("6666663"))
					throw new BizException(TransReturnCode.code_9109, "登陆失败，回执信息：" + rs.getBankPostScript());
			}

			isSign = true;
		}

		double totalAmount = 0.0;

		for (int i = 0; i < list.size(); i++) {
			totalAmount = totalAmount + list.get(i).getAmount().doubleValue();
		}

		// 2.调用实例化结账接口报文对象的方法
		CiticUtil citicUtil = new CiticUtil();
		Settlement settlement = citicUtil.getSettlement(cp.getTerminalID(), cp.getMerchantId(), batchId,
				String.valueOf(list.size()), MoneyUtil.getFenString(new BigDecimal(totalAmount)));
		ObjectUtil.printPropertyString(logPrefix, settlement);

		// 3. 调用发送报文并接受回执的方法
		ReturnState rst = cciticbSendAndRecService.sendAndRecSettlement(channelId, settlement);
		ObjectUtil.printPropertyString(logPrefix, rst);

		/**
		 * 回执若为 核对不成功，再发起 对帐接口以核对交易明细的方式进行请款
		 */
		if (!rst.getChannelCode().equals(TransReturnCode.code_0000) && rst.getBankRetCode().equals("0000000")) {
			Log4jUtil.info("----批结算失败，开始以明细方式结算，批次号:{}--", batchId);
			rst = this.checkAccountDeal(list, batchId);
		}

		// 3.2.更新已批结算过的批次记录参数
		ChannelParm settledParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100028"));
		String parValue = settledParm.getParvalue();
		parValue = StringUtils.substring(batchId + "," + parValue, 0, 255);
		settledParm.setParvalue(parValue);
		channelParmService.update(settledParm);
		Log4jUtil.info("----更新已批结算过的批次记录为【{}】--", batchId);

		// 4. 结算成功后，更新批次号
		String batchId_ = cp.getBatchId();
		if (batchId_.equals(batchId)) {
			String newBatchId = this.updateBachId(batchId);
			Log4jUtil.info("----结算更新批次号【{}】为新批次【{}】--", batchId, newBatchId);
		}

		Log4jUtil.info("=========批结算结束，批次号:{}=======", batchId);

		// 5.登出
		// this.logout();

		return rst;
	}

	/**
	 * 
	 * <p>以核对交易明细的方式进行结算</p>
	 * 
	 * @param list
	 * @throws BizException
	 */
	private ReturnState checkAccountDeal(List<BillnoSn> list, String batchId) throws BizException {
		int maxNum = 20;
		int bizListSize = list.size();
		int num = (int) Math.ceil((double) bizListSize / maxNum);

		List<BillnoSn> bizList = null;
		CheckAccount checkAccount = null;
		CiticUtil citicUtil = new CiticUtil();
		ReturnState returnState = new ReturnState();
		CiticChannelParm cp = this.getChannelParm();

		for (int i = 0; i < num; i++) {
			bizList = list.subList(i * maxNum, (i + 1) * maxNum > bizListSize ? bizListSize : (i + 1) * maxNum);

			checkAccount = citicUtil.createCheckAccount(bizList, batchId, cp, i + 1 == num ? "Y" : "N");
			returnState = cciticbSendAndRecService.sendAndRecCheckAccount(channelId, checkAccount);

			CheckAccount ca = (CheckAccount) returnState.getReturnObj();
			ObjectUtil.printPropertyString("明细请款第" + i * maxNum + "开始的20条请款结果", ca);

			for (CheckAccountRecord e : ca.getRecords()) {
				Log4jUtil.info("订单号{}的交易请款后核对结果为：{}-{}", e.getPanOrderId(), e.getCheckFlg(),
						this.getdesc(e.getCheckFlg()));
			}

		}

		// 取最后一条的rs,做为参考
		return returnState;

	}

	/**
	 * 
	 * @param checkFlg
	 * @return
	 */
	private String getdesc(String checkFlg) {
		/**
		 * A-核对成功 B-已核对 C-核对失败 D-交易不存在 E-主机多出交易 M-金额不符 T-POS流水号不符 R-主机不成功商户成功
		 */
		if ("A".equals(checkFlg))
			return "核对成功";
		if ("B".equals(checkFlg))
			return "已核对";
		if ("C".equals(checkFlg))
			return "核对失败";
		if ("D".equals(checkFlg))
			return "交易不存在";
		if ("E".equals(checkFlg))
			return "主机多出交易";
		if ("M".equals(checkFlg))
			return "金额不符";
		if ("T".equals(checkFlg))
			return "POS流水号不符";
		if ("R".equals(checkFlg))
			return "主机不成功商户成功";

		return "未知状态";
	}

	/**
	 * 自适应退款
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState autoAdaptRefund(Param param) throws BizException {

		Log4jUtil.info("---渠道ID【{}】,渠道业务【{}】开始处理--", channelId, param.getClearingTransType());

		// 获取实时退款对象
		AutoRealTimeRefund autoRealTimeRefund = channelTransUtilService.getAutoRealTimeRefund(param);

		ReturnState rs = new ReturnState();

		String bankSendSn = sequenceManagerService.getCciticbCreditSN();

		// 保存到渠道流水表中
		billnoSnService.saveBillnoSn(bankSendSn, param);

		// 通过param来判断是走撤销或是走交易退款
		BillnoSn billnoSn = (BillnoSn) billnoSnService.findBillnoSn(autoRealTimeRefund.getOrgTransChannelId(),
				autoRealTimeRefund.getOrgPaySn());
		AssertUtils
				.notNull(billnoSn, TransReturnCode.code_9108, "渠道流水对照表中没有找到原流水号:" + autoRealTimeRefund.getOrgPaySn());
		String batchNo = billnoSn.getCreditbatchno(); // 银行端批次号
		ChannelParm batchNoParm = (ChannelParm) channelParmService.queryByPrimaryKey(new ChannelParmId(param
				.getChannelId(), "100007"));
		AssertUtils.notNull(batchNo, TransReturnCode.code_9108, "批次号不能为空");
		AssertUtils.notNull(batchNoParm, TransReturnCode.code_9108, "批次号不能为空");

		CiticChannelParm p = this.getChannelParm();

		CiticUtil citicUtil = new CiticUtil();

		if (batchNoParm.getParvalue().equals(batchNo)
				&& autoRealTimeRefund.getOrgAmounFen().equals(autoRealTimeRefund.getRefundAmounFen())
				&& DecimalUtil.eq(autoRealTimeRefund.getRefundAmount(), billnoSn.getAmount())) {

			// 撤销
			DividedPaymentReversal dividedPaymentReversal = citicUtil.getDividedPaymentReversal2(autoRealTimeRefund,
					billnoSn, p);

			rs = cciticbSendAndRecService.sendAndRecDividedPaymentReversal2(param, dividedPaymentReversal);
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_CANCLE);
			// 如果出现"未登陆"的情况，将做重签到交易,然后再重做交易
			if (rs.getBankRetCode().equals("6666661")) {
				// 1.重签到交易
				this.login();
				rs = cciticbSendAndRecService.sendAndRecDividedPaymentReversal2(param, dividedPaymentReversal);
			}
			// 如果出现"该批次号已被退货交易占用"情况，将做更新批次号,然后再重做交易
			if ("MBCH011".equalsIgnoreCase(rs.getBankRetCode())) {
				String newBatchId = this.updateBachId(p.getBatchId());
				p.setBatchId(newBatchId);

				Log4jUtil.info("----重发撤销交易--");
				dividedPaymentReversal = citicUtil.getDividedPaymentReversal2(autoRealTimeRefund, billnoSn, p);
				rs = cciticbSendAndRecService.sendAndRecDividedPaymentReversal2(param, dividedPaymentReversal);
			}

		} else {
			// 退款
			HirePurchaseReturn hirePurchaseReturn = citicUtil.getHirePurchaseReturn2(autoRealTimeRefund, billnoSn, p);
			rs = cciticbSendAndRecService.sendAndRecHirePurchaseReturn2(param, hirePurchaseReturn, billnoSn);
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_REFUND);
			// 如果出现"未登陆"的情况，将做重签到交易,然后再重做交易
			if (rs.getBankRetCode().equals("6666661")) {
				// 1.重签到交易
				this.login();
				rs = cciticbSendAndRecService.sendAndRecHirePurchaseReturn2(param, hirePurchaseReturn, billnoSn);
			}
			// 如果出现"该批次号已被退货交易占用"情况，将做更新批次号,然后再重做交易
			if ("MBCH011".equalsIgnoreCase(rs.getBankRetCode())) {
				String newBatchId = this.updateBachId(p.getBatchId());
				p.setBatchId(newBatchId);

				Log4jUtil.info("----重发退款交易--");
				hirePurchaseReturn = citicUtil.getHirePurchaseReturn2(autoRealTimeRefund, billnoSn, p);
				rs = cciticbSendAndRecService.sendAndRecHirePurchaseReturn2(param, hirePurchaseReturn, billnoSn);
			}
		}

		// 更新流水对照表
		billnoSnService.updateBillnoSn(param, rs, bankSendSn);

		return rs;
	}

	/**
	 * 
	 * <P>过滤出实时代扣的记录（不包含已经撤销交易）</P>
	 * 
	 * @author 汤兴友 xytang
	 */
	class FilterPredicate implements Predicate {
		private String attribute;
		private String attribute2;

		public FilterPredicate(String filterAttribute, String filterAttribute2) {
			this.attribute = filterAttribute;
			this.attribute2 = filterAttribute2;
		}

		public boolean evaluate(Object arg0) {
			if (arg0 instanceof BillnoSn) {
				return attribute.equals(((BillnoSn) arg0).getTranType())
						&& !attribute2.contains(((BillnoSn) arg0).getBankSendSn());
			}
			return false;
		}
	}

	/**
	 * 
	 * <P>过滤出撤销记录</P>
	 * 
	 * @author 汤兴友 xytang
	 */
	class FilterPredicateReversal implements Predicate {
		public boolean evaluate(Object arg0) {
			if (arg0 instanceof BillnoSn) {
				return ((BillnoSn) arg0).getBankRecvSn().endsWith("#0#S")
						&& "8025".equals(((BillnoSn) arg0).getTranType());
			}
			return false;
		}
	}
}
