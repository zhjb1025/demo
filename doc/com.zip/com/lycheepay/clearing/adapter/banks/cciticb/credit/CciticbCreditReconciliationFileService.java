/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-7-17 下午2:24:53
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.cciticb.credit;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Download;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.processor.CciticbCreditDirectProcess;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.processor.CciticbSendAndRecService;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util.CiticUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.SysparmConst;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ClearParamsService;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.StringUtil;


/**
 * <P>中信信用卡对账文件服务类</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.CCITICB_CREDIT_RECONCILIATION_FILE_SERVICE)
public class CciticbCreditReconciliationFileService implements ReconciliationFileServiceInner {

	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";

	private static String line = System.getProperty("line.separator"); // 回车换行符
	private static String channelId = ChannelIdEnum.ECITIC_CREDIT_CARD.getCode();

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCITICB_CREDIT_DIRECT_PROCESS)
	private CciticbCreditDirectProcess  cciticbCreditDirectProcess;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCITICB_SENDANDREC_SERVICE)
	private CciticbSendAndRecService cciticbSendAndRecService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CLEAR_PARAMS_SERVICE)
	private ClearParamsService sysParmService;

	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(settleDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {

		Log4jUtil.setLogClass("ECITIC", "check");

		final String logPrefix = "中信信用卡";

		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);

		Log4jUtil.info("-----------构建交易数据对象列表-------");
		final List<ReconciliationFileDTO> reconciliationFileDTOList = this.buildTransactionDataList(settleDate);

		Log4jUtil.info(logPrefix + "生成统一格式对账文件");

		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				settleDate, reconciliationFileDTOList);

		return fileFullPath;
	}

	/**
	 * 构建交易数据对象列表
	 * 
	 * @param cparam
	 * @return
	 * @throws ClearingAdapterBizCheckedException
	 */
	private ArrayList<ReconciliationFileDTO> buildTransactionDataList(final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.info("--------------------------开始进入中信银行信用卡下载流水文件接口交易----------------------");
		ArrayList<ReconciliationFileDTO> accBeanList = new ArrayList<ReconciliationFileDTO>();

		// 获取渠道参数
		final ChannelParm terminalIDParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		final ChannelParm merchantIDParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100003"));

		Assert.notNull(terminalIDParm, "terminalID不能为空");
		Assert.notNull(merchantIDParm, "merchantID不能为空");

		String terminalID = terminalIDParm.getParvalue();
		String merchantID = merchantIDParm.getParvalue();

		// 先做登录
		cciticbCreditDirectProcess.login();

		// 调用实例化流水文件下载对象的方法
		Download download = new CiticUtil().getDownload(terminalID, merchantID, settleDate);

		// 调用发送流水文件下载接口报文并接受回执的方法
		Download dl = cciticbSendAndRecService.sendAndrecDownload(download, channelId);

		if (dl.getList_data().size() == 0) {
			// throw new BizException(TransReturnCode.code_9900, "对账流水文件为空，无需对账");
			return new ArrayList<ReconciliationFileDTO>();
		}

		/**
		 * 将对账流水文件保存在系统中
		 */
		this.createAccFile(settleDate, dl.getList_data());

		List<String> tempList = new ArrayList<String>();
		for (int i = 4; i < dl.getList_data().size(); i++) {
			String record = dl.getList_data().get(i);

			/**
			 * 检查Merchant是否正确
			 */
			String[] em = record.trim().split(" +");
			if ("Merchant:".equalsIgnoreCase(em[0])) {
				if (!merchantID.equals(em[1])) {
					throw new BizException(TransReturnCode.code_9109, StringUtil.r(
							"流水文件中Merchant:{?}与系统中的Merchant:{?}不一致", em[1], merchantID));
				}
			}

			/**
			 * 过滤部分数据，如“----”行，“====”行，“Merchant”行，“CardNbr/OrderNbr”行，“Batch”行，
			 */
			if (em[0].contains("----") || em[0].contains("====") || em[0].contains("Merchant")
					|| em[0].contains("CardNbr") || em[0].contains("Batch")) {
				continue;
			}

			/**
			 * 过滤后的应该都是交易的明细
			 */
			Log4jUtil.info("第{}行的内容为：{}", i + 1, record.trim());
			tempList.add(record.trim());
		}

		/**
		 * 组装AccBean实例
		 */
		String e_1 = "";
		String e_2 = "";
		ReconciliationFileDTO accBean = null;
		String[] tempE_1 = null;
		String[] tempE_2 = null;

		String cardNbr = "";
		String orderNbr = "";
		String trxType = "";
		String tranDate = "";
		String traceNbr = "";
		String transAmt = "";
		String rspCde = "";
		String stlFlg = "";

		for (int i = 0; i < tempList.size() / 2; i++) {
			e_1 = tempList.get(2 * i);// 第一行
			e_2 = tempList.get(2 * i + 1);// 第二行

			/**
			 * 明细的数据合法的检查
			 */
			tempE_1 = e_1.split(" +");
			if (tempE_1.length != 13) {
				throw new BizException(TransReturnCode.code_9109, StringUtil.r("明细的{?}的参数列应该为13个", tempE_1));
			}

			tempE_2 = e_2.split(" +");
			if (tempE_2.length != 1) {
				throw new BizException(TransReturnCode.code_9109, StringUtil.r("明细的{?}的参数列[OrderNbr]应该只用1个", tempE_2));
			}

			/**
			 * CardNbr/OrderNbr TrxType TranDate TranTime AuthNbr TraceNbr RefNbr TransAmt Curr
			 * PdtCde DvdMth RspCde StlFlg
			 * ----------------------------------------------------------
			 * ------------------------------------------------------------------------
			 * 40339200****3532 PER 20100304 14561709 380679 005449 041507311505 .01 156 000000 00
			 * 00 A 20100304145717
			 */

			cardNbr = tempE_1[0];
			orderNbr = tempE_2[0];
			trxType = tempE_1[1];
			tranDate = tempE_1[2];
			traceNbr = tempE_1[5];
			transAmt = tempE_1[7];
			rspCde = tempE_1[11];
			stlFlg = tempE_1[12];

			BillnoSn billnoSn = null;
			String errMsg = "";

			/**
			 * 处理退款记录
			 */
			if ("RFD".equalsIgnoreCase(trxType)) {
				if (stlFlg.equalsIgnoreCase("A")) {
					// 退款记录
					billnoSn = billnoSnService.getBillnoSnByBankRecvSn(channelId,
							orderNbr.trim() + "#1#" + traceNbr.trim()); // #1# 为退款 ； #0# 为撤销；
					if (billnoSn == null || !"1".equals(billnoSn.getPayState())) {
						Log4jUtil.info("没有查找到订单号为【{}】,流水号为【{}】,BankRecvSn【{}】的【退款成功】的记录,请人工核实！", orderNbr.trim(), traceNbr.trim(),orderNbr.trim() + "#1#" + traceNbr.trim());
						continue;
					}

					accBean = new ReconciliationFileDTO();
					accBean.setChannelId(channelId);
					accBean.setPayGet(STR_PAY);
					accBean.setCheckDate(DateUtil.getCurrentDate());
					accBean.setBankSendId(billnoSn.getBankSendSn());
					accBean.setTransDate(tranDate);
					accBean.setAmount(new BigDecimal(transAmt.trim().replace("-", "")));
					accBean.setBankTransState("00");
				} else {
					continue;
				}
			}
			
			/**
			 * 处理消费和撤销记录
			 */

			if ("PER".equalsIgnoreCase(trxType)) {
				if (stlFlg.equalsIgnoreCase("A")) {
					accBean = new ReconciliationFileDTO();
					accBean.setChannelId(channelId);
					accBean.setPayGet(STR_GET);
					accBean.setCheckDate(DateUtil.getCurrentDate());
					accBean.setBankSendId(orderNbr);
					accBean.setTransDate(tranDate);
					accBean.setAmount(new BigDecimal(transAmt));
					accBean.setBankTransState("00");
				} else if (stlFlg.equalsIgnoreCase("R")) {
					/**
					 * 对账文件 R 的需要拆分出原交易和撤销交易
					 */

					/**
					 * 查询符合条件的消费撤销记录
					 */
					billnoSn = billnoSnService.getBillnoSnByBankRecvSn(channelId,
							orderNbr.trim() + "#0#S"); // #0为撤销；
					if (billnoSn == null || !"1".equals(billnoSn.getPayState())) {
						Log4jUtil.info("没有查找到订单号为【{}】,BankRecvSn【{}】的成功状态【撤销记录】,请人工核实,此处暂时跳过！", orderNbr.trim(),orderNbr.trim() + "#0#S");
						continue;
					}
					// 生成一条成功消费撤销的对账记录
					accBean = new ReconciliationFileDTO();
					accBean.setChannelId(channelId);
					accBean.setPayGet(STR_PAY);
					accBean.setCheckDate(DateUtil.getCurrentDate());
					accBean.setBankSendId(billnoSn.getBankSendSn());
					accBean.setTransDate(tranDate);
					accBean.setAmount(new BigDecimal(transAmt));
					accBean.setBankTransState("00");
					Log4jUtil.info("拆分出撤销记录:bankSendSn[" + accBean.getBankSendId() + "]tradeAmount["
							+ accBean.getAmount() + "]TranDate[" + accBean.getTransDate() + "]CheckDate["
							+ accBean.getCheckDate() + "]BankTradestate[" + accBean.getBankTransState() + "]");
					accBeanList.add(accBean);


					/**
					 * 查询符合条件的消费记录
					 */
					billnoSn = billnoSnService.getBillnoSn(channelId, orderNbr);
					if (billnoSn == null || !"1".equals(billnoSn.getPayState())) {
						errMsg = StringUtil.r("没有查找到订单号为【{?}】的成功状态【消费记录】,但找到了相关联成功的撤销交易,请人工核实", orderNbr.trim());
						Log4jUtil.info(errMsg);
						throw new BizException(TransReturnCode.code_9109, errMsg);
					}
					// 生成一条成功消费的对账记录
					accBean = new ReconciliationFileDTO();
					accBean.setChannelId(channelId);
					accBean.setPayGet(STR_GET);
					accBean.setCheckDate(DateUtil.getCurrentDate());
					accBean.setBankSendId(orderNbr);
					accBean.setTransDate(tranDate);
					accBean.setAmount(new BigDecimal(transAmt));
					accBean.setBankTransState("00");

				} else {
					continue;
				}

			}

			Log4jUtil.info("AccBean信息为:bankSendSn[" + accBean.getBankSendId() + "]tradeAmount[" + accBean.getAmount()
					+ "]TranDate[" + accBean.getTransDate() + "]CheckDate[" + accBean.getCheckDate()
					+ "]BankTradestate[" + accBean.getBankTransState() + "]");

			accBeanList.add(accBean);

		}

		return accBeanList;
	}

	/**
	 * 
	 * <p>保存对账流水信息到文件中</p>
	 * 
	 * @param listData
	 * @author 汤兴友 13692259317
	 * @throws BizException
	 */
	private String createAccFile(String checkDate, List<String> listData) throws BizException {
		String AccFileStr = ""; // 文件内容
		StringBuffer sourceMsg = new StringBuffer("");
		String str = "";
		for (Iterator<String> iterator = listData.iterator(); iterator.hasNext();) {
			str = (String) iterator.next();
			sourceMsg.append(str);
			sourceMsg.append(line); // 回车换行
		}

		AccFileStr = sourceMsg.toString();
		String accPath = sysParmService.getParmValue(SysparmConst.CHANNEL_RECON_FILE_DIR) + "accPath" + channelId;
		FileProcess.createDir(accPath); // 如果文件夹不存在，创建文件夹
		String accFile = accPath + File.separator + checkDate + ".txt"; // 含相对路径的文件名

		PrintWriter pw = null;
		try {
			pw = new PrintWriter(accFile);
		} catch (FileNotFoundException e) {
			Log4jUtil.error(e);
			throw new BizException("生成文件出错！！" + e.getMessage());
		}

		pw.write(AccFileStr);
		pw.flush();
		pw.close();
		Log4jUtil.info(line + "渠道ID:" + channelId + "；对账日期：" + checkDate + " 对账流水，对账文件名为【" + accFile + "】");
		return accFile;
	}

	public static void main(String[] args) {
		String r1 = " 40339200****8627    PER     20121225 10330133 331007  103047   251033014607                   .02  156 000000   00     00    A";
		String r2 = " 0000000000000100066                                                                                                             ";

		String[] tempE_1 = null;
		String[] tempE_2 = null;

		tempE_1 = r1.trim().split(" +");
		if (tempE_1.length != 13) {
			System.out.println(StringUtil.r("明细的{?}的参数列应该为13个", tempE_1));
		}

		tempE_2 = r2.trim().split(" +");
		if (tempE_2.length != 1) {
			System.out.println(StringUtil.r("明细的{?}的参数列[OrderNbr]应该只用1个", tempE_2));
		}

		String cardNbr = tempE_1[0];
		String orderNbr = tempE_2[0];
		String trxType = tempE_1[1];
		String tranDate = tempE_1[2];
		String traceNbr = tempE_1[5];
		String transAmt = tempE_1[7];
		String rspCde = tempE_1[11];
		String stlFlg = tempE_1[12];

		/**
		 * 过滤退款等记录
		 */
		if (!"PER".equalsIgnoreCase(trxType)) {
			System.out.println("!!!!!!!!!!!!!PER");
		}

		ReconciliationFileDTO accBean = null;
		if (stlFlg.equalsIgnoreCase("A")) {
			accBean = new ReconciliationFileDTO();
			accBean.setChannelId(channelId);
			accBean.setPayGet(STR_GET);
			accBean.setCheckDate(DateUtil.getCurrentDate());
			accBean.setBankSendId(orderNbr);
			accBean.setTransDate(tranDate);
			accBean.setAmount(new BigDecimal(transAmt));
			accBean.setBankTransState("00");
		} else {
			System.out.println("!!!!!!!!!!!!!!A");
		}

		System.out.println("ChannelId:" + accBean.getChannelId());
		System.out.println("AccBean信息为:bankSendSn[" + accBean.getBankSendId() + "]tradeAmount[" + accBean.getAmount()
				+ "]TranDate[" + accBean.getTransDate() + "]CheckDate[" + accBean.getCheckDate() + "]BankTradestate["
				+ accBean.getBankTransState() + "]");

	}

}
