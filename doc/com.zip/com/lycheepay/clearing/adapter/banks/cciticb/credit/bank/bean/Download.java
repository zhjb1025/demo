package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

import java.util.List;


/**
 * 
 * @author 汤兴友 xytang
 */
public class Download {
	private String infoType; // 信息类型
	private String posTime;	// POS交易时间
	private String posID; // POS本地流水号
	private String retCode;	// 返回码
	private String terminalID;	// 终端号
	private String merchantID;	// 商户号
	private String fileType; // 文件类型
	private String dataSet;	// 数据结果集
	private String date; // 获取某一天的流水文件
	private String commentRes;	// 附加响应
	private String reserved; // 保留域
	private List<String> list_data; // 数据结果列表（用于解析流水明细）
	
	/**
	 * 获取信息类型的方法
	 * 
	 * @return
	 */
	public String getInfoType() {
		return infoType;
	}
	
	/**
	 * 设置信息类型的方法
	 * 
	 * @return
	 */
	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}
	
	/**
	 * 获取POS交易时间的方法
	 * 
	 * @return
	 */
	public String getPosTime() {
		return posTime;
	}
	
	/**
	 * 设置POS交易时间的方法
	 * 
	 * @param posTime
	 */
	public void setPosTime(String posTime) {
		this.posTime = posTime;
	}
	
	/**
	 * 获取POS本地流水号的方法
	 * 
	 * @return
	 */
	public String getPosID() {
		return posID;
	}
	
	/**
	 * 设置POS本地流水号的方法
	 * 
	 * @param posID
	 */
	public void setPosID(String posID) {
		this.posID = posID;
	}
	
	/**
	 * 获取返回码的方法
	 * 
	 * @return
	 */
	public String getRetCode() {
		return retCode;
	}
	
	/**
	 * 设置返回码的方法
	 * 
	 * @param retCode
	 */
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	
	/**
	 * 获取终端号的方法
	 * 
	 * @return
	 */
	public String getTerminalID() {
		return terminalID;
	}
	
	/**
	 * 设置终端号的方法
	 * 
	 * @param terminalID
	 */
	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}
	
	/**
	 * 获取商户号的方法
	 * 
	 * @return
	 */
	public String getMerchantID() {
		return merchantID;
	}
	
	/**
	 * 设置商户号的方法
	 * 
	 * @param merchantID
	 */
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}
	
	/**
	 * 获取文件类型的方法
	 * 
	 * @return
	 */
	public String getFileType() {
		return fileType;
	}
	
	/**
	 * 设置文件类型的方法
	 * 
	 * @param fileType
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
	/**
	 * 获取数据结果集的方法
	 * 
	 * @return
	 */
	public String getDataSet() {
		return dataSet;
	}
	
	/**
	 * 设置数据结果集的方法
	 * 
	 * @param dataSet
	 */
	public void setDataSet(String dataSet) {
		this.dataSet = dataSet;
	}
	
	/**
	 * 获取某一天的流水文件时间的方法
	 * 
	 * @return
	 */
	public String getDate() {
		return date;
	}
	
	/**
	 * 设置获取某一天的流水文件时间的方法
	 * 
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}
	
	/**
	 * 获取附加响应的方法
	 * 
	 * @return
	 */
	public String getCommentRes() {
		return commentRes;
	}
	
	/**
	 * 设置附加响应的方法
	 * 
	 * @param commentRes
	 */
	public void setCommentRes(String commentRes) {
		this.commentRes = commentRes;
	}
	
	/**
	 * 获取保留域的方法
	 * 
	 * @return
	 */
	public String getReserved() {
		return reserved;
	}
	
	/**
	 * 设置保留域的方法
	 * 
	 * @param reserved
	 */
	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	/**
	 * 获取数据结果列表（用于解析流水明细）的方法
	 * 
	 * @return
	 */
	public List<String> getList_data() {
		return list_data;
	}

	/**
	 * 设置数据结果列表（用于解析流水明细）的方法
	 * 
	 * @param list_data
	 */
	public void setList_data(List<String> list_data) {
		this.list_data = list_data;
	}
}
