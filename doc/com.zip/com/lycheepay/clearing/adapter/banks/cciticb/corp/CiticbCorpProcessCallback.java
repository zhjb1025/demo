package com.lycheepay.clearing.adapter.banks.cciticb.corp;

import java.util.Map;

import com.lycheepay.clearing.common.constant.ClearingTransType.ClearingTransTypeEnum;

public interface CiticbCorpProcessCallback<K> {
		ClearingTransTypeEnum getTransType();

		Map<String, String> buildMessage(K k);
	}