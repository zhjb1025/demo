package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

/**
 * 
 * @author 汤兴友 xytang
 */
public class HirePurchaseReturn extends DividedPaymentReversal {
	private String orgTransAmt;	// 原交易金额
	
	private String orgBatchNo;	// 原交易记录的批次号
	
	/**
	 * 获取原交易金额的方法
	 * 
	 * @return
	 */
	public String getOrgTransAmt() {
		return orgTransAmt;
	}
	
	/**
	 * 设置原交易金额的方法
	 * 
	 * @param orgTransAmt
	 */
	public void setOrgTransAmt(String orgTransAmt) {
		this.orgTransAmt = orgTransAmt;
	}
	
	/**
	 * 获取原批次号的方法
	 * 
	 * @return
	 */
	public String getOrgBatchNo() {
		return orgBatchNo;
	}
	
	/**
	 * 设置原批次号的方法
	 * 
	 * @param orgBatchNo
	 */
	public void setOrgBatchNo(String orgBatchNo) {
		this.orgBatchNo = orgBatchNo;
	}
}
