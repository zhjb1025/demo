package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

/**
 * 
 * @author 汤兴友 xytang
 */
public class DividedPaymentReversal extends DividedPayment {
	
	private String orgPosID; // 原POS流水号
	
	/**
	 * 设置原POS流水号
	 * 
	 * @param orgPosID
	 */
	public void setOrgPosID(String orgPosID) {
		this.orgPosID = orgPosID;
	}
	
	/**
	 * 获取远POS流水号
	 * 
	 * @return
	 */
	public String getOrgPosID() {
		return orgPosID;
	}
	
}
