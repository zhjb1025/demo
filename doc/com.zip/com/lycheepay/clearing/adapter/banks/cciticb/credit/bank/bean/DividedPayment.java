package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

/**
 * 
 * <P>支付实体类</P>
 * 
 * @author 汤兴友 xytang
 */
public class DividedPayment {
	private String infoType; // 信息类型
	private String pan; // 主帐号(卡号)
	private String processCode;	// 处理代码
	private String transAmt; // 交易金额
	private String posTime;	// POS交易时间
	private String posID; // POS流水号
	private String orderID; // 订单编号
	private String transTime; // 交易时间
	private String transDate; // 交易日期
	private String inputType; // POS输入方式
	private String cardSerialNo; // 卡片序列号
	private String posConditionCode; // 服务点条件码
	private String secondTrack;	// 二磁道内容
	private String thirdTrack; // 三磁道内容
	private String systemRefCode; // 系统参考号
	private String authorizeCode; // 授权码
	private String retCode; // 返回码
	private String terminalID; // 终端号
	private String merchantID; // 商户号
	private String merchantName; // 商户名称
	private String commentRes; // 附加响应
	private String currCode; // 货币代码
	private String passwdMac; // 个人密码密文
	private String securityInfo; // 安全控制信息
	private String icDataField; // IC卡数据域
	private String termAbilities; // 自定义域
	private String chIdNum; // 持卡人证件号码
	private String chName; // 持卡人姓名
	private String chMobile; // 持卡人手机号码
	private String cvv2; // 卡背面末三位数字
	private String expiredDate; // 卡有效期
	private String dynamicPwd; // 动态密码
	private String personalMsg; // 个人化信息
	private String batchNo;	// 批次号
	private String dividedNum; // 分期期数
	private String productType;	// 产品类型
	private String dividedFee; // 分期手续费
	private String totalAmt; // 授权总金额
	private String dividedAmt; // 分期金额
	private String reserved1; // 保留域1
	private String reserved2; // 保留域2
	
	/**
	 * 获取信息类型的方法
	 * 
	 * @return
	 */
	public String getInfoType() {
		return infoType;
	}
	
	/**
	 * 设置信息类型的方法
	 * 
	 * @return
	 */
	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}
	
	/**
	 * 获取主帐号(卡号)的方法
	 * 
	 * @return
	 */
	public String getPan() {
		return pan;
	}
	
	/**
	 * 设置主帐号(卡号)的方法
	 * 
	 * @param pan
	 */
	public void setPan(String pan) {
		this.pan = pan;
	}
	
	/**
	 * 获取处理代码方法
	 * 
	 * @return
	 */
	public String getProcessCode() {
		return processCode;
	}
	
	/**
	 * 设置处理代码的方法
	 * 
	 * @param processCode
	 */
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	
	/**
	 * 获取交易金额方法
	 * 
	 * @return
	 */
	public String getTransAmt() {
		return transAmt;
	}
	
	/**
	 * 设置交易金额的方法
	 * 
	 * @param transAmt
	 */
	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}
	
	/**
	 * 获取POS交易时间的方法
	 * 
	 * @return
	 */
	public String getPosTime() {
		return posTime;
	}
	
	/**
	 * 设置POS交易时间的方法
	 * 
	 * @param posTime
	 */
	public void setPosTime(String posTime) {
		this.posTime = posTime;
	}
	
	/**
	 * 获取POS流水号的方法
	 * 
	 * @return
	 */
	public String getPosID() {
		return posID;
	}
	
	/**
	 * 设置POS流水号的方法
	 * 
	 * @param posID
	 */
	public void setPosID(String posID) {
		this.posID = posID;
	}
	
	/**
	 * 获取订单编号的方法
	 * 
	 * @return
	 */
	public String getOrderID() {
		return orderID;
	}
	
	/**
	 * 设置订单编号的方法
	 * 
	 * @param orderID
	 */
	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}
	
	/**
	 * 获取交易时间的方法
	 * 
	 * @return
	 */
	public String getTransTime() {
		return transTime;
	}
	
	/**
	 * 设置交易时间的方法
	 * 
	 * @param transTime
	 */
	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}
	
	/**
	 * 获取交易日期的方法
	 * 
	 * @return
	 */
	public String getTransDate() {
		return transDate;
	}
	
	/**
	 * 设置交易日期的方法
	 * 
	 * @param transDate
	 */
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	
	/**
	 * 获取POS输入方式的方法
	 * 
	 * @return
	 */
	public String getInputType() {
		return inputType;
	}
	
	/**
	 * 设置POS输入方式的方法
	 * 
	 * @param inputType
	 */
	public void setInputType(String inputType) {
		this.inputType = inputType;
	}
	
	/**
	 * 获取卡片序列号的方法
	 * 
	 * @return
	 */
	public String getCardSerialNo() {
		return cardSerialNo;
	}
	
	/**
	 * 设置卡片序列号的方法
	 * 
	 * @param cardSerialNo
	 */
	public void setCardSerialNo(String cardSerialNo) {
		this.cardSerialNo = cardSerialNo;
	}
	
	/**
	 * 获取服务点条件码的方法
	 * 
	 * @return
	 */
	public String getPosConditionCode() {
		return posConditionCode;
	}
	
	/**
	 * 设置服务点条件码的方法
	 * 
	 * @param posConditionCode
	 */
	public void setPosConditionCode(String posConditionCode) {
		this.posConditionCode = posConditionCode;
	}
	
	/**
	 * 获取二磁道内容的方法
	 * 
	 * @return
	 */
	public String getSecondTrack() {
		return secondTrack;
	}
	
	/**
	 * 设置二磁道内容的方法
	 * 
	 * @param secondTrack
	 */
	public void setSecondTrack(String secondTrack) {
		this.secondTrack = secondTrack;
	}
	
	/**
	 * 获取三磁道内容的方法
	 * 
	 * @return
	 */
	public String getThirdTrack() {
		return thirdTrack;
	}
	
	/**
	 * 设置三磁道内容的方法
	 * 
	 * @param thirdTrack
	 */
	public void setThirdTrack(String thirdTrack) {
		this.thirdTrack = thirdTrack;
	}
	
	/**
	 * 获取系统参考号的方法
	 * 
	 * @return
	 */
	public String getSystemRefCode() {
		return systemRefCode;
	}
	
	/**
	 * 设置系统参考号的方法
	 * 
	 * @param systemRefCode
	 */
	public void setSystemRefCode(String systemRefCode) {
		this.systemRefCode = systemRefCode;
	}
	
	/**
	 * 获取授权码的方法
	 * 
	 * @return
	 */
	public String getAuthorizeCode() {
		return authorizeCode;
	}
	
	/**
	 * 设置授权码的方法
	 * 
	 * @param authorizeCode
	 */
	public void setAuthorizeCode(String authorizeCode) {
		this.authorizeCode = authorizeCode;
	}
	
	/**
	 * 获取返回码的方法
	 * 
	 * @return
	 */
	public String getRetCode() {
		return retCode;
	}
	
	/**
	 * 设置返回码的方法
	 * 
	 * @param retCode
	 */
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	
	/**
	 * 获取终端号的方法
	 * 
	 * @return
	 */
	public String getTerminalID() {
		return terminalID;
	}
	
	/**
	 * 设置终端号的方法
	 * 
	 * @param terminalID
	 */
	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}
	
	/**
	 * 获取商户号的方法
	 * 
	 * @return
	 */
	public String getMerchantID() {
		return merchantID;
	}
	
	/**
	 * 设置商户号的方法
	 * 
	 * @param merchantID
	 */
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}
	
	/**
	 * 获取商户名称的方法
	 * 
	 * @return
	 */
	public String getMerchantName() {
		return merchantName;
	}
	
	/**
	 * 设置商户名称的方法
	 * 
	 * @param merchantName
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	
	/**
	 * 获取附加响应的方法
	 * 
	 * @return
	 */
	public String getCommentRes() {
		return commentRes;
	}
	
	/**
	 * 设置附加响应的方法
	 * 
	 * @param commentRes
	 */
	public void setCommentRes(String commentRes) {
		this.commentRes = commentRes;
	}
	
	/**
	 * 获取货币代码的方法
	 * 
	 * @return
	 */
	public String getCurrCode() {
		return currCode;
	}
	
	/**
	 * 设置货币代码的方法
	 * 
	 * @param currCode
	 */
	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}
	
	/**
	 * 获取个人密码密文的方法
	 * 
	 * @return
	 */
	public String getPasswdMac() {
		return passwdMac;
	}
	
	/**
	 * 设置个人密码密文的方法
	 * 
	 * @param passwdMac
	 */
	public void setPasswdMac(String passwdMac) {
		this.passwdMac = passwdMac;
	}
	
	/**
	 * 获取安全控制信息的方法
	 * 
	 * @return
	 */
	public String getSecurityInfo() {
		return securityInfo;
	}
	
	/**
	 * 设置安全控制信息的方法
	 * 
	 * @param securityInfo
	 */
	public void setSecurityInfo(String securityInfo) {
		this.securityInfo = securityInfo;
	}
	
	/**
	 * 获取IC卡数据域的方法
	 * 
	 * @return
	 */
	public String getIcDataField() {
		return icDataField;
	}
	
	/**
	 * 设置IC卡数据域的方法
	 * 
	 * @param icDataField
	 */
	public void setIcDataField(String icDataField) {
		this.icDataField = icDataField;
	}
	
	/**
	 * 获取自定义域的方法
	 * 
	 * @return
	 */
	public String getTermAbilities() {
		return termAbilities;
	}
	
	/**
	 * 设置自定义域的方法
	 * 
	 * @param termAbilities
	 */
	public void setTermAbilities(String termAbilities) {
		this.termAbilities = termAbilities;
	}
	
	/**
	 * 获取持卡人证件号码的方法
	 * 
	 * @return
	 */
	public String getChIdNum() {
		return chIdNum;
	}
	
	/**
	 * 设置持卡人证件号码的方法
	 * 
	 * @param chIdNum
	 */
	public void setChIdNum(String chIdNum) {
		this.chIdNum = chIdNum;
	}
	
	/**
	 * 获取持卡人姓名的方法
	 * 
	 * @return
	 */
	public String getChName() {
		return chName;
	}
	
	/**
	 * 设置持卡人姓名的方法
	 * 
	 * @param chName
	 */
	public void setChName(String chName) {
		this.chName = chName;
	}
	
	/**
	 * 获取持卡人手机号码的方法
	 * 
	 * @return
	 */
	public String getChMobile() {
		return chMobile;
	}
	
	/**
	 * 设置持卡人手机号码的方法
	 * 
	 * @param chMobile
	 */
	public void setChMobile(String chMobile) {
		this.chMobile = chMobile;
	}
	
	/**
	 * 获取卡背面末三位数字的方法
	 * 
	 * @return
	 */
	public String getCvv2() {
		return cvv2;
	}
	
	/**
	 * 设置卡背面末三位数字的方法
	 * 
	 * @param cvv2
	 */
	public void setCvv2(String cvv2) {
		this.cvv2 = cvv2;
	}
	
	/**
	 * 获取卡有效期的方法
	 * 
	 * @return
	 */
	public String getExpiredDate() {
		return expiredDate;
	}
	
	/**
	 * 设置卡有效期的方法
	 * 
	 * @param expiredDate
	 */
	public void setExpiredDate(String expiredDate) {
		this.expiredDate = expiredDate;
	}
	
	/**
	 * 获取动态密码的方法
	 * 
	 * @return
	 */
	public String getDynamicPwd() {
		return dynamicPwd;
	}
	
	/**
	 * 设置动态密码的方法
	 * 
	 * @param dynamicPwd
	 */
	public void setDynamicPwd(String dynamicPwd) {
		this.dynamicPwd = dynamicPwd;
	}
	
	/**
	 * 获取个人化信息的方法
	 * 
	 * @return
	 */
	public String getPersonalMsg() {
		return personalMsg;
	}
	
	/**
	 * 设置个人化信息的方法
	 * 
	 * @param personalMsg
	 */
	public void setPersonalMsg(String personalMsg) {
		this.personalMsg = personalMsg;
	}
	
	/**
	 * 获取批次号的方法
	 * 
	 * @return
	 */
	public String getBatchNo() {
		return batchNo;
	}
	
	/**
	 * 设置批次号的方法
	 * 
	 * @param batchNo
	 */
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	
	/**
	 * 获取分期期数的方法
	 * 
	 * @return
	 */
	public String getDividedNum() {
		return dividedNum;
	}
	
	/**
	 * 设置分期期数的方法
	 * 
	 * @param dividedNum
	 */
	public void setDividedNum(String dividedNum) {
		this.dividedNum = dividedNum;
	}
	
	/**
	 * 获取产品类型的方法
	 * 
	 * @return
	 */
	public String getProductType() {
		return productType;
	}
	
	/**
	 * 设置产品类型的方法
	 * 
	 * @param productType
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	/**
	 * 获取分期手续费的方法
	 * 
	 * @return
	 */
	public String getDividedFee() {
		return dividedFee;
	}
	
	/**
	 * 设置分期手续费的方法
	 * 
	 * @param dividedFee
	 */
	public void setDividedFee(String dividedFee) {
		this.dividedFee = dividedFee;
	}
	
	/**
	 * 获取授权总金额的方法
	 * 
	 * @return
	 */
	public String getTotalAmt() {
		return totalAmt;
	}
	
	/**
	 * 设置授权总金额的方法
	 * 
	 * @param totalAmt
	 */
	public void setTotalAmt(String totalAmt) {
		this.totalAmt = totalAmt;
	}
	
	/**
	 * 获取分期金额的方法
	 * 
	 * @return
	 */
	public String getDividedAmt() {
		return dividedAmt;
	}
	
	/**
	 * 设置分期金额的方法
	 * 
	 * @param dividedAmt
	 */
	public void setDividedAmt(String dividedAmt) {
		this.dividedAmt = dividedAmt;
	}
	
	/**
	 * 获取保留域1的方法
	 * 
	 * @return
	 */
	public String getReserved1() {
		return reserved1;
	}
	
	/**
	 * 设置保留域1的方法
	 * 
	 * @param reserved1
	 */
	public void setReserved1(String reserved1) {
		this.reserved1 = reserved1;
	}
	
	/**
	 * 获取保留域2的方法
	 * 
	 * @return
	 */
	public String getReserved2() {
		return reserved2;
	}
	
	/**
	 * 设置保留域2的方法
	 * 
	 * @param reserved2
	 */
	public void setReserved2(String reserved2) {
		this.reserved2 = reserved2;
	}
}
