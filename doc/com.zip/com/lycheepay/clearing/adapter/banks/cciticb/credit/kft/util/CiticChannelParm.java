package com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util;

public class CiticChannelParm {
	private String terminalID;
	private String merchantId;
	private String password;
	private String batchId;
	private String token;
	private String inputType;
	private String posCoditionCode;

	public String getTerminalID() {
		return terminalID;
	}

	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getInputType() {
		return inputType;
	}

	public void setInputType(String inputType) {
		this.inputType = inputType;
	}

	public String getPosCoditionCode() {
		return posCoditionCode;
	}

	public void setPosCoditionCode(String posCoditionCode) {
		this.posCoditionCode = posCoditionCode;
	}
}
