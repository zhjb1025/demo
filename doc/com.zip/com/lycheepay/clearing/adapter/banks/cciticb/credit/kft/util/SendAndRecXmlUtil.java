package com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccount;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccountRecord;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogin;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogout;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPayment;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPaymentReversal;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Download;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.HirePurchaseReturn;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.MaintainSession;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Settlement;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 用于拼装发送报文和解析返回报文的类 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author 汤兴友
 * @version 1.0
 * 
 */
public class SendAndRecXmlUtil {
	/**
	 * 组建登录报文的方法
	 * 
	 * @param creditLogin 登录报文发送对象
	 * @return
	 */
	public static String createCreditLoginXml(CreditLogin creditLogin) {

		// 创建XML文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档的编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为login和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "login")
				.addAttribute("type", "request");

		// 为根节点添加子节点
		rootElement.addElement("infoType").addText(creditLogin.getInfoType()); // 信息类型
		rootElement.addElement("posTime").addText(creditLogin.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(creditLogin.getPosID()); // POS本地流水号
		rootElement.addElement("transTime").addText(creditLogin.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(creditLogin.getTransDate()); // 交易日期
		rootElement.addElement("retCode").addText(creditLogin.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(creditLogin.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(creditLogin.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(creditLogin.getMerchantName()); // 商户名称
		rootElement.addElement("password").addText(creditLogin.getPassword()); // 商户登陆密码
		rootElement.addElement("commentRes").addText(creditLogin.getCommentRes()); // 附加响应
		rootElement.addElement("resParam").addText(creditLogin.getResParam()); // 下装参数
		rootElement.addElement("payURL").addText(creditLogin.getPayURL()); // 支付交易地址
		rootElement.addElement("token").addText(creditLogin.getToken()); // 交易验证码
		rootElement.addElement("reserved").addText(creditLogin.getReserved()); // 保留域

		return xml_Document.asXML();
	}

	/**
	 * 组建登录报文的方法
	 * 
	 * @param creditLogout
	 * @return
	 */
	public static String createCreditLogoutXML(CreditLogout creditLogout) {

		// 创建XML文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为logout和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "logout")
				.addAttribute("type", "request");

		// 为根节点添加子节点
		rootElement.addElement("infoType").addText(creditLogout.getInfoType()); // 信息类型
		rootElement.addElement("posTime").addText(creditLogout.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(creditLogout.getPosID()); // POS本地流水号
		rootElement.addElement("transTime").addText(creditLogout.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(creditLogout.getTransDate()); // 交易日期
		rootElement.addElement("retCode").addText(creditLogout.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(creditLogout.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(creditLogout.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(creditLogout.getMerchantName()); // 商户名
		rootElement.addElement("password").addText(creditLogout.getPassword()); // 商户密码
		rootElement.addElement("commentRes").addText(creditLogout.getCommentRes()); // 附加响应
		rootElement.addElement("reserved").addText(creditLogout.getReserved()); // 保留域

		return xml_Document.asXML();
	}

	/**
	 * 组建分期支付报文的方法
	 * 
	 * @param collection
	 * @return
	 */
	public static String createDividedPaymentXML(DividedPayment dividedPayment) {

		// 创建XML文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为dividedPayment和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "dividedPayment")
				.addAttribute("type", "request");

		// 给根节点添加子节点
		rootElement.addElement("infoType").addText(dividedPayment.getInfoType()); // 信息类型
		rootElement.addElement("pan").addText(dividedPayment.getPan()); // 主帐号(卡号)
		rootElement.addElement("processCode").addText(dividedPayment.getProcessCode()); // 处理代码
		rootElement.addElement("transAmt").addText(dividedPayment.getTransAmt()); // 交易金额
		rootElement.addElement("posTime").addText(dividedPayment.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(dividedPayment.getPosID()); // POS流水
		rootElement.addElement("orderID").addText(dividedPayment.getOrderID()); // 订单编号
		rootElement.addElement("transTime").addText(dividedPayment.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(dividedPayment.getTransDate()); // 交易日期
		rootElement.addElement("inputType").addText(dividedPayment.getInputType()); // POS输入方式
		rootElement.addElement("cardSerialNo").addText(dividedPayment.getCardSerialNo()); // 卡片序列号
		rootElement.addElement("posConditionCode").addText(dividedPayment.getPosConditionCode()); // 服务点条件码
		rootElement.addElement("secondTrack").addText(dividedPayment.getSecondTrack()); // 二磁道内容
		rootElement.addElement("thirdTrack").addText(dividedPayment.getThirdTrack()); // 三磁道内容
		rootElement.addElement("systemRefCode").addText(dividedPayment.getSystemRefCode()); // 系统参考号
		rootElement.addElement("authorizeCode").addText(dividedPayment.getAuthorizeCode()); // 授权码
		rootElement.addElement("retCode").addText(dividedPayment.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(dividedPayment.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(dividedPayment.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(dividedPayment.getMerchantName()); // 商户名称
		rootElement.addElement("commentRes").addText(dividedPayment.getCommentRes()); // 附加响应
		rootElement.addElement("currCode").addText(dividedPayment.getCurrCode()); // 货币代码
		rootElement.addElement("passwdMac").addText(dividedPayment.getPasswdMac()); // 个人密码密文
		rootElement.addElement("securityInfo").addText(dividedPayment.getSecurityInfo()); // 安全控制信息
		rootElement.addElement("icDataField").addText(dividedPayment.getIcDataField()); // IC卡数据域
		rootElement.addElement("termAbilities").addText(dividedPayment.getTermAbilities()); // 自定义域
		rootElement.addElement("chIdNum").addText(dividedPayment.getChIdNum()); // 持卡人证件号码
		rootElement.addElement("chName").addText(dividedPayment.getChName()); // 持卡人姓名
		rootElement.addElement("chMobile").addText(dividedPayment.getChMobile()); // 持卡人手机号码
		rootElement.addElement("cvv2").addText(dividedPayment.getCvv2()); // 卡背面末三位数字
		rootElement.addElement("expiredDate").addText(dividedPayment.getExpiredDate()); // 卡有效期
		rootElement.addElement("dynamicPwd").addText(dividedPayment.getDynamicPwd()); // 动态密码
		rootElement.addElement("personalMsg").addText(dividedPayment.getPersonalMsg()); // 个人化信息
		rootElement.addElement("batchNo").addText(dividedPayment.getBatchNo()); // 批次号
		rootElement.addElement("dividedNum").addText(dividedPayment.getDividedNum()); // 分期期数
		rootElement.addElement("productType").addText(dividedPayment.getProductType()); // 产品类型
		rootElement.addElement("dividedFee").addText(dividedPayment.getDividedFee()); // 分期手续费
		rootElement.addElement("totalAmt").addText(dividedPayment.getTotalAmt()); // 授权总金额
		rootElement.addElement("dividedAmt").addText(dividedPayment.getDividedAmt()); // 分期金额
		rootElement.addElement("reserved1").addText(dividedPayment.getReserved1()); // 保留域1
		rootElement.addElement("reserved2").addText(dividedPayment.getReserved2()); // 保留域2

		return xml_Document.asXML();
	}

	/**
	 * 组建分期支付冲正报文的方法
	 * 
	 * @param re
	 * @return
	 */
	public static String createDividedPaymentReversalXML(DividedPaymentReversal re) {

		// 创建XML文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为dividedPaymentReversal和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "dividedPaymentReversal")
				.addAttribute("type", "request");

		// 给根节点添加子节点
		rootElement.addElement("infoType").addText(re.getInfoType()); // 信息类型
		rootElement.addElement("pan").addText(re.getPan()); // 主帐号(卡号)
		rootElement.addElement("orderID").addText(re.getOrderID()); // 订单编号
		rootElement.addElement("processCode").addText(re.getProcessCode()); // 处理代码
		rootElement.addElement("transAmt").addText(re.getTransAmt()); // 交易金额
		rootElement.addElement("posTime").addText(re.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(re.getPosID()); // POS流水
		rootElement.addElement("transTime").addText(re.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(re.getTransDate()); // 交易日期
		rootElement.addElement("inputType").addText(re.getInputType()); // POS输入方式
		rootElement.addElement("cardSerialNo").addText(re.getCardSerialNo()); // 卡片序列号
		rootElement.addElement("posConditionCode").addText(re.getPosConditionCode()); // 服务点条件码
		rootElement.addElement("secondTrack").addText(re.getSecondTrack()); // 二磁道内容
		rootElement.addElement("thirdTrack").addText(re.getThirdTrack()); // 三磁道内容
		rootElement.addElement("systemRefCode").addText(re.getSystemRefCode()); // 系统参考号
		rootElement.addElement("authorizeCode").addText(re.getAuthorizeCode()); // 授权码
		rootElement.addElement("orgPosID").addText(re.getOrgPosID()); // 原POS流水号
		rootElement.addElement("retCode").addText(re.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(re.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(re.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(re.getMerchantName()); // 商户名称
		rootElement.addElement("commentRes").addText(re.getCommentRes()); // 附加响应
		rootElement.addElement("currCode").addText(re.getCurrCode()); // 货币代码
		rootElement.addElement("passwdMac").addText(re.getPasswdMac()); // 个人密码密文
		rootElement.addElement("securityInfo").addText(re.getSecurityInfo()); // 安全控制信息
		rootElement.addElement("icDataField").addText(re.getIcDataField()); // IC卡数据域
		rootElement.addElement("termAbilities").addText(re.getTermAbilities()); // 自定义域
		rootElement.addElement("personalMsg").addText(re.getPersonalMsg()); // 个人化信息
		rootElement.addElement("chIdNum").addText(re.getChIdNum()); // 持卡人证件号码
		rootElement.addElement("chName").addText(re.getChName()); // 持卡人姓名
		rootElement.addElement("chMobile").addText(re.getChMobile()); // 持卡人手机号码
		rootElement.addElement("cvv2").addText(re.getCvv2()); // 卡背面末三位数字
		rootElement.addElement("expiredDate").addText(re.getExpiredDate()); // 卡有效期
		rootElement.addElement("dynamicPwd").addText(re.getDynamicPwd()); // 动态密码
		rootElement.addElement("dividedNum").addText(re.getDividedNum()); // 分期期数
		rootElement.addElement("productType").addText(re.getProductType()); // 产品类型
		rootElement.addElement("batchNo").addText(re.getBatchNo()); // 批次号
		rootElement.addElement("reserved1").addText(re.getReserved1()); // 保留域1
		rootElement.addElement("reserved2").addText(re.getReserved2()); // 保留域2

		return xml_Document.asXML();
	}

	/**
	 * 组建分期支付付款的方法
	 * 
	 * @param hirePurchaseReturn
	 * @return
	 */
	public static String createHirePurchaseReturnXML(HirePurchaseReturn hirePurchaseReturn) {

		// 创建XML文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档的编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为hirepurchasereturn和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "hirePurchaseReturn")
				.addAttribute("type", "request");

		// 给根节点添加子节点
		rootElement.addElement("infoType").addText(hirePurchaseReturn.getInfoType()); // 信息类型
		rootElement.addElement("pan").addText(hirePurchaseReturn.getPan()); // 主帐号(卡号)
		rootElement.addElement("orderID").addText(hirePurchaseReturn.getOrderID()); // 订单编号
		rootElement.addElement("processCode").addText(hirePurchaseReturn.getProcessCode()); // 处理代码
		rootElement.addElement("orgTransAmt").addText(hirePurchaseReturn.getOrgTransAmt()); // 原交易金额
		rootElement.addElement("transAmt").addText(hirePurchaseReturn.getTransAmt()); // 退货金额
		rootElement.addElement("posTime").addText(hirePurchaseReturn.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(hirePurchaseReturn.getPosID()); // POS流水
		rootElement.addElement("transTime").addText(hirePurchaseReturn.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(hirePurchaseReturn.getTransDate()); // 交易日期
		rootElement.addElement("inputType").addText(hirePurchaseReturn.getInputType()); // POS输入方式
		rootElement.addElement("cardSerialNo").addText(hirePurchaseReturn.getCardSerialNo()); // 卡片序列号
		rootElement.addElement("posConditionCode").addText(hirePurchaseReturn.getPosConditionCode()); // 服务点条件码
		rootElement.addElement("secondTrack").addText(hirePurchaseReturn.getSecondTrack()); // 二磁道内容
		rootElement.addElement("thirdTrack").addText(hirePurchaseReturn.getThirdTrack()); // 三磁道内容
		rootElement.addElement("systemRefCode").addText(hirePurchaseReturn.getSystemRefCode()); // 系统参考号
		rootElement.addElement("authorizeCode").addText(hirePurchaseReturn.getAuthorizeCode()); // 授权码
		rootElement.addElement("retCode").addText(hirePurchaseReturn.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(hirePurchaseReturn.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(hirePurchaseReturn.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(hirePurchaseReturn.getMerchantName()); // 商户名称
		rootElement.addElement("commentRes").addText(hirePurchaseReturn.getCommentRes()); // 附加响应
		rootElement.addElement("currCode").addText(hirePurchaseReturn.getCurrCode()); // 货币代码
		rootElement.addElement("orgPosID").addText(hirePurchaseReturn.getOrgPosID()); // 原POS流水号
		rootElement.addElement("orgBatchNo").addText(hirePurchaseReturn.getOrgBatchNo()); // 原批次号
		rootElement.addElement("passwdMac").addText(hirePurchaseReturn.getPasswdMac()); // 个人密码密文
		rootElement.addElement("securityInfo").addText(hirePurchaseReturn.getSecurityInfo()); // 安全控制信息
		rootElement.addElement("icDataField").addText(hirePurchaseReturn.getIcDataField()); // IC卡数据域
		rootElement.addElement("termAbilities").addText(hirePurchaseReturn.getTermAbilities()); // 自定义域
		rootElement.addElement("personalMsg").addText(hirePurchaseReturn.getPersonalMsg()); // 个人化信息
		rootElement.addElement("chIdNum").addText(hirePurchaseReturn.getChIdNum()); // 持卡人证件号码
		rootElement.addElement("chName").addText(hirePurchaseReturn.getChName()); // 持卡人姓名
		rootElement.addElement("chMobile").addText(hirePurchaseReturn.getChMobile()); // 持卡人手机号码
		rootElement.addElement("cvv2").addText(hirePurchaseReturn.getCvv2()); // 卡背面末三位数字
		rootElement.addElement("expiredDate").addText(hirePurchaseReturn.getExpiredDate()); // 卡有效期
		rootElement.addElement("dynamicPwd").addText(hirePurchaseReturn.getDynamicPwd()); // 动态密码
		rootElement.addElement("dividedNum").addText(hirePurchaseReturn.getDividedNum()); // 分期期数
		rootElement.addElement("productType").addText(hirePurchaseReturn.getProductType()); // 产品类型
		rootElement.addElement("batchNo").addText(hirePurchaseReturn.getBatchNo()); // 批次号
		rootElement.addElement("reserved1").addText(hirePurchaseReturn.getReserved1()); // 保留域1
		rootElement.addElement("reserved2").addText(hirePurchaseReturn.getReserved2()); // 保留域2

		return xml_Document.asXML();
	}

	/**
	 * 组建维护连接报文的方法
	 * 
	 * @param maintainSession
	 * @return
	 */
	public static String createMainSessionXML(MaintainSession maintainSession) {

		// 创建XML文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档的编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为maintainsession和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", " maintainsession")
				.addAttribute("type", "request");

		// 为根节点添加子节点
		rootElement.addElement("infoType").addText(maintainSession.getInfoType()); // 信息类型
		rootElement.addElement("merchantID").addText(maintainSession.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(maintainSession.getMerchantName()); // 商户名称
		rootElement.addElement("token").addText(maintainSession.getToken()); // 交易验证码
		rootElement.addElement("retCode").addText(maintainSession.getRetCode()); // 返回码
		rootElement.addElement("commentRes").addText(maintainSession.getCommentRes()); // 附加响应

		return xml_Document.asXML();
	}

	/**
	 * 组建结算报文的方法
	 * 
	 * @param settlement
	 * @return
	 */
	public static String createSettlementXML(Settlement settlement) {

		// 创建XML对文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档的编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为settltment和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "settltment")
				.addAttribute("type", "request");

		// 为根节点添加子节点
		rootElement.addElement("infoType").addText(settlement.getInfoType()); // 信息类型
		rootElement.addElement("posTime").addText(settlement.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(settlement.getPosID()); // POS本地流水号
		rootElement.addElement("transTime").addText(settlement.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(settlement.getTransDate()); // 交易日期
		rootElement.addElement("retCode").addText(settlement.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(settlement.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(settlement.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(settlement.getMerchantName()); // 商户名称
		rootElement.addElement("batchNo").addText(settlement.getBatchNo()); // 批次号
		rootElement.addElement("totalTrsCnt").addText(settlement.getTotalTrsCnt()); // 交易总条数
		rootElement.addElement("sign").addText(settlement.getSign()); // 金额符号表示
		rootElement.addElement("traSumAmt").addText(settlement.getTraSumAmt()); // 交易总金额
		rootElement.addElement("successFlag").addText(settlement.getSuccessFlag()); // 成功标志
		rootElement.addElement("commentRes").addText(settlement.getCommentRes()); // 附加响应
		rootElement.addElement("reserved").addText(settlement.getReserved()); // 保留域

		return xml_Document.asXML();
	}

	/**
	 * 组建明细的方式进行请款
	 * 
	 * @param settlement
	 * @return
	 * @throws BizException
	 */
	public static String createCheckAccountXML(CheckAccount checkAccount) throws BizException {

		// 创建XML对文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档的编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为checkAccount和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "checkAccount")
				.addAttribute("type", "request");

		// 为根节点添加子节点
		rootElement.addElement("infoType").addText(checkAccount.getInfoType()); // 信息类型
		rootElement.addElement("posTime").addText(checkAccount.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(checkAccount.getPosID()); // POS本地流水号
		rootElement.addElement("transTime").addText(checkAccount.getTransTime()); // 交易时间
		rootElement.addElement("transDate").addText(checkAccount.getTransDate()); // 交易日期
		rootElement.addElement("retCode").addText(checkAccount.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(checkAccount.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(checkAccount.getMerchantID()); // 商户号
		rootElement.addElement("merchantName").addText(checkAccount.getMerchantName()); // 商户名称
		rootElement.addElement("batchNo").addText(checkAccount.getBatchNo()); // 批次号

		/**
		 * dataSet 明细交易记录
		 */
		List<CheckAccountRecord> records = checkAccount.getRecords();
		int recordNum = records.size();
		Element dataSet = rootElement.addElement("dataSet").addAttribute("count", String.valueOf(recordNum));

		String record = null;
		for (CheckAccountRecord rd : records) {
			record = "";
			record += FormatTransfer.setStrFormat(rd.getMerchantID(), 15); // 15A
			record += FormatTransfer.setStrFormat(rd.getTerminalID(), 8); // 8A
			record += FormatTransfer.setStrFormat(rd.getBatchNo(), 6); // 6A
			record += FormatTransfer.setStrFormat(rd.getTransDate(), 8); // 8A
			record += FormatTransfer.setStrFormat(rd.getTransTime(), 8); // 8A
			record += FormatTransfer.setStrFormat(rd.getPanOrderId(), 19); // 19A
			record += FormatTransfer.setStrFormat(rd.getTransAmt(), 13); // 13A
			record += FormatTransfer.setStrFormat(rd.getCurrCode(), 3); // 3A
			record += FormatTransfer.setStrFormat(rd.getSystemRefCode(), 12);// 12A
			record += FormatTransfer.setStrFormat(rd.getPosID(), 6); // 6A
			record += FormatTransfer.setStrFormat(rd.getAuthorizeCode(), 6);// 6A
			record += FormatTransfer.setStrFormat(rd.getProductCode(), 6); // 6A
			record += FormatTransfer.setStrFormat(rd.getDividedMonths(), 2);// 2A
			record += FormatTransfer.setStrFormat(rd.getRefundFlg(), 1); // 1A
			record += FormatTransfer.setStrFormat(rd.getCheckFlg(), 1); // 1A
			record += FormatTransfer.setStrFormat(rd.getFiller(), 36); // 36A

			if (150 != record.length())
				throw new BizException(TransReturnCode.code_9108, "对帐接口 checkAccount 中的 dataSet - Record 总长应为150");

			dataSet.addElement("record").addText(record);
		}

		rootElement.addElement("terminalFlag").addText(checkAccount.getTerminalFlag()); // 成功标志
		rootElement.addElement("commentRes").addText(checkAccount.getCommentRes()); // 附加响应
		rootElement.addElement("reserved").addText(checkAccount.getReserved()); // 保留域

		return xml_Document.asXML();
	}

	/**
	 * 解析 "明细的方式的请款" 结果
	 * 
	 * @param rec
	 * @param param
	 * @return
	 */
	public static CheckAccount parseCheckAccountXML(String rec) {

		CheckAccount checkAccount = new CheckAccount();
		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装的实体中去
			checkAccount.setInfoType(rootElement.elementTextTrim("infoType"));
			checkAccount.setPosTime(rootElement.elementTextTrim("posTime"));
			checkAccount.setPosID(rootElement.elementTextTrim("posID"));
			checkAccount.setTransTime(rootElement.elementTextTrim("transTime"));
			checkAccount.setTransDate(rootElement.elementTextTrim("transDate"));
			checkAccount.setRetCode(rootElement.elementTextTrim("retCode"));
			checkAccount.setTerminalID(rootElement.elementTextTrim("terminalID"));
			checkAccount.setMerchantID(rootElement.elementTextTrim("merchantID"));
			checkAccount.setMerchantName(rootElement.elementTextTrim("merchantName"));
			checkAccount.setBatchNo(rootElement.elementTextTrim("batchNo"));

			/**
			 * record明细解析
			 */
			Iterator it = rootElement.element("dataSet").elementIterator("record");

			String record = "";
			List<CheckAccountRecord> records = new ArrayList<CheckAccountRecord>();
			CheckAccountRecord bean = null;

			while (it.hasNext()) {
				Element re = (Element) it.next();
				record = re.getText();

				if (record == null || record.length() != 150)
					continue;

				Log4jUtil.info("明细请款返回:" + record);
				bean = parseCheckAccountRecord(record);
				records.add(bean);
			}

			checkAccount.setRecords(records);
			checkAccount.setTerminalFlag(rootElement.elementTextTrim("terminalFlag"));
			checkAccount.setCommentRes(rootElement.elementTextTrim("commentRes"));
			checkAccount.setReserved(rootElement.elementTextTrim("reserved"));

		} catch (DocumentException e) {
			Log4jUtil.error("明细方式请款XML字符串转换成XML对象失败:", e);
		} catch (Exception e) {
			Log4jUtil.error("明细方式请款XML字符串转换成XML对象失败:", e);
		}

		return checkAccount;
	}

	/**
	 * 
	 * <p>解析CheckAccountRecord</p>
	 * 
	 * @param record
	 * @return
	 * @author 汤兴友 13692259317
	 * @throws BizException
	 */
	private static CheckAccountRecord parseCheckAccountRecord(String record) throws BizException {
		if (record == null || record.length() != 150)
			throw new BizException(TransReturnCode.code_9109, "CheckData返回数据总长应为150");
		CheckAccountRecord bean = new CheckAccountRecord();
		bean.setMerchantID(record.substring(0, 15).trim()); // 商户号 15A
		bean.setTerminalID(record.substring(15, 23).trim()); // 终端号 8A
		bean.setBatchNo(record.substring(23, 29).trim()); // 批次号 6A
		bean.setTransDate(record.substring(29, 37).trim()); // 交易日期 8A
		bean.setTransTime(record.substring(37, 45).trim()); // 交易时间 8A
		bean.setPanOrderId(record.substring(45, 64).trim()); // 主帐号(卡号)或订单号19A
		bean.setTransAmt(record.substring(64, 77).trim()); // 交易金额 13A
		bean.setCurrCode(record.substring(77, 80).trim()); // 货币代码 3A
		bean.setSystemRefCode(record.substring(80, 92).trim()); // 系统参考号 12A
		bean.setPosID(record.substring(92, 98).trim()); // POS流水号 6A
		bean.setAuthorizeCode(record.substring(98, 104).trim()); // 交易授权码 6A
		bean.setProductCode(record.substring(104, 110).trim()); // 产品代码 6A
		bean.setDividedMonths(record.substring(110, 112).trim()); // 分期期数 2A
		bean.setRefundFlg(record.substring(112, 113).trim()); // 退货标记 1A
		bean.setCheckFlg(record.substring(113, 114).trim()); // 核对标识 1A
		bean.setFiller(record.substring(114, 150).trim()); // 保留字段 36A

		return bean;
	}

	/**
	 * 组建流水文件下载接口报文的方法
	 * 
	 * @param download
	 * @return
	 */
	public static String createDownloadXML(Download download) {

		// 创建XML对文档对象
		Document xml_Document = DocumentHelper.createDocument();

		// 设置XML文档的编码格式
		xml_Document.setXMLEncoding("GBK");

		// 添加名称为“message”的根节点，并添加属性method和type，设置值为download和request
		Element rootElement = xml_Document.addElement("message").addAttribute("method", "download")
				.addAttribute("type", "request");

		// 为根节点添加子节点
		rootElement.addElement("infoType").addText(download.getInfoType()); // 信息类型
		rootElement.addElement("posTime").addText(download.getPosTime()); // POS交易时间
		rootElement.addElement("posID").addText(download.getPosID()); // POS本地流水号
		rootElement.addElement("retCode").addText(download.getRetCode()); // 返回码
		rootElement.addElement("terminalID").addText(download.getTerminalID()); // 终端号
		rootElement.addElement("merchantID").addText(download.getMerchantID()); // 商户号
		rootElement.addElement("fileType").addText(download.getFileType()); // 文件类型
		rootElement.addElement("dataSet").addText(download.getDataSet()); // 数据结果集
		rootElement.addElement("date").addText(download.getDate()); // 获取某一天的流水文件的时间
		rootElement.addElement("commentRes").addText(download.getCommentRes()); // 附加响应
		rootElement.addElement("reserved").addText(download.getReserved()); // 保留域

		return xml_Document.asXML();
	}

	/**
	 * 解析登录返回报文的方法
	 * 
	 * @param rec 中信银行返回的登录返回报文
	 * @return
	 */
	public static CreditLogin parseCreditLoginXml(Object rec) {

		CreditLogin creditLogin = new CreditLogin();

		if (rec == null || "".equals(rec.toString())) {
			return null;
		}

		Document doc = null;

		try {
			doc = DocumentHelper.parseText(rec.toString());// 将字符串转为XML

			Element rootElt = doc.getRootElement(); // 获取根节点

			// 解析XML并把代码封装到实体中去
			creditLogin.setInfoType(rootElt.elementTextTrim("infoType"));
			creditLogin.setPosTime(rootElt.elementTextTrim("posTime"));
			creditLogin.setPosID(rootElt.elementTextTrim("posID"));
			creditLogin.setTransTime(rootElt.elementTextTrim("transTime"));
			creditLogin.setTransDate(rootElt.elementTextTrim("transDate"));
			creditLogin.setRetCode(rootElt.elementTextTrim("retCode"));
			creditLogin.setTerminalID(rootElt.elementTextTrim("terminalID"));
			creditLogin.setMerchantID(rootElt.elementTextTrim("merchantID"));
			creditLogin.setPassword(rootElt.elementTextTrim("password"));
			creditLogin.setCommentRes(rootElt.elementTextTrim("commentRes"));

			Iterator iters = rootElt.elementIterator("resParam"); // 获取子节点resParam
			while (iters.hasNext()) {
				Element itemEle = (Element) iters.next();
				String payURL = itemEle.elementTextTrim("payURL");
				String token = itemEle.elementTextTrim("token");
				Log4jUtil.info("-登陆回执Token为【{}】", token);
				creditLogin.setPayURL(payURL);
				creditLogin.setToken(token);
			}

			creditLogin.setReserved(rootElt.elementTextTrim("reserved"));

		} catch (DocumentException e) {
			Log4jUtil.error("---登录XML字符串转换成XML对象失败--", e);

		} catch (Exception e) {
			Log4jUtil.error("---解析登录XML字符串出错---", e);
		}

		return creditLogin;
	}

	/**
	 * 解析登出返回报文的方法
	 * 
	 * @param rec
	 * @return
	 */
	public static CreditLogout parseCreditLogoutXml(String rec) {
		CreditLogout creditLogout = new CreditLogout();
		try {
			// 将XML字符串转换成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 将XML里面的数据封入实体当中
			creditLogout.setInfoType(rootElement.elementTextTrim("infoType"));
			creditLogout.setPosTime(rootElement.elementTextTrim("posTime"));
			creditLogout.setPosID(rootElement.elementTextTrim("posID"));
			creditLogout.setTransTime(rootElement.elementTextTrim("transTime"));
			creditLogout.setTransDate(rootElement.elementTextTrim("transDate"));
			creditLogout.setRetCode(rootElement.elementTextTrim("retCode"));
			creditLogout.setTerminalID(rootElement.elementTextTrim("terminalID"));
			creditLogout.setMerchantID(rootElement.elementTextTrim("merchantID"));
			creditLogout.setMerchantName(rootElement.elementTextTrim("merchantName"));
			creditLogout.setPassword(rootElement.elementTextTrim("password"));
			creditLogout.setCommentRes(rootElement.elementTextTrim("commentRes"));
			creditLogout.setReserved(rootElement.elementTextTrim("reserved"));

		} catch (DocumentException e) {
			Log4jUtil.error("--登出XML字符串转换成XML对象失败-----", e);
		} catch (Exception e) {
			Log4jUtil.error("--解析登出XML字符串出错-----", e);
		}

		return creditLogout;
	}

	/**
	 * 解析分期支付回执报文的方法
	 * 
	 * @param rec 回执的XML
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public static DividedPayment parseDividedPaymentXML(String rec) throws BizException {

		DividedPayment dividedPayment = new DividedPayment();

		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装到实体中去
			dividedPayment.setInfoType(rootElement.elementTextTrim("infoType"));
			dividedPayment.setPan(rootElement.elementTextTrim("pan"));
			dividedPayment.setProcessCode(rootElement.elementTextTrim("processCode"));
			dividedPayment.setTransAmt(rootElement.elementTextTrim("transAmt"));
			dividedPayment.setPosTime(rootElement.elementTextTrim("posTime"));
			dividedPayment.setPosID(rootElement.elementTextTrim("posID"));
			dividedPayment.setOrderID(rootElement.elementTextTrim("orderID"));
			dividedPayment.setTransTime(rootElement.elementTextTrim("transTime"));
			dividedPayment.setTransDate(rootElement.elementTextTrim("transDate"));
			dividedPayment.setInputType(rootElement.elementTextTrim("inputType"));
			dividedPayment.setCardSerialNo(rootElement.elementTextTrim("cardSerialNo"));
			dividedPayment.setPosConditionCode(rootElement.elementTextTrim("posConditionCode"));
			dividedPayment.setSecondTrack(rootElement.elementTextTrim("secondTrack"));
			dividedPayment.setThirdTrack(rootElement.elementTextTrim("thirdTrack"));
			dividedPayment.setSystemRefCode(rootElement.elementTextTrim("systemRefCode"));
			dividedPayment.setAuthorizeCode(rootElement.elementTextTrim("authorizeCode"));
			dividedPayment.setRetCode(rootElement.elementTextTrim("retCode"));
			dividedPayment.setTerminalID(rootElement.elementTextTrim("terminalID"));
			dividedPayment.setMerchantID(rootElement.elementTextTrim("merchantID"));
			dividedPayment.setMerchantName(rootElement.elementTextTrim("merchantName"));
			dividedPayment.setCommentRes(rootElement.elementTextTrim("commentRes"));
			dividedPayment.setCurrCode(rootElement.elementTextTrim("currCode"));
			dividedPayment.setPasswdMac(rootElement.elementTextTrim("passwdMac"));
			dividedPayment.setSecurityInfo(rootElement.elementTextTrim("securityInfo"));
			dividedPayment.setIcDataField(rootElement.elementTextTrim("icDataField"));
			dividedPayment.setTermAbilities(rootElement.elementTextTrim("termAbilities"));
			dividedPayment.setChIdNum(rootElement.elementTextTrim("chIdNum"));
			dividedPayment.setChName(rootElement.elementTextTrim("chName"));
			dividedPayment.setChMobile(rootElement.elementTextTrim("chMobile"));
			dividedPayment.setCvv2(rootElement.elementTextTrim("cvv2"));
			dividedPayment.setExpiredDate(rootElement.elementTextTrim("expiredDate"));
			dividedPayment.setDynamicPwd(rootElement.elementTextTrim("dynamicPwd"));
			dividedPayment.setPersonalMsg(rootElement.elementTextTrim("personalMsg"));
			dividedPayment.setBatchNo(rootElement.elementTextTrim("batchNo"));
			dividedPayment.setDividedNum(rootElement.elementTextTrim("dividedNum"));
			dividedPayment.setProductType(rootElement.elementTextTrim("productType"));
			dividedPayment.setDividedFee(rootElement.elementTextTrim("dividedFee"));
			dividedPayment.setTotalAmt(rootElement.elementTextTrim("totalAmt"));
			dividedPayment.setDividedAmt(rootElement.elementTextTrim("dividedAmt"));
			dividedPayment.setReserved1(rootElement.elementTextTrim("reserved1"));
			dividedPayment.setReserved2(rootElement.elementTextTrim("reserved2"));

		} catch (DocumentException e) {
			Log4jUtil.error("中信银行信用卡：分期支付XML字符串转换成XML对象失败，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		} catch (Exception e) {
			Log4jUtil.error("中信银行信用卡：解析分期支付XML字符串出错，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		}

		return dividedPayment;
	}

	/**
	 * 解析分期支付冲正回执报文的方法
	 * 
	 * @param rec
	 * @return
	 */
	public static DividedPaymentReversal parseDividedPaymentReversalXML(String rec) {

		DividedPaymentReversal dividedPaymentReversal = new DividedPaymentReversal();

		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装到实体中去
			dividedPaymentReversal.setInfoType(rootElement.elementTextTrim("infoType"));
			dividedPaymentReversal.setPan(rootElement.elementTextTrim("pan"));
			dividedPaymentReversal.setOrderID(rootElement.elementTextTrim("orderID"));
			dividedPaymentReversal.setProcessCode(rootElement.elementTextTrim("processCode"));
			dividedPaymentReversal.setTransAmt(rootElement.elementTextTrim("transAmt"));
			dividedPaymentReversal.setPosTime(rootElement.elementTextTrim("posTime"));
			dividedPaymentReversal.setPosID(rootElement.elementTextTrim("posID"));
			dividedPaymentReversal.setTransTime(rootElement.elementTextTrim("transTime"));
			dividedPaymentReversal.setTransDate(rootElement.elementTextTrim("transDate"));
			dividedPaymentReversal.setInputType(rootElement.elementTextTrim("inputType"));
			dividedPaymentReversal.setCardSerialNo(rootElement.elementTextTrim("cardSerialNo"));
			dividedPaymentReversal.setPosConditionCode(rootElement.elementTextTrim("posConditionCode"));
			dividedPaymentReversal.setSecondTrack(rootElement.elementTextTrim("secondTrack"));
			dividedPaymentReversal.setThirdTrack(rootElement.elementTextTrim("thirdTrack"));
			dividedPaymentReversal.setSystemRefCode(rootElement.elementTextTrim("systemRefCode"));
			dividedPaymentReversal.setAuthorizeCode(rootElement.elementTextTrim("authorizeCode"));
			dividedPaymentReversal.setOrgPosID(rootElement.elementTextTrim("orgPosID"));
			dividedPaymentReversal.setRetCode(rootElement.elementTextTrim("retCode"));
			dividedPaymentReversal.setTerminalID(rootElement.elementTextTrim("terminalID"));
			dividedPaymentReversal.setMerchantID(rootElement.elementTextTrim("merchantID"));
			dividedPaymentReversal.setMerchantName(rootElement.elementTextTrim("merchantName"));
			dividedPaymentReversal.setCommentRes(rootElement.elementTextTrim("commentRes"));
			dividedPaymentReversal.setCurrCode(rootElement.elementTextTrim("currCode"));
			dividedPaymentReversal.setPasswdMac(rootElement.elementTextTrim("passwdMac"));
			dividedPaymentReversal.setSecurityInfo(rootElement.elementTextTrim("securityInfo"));
			dividedPaymentReversal.setIcDataField(rootElement.elementTextTrim("icDataField"));
			dividedPaymentReversal.setTermAbilities(rootElement.elementTextTrim("termAbilities"));
			dividedPaymentReversal.setPersonalMsg(rootElement.elementTextTrim("personalMsg"));
			dividedPaymentReversal.setChIdNum(rootElement.elementTextTrim("chIdNum"));
			dividedPaymentReversal.setChName(rootElement.elementTextTrim("chName"));
			dividedPaymentReversal.setChMobile(rootElement.elementTextTrim("chMobile"));
			dividedPaymentReversal.setCvv2(rootElement.elementTextTrim("cvv2"));
			dividedPaymentReversal.setExpiredDate(rootElement.elementTextTrim("expiredDate"));
			dividedPaymentReversal.setDynamicPwd(rootElement.elementTextTrim("dynamicPwd"));
			dividedPaymentReversal.setDividedNum(rootElement.elementTextTrim("dividedNum"));
			dividedPaymentReversal.setProductType(rootElement.elementTextTrim("productType"));
			dividedPaymentReversal.setBatchNo(rootElement.elementTextTrim("batchNo"));
			dividedPaymentReversal.setReserved1(rootElement.elementTextTrim("reserved1"));
			dividedPaymentReversal.setReserved2(rootElement.elementTextTrim("reserved2"));

		} catch (DocumentException e) {
			Log4jUtil.error("中信银行信用卡：分期支付XML字符串转换成XML对象失败，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		} catch (Exception e) {
			Log4jUtil.error("中信银行信用卡：解析分期支付XML字符串出错，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		}

		return dividedPaymentReversal;
	}

	/**
	 * 解析分期支付退款XML的回执的方法
	 * 
	 * @param rec
	 * @return
	 * @throws BizException
	 */
	public static HirePurchaseReturn parseHirePurchaseReturnXML(String rec) throws BizException {

		HirePurchaseReturn hirePurchaseReturn = new HirePurchaseReturn();

		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装到实体中去
			hirePurchaseReturn.setInfoType(rootElement.elementTextTrim("infoType"));
			hirePurchaseReturn.setPan(rootElement.elementTextTrim("pan"));
			hirePurchaseReturn.setOrderID(rootElement.elementTextTrim("orderID"));
			hirePurchaseReturn.setProcessCode(rootElement.elementTextTrim("processCode"));
			hirePurchaseReturn.setOrgTransAmt(rootElement.elementTextTrim("orgTransAmt"));
			hirePurchaseReturn.setTransAmt(rootElement.elementTextTrim("transAmt"));
			hirePurchaseReturn.setPosTime(rootElement.elementTextTrim("posTime"));
			hirePurchaseReturn.setPosID(rootElement.elementTextTrim("posID"));
			hirePurchaseReturn.setTransTime(rootElement.elementTextTrim("transTime"));
			hirePurchaseReturn.setTransDate(rootElement.elementTextTrim("transDate"));
			hirePurchaseReturn.setInputType(rootElement.elementText("inputType"));
			hirePurchaseReturn.setCardSerialNo(rootElement.elementTextTrim("cardSerialNo"));
			hirePurchaseReturn.setPosConditionCode(rootElement.elementTextTrim("posConditionCode"));
			hirePurchaseReturn.setSecondTrack(rootElement.elementTextTrim("secondTrack"));
			hirePurchaseReturn.setThirdTrack(rootElement.elementTextTrim("thirdTrack"));
			hirePurchaseReturn.setSystemRefCode(rootElement.elementTextTrim("systemRefCode"));
			hirePurchaseReturn.setAuthorizeCode(rootElement.elementTextTrim("authorizeCode"));
			hirePurchaseReturn.setRetCode(rootElement.elementTextTrim("retCode"));
			hirePurchaseReturn.setTerminalID(rootElement.elementTextTrim("terminalID"));
			hirePurchaseReturn.setMerchantID(rootElement.elementTextTrim("merchantID"));
			hirePurchaseReturn.setMerchantName(rootElement.elementTextTrim("merchantName"));
			hirePurchaseReturn.setCommentRes(rootElement.elementTextTrim("commentRes"));
			hirePurchaseReturn.setCurrCode(rootElement.elementTextTrim("currCode"));
			hirePurchaseReturn.setOrgPosID(rootElement.elementTextTrim("orgPosID"));
			hirePurchaseReturn.setOrgBatchNo(rootElement.elementTextTrim("orgBatchNo"));
			hirePurchaseReturn.setPasswdMac(rootElement.elementTextTrim("passwdMac"));
			hirePurchaseReturn.setSecurityInfo(rootElement.elementTextTrim("securityInfo"));
			hirePurchaseReturn.setIcDataField(rootElement.elementTextTrim("icDataField"));
			hirePurchaseReturn.setTermAbilities(rootElement.elementTextTrim("termAbilities"));
			hirePurchaseReturn.setPersonalMsg(rootElement.elementTextTrim("personalMsg"));
			hirePurchaseReturn.setChIdNum(rootElement.elementTextTrim("chIdNum"));
			hirePurchaseReturn.setChName(rootElement.elementTextTrim("chName"));
			hirePurchaseReturn.setChMobile(rootElement.elementTextTrim("chMobile"));
			hirePurchaseReturn.setCvv2(rootElement.elementTextTrim("cvv2"));
			hirePurchaseReturn.setExpiredDate(rootElement.elementTextTrim("expiredDate"));
			hirePurchaseReturn.setDynamicPwd(rootElement.elementTextTrim("dynamicPwd"));
			hirePurchaseReturn.setDividedNum(rootElement.elementTextTrim("dividedNum"));
			hirePurchaseReturn.setProductType(rootElement.elementTextTrim("productType"));
			hirePurchaseReturn.setBatchNo(rootElement.elementTextTrim("batchNo"));
			hirePurchaseReturn.setReserved1(rootElement.elementTextTrim("reserved1"));
			hirePurchaseReturn.setReserved2(rootElement.elementTextTrim("reserved2"));

		} catch (DocumentException e) {
			Log4jUtil.error("中信银行信用卡：分期支付退款XML字符串转换成XML对象失败，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		} catch (Exception e) {
			Log4jUtil.error("中信银行信用卡：解析分期支付退款XML字符串出错，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		}

		return hirePurchaseReturn;
	}

	/**
	 * 解析维护连接返回报文的方法
	 * 
	 * @param maintainSession
	 * @return
	 * @throws BizException
	 */
	public static MaintainSession parseMainSessionXML(String rec, Param param) throws BizException {
		Log4jUtil.setLogClass("channelLog" + File.separator + param.getChannelId(), param.getChannelId() + "QTimer");

		MaintainSession maintainSession = new MaintainSession();

		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装到实体中去
			maintainSession.setInfoType(rootElement.elementTextTrim("infoType"));
			maintainSession.setMerchantID(rootElement.elementTextTrim("merchantID"));
			maintainSession.setMerchantName(rootElement.elementTextTrim("merchantName"));
			maintainSession.setToken(rootElement.elementTextTrim("token"));
			maintainSession.setRetCode(rootElement.elementTextTrim("retCode"));
			maintainSession.setCommentRes(rootElement.elementTextTrim("commentRes"));

		} catch (DocumentException e) {
			Log4jUtil.error("中信银行信用卡：维护连接XML字符串转换成XML对象失败，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		} catch (Exception e) {
			Log4jUtil.error("中信银行信用卡：解析维护连接XML字符串出错，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		}

		return maintainSession;
	}

	/**
	 * 解析结算接口回执报文的方法
	 * 
	 * @param rec
	 * @param param
	 * @return
	 */
	public static Settlement parseSettlementXML(String rec) {

		Settlement settlement = new Settlement();
		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装的实体中去
			settlement.setInfoType(rootElement.elementTextTrim("infoType"));
			settlement.setPosTime(rootElement.elementTextTrim("posTime"));
			settlement.setPosID(rootElement.elementTextTrim("posID"));
			settlement.setTransTime(rootElement.elementTextTrim("transTime"));
			settlement.setTransDate(rootElement.elementTextTrim("transDate"));
			settlement.setRetCode(rootElement.elementTextTrim("retCode"));
			settlement.setTerminalID(rootElement.elementTextTrim("terminalID"));
			settlement.setMerchantID(rootElement.elementTextTrim("merchantID"));
			settlement.setMerchantName(rootElement.elementTextTrim("merchantName"));
			settlement.setBatchNo(rootElement.elementTextTrim("batchNo"));
			settlement.setTotalTrsCnt(rootElement.elementTextTrim("totalTrsCnt"));
			settlement.setSign(rootElement.elementTextTrim("sign"));
			settlement.setTraSumAmt(rootElement.elementTextTrim("traSumAmt"));
			settlement.setSuccessFlag(rootElement.elementTextTrim("successFlag"));
			settlement.setCommentRes(rootElement.elementTextTrim("commentRes"));
			settlement.setReserved(rootElement.elementTextTrim("reserved"));

		} catch (DocumentException e) {
			Log4jUtil.error("中信银行信用卡：结算接口XML字符串转换成XML对象失败，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		} catch (Exception e) {
			Log4jUtil.error("中信银行信用卡：解析结算接口XML字符串出错，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		}

		return settlement;
	}

	/**
	 * 解析下载流水文件的返回报文的方法
	 * 
	 * @param rec
	 * @return
	 */
	public static Download parseDownload(String rec) {

		Download download = new Download();

		List<String> list_record = new ArrayList<String>();

		try {
			// XML字符串解析成XML文档对象
			Document doc = DocumentHelper.parseText(rec);

			// 获取根节点
			Element rootElement = doc.getRootElement();

			// 把XML里面的数据封装的实体中去
			download.setInfoType(rootElement.elementTextTrim("infoType"));
			download.setPosTime(rootElement.elementTextTrim("posTime"));
			download.setPosID(rootElement.elementTextTrim("posID"));
			download.setRetCode(rootElement.elementTextTrim("retCode"));
			download.setTerminalID(rootElement.elementTextTrim("terminalID"));
			download.setMerchantID(rootElement.elementTextTrim("merchantID"));
			download.setFileType(rootElement.elementTextTrim("fileType"));

			Iterator it = rootElement.element("dataSet").elementIterator("record");

			while (it.hasNext()) {
				Element recordElement = (Element) it.next();

				String str = recordElement.getText();

				list_record.add(str);
			}

			download.setList_data(list_record);

			download.setDate(rootElement.elementTextTrim("date"));
			download.setCommentRes(rootElement.elementTextTrim("commentRes"));
			download.setReserved(rootElement.elementTextTrim("reserved"));

		} catch (DocumentException e) {
			Log4jUtil.error("中信银行信用卡：流水文件下载接口XML字符串转换成XML对象失败，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		} catch (Exception e) {
			Log4jUtil.error("中信银行信用卡：解析流水文件下载接口XML字符串出错，执行时间是：" + DateUtil.getCurrentDateTime(), e);
		}

		return download;
	}
}
