/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-7-4 下午3:39:14
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.cciticb.handler;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.processor.CciticbCreditDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中信银行信用卡服务入口类</P>
 * 
 * @author 汤兴友
 */
@Service(ClearingAdapterAnnotationName.CCITICB_CREDIT_CHANNEL_SERVICE)
public class CciticbCreditChannelService extends AbstractChannelService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCITICB_CREDIT_DIRECT_PROCESS)
	private CciticbCreditDirectProcess cciticbCreditDirectProcess;

	public final static String channelId = ChannelIdEnum.ECITIC_CREDIT_CARD.getCode();

	/**
	 * 单笔实时代扣
	 */
	@Override
	public ClearingResultDTO directDeduct(DeductDTO deductDTO) {
		Log4jUtil.setLogClass("ECITIC", "direct");
		Log4jUtil.info(deductDTO);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);

		try {
			dto = ChannelResultUtil.covertResultDTO(cciticbCreditDirectProcess.directDeduct(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 自适应实时退款
	 */
	@Override
	public ClearingResultDTO autoRealtimeRefund(RefundDTO refund) {
		Log4jUtil.setLogClass("ECITIC", "refund");
		Log4jUtil.info(refund);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		param.setSn(refund.getTxnId());
		param.setCardType(refund.getBankCardType());
		param.setBorc(refund.getAccountType());
		param.setBizBean(refund);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);

		try {
			dto = ChannelResultUtil.covertResultDTO(cciticbCreditDirectProcess.autoAdaptRefund(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 
	 * <p>批结算定时任务处理</p> <p>yesterday 若不指定(为null或为空)则默认为当天的所有未结算的批次</p>
	 * 
	 * @param yesterday
	 * @author 汤兴友 xytang
	 * @throws ClearingAdapterBizCheckedException
	 */
	public void dealBatSettle(Date yesterday) {
		Log4jUtil.setLogClass("ECITIC", "dealBatSettle");

		ReturnState returnState = new ReturnState();
		try {
			returnState = cciticbCreditDirectProcess.dealBatSettle(yesterday);
		} catch (final BizException e) {
			Log4jUtil.error(e);
		}

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) {
			Log4jUtil.info("03 处理成功。");
		} else {
			Log4jUtil.info("04处理失败" + returnState.getReturnMsg());
		}
	}
}
