package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

/**
 * 
 * <P>登陆接口实体</P>
 * 
 * @author 汤兴友 xytang
 */
public class CreditLogin {
	private String infoType;	// 信息类型
	private String posTime;	// POS交易时间
	private String posID;	// POS本地流水号
	private String transTime; // 交易时间
	private String transDate; // 交易日期
	private String retCode;	// 返回码
	private String terminalID;	// 终端号
	private String merchantID;	// 商户号
	private String merchantName;	// 商户名称
	private String password;	// 商户登陆密码
	private String commentRes;	// 附加响应
	private String resParam;	// 下装参数
	private String payURL;	// 支付交易地址
	private String token;	// 交易验证码
	private String reserved;	// 保留域
	
	/**
	 * 获取信息类型的方法
	 * 
	 * @return
	 */
	public String getInfoType() {
		return infoType;
	}
	
	/**
	 * 设置信息类型的方法
	 * 
	 * @param infoType
	 */
	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}
	
	/**
	 * 获取POS交易时间的方法
	 * 
	 * @return
	 */
	public String getPosTime() {
		return posTime;
	}
	
	/**
	 * 设置POS交易时间的方法
	 * 
	 * @param posTime
	 */
	public void setPosTime(String posTime) {
		this.posTime = posTime;
	}
	
	/**
	 * 获取POS本地流水号的方法
	 * 
	 * @return
	 */
	public String getPosID() {
		return posID;
	}
	
	/**
	 * 设置POS本地流水号的方法
	 * 
	 * @param posID
	 */
	public void setPosID(String posID) {
		this.posID = posID;
	}
	
	/**
	 * 获取交易时间的方法
	 * 
	 * @return
	 */
	public String getTransTime() {
		return transTime;
	}
	
	/**
	 * 设置交易时间的方法
	 * 
	 * @param transTime
	 */
	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}
	
	/**
	 * 获取交易日期的方法
	 * 
	 * @return
	 */
	public String getTransDate() {
		return transDate;
	}
	
	/**
	 * 设置交易日期的方法
	 * 
	 * @return
	 */
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	
	/**
	 * 获取返回码的方法
	 * 
	 * @return
	 */
	public String getRetCode() {
		return retCode;
	}
	
	/**
	 * 设置返回码的方法
	 * 
	 * @return
	 */
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	
	/**
	 * 获取终端号的方法
	 * 
	 * @return
	 */
	public String getTerminalID() {
		return terminalID;
	}
	
	/**
	 * 设置终端号的方法
	 * 
	 * @param terminalID
	 */
	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}
	
	/**
	 * 获取商户号的方法
	 * 
	 * @return
	 */
	public String getMerchantID() {
		return merchantID;
	}
	
	/**
	 * 设置商户号的方法
	 * 
	 * @param terminalID
	 */
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}
	
	/**
	 * 获取商户名称的方法
	 * 
	 * @return
	 */
	public String getMerchantName() {
		return merchantName;
	}
	
	/**
	 * 设置商户名称的方法
	 * 
	 * @param merchantName
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	
	/**
	 * 获取商户登陆密码的方法
	 * 
	 * @return
	 */
	public String getPassword() {
		return password;
	}
	
	/**
	 * 设置商户登陆密码的方法
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * 获取附加响应的方法
	 * 
	 * @return
	 */
	public String getCommentRes() {
		return commentRes;
	}
	
	/**
	 * 设置附加响应的方法
	 * 
	 * @param commentRes
	 */
	public void setCommentRes(String commentRes) {
		this.commentRes = commentRes;
	}
	
	/**
	 * 获取下装参数的方法
	 * 
	 * @return
	 */
	public String getResParam() {
		return resParam;
	}
	
	/**
	 * 设置下装参数的方法
	 * 
	 * @param resParam
	 */
	public void setResParam(String resParam) {
		this.resParam = resParam;
	}
	
	/**
	 * 获取支付交易地址的方法
	 * 
	 * @return
	 */
	public String getPayURL() {
		return payURL;
	}
	
	/**
	 * 设置支付交易地址的方法
	 * 
	 * @return
	 */
	public void setPayURL(String payURL) {
		this.payURL = payURL;
	}
	
	/**
	 * 获取交易验证码的方法
	 * 
	 * @return
	 */
	public String getToken() {
		return token;
	}
	
	/**
	 * 设置交易验证码的方法
	 * 
	 * @return
	 */
	public void setToken(String token) {
		this.token = token;
	}
	
	/**
	 * 获取保留域的方法
	 * 
	 * @return
	 */
	public String getReserved() {
		return reserved;
	}
	
	/**
	 * 设置保留域的方法
	 * 
	 * @param reserved
	 */
	public void setReserved(String reserved) {
		this.reserved = reserved;
	}
}
