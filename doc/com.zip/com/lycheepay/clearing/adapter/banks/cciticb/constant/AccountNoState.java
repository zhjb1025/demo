/*******************************************************************************
 * Project Key : clearing
 * Create on 2013-10-29 上午10:26:36
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.cciticb.constant;


/**
 * 中信账户状态
 * 
 * @author 张凯锋
 */
public enum AccountNoState {
	// 如果输入账号：正常：01;部分冻结：02;全部冻结：03;挂失：04;暂禁：05;看管：06;如果输入卡号：正常：01;部分冻结：02;全部冻结：03;挂失：04;
	NO_FOUND("", "订单状态错误"), S1("01", "正常"), S2("02", "部分冻结"), S3("03", "全部冻结"), S4("04", "挂失"), S5("05", "暂禁"), S6(
			"06", "看管");
	private String code;
	private String desc;
	private AccountNoState(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public static AccountNoState getDescByKeyCode(String code) {
		for (final AccountNoState element : values()) {
			if (code.equals(element.getCode())) {
				return element;
			}
		}
		return NO_FOUND;
	}
	
}
