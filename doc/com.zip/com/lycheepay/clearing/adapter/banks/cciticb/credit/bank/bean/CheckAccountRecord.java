package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;


/**
 * 
 * <P>对帐接口中 交易记录明细实体</P>
 * 
 * @author 汤兴友
 */
public class CheckAccountRecord {
	private String merchantID; // 商户号
	private String terminalID; // 终端号
	private String batchNo; // 批次号
	private String transDate; // 交易日期
	private String transTime; // 交易时间
	private String panOrderId; // 主帐号(卡号)或订单号
	private String transAmt; // 交易金额
	private String currCode; // 货币代码
	private String systemRefCode; // 系统参考号
	private String posID; // POS流水号
	private String authorizeCode; // 交易授权码
	private String productCode; // 产品代码
	private String dividedMonths; // 分期期数
	private String refundFlg; // 退货标记
	private String checkFlg; // 核对标识
	private String filler; // 保留字段

	public String getMerchantID() {
		return merchantID;
	}

	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}

	public String getTerminalID() {
		return terminalID;
	}

	public void setTerminalID(String terminalID) {
		this.terminalID = terminalID;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getPanOrderId() {
		return panOrderId;
	}

	public void setPanOrderId(String panOrderId) {
		this.panOrderId = panOrderId;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

	public String getCurrCode() {
		return currCode;
	}

	public void setCurrCode(String currCode) {
		this.currCode = currCode;
	}

	public String getSystemRefCode() {
		return systemRefCode;
	}

	public void setSystemRefCode(String systemRefCode) {
		this.systemRefCode = systemRefCode;
	}

	public String getPosID() {
		return posID;
	}

	public void setPosID(String posID) {
		this.posID = posID;
	}

	public String getAuthorizeCode() {
		return authorizeCode;
	}

	public void setAuthorizeCode(String authorizeCode) {
		this.authorizeCode = authorizeCode;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getDividedMonths() {
		return dividedMonths;
	}

	public void setDividedMonths(String dividedMonths) {
		this.dividedMonths = dividedMonths;
	}

	public String getRefundFlg() {
		return refundFlg;
	}

	public void setRefundFlg(String refundFlg) {
		this.refundFlg = refundFlg;
	}

	public String getCheckFlg() {
		return checkFlg;
	}

	public void setCheckFlg(String checkFlg) {
		this.checkFlg = checkFlg;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
}
