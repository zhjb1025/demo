package com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean;

/**
 * 
 * @author 汤兴友 xytang
 */
public class MaintainSession {
	private String infoType; // 信息类型
	private String merchantID; // 商户号
	private String MerchantName; // 商户名称
	private String token; // 交易验证码
	private String retCode; // 返回码
	private String commentRes;	// 附加响应
	
	/**
	 * 获取信息类型的方法
	 * 
	 * @return
	 */
	public String getInfoType() {
		return infoType;
	}
	
	/**
	 * 设置信息类型的方法
	 * 
	 * @param infoType
	 */
	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}
	
	/**
	 * 获取商户号的方法
	 * 
	 * @return
	 */
	public String getMerchantID() {
		return merchantID;
	}
	
	/**
	 * 设置商户号的方法
	 * 
	 * @param merchantID
	 */
	public void setMerchantID(String merchantID) {
		this.merchantID = merchantID;
	}
	
	/**
	 * 获取商户名称的方法
	 * 
	 * @return
	 */
	public String getMerchantName() {
		return MerchantName;
	}
	
	/**
	 * 设置商户名称的方法
	 * 
	 * @param merchantName
	 */
	public void setMerchantName(String merchantName) {
		MerchantName = merchantName;
	}
	
	/**
	 * 获取交易验证码的方法
	 * 
	 * @return
	 */
	public String getToken() {
		return token;
	}
	
	/**
	 * 设置交易验证码的方法
	 * 
	 * @return
	 */
	public void setToken(String token) {
		this.token = token;
	}
	
	/**
	 * 获取返回码的方法
	 * 
	 * @return
	 */
	public String getRetCode() {
		return retCode;
	}
	
	/**
	 * 设置返回码的方法
	 * 
	 * @param retCode
	 */
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	
	/**
	 * 获取附加响应的方法
	 * 
	 * @return
	 */
	public String getCommentRes() {
		return commentRes;
	}
	
	/**
	 * 设置附加响应的方法
	 * 
	 * @param commentRes
	 */
	public void setCommentRes(String commentRes) {
		this.commentRes = commentRes;
	}
}
