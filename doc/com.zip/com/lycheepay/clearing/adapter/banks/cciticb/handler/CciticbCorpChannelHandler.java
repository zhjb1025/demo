package com.lycheepay.clearing.adapter.banks.cciticb.handler;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.cciticb.corp.CiticbCorpProcessCallback;
import com.lycheepay.clearing.adapter.banks.cciticb.corp.config.MessageConfig;
import com.lycheepay.clearing.adapter.banks.cciticb.corp.config.MessageConfig.MessageType;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.common.constant.ClearingTransType.ClearingTransTypeEnum;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.CCITICB_CORP_CHANNEL_SERVICE)
public class CciticbCorpChannelHandler extends CciticbCorpAbstractChannelHandler {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;

	@Override
	public ClearingResultDTO directPay(final PayOutDTO payOut) throws ClearingAdapterBizCheckedException {

		return processRealTransaction(payOut, new  CiticbCorpProcessCallback<PayOutDTO>(){
			@Override
			public Map<String, String> buildMessage(PayOutDTO k) {
				Map<String, String> message = new HashMap<String, String>();
				message.put("transactionDate", DateUtil.getCurrentDate());
				message.put("transactionTime", DateUtil.getCurrentTime());
				message.put("bankSendSn", sequenceManager.getCiticbCorpSN());
				message.put("payOrDeduct", MessageConfig.IS_PAY_FLAG);
				BankaccountBalance kftBankaccount = bankAccountBalanceService.getBankaccountBean(channelId);
				message.put("payerAccountNo", kftBankaccount.getAccountNo());
				message.put("payerName", kftBankaccount.getAccountName());
				message.put("payeeAccountNo", payOut.getBankCardNo());
				message.put("payeeName", payOut.getCardHolderName());
				message.put("transactionAmount", DecimalUtil.formatFenStringByYuan(payOut.getAmount()));
				message.put("memo", payOut.getOrderNote());
				return message;
			}

			@Override
			public ClearingTransTypeEnum getTransType() {
				return ClearingTransTypeEnum.REAL_TIME_PAY;
			}		
		});
	}
	
      @Override
    public ClearingResultDTO directDeduct(DeductDTO deduct) throws ClearingAdapterBizCheckedException {
    	  return processRealTransaction(deduct, new  CiticbCorpProcessCallback<DeductDTO>(){

  			@Override
  			public Map<String, String> buildMessage(DeductDTO deduct) {
  				Map<String, String> message = new HashMap<String, String>();
				message.put("transactionDate", DateUtil.getCurrentDate());
				message.put("transactionTime", DateUtil.getCurrentTime());
  				message.put("bankSendSn", sequenceManager.getCiticbCorpSN());
  				message.put("payOrDeduct", MessageConfig.IS_DEDUCT_FLAG);
  				BankaccountBalance kftBankaccount = bankAccountBalanceService.getBankaccountBean(channelId);
  				message.put("payerAccountNo", deduct.getBankCardNo());
  				message.put("payerName", deduct.getCardHolderName());
  				message.put("payeeAccountNo", kftBankaccount.getAccountNo());
  				message.put("payeeName", kftBankaccount.getAccountName());
				message.put("transactionAmount", DecimalUtil.formatFenStringByYuan(deduct.getAmount()));
  				message.put("memo", deduct.getOrderNote());
  				return message;
  			}

			@Override
			public ClearingTransTypeEnum getTransType() {
				return ClearingTransTypeEnum.REAL_TIME_DEDUCT;
			}			
  		});
    }

      
    @Override
    public ClearingResultDTO accountVerify(final BankCardVerifyDTO accountVerify) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CiticbCorp", "accountVerify");
    	return processQuery(accountVerify, new CiticbCorpProcessCallback<BankCardVerifyDTO>() {
			@Override
			public Map<String, String> buildMessage(BankCardVerifyDTO k) {
				Map<String, String> message = new HashMap<String, String>();
  				message.put("msgID", MessageType.VERIFY_ACCOUNT_REQUEST.toString());
				message.put("transactionDate", DateUtil.getCurrentDate());
				message.put("transactionTime", DateUtil.getCurrentTime());
  				message.put("bankSendSn", sequenceManager.getCiticbCorpSN());
				Log4jUtil.info("账户验证流水：{}", message.get("bankSendSn"));
  				message.put("accountNo", accountVerify.getBankCardNo());
  				message.put("accountName", accountVerify.getCardHolderName());
				if (StringUtils.isNotBlank(accountVerify.getCertificateType())) {
					String certType = channelCertTypeService.getCertType(channelId, accountVerify.getCertificateType());
					message.put("identifyType", certType);
				} else {
					message.put("identifyType", "");// 未知证件类型置空
				}
  				message.put("identifyNo", accountVerify.getCertificateNo());
  				return message;
			}			

			@Override
			public ClearingTransTypeEnum getTransType() {
				return ClearingTransTypeEnum.MSG_ACCOUNT_VERIFY;
			}    		
    	});    	
    }
    
      
    @Override
    public ClearingResultDTO querySingleRecord(final BillnoSn billnoSn)  {
		Log4jUtil.setLogClass("CiticbCorp", "direct");
    	ClearingResultDTO result = null;
    	try {
    		result = processQuery(billnoSn, new CiticbCorpProcessCallback<BillnoSn>() {
				@Override
				public Map<String, String> buildMessage(BillnoSn k) {
					Map<String, String> message = new HashMap<String, String>();
					message.put("msgID", MessageType.QUERY_REQUEST.toString());
					message.put("queryDate", DateUtil.getCurrentDate());
					message.put("queryTime", DateUtil.getCurrentTime());
					message.put("bankSendSn", sequenceManager.getCiticbCorpSN());
					Log4jUtil.info("查询流水：{}", message.get("bankSendSn"));
					// BankaccountBalance kftBankaccount =
					// bankAccountBalanceService.getBankaccountBean(channelId);
					// message.put("payerAccountNo", billnoSn.getOtheracctno());
					// message.put("payeeAccountNo", kftBankaccount.getAccountNo());
					message.put("transactionAmount", DecimalUtil.formatFenStringByYuan(billnoSn.getAmount()));
					message.put("oldBankSendSn", billnoSn.getBankSendSn());
					return message;
				}			

				@Override
				public ClearingTransTypeEnum getTransType() {
					return null;
				}    		
			});
		} catch (Exception e) {
			Log4jUtil.error("查询单笔交易信息失败！billnoSn="+billnoSn, e);
		}    	
    	return result;
    }        

}
