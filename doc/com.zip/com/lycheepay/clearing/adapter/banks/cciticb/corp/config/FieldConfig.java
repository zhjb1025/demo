package com.lycheepay.clearing.adapter.banks.cciticb.corp.config;

import static com.lycheepay.clearing.adapter.common.util.biz.StringUtil.fillNumberWithZeroOnLeft;
import static com.lycheepay.clearing.adapter.common.util.biz.StringUtil.fillStringWithSpaceOnRight;
import static com.lycheepay.clearing.adapter.common.util.biz.StringUtil.trimNumericString;

import org.apache.commons.lang.StringUtils;


public class FieldConfig {

	private String id;

	private String name;

	private FieldDataType type;

	private int length;

	private String defaultValue;

	private boolean required;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public FieldDataType getType() {
		return type;
	}

	public void setType(FieldDataType type) {
		this.type = type;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}
	
	public String toMsgString(String value) {
		return this.getType().toMsgString(this, value);
	}
	
	public String toFieldValue(String value) {
		return this.getType().toFieldValue(this, value);
	}


	@Override
	public String toString() {
		return "FieldConfig [id=" + id + ", name=" + name + ", type=" + type + ", length=" + length + ", defaultValue="
				+ defaultValue + ", required=" + required + "]";
	} 

	public enum FieldDataType {
		String {
			public String toMsgString(FieldConfig config, String value) {
				if (value == null)
					value = config.getDefaultValue();
					return fillStringWithSpaceOnRight(value.toString(), config.getLength());
			}

			public String toFieldValue(FieldConfig config, String fieldStr) {
					return fieldStr.trim();
			}

		},
		Money {
			public String toMsgString(FieldConfig config, String value) {						
				return fillNumberWithZeroOnLeft(value, config.getLength());
			}

			public String toFieldValue(FieldConfig config, String fieldStr) {
				if (StringUtils.isBlank(fieldStr.trim()))
					return null;

				if (!StringUtils.isNumeric(fieldStr)) {
					throw new IllegalStateException("Field " + config.getId() + " has wrong value: " + fieldStr);
				}				
				return trimNumericString(fieldStr);

			}
		};


		public abstract String toMsgString(FieldConfig config, String value);

		public abstract String toFieldValue(FieldConfig config, String msgStr);
		

	}

}
