package com.lycheepay.clearing.adapter.banks.cciticb.credit.kft.util;

import java.util.ArrayList;
import java.util.List;

import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccount;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CheckAccountRecord;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogin;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.CreditLogout;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPayment;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.DividedPaymentReversal;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Download;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.HirePurchaseReturn;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.MaintainSession;
import com.lycheepay.clearing.adapter.banks.cciticb.credit.bank.bean.Settlement;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;


/**
 * 中信信用卡实例化报文实体的类 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author 汤兴友
 * @version 1.0
 */
public class CiticUtil {
	
	/**
	 * 实例化登录报文实体的方法
	 * 
	 * @return
	 */
	public CreditLogin getCreitLogin(String terminalID, String merchantId, String password){
		
		CreditLogin creditLogin = new CreditLogin();
		creditLogin.setInfoType("0800"); // 信息类型
		creditLogin.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		creditLogin.setPosID(DateUtil.getCurrentTime()); // POS本地流水号
		creditLogin.setTransTime(""); // 交易时间
		creditLogin.setTransDate(""); // 交易日期
		creditLogin.setRetCode(""); // 返回码
		creditLogin.setTerminalID(terminalID); // 终端号
		creditLogin.setMerchantID(merchantId); // 商户号
		creditLogin.setMerchantName(""); // 商户名
		creditLogin.setPassword(password); // 登录密码
		creditLogin.setCommentRes(""); // 附加响应
		creditLogin.setResParam(""); // 下装参数
		creditLogin.setPayURL(""); // 支付交易地址
		creditLogin.setToken(""); // 交易验证码
		creditLogin.setReserved("");// 保留域
		
		return creditLogin;
	}
	
	/**
	 * 实例化登出报文实体的方法
	 * 
	 * @param param
	 * @param terminalID // 终端号
	 * @param merchantId // 商户号
	 * @return
	 */
	public CreditLogout getCreditLogout(String terminalID, String merchantId, String pwd){
		
		CreditLogout creditLogout = new CreditLogout();
		creditLogout.setInfoType("0800"); // 信息类型
		creditLogout.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		creditLogout.setPosID(DateUtil.getCurrentTime()); // POS本地流水号
		creditLogout.setTransTime(""); // 交易时间
		creditLogout.setTransDate(""); // 交易日期
		creditLogout.setRetCode(""); // 返回码
		creditLogout.setTerminalID(terminalID); // 终端号
		creditLogout.setMerchantID(merchantId); // 商户号
		creditLogout.setMerchantName(""); // 商户名
		creditLogout.setPassword(pwd); // 商户密码
		creditLogout.setCommentRes(""); // 附加响应
		creditLogout.setReserved(""); // 保留域
		
		return creditLogout;
	}
	
	/**
	 * 实例化分期支付的实体类的方法
	 * 
	 * @param param
	 * @param terminalID // 终端号
	 * @param merchantId // 商户号
	 * @param inputType // POS输入方式
	 * @param posCoditionCode // 服务点条件码
	 * @param debit_Pay_Real // 单笔代收付对象
	 * @return
	 */
	public DividedPayment getDividedPayment(Param param, DeductDTO debit_Pay_Real, CiticChannelParm p,
			String bankSendSn, String posID) {
		
		DividedPayment dividedPayment = new DividedPayment();
		
		dividedPayment.setInfoType("0200"); // 信息类型
		dividedPayment.setPan(debit_Pay_Real.getBankCardNo()); // 主帐号
		dividedPayment.setProcessCode("002000");// 处理代码
		dividedPayment.setTransAmt(append13(DecimalUtil.formatFenStringByYuan(debit_Pay_Real.getAmount()))); // 交易金额,
		dividedPayment.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		dividedPayment.setPosID(posID); // POS流水号
		dividedPayment.setOrderID(bankSendSn); // 订单号
		dividedPayment.setTransTime(""); // 交易时间
		dividedPayment.setTransDate(""); // 交易日期
		dividedPayment.setInputType(p.getInputType()); // POS输入方式
		dividedPayment.setCardSerialNo(""); // 卡片序列号
		dividedPayment.setPosConditionCode(p.getPosCoditionCode()); // 服务点条件码
		dividedPayment.setSecondTrack(""); // 二磁道内容
		dividedPayment.setThirdTrack(""); // 三磁道内容
		dividedPayment.setSystemRefCode(""); // 系统参考号
		dividedPayment.setAuthorizeCode(""); // 授权码
		dividedPayment.setRetCode(""); // 返回码
		dividedPayment.setTerminalID(p.getTerminalID()); // 终端号
		dividedPayment.setMerchantID(p.getMerchantId()); // 商户号
		dividedPayment.setMerchantName(""); // 商户名称
		dividedPayment.setCommentRes(""); // 附加响应
		dividedPayment.setCurrCode("156"); // 货币代码
		dividedPayment.setPasswdMac(""); // 个人密码密文
		dividedPayment.setSecurityInfo(""); // 安全控制信息
		dividedPayment.setIcDataField(""); // IC卡数据域
		dividedPayment.setTermAbilities(""); // 自定义域
		dividedPayment.setChIdNum(debit_Pay_Real.getCertificateNo()); // 持卡人证件号码
		dividedPayment.setChName(debit_Pay_Real.getCardHolderName()); // 持卡人姓名
		dividedPayment.setChMobile(""); // 持卡人手机号码
		dividedPayment.setCvv2(debit_Pay_Real.getCvv2()); // 卡背面末三位数字
		dividedPayment.setExpiredDate(debit_Pay_Real.getCreditCardEndDate()); // 卡有效期
		dividedPayment.setDynamicPwd(""); // 动态密码
		dividedPayment.setPersonalMsg(""); // 个人化信息
		dividedPayment.setBatchNo(p.getBatchId()); // 批次号
		dividedPayment.setDividedNum("00"); // 分期期数
		dividedPayment.setProductType("000000"); // 产品类型
		dividedPayment.setDividedFee(""); // 分期手续费
		dividedPayment.setTotalAmt(""); // 授权总金额
		dividedPayment.setDividedAmt(""); // 分期金额
		dividedPayment.setReserved1(""); // 保留域1
		dividedPayment.setReserved2(""); // 保留域2
		
		return dividedPayment;
	}
	
	/**
	 * 实例化分期支付冲正对象的方法
	 * 
	 * @param dividedPayment // 分期支付对象
	 * @return
	 */
	public DividedPaymentReversal getDividedPaymentReversal(DividedPayment dividedPayment){
		
		DividedPaymentReversal dividedPaymentReversal = new DividedPaymentReversal();
		
		dividedPaymentReversal.setInfoType("0420"); // 信息类型
		dividedPaymentReversal.setPan(dividedPayment.getPan()); // 主帐号
		dividedPaymentReversal.setOrderID(dividedPayment.getOrderID()); // 订单号
		dividedPaymentReversal.setProcessCode("002000");// 处理代码
		dividedPaymentReversal.setTransAmt(append13(dividedPayment.getTransAmt())); // 交易金额,
		dividedPaymentReversal.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		dividedPaymentReversal.setPosID(DateUtil.getCurrentTime()); // POS流水号
		dividedPaymentReversal.setTransTime(""); // 交易时间
		dividedPaymentReversal.setTransDate(""); // 交易日期
		dividedPaymentReversal.setInputType(dividedPayment.getInputType()); // POS输入方式
		dividedPaymentReversal.setCardSerialNo(""); // 卡片序列号
		dividedPaymentReversal.setPosConditionCode(dividedPayment.getPosConditionCode()); // 服务点条件码
		dividedPaymentReversal.setSecondTrack(""); // 二磁道内容
		dividedPaymentReversal.setThirdTrack(""); // 三磁道内容
		dividedPaymentReversal.setSystemRefCode(""); // 系统参考号
		dividedPaymentReversal.setAuthorizeCode(""); // 授权码
		dividedPaymentReversal.setOrgPosID(dividedPayment.getPosID()); // 原POS流水号
		dividedPaymentReversal.setRetCode(""); // 返回码
		dividedPaymentReversal.setTerminalID(dividedPayment.getTerminalID()); // 终端号
		dividedPaymentReversal.setMerchantID(dividedPayment.getMerchantID()); // 商户号
		dividedPaymentReversal.setMerchantName(""); // 商户名称
		dividedPaymentReversal.setCommentRes(""); // 附加响应
		dividedPaymentReversal.setCurrCode("156"); // 货币代码
		dividedPaymentReversal.setPasswdMac(""); // 个人密码密文
		dividedPaymentReversal.setSecurityInfo(""); // 安全控制信息
		dividedPaymentReversal.setIcDataField(""); // IC卡数据域
		dividedPaymentReversal.setTermAbilities(""); // 自定义域
		dividedPaymentReversal.setPersonalMsg(""); // 个人化信息
		dividedPaymentReversal.setChIdNum(""); // 持卡人证件号码
		dividedPaymentReversal.setChName(""); // 持卡人姓名
		dividedPaymentReversal.setChMobile(""); // 持卡人手机号码
		dividedPaymentReversal.setCvv2(""); // 卡背面末三位数字
		dividedPaymentReversal.setExpiredDate(""); // 卡有效期
		dividedPaymentReversal.setDynamicPwd(""); // 动态密码
		dividedPaymentReversal.setDividedNum("00"); // 分期期数
		dividedPaymentReversal.setProductType("000000"); // 产品类型
		dividedPaymentReversal.setBatchNo(dividedPayment.getBatchNo()); // 批次号
		dividedPaymentReversal.setReserved1(""); // 保留域1
		dividedPaymentReversal.setReserved2(""); // 保留域2
		
		return dividedPaymentReversal;
	}
	
	/**
	 * 实例化分期支付冲正对象的方法(实时)
	 * 
	 * @param dividedPayment // 分期支付对象
	 * @return
	 */
	public DividedPaymentReversal getDividedPaymentReversal2(AutoRealTimeRefund autoRealTimeRefund, BillnoSn billnoSn,
			CiticChannelParm p) {
		
		DividedPaymentReversal dpr = new DividedPaymentReversal();
		
		dpr.setInfoType("0420"); // 信息类型
		dpr.setPan(autoRealTimeRefund.getRevBankCardNo()); // 主帐号
		// dpr.setOrderID(sendSn);
		// 撤销交易时orderID值，应与原交易的orderID相同，（即bank_send_sn应该一样）
		dpr.setOrderID(billnoSn.getBankSendSn()); // 订单号
		dpr.setProcessCode("002000");// 处理代码
		dpr.setTransAmt(append13(autoRealTimeRefund.getRefundAmounFen())); // 交易金额,
		dpr.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		dpr.setPosID(DateUtil.getCurrentTime()); // POS流水号
		dpr.setTransTime(""); // 交易时间
		dpr.setTransDate(""); // 交易日期
		dpr.setInputType(p.getInputType()); // POS输入方式
		dpr.setCardSerialNo(""); // 卡片序列号
		dpr.setPosConditionCode(p.getPosCoditionCode()); // 服务点条件码
		dpr.setSecondTrack(""); // 二磁道内容
		dpr.setThirdTrack(""); // 三磁道内容
		dpr.setSystemRefCode(""); // 系统参考号
		
		String[] item = null;
		String field = billnoSn.getBankRecvSn();
		if (field!=null&&field.contains("#")) {
			item = field.split("#");
		}
		dpr.setOrgPosID(item[0]); // 原POS流水号
		dpr.setAuthorizeCode(item[1]); // 授权码
		
		dpr.setRetCode(""); // 返回码
		dpr.setTerminalID(p.getTerminalID()); // 终端号
		dpr.setMerchantID(p.getMerchantId()); // 商户号
		dpr.setMerchantName(""); // 商户名称
		dpr.setCommentRes(""); // 附加响应
		dpr.setCurrCode("156"); // 货币代码
		dpr.setPasswdMac(""); // 个人密码密文
		dpr.setSecurityInfo(""); // 安全控制信息
		dpr.setIcDataField(""); // IC卡数据域
		dpr.setTermAbilities(""); // 自定义域
		dpr.setPersonalMsg(""); // 个人化信息
		dpr.setChIdNum(""); // 持卡人证件号码
		dpr.setChName(""); // 持卡人姓名
		dpr.setChMobile(""); // 持卡人手机号码
		dpr.setCvv2(""); // 卡背面末三位数字
		dpr.setExpiredDate(""); // 卡有效期
		dpr.setDynamicPwd(""); // 动态密码
		dpr.setDividedNum("00"); // 分期期数
		dpr.setProductType("000000"); // 产品类型
		dpr.setBatchNo(billnoSn.getCreditbatchno()); // 批次号
		dpr.setReserved1(""); // 保留域1
		dpr.setReserved2(""); // 保留域2
		
		return dpr;
	}
	
	/**
	 * 实例化分期支付退款对象的方法
	 * 
	 * @param param
	 * @param channelRefund 退款流水对象
	 * @param billnoSn 渠道流水对象
	 * @param inputType POS输入方式
	 * @param posConditionCode 服务点条件码
	 * @param terminalID 终端号
	 * @param merchantID 商户号
	 * @param batchId 批次号
	 * @return
	 */
	public HirePurchaseReturn getHirePurchaseReturn(Param param, double refundAmount, BillnoSn billnoSn,
			String inputType, String posConditionCode, String terminalID, String merchantID, String batchId) {
		
		HirePurchaseReturn hirePurchaseReturn = new HirePurchaseReturn();
		
		hirePurchaseReturn.setInfoType("0200"); // 信息类型
		hirePurchaseReturn.setPan(billnoSn.getOtheracctno()); // 主帐号
		hirePurchaseReturn.setOrderID(billnoSn.getBankSendSn()); // 订单号
		hirePurchaseReturn.setProcessCode("002000"); // 处理代码
		hirePurchaseReturn.setOrgTransAmt(append13(billnoSn.getAmount().toString())); // 原交易金额
		hirePurchaseReturn.setTransAmt(append13(String.valueOf(refundAmount))); // 退货金额 TODO
		hirePurchaseReturn.setPosTime(DateUtil.getCurrentDateTime()); // 交易时间
		hirePurchaseReturn.setPosID(DateUtil.getCurrentTime()); // POS流水号
		hirePurchaseReturn.setTransTime(""); // 交易时间
		hirePurchaseReturn.setTransDate(""); // 交易日期
		hirePurchaseReturn.setInputType(inputType); // POS输入方式
		hirePurchaseReturn.setCardSerialNo(""); // 卡片序列号
		hirePurchaseReturn.setPosConditionCode(posConditionCode); // 服务点条件码
		hirePurchaseReturn.setSecondTrack(""); // 二磁道内容
		hirePurchaseReturn.setThirdTrack(""); // 三磁道内容
		hirePurchaseReturn.setSystemRefCode(""); // 系统参考号
		hirePurchaseReturn.setAuthorizeCode(billnoSn.getFeedesc()); // 授权码
		hirePurchaseReturn.setRetCode(""); // 返回码
		hirePurchaseReturn.setTerminalID(terminalID); // 终端号
		hirePurchaseReturn.setMerchantID(merchantID); // 商户号
		hirePurchaseReturn.setMerchantName(""); // 商户名称
		hirePurchaseReturn.setCommentRes(""); // 附加响应
		hirePurchaseReturn.setCurrCode("156"); // 货币代码
		hirePurchaseReturn.setOrgPosID(billnoSn.getBankRecvSn()); // 原交易记录POS流水号
		hirePurchaseReturn.setOrgBatchNo(billnoSn.getCreditbatchno()); // 原交易记录的批次号
		hirePurchaseReturn.setPasswdMac(""); // 个人密码密文
		hirePurchaseReturn.setSecurityInfo(""); // 安全控制信息
		hirePurchaseReturn.setIcDataField(""); // IC卡数据域
		hirePurchaseReturn.setTermAbilities(""); // 自定义域
		hirePurchaseReturn.setPersonalMsg(""); // 个人化信息
		hirePurchaseReturn.setChIdNum(""); // 持卡人证件号码
		hirePurchaseReturn.setChName(""); // 持卡人姓名
		hirePurchaseReturn.setChMobile(""); // 持卡人手机
		hirePurchaseReturn.setCvv2(""); // 卡背面末三位数字
		hirePurchaseReturn.setExpiredDate(""); // 卡有效期
		hirePurchaseReturn.setDynamicPwd(""); // 动态密码
		hirePurchaseReturn.setDividedNum("00"); // 分期期数
		hirePurchaseReturn.setProductType("000000"); // 产品类型
		hirePurchaseReturn.setBatchNo(batchId); // 批次号
		hirePurchaseReturn.setReserved1(""); // 保留域1
		hirePurchaseReturn.setReserved2(""); // 保留域2
		
		return hirePurchaseReturn;
	}
	
	/**
	 * 实例化分期支付退款对象的方法（实时）
	 * 
	 * @param param
	 * @param channelRefund 退款流水对象
	 * @param billnoSn 渠道流水对象
	 * @param inputType POS输入方式
	 * @param posConditionCode 服务点条件码
	 * @param terminalID 终端号
	 * @param merchantID 商户号
	 * @param batchId 批次号
	 * @return
	 */
	public HirePurchaseReturn getHirePurchaseReturn2(AutoRealTimeRefund autoRealTimeRefund, BillnoSn billnoSn,
			CiticChannelParm p) {
		
		HirePurchaseReturn hirePurchaseReturn = new HirePurchaseReturn();
		
		hirePurchaseReturn.setInfoType("0200"); // 信息类型
		hirePurchaseReturn.setPan(billnoSn.getOtheracctno()); // 主帐号
		hirePurchaseReturn.setOrderID(billnoSn.getBankSendSn()); // 订单号
		hirePurchaseReturn.setProcessCode("002000"); // 处理代码
		hirePurchaseReturn.setOrgTransAmt(append13(autoRealTimeRefund.getOrgAmounFen())); // 原交易金额
		hirePurchaseReturn.setTransAmt(append13(autoRealTimeRefund.getRefundAmounFen())); // 退货金额
		hirePurchaseReturn.setPosTime(DateUtil.getCurrentDateTime()); // 交易时间
		hirePurchaseReturn.setPosID(DateUtil.getCurrentTime()); // POS流水号
		hirePurchaseReturn.setTransTime(""); // 交易时间
		hirePurchaseReturn.setTransDate(""); // 交易日期
		hirePurchaseReturn.setInputType(p.getInputType()); // POS输入方式
		hirePurchaseReturn.setCardSerialNo(""); // 卡片序列号
		hirePurchaseReturn.setPosConditionCode(p.getPosCoditionCode()); // 服务点条件码
		hirePurchaseReturn.setSecondTrack(""); // 二磁道内容
		hirePurchaseReturn.setThirdTrack(""); // 三磁道内容
		hirePurchaseReturn.setSystemRefCode(""); // 系统参考号
		
		String[] item = null;
		String field = billnoSn.getBankRecvSn();
		if (field!=null&&field.contains("#")) {
			item = field.split("#");
		}
		
		hirePurchaseReturn.setAuthorizeCode(item[1]); // 授权码
		hirePurchaseReturn.setRetCode(""); // 返回码
		hirePurchaseReturn.setTerminalID(p.getTerminalID()); // 终端号
		hirePurchaseReturn.setMerchantID(p.getMerchantId()); // 商户号
		hirePurchaseReturn.setMerchantName(""); // 商户名称
		hirePurchaseReturn.setCommentRes(""); // 附加响应
		hirePurchaseReturn.setCurrCode("156"); // 货币代码
		hirePurchaseReturn.setOrgPosID(item[0]); // 原交易记录POS流水号
		hirePurchaseReturn.setOrgBatchNo(billnoSn.getCreditbatchno()); // 原交易记录的批次号
		hirePurchaseReturn.setPasswdMac(""); // 个人密码密文
		hirePurchaseReturn.setSecurityInfo(""); // 安全控制信息
		hirePurchaseReturn.setIcDataField(""); // IC卡数据域
		hirePurchaseReturn.setTermAbilities(""); // 自定义域
		hirePurchaseReturn.setPersonalMsg(""); // 个人化信息
		hirePurchaseReturn.setChIdNum(""); // 持卡人证件号码
		hirePurchaseReturn.setChName(""); // 持卡人姓名
		hirePurchaseReturn.setChMobile(""); // 持卡人手机
		hirePurchaseReturn.setCvv2(""); // 卡背面末三位数字
		hirePurchaseReturn.setExpiredDate(""); // 卡有效期
		hirePurchaseReturn.setDynamicPwd(""); // 动态密码
		hirePurchaseReturn.setDividedNum("00"); // 分期期数
		hirePurchaseReturn.setProductType("000000"); // 产品类型
		hirePurchaseReturn.setBatchNo(p.getBatchId()); // 批次号
		hirePurchaseReturn.setReserved1(""); // 保留域1
		hirePurchaseReturn.setReserved2(""); // 保留域2
		
		return hirePurchaseReturn;
	}
	
	/**
	 * 实例化维护连接对象的方法
	 * 
	 * @param param
	 * @return
	 */
	public MaintainSession getMaintainSession(Param param, String merchantId, String token){
		
		MaintainSession maintainSession = new MaintainSession();
		
		maintainSession.setInfoType("0200"); // 信息类型
		maintainSession.setMerchantID(merchantId); // 商户号
		maintainSession.setMerchantName(""); // 商户名称
		maintainSession.setToken(token); // 交易验证码
		maintainSession.setRetCode(""); // 返回码
		maintainSession.setCommentRes(""); // 附加响应
		
		return maintainSession;
	}
	
	/**
	 * 实例化结算接口报文对象的方法
	 * 
	 * @param param
	 * @param terminalID 终端号
	 * @param merchantID 商户号
	 * @param batchId 批次号
	 * @return
	 */
	public Settlement getSettlement(String terminalID, String merchantID, String batchId, String totalTrsCnt, String traSumAmt){
		
		Settlement settlement = new Settlement();
		
		settlement.setInfoType("0200"); // 信息类型
		settlement.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		settlement.setPosID(DateUtil.getCurrentTime()); // POS本地流水号
		settlement.setTransTime(""); // 交易时间
		settlement.setTransDate(""); // 交易日期
		settlement.setRetCode(""); // 返回码
		settlement.setTerminalID(terminalID); // 终端号
		settlement.setMerchantID(merchantID); // 客户号
		settlement.setMerchantName(""); // 客户名称
		settlement.setBatchNo(batchId); // 批次号
		settlement.setTotalTrsCnt(totalTrsCnt); // 交易总记录数
		settlement.setSign("+"); // 金额符号表示
		settlement.setTraSumAmt(append13(traSumAmt)); // 交易总金额
		settlement.setSuccessFlag(""); // 成功标志
		settlement.setCommentRes(""); // 附加响应
		settlement.setReserved(""); // 保留域
		
		return settlement;
	}
	
	
	/**
	 * 
	 * @param bizList
	 * @return
	 */
	public CheckAccount createCheckAccount(List<BillnoSn> bizList,String batchId,CiticChannelParm cp,String terminalFlag) {
		CheckAccount ca = new CheckAccount();
		
		ca.setInfoType("0200"); // 信息类型
		ca.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		ca.setPosID(DateUtil.getCurrentTime()); // POS本地流水号
		ca.setTransTime(""); // 交易时间
		ca.setTransDate(""); // 交易日期
		ca.setRetCode(""); // 返回码
		ca.setTerminalID(cp.getTerminalID()); // 终端号
		ca.setMerchantID(cp.getMerchantId()); // 客户号
		ca.setMerchantName(""); // 客户名称
		ca.setBatchNo(batchId); // 批次号
		
		ca.setTerminalFlag(terminalFlag); // 对帐终止符号
		ca.setCommentRes(""); // 附加响应
		ca.setReserved(""); // 保留域
		
		//dataSet
		List<CheckAccountRecord> records = new ArrayList<CheckAccountRecord>(); // 明细交易记录
		CheckAccountRecord rc = null;
		
		String[] item = null;
		for (BillnoSn bs : bizList) {
			rc = new CheckAccountRecord();
			rc.setMerchantID(cp.getMerchantId()); // 商户号 15A
			rc.setTerminalID(cp.getTerminalID()); // 终端号 8A
			rc.setBatchNo(batchId); // 批次号 6A
			rc.setTransDate(""); // 交易日期 8A
			rc.setTransTime(""); // 交易时间 8A
			rc.setPanOrderId(bs.getBankSendSn()); // 主帐号(卡号)或订单号19A
			rc.setTransAmt(append13(String.format("%1$.0f", bs.getAmount().doubleValue() * 100))); // 交易金额
																									// 13A
			rc.setCurrCode("156"); // 货币代码 3A
			
			String field = bs.getBankRecvSn();
			if (field!=null&&field.contains("#")) {
				item = field.split("#");
			}
			
			rc.setSystemRefCode(""); // 系统参考号 12A
			rc.setPosID(item[0]); // POS流水号 6A
			rc.setAuthorizeCode(item[1]); // 交易授权码 6A
			rc.setProductCode("000000"); // 产品代码 6A
			rc.setDividedMonths("00"); // 分期期数 2A
			
			if(bs.getTranType().equals("8025")){
				rc.setRefundFlg("Y"); // 退货标记 1A
			}else{
				rc.setRefundFlg(""); // 退货标记 1A
			}
			
			rc.setCheckFlg(""); // 核对标识 1A
			rc.setFiller(""); // 保留字段 36A
			
			records.add(rc);
		}
		
		ca.setRecords(records);
		
		return ca;
	}
	
	/**
	 * 实例化流水文件下载接口对象的方法
	 * 
	 * @param terminalID 终端号
	 * @param merchantID 商户号
	 * @param checkDate 日期
	 * @return
	 */
	public Download getDownload(String terminalID, String merchantID, String checkDate){
		
		Download download = new Download();
		
		download.setInfoType("0200"); // 信息类型
		download.setPosTime(DateUtil.getCurrentDateTime()); // POS交易时间
		download.setPosID(DateUtil.getCurrentTime()); // POS交易时间
		download.setRetCode(""); // 返回码
		download.setTerminalID(terminalID); // 终端号
		download.setMerchantID(merchantID); // 商户号
		download.setFileType("A"); // 文件类型
		download.setDataSet(""); // 数据结果集
		download.setDate(checkDate); // 获取某一天的流水文件
		download.setCommentRes(""); // 附加响应
		download.setReserved(""); // 保留域
		
		return download;
	}
	
	/**
	 * 判断字符串是否有13位，如果没有就加到13位
	 * 
	 * @param str
	 * @return
	 */
	private String append13(String str){
		
		int range = 13 - str.length();
		
		if(range > 0){
			StringBuffer sb = new StringBuffer(str);
			for(int i = 0; i < range; i++){
				sb.insert(0, "0");
			}
			
			return sb.toString();
		}
		
		return str;
	}
}
