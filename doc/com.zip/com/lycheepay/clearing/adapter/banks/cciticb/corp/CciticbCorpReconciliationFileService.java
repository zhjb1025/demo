package com.lycheepay.clearing.adapter.banks.cciticb.corp;

/*******************************************************************************
 * Project Key : ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.constant.biz.SysparmConst;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ClearParamsService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中信银行银企对账文件服务类</P>
 * 
 * @author
 */
@Service(ClearingAdapterAnnotationName.CCITICB_CORP_RECONCILIATION_FILE_SERVICE)
public class CciticbCorpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	@Autowired
	private ClearParamsService sysParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	protected String channelId = ChannelIdEnum.CNCB_CORP.getCode();

	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CiticbCorp", "check");
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId) + " ";
		Log4jUtil.info("进入" + logPrefix + "对账处理。传进文件保存路径参数为:[" + fileSavePath + "],渠道ID为:[" + channelId + "]对账日期为:["
				+ settleDate + "]");

		AssertUtils.notNull(channelId, TransReturnCode.code_9108, "渠道ID");
		AssertUtils.notNull(fileSavePath, TransReturnCode.code_9108, "对账文件保存路径");
		final String reconciliationDate = ReconciliationFileUtil.checkSettleDate(settleDate, logPrefix);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + reconciliationDate);

		final Map<String, String> channelParam = channelParamService.queryNameParamsMapByChannelId(channelId);

		final String fileName = "KFT_DZ_" + reconciliationDate + ".txt";
		final String accPath = sysParmService.getParmValue(SysparmConst.CHANNEL_RECON_FILE_DIR) + "accPath" + channelId
				+ File.separator;
		File file = new File(accPath);
		if (!file.exists())
			file.mkdirs();
		final FtpManager fm = new FtpManager();
		fm.setServer(channelParam.get("ftpServer"));
		fm.setPassword(channelParam.get("ftpPassword"));
		fm.setUser(channelParam.get("ftpUser"));
		fm.setFilename(fileName);
		fm.setLocalPath(accPath); // 下载到本地的文件夹
		fm.setPath(channelParam.get("ftpDirPath")); // 远程目录，就是FTP用户的默认目录
		fm.getMyFile_actionPerformed("bin");
		final String fileFullPathName = accPath + fileName;

		Log4jUtil.info(logPrefix + "FTP下载对账文件成功，保存路径为：" + fileFullPathName);

		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix,
				fileFullPathName, channelId, reconciliationDate);

		Log4jUtil.info(logPrefix + "生成统一格式对账文件");

		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				reconciliationDate, reconciliationFileDTOList);
		return fileFullPath;
	}

	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String fileFullPathName,
			final String channelId, final String reconciliationDate) {

		File file = new File(fileFullPathName);
		if (!file.exists() || file.length() == 0) {
			Log4jUtil.error("文件{}为空或不存在", fileFullPathName);
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.DOCUMENT_EXCEPTION, "渠道未获取到银行对账文件，请稍后再试");
		}

		BankaccountBalance kftBankaccount = bankAccountBalanceService.getBankaccountBean(channelId);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();

		// 循环对文本逐行处理
		String data = null;

		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(
				fileFullPathName), "gbk"));) {
			String summaryLine = bufferedReader.readLine();
			if (summaryLine == null || summaryLine.split("\\|").length != 2) {
				Log4jUtil.error("对账失败,文件{}首行格式错误", fileFullPathName);
				throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix + "对账失败,文件"
						+ fileFullPathName + "首行格式错误");
			}
			String[] summaryItems = summaryLine.split("\\|");
			long successCount = Long.parseLong(summaryItems[0]);
			BigDecimal successAmount = new BigDecimal(summaryItems[1]);
			while ((data = bufferedReader.readLine()) != null) {
				ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
				if (0 < data.trim().length()) {
					final String[] currentLineData = data.split("\\|", -1);

					if (currentLineData.length == 6) {
						// 发起方日期|发起方流水号|付款账号|收款账号|交易金额|中信平台流水号
						final String tradeDate = currentLineData[0].trim();// 交易时间
						final String bankSendSn = currentLineData[1].trim();// 发起方流水号
						final String amtTrade = currentLineData[4].trim();// 交易金额 分为单位
						final String bankRecvSn = currentLineData[5].trim();// 银行返回流水
						final BigDecimal transAmount = new BigDecimal(amtTrade);
						successAmount = successAmount.subtract(transAmount);
						reconciliationFileDTO.setBankTransState("00");
						reconciliationFileDTO.setCheckDate(reconciliationDate);
						reconciliationFileDTO.setBankSendId(bankSendSn); // 订单号
						reconciliationFileDTO.setTransDate(tradeDate); // 交易日期
						reconciliationFileDTO.setAmount(transAmount.divide(new BigDecimal("100")));// 交易金额
						reconciliationFileDTO
								.setPayGet(kftBankaccount.getAccountNo().equals(currentLineData[3].trim()) ? STR_GET
										: STR_PAY);
						reconciliationFileDTO.setChannelId(channelId);
						reconciliationFileDTO.setBankRecvSN(bankRecvSn);
						reconciliationFileDTOList.add(reconciliationFileDTO);
					} else {
						// 行数据格式错误
						Log4jUtil.error(logPrefix + "该行元素格式错误，不是合法的交易数据。行数据为：" + data);
						throw new ClearingAdapterAppUncheckedException(ExceptionCode.DOCUMENT_EXCEPTION, logPrefix
								+ "该行元素格式错误，不是合法的交易数据。行数据为：" + data);
					}
				}
				successCount--;
			}
			if (successCount != 0 || !successAmount.equals(BigDecimal.ZERO)) {
				throw new ClearingAdapterAppUncheckedException(ExceptionCode.DOCUMENT_EXCEPTION, logPrefix
						+ "对账失败,文件:[" + fileFullPathName + "] 总计笔数与金额核对错误！总计笔数为：" + summaryItems[0] + ",实际为："
						+ (summaryItems[0] + successCount) + "总计金额为：" + summaryItems[1] + ",实际为："
						+ successAmount.add(new BigDecimal(summaryItems[1])));
			}
			if (bufferedReader != null)
				bufferedReader.close();
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix + "对账失败,文件:["
					+ fileFullPathName + "]" + e);
		}
		return reconciliationFileDTOList;
	}

	/**
	  * 
	  */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix,
				targetFilePath, channelId, queryDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

}
