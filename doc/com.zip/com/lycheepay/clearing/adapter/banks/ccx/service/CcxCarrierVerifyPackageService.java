/*****************************************************************************************
 * Project Key : clearing-adapter
 * Create on 2017年10月26日 上午10:28:23
 * Copyright (c) 2008 - 2017.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ****************************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccx.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccx.constants.CcxConstants;
import com.lycheepay.clearing.adapter.banks.ccx.utils.Md5;
import com.lycheepay.clearing.common.dto.trade.CarrierInfoVerifyDTO;

/**
 * 
 * 中诚信请求打包
 * @author wwm
 * @since
 */
@Service
public class CcxCarrierVerifyPackageService {

	/**
	 * <p>打包运营商验证请求报文</p>
	 * @param carrierInfoVerifyDTO
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	public String packageCarrierVerifyParam(CarrierInfoVerifyDTO carrierInfoVerifyDTO, Map<String, String> channelParms, String bankSendSn) throws UnsupportedEncodingException {
		Map<String, Object> requestMap = new LinkedHashMap<String, Object>();
		
		requestMap.put("account", channelParms.get(CcxConstants.ACCOUNT));
		requestMap.put("name", carrierInfoVerifyDTO.getName());
		requestMap.put("cid", carrierInfoVerifyDTO.getCertificateNo());
		requestMap.put("mobile", carrierInfoVerifyDTO.getPhoneNumber());
		requestMap.put("reqId", bankSendSn);

		//封装签名
		requestMap.put("sign", makeSign(requestMap, channelParms.get(CcxConstants.PRIVATE_KEY)));
		
		StringBuffer sb = new StringBuffer();
		for(String key : requestMap.keySet()) {
			sb.append(key+"="+URLEncoder.encode(requestMap.get(key).toString(), "UTF-8"));
			sb.append("&");
		}
		sb.deleteCharAt(sb.length() - 1);
		
		return sb.toString();
	}
	
	/**
	 * 
	 * <p>生成签名</p>
	 * @param requestMap
	 * @param privateKey
	 * @return
	 */
	public String makeSign(Map<String, Object> requestMap, String privateKey) {
		
		List<String> signString = new ArrayList<>();
		
		for(String key : requestMap.keySet()) {
			signString.add(key + requestMap.get(key));
		}
		
		//字母排序
		Collections.sort(signString);
		
		/*
		 * 遍历生成字符串
		 */
		StringBuffer sb = new StringBuffer();
		for (String value : signString) {
			sb.append(value);
		}
		//加入私钥
		sb.append(privateKey);
		
		//MD5 加密
		return Md5.md5(sb.toString());
		
	}
	
	

}
