/*****************************************************************************************
 * Project Key : clearing-adapter
 * Create on 2017年10月26日 上午9:57:39
 * Copyright (c) 2008 - 2017.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ****************************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccx.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccx.constants.CcxConstants;
import com.lycheepay.clearing.adapter.banks.ccx.utils.HttpClient;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.CarrierInfoVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 
 * 中诚信 运营商服务类
 * @author wwm
 * @since
 */
@Service
public class CcxCarrierVerifyProcessService {

	@Autowired
	private CcxCarrierVerifyPackageService ccxCarrierVerifyPackageService;
	
	@Autowired
	private CcxCarrierVerifyResultProcessService ccxCarrierVerifyResultProcessService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;
	
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.CARD_VERIFY_SN_SERVICE)
//	private CardVerifySnService cardVerifySnService;
	
	
	/**
	 * <p>运营商验证</p>
	 * @param carrierInfoVerifyDTO
	 * @param channelid
	 * @return
	 * @throws BizException 
	 */
	public ClearingResultDTO carrierInfoVerify(CarrierInfoVerifyDTO carrierInfoVerifyDTO, String channelid) throws BizException {

		String bankSendSn = sequenceManagerService.getCcxSeq();
		
		Map<String, String> channelParms = channelParamService.queryCodeParamsMapByChannelId(channelid);
		
		//打包请求参数
		String param = "";
		try{
			param = ccxCarrierVerifyPackageService.packageCarrierVerifyParam(carrierInfoVerifyDTO, channelParms, bankSendSn);
		}catch(Exception e){
			throw new BizException(TransReturnCode.code_9108, "组装运营商验证请求参数异常");
		}
		

		Log4jUtil.info("Http请求参数json【{}】", param);
		
		HttpClient client = new HttpClient(channelParms.get(CcxConstants.URL) + "/data-service/telecom/identity/3mo/t1" + "?" + param, 30000, 60000);
		
		//发送请求
		String result = client.sendGet("UTF-8");

		//处理结果
		return ccxCarrierVerifyResultProcessService.processResultCode(result);
		
	}

}
