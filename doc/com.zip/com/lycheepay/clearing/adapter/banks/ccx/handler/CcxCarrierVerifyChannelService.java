/*****************************************************************************************
 * Project Key : clearing-adapter
 * Create on 2017年4月5日 上午10:34:13
 * Copyright (c) 2008 - 2017.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ****************************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccx.handler;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ccx.service.CcxCarrierVerifyProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.CarrierInfoVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 中诚信 运营商身份验证 入口类
 * @author wwm
 * @since 2017年4月5日 上午10:34:13
 */
@Service(ClearingAdapterAnnotationName.CCX_CARRIER_VERIFY_CHANNEL_SERVICE)
public class CcxCarrierVerifyChannelService extends AbstractChannelService {
	
	@Autowired
	private CcxCarrierVerifyProcessService ccxCarrierVerifyProcessService;
	
	public final static String channelId = ChannelIdEnum.CCX_CARRIER.getCode();

	
	/** 
	 * 运营商身份验证
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#carrierInfoVerify(com.lycheepay.clearing.common.dto.trade.CarrierInfoVerifyDTO)
	 */
	@Override
	public ClearingResultDTO carrierInfoVerify(CarrierInfoVerifyDTO carrierInfoVerifyDTO) {
		Log4jUtil.setLogClass("CCXCARRIER", "carrierInfoVerify");
		Log4jUtil.info(carrierInfoVerifyDTO);
		ClearingResultDTO dto = null;
		try {

			/*
			 * 验证所需要的字段内容
			 */
			AssertUtils.notEmpty(carrierInfoVerifyDTO.getName(), TransReturnCode.code_9108, "姓名不能为空");
			AssertUtils.notEmpty(carrierInfoVerifyDTO.getPhoneNumber(), TransReturnCode.code_9108, "手机号不能为空");
			AssertUtils.notEmpty(carrierInfoVerifyDTO.getCertificateNo(), TransReturnCode.code_9108, "证件号码不能为空");
			
			dto = ccxCarrierVerifyProcessService.carrierInfoVerify(carrierInfoVerifyDTO, channelId);

			dto.setChannelId(channelId);
			dto.setClearingTransType(ClearingTransType.CARRIER_INFO_VERIFY);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}
	
}
