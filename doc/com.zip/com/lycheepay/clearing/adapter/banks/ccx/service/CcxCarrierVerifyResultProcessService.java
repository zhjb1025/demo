/*****************************************************************************************
 * Project Key : clearing-adapter
 * Create on 2017年10月26日 上午10:05:08
 * Copyright (c) 2008 - 2017.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ****************************************************************************************/
package com.lycheepay.clearing.adapter.banks.ccx.service;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;

/**
 * 
 * @author wwm
 * @since
 */
@Service
public class CcxCarrierVerifyResultProcessService {

	/**
	 * <p>中诚信-运营商验证</p>
	 * @param result 银行返回结果
	 * @return
	 */
	public ClearingResultDTO processResultCode(String result) {
		ClearingResultDTO dto = new ClearingResultDTO();
		JSONObject json = JSON.parseObject(result);
		if("2060".equals(json.getString("resCode"))) {
			dto.setChannelResponseCode(TransReturnCode.code_0000);
			dto.setTxnStatus(PayState.SUCCEED_STR);
		} else {
			dto.setChannelResponseCode(TransReturnCode.code_9900);
			dto.setTxnStatus(PayState.FAILED_STR);
		}

		dto.setChannelResponseMsg(json.getString("resMsg"));
		return dto;
	}

}
