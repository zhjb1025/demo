package com.lycheepay.clearing.adapter.banks.bosc.model;

/**
 * @author 罗帅
 * @since 2017/12/3 14:01.
 */
public class BoscDeductResDTO extends BoscCommonDTO{


}
