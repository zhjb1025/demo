package com.lycheepay.clearing.adapter.banks.bosc.utils;


import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import sun.security.pkcs.ContentInfo;
import sun.security.pkcs.PKCS7;
import sun.security.pkcs.SignerInfo;
import sun.security.util.DerValue;
import sun.security.x509.AlgorithmId;
import sun.security.x509.X500Name;

/**
 * @author 罗帅
 * @since 2017/11/29 20:56.
 */
public class SvsSign extends SvsBase {

    private PrivateKey privKey;

    public void initSignCertAndKey(String pfxFileName, String passwd)
            throws Exception
    {
        if ((passwd == null) || (passwd.length() <= 0)) {
            throw new SvsException("Password cannot be empty");
        }
        KeyStore ks = KeyStore.getInstance("PKCS12");
        FileInputStream fin = new FileInputStream(pfxFileName);
        ks.load(fin, passwd.toCharArray());

        Enumeration aliases = ks.aliases();
        String alias = (String)aliases.nextElement();
        boolean bRet = ks.isKeyEntry(alias);
        if (!bRet) {
            throw new SvsException("No key is found in pfx file");
        }
        this.privKey = ((PrivateKey)ks.getKey(alias, passwd.toCharArray()));
        this.signCert = ((X509Certificate)ks.getCertificate(alias));
    }

    public String signData(byte[] originData, int offset, int len)
            throws Exception
    {
        Signature sign = Signature.getInstance(this.digestAlg + "with" + this.cryptAlg);
        sign.initSign(this.privKey);
        sign.update(originData, offset, len);
        return SvsBase.base64Encode(sign.sign());
    }

    public String signData(byte[] originData)
            throws Exception
    {
        return signData(originData, 0, originData.length);
    }

    public String signFile(String fileName)
            throws Exception
    {
        byte[] digestData = SvsBase.digestFile(fileName, this.digestAlg);
        return signData(digestData, 0, digestData.length);
    }

    public String pkcs7SignData(byte[] originData)
            throws Exception
    {
        Signature sign = Signature.getInstance(this.digestAlg + "with" + this.cryptAlg);
        sign.initSign(this.privKey);
        sign.update(originData);
        return SvsBase.base64Encode(creatPkcs7(originData, sign.sign()));
    }

    public String pkcs7DetachSignData(byte[] originData)
            throws Exception
    {
        Signature sign = Signature.getInstance(this.digestAlg + "with" + this.cryptAlg);
        sign.initSign(this.privKey);
        sign.update(originData);
        return SvsBase.base64Encode(creatPkcs7(null, sign.sign()));
    }

    public String pkcs7SignFile(String fileName)
            throws Exception
    {
        byte[] digestData = SvsBase.digestFile(fileName, this.digestAlg);
        Signature sign = Signature.getInstance(this.digestAlg + "with" + this.cryptAlg);
        sign.initSign(this.privKey);
        sign.update(digestData);
        return SvsBase.base64Encode(creatPkcs7(digestData, sign.sign()));
    }

    public static String sign(byte[] originData, String pfxFileName, String passwd)
            throws Exception
    {
        SvsSign sign = new SvsSign();
        sign.initSignCertAndKey(pfxFileName, passwd);
        return sign.signData(originData);
    }

    protected byte[] creatPkcs7(byte[] originData, byte[] signedData)
            throws Exception
    {
        AlgorithmId[] digestAlgorithmIds = {
                AlgorithmId.getAlgorithmId(this.digestAlg) };

        ContentInfo contentInfo = null;
        if (originData == null) {
            contentInfo =
                    new ContentInfo(ContentInfo.DATA_OID, null);
        } else {
            contentInfo =
                    new ContentInfo(ContentInfo.DATA_OID, new DerValue((byte)4, originData));
        }
        X509Certificate[] certificates = { this.signCert };

        SignerInfo si = new SignerInfo(
                (X500Name)this.signCert.getIssuerDN(),
                this.signCert.getSerialNumber(),
                AlgorithmId.getAlgorithmId(this.digestAlg),
                null,
                new AlgorithmId(AlgorithmId.RSAEncryption_oid),
                signedData,
                null);

        SignerInfo[] signerInfos = { si };

        PKCS7 p7 = new PKCS7(
                digestAlgorithmIds,
                contentInfo,
                certificates,
                signerInfos);

        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        p7.encodeSignedData(bout);

        return bout.toByteArray();
    }
}
