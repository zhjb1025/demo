package com.lycheepay.clearing.adapter.banks.bosc.service;

import com.lycheepay.clearing.adapter.banks.bosc.constants.BoscConsts;
import com.lycheepay.clearing.adapter.banks.bosc.model.BoscDeductResDTO;
import com.lycheepay.clearing.adapter.banks.bosc.model.BoscPaymentQueryResDTO;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.biz.ClearingResult;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;
import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;


/**
 * @author 罗帅
 * @since 2017/11/28 10:25.
 */
@Service(ClearingAdapterAnnotationName.BOSC_CHANNEL_PROCESS_SERVICE)
public class BoscChannelProcessService extends BaseWithoutAuditLogService {

    /**
     * 上海银行银企直连channelId
     */
    static final String channelId = ChannelId.ChannelIdEnum.BOSC_CORP.getCode();
    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
    private BillnoSnService billnoSnService;

    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
    private SequenceManager seqService;

    @Autowired
    private BoscCorpPackageService packageService;

    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
    private ChannelParmService channelParmService;

    @Autowired
    private BoscHttpService boscHttpService;

    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
    private ChannelRtncodeService channelRtncodeService;

    /**
     * 单笔实时代收
     *
     * @param deduct 收、扣款交易信息实体DTO
     * @return
     * @throws BizException
     * @author 罗帅
     */
    public ClearingResultDTO directDeduct(final DeductDTO deduct) throws BizException {
        boolean isQuery = false;
        // 生成交易请求序列号；
        String bankSendSN = seqService.getBoscCorpSendSeq();

        Log4jUtil.info("发送银行流水号：" + bankSendSN);

        // 保存渠道交易流水kftcl.billno_sn（交易请求独立事务保存，即使逻辑处理失败，交易请求也要在数据库有记录存档）。
        BillnoSn billnoSn = billnoSnService.saveBillnoSn(bankSendSN, channelId, deduct);
        // 获取渠道参数；
        Map<String, String> channelParams = channelParmService.queryCodeParamsMapByChannelId(channelId);
        // 根据报文规范组装报文；生成验签内容；
        String scReqXml = packageService.buildSCReq(bankSendSN, deduct, channelParams);
        // 发送报文；
        byte[] scResXml = boscHttpService.send(channelParams.get(BoscConsts.PAYMENT_REQ_URL), scReqXml, isQuery);

        ClearingResult clearingResult = new ClearingResult();

        // 接收报文响应；解析报文，验签；
        BoscDeductResDTO boscDeductResDTO = packageService.parseSCRes(scResXml, channelParams, bankSendSN);

        // FIXME 上海银行建议以status作为交易结果判断依据
        if (BoscConsts.BOSC_STATUS_SUCCESS.equals(boscDeductResDTO.getStatus())) {
            // 明确成功
            clearingResult.setTxnStatus(PayState.SUCCEED_STR);
            clearingResult.setChannelResponseCode(TransReturnCode.code_0000);
            clearingResult.setChannelResponseMsg("交易成功");
            clearingResult.setBankRtnCode(boscDeductResDTO.getErrorCode());
            clearingResult.setBankRtnMsg(boscDeductResDTO.getErrorMessage());
        } else if (BoscConsts.BOSC_STATUS_FAILURE.equals(boscDeductResDTO.getStatus())) {
            // 明确失败
            ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
                    boscDeductResDTO.getErrorCode().trim()));
            if (null != channelRtncode) {
                clearingResult.setChannelResponseCode(channelRtncode.getKftRtncode());
                clearingResult.setChannelResponseMsg(channelRtncode.getChannelReamrk());
            } else {
                clearingResult.setChannelResponseCode(TransReturnCode.code_9900);
                clearingResult.setChannelResponseMsg(StringUtils.isBlank(boscDeductResDTO.getErrorMessage())
                        ? "交易失败" : boscDeductResDTO.getErrorMessage());
            }
            clearingResult.setTxnStatus(PayState.FAILED_STR);
            clearingResult.setBankRtnCode(boscDeductResDTO.getErrorCode());
            clearingResult.setBankRtnMsg(boscDeductResDTO.getErrorMessage());
        } else if (BoscConsts.BOSC_STATUS_PROCESSING.equals(boscDeductResDTO.getStatus())) {
            // 处理中
            try {
                for (int i = 0; i < 3; i++) {    //30秒
                    //查询单笔交易结果
                    this.querySingleRecord(clearingResult, bankSendSN);
                    //如果交易结果'未知',则暂停3秒后再查询,直至超出最大查询次数
                    if (TransReturnCode.code_9109.equals(clearingResult.getChannelResponseCode())) {
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            Log4jUtil.error(e);
                        }
                    } else {
                        break;
                    }
                }
            } catch (Exception biz) {
                Log4jUtil.error(biz);
                throw new BizException(biz, TransReturnCode.code_9109, biz.getMessage());    //如果查询交易状态时发生异常, 当异常失败处理, 以保证资金安全.
            }
        } else {
            // 银行返回提供的状态之外的状态，一般不存在
            // 其余按未知返回 9109
            clearingResult.setTxnStatus(PayState.UNKNOW_STR);
            clearingResult.setChannelResponseCode(TransReturnCode.code_9109);
            clearingResult.setChannelResponseMsg(StringUtils.isBlank(boscDeductResDTO.getErrorMessage()) ? "其他错误" :
                    boscDeductResDTO.getErrorMessage());
            clearingResult.setBankRtnCode(boscDeductResDTO.getErrorCode());
            clearingResult.setBankRtnMsg(boscDeductResDTO.getErrorMessage());
        }


//        if (boscDeductResDTO.getErrorCode().equals(BoscConsts.BOSC_ERROR_CODE_SUCC)) { // 交易请求成功
//
//            if (boscDeductResDTO.getStatus().equals(BoscConsts.BOSC_STATUS_SUCCESS)) {
//                // 明确成功
//                clearingResult.setTxnStatus(PayState.SUCCEED_STR);
//                clearingResult.setChannelResponseCode(TransReturnCode.code_0000);
//                clearingResult.setChannelResponseMsg("交易成功");
//                clearingResult.setBankRtnCode(boscDeductResDTO.getErrorCode());
//                clearingResult.setBankRtnMsg(boscDeductResDTO.getErrorMessage());
//            } else if (boscDeductResDTO.getStatus().equals(BoscConsts.BOSC_STATUS_FAILURE)) {
//                // 明确失败
//                ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
//                        boscDeductResDTO.getErrorCode().trim()));
//                if (null != channelRtncode) {
//                    clearingResult.setChannelResponseCode(channelRtncode.getKftRtncode());
//                    clearingResult.setChannelResponseMsg(channelRtncode.getChannelReamrk());
//                } else {
//                    // FIXME 需要确认
//                    clearingResult.setChannelResponseCode(TransReturnCode.code_9900);
//                    clearingResult.setChannelResponseMsg(boscDeductResDTO.getErrorMessage());
//                }
//                clearingResult.setTxnStatus(PayState.FAILED_STR);
//                clearingResult.setBankRtnCode(boscDeductResDTO.getErrorCode());
//                clearingResult.setBankRtnMsg(boscDeductResDTO.getErrorMessage());
//            } else {
//                // 处理中
//                try {
//                    for (int i = 0; i < 3; i++) {    //30秒
//                        //查询单笔交易结果
//                        this.querySingleRecord(clearingResult, bankSendSN);
//                        //如果交易结果'未知',则暂停3秒后再查询,直至超出最大查询次数
//                        if (TransReturnCode.code_9109.equals(clearingResult.getChannelResponseCode())) {
//                            try {
//                                Thread.sleep(3000);
//                            } catch (InterruptedException e) {
//                                Log4jUtil.error(e);
//                            }
//                        } else {
//                            break;
//                        }
//                    }
//                } catch (Exception biz) {
//                    Log4jUtil.error(biz);
//                    throw new BizException(biz, TransReturnCode.code_9109, biz.getMessage());    //如果查询交易状态时发生异常, 当异常失败处理, 以保证资金安全.
//                }
//            }
//
//        } else { // 交易请求失败
//            ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
//                    boscDeductResDTO.getErrorCode().trim()));
//            if (null != channelRtncode) {
//                clearingResult.setChannelResponseCode(channelRtncode.getKftRtncode());
//                clearingResult.setChannelResponseMsg(channelRtncode.getChannelReamrk());
//            } else {
//                clearingResult.setChannelResponseCode(TransReturnCode.code_9900);
//                clearingResult.setChannelResponseMsg(StringUtils.isBlank(boscDeductResDTO.getErrorMessage())
//                        ? "交易失败" : boscDeductResDTO.getErrorMessage());
//            }
//
//            if (!StringUtils.isBlank(boscDeductResDTO.getErrorMessage())) {    //如果银行有返回错误描述, 则优先使用银行返回的提示. 因为运营会根据错误提示去银行咨询具体失败原因.
//                clearingResult.setChannelResponseMsg(boscDeductResDTO.getErrorMessage());
//            }
//
//            clearingResult.setTxnStatus(PayState.FAILED_STR);
//            clearingResult.setBankRtnCode(boscDeductResDTO.getErrorCode());
//            clearingResult.setBankRtnMsg(boscDeductResDTO.getErrorMessage());
//
//        }

        clearingResult.setRetrievalRefNo(boscDeductResDTO.getSerialNo());    //线上收付平台流水号
        clearingResult.setRecvTime(new Date());

        billnoSnService.updateBillnoSnByClearingResultForUnknow(billnoSn, clearingResult);

        // 根据响应报文结果，确认返回内容。
        ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
        BeanUtils.copyProperties(clearingResult, clearingResultDTO);

        return clearingResultDTO;
    }


    private void querySingleRecord(ClearingResult clearingResult, String originalBankSendSN) throws BizException {
        boolean isQuery = true;
        String bankSendSN = seqService.getBoscCorpSendSeq();

        Map<String, String> channelParams = channelParmService.queryCodeParamsMapByChannelId(channelId);

        String sqReqXml = packageService.buildSQReq(bankSendSN, channelParams, originalBankSendSN);

        byte[] sqResXml = boscHttpService.send(channelParams.get(BoscConsts.QUERY_REQ_URL), sqReqXml, isQuery);

        BoscPaymentQueryResDTO boscPaymentQueryResDTO = packageService.parseSQRes(sqResXml, channelParams, bankSendSN);

//        if (boscPaymentQueryResDTO
//                .getErrorCode().equals(BoscConsts.BOSC_ERROR_CODE_SUCC)) {
//            // 查询成功
//            convertTransStatus(boscPaymentQueryResDTO, clearingResult);
//            clearingResult.setBankRtnCode(boscPaymentQueryResDTO.getErrorCode());
//            clearingResult.setBankRtnMsg(boscPaymentQueryResDTO.getErrorMessage());
//        } else {
//            // 其余按未知返回
//            clearingResult.setTxnStatus(PayState.UNKNOW_STR);
//            clearingResult.setChannelResponseCode(TransReturnCode.code_9109);
//            clearingResult.setChannelResponseMsg(boscPaymentQueryResDTO.getErrorMessage());
//            clearingResult.setBankRtnCode(boscPaymentQueryResDTO.getErrorCode());
//            clearingResult.setBankRtnMsg(boscPaymentQueryResDTO.getErrorMessage());
//        }

        convertTransStatus(boscPaymentQueryResDTO, clearingResult);

    }

    /**
     * 银行返回状态： 0000 成功 0001 失败 0002 处理中 0003 无此订单
     *
     * @param boscPaymentQueryResDTO
     * @param clearingResult
     */
    private void convertTransStatus(final BoscPaymentQueryResDTO boscPaymentQueryResDTO, final ClearingResult clearingResult) {
        switch (boscPaymentQueryResDTO.getStatus()) {
            case BoscConsts.BOSC_STATUS_SUCCESS:
                clearingResult.setTxnStatus(PayState.SUCCEED_STR);
                clearingResult.setChannelResponseCode(TransReturnCode.code_0000);
                clearingResult.setChannelResponseMsg("交易成功");
                break;
            case BoscConsts.BOSC_STATUS_FAILURE:
                clearingResult.setTxnStatus(PayState.FAILED_STR);
                clearingResult.setChannelResponseCode(TransReturnCode.code_9900);
                clearingResult.setChannelResponseMsg(StringUtils.isBlank(boscPaymentQueryResDTO.getErrorMessage())
                        ? "交易失败" : boscPaymentQueryResDTO
                        .getErrorMessage());
                break;
            default:
                clearingResult.setTxnStatus(PayState.UNKNOW_STR);
                clearingResult.setChannelResponseCode(TransReturnCode.code_9109);
                clearingResult.setChannelResponseMsg(boscPaymentQueryResDTO.getStatus().equals(BoscConsts
                        .BOSC_STATUS_NOT_FOUND_BILL) ? "银行查无此订单" : "银行处理中");
                break;
        }

        clearingResult.setBankRtnCode(boscPaymentQueryResDTO.getErrorCode());
        clearingResult.setBankRtnMsg(boscPaymentQueryResDTO.getErrorMessage());
    }


    /**
     * 单笔代收查询
     *
     * @param billnoSn
     * @return
     * @throws BizException
     */
    public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) throws BizException {

        ClearingResult clearingResult = new ClearingResult();
        this.querySingleRecord(clearingResult, billnoSn.getBankSendSn());

        ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
        BeanUtils.copyProperties(clearingResult, clearingResultDTO);

        return clearingResultDTO;
    }


}
