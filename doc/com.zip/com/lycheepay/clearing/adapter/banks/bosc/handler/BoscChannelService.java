package com.lycheepay.clearing.adapter.banks.bosc.handler;

import com.lycheepay.clearing.adapter.banks.bosc.service.BoscChannelProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * @author 罗帅
 * @since 2017/12/1 8:44.
 */
@Service(ClearingAdapterAnnotationName.BOSC_CHANNEL_SERVICE)
public class BoscChannelService extends AbstractChannelService {

    // 渠道Id
    private final static String CHANNEL_ID = ChannelId.ChannelIdEnum.BOSC_CORP.getCode();

    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.BOSC_CHANNEL_PROCESS_SERVICE)
    private BoscChannelProcessService boscChannelProcessService;


    /**
     * 单笔代收
     */
    @Override
    public ClearingResultDTO directDeduct(DeductDTO deduct) throws ClearingAdapterBizCheckedException {
        Log4jUtil.setLogClass("BOSC", "directDeduct");
        Log4jUtil.info(deduct);
        ClearingResultDTO dto = null;
        try {
            dto = boscChannelProcessService.directDeduct(deduct);
            dto.setChannelId(CHANNEL_ID);
            dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
        } catch (final Exception e) {
            return ChannelResultUtil.exceptionToResult(e, dto);
        }
        Log4jUtil.info(dto);
        return dto;
    }


    /**
     * 单笔交易结果查询
     */
    @Override
    public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) {
        Log4jUtil.setLogClass("BOSC", "singleQuery");
        Log4jUtil.info(billnoSn);
        ClearingResultDTO dto = null;
        try {
            dto = boscChannelProcessService.querySingleRecord(billnoSn);
        } catch (BizException e) {
            dto = new ClearingResultDTO();
            dto.setChannelResponseCode(TransReturnCode.code_9109);
            dto.setChannelResponseMsg("结果未知");
            dto.setTxnStatus(PayState.UNKNOW_STR);
            dto.setChannelId(CHANNEL_ID);
//			Log4jUtil.error(e);
//			return null;
//			return ChannelResultUtil.exceptionToResult(e, dto);
        }
        Log4jUtil.info(dto);
        return dto;
    }




}