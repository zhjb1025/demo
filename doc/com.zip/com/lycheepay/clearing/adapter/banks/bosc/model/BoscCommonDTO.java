package com.lycheepay.clearing.adapter.banks.bosc.model;

/**
 * @author 罗帅
 * @since 2017/12/3 14:19.
 */
public class BoscCommonDTO {
    /**
     * 版本 目前1.0.1
     */
    protected String version;
    /**
     * 商户标识
     */
    protected String instId;
    /**
     * 流水号
     */
    protected String serialNo;
    /**
     * 商户支付订单号
     */
    protected String orderNum;
    /**
     * 交易日期和时间 yyyyMMdd HH:mm:ss
     */
    protected String date;
    /**
     * 交易状态
     * 0000 成功
     * 0001 失败
     * 0002 处理中
     * 0003 银行查无此订单
     */
    protected String status;
    /**
     * 卡号
     */
    protected String cardNo;
    /**
     * 错误码 成功SUCC 其他均为失败
     */
    protected String errorCode;
    /**
     * 订单失败原因
     */
    protected String orderRemark;
    /**
     * 错误描述
     */
    protected String errorMessage;
    /**
     * 签名
     */
    protected String Signature;

    public String getSignature() {
        return Signature;
    }

    public void setSignature(String signature) {
        Signature = signature;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getInstId() {
        return instId;
    }

    public void setInstId(String instId) {
        this.instId = instId;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getOrderRemark() {
        return orderRemark;
    }

    public void setOrderRemark(String orderRemark) {
        this.orderRemark = orderRemark;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "BoscCommonDTO{" +
                "version='" + version + '\'' +
                ", instId='" + instId + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", orderNum='" + orderNum + '\'' +
                ", date='" + date + '\'' +
                ", status='" + status + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", errorCode='" + errorCode + '\'' +
                ", orderRemark='" + orderRemark + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                ", Signature='" + Signature + '\'' +
                '}';
    }
}
