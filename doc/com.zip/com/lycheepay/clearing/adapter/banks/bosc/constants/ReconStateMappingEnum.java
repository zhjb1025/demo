package com.lycheepay.clearing.adapter.banks.bosc.constants;

/**
 * @author 罗帅
 * @since 2017/12/11 11:23.
 */
public enum ReconStateMappingEnum {

    RECON_SUCCESS("Y", "00", "成功"), RECON_FAILED("N", "01", "失败");

    private String bankReconStatus;
    private String kftReconStatus;
    private String reconDesc;

    /**
     * @param bankReconStatus
     * @param kftReconStatus
     * @param reconDesc
     */
    private ReconStateMappingEnum(String bankReconStatus, String kftReconStatus, String reconDesc) {
        this.bankReconStatus = bankReconStatus;
        this.kftReconStatus = kftReconStatus;
        this.reconDesc = reconDesc;
    }

    public static String getKftReconStatus(String bankReconStatus) {
        for (ReconStateMappingEnum reconStateMappingEnum : values()) {
            if (bankReconStatus.equals(reconStateMappingEnum.getBankReconStatus())) {
                return reconStateMappingEnum.getKftReconStatus();
            }
        }
        return null;
    }

    public String getBankReconStatus() {
        return bankReconStatus;
    }

    public String getKftReconStatus() {
        return kftReconStatus;
    }

    public String getReconDesc() {
        return reconDesc;
    }

}
