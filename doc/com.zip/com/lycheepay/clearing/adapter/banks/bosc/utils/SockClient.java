package com.lycheepay.clearing.adapter.banks.bosc.utils;

/**
 * @author 罗帅
 * @since 2017/11/29 20:52.
 */
public abstract class SockClient
{
    abstract String sendAndRecv(String paramString)
            throws Exception;
}