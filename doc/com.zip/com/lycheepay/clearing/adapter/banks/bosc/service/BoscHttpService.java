package com.lycheepay.clearing.adapter.banks.bosc.service;

import com.lycheepay.clearing.adapter.banks.bosc.constants.BoscConsts;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.util.Map;

/**
 * @author 罗帅
 * @since 2017/11/29 16:55.
 */
@Service
public class BoscHttpService {

    static final String channelId = ChannelId.ChannelIdEnum.BOSC_CORP.getCode();
    private static final String CHARSET = StandardCharsets.UTF_8.displayName();
    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
    private ChannelParmService channelParmService;

    public byte[] send(String requestUrl, String xml, boolean isQuery) throws BizException {
        HttpClient httpClient = null;
        HttpPost httpPost = null;

        // 获取渠道参数；
        Map<String, String> channelParams = channelParmService.queryCodeParamsMapByChannelId(channelId);

        Log4jUtil.info("HttpPost请求参数:【{}】,requestUrl:【{}】", xml, requestUrl);
        try {
            URL url = new URL(requestUrl);
            httpClient = getHttpClient(false, url.getPort());
            HttpParams httpParams = httpClient.getParams();

            HttpConnectionParams.setConnectionTimeout(httpParams, Integer.parseInt(channelParams.get(BoscConsts.HTTP_CONNECTION_TIMEOUT)));
            HttpConnectionParams.setSoTimeout(httpParams, Integer.parseInt(channelParams.get(BoscConsts.HTTP_READ_TIMEOUT)));

            httpPost = new HttpPost(requestUrl);
            StringEntity stringEntity = new StringEntity(xml, StandardCharsets.UTF_8);
            httpPost.setEntity(stringEntity);

            httpPost.setHeader("Content-Type", "application/xml; charset=utf-8");
//            httpPost.setHeader("Content-Length", String.valueOf(xml.length()));

        } catch (Exception e) {
            Log4jUtil.error(e);
            throw new BizException(e, isQuery ? TransReturnCode.code_9109 : TransReturnCode.code_9108, e.getMessage());
        }

        try {
            HttpResponse response = httpClient.execute(httpPost);
            int statusCode = response.getStatusLine().getStatusCode();
            Log4jUtil.info("收到http响应回执: statusCode:【{}】", statusCode);

            if (statusCode != HttpStatus.SC_OK) {
                Log4jUtil.error("PostMethod failed, statusCode" + statusCode);
                throw new BizException(TransReturnCode.code_9109, "unable to get response,statusCode incorrect");
            }
            HttpEntity entity = response.getEntity();

            byte[] result = EntityUtils.toByteArray(entity);

            Log4jUtil.info("接收到http报文内容：{}", new String(result, CHARSET));
            return result;
        } catch (Exception e) {
            Log4jUtil.error(e);
            throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
        } finally {
            if (httpPost != null) {
                httpPost.releaseConnection();
            }
            if (httpClient != null) {
                httpClient.getConnectionManager().shutdown();
            }
        }
    }


    private HttpClient getHttpClient(boolean pool, int httpsPort) {
        SSLSocketFactory sf = null;
        try {
            TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] certificate, String authType) {
                    return true;
                }
            };
            sf = new SSLSocketFactory(acceptingTrustStrategy, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        } catch (Exception e) {
            Log4jUtil.error(e.getMessage());
        }

        Scheme sch = new Scheme("https", httpsPort == -1 ? 443:httpsPort, sf);
        ClientConnectionManager ccm = null;
        if (pool) {
            SchemeRegistry registry = new SchemeRegistry();
            registry.register(sch);
            ccm = new PoolingClientConnectionManager(registry);
            return new DefaultHttpClient(ccm);
        } else {
            DefaultHttpClient client = new DefaultHttpClient();
            client.getConnectionManager().getSchemeRegistry().register(sch);
            return client;
        }
    }

}
