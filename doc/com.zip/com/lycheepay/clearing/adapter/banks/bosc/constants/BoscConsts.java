package com.lycheepay.clearing.adapter.banks.bosc.constants;

/**
 * 上海银行银企直连常量
 *
 * @author 罗帅
 * @since 2017/11/29 9:18.
 */
public interface BoscConsts {

    /**
     *  交易请求url
     */
    String PAYMENT_REQ_URL = "100001";

    /**
     * 快付通在上海银行的商户编号
     */
    String MERCHANT_ID = "100002";

    /**
     * bosc 交易摘要(9. 其他)
     */
    String DIGEST = "100003";


    /**
     * bosc 交易描述（对应交易摘要）
     */
    String DESCRIBE = "100004";

    /**
     * 公钥路径
     */
    String MERCHANT_PUB_KEY = "100005";

    /**
     * 私钥路径
     */
    String MERCHANT_PRI_KEY = "100006";

    /**
     * 私钥保护口令
     */
    String MERCHANT_PRI_PWD = "100007";


    /**
     * 对账文件临时路径
     */
    String RECON_LOCAL_TEMP_PATH = "100008";

    /**
     * 对账文件请求url
     */
    String RECON_REQUEST_URL = "100009";

    /**
     * bosc 3DES key
     */
    String BOSC_3DES_KEY = "100010";


    /**
     * 查询请求url
     */
    String QUERY_REQ_URL = "100011";


    /**
     * 银行公钥路径
     */
    String BANK_PUB_KEY = "100012";


    /**
     * 连接超时
     */
    String HTTP_CONNECTION_TIMEOUT = "100013";


    /**
     * 读取超时
     */
    String HTTP_READ_TIMEOUT = "100014";


    /**
     * bosc 对账状态 成功
     */
    String BOSC_RECON_STATUS_SUCC = "Y";

    /**
     * bosc 对账状态 失败
     */
    String BOSC_RECON_STATUS_FAIL = "N";


    /**
     * ================= kft 卡类型 ==========
     */

    /**
     * kft 存折常量
     */
    String KFT_CARDTYPE_BANKBOOK = "0";

    /**
     * kft 借记卡常量
     */
    String KFT_CARDTYPE_DEBITCARD = "1";

    /**
     * kft 信用卡常量
     */
    String KFT_CARDTYPE_CREDITCARD = "2"; // 信用卡 == 贷记卡

    /**
     * kft 其他
     */
    String KFT_CARDTYPE_OTHER = "3";


    /**
     *  =============== bosc 卡类型 ===========
     */

    /**
     * bosc 存折常量
     */
    String BOSC_CARDTYPE_BANKBOOK = "3";

    /**
     * bosc 借记卡常量
     */
    String BOSC_CARDTYPE_DEBITCARD = "1";

    /**
     * bosc 贷记卡（信用卡）常量
     */
    String BOSC_CARDTYPE_CREDITCARD = "2";


    /**
     * bosc 货币代码 (人民币 156 )
     */
    String CURRENCY_CODE_RMB = "156";


    /**
     * 单笔交易查询接口类型
     * 0. 全部 1.支付 2.退款 3.提现
     */
    String QUERY_TYPE = "0";


    /**
     * bosc 请求version (目前1.0.1)
     */
    String BOSC_VERSION = "1.0.1";

    /**
     *  ======== bosc 交易状态码 =======
     */

    /**
     *  bosc 交易状态：0000 (明确成功)
     */
    String BOSC_STATUS_SUCCESS = "0000";

    /**
     * bosc 交易状态：0001 (明确失败)
     */
    String BOSC_STATUS_FAILURE = "0001";

    /**
     * bosc 交易状态： 0002 (银行处理中)
     */
    String BOSC_STATUS_PROCESSING = "0002";

    /**
     * bosc 交易状态：0003 (银行查无次订单)
     */
    String BOSC_STATUS_NOT_FOUND_BILL = "0003";


    /**
     * bosc 错误码： SUCC 表示成功，其余表示失败
     */
    String BOSC_ERROR_CODE_SUCC = "SUCC";

}
