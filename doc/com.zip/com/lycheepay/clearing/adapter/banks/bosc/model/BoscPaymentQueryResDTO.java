package com.lycheepay.clearing.adapter.banks.bosc.model;

/**
 * @author 罗帅
 * @since 2017/12/3 15:35.
 */
public class BoscPaymentQueryResDTO extends BoscCommonDTO {

    /**
     * 交易性质
     */
    private String type;
    /**
     * 交易金额
     */
    private String amount;
    /**
     * 手续费
     */
    private String charge;
    /**
     * 交易卡类型 1 借记卡 2 贷记卡
     */
    private String cardType;

    @Override
    public String toString() {
        return "BoscPaymentQueryResDTO{" +
                "type='" + type + '\'' +
                ", amount='" + amount + '\'' +
                ", charge='" + charge + '\'' +
                ", cardType='" + cardType + '\'' +
                ", version='" + version + '\'' +
                ", instId='" + instId + '\'' +
                ", serialNo='" + serialNo + '\'' +
                ", orderNum='" + orderNum + '\'' +
                ", date='" + date + '\'' +
                ", status='" + status + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", errorCode='" + errorCode + '\'' +
                ", orderRemark='" + orderRemark + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                ", Signature='" + Signature + '\'' +
                '}';
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

}
