package com.lycheepay.clearing.adapter.banks.bosc.handler;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.bosc.constants.BoscConsts;
import com.lycheepay.clearing.adapter.banks.bosc.constants.ReconStateMappingEnum;
import com.lycheepay.clearing.adapter.banks.bosc.utils.Bosc3DESUtils;
import com.lycheepay.clearing.adapter.banks.bosc.utils.SvsBase;
import com.lycheepay.clearing.adapter.banks.bosc.utils.SvsSign;
import com.lycheepay.clearing.adapter.banks.bosc.utils.SvsVerify;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.Log4jUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.LineIterator;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * 上海银行对账服务类
 *
 * @author 罗帅
 * @since 2017/12/3 18:07.
 */

@Service(ClearingAdapterAnnotationName.BOSC_RECONCILATION_FILE_SERVICE)
public class BoscReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

    @Autowired
    @Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
    private ChannelParmService channelParmService;

    private static final String STR_PAY = "pay";
    private static final String STR_GET = "get";

    @Override
    public String getReconciliationFile(String fileSavePath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {

        Log4jUtil.setLogClass("BOSC", "reconFile");
        final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
        final String reconciliationDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
                settleDate);

        Log4jUtil.info(logPrefix + "本次对账文件日期为：" + reconciliationDate);

        final Map<String, String> channelParams = channelParmService.queryCodeParamsMapByChannelId(channelId);

        final String reconFileName = "CCF" + "_" + reconciliationDate + "_01.zip";

        List<ReconciliationFileDTO> reconciliationFileDTOList = null;

        try {
            reconciliationFileDTOList = getReconFileFromBoscServer(channelParams, reconFileName, reconciliationDate, channelId);
        } catch (Exception e) {
            Log4jUtil.error(e);
        }

        return ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate,
                reconciliationFileDTOList);
    }


    /**
     * 从上海银行下载对账文件
     *
     * @param channelParams
     * @param reconFileName
     * @param settleDate
     * @param channelId
     */
    private List<ReconciliationFileDTO> getReconFileFromBoscServer(Map<String, String> channelParams, String reconFileName, String settleDate, String channelId) throws ClearingAdapterBizCheckedException {
        HttpResponse response = getReconFile(channelParams, reconFileName, settleDate);

        String banksha1 = response.getFirstHeader("Banksha1").getValue();
        String banksign = response.getFirstHeader("Banksign").getValue();


        if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
            throw new BizException("对账文件下载请求失败");
        }

        HttpEntity entity = response.getEntity();

        InputStream is = null;
        try {
             is = entity.getContent();
        } catch (IOException e) {
            throw new BizException("获取流错误");
        }

        BufferedInputStream bis = new BufferedInputStream(is);

        String sha1 = null;
        try {
            bis.mark(bis.available() + 1);
            sha1 = DigestUtils.sha1Hex(bis).toUpperCase();
            bis.reset();
        } catch (IOException e) {
            throw new BizException("计算对账文件摘要发生错误");
        }


        SvsVerify svsVerify = new SvsVerify();

        try {
            svsVerify.initSignCertFile(channelParams.get(BoscConsts.BANK_PUB_KEY));
//            svsVerify.initSignCertFile("F:\\boscKey\\bosc_bank.cer");
        } catch (Exception e) {
            throw new BizException("银行公钥路径不正确或公钥不存在");
        }

        if (svsVerify.verifySign(banksha1.getBytes(), banksign) != 0) {
            throw new BizException("下载对账文件验签失败!");
        }

        if (!sha1.equals(banksha1)) {
            throw new BizException("校验银行摘要错误");
        }


        List<ReconciliationFileDTO> list = new ArrayList<>();


        try {
            ZipInputStream zipInputStream = Bosc3DESUtils.getZipInputStream(channelParams.get(BoscConsts
                    .BOSC_3DES_KEY), bis);

            ZipEntry entry = zipInputStream.getNextEntry();
            if (null != entry) {

                BufferedReader br = new BufferedReader(new InputStreamReader(zipInputStream, "gbk"));
                StringBuilder sb = new StringBuilder();
                String line = null;
                int x = 0;
                while ((line = br.readLine()) != null) {
                    x++;
                    sb.append(line + "\r\n");
                }

                ByteArrayInputStream content = new ByteArrayInputStream(sb.toString().getBytes());

                LineIterator reconFileIterator = IOUtils.lineIterator(content, StandardCharsets.UTF_8);
                if (reconFileIterator.hasNext()) {
                    reconFileIterator.nextLine();
                } else {
                    Log4jUtil.error("对账文件无内容");
                    throw new BizException("对账文件无内容");
                }
                int index = 1;

                SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
                SimpleDateFormat yyyyMMddHHmmss = new SimpleDateFormat("yyyyMMdd HH:mm:ss");

                while (reconFileIterator.hasNext()) {
                    String reconLine = reconFileIterator.nextLine();
                    index++;
                    Log4jUtil.info("读取到对账文件第[{}]行，内容：{}", index, reconLine);
                    String[] reconInfos = reconLine.split(",");
                    if (reconInfos.length < 11) {
                        Log4jUtil.error("对账文件第[{}]行对账信息不足", index);
                        continue;
                    }
                    String bankSendSn = reconInfos[0]; // 流水号
                    String tradeDate = reconInfos[1]; // 交易日期

                    Date parse = yyyyMMddHHmmss.parse(tradeDate);
                    tradeDate = yyyyMMdd.format(parse);

                    String tradeType = reconInfos[2]; // 交易类型
                    String chargeAmount = reconInfos[4]; // 手续费
                    String amount = reconInfos[5]; // 金额
                    String status = reconInfos[9]; // 处理状态
                    String failureReason = reconInfos[10]; // 失败原因

                    String reconStatus = ReconStateMappingEnum.getKftReconStatus(status);

                    ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();

                    //TODO 填充 reconciliationFileDTO

                    reconciliationFileDTO.setAmount(new BigDecimal(amount).divide(BigDecimal.valueOf(100))); // 分->元
                    reconciliationFileDTO.setChannelId(channelId);
                    reconciliationFileDTO.setBankSendId(bankSendSn);
                    reconciliationFileDTO.setTransDate(tradeDate);
                    reconciliationFileDTO.setBankTransState(reconStatus);
                    reconciliationFileDTO.setCheckDate(settleDate);
                    reconciliationFileDTO.setPayGet(STR_GET); // 代收

                    list.add(reconciliationFileDTO);
                }
            }

            return list;

        } catch (Exception e) {
            throw new BizException("解析对账文件失败");
        }

    }

    private HttpResponse getReconFile(Map<String, String> channelParams, String reconFileName, String settleDate) throws BizException {
        try {
            URL url = new URL(channelParams.get(BoscConsts.RECON_REQUEST_URL));

            HttpClient httpClient = getHttpClient(false, url.getPort());

            List<NameValuePair> params = new ArrayList<>();
            SvsBase svsBase = new SvsBase();
            svsBase.initSignCertFile(channelParams.get(BoscConsts.MERCHANT_PUB_KEY));
//            svsBase.initSignCertFile("F:\\boscKey\\bosc_merchant.cer");
            String b64Cert = svsBase.getEncodedSignCert();

            params.add(new BasicNameValuePair("instId", channelParams.get(BoscConsts.MERCHANT_ID)));
            params.add(new BasicNameValuePair("actiontype", "download"));
            params.add(new BasicNameValuePair("filename", reconFileName));
            params.add(new BasicNameValuePair("KoalB64Cert", b64Cert));
            params.add(new BasicNameValuePair("date", settleDate));


            SvsSign svsSign = new SvsSign();
            String unSignStr = new StringBuilder().append("download").append("|").append(channelParams.get(BoscConsts
                    .MERCHANT_ID)).append("|").append
                    (settleDate)
                    .append("|")
                    .append(reconFileName).toString();

            svsSign.initSignCertAndKey(channelParams.get(BoscConsts.MERCHANT_PRI_KEY), channelParams.get(BoscConsts
                    .MERCHANT_PRI_PWD));
//            svsSign.initSignCertAndKey("F:\\boscKey\\bosc_merchant.pfx", "000000");
            String signedStr = svsSign.signData(unSignStr.getBytes("GBK"));
            params.add(new BasicNameValuePair("sign", signedStr));
            String p = EntityUtils.toString(new UrlEncodedFormEntity(params, StandardCharsets.UTF_8));
            HttpGet httpGet = new HttpGet(channelParams.get(BoscConsts.RECON_REQUEST_URL) + "?" + p);
            return httpClient.execute(httpGet);
        } catch (Exception e) {
            Log4jUtil.error("获取对账文件异常：", e);
            throw new BizException("公钥路径错误或公钥不存在");
        }
    }


    private HttpClient getHttpClient(boolean pool, int httpsPort) {
        SSLSocketFactory sf = null;
        try {
            TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] certificate, String authType) {
                    return true;
                }
            };
            sf = new SSLSocketFactory(acceptingTrustStrategy, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        } catch (Exception e) {
            Log4jUtil.error(e.getMessage());
        }

        Scheme sch = new Scheme("https", httpsPort == -1 ? 443:httpsPort, sf);
        ClientConnectionManager ccm = null;
        if (pool) {
            SchemeRegistry registry = new SchemeRegistry();
            registry.register(sch);
            ccm = new PoolingClientConnectionManager(registry);
            return new DefaultHttpClient(ccm);
        } else {
            DefaultHttpClient client = new DefaultHttpClient();
            client.getConnectionManager().getSchemeRegistry().register(sch);
            return client;
        }
    }


    @Override
    public String convertToStandardReconciliationFile(String targetFilePath, String fileSavePath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
        return null;
    }
}
