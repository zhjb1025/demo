package com.lycheepay.clearing.adapter.banks.bosc.service;

import com.lycheepay.clearing.adapter.banks.bosc.constants.BoscConsts;
import com.lycheepay.clearing.adapter.banks.bosc.model.BoscDeductResDTO;
import com.lycheepay.clearing.adapter.banks.bosc.model.BoscPaymentQueryResDTO;
import com.lycheepay.clearing.adapter.banks.bosc.utils.SvsBase;
import com.lycheepay.clearing.adapter.banks.bosc.utils.SvsSign;
import com.lycheepay.clearing.adapter.banks.bosc.utils.SvsVerify;
import com.lycheepay.clearing.adapter.banks.cmb.mobilePay.utils.RandomUtils;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.CertificateType;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import org.dom4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 罗帅
 * @since 2017/11/28 17:03.
 */
@Service
public class BoscCorpPackageService {

    private Map<String, String> certTypeMap = null;

    private Map<String, String> cardTypeMap = null;

    @PostConstruct
    public void initMap() {
        certTypeMap = new HashMap<>();
        certTypeMap.put(CertificateType.IDENTITY_CARD, "A"); // 身份证
        certTypeMap.put(CertificateType.BOOKLET, "B"); // 户口簿
        certTypeMap.put(CertificateType.MILITARY_CERTIFICATE, "C"); //军官证
        certTypeMap.put(CertificateType.POLICE_ID, "D"); //警官证
        certTypeMap.put(CertificateType.CHINA_PASSPORT, "E"); //护照
        certTypeMap.put(CertificateType.OTHER, "J"); // 士兵证
        certTypeMap.put(CertificateType.TAIWANESE_PASS, "K"); // 台胞证
        //0存折 1借记卡 2信用卡3不区分

        cardTypeMap = new HashMap<>();
        cardTypeMap.put(BankCardType.BANK_BOOK, "3"); //存折
        cardTypeMap.put(BankCardType.CREDIT_CARD, "2"); //贷记卡（信用卡）
        cardTypeMap.put(BankCardType.DEBIT_CARD, "1"); //借记卡
    }


    /**
     * 构建单笔代收交易请求报文
     *
     * @param bankSendSN
     * @param deduct
     * @param channelParams
     */
    public String buildSCReq(String bankSendSN, DeductDTO deduct, Map<String, String> channelParams) throws BizException {

        try {
            Document document = DocumentHelper.createDocument();
            document.setXMLEncoding("UTF-8");
            // 创建root节点
            Element banksh = document.addElement("Banksh");
            // 创建Message 节点
            Element message = banksh.addElement("Message");
            // 给Message 节点添加 id 属性
            message.addAttribute("id", bankSendSN);
            // 创建 CSReq 节点
            Element csReq = message.addElement("CSReq");
            csReq.addAttribute("id", "SCReq");
            // 为 CSReq 节点添加 子节点
            csReq.addElement("version").addText(BoscConsts.BOSC_VERSION); // 目前版本号1.0.1

            String merchantId = channelParams.get(BoscConsts.MERCHANT_ID);

            //------------  数据校验 -------------
            AssertUtils.isBlank(merchantId, TransReturnCode.code_9108, "商户号不能为空");
            AssertUtils.isBlank(bankSendSN, TransReturnCode.code_9108, "订单号bankSendSN不能为空");
            AssertUtils.isBlank(deduct.getCardHolderName(), TransReturnCode.code_9108, "户名不能为空");
            AssertUtils.isBlank(deduct.getAccountType(), TransReturnCode.code_9108, "账户类型不能为空");
            AssertUtils.isBlank(deduct.getBankCardType(), TransReturnCode.code_9108, "银行卡类型不能为空");
            AssertUtils.isBlank(deduct.getBankCardNo(), TransReturnCode.code_9108, "银行卡号不能为空");

            String amount = null;
            if (deduct.getAmount() != null) {
                // 交易金额 元 -> 分
                amount = deduct.getAmount().multiply(new BigDecimal(100)).longValue() + "";
                AssertUtils.isBlank(amount, TransReturnCode.code_9108, "交易金额不能为空");
            }

            // 如果账户类型为对公时，无需输入证件类型和证件号
            if (deduct.getAccountType().equals("1")) { // 1 个人 2 企业
                String certType = certTypeMap.get(deduct.getCertificateType());

                AssertUtils.isBlank(deduct.getCertificateNo(), TransReturnCode.code_9108, "证件号不能为空");
                AssertUtils.isBlank(certType, TransReturnCode.code_9108, "证件类型为空或类型不匹配");

                csReq.addElement("certType").addText(certType); // 证件类型
                csReq.addElement("certNo").addText(deduct.getCertificateNo()); // 证件号
            }

            AssertUtils.isBlank(BoscConsts.CURRENCY_CODE_RMB, TransReturnCode.code_9108, "货币代码不能为空");
            String digest = channelParams.get(BoscConsts.DIGEST);
            AssertUtils.isBlank(digest, TransReturnCode.code_9108, "交易摘要不能为空");

            String describe = channelParams.get(BoscConsts.DESCRIBE);
            AssertUtils.isBlank(describe, TransReturnCode.code_9108, "交易摘要描述不能为空");

            SvsBase svsBase = new SvsBase();
            String b64Cert = null;
            try {
                svsBase.initSignCertFile(channelParams.get(BoscConsts.MERCHANT_PUB_KEY));
//                svsBase.initSignCertFile("F:\\boscKey\\bosc_merchant.cer");
                b64Cert = svsBase.getEncodedSignCert();
            } catch (Exception e) {
                throw new BizException(e, TransReturnCode.code_9108, "公钥路径错误或公钥不存在");
            }
            AssertUtils.isBlank(b64Cert, TransReturnCode.code_9108, "获取本地商户证书Base64编码错误");


            //------------  数据填充 -----------------
            csReq.addElement("instId").addText(merchantId); // 发送方商户标识
            csReq.addElement("orderNum").addText(bankSendSN); // 订单号
            String date = DateUtil.getCurrentTransDate();
            csReq.addElement("date").addText(date); // 交易时间和日期 YYYYMMDD HH:MM:SS
            csReq.addElement("name").addText(deduct.getCardHolderName()); // 户名
            csReq.addElement("accountType").addText(deduct.getAccountType()); // 1.对私， 2.对公
            // 获取bosc卡类型
            String cardType = cardTypeMap.get(deduct.getBankCardType());
            if (cardType == null) {
                throw new BizException(TransReturnCode.code_9108, "银行卡类型不匹配");
            }
            csReq.addElement("cardType").addText(cardType); // 卡类型 1.借记卡 2.贷记卡 3.存折
            csReq.addElement("cardNo").addText(deduct.getBankCardNo()); // 银行卡号
            csReq.addElement("amount").addText(amount); // 交易金额 单位分
            csReq.addElement("currency").addText(BoscConsts.CURRENCY_CODE_RMB); // 交易货币代码 RMB
            csReq.addElement("KoalB64Cert").addText(b64Cert); // 经过Base64处理的商户证书代码
            csReq.addElement("digest").addText(digest); // 交易摘要
            csReq.addElement("describe").addText(describe); // 交易摘要描述


            Element signature = message.addElement("Signature");

            StringBuilder builder = new StringBuilder();
            // 拼接待签名字段
            String unsignStr = builder.append(merchantId).append("|").append(bankSendSN).append("|").append(date).append
                    ("|")
                    .append(deduct
                            .getCardHolderName()).append("|").append(deduct.getAccountType()).append("|").append(cardType).append
                            ("|").append(deduct.getBankCardNo()).append("|").append(amount).append("|").append(
                            BoscConsts.CURRENCY_CODE_RMB).toString();

            SvsSign svsSign = new SvsSign();
            String signedStr = null;
            try {
                svsSign.initSignCertAndKey(channelParams.get(BoscConsts.MERCHANT_PRI_KEY), channelParams.get
                        (BoscConsts.MERCHANT_PRI_PWD));
//                svsSign.initSignCertAndKey("F:\\boscKey\\bosc_merchant.pfx", "000000");
                signedStr = svsSign.signData(unsignStr.getBytes("GBK"));
            } catch (Exception e) {
                throw new BizException(e, TransReturnCode.code_9108, "数字签名失败");
            }

            AssertUtils.isBlank(signedStr, TransReturnCode.code_9108, "签名不能为空");
            signature.addText(signedStr);

            return document.asXML();

        } catch (Exception e) {
            Log4jUtil.error("单笔代收交易请求报文组装异常", e);
            throw new BizException(e, TransReturnCode.code_9108, "请求报文组装异常");
        }
    }

    /**
     * 解析单笔代扣结果
     *
     * @param resposeXml
     * @param bankSendSN
     */
    public BoscDeductResDTO parseSCRes(byte[] resposeXml, Map<String, String> channelParams, String bankSendSN) throws
            BizException {
        String xml = new String(resposeXml);
        String instId = null;
        String orderNum = null;
        String serialNo = null;
        String cardNo = null;
        String date = null;
        String status = null;
        String errorCode = null;
        String orderRemark = null;
        String errorMessage = null;

        String signature = null;
        String messageId = null;

        try {
            Document document = DocumentHelper.parseText(xml);
            Element message = (Element) document.selectSingleNode("/Banksh/Message");
            messageId = message.attribute("id").getStringValue();

            Node csRes = message.selectSingleNode("CSRes");

            instId = csRes.selectSingleNode("instId").getText();
            orderNum = csRes.selectSingleNode("orderNum").getText();
            serialNo = csRes.selectSingleNode("serialNo").getText();
            cardNo = csRes.selectSingleNode("cardNo").getText();
            date = csRes.selectSingleNode("date").getText();
            status = csRes.selectSingleNode("status").getText();
            errorCode = csRes.selectSingleNode("errorCode").getText(); //SUCC 表示成功，其余表示失败

            Node or = csRes.selectSingleNode("orderRemark");
            if (or != null) {
                orderRemark = or.getText();
            }

            Node em = csRes.selectSingleNode("errorMessage");

            if (em != null) {
                errorMessage = em.getText();
            }

            signature = message.selectSingleNode("Signature").getText();

        } catch (Exception e) {
            throw new BizException(e, TransReturnCode.code_9109, "解析交易结果失败");
        }

//        if (!messageId.equals(bankSendSN)) {
//            throw new BizException(TransReturnCode.code_9109, "响应报文message id与请求报文message id不一致");
//        }


        StringBuilder sb = new StringBuilder();
        sb.append(instId).append("|").append(orderNum).append("|").append(serialNo).append("|").append(cardNo).append
                ("|").append(date).append("|").append(status).append("|").append(errorCode);
        String unVerify = sb.toString();

        SvsVerify svsVerify = new SvsVerify();

        try {
            svsVerify.initSignCertFile(channelParams.get(BoscConsts.BANK_PUB_KEY));
//            svsVerify.initSignCertFile("F:\\boscKey\\bosc_bank.cer");
        } catch (Exception e) {
            throw new BizException(e, TransReturnCode.code_9109, "公钥路径不正确或公钥不存在");
        }


        if (svsVerify.verifySign(unVerify.getBytes(Charset.forName("GBK")), signature) != 0) {
            throw new BizException(TransReturnCode.code_9109, "验签失败!");
        }


        BoscDeductResDTO boscDeductResDTO = new BoscDeductResDTO();
        boscDeductResDTO.setInstId(instId);
        boscDeductResDTO.setOrderNum(orderNum);
        boscDeductResDTO.setSerialNo(serialNo);
        boscDeductResDTO.setCardNo(cardNo);
        boscDeductResDTO.setDate(date);
        boscDeductResDTO.setStatus(status);
        boscDeductResDTO.setErrorCode(errorCode);
        boscDeductResDTO.setOrderRemark(orderRemark);
        boscDeductResDTO.setErrorMessage(errorMessage);
        boscDeductResDTO.setSignature(signature);

        Log4jUtil.info("代扣交易结果响应：{}", boscDeductResDTO.toString());

        return boscDeductResDTO;

    }


    /**
     * 构建单笔交易查询请求报文
     */
    public String buildSQReq(String bankSendSN, Map<String, String> channelParams, String originalBankSendSN) throws BizException {
        try {
            Document document = DocumentHelper.createDocument();
            document.setXMLEncoding("UTF-8");
            // 创建root节点
            Element banksh = document.addElement("Banksh");
            // 创建Message 节点
            Element message = banksh.addElement("Message");
            // 给Message 节点添加 id 属性
            message.addAttribute("id", bankSendSN);
            // 创建 CSReq 节点
            Element csReq = message.addElement("CSReq");
            csReq.addAttribute("id", "SQReq");
            // 为 SCReq 节点添加 子节点
            csReq.addElement("version").addText("1.0.1"); // 目前版本号1.0.1

            String merchantId = channelParams.get(BoscConsts.MERCHANT_ID);
            AssertUtils.isBlank(merchantId, TransReturnCode.code_9109, "商户号不能为空");
            AssertUtils.isBlank(originalBankSendSN, TransReturnCode.code_9109, "银行流水号serialNo不能为空");


            csReq.addElement("instId").addText(merchantId); // 发送方商户标识
            csReq.addElement("serialNo").addText(bankSendSN); // 该笔查询交易的流水号

            String date = DateUtil.getCurrentTransDate();
            csReq.addElement("date").addText(date); // 交易时间和日期 YYYYMMDD HH:MM:SS
            csReq.addElement("type").addText(BoscConsts.QUERY_TYPE); // 查询类型 0. 全部 1.支付 2.退款 3.提现
            csReq.addElement("orderNum").addText(originalBankSendSN); // 查询的交易订单号


            SvsBase svsBase = new SvsBase();
            svsBase.initSignCertFile(channelParams.get(BoscConsts.MERCHANT_PUB_KEY));
//            svsBase.initSignCertFile("F:\\boscKey\\bosc_merchant.cer");
            String b64Cert = svsBase.getEncodedSignCert();

            AssertUtils.isBlank(b64Cert, TransReturnCode.code_9109, "获取本地商户证书Base64编码错误");
            csReq.addElement("KoalB64Cert").addText(b64Cert); // 商户证书b64编码

            // 在Message下添加Signature节点
            Element signature = message.addElement("Signature");

            StringBuilder builder = new StringBuilder();
            // 拼接待签名字段
            String unsignStr = builder.append(merchantId).append("|").append(bankSendSN).append("|").append(date).append
                    ("|")
                    .append(BoscConsts.QUERY_TYPE).append("|").append(originalBankSendSN).toString();

            SvsSign svsSign = new SvsSign();
            String signedStr = null;

            try {
                svsSign.initSignCertAndKey(channelParams.get(BoscConsts.MERCHANT_PRI_KEY), channelParams.get(BoscConsts
                        .MERCHANT_PRI_PWD));
//                svsSign.initSignCertAndKey("F:\\boscKey\\bosc_merchant.pfx", "000000");
                signedStr = svsSign.signData(unsignStr.getBytes("GBK"));
            } catch (Exception e) {
                throw new BizException(e, TransReturnCode.code_9109, "数字签名失败");
            }


            AssertUtils.isBlank(signedStr, TransReturnCode.code_9109, "签名不能为空");
            signature.addText(signedStr);

            return document.asXML();
        } catch (Exception e) {
            Log4jUtil.error("单笔交易查询请求报文组装异常:", e);
            throw new BizException(e, TransReturnCode.code_9109, "单笔交易查询报文组装异常");
        }
    }


    /**
     * 解析单笔交易查询结果
     *
     * @param sqResXml
     * @param channelParams
     * @param bankSendSN
     * @return
     * @throws BizException
     */
    public BoscPaymentQueryResDTO parseSQRes(byte[] sqResXml, Map<String, String> channelParams, String bankSendSN) throws BizException {

        String xml = new String(sqResXml);
        BoscPaymentQueryResDTO boscPaymentQueryResDTO = new BoscPaymentQueryResDTO();
        String messageId = null;
        try {
            Document document = DocumentHelper.parseText(xml);
            Element message = (Element) document.selectSingleNode("/Banksh/Message");
            messageId = message.attribute("id").getStringValue();

            Node sqRes = message.selectSingleNode("CSRes");

            boscPaymentQueryResDTO.setInstId(sqRes.selectSingleNode("instId").getText());
            boscPaymentQueryResDTO.setOrderNum(sqRes.selectSingleNode("orderNum").getText());
            boscPaymentQueryResDTO.setSerialNo(sqRes.selectSingleNode("serialNo").getText());
            boscPaymentQueryResDTO.setCardNo(sqRes.selectSingleNode("cardNo").getText());
            boscPaymentQueryResDTO.setDate(sqRes.selectSingleNode("date").getText());
            boscPaymentQueryResDTO.setType(sqRes.selectSingleNode("type").getText());
            boscPaymentQueryResDTO.setStatus(sqRes.selectSingleNode("status").getText());
            boscPaymentQueryResDTO.setErrorCode(sqRes.selectSingleNode("errorCode").getText()); //SUCC 表示成功，其余表示失败

            Node or = sqRes.selectSingleNode("orderRemark");
            if (or != null) {
                boscPaymentQueryResDTO.setOrderRemark(or.getText());
            }

            Node em = sqRes.selectSingleNode("errorMessage");

            if (em != null) {
                boscPaymentQueryResDTO.setErrorMessage(em.getText());
            }

            boscPaymentQueryResDTO.setSignature(message.selectSingleNode("Signature").getText().trim());

        } catch (Exception e) {
            throw new BizException(e, TransReturnCode.code_9109, "解析查询结果失败");
        }

//        if (!messageId.equals(bankSendSN)) {
//            throw new BizException(TransReturnCode.code_9109, "响应报文message id与请求报文message id不一致");
//        }


        StringBuilder sb = new StringBuilder();
        sb.append(boscPaymentQueryResDTO.getInstId()).append("|").append(boscPaymentQueryResDTO.getSerialNo()).append("|")
                .append(boscPaymentQueryResDTO.getDate()).append("|")
                .append(boscPaymentQueryResDTO.getType()).append
                ("|").append(boscPaymentQueryResDTO.getOrderNum()).append("|").append(boscPaymentQueryResDTO.getStatus())
                .append("|").append
                (boscPaymentQueryResDTO.getErrorCode());
        String unVerify = sb.toString();

        SvsVerify svsVerify = new SvsVerify();

        try {
            svsVerify.initSignCertFile(channelParams.get(BoscConsts.BANK_PUB_KEY));
//            svsVerify.initSignCertFile("F:\\boscKey\\bosc_bank.cer");
        } catch (Exception e) {
            throw new BizException(e, TransReturnCode.code_9109, "公钥路径不正确或公钥不存在");
        }


        if (svsVerify.verifySign(unVerify.getBytes(Charset.forName("GBK")), boscPaymentQueryResDTO.getSignature()) != 0) {
            throw new BizException(TransReturnCode.code_9109, "单笔交易查询验签不通过!");
        }

        Log4jUtil.info("单笔交易查询结果响应：{}", boscPaymentQueryResDTO.toString());

        return boscPaymentQueryResDTO;
    }

}
