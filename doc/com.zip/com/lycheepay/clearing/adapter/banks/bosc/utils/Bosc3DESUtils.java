package com.lycheepay.clearing.adapter.banks.bosc.utils;

import com.lycheepay.clearing.adapter.banks.bosc.constants.BoscConsts;
import com.lycheepay.clearing.adapter.banks.bosc.handler.BoscReconciliationFileService;
import com.lycheepay.clearing.adapter.banks.egfSH.util.Base64;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.ZipUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.mongodb.Bytes;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.LineIterator;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * @author 罗帅
 * @since 2017/12/4 14:41.
 */
public class Bosc3DESUtils {

    //定义加密算法，有DES、DESede(即3DES)、Blowfish
    private static final String Algorithm = "DESede";


    /**
     * 加密方法
     *
     * @param src 源数据的字节数组
     * @return
     */
    public static byte[] encryptMode(String key, byte[] src) {
        try {
            SecretKey deskey = new SecretKeySpec(build3DesKey(key), Algorithm);    //生成密钥
            Cipher c1 = Cipher.getInstance(Algorithm);    //实例化负责加密/解密的Cipher工具类
            c1.init(Cipher.ENCRYPT_MODE, deskey);    //初始化为加密模式
            return c1.doFinal(src);
        } catch (java.security.NoSuchAlgorithmException e1) {
//            e1.printStackTrace();
        } catch (javax.crypto.NoSuchPaddingException e2) {
//            e2.printStackTrace();
        } catch (java.lang.Exception e3) {
//            e3.printStackTrace();
        }
        return null;
    }


    /**
     * 解密函数
     *
     * @param src 密文的字节数组
     * @return
     */
    public static byte[] decryptMode(String key, byte[] src) throws BizException {
        try {
            SecretKey deskey = new SecretKeySpec(build3DesKey(key), Algorithm);
            Cipher c1 = Cipher.getInstance(Algorithm);
            c1.init(Cipher.DECRYPT_MODE, deskey);    //初始化为解密模式
            return c1.doFinal(src);
        } catch (Exception e) {
            Log4jUtil.error("上海银行对账下载解密异常：", e);
            throw new BizException("上海银行对账下载解密异常");
        }
    }


    /*
     * 根据字符串生成密钥字节数组
     * @param keyStr 密钥字符串
     * @return
     * @throws UnsupportedEncodingException
     */
    public static byte[] build3DesKey(String keyStr) throws UnsupportedEncodingException {
        byte[] key = new byte[24];    //声明一个24位的字节数组，默认里面都是0
        byte[] temp = keyStr.getBytes("UTF-8");    //将字符串转成字节数组

        /*
         * 执行数组拷贝
         * System.arraycopy(源数组，从源数组哪里开始拷贝，目标数组，拷贝多少位)
         */
        if (key.length > temp.length) {
            //如果temp不够24位，则拷贝temp数组整个长度的内容到key数组中
            System.arraycopy(temp, 0, key, 0, temp.length);
        } else {
            //如果temp大于24位，则拷贝temp数组24个长度的内容到key数组中
            System.arraycopy(temp, 0, key, 0, key.length);
        }
        return key;
    }


    /**
     * 设置数据流为解密模式
     * @param des3Key
     * @param inputStream
     * @return
     */
    public static CipherInputStream decryptMode(String des3Key, InputStream inputStream) {
        //生成密钥
        SecretKey deskey = new SecretKeySpec(des3Key.getBytes(), "DESede"); //解密
        return decryptMode(deskey, inputStream);
    }
    /**
     * 设置数据流为解密模式
     * @param secretKey
     * @param inputStream
     * @return
     */
    public static CipherInputStream decryptMode(SecretKey secretKey, InputStream inputStream) {
        try {
            Cipher c1 = Cipher.getInstance("DESede");
            c1.init(Cipher.DECRYPT_MODE, secretKey);
            return new CipherInputStream(inputStream, c1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ZipInputStream getZipInputStream(String threeDesKey,
                                                  InputStream fileInputStream) throws IOException {
        InputStream decryptInputStream = decryptMode(threeDesKey,
                fileInputStream);
        // 设置流以解密模式输出
        ZipInputStream zipIn = new ZipInputStream(decryptInputStream);
        return zipIn;
    }


    public static void main(String[] args) throws IOException, BizException {
//        String channelId = "3003135842";
//        String settleDate = "20171205";
//
//        String key = "123456788765432112345678";
//
//        File file = new File("F:\\CCF_20171207_01.zip");
//
//        byte[] bytes = IOUtils.toByteArray(new FileInputStream(file));
//
////        byte[] encryptBytes = encryptMode(key, bytes);
//
////        String s = Base64.encode(encryptBytes);
//
////        String s = new String(bytes);
//
////        System.out.println(s);
//
//
//        byte[] decryptFileBytes = Bosc3DESUtils.decryptMode(key,
//                bytes);
//
//        System.out.println(new String(decryptFileBytes));
//
//        List<ReconciliationFileDTO> list = new ArrayList<>();
//
//        try (ZipInputStream zipInputStream = new ZipInputStream(new ByteArrayInputStream(decryptFileBytes),
//                StandardCharsets.UTF_8)) {
//            ZipEntry entry = zipInputStream.getNextEntry();
//            if (null != entry) {
//                int fileSize = (int) entry.getSize();
//                byte[] unzipBytes = new byte[fileSize];
//
//                int rb = 0, chunk = 0;
//                //通过循环一次把数据全部都读到内存中去
//                while(fileSize - rb > 0)
//                {
//                    chunk = zipInputStream.read(unzipBytes, rb, fileSize - rb);
//                    if (chunk <= 0)
//                    {
//                        break;
//                    }
//                    rb += chunk;
//                }
//
//                ByteArrayInputStream content = new ByteArrayInputStream(unzipBytes);
//
//                LineIterator reconFileIterator = IOUtils.lineIterator(content, StandardCharsets.UTF_8);
//                if (reconFileIterator.hasNext()) {
//                    reconFileIterator.nextLine();
//                } else {
//                    Log4jUtil.error("对账文件无内容");
//                    throw new BizException("对账文件无内容");
//                }
//                int index = 1;
//                while (reconFileIterator.hasNext()) {
//                    String reconLine = reconFileIterator.nextLine();
//                    index++;
//                    Log4jUtil.info("读取到对账文件第[{}]行，内容：{}", index, reconLine);
//                    String[] reconInfos = reconLine.split(",");
//                    if (reconInfos.length < 11) {
//                        Log4jUtil.error("对账文件第[{}]行对账信息不足", index);
//                        continue;
//                    }
//                    String bankSendSn = reconInfos[0];
//                    String tradeDate = reconInfos[1];
//                    String tradeType = reconInfos[2];
//                    String payNo = reconInfos[3]; //支付协议号
//                    String amount = reconInfos[5];
//                    String status = reconInfos[9];
//                    String failureReason = reconInfos[10];
//
//                    ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
//
//                    //TODO 填充 reconciliationFileDTO
//
//                    reconciliationFileDTO.setAmount(new BigDecimal(amount).divide(BigDecimal.valueOf(100))); // 分->元
//                    reconciliationFileDTO.setChannelId(channelId);
//                    reconciliationFileDTO.setBankSendId(bankSendSn);
//                    reconciliationFileDTO.setTransDate(tradeDate);
////                        reconciliationFileDTO.setBankRecvSN();
////                        reconciliationFileDTO.setBankTransState();
//                    reconciliationFileDTO.setCheckDate(settleDate);
////                        reconciliationFileDTO.setPayGet();
//
//                    list.add(reconciliationFileDTO);
//                }
//            }
//
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

    }
}
