package com.lycheepay.clearing.adapter.banks.bosc.utils;

/**
 * @author 罗帅
 * @since 2017/11/29 20:57.
 */
public class SvsException extends Exception {

    private int errorNum = 0;

    public SvsException() {}

    public SvsException(String msg)
    {
        super(msg);
    }

    public SvsException(String msg, int num)
    {
        super(msg);
        this.errorNum = num;
    }

    public int getErrorNum()
    {
        return this.errorNum;
    }

}
