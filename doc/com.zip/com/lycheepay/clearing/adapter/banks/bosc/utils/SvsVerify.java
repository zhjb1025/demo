package com.lycheepay.clearing.adapter.banks.bosc.utils;


import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import sun.security.pkcs.PKCS7;
import sun.security.pkcs.ParsingException;
import sun.security.pkcs.SignerInfo;
import sun.security.x509.AlgorithmId;

/**
 * @author 罗帅
 * @since 2017/11/29 20:55.
 */
public class SvsVerify extends SvsBase {

    public static final int VERIFY_FAILED = 1;
    public static final int NO_SUCH_ALG_EXP = 1010;
    public static final int NO_DIGEST_ALG_EXP = 1011;
    public static final int NO_SIGN_ALG_EXP = 1012;
    public static final int B64_DECODE_IO_EXP = 1021;
    public static final int FILE_IO_EXP = 1022;
    public static final int PKCS7_PARSE_EXP = 1031;
    public static final int PKCS7_NO_SIGN_CERT = 1032;
    public static final int INVALID_KEY_EXP = 1041;
    public static final int SIGN_EXP = 1042;

    public int verifySign(byte[] originData, int offset, int len, String szB64SignedData)
    {
        if ((originData == null) || (szB64SignedData == null)) {
            return -1;
        }
        try
        {
            Signature sign = Signature.getInstance(this.digestAlg + "with" + this.cryptAlg);
            sign.initVerify(this.signCert);
            sign.update(originData, offset, len);
            byte[] signedData = SvsBase.base64Decode(szB64SignedData);
            if (sign.verify(signedData)) {
                return 0;
            }
            return 1;
        }
        catch (NoSuchAlgorithmException exp)
        {
            return 1012;
        }
        catch (InvalidKeyException exp)
        {
            return 1041;
        }
        catch (SignatureException exp)
        {
            return 1042;
        }
        catch (IOException exp) {}
        return 1021;
    }

    public int verifySign(byte[] originData, String szB64SignedData)
    {
        return verifySign(originData, 0, originData.length, szB64SignedData);
    }

    public int verifyFileSign(String fileName, String szB64SignedData)
            throws Exception
    {
        byte[] digesData = SvsBase.digestFile(fileName, this.digestAlg);
        return verifySign(digesData, 0, digesData.length, szB64SignedData);
    }

    public int verifyPkcs7Sign(byte[] originData, String szPkcs7B64Data)
    {
        if (szPkcs7B64Data == null) {
            return -1;
        }
        this.signCert = null;
        try
        {
            PKCS7 p7 = new PKCS7(SvsBase.base64Decode(szPkcs7B64Data));
            if (originData == null)
            {
                SignerInfo[] signers = p7.verify();
                if (signers != null)
                {
                    X509Certificate[] certs = p7.getCertificates();
                    if (certs[0].getSerialNumber().equals(signers[0].getCertificateSerialNumber()))
                    {
                        this.signCert = certs[0];
                        return 0;
                    }
                    return 1032;
                }
                return 1;
            }
            SignerInfo[] signers = p7.verify(originData);
            if (signers != null)
            {
                X509Certificate[] certs = p7.getCertificates();
                if (certs[0].getSerialNumber().equals(signers[0].getCertificateSerialNumber()))
                {
                    this.signCert = certs[0];
                    return 0;
                }
                return 1032;
            }
            return 1;
        }
        catch (ParsingException exp)
        {
            return 1031;
        }
        catch (IOException exp)
        {
            return 1021;
        }
        catch (NoSuchAlgorithmException exp)
        {
            return 1010;
        }
        catch (SignatureException exp) {}
        return 1042;
    }

    public int verifyPkcs7SignFile(String szFileName, String szPkcs7B64Data)
    {
        byte[] digestData = null;
        AlgorithmId[] aids = null;

        try
        {
            PKCS7 p7 = new PKCS7(SvsBase.base64Decode(szPkcs7B64Data));
            aids = p7.getDigestAlgorithmIds();
        }
        catch (ParsingException exp)
        {
            return 1031;
        }
        catch (IOException exp)
        {
            return 1021;
        }
        try
        {
            digestData = SvsBase.digestFile(szFileName, aids[0].getName());
        }
        catch (IOException exp)
        {
            return 1022;
        }
        catch (NoSuchAlgorithmException exp)
        {
            return 1011;
        }
        return verifyPkcs7Sign(digestData, szPkcs7B64Data);
    }

    public static int verify(byte[] originData, String szB64SignedData, String szCertFileName)
            throws Exception
    {
        SvsVerify very = new SvsVerify();
        very.initSignCertFile(szCertFileName);
        return very.verifySign(originData, szB64SignedData);
    }
}
