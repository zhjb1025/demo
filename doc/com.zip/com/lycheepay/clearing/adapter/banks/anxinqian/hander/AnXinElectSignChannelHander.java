package com.lycheepay.clearing.adapter.banks.anxinqian.hander;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.AnXinQianManualDownLoadFile;
import com.lycheepay.clearing.adapter.banks.anxinqian.service.AnXinElectSignService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ElectSignUserService;
import com.lycheepay.clearing.adapter.common.service.biz.ElectsignContractService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.sign.AccountResultDTO;
import com.lycheepay.clearing.common.dto.sign.BatchContractDTO;
import com.lycheepay.clearing.common.dto.sign.BatchContractResultDTO;
import com.lycheepay.clearing.common.dto.sign.ContractDTO;
import com.lycheepay.clearing.common.dto.sign.ContractResultDTO;
import com.lycheepay.clearing.common.dto.sign.EnterpriseDTO;
import com.lycheepay.clearing.common.dto.sign.IdentyDTO;
import com.lycheepay.clearing.common.dto.sign.MsgCodeDTO;
import com.lycheepay.clearing.common.dto.sign.UploadContractDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.ElectSignUser;
import com.lycheepay.clearing.common.model.ElectsignContract;
import com.lycheepay.clearing.util.Log4jUtil;


@Service(ClearingAdapterAnnotationName.ANXIN_ELECTSIGN_CHANNEL_HANDER)
public class AnXinElectSignChannelHander extends AbstractChannelService implements AnXinQianManualDownLoadFile {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ANXIN_ELECT_SIGN_SERVICE)
	private AnXinElectSignService anXinElectSignService;

	@Autowired
	private ElectSignUserService electSignUserService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	private ElectsignContractService electsignContractService;

	/**
	 * 电子签章个人开户
	 */
	@Override
	public AccountResultDTO createPersonSign(IdentyDTO identyDTO) {
		Log4jUtil.info("安心签渠道接受个人开户请求参数：" + identyDTO);
		AccountResultDTO accountResultDTO = null;
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");
			Assert.notEmpty(deduct.getBankCardNo(), "银行卡号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			// Assert.notNull(electSignUser, "电子签章用户对象不能为空");
			accountResultDTO = anXinElectSignService.createPersonSign(identyDTO);
			if (accountResultDTO.getTxnStatus() == TxnStatus.SUCCEED) {
				electSignUserService.saveElectSignPerson(identyDTO, accountResultDTO.getUserId());
			}
		} catch (Exception e) {
			accountResultDTO = new AccountResultDTO();
			accountResultDTO.setChannelResponseMsg(e.getMessage());
			accountResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			accountResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受个人开户返回对象：" + accountResultDTO);
		return accountResultDTO;
	}

	/**
	 * 电子签章企业开户
	 */
	@Override
	public AccountResultDTO createEnterpriseSign(EnterpriseDTO enterpriseDTO) {
		Log4jUtil.info("安心签渠道接受企业开户请求参数：" + enterpriseDTO);
		AccountResultDTO accountResultDTO = null;
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			accountResultDTO = anXinElectSignService.createEnterpriseSign(enterpriseDTO);
			if (accountResultDTO.getTxnStatus() == TxnStatus.SUCCEED) {
				electSignUserService.saveElectSignEnterprise(enterpriseDTO, accountResultDTO.getUserId());
			}
		} catch (Exception e) {
			accountResultDTO = new AccountResultDTO();
			accountResultDTO.setChannelResponseMsg(e.getMessage());
			accountResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			accountResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受企业开户返回对象：" + accountResultDTO);
		return accountResultDTO;
	}

	/**
	 * 电子签章申请验证码
	 */
	@Override
	public ClearingResultDTO sendMsgCode(MsgCodeDTO msgCodeDTO) {
		Log4jUtil.info("安心签渠道接受申请验证码请求参数：" + msgCodeDTO);
		ClearingResultDTO clearingResultDTO = null;
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			ElectSignUser electSignUser = electSignUserService.selectByPrimaryKey(msgCodeDTO.getOrgTxnId());
			Assert.notNull(electSignUser, "orgTxnId获取对应的用户信息为空");
			clearingResultDTO = anXinElectSignService.sendMsgCode(msgCodeDTO, electSignUser);
		} catch (Exception e) {
			clearingResultDTO = new ClearingResultDTO();
			clearingResultDTO.setChannelResponseMsg(e.getMessage());
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受申请验证码返回对象：" + clearingResultDTO);
		return clearingResultDTO;
	}

	/**
	 * 电子签章确认验证码
	 */
	@Override
	public ClearingResultDTO checkMsgCode(MsgCodeDTO msgCodeDTO) {
		Log4jUtil.info("安心签渠道接受校验验证码请求参数：" + msgCodeDTO);
		ClearingResultDTO clearingResultDTO = null;
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			ElectSignUser electSignUser = electSignUserService.selectByPrimaryKey(msgCodeDTO.getOrgTxnId());
			Assert.notNull(electSignUser, "orgTxnId获取对应的用户信息为空");
			clearingResultDTO = anXinElectSignService.checkMsgCode(msgCodeDTO, electSignUser);
		} catch (Exception e) {
			clearingResultDTO = new ClearingResultDTO();
			clearingResultDTO.setChannelResponseMsg(e.getMessage());
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受校验验证码返回对象：" + clearingResultDTO);
		return clearingResultDTO;
	}

	/**
	 * 电子签章创建合同
	 */
	@Override
	public ContractResultDTO createContract(ContractDTO contractDTO) {
		Log4jUtil.info("安心签渠道接受创建电子合同请求参数：" + contractDTO);
		ContractResultDTO contractResultDTO = null;
		try {
			final String sn = sequenceManagerService.getAnXinSN();
			electsignContractService.saveContractInfo(contractDTO, sn);
			contractResultDTO = anXinElectSignService.createContract(contractDTO);
			electsignContractService.updateContractInfo(contractDTO, contractResultDTO, sn);
			if(contractResultDTO.getTxnStatus() == TxnStatus.SUCCEED){
				Log4jUtil.info("进入异步下载程序");
				final String contractNo = contractResultDTO.getContractNo();
				final int contractState = contractResultDTO.getContractState();
				final int status = contractResultDTO.getTxnStatus();
				Runnable runable = new Runnable() {
					@Override
					public void run() {
						ElectsignContract electsignContract = new ElectsignContract();
						electsignContract.setId(sn);
						electsignContract.setContractNo(contractNo);
						electsignContract.setContractState(contractState);
						electsignContract.setStatus(contractState);
						Log4jUtil.info("开始异步下载合同文件："+contractNo);
						String fullPath = downLoadContract(electsignContract);
						Log4jUtil.info("异步下载后返回的文件路径为："+fullPath);
					}
				};
				new Thread(runable).start();
			}
		} catch (Exception e) {
			contractResultDTO = new ContractResultDTO();
			contractResultDTO.setChannelResponseMsg(e.getMessage());
			contractResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			contractResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受创建电子合同返回对象：" + contractResultDTO);
		return contractResultDTO;
	}

	/**
	 * 电子签章批量创建合同
	 */
	@Override
	public BatchContractResultDTO batchCreateContract(BatchContractDTO batchContractDTO) {
		BatchContractResultDTO batchContractResultDTO = null;
		Log4jUtil.info("安心签渠道接受批量创建电子合同请求参数：" + batchContractDTO);
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			electsignContractService.batchSaveContractInfo(batchContractDTO);
			batchContractResultDTO = anXinElectSignService.batchCreateContract(batchContractDTO);
			// electsignContractService.batchUpdateContractInfo(batchContractDTO,batchContractResultDTO);
		} catch (Exception e) {
			batchContractResultDTO = new BatchContractResultDTO();
			batchContractResultDTO.setChannelResponseMsg(e.getMessage());
			batchContractResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			batchContractResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受创建电子合同返回对象：" + batchContractResultDTO);
		return batchContractResultDTO;
	}

	@Override
	public ContractResultDTO uploadContract(UploadContractDTO uploadContractDTO) {
		Log4jUtil.info("安心签渠道接受上传电子合同请求参数：" + uploadContractDTO);
		ContractResultDTO contractResultDTO = null;
		try {
			final String sn = sequenceManagerService.getAnXinSN();
			electsignContractService.saveContractInfo(uploadContractDTO, sn);
			contractResultDTO = anXinElectSignService.uploadContract(uploadContractDTO);
			electsignContractService.updateContractInfo(uploadContractDTO, contractResultDTO, sn);
			if(contractResultDTO.getTxnStatus() == TxnStatus.SUCCEED){
				Log4jUtil.info("进入异步下载程序");
				final String contractNo = contractResultDTO.getContractNo();
				final int contractState = contractResultDTO.getContractState();
				final int status = contractResultDTO.getTxnStatus();
				Runnable runable = new Runnable() {
					@Override
					public void run() {
						ElectsignContract electsignContract = new ElectsignContract();
						electsignContract.setId(sn);
						electsignContract.setContractNo(contractNo);
						electsignContract.setContractState(contractState);
						electsignContract.setStatus(contractState);
						Log4jUtil.info("开始异步下载合同文件："+contractNo);
						String fullPath = downLoadContract(electsignContract);
						Log4jUtil.info("异步下载后返回的文件路径为："+fullPath);
					}
				};
				new Thread(runable).start();
			}
		} catch (Exception e) {
			contractResultDTO = new ContractResultDTO();
			contractResultDTO.setChannelResponseMsg(e.getMessage());
			contractResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			contractResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受上传电子合同返回对象：" + contractResultDTO);
		return contractResultDTO;
	}

	@Override
	public ContractResultDTO queryContractInfo(String orgTxnid, String channelId) {
		Log4jUtil.info("安心签渠道接受上传电子合同请求参数：交易流水" + orgTxnid + ",渠道号：" + channelId);
		ContractResultDTO contractResultDTO = null;
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			ElectsignContract electsignContract = new ElectsignContract();
			electsignContract.setTxnId(orgTxnid);
			electsignContract.setChannelId(channelId);
			electsignContract = electsignContractService.queryLocalContractInfo(electsignContract);
			Assert.notNull(electsignContract, "电子合同对象不能为空");
			contractResultDTO = anXinElectSignService.queryContractInfo(electsignContract);
		} catch (Exception e) {
			contractResultDTO = new ContractResultDTO();
			contractResultDTO.setChannelResponseMsg(e.getMessage());
			contractResultDTO.setChannelResponseCode(TransReturnCode.code_9108);
			contractResultDTO.setTxnStatus(TxnStatus.FAILED);
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受上传电子合同返回对象：" + contractResultDTO);
		return contractResultDTO;
	}

	@Override
	public List<ElectsignContract> batchQueryContractInfo(List<String> txnIds) {
		Log4jUtil.info("查询合同信息传入信息：" + txnIds);
		List<ElectsignContract> list = null;
		try {
			list = electsignContractService.batchSelectByPrimaryKey(txnIds);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("查询合同信息返回信息：" + list);
		return list;
	}

	@Override
	public String downLoadContract(ElectsignContract electsignContract) {
		Log4jUtil.info("安心签渠道接受下载电子合同请求参数：合同编号" + electsignContract.getContractNo());
		ContractResultDTO contractResultDTO = null;
		String fullFilePath = null;
		try {
			fullFilePath = anXinElectSignService.downLoadContract(electsignContract.getContractNo());
			contractResultDTO = new ContractResultDTO();
			if (StringUtils.isNotEmpty(fullFilePath)) {
				electsignContract.setEndFilePath(fullFilePath);
				electsignContractService.updateContractInfo(electsignContract, contractResultDTO);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受下载电子合同返回对象：" + contractResultDTO);
		return fullFilePath;
	}

	public void batchDownLoadContract(String channelId, String orgTxnids) {
		Log4jUtil.info("安心签渠道接受批量下载电子合同请求参数：交易流水" + orgTxnids + ",渠道号：" + channelId);
		ContractResultDTO contractResultDTO = null;
		try {
			/*Assert.notEmpty(deduct.getAmount().toString(), "订单编号不能为空");*/
			// 1. 写渠道流水对照表(billno_sn)
			ElectsignContract electsignContract = new ElectsignContract();
			electsignContract.setTxnId(orgTxnids);
			electsignContract.setChannelId(channelId);
			electsignContract = electsignContractService.queryLocalContractInfo(electsignContract);
			anXinElectSignService.batchDownLoadContract(electsignContract);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
		}
		Log4jUtil.info("安心签渠道接受批量下载电子合同返回对象：" + contractResultDTO);
	}

	@Override
	public String downloadContractFile(String day) {
		Log4jUtil.setLogClass("ANXINQIAN", "downloadFile");
		Log4jUtil.info("当前日期为：" + day);
		String filePath = null;
		try {
			List<ElectsignContract> list = anXinElectSignService.queryNeedDownLoadFile(day);
			Log4jUtil.info("需要下载的文件文件列表共：" + list.size() + "条记录");
			if (list != null && list.size() > 0) {
				for (ElectsignContract electsignContract : list) {
					Log4jUtil.info("正在下载的合同信息为：" + electsignContract);
					filePath = downLoadContract(electsignContract);
					Log4jUtil.info("下载成功，存放的文件路径为：" + filePath);
				}
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
		}
		return filePath;
	}
}
