package com.lycheepay.clearing.adapter.banks.anxinqian.sdk;

public class Request {
	public static final String CHANNEL = "channel";
	public static final String LOCALE = "locale";
	public static final String DATA = "data";
	public static final String SIGNATURE = "signature";

	public static String PLAT_ID = "44CA3E78498833FFE0538E02030A4E3F";

}
