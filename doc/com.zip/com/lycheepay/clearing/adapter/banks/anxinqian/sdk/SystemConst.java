package com.lycheepay.clearing.adapter.banks.anxinqian.sdk;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class SystemConst {
	public static final String DEFAULT_CHARSET = "UTF-8";
	public static final Locale DEFAULT_LOCALE = Locale.CHINA;
	
	public static Map<Integer,String> CONTRACT_STATUS = new HashMap<Integer,String>();
	
	static{
		CONTRACT_STATUS.put(0, "合同创建未完成");
		CONTRACT_STATUS.put(1, "合同创建已完成");
		CONTRACT_STATUS.put(2, "合同创建已拒绝");
		CONTRACT_STATUS.put(3, "合同创建正在签署");
		CONTRACT_STATUS.put(4, "合同创建锁定待签");
	}

	public interface Params {
		final String URL = "100001";
		final String JKS_PATH = "100002";
		final String JKS_PWD = "100003";
		final String ALIAS = "100004";
		final String FILEPATH = "100005";
		final String PLAT_ID = "100006";
	}
	
	private static final String[] SORT = { Locale.CHINA.toString() };
	static {
		Arrays.sort(SORT);
	}

	public static boolean isSupportedLocale(String locale) {
		return (Arrays.binarySearch(SORT, locale) >= 0);
	}
}
