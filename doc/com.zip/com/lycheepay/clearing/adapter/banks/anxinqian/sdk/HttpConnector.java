package com.lycheepay.clearing.adapter.banks.anxinqian.sdk;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;
import com.unionpay.acp.sdk.LogUtil;


public class HttpConnector {

	public static String JKS_PATH = "/home/admin/app/cer/anxinqian/kftpay.jks";
	public static String JKS_PWD = "cfca1234";
	public static String ALIAS = "anxinsign@深圳市快付通金融网络科技服务有限公司";
	public static String url = "https://210.74.40.8:443/FEP/";
	
	// 测试环境
	// public String url = "https://210.74.40.1:443/FEP/";
	// 生产环境
	public int connectTimeout = 3000;
	public int readTimeout = 10000;
	public String channel = "Test";
	public boolean isSSL = true;
	public String keyStorePath = JKS_PATH;
	public String keyStorePassword = JKS_PWD;
	public String trustStorePath = JKS_PATH;
	public String trustStorePassword = JKS_PWD;

	private HttpClient httpClient;

	public void init(String url,String jksPath,String jksPwd) {
		httpClient = new HttpClient();
		httpClient.config.connectTimeout = connectTimeout;
		httpClient.config.readTimeout = readTimeout;
		httpClient.httpConfig.userAgent = "TrustSign FEP";
		httpClient.httpConfig.contentType = MIMEType.FORM;
		httpClient.httpConfig.accept = MIMEType.JSON;
		try {
			if (isSSL) {
				Log4jUtil.info("keyStorePath == "+jksPath);
				Log4jUtil.info("keyStorePassword == "+jksPwd);
				httpClient.initSSL(jksPath, jksPwd.toCharArray(), jksPath,jksPwd.toCharArray());
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
		}
		if (!url.endsWith("/")) {
			url += "/";
		}
	}

	public String post(String uri, String data, String signature) throws BizException {
		return deal(uri, "POST", prepare(data, signature, null));
	}

	public String post(String uri, String data, String signature, Map<String, String> map) throws BizException {
		return deal(uri, "POST", prepare(data, signature, map));
	}

	public String post(String uri, String data, String signature, File file) throws BizException {
		return deal(uri, "POST", data, file, signature);
	}

	public byte[] getFile(String uri) throws BizException {
		HttpURLConnection connection = null;
		try {
			Log4jUtil.info("请求url："+url + uri);
			connection = httpClient.connect(url + uri, "GET");
			int responseCode = httpClient.send(connection, null);
			Log4jUtil.info("responseCode:" + responseCode);
			if (responseCode != 200) {
				Log4jUtil.info(CommonUtil.getString(httpClient.receive(connection)));
			}

			return httpClient.receive(connection);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("连接URL："+uri+"异常");
		} finally {
			httpClient.disconnect(connection);
		}
	}

	private String prepare(String data, String signature, Map<String, String> map) {
		try {
			StringBuilder request = new StringBuilder();
			request.append(Request.CHANNEL).append("=").append(URLEncoder.encode(channel, SystemConst.DEFAULT_CHARSET));
			if (CommonUtil.isNotEmpty(data)) {
				request.append("&").append(Request.DATA).append("=")
						.append(URLEncoder.encode(data, SystemConst.DEFAULT_CHARSET));
			}
			if (CommonUtil.isNotEmpty(signature)) {
				request.append("&").append(Request.SIGNATURE).append("=")
						.append(URLEncoder.encode(signature, SystemConst.DEFAULT_CHARSET));
			}
			if (CommonUtil.isNotEmpty(map)) {
				for (Entry<String, String> pair : map.entrySet()) {
					request.append("&")
							.append(pair.getKey())
							.append("=")
							.append(pair.getValue() == null ? "" : URLEncoder.encode(pair.getValue(),
									SystemConst.DEFAULT_CHARSET));
				}
			}
			return request.toString();
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e.getMessage(), e);
			return null;
		}
	}

	private String deal(String uri, String method, String request) throws BizException {
		HttpURLConnection connection = null;
		try {
			connection = httpClient.connect(url + uri, method);
			Log4jUtil.info("请求url："+url + uri);
			Log4jUtil.info(method);
			Log4jUtil.info("请求串："+request);
			int responseCode = httpClient.send(connection, request == null ? null : CommonUtil.getBytes(request));
			Log4jUtil.info("responseCode:" + responseCode);
			return CommonUtil.getString(httpClient.receive(connection));
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("连接安心签URL：" + url + "异常");
		} finally {
			httpClient.disconnect(connection);
		}
	}

	private String deal(String uri, String method, String request, File file, String signature) throws BizException {
		HttpURLConnection connection = null;
		try {
			connection = httpClient.connect(url + uri, method);
			Log4jUtil.info("请求url："+url + uri);
			Log4jUtil.info(method);
			Log4jUtil.info("请求串："+request);
			int responseCode = httpClient.send(connection, request == null ? null : CommonUtil.getBytes(request), file,
					signature);
			Log4jUtil.info("responseCode:" + responseCode);
			return CommonUtil.getString(httpClient.receive(connection));
		}catch(FileNotFoundException e){
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("没有找到文件名"+file.getName());
		}catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("连接安心签URL：" + url + "异常");
		} finally {
			httpClient.disconnect(connection);
		}
	}

}
