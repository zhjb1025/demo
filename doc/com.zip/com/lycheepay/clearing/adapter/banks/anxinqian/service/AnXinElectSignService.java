package com.lycheepay.clearing.adapter.banks.anxinqian.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import cfca.sadk.algorithm.common.PKIException;
import cfca.trustsign.common.vo.request.tx3.Tx3001ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3002ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3101ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3102ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3201ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3202ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3203ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3210ReqVO;

import com.lycheepay.clearing.adapter.app.common.service.AnXinQianManualDownLoadFile;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.HttpConnector;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.JsonObjectMapper;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.Request;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.SecurityUtil;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.SystemConst;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.SystemConst.Params;
import com.lycheepay.clearing.adapter.banks.anxinqian.util.RepConvertUtil;
import com.lycheepay.clearing.adapter.banks.anxinqian.util.ResConvertUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.mapper.ElectsignContractMapper;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.sign.AccountResultDTO;
import com.lycheepay.clearing.common.dto.sign.BatchContractDTO;
import com.lycheepay.clearing.common.dto.sign.BatchContractResultDTO;
import com.lycheepay.clearing.common.dto.sign.ContractDTO;
import com.lycheepay.clearing.common.dto.sign.ContractResultDTO;
import com.lycheepay.clearing.common.dto.sign.EnterpriseDTO;
import com.lycheepay.clearing.common.dto.sign.IdentyDTO;
import com.lycheepay.clearing.common.dto.sign.MsgCodeDTO;
import com.lycheepay.clearing.common.dto.sign.UploadContractDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.ElectSignUser;
import com.lycheepay.clearing.common.model.ElectsignContract;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


@Service(ClearingAdapterAnnotationName.ANXIN_ELECT_SIGN_SERVICE)
public class AnXinElectSignService /*implements InitializingBean*/{

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	private static final String channelId = ChannelIdEnum.ANXINQIAN.getCode();

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ELECT_SIGN_CONTRACT_MAPPER)
	private ElectsignContractMapper electsignContractMapper;

	public AccountResultDTO createPersonSign(IdentyDTO identyDTO) throws PKIException, BizException {
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			String certType = channelCertTypeService.getCertType(channelId, identyDTO.getIdentTypeCode());
			Assert.notEmpty(certType, "证件类型不能为空");
			identyDTO.setIdentTypeCode(certType);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);
			Tx3001ReqVO tx3001ReqVO = RepConvertUtil.packet3001(identyDTO);
			String req = jsonObjectMapper.writeValueAsString(tx3001ReqVO);
			Log4jUtil.info("请求字符串：" + req);
			String txCode = "3001";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector
					.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串：" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("个人开户服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3001(jsonObjectMapper, res);
	}

	public AccountResultDTO createEnterpriseSign(EnterpriseDTO enterpriseDTO) throws ClearingAdapterBizCheckedException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			String certType = channelCertTypeService.getCertType(channelId, enterpriseDTO.getIdentTypeCode());
			String personCertType = channelCertTypeService.getCertType(channelId, enterpriseDTO.getContractIdentTypeCode());
			Assert.notEmpty(certType, "证件类型不能为空");
			Assert.notEmpty(personCertType, "个人证件类型不能为空");
			enterpriseDTO.setIdentTypeCode(certType);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);
			Tx3002ReqVO tx3002ReqVO = RepConvertUtil.packet3002(enterpriseDTO);

			String req = jsonObjectMapper.writeValueAsString(tx3002ReqVO);
			Log4jUtil.info("请求字符串:" + req);
			String txCode = "3002";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("企业开户服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3002(jsonObjectMapper, res);
	}

	public ClearingResultDTO sendMsgCode(MsgCodeDTO msgCodeDTO, ElectSignUser electSignUser) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);
			Tx3101ReqVO tx3101ReqVO = RepConvertUtil.packet3101(msgCodeDTO, electSignUser);

			String req = jsonObjectMapper.writeValueAsString(tx3101ReqVO);
			Log4jUtil.info("请求字符串:" + req);

			String txCode = "3101";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("申请验证码服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3101(jsonObjectMapper, res);
	}

	public ClearingResultDTO checkMsgCode(MsgCodeDTO msgCodeDTO, ElectSignUser electSignUser) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);
			Tx3102ReqVO tx3102ReqVO = RepConvertUtil.packet3102(msgCodeDTO, electSignUser);

			String req = jsonObjectMapper.writeValueAsString(tx3102ReqVO);
			Log4jUtil.info("请求字符串:" + req);

			String txCode = "3102";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector
					.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("校验验证码服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3102(jsonObjectMapper, res);
	}

	public ContractResultDTO createContract(ContractDTO contractDTO) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);

			Tx3201ReqVO tx3201ReqVO = RepConvertUtil.packet3201(contractDTO);

			String req = jsonObjectMapper.writeValueAsString(tx3201ReqVO);
			Log4jUtil.info("请求字符串:" + req);

			String txCode = "3201";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("创建合同服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3201(jsonObjectMapper, res);
	}

	public BatchContractResultDTO batchCreateContract(BatchContractDTO batchContractDTO) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);
			Tx3202ReqVO tx3202ReqVO = RepConvertUtil.packet3202(batchContractDTO);

			String req = jsonObjectMapper.writeValueAsString(tx3202ReqVO);
			Log4jUtil.info("请求字符串:" + req);

			String txCode = "3202";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("创建合同服务异常");
		}
		return ResConvertUtil.parse3202(jsonObjectMapper, res);
	}

	public ContractResultDTO uploadContract(UploadContractDTO uploadContractDTO) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);

			Tx3203ReqVO tx3203ReqVO = RepConvertUtil.packet3203(uploadContractDTO);

			String req = jsonObjectMapper.writeValueAsString(tx3203ReqVO);
			Log4jUtil.info("请求字符串:" + req);

			String fullFileName = uploadContractDTO.getTemplatePath() + File.separator
					+ uploadContractDTO.getContractName();
			File file = new File(fullFileName);

			String txCode = "3203";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req,
					signature, file);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("上传合同签署服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3203(jsonObjectMapper, res);
	}

	public ContractResultDTO queryContractInfo(ElectsignContract electsignContract) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);

			Tx3210ReqVO tx3210ReqVO = RepConvertUtil.packet3210(electsignContract);

			String req = jsonObjectMapper.writeValueAsString(tx3210ReqVO);
			Log4jUtil.info("请求字符串:" + req);

			String txCode = "3210";
			String signature = SecurityUtil.p7SignMessageDetach(jksPath, jksPwd, alias, req);
			res = httpConnector.post("platId/" + platId + "/txCode/" + txCode + "/transaction", req, signature);
			Log4jUtil.info("返回字符串:" + res);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("查询合同服务异常:"+e.getMessage());
		}
		return ResConvertUtil.parse3210(jsonObjectMapper, res);
	}

	public String downLoadContract(String contractNo) throws BizException {
		BufferedOutputStream bos = null;
		FileOutputStream fos = null;
		String fullFileName = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		String filePath = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			filePath = channelParms.get(Params.FILEPATH);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);

			Assert.notEmpty(contractNo, "合同编号不能为空");
			byte[] fileBtye = httpConnector.getFile("platId/" + platId + "/contractNo/" + contractNo+ "/downloading");
			if (fileBtye == null || fileBtye.length == 0) {
				throw new BizException("下载合同：" + contractNo + "失败");
			}

			File file = null;
			
			Log4jUtil.info("下载文件保存目录");
			File dir = new File(filePath);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			fullFileName = filePath + File.separator + contractNo + ".pdf";
			file = new File(fullFileName);
			fos = new FileOutputStream(file);
			bos = new BufferedOutputStream(fos);
			bos.write(fileBtye);
			Log4jUtil.info("下载完成");

		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("编号号为：" + contractNo + "的合同下载异常:"+e.getMessage());
		} finally {
			if (bos != null) {
				try {
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return fullFileName;
	}

	public void batchDownLoadContract(ElectsignContract electsignContract) throws BizException {
		JsonObjectMapper jsonObjectMapper = new JsonObjectMapper();
		String res = null;
		BufferedOutputStream bos = null;
		FileOutputStream fos = null;
		String jksPath = null;
		String jksPwd = null;
		String alias = null;
		String platId = null;
		String url = null;
		try {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			jksPath = channelParms.get(Params.JKS_PATH);
			jksPwd = channelParms.get(Params.JKS_PWD);
			alias = channelParms.get(Params.ALIAS);
			platId = channelParms.get(Params.PLAT_ID);
			url = channelParms.get(Params.URL);
			HttpConnector httpConnector = new HttpConnector();
			httpConnector.init(url,jksPath,jksPwd);

			String contractNos = "MM20160519000000002@MM20160519000000003@MM20160519000000005";
			byte[] fileBtye = httpConnector.getFile("platId/" + Request.PLAT_ID + "/contractNos/" + contractNos
					+ "/batchDownloading");
			if (fileBtye == null || fileBtye.length == 0) {
				throw new BizException("批量下载合同：" + contractNos + "失败");
			}

			File file = null;
			String filePath = "./file";
			File dir = new File(filePath);
			if (!dir.exists()) {
				dir.mkdirs();
			}
			file = new File(filePath + File.separator + DateUtil.getCurrentDateTime() + ".zip");
			fos = new FileOutputStream(file);
			bos = new BufferedOutputStream(fos);
			bos.write(fileBtye);

		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("批量下载合同服务异常");
		} finally {
			if (bos != null) {
				try {
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public List<ElectsignContract> queryNeedDownLoadFile(String day) {
		String startTime = day + "000000";
		String endTime = day + "235959";
		return electsignContractMapper.selectNeedDownFile(startTime, endTime);
	}
	
	/*@Override
	public void afterPropertiesSet() throws Exception {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		HttpConnector.url = channelParms.get("100001");
		HttpConnector.JKS_PATH = channelParms.get("100002");
		HttpConnector.JKS_PWD = channelParms.get("100003");
		HttpConnector.ALIAS = channelParms.get("100004");
		SystemConst.DOWNFILEPATH = channelParms.get("100005");
		Request.PLAT_ID = channelParms.get("100006");
	}*/

}
