package com.lycheepay.clearing.adapter.banks.anxinqian.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;

import cfca.trustsign.common.vo.cs.ContractVO;
import cfca.trustsign.common.vo.cs.CreateContractVO;
import cfca.trustsign.common.vo.cs.EnterpriseTransactorVO;
import cfca.trustsign.common.vo.cs.EnterpriseVO;
import cfca.trustsign.common.vo.cs.HeadVO;
import cfca.trustsign.common.vo.cs.PersonVO;
import cfca.trustsign.common.vo.cs.ProxySignVO;
import cfca.trustsign.common.vo.cs.SignInfoVO;
import cfca.trustsign.common.vo.cs.SignLocationVO;
import cfca.trustsign.common.vo.cs.UploadContractVO;
import cfca.trustsign.common.vo.cs.UploadSignInfoVO;
import cfca.trustsign.common.vo.request.tx3.Tx3001ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3002ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3101ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3102ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3201ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3202ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3203ReqVO;
import cfca.trustsign.common.vo.request.tx3.Tx3210ReqVO;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.common.dto.sign.BatchContractDTO;
import com.lycheepay.clearing.common.dto.sign.ContractDTO;
import com.lycheepay.clearing.common.dto.sign.EnterpriseDTO;
import com.lycheepay.clearing.common.dto.sign.IdentyDTO;
import com.lycheepay.clearing.common.dto.sign.MsgCodeDTO;
import com.lycheepay.clearing.common.dto.sign.SignInfo;
import com.lycheepay.clearing.common.dto.sign.SignLocation;
import com.lycheepay.clearing.common.dto.sign.UploadContractDTO;
import com.lycheepay.clearing.common.model.ElectSignUser;
import com.lycheepay.clearing.common.model.ElectsignContract;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


public class RepConvertUtil {

	public static Tx3001ReqVO packet3001(IdentyDTO identyDTO) {
		Tx3001ReqVO tx3001ReqVO = new Tx3001ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		PersonVO person = new PersonVO();
		person.setPersonName(identyDTO.getPersonName());
		person.setIdentTypeCode(identyDTO.getIdentTypeCode());
		person.setIdentNo(identyDTO.getIdentNo());
		person.setMobilePhone(identyDTO.getMobilePhone());
		person.setEmail(identyDTO.getEmail());
		person.setAddress(identyDTO.getAddress());
		person.setAuthenticationMode(identyDTO.getAuthenticationMode());

		tx3001ReqVO.setHead(head);
		tx3001ReqVO.setPerson(person);
		tx3001ReqVO.setNotSendPwd(identyDTO.getNotSendPwd());
		return tx3001ReqVO;
	}

	public static Tx3002ReqVO packet3002(EnterpriseDTO enterpriseDTO) {
		Tx3002ReqVO tx3002ReqVO = new Tx3002ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		EnterpriseVO enterprise = new EnterpriseVO();
		enterprise.setEnterpriseName(enterpriseDTO.getEnterpriseName());
		enterprise.setIdentTypeCode(enterpriseDTO.getIdentTypeCode());
		enterprise.setIdentNo(enterpriseDTO.getIdentNo());
		enterprise.setMobilePhone(enterpriseDTO.getMobilePhone());
		enterprise.setLandlinePhone(enterpriseDTO.getLandlinePhone());
		// enterprise.setEmail("11900139002@cfca.com.cn");
		enterprise.setAuthenticationMode(enterpriseDTO.getAuthenticationMode());

		EnterpriseTransactorVO enterpriseTransactor = new EnterpriseTransactorVO();
		enterpriseTransactor.setTransactorName(enterpriseDTO.getContractTransactorName());
		enterpriseTransactor.setIdentTypeCode(enterpriseDTO.getContractIdentTypeCode());
		enterpriseTransactor.setIdentNo(enterpriseDTO.getContractIdentNo());
		enterpriseTransactor.setAddress(enterpriseDTO.getAddress());

		tx3002ReqVO.setHead(head);
		tx3002ReqVO.setEnterprise(enterprise);
		tx3002ReqVO.setEnterpriseTransactor(enterpriseTransactor);
		tx3002ReqVO.setNotSendPwd(enterpriseDTO.getNotSendPwd());

		return tx3002ReqVO;
	}

	public static Tx3101ReqVO packet3101(MsgCodeDTO msgCodeDTO, ElectSignUser electSignUser) {
		Tx3101ReqVO tx3101ReqVO = new Tx3101ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		ProxySignVO proxySignVO = new ProxySignVO();
		proxySignVO.setUserId(electSignUser.getUserId());
		proxySignVO.setProjectCode(msgCodeDTO.getProjectCode());
		//短信模板编号,如果不传,安心签将使用默认模板
		if(!StringUtils.isBlank(msgCodeDTO.getSmsTemplateId())){
			proxySignVO.setSmsTemplateId(msgCodeDTO.getSmsTemplateId());
		}		

		tx3101ReqVO.setHead(head);
		tx3101ReqVO.setProxySign(proxySignVO);
		return tx3101ReqVO;
	}

	public static Tx3102ReqVO packet3102(MsgCodeDTO msgCodeDTO, ElectSignUser electSignUser) {
		Tx3102ReqVO tx3102ReqVO = new Tx3102ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		ProxySignVO proxySignVO = new ProxySignVO();
		proxySignVO.setUserId(electSignUser.getUserId());
		proxySignVO.setProjectCode(msgCodeDTO.getProjectCode());
		proxySignVO.setCheckCode(msgCodeDTO.getCheckCode());

		tx3102ReqVO.setHead(head);
		tx3102ReqVO.setProxySign(proxySignVO);
		return tx3102ReqVO;
	}

	public static Tx3201ReqVO packet3201(ContractDTO contractDTO) {
		Tx3201ReqVO tx3201ReqVO = new Tx3201ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		CreateContractVO createContract = new CreateContractVO();

		createContract.setIsSign(contractDTO.getIsSign());
		createContract.setTemplateId(contractDTO.getTemplateId());

		createContract.setInvestmentInfo(contractDTO.getInvestmentInfo());
		List<SignInfo> list = contractDTO.getSignInfos();
		List<SignInfoVO> targetlist = new ArrayList<SignInfoVO>();
		SignInfo[] signInfos = list.toArray(new SignInfo[list.size()]);

		for (SignInfo srcobject : signInfos) {
			SignInfoVO targetObject = new SignInfoVO();
			BeanUtils.copyProperties(srcobject, targetObject);
			targetlist.add(targetObject);
			targetObject.setIsProxySign(1);
			// targetObject.setIsCopy(1);
		}
		SignInfoVO[] targetObject = targetlist.toArray(new SignInfoVO[list.size()]);
		BeanUtils.copyProperties(signInfos, targetObject);
		createContract.setSignInfos(targetObject);

		tx3201ReqVO.setHead(head);
		tx3201ReqVO.setCreateContract(createContract);
		return tx3201ReqVO;
	}

	public static Tx3202ReqVO packet3202(BatchContractDTO batchContractDTO) {
		Tx3202ReqVO tx3202ReqVO = new Tx3202ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		List<CreateContractVO> createContractlist = new ArrayList<CreateContractVO>();
		CreateContractVO createContract = new CreateContractVO();

		List<ContractDTO> contractDTOs = batchContractDTO.getContractDTOs();
		String[] ignoreProperties = { "signInfos" };
		if (contractDTOs != null && contractDTOs.size() > 0) {
			for (ContractDTO contractDTO : contractDTOs) {
				BeanUtils.copyProperties(contractDTO, createContract, ignoreProperties);
				createContractlist.add(createContract);
				List<SignInfo> list = contractDTO.getSignInfos();
				List<SignInfoVO> targetlist = new ArrayList<SignInfoVO>();
				SignInfo[] signInfos = list.toArray(new SignInfo[list.size()]);

				for (SignInfo srcobject : signInfos) {
					SignInfoVO targetObject = new SignInfoVO();
					BeanUtils.copyProperties(srcobject, targetObject);
					targetObject.setIsProxySign(1);
					targetlist.add(targetObject);
				}
				SignInfoVO[] targetObject = targetlist.toArray(new SignInfoVO[list.size()]);
				createContract.setSignInfos(targetObject);
			}
		}
		tx3202ReqVO.setCreateContracts(createContractlist.toArray(new CreateContractVO[createContractlist.size()]));
		tx3202ReqVO.setHead(head);
		tx3202ReqVO.setBatchNo(batchContractDTO.getBatchNo());
		tx3202ReqVO.setCreateContracts(createContractlist.toArray(new CreateContractVO[0]));
		return tx3202ReqVO;
	}

	public static Tx3203ReqVO packet3203(UploadContractDTO uploadContractDTO) throws BizException {
		Tx3203ReqVO tx3203ReqVO = new Tx3203ReqVO();
		HeadVO head = new HeadVO();
		try{
			head.setTxTime(DateUtil.getCurrentDateTime());

			UploadContractVO uploadContract = new UploadContractVO();

			uploadContract.setContractTypeCode(uploadContractDTO.getContractTypeCode());
			uploadContract.setContractName(uploadContractDTO.getContractName());

			uploadContract.setIsSign(Integer.parseInt(uploadContractDTO.getIsSign()));
			List<UploadSignInfoVO> uploadSignInfoVOs = new ArrayList<UploadSignInfoVO>();
			List<SignInfo> signInfos = uploadContractDTO.getSignInfos();
			for (SignInfo signInfo : signInfos) {
				UploadSignInfoVO signInfoVO0 = new UploadSignInfoVO();
				signInfoVO0.setProjectCode(signInfo.getProjectCode());
				signInfoVO0.setAuthorizationTime(signInfo.getAuthorizationTime());
				signInfoVO0.setUserId(signInfo.getUserId());
				signInfoVO0.setLocation(signInfo.getLocation());
				// BeanUtils.copyProperties(signInfo, signInfoVO0);

				List<SignLocation> signLocations = signInfo.getSignLocations();
				List<SignLocationVO> signLocationVOs = new ArrayList<SignLocationVO>();
				for (SignLocation signLocation : signLocations) {
					SignLocationVO signLocationV0 = new SignLocationVO();
					BeanUtils.copyProperties(signLocation, signLocationV0);
					signLocationVOs.add(signLocationV0);
				}
				SignLocationVO[] arraySignLocationVOs = signLocationVOs.toArray(new SignLocationVO[signLocationVOs.size()]);
				signInfoVO0.setSignLocations(arraySignLocationVOs);
				signInfoVO0.setIsProxySign(1);
				uploadSignInfoVOs.add(signInfoVO0);
			}

			uploadContract.setSignInfos(uploadSignInfoVOs.toArray(new UploadSignInfoVO[uploadSignInfoVOs.size()]));

			List<SignLocation> signLocations = uploadContractDTO.getSignLocations();
			List<SignLocationVO> signLocationVOs = new ArrayList<SignLocationVO>();
			for (SignLocation signLocation : signLocations) {
				SignLocationVO signLocationPlat = new SignLocationVO();
				BeanUtils.copyProperties(signLocation, signLocationPlat);
				signLocationVOs.add(signLocationPlat);
			}

			uploadContract.setSignLocations(signLocationVOs.toArray(new SignLocationVO[signLocationVOs.size()]));

			tx3203ReqVO.setHead(head);
			tx3203ReqVO.setUploadContract(uploadContract);
		}catch(Exception e){
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("上传合同模板组装报文时异常");
		}
		return tx3203ReqVO;
	}

	public static Tx3210ReqVO packet3210(ElectsignContract electsignContract) {
		Tx3210ReqVO tx3210ReqVO = new Tx3210ReqVO();
		HeadVO head = new HeadVO();
		head.setTxTime(DateUtil.getCurrentDateTime());

		ContractVO contract = new ContractVO();
		contract.setContractNo(electsignContract.getContractNo());

		tx3210ReqVO.setHead(head);
		tx3210ReqVO.setContract(contract);
		return tx3210ReqVO;
	}
}
