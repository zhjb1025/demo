package com.lycheepay.clearing.adapter.banks.anxinqian.util;

/**
 * 返回装换工具类
 */
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import cfca.trustsign.common.vo.cs.ContractVO;
import cfca.trustsign.common.vo.cs.CreateContractVO;
import cfca.trustsign.common.vo.cs.EnterpriseVO;
import cfca.trustsign.common.vo.cs.PersonVO;
import cfca.trustsign.common.vo.response.ErrorResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3001ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3002ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3101ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3102ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3201ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3202ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3203ResVO;
import cfca.trustsign.common.vo.response.tx3.Tx3210ResVO;

import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.JsonObjectMapper;
import com.lycheepay.clearing.adapter.banks.anxinqian.sdk.SystemConst;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.sign.AccountResultDTO;
import com.lycheepay.clearing.common.dto.sign.BatchContractResultDTO;
import com.lycheepay.clearing.common.dto.sign.ContractResultDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;


@Service
public class ResConvertUtil {

	public static AccountResultDTO parse3001(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		AccountResultDTO accountResultDTO = new AccountResultDTO();
		try {
			Tx3001ResVO tx3001ResVO = jsonObjectMapper.readValue(res, Tx3001ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3001ResVO != null && tx3001ResVO.getHead() != null) {
				accountResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
				PersonVO personVO = tx3001ResVO.getPerson();
				accountResultDTO.setChannelResponseMsg("个人开户成功");
				accountResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				Assert.notNull(personVO, BusinessCode.INVALID_PARAMETER, "安心签返回企业信息为空");
				accountResultDTO.setUserId(personVO.getUserId());
				accountResultDTO.setMobilePhone(personVO.getAnXinSignMobilePhone());
				accountResultDTO.setEmail(personVO.getAnXinSignEmail());
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				accountResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				accountResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				accountResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return accountResultDTO;
	}

	public static AccountResultDTO parse3002(JsonObjectMapper jsonObjectMapper, String res)
			throws ClearingAdapterBizCheckedException {
		AccountResultDTO accountResultDTO = new AccountResultDTO();
		try {
			Tx3002ResVO tx3002ResVO = jsonObjectMapper.readValue(res, Tx3002ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3002ResVO != null && tx3002ResVO.getHead() != null) {
				accountResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
				accountResultDTO.setChannelResponseMsg("企业开户成功");
				accountResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				EnterpriseVO enterpriseVO = tx3002ResVO.getEnterprise();
				Assert.notNull(enterpriseVO, BusinessCode.INVALID_PARAMETER, "安心签返回企业信息为空");
				accountResultDTO.setUserId(enterpriseVO.getUserId());
				accountResultDTO.setEmail(enterpriseVO.getAnXinSignEmail());
				accountResultDTO.setMobilePhone(enterpriseVO.getAnXinSignMobilePhone());
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				accountResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				accountResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				accountResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return accountResultDTO;
	}

	public static ClearingResultDTO parse3101(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
		try {
			Tx3101ResVO tx3101ResVO = jsonObjectMapper.readValue(res, Tx3101ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3101ResVO != null && tx3101ResVO.getHead() != null) {
				clearingResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
				clearingResultDTO.setChannelResponseMsg("申请验证码成功");
				clearingResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				clearingResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				clearingResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return clearingResultDTO;
	}

	public static ClearingResultDTO parse3102(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
		try {
			Tx3102ResVO tx3102ResVO = jsonObjectMapper.readValue(res, Tx3102ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3102ResVO != null && tx3102ResVO.getHead() != null) {
				clearingResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
				clearingResultDTO.setChannelResponseMsg("校验验证码成功");
				clearingResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				clearingResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				clearingResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return clearingResultDTO;
	}

	public static ContractResultDTO parse3201(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		ContractResultDTO contractResultDTO = new ContractResultDTO();
		try {
			Tx3201ResVO tx3201ResVO = jsonObjectMapper.readValue(res, Tx3201ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3201ResVO != null && tx3201ResVO.getHead() != null) {
				ContractVO contractVO = tx3201ResVO.getContract();
				if (contractVO != null) {
					int contractState = contractVO.getContractState();
					if(contractState == 1){
						contractResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
						contractResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
					}else{
						contractResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
						contractResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					}
					contractResultDTO.setChannelResponseMsg(SystemConst.CONTRACT_STATUS.get(contractState));
					contractResultDTO.setContractNo(contractVO.getContractNo());
					contractResultDTO.setFileId(contractVO.getFileId());
					contractResultDTO.setCreateTime(contractVO.getCreateTime());
					contractResultDTO.setContractState(contractVO.getContractState());
					contractResultDTO.setExpiredDate(contractVO.getExpiredDate());
				}
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				contractResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				contractResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				contractResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				contractResultDTO.setContractState(9);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return contractResultDTO;
	}

	public static BatchContractResultDTO parse3202(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		BatchContractResultDTO batchContractResultDTO = new BatchContractResultDTO();
		try {
			Tx3202ResVO tx3202ResVO = jsonObjectMapper.readValue(res, Tx3202ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3202ResVO != null && tx3202ResVO.getHead() != null) {
				batchContractResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
				batchContractResultDTO.setChannelResponseMsg("批量创建电子合同成功");
				batchContractResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				batchContractResultDTO.setBatchNo(tx3202ResVO.getBatchNo());
				CreateContractVO[] arrayContract = tx3202ResVO.getCreateContracts();
				List<ContractResultDTO> contractResults = new ArrayList<ContractResultDTO>();
				for (CreateContractVO contract : arrayContract) {
					ContractResultDTO contractResultDTO = new ContractResultDTO();
					contractResultDTO.setContractNo(contract.getContractNo());
					contractResults.add(contractResultDTO);
				}
				batchContractResultDTO.setContractResults(contractResults);
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				batchContractResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				batchContractResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				batchContractResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return batchContractResultDTO;
	}

	public static ContractResultDTO parse3203(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		ContractResultDTO contractResultDTO = new ContractResultDTO();
		try {
			Tx3203ResVO tx3203ResVO = jsonObjectMapper.readValue(res, Tx3203ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3203ResVO != null && tx3203ResVO.getHead() != null) {
				ContractVO contractVO = tx3203ResVO.getContract();
				if (contractVO != null) {
					int contractState = contractVO.getContractState();
					if(contractState == 1){
						contractResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
						contractResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
					}else{
						contractResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
						contractResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					}
					contractResultDTO.setChannelResponseMsg(SystemConst.CONTRACT_STATUS.get(contractState));
					contractResultDTO.setContractNo(contractVO.getContractNo());
					contractResultDTO.setFileId(contractVO.getFileId());
					contractResultDTO.setCreateTime(contractVO.getCreateTime());
					contractResultDTO.setExpiredDate(contractVO.getExpiredDate());
					contractResultDTO.setContractState(contractVO.getContractState());
				}
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				contractResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				contractResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				contractResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				contractResultDTO.setContractState(9);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return contractResultDTO;
	}

	public static ContractResultDTO parse3210(JsonObjectMapper jsonObjectMapper, String res) throws BizException {
		ContractResultDTO contractResultDTO = new ContractResultDTO();
		try {
			Tx3210ResVO tx3210ResVO = jsonObjectMapper.readValue(res, Tx3210ResVO.class);
			ErrorResVO errorResVO = null;
			if (tx3210ResVO != null && tx3210ResVO.getHead() != null) {
				contractResultDTO.setTxnStatus(PayState.TxnStatus.SUCCEED);
				contractResultDTO.setChannelResponseMsg("查询合同成功");
				contractResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				ContractVO contractVO = tx3210ResVO.getContract();
				if (contractVO != null) {
					String[] ignoreProperties = { "signatories" };
					BeanUtils.copyProperties(contractVO, contractResultDTO, ignoreProperties);
				}
			} else {
				errorResVO = jsonObjectMapper.readValue(res, ErrorResVO.class);
				contractResultDTO.setTxnStatus(PayState.TxnStatus.FAILED);
				contractResultDTO.setChannelResponseMsg(errorResVO.getErrorMessage());
				contractResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException("安心签服务异常,请联系开发人员");
		}
		return contractResultDTO;
	}
}
