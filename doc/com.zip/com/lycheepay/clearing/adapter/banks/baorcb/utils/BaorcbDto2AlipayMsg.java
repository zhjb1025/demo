package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.dom4j.Element;
import org.soofa.util.StringUtils;

import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.spdbXM.mobilePay.utils.RandomUtils;
import com.lycheepay.clearing.adapter.common.constant.biz.MobileMerchantState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BDsmDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPayRefundDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;

public class BaorcbDto2AlipayMsg {
	
	/**
	 *被扫- 支付宝刷卡支付
	 * @param bdsmDTO
	 * @param bankSendSn
	 * @return
	 * @throws BizException
	 */
	public static String micropayXMLBDsmMsg(BDsmDTO bdsmDTO, String bankSendSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		//随机字符串，不长于32位
		String nonce_str = RandomUtils.getRandomString(32);
		String tradeAmount = bdsmDTO.getAmount() == null ? "0" : bdsmDTO.getAmount().movePointRight(2).toString();
		try {
			
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element root = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(root, "merchant_trade_no", bankSendSn);
			if (Constants.aliPay.ALIPAY_SCENE_BAR_CODE_1.equals(bdsmDTO.getScene())) {
				dom4jxml.addNode(root, "scene", Constants.aliPay.ALIPAY_SCENE_BAR_CODE);
			} else if (Constants.aliPay.ALIPAY_SCENE_WAVE_CODE_2.equals(bdsmDTO.getScene())) {
				dom4jxml.addNode(root, "scene", Constants.aliPay.ALIPAY_SCENE_WAVE_CODE);
			} else {
				dom4jxml.addNode(root, "scene", Constants.aliPay.ALIPAY_SCENE_BAR_CODE);
			}
			dom4jxml.addNode(root, "auth_code", bdsmDTO.getAuthCode());
			dom4jxml.addNode(root, "subject", bdsmDTO.getTradeName());
			dom4jxml.addNode(root, "total_amount", tradeAmount);
			dom4jxml.addNode(root, "nonce_str", nonce_str);
			//数字签名
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("被扫- 支付宝刷卡支付请求报文:", dom4jxml.toString());
		return dom4jxml.toString();
	}
	/**
	 * 主动扫描-支付宝支付组装请求报文
	 * @param adsmDto
	 * @param bankSendSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 */
	public static String createZdsmAlipayMsg(ZDsmDTO zdsmDTO, String bankSendSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		//随机字符串，不长于32位
		String nonce_str = RandomUtils.getRandomString(32);
		String tradeAmount = zdsmDTO.getAmount() == null ? "0" : zdsmDTO.getAmount().movePointRight(2).toString();
		
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element root = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(root, "merchant_trade_no", bankSendSn);
			dom4jxml.addNode(root, "total_amount", tradeAmount);
			dom4jxml.addNode(root, "subject", zdsmDTO.getTradeName());
			dom4jxml.addNode(root, "timeout_express", channelParms.get(Constants.mobileparam.PAY_DEFAULT_TIME));
			
			dom4jxml.addNode(root, "notify_url", channelParms.get(Constants.mobileparam.CALL_BACK_URL));
			
			dom4jxml.addNode(root, "nonce_str", nonce_str);
			
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("主扫- 支付宝刷卡支付请求报文:", dom4jxml.toString());
		return dom4jxml.toString();
	}
	/**
	 * 窗口支付 - 报文
	 * @param jsapiPayDTO
	 * @param bankSendSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 */
	public static String createJsapiPayMsg(JsapiPayDTO jsapiPayDTO, String bankSendSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		//随机字符串，不长于32位
		String nonce_str = RandomUtils.getRandomString(32);
		String tradeAmount = jsapiPayDTO.getAmount() == null ? "0" : jsapiPayDTO.getAmount().movePointRight(2).toString();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element root = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(root, "merchant_trade_no", bankSendSn);
			dom4jxml.addNode(root, "total_amount", tradeAmount);
			dom4jxml.addNode(root, "buyer_id", jsapiPayDTO.getBuyer_id());
			dom4jxml.addNode(root, "subject", jsapiPayDTO.getTradeName());
			dom4jxml.addNode(root, "timeout_express", channelParms.get(Constants.mobileparam.PAY_DEFAULT_TIME));
			dom4jxml.addNode(root, "notify_url", channelParms.get(Constants.mobileparam.CALL_BACK_URL));
			
			dom4jxml.addNode(root, "nonce_str", nonce_str);
			
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("窗口 - 支付宝支付请求报文:", dom4jxml.toString());
		return dom4jxml.toString();
	}
	/**
	 * 支付宝 - 退款 - 报文
	 * @param zdPayRefundDTO
	 * @param bankSendSn
	 * @param oriBillNoSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 * 2018年2月2日 下午4:01:39
	 */
	public static String createZdPayRufundMsg(ZDPayRefundDTO zdPayRefundDTO, String bankSendSn, BillnoSn oriBillNoSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		//随机字符串，不长于32位
		String nonce_str = RandomUtils.getRandomString(32);
		String tradeAmount = zdPayRefundDTO.getAmount() == null ? "0" : zdPayRefundDTO.getAmount().movePointRight(2).toString();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element root = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(root, "merchant_trade_no", oriBillNoSn.getBankSendSn());
			dom4jxml.addNode(root, "refund_amount", tradeAmount);
			dom4jxml.addNode(root, "merchant_refund_no", bankSendSn);
			
			dom4jxml.addNode(root, "nonce_str", nonce_str);
			
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("窗口 - 支付宝支付请求报文:", dom4jxml.toString());
		return dom4jxml.toString();
	}
	
	/**
	 * 支付宝 - 退款查询 - 报文
	 * @param zdPayRefundDTO
	 * @param bankSendSn
	 * @param oriBillNoSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 * 2018年2月2日 下午4:01:39
	 */
	public static String createRefundRecordMsg(BillnoSn billNoSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		//随机字符串，不长于32位
		String nonce_str = RandomUtils.getRandomString(32);
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element root = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(root, "merchant_trade_no", billNoSn.getBankPaySn());
			dom4jxml.addNode(root, "merchant_refund_no", billNoSn.getBankSendSn());
			
			dom4jxml.addNode(root, "nonce_str", nonce_str);
			
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("窗口 - 支付宝支付请求报文:", dom4jxml.toString());
		return dom4jxml.toString();
	}
	
	/**
	 * 支付宝 - 订单 - 报文
	 * @param zdPayRefundDTO
	 * @param bankSendSn
	 * @param oriBillNoSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 * 2018年2月2日 下午4:01:39
	 */
	public static String createSingleRecordMsg(BillnoSn billNoSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		//随机字符串，不长于32位
		String nonce_str = RandomUtils.getRandomString(32);
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element root = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(root, "merchant_trade_no", billNoSn.getBankSendSn());
//			dom4jxml.addNode(root, "refund_no", billNoSn.getBankRecvSn());
			
			dom4jxml.addNode(root, "nonce_str", nonce_str);
			
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("窗口 - 支付宝支付请求报文:", dom4jxml.toString());
		return dom4jxml.toString();
	}
	
}	
