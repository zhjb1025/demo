package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.dto.trade.BDsmResultDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayResultDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPTradeResultDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmResultDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;

public class Msg2Dto {
		
	/**
	 * 支付宝被动扫码报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static BDsmResultDTO parseAliMsgBdsm(String resultMsg, BDsmResultDTO bdsmResultDTO, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("支付宝 被动扫码报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String trade_no = "";
		try { 
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String sign = helper.getNodeText("/xml/sign");												//	MD5 签名结果，
				 String err_code = helper.getNodeText("/xml/err_code");										//参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								//结果信息描述
				 String nonce_str = helper.getNodeText("xml/nonce_str");							//结果信息描述
				 String sign_type = helper.getNodeText("xml/sign_type");
				 if ("SUCCESS".equals(result_code)) {
					 String alipay_trade_no = helper.getNodeText("/xml/alipay_trade_no");							//商户订单号
					 trade_no = helper.getNodeText("/xml/trade_no");						//UCHANG交易号
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								//总金额，以分为单位，不允许包含任何字、 符号
					 String buyer_logon_id = helper.getNodeText("/xml/buyer_logon_id");										//用户支付宝的账户名
					 String buyer_user_id = helper.getNodeText("/xml/buyer_user_id");
					 String pay_info = helper.getNodeText("/xml/pay_info");
					 String total_amount = helper.getNodeText("/xml/total_amount");							//支付完成时间，格式为 yyyyMMddHHmmss，
					 String point_amount = helper.getNodeText("/xml/point_amount");										//商家数据包
					 String buyer_pay_amount = helper.getNodeText("/xml/buyer_pay_amount");
					 String fund_bill_list = helper.getNodeText("/xml/fund_bill_list");
					 String end_date = helper.getNodeText("/xml/end_date");
					 String end_time = helper.getNodeText("/xml/buyer_pay_amount");
					 bdsmResultDTO.setTxnStatus(TxnStatus.SUCCEED);
					 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
					 bdsmResultDTO.setTransactionId(trade_no);
//					 if ("CNL00000".equals(err_code)) {
//						 bdsmResultDTO.setChannelResponseMsg("交易未知");
//					 }
					 if(!StringUtils.isEmpty(total_amount)){
						 //返回单位 元
						 bdsmResultDTO.setActualAmount((new BigDecimal(total_amount)).movePointLeft(2));
					 }
				 } else {
					 if ("CNL00002".equals(err_code) || "CNL00003".equals(err_code)) {
						 bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
					} else {
						Log4jUtil.error("支付宝被动扫码交易失败");
						bdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
						bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
					}
				 }
				 if(!StringUtils.isEmpty(err_code_des)){
					 bankMsg = err_code_des;
					 bankCode = err_code;
				 }
				 bdsmResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 bdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
				 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 bdsmResultDTO.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
			 if (!StringUtils.isEmpty(trade_no)) {
				 bdsmResultDTO.setTransactionId(trade_no);
			 }
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return bdsmResultDTO;
	}
	
	/**
	 * 微信被动扫码报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static BDsmResultDTO parseMsgWechatBdsm(String resultMsg, BDsmResultDTO bdsmResultDTO, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("微信 被动扫码报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String trade_no = "";
		try {
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");											//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//业务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String rece_org_no = helper.getNodeText("/xml/rece_org_no"); 
				 String merchant_id = helper.getNodeText("/xml/merchant_id"); 
				 
				 //商户号，由UCHANG分配
				 String nonce_str = helper.getNodeText("/xml/nonce_str");										//随机字符串，不长于 32 位
				 String sign = helper.getNodeText("/xml/sign");													//	MD5 签名结果，详见“第 4 章 MD5 签名规则”
				 String err_code = helper.getNodeText("/xml/err_code");										    //参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");									//结果信息描述									//结果信息描述
				 String trade_state_desc = helper.getNodeText("/xml/trade_state_desc");
				 trade_no = helper.getNodeText("/xml/trade_no");
				 if("SUCCESS".equals(result_code)){
					 String trade_type = helper.getNodeText("/xml/trade_type");								//用户是否关注公众账号，仅在公众账号类型支付有效，取值范围：Y或N;Y-关注;N-未关注
					 String bank_type = helper.getNodeText("/xml/bank_type");						//用户是否关注子公众账号，仅在公众账号类型支付有效，取值范围：Y或N;Y-关注;N-未关注	
					 String fee_type = helper.getNodeText("/xml/fee_type");									//MICROPAY
					 String total_fee = helper.getNodeText("/xml/total_fee");									//总金额，以分为单位，不允许包含任何字、符号
					 String cash_fee = helper.getNodeText("/xml/cash_fee");								//商户系统内部的定单号，32 个字符内、可包含字母
					 String wechat_trade_no = helper.getNodeText("/xml/wechat_trade_no");
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");
					 String end_date = helper.getNodeText("/xml/end_date");
					 String End_time = helper.getNodeText("/xml/End_time");
					 
					 bdsmResultDTO.setTxnStatus(TxnStatus.SUCCEED);
					 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
					 bdsmResultDTO.setTransactionId(trade_no);
//					 if ("CNL00000".equals(err_code)) {
//						 bdsmResultDTO.setChannelResponseMsg(err_code_des);
//					 }
					 if(!StringUtils.isEmpty(total_fee)){
						 //返回单位 元
						 bdsmResultDTO.setActualAmount((new BigDecimal(total_fee)).movePointLeft(2));
					 }
					 
				 }else{
					 if("CNL00002".equals(err_code) || "CNL00003".equals(err_code)){
						 bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
						 bdsmResultDTO.setChannelResponseMsg(err_code_des);
					 }else{
						 Log4jUtil.error("微信被动扫码-响应交易失败");
						 bdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
						 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
						 bdsmResultDTO.setChannelResponseMsg(err_code_des);
					 }
				 }
				 
				 if(!StringUtils.isEmpty(err_code_des)){
					 //微信 特殊 处理
					 if(!StringUtils.isEmpty(trade_state_desc)){
						 bankMsg = trade_state_desc;
					 }else{
						 bankMsg = err_code_des;
					 }
					 bankCode = err_code;
				 }
				 bdsmResultDTO.setChannelResponseMsg(bankMsg);
			 }else{
				 bdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
				 bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 bdsmResultDTO.setChannelResponseMsg(bankMsg);
			 }
			 
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
			 
			 bdsmResultDTO.setTransactionId(trade_no);
//			 Log4jUtil.info("微信被动扫码报文解析:", bdsmResultDTO);
		} catch (BizException e) {
			Log4jUtil.error("微信被动扫码报文解析异常【{}】", e);
			throw e;
		}
		 return bdsmResultDTO;
	}
	
	/**
	 * 支付宝主动扫码报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ZDsmResultDTO parseAliMsgZdsm(String resultMsg, ZDsmResultDTO zdsmResultDTO, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("支付宝报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String trade_no = "";
		try { 
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String sign = helper.getNodeText("/xml/sign");												//	MD5 签名结果，
				 String err_code = helper.getNodeText("/xml/err_code");										//参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								//结果信息描述
				 String nonce_str = helper.getNodeText("xml/nonce_str");							//结果信息描述
				 String sign_type = helper.getNodeText("xml/sign_type");
				 if ("SUCCESS".equals(result_code)) {
					 String alipay_trade_no = helper.getNodeText("/xml/alipay_trade_no");							//商户订单号
					 trade_no = helper.getNodeText("/xml/trade_no");
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								//总金额，以分为单位，不允许包含任何字、 符号
					 String total_amount = helper.getNodeText("/xml/total_amount");
					 String pay_info = helper.getNodeText("/xml/pay_info");
					 String qr_code = helper.getNodeText("/xml/qr_code");
					 zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					 zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
					 zdsmResultDTO.setTransactionId(alipay_trade_no);
					 zdsmResultDTO.setCodeUrl(qr_code);
					 bankMsg = "等待用户支付";
				 } else {
					 zdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
					 zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 }
				 if(!StringUtils.isEmpty(err_code_des)){
					 bankMsg = err_code_des;
				 }
				 if(!StringUtils.isEmpty(err_code)){
					 bankCode = err_code;
				 }
				 zdsmResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 zdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
				 zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 zdsmResultDTO.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return zdsmResultDTO;
	}
	
	/**
	 * 微信主动扫码报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ZDsmResultDTO parseWxMsgZdsm(String resultMsg, ZDsmResultDTO zdsmResultDTO, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("微信 报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String err_code_des = "";
		try { 
			 helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//业务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String rece_org_no = helper.getNodeText("/xml/rece_org_no"); 
				 String merchant_id = helper.getNodeText("/xml/merchant_id"); 
				 //商户号，由UCHANG分配
				 String nonce_str = helper.getNodeText("/xml/nonce_str");										//随机字符串，不长于 32 位
				 String sign = helper.getNodeText("/xml/sign");													//	MD5 签名结果，详见“第 4 章 MD5 签名规则”
				 String err_code = helper.getNodeText("/xml/err_code");										    //参考错误码
				 err_code_des = helper.getNodeText("/xml/err_code_des");
				 if ("SUCCESS".equals(result_code)) {
					 String trade_type = helper.getNodeText("/xml/trade_type");								//总金额，以分为单位，不允许包含任何字、 符号
					 String prepay_id = helper.getNodeText("/xml/prepay_id");//支付完成时间，格式为 yyyyMMddHHmmss，
					 String code_url = helper.getNodeText("/xml/code_url");
					 zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					 zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
					 zdsmResultDTO.setPrepayId(prepay_id);
					 zdsmResultDTO.setCodeUrl(code_url);
//					 if ("CNL00000".equals(err_code)) {
//						  zdsmResultDTO.setChannelResponseMsg("响应报文解析成功！");
//					 }
				 } else {
					zdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
					zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 }
				 zdsmResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 Log4jUtil.error("响应报文解析失败");
				 zdsmResultDTO.setTxnStatus(TxnStatus.FAILED);
				 zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 zdsmResultDTO.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return zdsmResultDTO;
	}
	
	/**
	 * 支付宝 - 窗口 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static JsapiPayResultDTO parseJsapiAliMsg(String resultMsg, JsapiPayResultDTO jsapiPayResultDTO, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("支付宝报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String trade_no = "";
		try { 
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 String pay_info = "";
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String sign = helper.getNodeText("/xml/sign");												//	MD5 签名结果，
				 String err_code = helper.getNodeText("/xml/err_code");										//参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								//结果信息描述
				 String nonce_str = helper.getNodeText("xml/nonce_str");							//结果信息描述
				 String sign_type = helper.getNodeText("xml/sign_type");
				 if ("SUCCESS".equals(result_code)) {
					 String alipay_trade_no = helper.getNodeText("/xml/alipay_trade_no");							//商户订单号
					 trade_no = helper.getNodeText("/xml/trade_no");
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								//总金额，以分为单位，不允许包含任何字、 符号
					 String total_amount = helper.getNodeText("/xml/total_amount");
					 pay_info = helper.getNodeText("/xml/pay_info");
					 String qr_code = helper.getNodeText("/xml/qr_code");
					 jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					 jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
					//解析json字符串成主动平台  对应字段
					 JSONObject dataJson = JSONObject.parseObject(pay_info);
					 Map<String, String> jsonMap = new HashMap<String, String>();
					 jsonMap.put("tradeNO", dataJson.get("trade_no").toString());
					 String js_prepay_info = com.alibaba.fastjson.JSONObject.toJSONString(jsonMap);
					 jsapiPayResultDTO.setJs_prepay_info(js_prepay_info);
//					 if ("CNL00000".equals(err_code)) {
//						 jsapiPayResultDTO.setChannelResponseMsg("响应报文解析成功！");
//					 }
					 jsapiPayResultDTO.setTransactionId(alipay_trade_no);
				 } else {
					jsapiPayResultDTO.setTxnStatus(TxnStatus.FAILED);
					jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 }
				 if(!StringUtils.isEmpty(err_code_des)){
					 bankMsg = err_code_des;
					 bankCode = err_code;
				 }
//				 if(!StringUtils.isEmpty(err_message)){
//					 bankMsg = err_message;
//					 bankCode = err_code;
//				 }
				 jsapiPayResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 jsapiPayResultDTO.setTxnStatus(TxnStatus.FAILED);
				 jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 jsapiPayResultDTO.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
			 if (!StringUtils.isEmpty(trade_no)) {
				 jsapiPayResultDTO.setTransactionId(trade_no);
			 }
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return jsapiPayResultDTO;
	}
	/**
	 * 微信 - 公众号 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static JsapiPayResultDTO parseJsapiWxMsg(String resultMsg, JsapiPayResultDTO jsapiPayResultDTO, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("微信 报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		try { 
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 String pay_info = "";
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String sign = helper.getNodeText("/xml/sign");												//	MD5 签名结果，
				 String err_code = helper.getNodeText("/xml/err_code");										//参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								//结果信息描述
				 String nonce_str = helper.getNodeText("xml/nonce_str");							//结果信息描述
				 String sign_type = helper.getNodeText("xml/sign_type");
				 if ("SUCCESS".equals(result_code)) {
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								//总金额，以分为单位，不允许包含任何字、 符号
					 String total_amount = helper.getNodeText("/xml/total_amount");
					 pay_info = helper.getNodeText("/xml/pay_info");
					 String prepay_id = helper.getNodeText("/xml/prepay_id");
					 jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					 jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
//					 jsapiPayResultDTO.setTransactionId(prepay_id);
					 jsapiPayResultDTO.setPrepayId(prepay_id);
					 jsapiPayResultDTO.setJs_prepay_info(pay_info);
//					 if ("CNL00000".equals(err_code)) {
//						 jsapiPayResultDTO.setChannelResponseMsg("响应报文解析成功！");
//					 }
				 } else {
					jsapiPayResultDTO.setTxnStatus(TxnStatus.FAILED);
					jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
//					jsapiPayResultDTO.setChannelResponseMsg("响应报文解析结果不通过");
				 }
				 jsapiPayResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 jsapiPayResultDTO.setTxnStatus(TxnStatus.FAILED);
				 jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 jsapiPayResultDTO.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return jsapiPayResultDTO;
	}
	
	/**
	 * 支付宝 - 退款 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ClearingResultDTO parseZdPayRefundAliMsg(String resultMsg, ClearingResultDTO resultDto, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("支付宝报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		try {
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String err_code = helper.getNodeText("/xml/err_code");										//参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								//结果信息描述
				 if ("SUCCESS".equals(result_code)) {
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								//总金额，以分为单位，不允许包含任何字、 符号
					 String trade_no = helper.getNodeText("/xml/trade_no");
					 String refund_no = helper.getNodeText("/xml/refund_no");
					 String merchant_refund_no = helper.getNodeText("/xml/merchant_refund_no");
					 String fund_change = helper.getNodeText("/xml/fund_change");
					 String refund_fee = helper.getNodeText("/xml/refund_fee");
					 String gmt_refund_pay = helper.getNodeText("/xml/gmt_refund_pay");
					 updateBillnoSn.setActualAmount(new BigDecimal(refund_fee).movePointLeft(2));
					 updateBillnoSn.setBankRecvSn(refund_no);
					 resultDto.setTxnStatus(TxnStatus.SUCCEED);
					 resultDto.setChannelResponseCode(TransReturnCode.code_0000);
					 resultDto.setChannelResponseMsg("退款成功");
				 } else {
//					 if ("CNL00002".equals(err_code)) {
//						 resultDto.setTxnStatus(TxnStatus.UNKNOW);
//						 resultDto.setChannelResponseCode(TransReturnCode.code_9109);
//						 resultDto.setChannelResponseMsg(err_code_des);
//					} else {
						resultDto.setTxnStatus(TxnStatus.FAILED);
						resultDto.setChannelResponseCode(TransReturnCode.code_9900);
						resultDto.setChannelResponseMsg(err_code_des);
//					}
				 }
				 if(!StringUtils.isEmpty(err_code_des)){
					 bankMsg = err_code_des;
					 bankCode = err_code;
				 }
			 } else {
				 resultDto.setTxnStatus(TxnStatus.FAILED);
				 resultDto.setChannelResponseCode(TransReturnCode.code_9900);
				 resultDto.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
			 
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return resultDto;
	}
	
	/**
	 * 微信 - 退款 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ClearingResultDTO parseZdPayRefundWxMsg(String resultMsg, ClearingResultDTO resultDto, BillnoSn updateBillnoSn) throws BizException {
		Log4jUtil.info("微信 报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		try {
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
			 String return_msg = helper.getNodeText("/xml/return_msg");										//返回信息，如非空，为错误原因签名失败参 数格式校验错误
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										//务返回结果，SUCCESS 表示成功 FAIL 表示失败
				 String err_code = helper.getNodeText("/xml/err_code");										//参考错误码
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								//结果信息描述
				 if ("SUCCESS".equals(result_code)) {
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								//总金额，以分为单位，不允许包含任何字、 符号
					 String trade_no = helper.getNodeText("/xml/trade_no");
					 String refund_no = helper.getNodeText("/xml/refund_no");
					 String merchant_refund_no = helper.getNodeText("/xml/wechat_refund_no");
					 String total_fee = helper.getNodeText("/xml/total_fee");
					 String settlement_refund_fee = helper.getNodeText("/xml/settlement_refund_fee");
					 
					 setterBillonSnAmount(isExist(settlement_refund_fee), updateBillnoSn, settlement_refund_fee);
					 updateBillnoSn.setBankRecvSn(refund_no);
					 updateBillnoSn.setAmount(new BigDecimal(total_fee).movePointLeft(2));
					 if(!StringUtils.isEmpty(err_code_des)){
						 bankMsg = err_code_des;
						 bankCode = err_code;
					 }
					 resultDto.setTxnStatus(TxnStatus.SUCCEED);
					 resultDto.setChannelResponseCode(TransReturnCode.code_0000);
					 resultDto.setChannelResponseMsg("退款成功");
				 }else{
//					 if ("CNL00002".equals(err_code)) {
//						 resultDto.setTxnStatus(TxnStatus.UNKNOW);
//						 resultDto.setChannelResponseCode(TransReturnCode.code_9109);
//						 resultDto.setChannelResponseMsg(err_code_des);
//					} else {
						resultDto.setTxnStatus(TxnStatus.FAILED);
						resultDto.setChannelResponseCode(TransReturnCode.code_9900);
						resultDto.setChannelResponseMsg(err_code_des);
//					}
				 }
//					 resultDto.setTxnStatus(TxnStatus.SUCCEED);
//					 resultDto.setChannelResponseCode(TransReturnCode.code_0000);
//					 if ("CNL00000".equals(err_code)) {
//						 resultDto.setChannelResponseMsg("响应报文解析成功！");
//					 }
			 } else {
				 resultDto.setTxnStatus(TxnStatus.FAILED);
				 resultDto.setChannelResponseCode(TransReturnCode.code_9900);
				 resultDto.setChannelResponseMsg(bankMsg);
			 }
			 //存银行返回信息
			 updateBillnoSn.setChannelRtncode(bankCode);
			 updateBillnoSn.setChannelRtnnote(bankMsg);
			 
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return resultDto;
	}
	
	/**
	 * 支付宝 - 退款查询 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ZDPTradeResultDTO parseAliRefundQueryMsg(String resultMsg, ZDPTradeResultDTO zdpTradeResultDTO) throws BizException {
		Log4jUtil.info("支付宝退款查询报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper = null;
		String bankMsg = "";
		String trade_no = "";
		try {
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										
			 String return_msg = helper.getNodeText("/xml/return_msg");										
			 bankMsg = return_msg;
//			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										
				 String err_code = helper.getNodeText("/xml/err_code");										
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								
				 if ("SUCCESS".equals(result_code)) {
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								
					 trade_no = helper.getNodeText("/xml/trade_no");
					 String refund_no = helper.getNodeText("/xml/refund_no");
					 String merchant_refund_no = helper.getNodeText("/xml/merchant_refund_no");
					 String fund_change = helper.getNodeText("/xml/fund_change");
					 String refund_fee = helper.getNodeText("/xml/refund_fee");
					 String gmt_refund_pay = helper.getNodeText("/xml/gmt_refund_pay");
					 String wechat_refund_no = helper.getNodeText("/xml/wechat_refund_no");
					 zdpTradeResultDTO.setActualAmount(new BigDecimal(refund_fee).movePointLeft(2));
					 zdpTradeResultDTO.setTransactionId(wechat_refund_no);
					 zdpTradeResultDTO.setTxnStatus(TxnStatus.SUCCEED);
					 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				 } else {
					 zdpTradeResultDTO.setTxnStatus(TxnStatus.FAILED);
					 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				 }
				 if(!StringUtils.isEmpty(err_code_des)){
					 bankMsg = err_code_des;
//					 bankCode = err_code;
				 }
				 zdpTradeResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				 zdpTradeResultDTO.setChannelResponseMsg("交易结果未知,请稍后查询");
			 }
//			 billnoSn.setChannelRtncode(bankCode);
//			 billnoSn.setChannelRtnnote(bankMsg);
			 zdpTradeResultDTO.setTransactionId(trade_no);
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return zdpTradeResultDTO;
	}
	
	/**
	 * 支付宝 - 订单查询 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ZDPTradeResultDTO parseAliSingleQueryMsg(String resultMsg, ZDPTradeResultDTO zdpTradeResultDTO, BillnoSn billnoSn) throws BizException {
		Log4jUtil.info("支付宝退款查询报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String tmp_err_code_msg = "交易结果未知";
		try {
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										
			 String return_msg = helper.getNodeText("/xml/return_msg");										
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										
				 String err_code = helper.getNodeText("/xml/err_code");										
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								
				 if ("SUCCESS".equals(result_code)) {
					 String alipay_trade_no = helper.getNodeText("/xml/alipay_trade_no");								
					 String trade_no = helper.getNodeText("/xml/trade_no");
					 String refund_no = helper.getNodeText("/xml/refund_no");
					 String merchant_refund_no = helper.getNodeText("/xml/merchant_refund_no");
					 String trade_status = helper.getNodeText("/xml/trade_status");
					 String total_amount = helper.getNodeText("/xml/total_amount");
					 String buyer_pay_amount = helper.getNodeText("/xml/buyer_pay_amount");
					 String end_date = helper.getNodeText("/xml/end_date");
					 String end_time = helper.getNodeText("/xml/end_time");
					 if (!StringUtils.isBlank(alipay_trade_no)) {
						 zdpTradeResultDTO.setTransactionId(alipay_trade_no);
						 billnoSn.setBankRecvSn(alipay_trade_no);
					 } else {
						 zdpTradeResultDTO.setTransactionId(trade_no);
						 billnoSn.setBankRecvSn(trade_no);
					 }
					 zdpTradeResultDTO.setActualAmount(new BigDecimal(total_amount).movePointLeft(2));
					 if ("SUCCESS".equals(trade_status)) {
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.SUCCEED);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
						 tmp_err_code_msg = "交易成功";
					 }else if("DEAL".equals(trade_status)){
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
						 tmp_err_code_msg = "等待用户支付";
					 }else if("FAIL".equals(trade_status) || "CLOSE".equals(trade_status)){
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.FAILED);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
						 tmp_err_code_msg = "交易失败";
					 }else{
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
						 tmp_err_code_msg = "交易未知";
					 }
				 } else {
					zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					err_code_des = "交易未知";
				 }
				 if(StringUtils.isBlank(err_code_des)){
					 err_code_des = tmp_err_code_msg;
				 }
				 zdpTradeResultDTO.setChannelResponseMsg(err_code_des);
			 } else {
				 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				 zdpTradeResultDTO.setChannelResponseMsg("响应报文解析结果不通过");
				 return zdpTradeResultDTO;
			 }
			 
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return zdpTradeResultDTO;
	}
	
	/**
	 * 微信 - 退款查询 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ZDPTradeResultDTO parseWxRefundQueryMsg(String resultMsg, ZDPTradeResultDTO zdpTradeResultDTO) throws BizException {
		Log4jUtil.info("支付宝退款查询报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		try { 
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										
			 String return_msg = helper.getNodeText("/xml/return_msg");										
			 bankMsg = return_msg;
			 bankCode = return_code;
			 String trade_no = "";
			 String tmp_err_code_msg = "交易结果未知";
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										
				 String err_code = helper.getNodeText("/xml/err_code");										
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								
				 if ("SUCCESS".equals(result_code)) {
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");								
					 trade_no = helper.getNodeText("/xml/trade_no");
					 String refund_no = helper.getNodeText("/xml/refund_no");
					 String merchant_refund_no = helper.getNodeText("/xml/merchant_refund_no");
					 String refund_success_time = helper.getNodeText("/xml/refund_success_time");//退款成功时间
					 String refund_status = helper.getNodeText("/xml/refund_status");//退款状态
					 String refund_fee = helper.getNodeText("/xml/refund_fee");//申请退款金额
					 String settlement_refund_fee = helper.getNodeText("/xml/settlement_refund_fee");//退款金额
					 zdpTradeResultDTO.setTxnStatus(TxnStatus.SUCCEED);
					 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
//					 if ("CNL00000".equals(err_code)) {
//						 zdpTradeResultDTO.setChannelResponseMsg("响应报文解析成功！");
//					 }
					 if ("SUCCESS".equals(refund_status)) {
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.SUCCEED);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
						 tmp_err_code_msg = "退款成功";
					 } else if ("REFUNDCLOSE".equals(refund_status) || "CHANGE".equals(refund_status)) {
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.FAILED);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
						 tmp_err_code_msg = "退款失败";
					 } else if ("PROCESSING".equals(refund_status)) {
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
						 tmp_err_code_msg = "退款处理中";
					 }
					 if(!StringUtils.isEmpty(refund_fee)){
						  zdpTradeResultDTO.setActualAmount(new BigDecimal(refund_fee).movePointLeft(2));
					  }
				 } else {
					 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				 }
				 if(!StringUtils.isEmpty(err_code_des)){
					 bankMsg = err_code_des;
					 bankCode = err_code;
				 } else {
					 bankMsg = tmp_err_code_msg;
				 }
				 zdpTradeResultDTO.setChannelResponseMsg(bankMsg);
			 } else {
				 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				 zdpTradeResultDTO.setChannelResponseMsg("交易结果未知,请稍后查询");
			 }
			 zdpTradeResultDTO.setTransactionId(trade_no);
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return zdpTradeResultDTO;
	}
	
	/**
	 * 微信 - 订单查询 - 报文解析
	 * @param resultMsg
	 * @return
	 * @throws BizException 
	 */
	public static ZDPTradeResultDTO parseWxSingleQueryMsg(String resultMsg, ZDPTradeResultDTO zdpTradeResultDTO) throws BizException {
		Log4jUtil.info("支付宝退款查询报文处理 resultMsg:【{}】", resultMsg);
		Dom4jXMLMessage helper;
		String bankMsg = "";
		String bankCode = "";
		String trade_status = "";
		String tmp_err_code_msg = "交易结果未知";
		try { 
			helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
			 String return_code = helper.getNodeText("/xml/return_code");										
			 String return_msg = helper.getNodeText("/xml/return_msg");										
			 bankMsg = return_msg;
			 bankCode = return_code;
			 if("SUCCESS".equals(return_code)){
				 String result_code = helper.getNodeText("/xml/result_code");										
				 String err_code = helper.getNodeText("/xml/err_code");										
				 String err_code_des = helper.getNodeText("/xml/err_code_des");								
				 if ("SUCCESS".equals(result_code)) {
					 String trade_type = helper.getNodeText("/xml/trade_type");								
					 trade_status = helper.getNodeText("/xml/trade_state");
					 String trade_state_desc = helper.getNodeText("/xml/trade_state_desc");
					 String detail = helper.getNodeText("/xml/detail");
					 String end_date = helper.getNodeText("/xml/end_date");//退款成功时间
					 String End_time = helper.getNodeText("/xml/End_time");//退款状态
					 String trade_no = helper.getNodeText("/xml/trade_no");//申请退款金额
					 String merchant_trade_no = helper.getNodeText("/xml/merchant_trade_no");//退款金额
					 zdpTradeResultDTO.setTransactionId(trade_no);
					 if ("SUCCESS".equals(trade_status)) {
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.SUCCEED);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
						 tmp_err_code_msg = "交易成功";
					 }else if("DEAL".equals(trade_status)){
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9110);
						 tmp_err_code_msg = "等待用户支付";
					 }else if("FAIL".equals(trade_status) || "CLOSE".equals(trade_status)){
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.FAILED);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
						 tmp_err_code_msg = "交易失败";
					 }else{
						 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
						 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
						 tmp_err_code_msg = "交易未知";
					 }
				 } else {
					zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdpTradeResultDTO.setChannelResponseMsg(StringUtils.isBlank(return_msg)?"交易结果未知":return_msg);
				 }
				 if(StringUtils.isBlank(err_code_des)){
					 err_code_des = tmp_err_code_msg;
				 }
				 zdpTradeResultDTO.setChannelResponseMsg(err_code_des);
			 } else {
				 zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				 zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				 zdpTradeResultDTO.setChannelResponseMsg("交易结果未知,请稍后查询");
			 }
		} catch (BizException e) {
			Log4jUtil.error("被动扫码报文解析异常【{}】", e);
			throw e;
		}
		return zdpTradeResultDTO;
	}
	
	public static boolean isExist(String val){
		if (StringUtils.isEmpty(val)) {
			return false;
		}
		return true;
	}
	
	public static void setterBillonSnAmount(boolean flag, BillnoSn billnoSn, String val){
		if (flag) 
			billnoSn.setActualAmount(new BigDecimal(val).movePointLeft(2));
	}
}
