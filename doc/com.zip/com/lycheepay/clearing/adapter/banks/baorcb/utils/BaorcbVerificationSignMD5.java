package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import oracle.net.aso.s;

import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.gdb.utils.Constants.status;
import com.lycheepay.clearing.adapter.banks.helipay.utils.Constants.channelParam;
import com.lycheepay.clearing.adapter.banks.spdbXM.mobilePay.utils.MD5Utils;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.util.Log4jUtil;

public class BaorcbVerificationSignMD5 {
	
	/**
	 * 验签处理  成功返回true  失败返回false(不对参数 个数进行限制，不知道参数 名，也可以使用)
	 * @param resultMsg  xml串
	 * @param channelParms  渠道 信息
	 * @return
	 * @throws BizException
	 * @throws UnsupportedEncodingException
	 */
	public static boolean micropayVerificationAllSignMD5(String resultMsg, Map<String, String> channelParms) throws BizException {
		 Map<String, String> map = new HashMap<String, String>();
		 Log4jUtil.info(">>>>>>解签前resultMsg:【{}】", resultMsg);
		 Dom4jXMLMessage helper;
		 helper = Dom4jXMLMessage.parse(resultMsg.getBytes());
		 map = helper.getChildNodeMap("xml");
		 String sign = helper.getNodeText("/xml/sign");
		 Log4jUtil.info("-------原sSign------:【{}】", sign);
		 try {
			//验签-提取签名
			 String verificationSign = BaorcbSignMd5.packSign(helper, channelParms.get(Constants.mobileparam.rece_org_key));
			 Log4jUtil.info("-------新verificationSign------:【{}】", verificationSign);
			 if (StringUtils.isBlank(sign) || !verificationSign.equals(sign)) {
				 Log4jUtil.info("XXXXXX参数非法,报文验参错误");
				 return false;
			 } else {
				 Log4jUtil.info("<<<<<<验参成功"); 
				 return true;
			}
		 } catch (Exception e) {
		     Log4jUtil.error("报文验签异常【{}】", e);
			 return false;
		 }
	}
	
	/**
     * 
     * 方法用途: 对所有传入参数按照字段名的 ASCII 码从小到大排序（字典序），并且生成url参数串<br>
     * 实现步骤: <br>
     * 
     * @param paraMap   要排序的Map对象
     * @param urlEncode   是否需要URLENCODE
     * @param keyToLower    是否需要将Key转换为全小写
     * true:key转化成小写，false:不转化
     * @return
     */
    public static String formatUrlMap(Map<String, String> paraMap, boolean urlEncode, boolean keyToLower) {
    	String buff = "";
        Map<String, String> tmpMap = paraMap;
        try {
        	List<Map.Entry<String, String>> infoIds = new ArrayList<Map.Entry<String, String>>(tmpMap.entrySet());
            // 对所有传入参数按照字段名的 ASCII 码从小到大排序（字典序）
            Collections.sort(infoIds, new Comparator<Map.Entry<String, String>>()
            {
                @Override
                public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2)
                {
                    return (o1.getKey()).toString().compareTo(o2.getKey());
                }
            });
         // 构造URL 键值对的格式
            StringBuilder buf = new StringBuilder();
            for (Map.Entry<String, String> item : infoIds)
            {
                if (!StringUtils.isEmpty(item.getValue()) && (item.getKey() != "sign"))
                {
                    String key = item.getKey();
                    String val = item.getValue();
                    if (urlEncode)
                        val = URLEncoder.encode(val, Constants.charset);
                    if (keyToLower)
                        buf.append(key.toLowerCase() + "=" + val);
                    else
                        buf.append(key + "=" + val);
                    buf.append("&");
                }
            }
            buff = buf.toString();
            if (!buff.isEmpty()) 
				buff = buff.substring(0, buff.length()-1);
		} catch (Exception e) {
			return null;
		}
        return buff ;
    }
}
