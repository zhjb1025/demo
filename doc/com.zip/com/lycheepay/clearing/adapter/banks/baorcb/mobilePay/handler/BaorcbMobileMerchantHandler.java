package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.handler;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.service.BaorcbMobileMerchantService;
import com.lycheepay.cif.constant.CustTypeConstant;
import com.lycheepay.cif.dto.agent.QueryMerchantResponseDTO;
import com.lycheepay.cif.service.OuterMerchantService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.MobileMerchantState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.MobileMenchartInfoService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.MobileProvinceCode;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 *  商户入驻服务类
 * @author zmm
 *
 */
@Service(ClearingAdapterAnnotationName.BAORCB_MOBILE_MERCHANTH_HANDLER)
public class BaorcbMobileMerchantHandler extends AbstractChannelService {
	
	@Autowired
	@Qualifier("cif.outerMerchantService")
	private OuterMerchantService outerMerchantService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BAORCB_MOBILE_MERCHANTH_SERVICE)
	private BaorcbMobileMerchantService baorcbMobileMerchantService;
		
	@Autowired
	private MobileMenchartInfoService mobileMenchartInfoService;
		
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	public final static String channelId = ChannelIdEnum.BAORCB_MOBILE_PAY.getCode();
	
	@Override
	public ClearingResultDTO report(String bizId, String merchantId) {
		Log4jUtil.setLogClass("BAORCB", "report");
		Log4jUtil.info("包头农商银行移动支付-商户进件传入参数：bizId:【{}】 , merchantId:【{}】 ", bizId, merchantId);
		ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
		
		try {
			//查询商户信息
			String custId = outerMerchantService.queryCustId(merchantId);
			QueryMerchantResponseDTO queryMerchantResponseDTO = outerMerchantService.queryMerchantInfo(custId);
			Log4jUtil.info("商户信息【{}】", queryMerchantResponseDTO);

			//商户类别 1：个人、2：企业、3：个体工商户、4：事业单位
			//商户属性 1实体特约商户 2 网络特约商户 3 实体兼网络特约商户
			AssertUtils.notTrue(CustTypeConstant.PERSONAL.equals(queryMerchantResponseDTO.getMerchantCategory().toString()) &&
				MobileMerchantState.MERCHANTATT.MERCHANT_ENTITY_NETWORK.equalsIgnoreCase(String.valueOf(queryMerchantResponseDTO.getMerchantAttribute())), TransReturnCode.code_9108, "包头农商银行移动支付-网络特约个人商户不予报备!");
			
			//查询省份并转化
			MobileProvinceCode mobileProvinceCode = new MobileProvinceCode();
			mobileProvinceCode.setKftProvinceCode(queryMerchantResponseDTO.getAddressInfo().getProvince());	//省份
			mobileProvinceCode.setKftCityCode(queryMerchantResponseDTO.getAddressInfo().getCity());	//城市
			mobileProvinceCode.setKftCountyCode(queryMerchantResponseDTO.getAddressInfo().getDistrict());	//区（县
			mobileProvinceCode.setChannelId(channelId);
			List<MobileProvinceCode> list = mobileMenchartInfoService.selectMchPieCodeInfo(mobileProvinceCode);
			
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelIdNoCache(channelId);
			
			if(list != null && list.size() > 0){ //如存在，设置银行地区数据
				MobileProvinceCode mpc = list.get(0);
				queryMerchantResponseDTO.getAddressInfo().setProvince(mpc.getBankProvinceCode());
				queryMerchantResponseDTO.getAddressInfo().setCity(mpc.getBankCityCode());
				queryMerchantResponseDTO.getAddressInfo().setDistrict(mpc.getBankCountyCode());
			}else{
				//填 默认值 
				queryMerchantResponseDTO.getAddressInfo().setProvince(channelParms.get(Constants.mobileparam.MCH_PROVINCE_CODE_DEFAULT));
				queryMerchantResponseDTO.getAddressInfo().setCity(channelParms.get(Constants.mobileparam.MCH_CITY_CODE_DEFAULT));
				queryMerchantResponseDTO.getAddressInfo().setDistrict(channelParms.get(Constants.mobileparam.MCH_COUNTRY_CODE_DEFAULT));
			}
			
			//进件逻辑处理
			clearingResultDTO = baorcbMobileMerchantService.report(queryMerchantResponseDTO, merchantId, channelId,channelParms);
		} catch (Exception e) {
			Log4jUtil.error(e);
			clearingResultDTO.setChannelResponseMsg("进件异常");
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
			clearingResultDTO.setChannelId(channelId);
		}
		Log4jUtil.info("包头农商银行移动支付-商户时件返回结果：【{}】", clearingResultDTO);
		return clearingResultDTO;
	}

	/**
	 * 
	 * @see com.lycheepay.clearing.adapter.app.common.service.MerchantReportedService#jsApiReport(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public ClearingResultDTO jsApiReport(String corpAccountId, String jsApiPath, String subAppId) {
		
		Log4jUtil.setLogClass("BAORCB", "jsApiReport");
		Log4jUtil.info("包头农商银行移动支付-微信公众号支付配置入参数：corpAccountId:【{}】 , jsApiPath:【{}】 ,subAppId【{}】", corpAccountId, jsApiPath, subAppId);
		ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
		try {
			AssertUtils.isBlank(jsApiPath, TransReturnCode.code_9108, "授权目录不能为空值");
			AssertUtils.isBlank(subAppId, TransReturnCode.code_9108, "关联APPID不能为空值");

			//报备逻辑处理
			clearingResultDTO = baorcbMobileMerchantService.wxConfig(channelId, corpAccountId, jsApiPath, subAppId);

		} catch (Exception e) {
			Log4jUtil.error("包头农商银行移动支付-微信公众号支付配置异常!", e);
			clearingResultDTO.setChannelResponseMsg(e.getMessage());
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
			clearingResultDTO.setChannelId(channelId);
		}
		Log4jUtil.info("包头农商银行移动支付-微信公众号支付配置返回结果：【{}】", clearingResultDTO);
		return clearingResultDTO;
	}

}