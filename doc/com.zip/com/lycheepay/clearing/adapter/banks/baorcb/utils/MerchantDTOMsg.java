package com.lycheepay.clearing.adapter.banks.baorcb.utils;

/**
 * 
 * @Title: MerchantDTOMsg.java 
 * @Description：封装请求参数
 * @Author zmm
 * @Create 2018-1-10 下午5:47:19
 * @Version
 */
public class MerchantDTOMsg {

	/**
	 * 
	* @Description: 组装进件请求参数
	* @Author zmm
	* @Time 2018-1-10 下午5:47:58
	 */
	public static String mchinletMsg(){
		
		return null;
	}
}
