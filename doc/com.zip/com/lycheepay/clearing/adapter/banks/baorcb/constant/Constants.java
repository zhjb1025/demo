package com.lycheepay.clearing.adapter.banks.baorcb.constant;

/**
 * 
 * @Title: Constants.java 
 * @Description：包头农商银行公共参数类
 * @Author zmm
 * @Create 2017-12-5 上午9:37:38
 * @Version
 */
public class Constants {

	public static final  String version = "2.0";
	
	public static final  String charset = "gbk";
	
	public static final String SUCCESS = "SUCCESS";

	
	//移动支付参数
	public interface mobileparam{
		//微信 
		String TRADE_PAY_BANKTYPE_0000001 = "0000001";
		
		//支付宝
		String TRADE_PAY_BANKTYPE_0000002 = "0000002";
		
		//受理机构编号
		String rece_org_no = "100001";		
		
		//受理机构Key
		String rece_org_key = "100002";
		
		//请求地址
		String req_url = "100003";
		
		//单个商户对账服务
		String bill_merchant_service = "100009";
		
		//大商户对账服务
		String bill_bigMerchant_service = "100010";
		
		//某渠道下所有商户的对账单
		String bill_agent_service = "100011";
		
		//默认支付时间(支付宝)
		String PAY_DEFAULT_TIME = "100012";
		
		//微信，支付宝下单、公众号窗口支付回调地址
		String CALL_BACK_URL = "100013";

		//默认省
		String MCH_PROVINCE_CODE_DEFAULT = "100020";
		
		//默认市
		String MCH_CITY_CODE_DEFAULT = "100021";
		
		//默认地区
		String MCH_COUNTRY_CODE_DEFAULT = "100022";

		//默认经营类目
		String MCH_ULINE_INDUSTRY_CATEGROY = "100023";

		//进件客服电话
//		String MCH_KFT_SERVICE_MOBILE = "100024";
		
		//进件联系人
//		String MCH_KFT_CONTACT_NAME = "100025";
		
		//进件联系人电话
//		String MCH_KFT_CONTACT_MOBILE = "100026";
		
		//进件联系人邮箱
		String MCH_KFT_CONTACT_EMAIL = "100027";

		//联系人身份证号
		String MCH_KFT_CONTACT_ID_NO = "100028";
		
		/** 银行FTP地址 **/
		String FTP_IP_ADDRESS = "100029";

		/** FTP登陆名 **/
		String FTP_USER_NAME = "100030";

		/** FTP登陆密码 **/
		String FTP_PASSWORD = "100031";

		/** FTP端口 **/
		String FTP_PORT = "100032";

		/** 银行对账文件路径 **/
		String FTP_ROUTER_PATH = "100033";

		/** 本地对账文件路径 **/
		String FTP_LOCAL_PATH = "100034";
		
		/**机构OPEN_ID */
		String SHOP_OPEN_ID = "SHOP_OPEN_ID";
		
		/**机构OPEN_KEY */
		String SHOP_OPEN_KEY = "SHOP_OPEN_KEY";
	}
	
	public interface aliPay{
		/**支付宝刷卡支付*/
		String ALIPAY_MICROPAY = "200001";
		/**支付宝JSAPI支付*/
		String ALIPAY_CREATE = "200002";
		/**支付宝扫码支付*/
		String ALIPAY_PRECREATE = "200003";
		/**支付宝进件请求地址*/
		String ALIPAY_MCH_MCHINLET = "200004";
		/**支付宝退款请求地址*/
		String ALIPAY_REFUND = "200005";
		/**支付宝退款查询请求地址*/
		String ALIPAY_REFUND_QUERY = "200006";
		/**支付宝订单查询请求地址*/
		String ALIPAY_ORDER_QUERY = "200007";
		/**支付场景 条码支付，取值：bar_code;*/
		String ALIPAY_SCENE_BAR_CODE = "bar_code";
		/**支付场景 条码支付，声波支付，取值：wave_code*/
		String ALIPAY_SCENE_WAVE_CODE = "wave_code";
		/**支付场景 条码支付，条码或二维码支付取值：bar_code;*/
		String ALIPAY_SCENE_BAR_CODE_1 = "1";
		/**支付场景 条码支付，声波支付，取值：wave_code*/
		String ALIPAY_SCENE_WAVE_CODE_2 = "2";
		/**支付宝进件pid*/
		String ALI_MER_SOURCE = "200008";
	}
	
	public interface wechatParam{
		/**微信刷卡接口*/
		String WECHAT_MICROPAY = "300001";
		/**微信公众号接口*/  
		String WECHAT_ORDERS = "300002";
		/**订单查询接口*/
		String WECHAT_QUERY = "300003";
		/**退款接口*/
		String WECHAT_REFUNDS = "300004";
		/**微信进件请求地址*/
		String WECHAT_MCH_MCHINLET = "300005";
		/**微信公众号授权目录地址*/
		String WECHAT_CONFIG_URL = "300006";
		/**退款查询接口*/
		String WECHAT_REFUNDS_QUERY = "300007";
		/**微信下单接口*/  
		String WECHAT_CREATE = "300008";
		/**订单查询接口*/
		String WECHAT_ORDER_QUERY = "300009";
		
	}
	
	public interface retCode{
		
		public static final String RESP_CODE = "return_code";
		public static final String RESP_DESC = "return_msg";
		
		/**响应码**/
		public static final String RESPCODE_SUCC = "0000";//交易成功-响应码
		public static final String RESPCODE_SUCC_SECTION ="0001";//部分成功
		public static final String RESPCODE_PROCESSING = "P000";//交易处理中-响应码
		public static final String RESPCODE_FAIL = "00";//交易失败-响应码前两位
		
		public static final String RESPCODE_TRAN_UNKNOW = "9997";//交易结果未知（应当发起交易查询）
		public static final String RESPCODE_TRAN_FAIL = "9998";//交易失败（应当发起交易查询）
		public static final String RESPCODE_SYS_EXCEPTION = "9999";//系统异常（应当发起交易查询）
	}
	
}
