package com.lycheepay.clearing.adapter.banks.baorcb.utils;



import java.io.Serializable;
import java.util.Map;
/**
 * 包头农商行http请求返回对象
 * @author lcy
 *
 */
public class HttpResponseDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * httpStatusCode
     */
    private int statusCode;
    /**
     * 公共响应参数json字符串
     */
    private String returnMsg;
    
    /**
     * 验签结果
     */
    private boolean validateSuccess = true;
    /**
     * 接收响应成功
     */
    private boolean respSuccess = true;
    /**
     * 发送请求是否成功
     */
    private boolean sendSuccess = true;
    
    /**响应处理是否成功*/
    private boolean dealRespSuccess = true;

    public HttpResponseDTO(int statusCode, String returnMsg) {
        this.statusCode = statusCode;
        this.returnMsg = returnMsg;
    }

    public HttpResponseDTO() {
        
    }
    
    public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public boolean isValidateSuccess() {
		return validateSuccess;
	}

	public void setValidateSuccess(boolean validateSuccess) {
		this.validateSuccess = validateSuccess;
	}


	public boolean isSendSuccess() {
		return sendSuccess;
	}


	public void setSendSuccess(boolean sendSuccess) {
		this.sendSuccess = sendSuccess;
	}
	
	public boolean isRespSuccess() {
        return this.respSuccess;
    }

	public void setRespSuccess(boolean respSuccess) {
		this.respSuccess = respSuccess;
	}

	/**
	 * 响应处理是否成功 (包括解密，验签，参数对象转换)
	 * @return
	 * @author HuangSheng
	 */
	public boolean isDealRespSuccess() {
		return dealRespSuccess;
	}

	public void setDealRespSuccess(boolean dealRespSuccess) {
		this.dealRespSuccess = dealRespSuccess;
	}

	@Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("HttpResponseDTO{");
        sb.append("sendSuccess=").append(sendSuccess);
        sb.append(",respSuccess=").append(respSuccess);
        sb.append(",validateSuccess=").append(validateSuccess);
        sb.append(",dealRespSuccess=").append(dealRespSuccess);
        sb.append(",statusCode=").append(statusCode);
        sb.append(", returnMsg='").append(returnMsg).append('\'');
//        sb.append(", methodRespParamMap='").append(methodRespParamMap).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
