package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BDsmDTO;
import com.lycheepay.clearing.util.Log4jUtil;
/**
 * 金城银行http处理类</br>
 * 
 * @author lcy
 *
 */
public class BaorcbHttpPost {
	/**
	 * s
	 * @param sendMsg 请求报文
	 * @param url 请求路径
	 * @return
	 * @throws Exception
	 */
	public static HttpResponseDTO sendMsg( String url, String sendMsg) throws Exception
	{
		HttpResponseDTO httpRespDTO = new HttpResponseDTO();
		//发送报文，捕捉到异常标记发送失败
		try {
			Log4jUtil.info("包头农商行移动支付-报文请求参数：【{}】", sendMsg);
			
			String response = (String)HttpsUtils.sendPost(url, sendMsg);
			if (response != null) {
				httpRespDTO.setStatusCode(HttpStatus.SC_OK);
				httpRespDTO.setReturnMsg(response);
			} else {
				throw new BizException(TransReturnCode.code_9108, "包头商行移动支付-进件请求异常");
			}
			Log4jUtil.info("包头农商行移动支付-响应原始内容：【{}】", httpRespDTO.getReturnMsg());
		} catch (Exception e) {
			if(e instanceof BizException){
    			if(TransReturnCode.code_9108.equals(((BizException) e).getErrorCode())){
    				httpRespDTO.setSendSuccess(false);
    			}else{
    				httpRespDTO.setRespSuccess(false);
    			}
    		}else{
    			Log4jUtil.error(e);
    			httpRespDTO.setSendSuccess(false);
    		}
		}
		
		return httpRespDTO;
	}
	
}
