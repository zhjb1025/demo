package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.handler;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.cif.exception.CifBizCheckedException;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.service.BaorcbMobilePayProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.constant.biz.MobileMerchantState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.AdaptMenchartService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.MobilePayInfoService;
import com.lycheepay.clearing.adapter.common.service.biz.RouterTxnRecordService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BDsmDTO;
import com.lycheepay.clearing.common.dto.trade.BDsmResultDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayResultDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPTradeResultDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPayRefundDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmResultDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 
 * @Title: BaorcbMobilePayHandler.java 
 * @Description：包头农商银行移动支付
 * @Author zmm
 * @Create 2017-12-4 下午7:42:36
 * @Version
 */
@Service(ClearingAdapterAnnotationName.BAORCB_MOBILE_PAY_HANDLER)
public class BaorcbMobilePayHandler extends AbstractChannelService{

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BAORCB_MOBILE_PAY_PROCESS_SERVICE)
	private BaorcbMobilePayProcessService baorcbMobilePayProcessService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.MOBILE_PAYINFO_SERVICE)
	private MobilePayInfoService mobilePayInfoService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ROUTER_TXNRECORD)
	private RouterTxnRecordService routerTxnRecordService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Autowired
	@Qualifier("clearing.adapter.adaptMenchart")
	private AdaptMenchartService adaptMenchartService;
	
	/**包头农商行移动支付*/
	private final static String channelId = ChannelIdEnum.BAORCB_MOBILE_PAY.getCode();
	
	/**
	 * 
	* @Description: 主动扫码服务
	* @Author lcy
	* @Time 2018-01-30 下午8:02:18
	 */
	@Override
	public ZDsmResultDTO zdsm(ZDsmDTO zdsmDTO) { 
		Log4jUtil.setLogClass("BAORCB", "zdsmDTO");
		Log4jUtil.info("BaorcbMobilePay被动扫码传入参数{}"+ zdsmDTO);
		if(Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(zdsmDTO.getBankType()))
			return zdsmAlipay(zdsmDTO);	//支付宝主扫
		else
			return zdsmWechat(zdsmDTO);	//微信主扫
	}
	
	/**
	 * 微信主动扫码
	 */
	
	private ZDsmResultDTO zdsmWechat(ZDsmDTO zdsmDTO) {
		ZDsmResultDTO zdsmResultDTO = null;
		try {
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			String corpAccountId = zdsmDTO.getSecMerchantId();
			if(StringUtils.isEmpty(corpAccountId)){
				corpAccountId = zdsmDTO.getCorpAccountId();
			}
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			adaptMenchartService.adaptMenchartInfo(channelParms, corpAccountId, channelId, null, zdsmDTO.getBankType(), zdsmDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, zdsmDTO.isD0());
			String bankMerchantId = channelParms.get(MobileMerchantState.MERCHANT_NO);//银行一级商户
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			Log4jUtil.info("包头农商行移动支付-微信-主扫请求流水号：【{}】,渠道商户号:【{}】,渠道商户门店号:【{}】", bankSendSn, bankMerchantNo, bankMerchantId);
			
			Map<String, Object> map = billnoSnService.saveBillnoSn(bankSendSn, channelId, bankMerchantNo, zdsmDTO);
			
			BillnoSn billNoSn = (BillnoSn) map.get("billnoSn");
			BillnoSn updateBillnoSn = new BillnoSn();
			zdsmResultDTO = baorcbMobilePayProcessService.zdsmWechat(zdsmDTO, channelId, bankSendSn, updateBillnoSn, channelParms);
			zdsmResultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			zdsmResultDTO.setAmount(billNoSn.getAmount());
			
			//更新渠道流水对照表(billno_sn)
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			if (TxnStatus.UNKNOW != zdsmResultDTO.getTxnStatus()) {
				updateBillnoSn.setPayState(String.valueOf(zdsmResultDTO.getTxnStatus()));
			}
			updateBillnoSn.setActualAmount(zdsmResultDTO.getActualAmount());// 交易金额
			updateBillnoSn.setBankRecvSn(zdsmResultDTO.getTransactionId());
			billnoSnService.update(updateBillnoSn);
			
			routerTxnRecordService.update(billNoSn.getSn(), zdsmResultDTO.getChannelResponseCode(), zdsmResultDTO.getChannelResponseMsg());
			mobilePayInfoService.insert(billNoSn, zdsmResultDTO.getCodeUrl());
		} catch (BizException e) {
			zdsmResultDTO = new ZDsmResultDTO();
			zdsmResultDTO.setTxnStatus(TransReturnCode.code_9900.equals(e.getErrorCode()) ? TxnStatus.FAILED : TxnStatus.UNKNOW);
			zdsmResultDTO.setChannelResponseMsg(e.getMessage());
			zdsmResultDTO.setChannelResponseCode(e.getErrorCode());
		} catch (Exception e) {
			Log4jUtil.error("主扫支付异常", e);
			zdsmResultDTO = new ZDsmResultDTO();
			zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdsmResultDTO.setChannelResponseMsg("主扫支付异常");
			zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
		}
		zdsmResultDTO.setChannelId(channelId);
		Log4jUtil.info("包头农商行移动支付-微信主动扫码返回对象：{}", zdsmResultDTO);
		return zdsmResultDTO;
	}	
	
	/**
	 * 支付宝主动扫码
	 */
	private ZDsmResultDTO zdsmAlipay(ZDsmDTO zdsmDTO) {
		ZDsmResultDTO zdsmResultDTO = new ZDsmResultDTO();
		try {
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			String corpAccountId = zdsmDTO.getSecMerchantId();
			if(StringUtils.isEmpty(corpAccountId)){
				corpAccountId = zdsmDTO.getCorpAccountId();
			}
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			adaptMenchartService.adaptMenchartInfo(channelParms, corpAccountId, channelId, null, zdsmDTO.getBankType(), zdsmDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);//银行二级商户
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, zdsmDTO.isD0());
			
			String bankMerchantId = channelParms.get(MobileMerchantState.MERCHANT_NO);//银行一级商户
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			Log4jUtil.info("包头农商行移动支付-支付宝-主扫请求流水号：【{}】,渠道商户号:【{}】,渠道商户门店号:【{}】", bankSendSn, bankMerchantNo, bankMerchantId);
			
			Map<String, Object> map = billnoSnService.saveBillnoSn(bankSendSn, channelId, bankMerchantNo, zdsmDTO);
			
			BillnoSn billNoSn = (BillnoSn) map.get("billnoSn");
			BillnoSn updateBillnoSn = new BillnoSn();
			zdsmResultDTO = baorcbMobilePayProcessService.zdsmAlipay(zdsmDTO, channelId, bankSendSn, updateBillnoSn, channelParms);
			
			zdsmResultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			zdsmResultDTO.setAmount(billNoSn.getAmount());
			
			//更新渠道流水对照表(billno_sn)
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			if (TxnStatus.UNKNOW != zdsmResultDTO.getTxnStatus()) {
				updateBillnoSn.setPayState(String.valueOf(zdsmResultDTO.getTxnStatus()));
			}
			updateBillnoSn.setActualAmount(zdsmResultDTO.getActualAmount());// 交易金额
			updateBillnoSn.setBankRecvSn(zdsmResultDTO.getTransactionId());
			billnoSnService.update(updateBillnoSn);
			
			routerTxnRecordService.update(billNoSn.getSn(), zdsmResultDTO.getChannelResponseCode(), zdsmResultDTO.getChannelResponseMsg());
			mobilePayInfoService.insert(billNoSn, zdsmResultDTO.getCodeUrl());
	    } catch (BizException e) {
			zdsmResultDTO.setTxnStatus(TransReturnCode.code_9900.equals(e.getErrorCode()) ? TxnStatus.FAILED : TxnStatus.UNKNOW);
			zdsmResultDTO.setChannelResponseMsg(e.getMessage());
			zdsmResultDTO.setChannelResponseCode(e.getErrorCode());
	    } catch (Exception e) {
	    	Log4jUtil.error("主扫支付异常", e);
			zdsmResultDTO = new ZDsmResultDTO();
			zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdsmResultDTO.setChannelResponseMsg("主扫支付异常");
			zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
	    }
		zdsmResultDTO.setChannelId(channelId);
		Log4jUtil.info("包头农商行移动支付-支付宝主动扫码返回对象：{}", zdsmResultDTO);
		return zdsmResultDTO;
	}
	
	/**
	 * 
	* @Description: 被动扫码服务
	* @Author lcy
	* @Time 2018-01-30 下午8:02:18
	 */
	@Override
	public BDsmResultDTO bdsm(BDsmDTO bdsmDTO) {
		Log4jUtil.setLogClass("BAORCB", "bdsm");
		Log4jUtil.info("BaorcbMobilePay被动扫码传入参数{}"+ bdsmDTO);
		if(Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(bdsmDTO.getBankType()))
			return bdsmAlipay(bdsmDTO);
		else
			return bdsmWechat(bdsmDTO);
	}
	
	/**
	 * 微信-被扫
	 * @param bssmDTO
	 * @return
	 */
	private BDsmResultDTO bdsmWechat(BDsmDTO bdsmDTO) {
		BDsmResultDTO bdResultDTO = new BDsmResultDTO();
		
		try {
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			String corpAccountId = bdsmDTO.getSecMerchantId();
			if(StringUtils.isEmpty(corpAccountId)){
				corpAccountId = bdsmDTO.getCorpAccountId();
			}
			
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			adaptMenchartService.adaptMenchartInfo(channelParms, corpAccountId, channelId, null, bdsmDTO.getBankType(), bdsmDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, bdsmDTO.isD0());
			String bankMerchantId = channelParms.get(MobileMerchantState.MERCHANT_NO);
//			String bankMerchantId =channelParms.get(Constants.mobileparam.SHOP_OPEN_ID);
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			//生成交易流水号
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			Log4jUtil.info("包头农商行移动支付-支付宝-被扫请求流水号：【{}】,渠道商户号:【{}】,渠道商户门店号:【{}】", bankSendSn, bankMerchantNo, bankMerchantId);
			
			//交易记录处理
			Map<String, Object> map = billnoSnService.saveBillnoSn(bankSendSn, channelId, bankMerchantNo, bdsmDTO);
			BillnoSn billNoSn = (BillnoSn) map.get("billnoSn");
			
			BillnoSn updateBillnoSn = new BillnoSn();
			bdResultDTO = baorcbMobilePayProcessService.bdsmWechat(bdsmDTO, channelId, bankSendSn, channelParms, updateBillnoSn);
			bdResultDTO.setChannelId(channelId);
			bdResultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			bdResultDTO.setAmount(bdsmDTO.getAmount());
			if(bdResultDTO.getActualAmount() == null){
				bdResultDTO.setActualAmount(bdsmDTO.getAmount());
			}
			Log4jUtil.info("包头农商行移动支付-微信被扫-返回结果bdResultDTO:【{}】", bdResultDTO);
			
			// 更新渠道流水对照表(billno_sn)
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			updateBillnoSn.setPayState(String.valueOf(bdResultDTO.getTxnStatus()));
			updateBillnoSn.setActualAmount(bdResultDTO.getActualAmount());// 交易金额
			updateBillnoSn.setBankRecvSn(bdResultDTO.getTransactionId());
			billnoSnService.update(updateBillnoSn);
			routerTxnRecordService.update(billNoSn.getSn(), bdResultDTO.getChannelResponseCode(), bdResultDTO.getChannelResponseMsg());
		} catch (BizException e) {
			bdResultDTO.setTxnStatus(TransReturnCode.code_9900.equals(e.getErrorCode()) ? TxnStatus.FAILED : TxnStatus.UNKNOW);
			bdResultDTO.setChannelResponseMsg(e.getMessage());
			bdResultDTO.setChannelResponseCode(e.getErrorCode());
			bdResultDTO.setChannelId(channelId);
		} catch (Exception e) {
			Log4jUtil.error(e);
			bdResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			bdResultDTO.setChannelResponseMsg("支付宝-被扫支付异常");
			bdResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			bdResultDTO.setChannelId(channelId);
		}
		
		return bdResultDTO;
			
	}
	
	/**
	 * 支付宝-被扫
	 * @param bssmDTO
	 * @return
	 */
	private BDsmResultDTO bdsmAlipay(BDsmDTO bdsmDTO) {
		BDsmResultDTO bdResultDTO = new BDsmResultDTO();
		try {
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			String corpAccountId = bdsmDTO.getSecMerchantId();
			if(StringUtils.isEmpty(corpAccountId)){
				corpAccountId = bdsmDTO.getCorpAccountId();
			}
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			adaptMenchartService.adaptMenchartInfo(channelParms, corpAccountId, channelId, null, bdsmDTO.getBankType(), bdsmDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, bdsmDTO.isD0());
			String bankMerchantId =channelParms.get(MobileMerchantState.MERCHANT_NO);
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			//生成交易流水号
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			Log4jUtil.info("包头农商行移动支付-支付宝-被扫请求流水号：【{}】,渠道商户号:【{}】,渠道商户门店号:【{}】", bankSendSn, bankMerchantNo, bankMerchantId);
			
			//交易记录处理
			Map<String, Object> map = billnoSnService.saveBillnoSn(bankSendSn, channelId, bankMerchantNo, bdsmDTO);
			BillnoSn billNoSn = (BillnoSn) map.get("billnoSn");
			
			BillnoSn updateBillnoSn = new BillnoSn();
			bdResultDTO = baorcbMobilePayProcessService.bdsmAlipay(bdsmDTO, channelId, bankSendSn, channelParms, updateBillnoSn);
			bdResultDTO.setChannelId(channelId);
			bdResultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			bdResultDTO.setAmount(bdsmDTO.getAmount());
			if(bdResultDTO.getActualAmount() == null){
				bdResultDTO.setActualAmount(bdsmDTO.getAmount());
			}
			Log4jUtil.info("包头农商行移动支付-支付宝-被动扫码返回对象：【{}】", bdResultDTO);
			
			// 更新渠道流水对照表(billno_sn)
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			updateBillnoSn.setPayState(String.valueOf(bdResultDTO.getTxnStatus()));
			updateBillnoSn.setActualAmount(bdResultDTO.getActualAmount());// 交易金额
			updateBillnoSn.setBankRecvSn(bdResultDTO.getTransactionId());
			billnoSnService.update(updateBillnoSn);
			routerTxnRecordService.update(billNoSn.getSn(), bdResultDTO.getChannelResponseCode(), bdResultDTO.getChannelResponseMsg());
		} catch (BizException e) {
			bdResultDTO.setTxnStatus(TransReturnCode.code_9900.equals(e.getErrorCode()) ? TxnStatus.FAILED : TxnStatus.UNKNOW);
			bdResultDTO.setChannelResponseMsg(e.getMessage());
			bdResultDTO.setChannelResponseCode(e.getErrorCode());
			bdResultDTO.setChannelId(channelId);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			bdResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			bdResultDTO.setChannelResponseMsg("支付宝-被扫支付异常");
			bdResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			bdResultDTO.setChannelId(channelId);
		}
		return bdResultDTO;
	}	
	
	/**
	 * 
	* @Description: 微信公众号/支付宝服务窗支付
	* @Author zmm
	* @Time 2017-12-6 下午3:38:51
	 */
	@Override
	public JsapiPayResultDTO jsapiPay(JsapiPayDTO jsapiPayDTO) {
		Log4jUtil.setLogClass("BAORCB", "jsapi");
		Log4jUtil.info("BaorcbMobilePay公众号/服务窗支付传入参数{}"+ jsapiPayDTO);
		if (Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(jsapiPayDTO.getBankType())) 
			return jsapiPayAlipay(jsapiPayDTO);	//支付宝服务窗
		else
			return jsapiPayWechat(jsapiPayDTO);	//微信公众号
	}
	
	/**
	 * 微信公众号
	 * @param jsapiPayDTO
	 * @return
	 */
	private JsapiPayResultDTO jsapiPayWechat(JsapiPayDTO jsapiPayDTO){
		JsapiPayResultDTO jsapiPayResultDTO = new JsapiPayResultDTO();
		
		try {
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			String corpAccountId = jsapiPayDTO.getSecMerchantId();
			if(StringUtils.isEmpty(corpAccountId)){
				corpAccountId = jsapiPayDTO.getCorpAccountId();
			}
			
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			adaptMenchartService.adaptMenchartInfo(channelParms, corpAccountId, channelId, null, jsapiPayDTO.getBankType(), jsapiPayDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, jsapiPayDTO.isD0());
			String bankMerchantId =channelParms.get(MobileMerchantState.MERCHANT_NO);
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			
			//生成交易流水号
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			Log4jUtil.info("包头农商行移动支付-微信-微信jsapi请求流水号：【{}】,渠道商户号:【{}】,渠道商户门店号:【{}】", bankSendSn, bankMerchantNo, bankMerchantId);
			//交易记录处理
			BillnoSn billNoSn = billnoSnService.saveBillnoSnByAlipay(bankSendSn, channelId, bankMerchantNo, jsapiPayDTO);
			//银行code msg
			BillnoSn updateBillnoSn = new BillnoSn();
			jsapiPayResultDTO = baorcbMobilePayProcessService.jsapiPayWechat(jsapiPayDTO, channelId, bankSendSn, channelParms, updateBillnoSn);
			jsapiPayResultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			jsapiPayResultDTO.setAmount(jsapiPayDTO.getAmount());
			jsapiPayResultDTO.setChannelId(channelId);
			Log4jUtil.info("包头农商行移动支付-jspAPI支付返回结果：【{}】", jsapiPayResultDTO);
			
			// 3. 更新渠道流水对照表(billno_sn)
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			if (TxnStatus.UNKNOW != jsapiPayResultDTO.getTxnStatus()) {
				updateBillnoSn.setPayState(String.valueOf(jsapiPayResultDTO.getTxnStatus()));
			}
			updateBillnoSn.setActualAmount(jsapiPayResultDTO.getActualAmount());// 交易金额
			updateBillnoSn.setBankRecvSn(jsapiPayResultDTO.getTransactionId());
			billnoSnService.update(updateBillnoSn);
			routerTxnRecordService.update(billNoSn.getSn(), jsapiPayResultDTO.getChannelResponseCode(),jsapiPayResultDTO.getChannelResponseMsg());
			mobilePayInfoService.insert(billNoSn, jsapiPayResultDTO);
		} catch (BizException e) {
			Log4jUtil.error(e);
			jsapiPayResultDTO.setTxnStatus(TransReturnCode.code_9900.equals(e.getErrorCode()) ? TxnStatus.FAILED : TxnStatus.UNKNOW);
			jsapiPayResultDTO.setChannelResponseMsg(e.getMessage());
			jsapiPayResultDTO.setChannelResponseCode(e.getErrorCode());
			jsapiPayResultDTO.setChannelId(channelId);
		} catch (Exception e) {
			Log4jUtil.error(e);
			jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			jsapiPayResultDTO.setChannelResponseMsg("微信jspApi支付异常");
			jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			jsapiPayResultDTO.setChannelId(channelId);
		}
		Log4jUtil.info("微信公众号返回数据：[{}]", jsapiPayResultDTO);
		return jsapiPayResultDTO;
	}
	/**
	 * 支付宝服务窗
	 * @param jsapiPayDTO
	 * @return
	 */
	private JsapiPayResultDTO jsapiPayAlipay(JsapiPayDTO jsapiPayDTO){
		JsapiPayResultDTO jsapiPayResultDTO = new JsapiPayResultDTO();
		
		try {
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			String corpAccountId = jsapiPayDTO.getSecMerchantId();
			if(StringUtils.isEmpty(corpAccountId)){
				corpAccountId = jsapiPayDTO.getCorpAccountId();
			}
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			adaptMenchartService.adaptMenchartInfo(channelParms, corpAccountId, channelId, null, jsapiPayDTO.getBankType(), jsapiPayDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, jsapiPayDTO.isD0());
			String bankMerchantId =channelParms.get(MobileMerchantState.MERCHANT_NO);
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			//生成交易流水号
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			Log4jUtil.info("包头农商行移动支付-支付宝-支付宝jsapi请求流水号：【{}】,渠道商户号:【{}】,渠道商户门店号:【{}】", bankSendSn, bankMerchantNo, bankMerchantId);
			//交易记录处理
			BillnoSn billNoSn = billnoSnService.saveBillnoSnByAlipay(bankSendSn, channelId, bankMerchantNo, jsapiPayDTO);
			//银行code msg
			BillnoSn updateBillnoSn = new BillnoSn();
			jsapiPayResultDTO = baorcbMobilePayProcessService.jsapiPayAlipay(jsapiPayDTO, channelId, bankSendSn, channelParms, updateBillnoSn);
			jsapiPayResultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			jsapiPayResultDTO.setAmount(jsapiPayDTO.getAmount());
			jsapiPayResultDTO.setChannelId(channelId);
			Log4jUtil.info("包头农商行移动支付-jspAPI支付返回结果：【{}】", jsapiPayResultDTO);
			
			// 3. 更新渠道流水对照表(billno_sn)
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			if (TxnStatus.UNKNOW != jsapiPayResultDTO.getTxnStatus()) {
				updateBillnoSn.setPayState(String.valueOf(jsapiPayResultDTO.getTxnStatus()));
			}
			updateBillnoSn.setActualAmount(jsapiPayResultDTO.getActualAmount());// 交易金额
			updateBillnoSn.setBankRecvSn(jsapiPayResultDTO.getTransactionId());
			billnoSnService.update(updateBillnoSn);
			routerTxnRecordService.update(billNoSn.getSn(), jsapiPayResultDTO.getChannelResponseCode(),jsapiPayResultDTO.getChannelResponseMsg());
			mobilePayInfoService.insert(billNoSn, jsapiPayResultDTO);
		} catch (BizException e) {
			Log4jUtil.error(e);
			jsapiPayResultDTO.setTxnStatus(TransReturnCode.code_9900.equals(e.getErrorCode()) ? TxnStatus.FAILED : TxnStatus.UNKNOW);
			jsapiPayResultDTO.setChannelResponseMsg(e.getMessage());
			jsapiPayResultDTO.setChannelResponseCode(e.getErrorCode());
			jsapiPayResultDTO.setChannelId(channelId);
		} catch (Exception e) {
			Log4jUtil.error(e);
			jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			jsapiPayResultDTO.setChannelResponseMsg("支付宝jspApi支付异常");
			jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			jsapiPayResultDTO.setChannelId(channelId);
		}
		Log4jUtil.info("支付宝服务窗返回数据：", jsapiPayResultDTO);
		return jsapiPayResultDTO;
	}
	/**
	 * 退款
	 * @param zdPayRefundDTO
	 * @author lcy
	 * @Time 2018-02-02  上午11:31:39
	 */
	@Override
	public ClearingResultDTO zdPayRefund(ZDPayRefundDTO zdPayRefundDTO)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BAORCB", "refund");
		Log4jUtil.info("BaorcbMobilePay退款申请传入参数{}"+ zdPayRefundDTO);		
		if(Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(zdPayRefundDTO.getBankType()))
			return zdPayRefundAlipay(zdPayRefundDTO);	//支付宝退款
		else
			return zdPayRefundWechat(zdPayRefundDTO);	//微信退款
	}
	
	/**
	 * @Description: 微信 - 退款
	 * @param zdPayRefundDTO
	 * @Author lcy
	 * @Time 2018-02-02  上午11:31:39
	 */
	public ClearingResultDTO zdPayRefundWechat(ZDPayRefundDTO zdPayRefundDTO) {
		Log4jUtil.setLogClass("BAORCB", "refund");
		Log4jUtil.info("BaorcbMobilePay微信退款申请传入参数{}"+ zdPayRefundDTO);		
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		try {
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			
			BillnoSn oriBillNoSn = billnoSnService.findBankSendSn(channelId, zdPayRefundDTO.getOrgTransTxnId());
			
			adaptMenchartService.adaptMenchartInfo(channelParms, null, channelId, oriBillNoSn.getBankMerchantId(), zdPayRefundDTO.getBankType(), zdPayRefundDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, false);
			String bankMerchantId =channelParms.get(MobileMerchantState.MERCHANT_NO);
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			//包头农商行生成交易流水号
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			//交易记录处理
			BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, bankMerchantNo, zdPayRefundDTO, oriBillNoSn.getBankSendSn());
			//接口主逻辑处理
			BillnoSn updateBillnoSn = new BillnoSn();
			
			resultDTO = baorcbMobilePayProcessService.zdPayRefundWx(zdPayRefundDTO, channelId, oriBillNoSn, updateBillnoSn, channelParms, bankSendSn);
			
			resultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			resultDTO.setChannelId(channelId);
			
			Log4jUtil.info("包头农商行移动支付-退款返回对象：【{}】", resultDTO);
			
			updateBillnoSn.setBankPaySn(oriBillNoSn.getBankSendSn());
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
			billnoSnService.update(updateBillnoSn);
			routerTxnRecordService.update(billNoSn.getSn(), resultDTO.getChannelResponseCode(), resultDTO.getChannelResponseMsg());
		} catch (BizException e) {
			Log4jUtil.error("包头农商行移动支付退款异常失败 业务异常", e);
			return ChannelResultUtil.exceptionToResult(e, resultDTO);
		} catch (Exception e) {
			Log4jUtil.error("包头农商行移动支付退款异常失败 系统异常", e);
			return ChannelResultUtil.exceptionToResult(e, resultDTO);
		}
		return resultDTO;
	}
	
	/**
	 * @Description: 支付宝 - 退款
	 * @param zdPayRefundDTO
	 * @Author lcy
	 * @Time 2018-02-02  上午08:31:39
	 */
	public ClearingResultDTO zdPayRefundAlipay(ZDPayRefundDTO zdPayRefundDTO) {
		Log4jUtil.setLogClass("BAORCB", "refund");
		Log4jUtil.info("BaorcbMobilePay支付宝退款申请传入参数{}"+ zdPayRefundDTO);		
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		try {
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			
			BillnoSn oriBillNoSn = billnoSnService.findBankSendSn(channelId, zdPayRefundDTO.getOrgTransTxnId());
			
			adaptMenchartService.adaptMenchartInfo(channelParms, null, channelId, oriBillNoSn.getBankMerchantId(), zdPayRefundDTO.getBankType(), zdPayRefundDTO.getAmount());
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, false);
			String bankMerchantId =channelParms.get(MobileMerchantState.MERCHANT_NO);
			AssertUtils.isBlank(bankMerchantId,TransReturnCode.code_9108, "包头农商行移动支付被动扫码,渠道商户门店号为空");
			//包头农商行生成交易流水号
			String bankSendSn = sequenceManagerService.getBaoRCBMobileSn();
			//交易记录处理
			BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, bankMerchantNo, zdPayRefundDTO, oriBillNoSn.getBankSendSn());
			//接口主逻辑处理
			BillnoSn updateBillnoSn = new BillnoSn();
			
			resultDTO = baorcbMobilePayProcessService.zdPayRefundAli(zdPayRefundDTO, channelId, oriBillNoSn, updateBillnoSn, channelParms, bankSendSn);
			
			resultDTO.setSettlementAccountNo(billNoSn.getCorpacctno());
			resultDTO.setChannelId(channelId);
			
			Log4jUtil.info("包头农商行移动支付-退款返回对象：【{}】", resultDTO);
			
			updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			updateBillnoSn.setRecvTime(new Date());
			updateBillnoSn.setState(BillnoSnState.billnoResp);
			updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
			billnoSnService.update(updateBillnoSn);
			routerTxnRecordService.update(billNoSn.getSn(), resultDTO.getChannelResponseCode(), resultDTO.getChannelResponseMsg());
		} catch (BizException e) {
			Log4jUtil.error("包头农商行移动支付退款异常失败 业务异常", e);
			return ChannelResultUtil.exceptionToResult(e, resultDTO);
		} catch (Exception e) {
			Log4jUtil.error("包头农商行移动支付退款异常失败 系统异常", e);
			return ChannelResultUtil.exceptionToResult(e, resultDTO);
		}
		return resultDTO;
	}
	
	/**
	 * <p>单笔查询，渠道内部使用，根据渠道流水表记录，调用 银行单笔查询接口获取交易结果</p>
	 * 
	 * @param billnoSn 不为null
	 * @return
	 */
	@Override
	public ZDPTradeResultDTO queryZDPSingleRecord(BillnoSn billnoSn) {
		ZDPTradeResultDTO resultDTO = new ZDPTradeResultDTO();
		Log4jUtil.setLogClass("BAORCB", "mobilePay");
		Log4jUtil.info("包头农商行 移动支付 查询-传入参数：{}", billnoSn);
		
		try {
			//根据渠道id查询系统参数
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			try {
				adaptMenchartService.adaptMenchartInfo(channelParms, null, channelId, billnoSn.getBankMerchantId(), billnoSn.getBankType(), billnoSn.getAmount());
			} catch (BizException | CifBizCheckedException e) {
				Log4jUtil.error(e);
				resultDTO.setTxnStatus(TxnStatus.FAILED);
				resultDTO.setChannelResponseMsg("厦门平安移动支付-获取二级商户号异常" + e.getMessage());
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelId(channelId);
				return resultDTO;
			}
			String bankMerchantNo = channelParms.get(MobileMerchantState.SUB_MCH_ID);
			//根据渠道ID和企业账户ID查询企业账户编号与银行商户编号映射实体
			baorcbMobilePayProcessService.merchantParms(channelParms, channelId, bankMerchantNo, false);
			if(billnoSn.getTranType().equals(ClearingTransType.MBP_ZD_PAY_REFUND)){
				resultDTO = baorcbMobilePayProcessService.queryRefundRecord(billnoSn, channelParms);
			}else{
				resultDTO = baorcbMobilePayProcessService.querySingleRecord(billnoSn, channelParms);
			}
		} catch (BizException e) {
			resultDTO.setTxnStatus(TxnStatus.UNKNOW);
			resultDTO.setChannelResponseMsg(e.getMessage());
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelId(channelId);
		} catch (Exception e) {
			Log4jUtil.error("交易查询异常", e);
			resultDTO.setTxnStatus(TxnStatus.UNKNOW);
			resultDTO.setChannelResponseMsg("交易查询异常");
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelId(channelId);
		}
		if (StringUtils.isEmpty(resultDTO.getSettlementAccountNo())) {
			resultDTO.setSettlementAccountNo(billnoSn.getCorpacctno());
		}
		if (resultDTO.getActualAmount() == null) {
			resultDTO.setActualAmount(billnoSn.getActualAmount());
		}
		Log4jUtil.info("包头农商行 移动支付 查询-返回对象：【{}】", resultDTO);
		return resultDTO;
	}
	
	/**
	 * 定时任务关闭逾期商户订单
	 * 
	 * 2018年2月8日 上午10:23:33
	 */
	public void closeOrderTimetask(){
		//根据渠道id查询系统参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String timeoutStr = channelParms.get(Constants.mobileparam.PAY_DEFAULT_TIME);
		final int timeoutInt = StringUtils.isBlank(timeoutStr) ? 2 :  Integer.valueOf(timeoutStr.substring(0, 1));
		
		Log4jUtil.info("查询{}小时前下单的，支付状态未知的商户订单信息", timeoutInt);
		List<BillnoSn> billionList = billnoSnService.queryAllUnknownBillnoSn(channelId,timeoutInt);
		Log4jUtil.info("查询到需要关闭的订单共{}条",billionList.size());
		if (billionList != null || billionList.size() >0) {
			final List<BillnoSn> processResult = new CopyOnWriteArrayList<BillnoSn>();
			ExecutorService threadPool = Executors.newFixedThreadPool(5);
			for (final BillnoSn billnoSn : billionList) {
				threadPool.execute(new Runnable() {
					@Override
					public void run() {
						closeOrder(billnoSn, processResult);
					}
				});
			}
			threadPool.shutdown();
			boolean finished = false;
			while (!finished) {
				try {
					Thread.sleep(10000);// 10秒检查一次，看是否处理完成
				} catch (Exception e) {
					Log4jUtil.error(e);
				}
				Log4jUtil.info("已处理：{}笔", processResult.size());
				finished = billionList.size() == processResult.size();
			}
			processResult.clear();
		}
	}
	
	/**
	 * 关闭商户订单
	 * 
	 * @param billNoSn
	 * @param processResult
	 * @param channelParms
	 */
	public void closeOrder(BillnoSn billNoSn, List<BillnoSn> processResult) {
		try {
			Log4jUtil.setLogClass("BAORCB", "closeOrder");
			Log4jUtil.info("定时任务关闭订单参数 billNoSn:{}", billNoSn);
			
			if(Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(billNoSn.getBankType()) || 
				Constants.mobileparam.TRADE_PAY_BANKTYPE_0000001.equals(billNoSn.getBankType())){
				Log4jUtil.info("bankType:{}关闭订单!", billNoSn.getBankType());

				//调用查询接口，查询订单交易结果
				ZDPTradeResultDTO zdpTradeResultDTO = queryZDPSingleRecord(billNoSn);
				
				baorcbMobilePayProcessService.closeOrderService(billNoSn,zdpTradeResultDTO);
			}else {
				Log4jUtil.info("未知订单类型:{}", billNoSn.getBankType());
			}
		} catch(Exception e){
			Log4jUtil.error("定时任务关闭订单异常", e);
		} finally{
			processResult.add(billNoSn);
		}
	}
}
