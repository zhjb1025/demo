package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * 包头农商行https工具类
 * 
 * @author lcy
 * @since
 */
public class HttpsUtils {

	private final static int BUFFER_SIZE = 2048;

	private static final String CHARSET = "GBK";

	// 是否为开发测试模式，true时将连接测试环境，false时将连接生产环境
	private static final boolean devEnv = true;

	// 是否验签，true验证应答报文签名，false不验证签名，建议不要修改此项为false，生产环境请务必更改为true
//	private static final boolean needChkSign = true;

	/**
	 * 
	 * <p>拼装参数Map为String，含URLEncode</p>
	 * 
	 * @param params
	 * @return
	 * @throws BizException
	 */
	public static String getUrlEncodeParams(Map<String, String> params) throws BizException {
		StringBuffer paramstr = null;
		try {
			// 拼装参数Map为String，含URLEncode
			paramstr = new StringBuffer();
			for (Map.Entry<String, String> entry : params.entrySet()) {
				paramstr.append(entry.getKey()).append("=").append(URLEncoder.encode(entry.getValue(), CHARSET))
						.append("&");
			}
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error("拼装业务参数异常", e);
			throw new BizException(TransReturnCode.code_9108, "拼装业务参数失败");
		}

		return paramstr.toString();
	}

	public static Object sendPost(String url, String params) throws BizException {
		HttpURLConnection conn = null;
		Object ret = null;
		OutputStream outStream = null;
		InputStream inStream = null;
		URL connurl = null;
		try{
			connurl = new URL(url);
//			conn.setRequestProperty("Content-Type","application/xml;charset=gbk");
			conn = (HttpURLConnection) connurl.openConnection();
			// 测试环境忽略SSL证书验证
			if (isDevEnv() && connurl.getProtocol().equals("https")) {
				ignoreSSLVerify((HttpsURLConnection) conn);
			}
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
//			conn.setConnectTimeout(30 * 1000);
//			conn.setReadTimeout(60 * 1000);
			conn.setConnectTimeout(10 * 1000);
			conn.setReadTimeout(35 * 1000);
		}catch(Exception e){
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "初始化网络通讯组件异常");
		}
		
		try {
			outStream = conn.getOutputStream();
			outStream.write(params.getBytes(CHARSET));
			outStream.flush();

			inStream = conn.getInputStream();
			byte[] bin = readInputStream(inStream);

			if ("application/octet-stream".equals(conn.getContentType())) {
				ret = bin;
			} else {
				ret = new String(bin, CHARSET);
			}
		}catch(Exception e){
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "通讯错误或超时,交易未决");
		} finally {
			if (inStream != null)
				try {
					inStream.close();
				} catch (IOException e) {
					Log4jUtil.error("关闭输入流异常:", e);
				}
			if (outStream != null)
				try {
					outStream.close();
				} catch (IOException e) {
					Log4jUtil.error("关闭输出流异常:", e);
				}
			if (conn != null)
				conn.disconnect();
		}
		return ret;
	}

	private static byte[] readInputStream(InputStream inStream) throws IOException {

		ByteArrayOutputStream outStream = new ByteArrayOutputStream();
		byte[] data = null;
		byte[] buffer = new byte[BUFFER_SIZE];
		int len = 0;
		try {
			while ((len = inStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, len);
			}
			data = outStream.toByteArray();
		} finally {
			if (outStream != null)
				outStream.close();
		}
		return data;
	}

	private static void ignoreSSLVerify(HttpsURLConnection conn) throws BizException {

		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			}
		} };
		SSLContext sc = null;
		try {
//			sc = SSLContext.getInstance("SSL");
			sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
		} catch (Exception e) {
			Log4jUtil.error("设置忽略SSL证书验证失败", e);
			throw new BizException(TransReturnCode.code_9108, "设置忽略SSL证书验证失败");
		}

		conn.setSSLSocketFactory(sc.getSocketFactory());
		conn.setHostnameVerifier(new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		});
	}

	public static boolean isDevEnv() {
		return devEnv;
	}

//	public static boolean isNeedChkSign() {
//		return needChkSign;
//	}
	
}