package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.handler.BaorcbMobilePayHandler;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.BaorcbVerificationSignMD5;
import com.lycheepay.clearing.adapter.banks.pinganXM.mobilePay.service.PinganXMMobilePayMQSenderService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.RouterTxnRecordService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.dto.common.ZdsmBackToZDPTDto;
import com.lycheepay.clearing.common.dto.trade.ZDPTradeResultDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;

@Service("baorcbMobilePayCallBackMQListener")
public class BaorcbMobilePayCallBackMQListener implements MessageListener {

//	protected static final Logger logger = LoggerFactory.getLogger(BaorcbMobilePayCallBackMQListener.class); // 日志器
	
	private final static String channelId = ChannelIdEnum.BAORCB_MOBILE_PAY.getCode();
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	
	@Autowired
	private PinganXMMobilePayMQSenderService payMQSenderService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ROUTER_TXNRECORD)
	private RouterTxnRecordService routerTxnRecordService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BAORCB_MOBILE_PAY_HANDLER)
	private BaorcbMobilePayHandler baorcbMobilePayHandler;
	
	@Override
	public void onMessage(Message message) {
		Log4jUtil.setLogClass("BAORCB", "mobilePayCallBackMQListener");
		Log4jUtil.info("======触发==mobilePayCallBackMQListener=========");
		if (message instanceof TextMessage) {
			String textMsg = "" ;
			try {
				TextMessage msg = (TextMessage) message;
				textMsg = msg.getText();
				Log4jUtil.info(textMsg);
				//逻辑处理
				dealMQSender(textMsg);
				message.acknowledge();
			} catch (Exception e) {
				Log4jUtil.error("包头农商行移动支付下单回调_Exception接收MQ信息为:" + textMsg + " 处理失败!", e);
			}
		} else {
			Log4jUtil.error(message);
		}
	}
	
	private void dealMQSender(String resultMsg) throws Exception{
		Map<String,String> map = new HashMap<String,String>();
		Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(resultMsg.getBytes());
		List<Element> elements = dom4jxml.getRoot().elements();
		for(Element element : elements){
			map.put(element.getName(), element.getText());
		}
		if (map.containsKey("alipay_trade_no"))
			dealAliResResultMsg(resultMsg, map);
		else
			dealWxResResultMsg(resultMsg, map);
	}
	
	private void dealWxResResultMsg(String resultMsg, Map<String, String> resultMap) throws Exception{
		String channelResponseCode = null;
		String retMsg = null;
		int txnStatus = 0;
		//查询通道配置信息
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
//			String status = resultMap.get("result_code");
//			if (Constants.SUCCESS.equals(status)) {
//				txnStatus = TxnStatus.SUCCEED;
//				channelResponseCode = TransReturnCode.code_0000;
//				retMsg = "交易成功";
//			} else {
//				txnStatus = TxnStatus.FAILED;
//				channelResponseCode = TransReturnCode.code_9900;
//				retMsg = "交易失败";
//			}
			String bankRecvSn = resultMap.get("trade_no");
			String order_fee  = resultMap.get("order_fee");
			String act_fee  = resultMap.get("act_fee");
			String bankSendSn = resultMap.get("merchant_trade_no");
			BigDecimal feeAmount, actualAmount;
			if(StringUtils.isBlank(order_fee)){
				feeAmount = new BigDecimal("0");
			}else{
				feeAmount = new BigDecimal(order_fee).movePointLeft(2);
			}
			if(StringUtils.isBlank(act_fee)){
				actualAmount = new BigDecimal("0");
			}else{
				actualAmount = new BigDecimal(act_fee).movePointLeft(2);
			}
			//银行交易流水
			BillnoSn billnoSn = billnoSnService.findTranTypeByChannel(channelId, bankSendSn);
			Log4jUtil.info("获取到的billnoSn对象为：{}",billnoSn);
			Assert.notNull(billnoSn,"billnoSn表记录不能为空");
			
			ZDPTradeResultDTO zDto = baorcbMobilePayHandler.queryZDPSingleRecord(billnoSn);
			Log4jUtil.info("开始更新数据库和发送消息队列：");
			
			billnoSn.setPayState(String.valueOf(zDto.getTxnStatus()));
			billnoSn.setChannelRtnnote(zDto.getChannelResponseMsg());
			billnoSn.setChannelRtncode(zDto.getChannelResponseCode());
			billnoSn.setActualAmount(actualAmount);
			billnoSn.setAmount(feeAmount);
			billnoSn.setRecvTime(new Date());
			billnoSn.setState(BillnoSnState.billnoRecv);// 业务回执已返回
			billnoSn.setBankRecvSn(bankRecvSn);
			
			int result = billnoSnService.updateByStatus(billnoSn);//更新交易流水
			if (result >= 1) {
				Log4jUtil.info("路由交易处理:channelResponseCode:{}", channelResponseCode);
				//路由交易处理
				routerTxnRecordService.updateCallBack(billnoSn.getSn(), feeAmount, channelResponseCode, retMsg);
				Map<String, String> msgMap = new HashMap<String, String>();
				msgMap.put("total_fee", feeAmount.toString());
				msgMap.put("bankSendSn", bankSendSn);
				msgMap.put("bankRecvSn", bankRecvSn);
				//发送主动平台
				sendMQ(msgMap, billnoSn, channelResponseCode,txnStatus);
				Log4jUtil.info("包头农商行移动支付下单回调_发送MQ到主动支付处理完成!result:{}", result);
			} else {
				Log4jUtil.info("[重复请求，不发MQ]包头农商行移动支付下单回调_发送MQ到主动支付处理完成!result:{}", result);
			}
		} else {
			Log4jUtil.error("包头农商行移动支付下单回调_验签失败");
		}
	}
	
	private void dealAliResResultMsg(String resultMsg, Map<String, String> resultMap) throws Exception{
		String channelResponseCode = null;
		String retMsg = null;
		int txnStatus = 0;
		//查询通道配置信息
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
			//交易状态
			String trade_status = resultMap.get("trade_status");
			if ("SUCCESS".equals(trade_status)) {
				txnStatus = TxnStatus.SUCCEED;
				channelResponseCode = TransReturnCode.code_0000;
				retMsg = "交易成功";
			 }else if("DEAL".equals(trade_status)){
				 txnStatus = TxnStatus.UNKNOW;
				 channelResponseCode = TransReturnCode.code_9110;
				 retMsg = "等待用户支付";
			 }else if("FAIL".equals(trade_status) || "CLOSE".equals(trade_status)){
				 txnStatus = TxnStatus.FAILED;
				 channelResponseCode = TransReturnCode.code_9900;
				 retMsg = "交易失败";
			 }else{
				 txnStatus = TxnStatus.UNKNOW;
				 channelResponseCode = TransReturnCode.code_9110;
				 retMsg = "交易未知";
			 }
//			String bankRecvSn = resultMap.get("trade_no");
			String total_amount  = resultMap.get("total_amount");
			String receipt_amount  = resultMap.get("receipt_amount");
			String bankSendSn = resultMap.get("merchant_trade_no");
			String alipayTradeNo = resultMap.get("alipay_trade_no");
			BigDecimal feeAmount,actualAmount;
			if(StringUtils.isBlank(total_amount)){
				feeAmount = new BigDecimal("0");
			}else{
				feeAmount = new BigDecimal(total_amount).movePointLeft(2);
			}
			if(StringUtils.isBlank(receipt_amount)){
				actualAmount = new BigDecimal("0");
			}else{
				actualAmount = new BigDecimal(receipt_amount).movePointLeft(2);
			}
			//银行交易流水
			BillnoSn billnoSn = billnoSnService.findTranTypeByChannel(channelId, bankSendSn);
			Log4jUtil.info("获取到的billnoSn对象为：{}",billnoSn);
			Assert.notNull(billnoSn,"billnoSn表记录不能为空");
			Log4jUtil.info("开始更新数据库和发送消息队列：");
			
			billnoSn.setPayState(String.valueOf(txnStatus));
			billnoSn.setChannelRtnnote(retMsg);
			billnoSn.setChannelRtncode(channelResponseCode);
			billnoSn.setActualAmount(actualAmount);
			billnoSn.setAmount(feeAmount);
			billnoSn.setRecvTime(new Date());
			billnoSn.setState(BillnoSnState.billnoRecv);// 业务回执已返回
			billnoSn.setBankRecvSn(alipayTradeNo);
			
			int result = billnoSnService.updateByStatus(billnoSn);//更新交易流水
			if (result >= 1) {
				Log4jUtil.info("路由交易处理:channelResponseCode:{}", channelResponseCode);
				//路由交易处理
				routerTxnRecordService.updateCallBack(billnoSn.getSn(), feeAmount, channelResponseCode, retMsg);
				Map<String, String> msgMap = new HashMap<String, String>();
				msgMap.put("total_fee", feeAmount.toString());
				msgMap.put("bankSendSn", bankSendSn);
				msgMap.put("bankRecvSn", alipayTradeNo);
				//发送主动平台
				sendMQ(msgMap, billnoSn, channelResponseCode,txnStatus);
				Log4jUtil.info("包头农商行移动支付下单回调_发送MQ到主动支付处理完成!result:{}", result);
			} else {
				Log4jUtil.info("[重复请求，不发MQ]包头农商行移动支付下单回调_发送MQ到主动支付处理完成!result:{}", result);
			}
		} else {
			Log4jUtil.error("包头农商行移动支付下单回调_验签失败");
		}
	}
	
	/**
	 * MQ发送处理
	 * @param map
	 * @param billnoSn
	 * @param channelResponseCode
	 * @param status
	 */
	public void sendMQ(Map<String, String> map,BillnoSn billnoSn,String channelResponseCode,int status){
		ZdsmBackToZDPTDto resultDto = new ZdsmBackToZDPTDto();
		resultDto.setAmount(billnoSn.getAmount().toString());
		resultDto.setActual_amount(billnoSn.getActualAmount().toString());
		resultDto.setBankCardType(billnoSn.getBankCardType());
		resultDto.setChannelId(channelId);
		resultDto.setChannelResponseCode(channelResponseCode);
		resultDto.setOrgTxnId(billnoSn.getSn());
		resultDto.setSettlementAccountNo(billnoSn.getCorpacctno());
		resultDto.setTransactionId(map.get("bankRecvSn"));
		resultDto.setTxnStatus(String.valueOf(status));
		String sendmsg = com.alibaba.fastjson.JSONObject.toJSONString(resultDto);
		Log4jUtil.info("厦门平安移动支付下单回调_返回给主动支付平台的报文：【{}】",sendmsg);
		payMQSenderService.sendMQ(sendmsg);
	}
	
}
