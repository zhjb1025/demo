package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.dom4j.Element;
import org.soofa.util.StringUtils;

import com.lycheepay.cif.dto.agent.QueryMerchantResponseDTO;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.unipayBJ.utils.DateUtil;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.security.MD5Util;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;

public class RandomUtil {

	public static String random(int length){
		Random r = new Random();
		StringBuffer str = new StringBuffer();
		for(int i=0; i<length; i++){
			str.append(r.nextInt(10));
		}
		return str.toString();
	}
	
	public static void main(String[] args) {
		try {
			System.out.println(RandomUtil.mchinletMsg());
		} catch (BizException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static String mchinletMsg() throws BizException{
		

		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			Element root = dom4jxml.getRoot();
		
			dom4jxml.addNode(root, "rece_org_no", "rece_org_no");
			dom4jxml.addNode(root, "out_merchant_id", "out_merchant_id");
			dom4jxml.addNode(root, "merchant_name", "merchant_name");
			dom4jxml.addNode(root, "merchant_shortname", "merchant_shortname");
			dom4jxml.addNode(root, "service_phone", "service_phone");
			dom4jxml.addNode(root, "contact_name", "contact_name");
			dom4jxml.addNode(root, "contact_phone", "contact_phone");
			dom4jxml.addNode(root, "contact_email", "contact_email");
			dom4jxml.addNode(root, "business", "business");
			dom4jxml.addNode(root, "nonce_str", "nonce_str");
			
			String sign = packSign(dom4jxml,"key");
			dom4jxml.addNode(root, "sign", sign);

		}catch (Exception e) {
			// TODO: handle exception
			Log4jUtil.error("包头农商银行封装微信进件请求参数异常：" +e);
			throw new BizException(TransReturnCode.code_9900, "封装进件请求参数异常");
		}			
		return dom4jxml.toString();
	}
	
	/**
	 * 
	* @Description: 组装签名参数
	* @Author zmm
	* @Time 2018-1-10 下午7:25:48
	 */
	public static String packSign(Dom4jXMLMessage dom4jxml,String Key){
		Element root = dom4jxml.getRoot();
		List<Element> elements = root.elements();
		StringBuffer sb = new StringBuffer();
		for(Element element : elements){
			if("sign".equalsIgnoreCase(element.getName())){
				continue;
			}
			if(StringUtils.isNotBlank(element.getText())){
				sb.append(element.getName()).append("=").append(element.getText()).append("&");
			}
		}
		sb.append("key=" + Key);
		System.out.println(sb.toString());
		return MD5Util.md5(sb.toString()).toUpperCase();
	}
}
