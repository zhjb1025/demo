package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.service;

import java.io.UnsupportedEncodingException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.http.message.BasicNameValuePair;
import org.dom4j.Element;
import org.soofa.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.cif.dto.agent.QueryMerchantResponseDTO;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.RandomUtil;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.RandomUtils;
import com.lycheepay.clearing.adapter.banks.spdb.mobilePay.utils.HttpPostMsgUtils;
import com.lycheepay.clearing.adapter.banks.unipayBJ.utils.DateUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.security.MD5Util;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BDsmDTO;
import com.lycheepay.clearing.common.dto.trade.BDsmResultDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.MobileMenchartInfo;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.BAORCB_MOBILE_PAY_PACKAGE_SERVICE)
public class BaorcbMobilePayPackageService {

//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
//	private SequenceManagerService sequenceManagerService;
	
	/**
	 * 
	* @throws BizException 
	 * @Description: 封装微信进件请求参数
	* @Author zmm
	* @Time 2018-1-10 下午5:50:01
	 */
	public String mchinletWeChatMsg(QueryMerchantResponseDTO queryMerchantResponseDTO,
			String corpAccountId, String channelId,Map<String, String> channelParms) throws BizException{
		
		String shortName = StringUtils.isBlank(queryMerchantResponseDTO.getShortName()) ? queryMerchantResponseDTO.getMerchantName() : queryMerchantResponseDTO.getShortName();

		try {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			Element root = dom4jxml.getRoot();
		
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "out_merchant_id", corpAccountId);
			dom4jxml.addNode(root, "merchant_name", queryMerchantResponseDTO.getMerchantName());
			dom4jxml.addNode(root, "merchant_shortname", shortName);
			dom4jxml.addNode(root, "service_phone", queryMerchantResponseDTO.getTelePhone());
			dom4jxml.addNode(root, "contact_name", queryMerchantResponseDTO.getContactName());
			dom4jxml.addNode(root, "contact_phone", queryMerchantResponseDTO.getContactPhone());
//			dom4jxml.addNode(root, "contact_email", channelParms.get(Constants.mobileparam.MCH_KFT_CONTACT_EMAIL));
			dom4jxml.addNode(root, "business", queryMerchantResponseDTO.getIndustryCategory());
			dom4jxml.addNode(root, "nonce_str", DateUtil.getCompleteTime() + RandomUtil.random(8));
			
			String sign = packSign(dom4jxml,channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
			return dom4jxml.toString();
		}catch (Exception e) {
			// TODO: handle exception
			Log4jUtil.error("包头农商银行封装微信进件请求参数异常：" +e);
			throw new BizException(TransReturnCode.code_9900, "封装微信进件请求参数异常");
		}			
	}
	
	/**
	 * 
	* @throws BizException 
	 * @Description: 封装支付宝进件请求参数
	* @Author zmm
	* @Time 2018-1-10 下午5:50:01
	 */
	public String mchinletAlipayMsg(QueryMerchantResponseDTO queryMerchantResponseDTO,
			String corpAccountId, String channelId,Map<String, String> channelParms, BankaccountBalance bankaccountBalance) throws BizException{
		
		String shortName = StringUtils.isBlank(queryMerchantResponseDTO.getShortName()) ? queryMerchantResponseDTO.getMerchantName() : queryMerchantResponseDTO.getShortName();
		//截取商户简称的前19个字符
		if(shortName.length() >= 20){
			shortName = shortName.substring(0, 19);
		}
		
		try {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			Element root = dom4jxml.getRoot();
		
			dom4jxml.addNode(root, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(root, "rece_merchant_id", corpAccountId);
			dom4jxml.addNode(root, "merchant_name", queryMerchantResponseDTO.getMerchantName());
			dom4jxml.addNode(root, "merchant_shortname", shortName);
			dom4jxml.addNode(root, "service_phone", queryMerchantResponseDTO.getTelePhone());
			dom4jxml.addNode(root, "contact_name", queryMerchantResponseDTO.getContactName());
//			dom4jxml.addNode(root, "contact_phone", channelParms.get(Constants.mobileparam.MCH_KFT_CONTACT_MOBILE));
//			dom4jxml.addNode(root, "contact_email", channelParms.get(Constants.mobileparam.MCH_KFT_CONTACT_EMAIL));
			dom4jxml.addNode(root, "business", queryMerchantResponseDTO.getIndustryCategory());
//			dom4jxml.addNode(root, "business_license_type", );
			dom4jxml.addNode(root, "business_license", queryMerchantResponseDTO.getCertificateInfo().getBusinessLicense());
			dom4jxml.addNode(root, "contact_id_no", queryMerchantResponseDTO.getCertificateInfo().getLegalCertNo());
			dom4jxml.addNode(root, "card_no", bankaccountBalance.getAccountNo());
			dom4jxml.addNode(root, "card_name", bankaccountBalance.getAccountName());
			dom4jxml.addNode(root, "province_code", queryMerchantResponseDTO.getAddressInfo().getProvince());
			dom4jxml.addNode(root, "city_code", queryMerchantResponseDTO.getAddressInfo().getCity());
			dom4jxml.addNode(root, "district_code", queryMerchantResponseDTO.getAddressInfo().getDistrict());
			dom4jxml.addNode(root, "address", queryMerchantResponseDTO.getAddressInfo().getAddress());
			
			dom4jxml.addNode(root, "source", channelParms.get(Constants.aliPay.ALI_MER_SOURCE));
			
			dom4jxml.addNode(root, "nonce_str", DateUtil.getCompleteTime() + RandomUtil.random(8));
			
			String sign = packSign(dom4jxml,channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(root, "sign", sign);
			return dom4jxml.toString();
		}catch (Exception e) {
			// TODO: handle exception
			Log4jUtil.error("包头农商银行封装支付宝进件请求参数异常：" +e);
			throw new BizException(TransReturnCode.code_9900, "封装支付宝进件请求参数异常");
		}			
	}
	
	/**
	 * 组装微信公众号授权目录报文信息
	 */
	public String preCreateXMLWxConfigMsg(MobileMenchartInfo mobileMenchartInfo,
			Map<String, String> channelParms,String jsApiPath, String subAppId) throws Exception {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			//随机字符串，不长于32位
			String nonce_str = DateUtil.getCompleteTime() + RandomUtil.random(8);
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			// 根节点,1
			Element rootElement = dom4jxml.getRoot();
			dom4jxml.addNode(rootElement, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(rootElement, "merchant_id", mobileMenchartInfo.getMerNo());
			if (jsApiPath != null) {
				dom4jxml.addNode(rootElement, "jsapi_path", jsApiPath);
			}
			if (subAppId != null) {
				dom4jxml.addNode(rootElement, "sub_appid", subAppId);
			}
			dom4jxml.addNode(rootElement, "nonce_str", nonce_str);
			//组装签名参数
			String sign = packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(rootElement, "sign", sign);
			
		} catch (Exception e) {
			Log4jUtil.error("组装报文错误【{}】", e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("-------上传报文组装xml------【{}】", dom4jxml.toString());
		return dom4jxml.toString();
	}
	
	/**
	 * 
	* @Description: 组装签名参数
	* @Author lcy
	* @Time 2018-1-10 下午7:25:48
	 */
	public String packSign(Dom4jXMLMessage dom4jxml,String Key){
		Element root = dom4jxml.getRoot();
		List<Element> elements = root.elements();
		StringBuffer sb = new StringBuffer();
		Map<String, String> mapSign = new TreeMap<String, String>(new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		});
		
		for(Element element : elements){
			if("sign".equalsIgnoreCase(element.getName())){
				continue;
			}
			if(StringUtils.isNotBlank(element.getText())){
//				sb.append(element.getName()).append("=").append(element.getText()).append("&");
				mapSign.put(element.getName(),element.getText());
			}
		}
		for (Map.Entry<String, String> entry:mapSign.entrySet()) {
			sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
		}
		sb.append("key=" + Key);
		
		return MD5Util.md5(sb.toString()).toUpperCase();
	}

	/**
	 * 
	* @throws BizException 
	 * @throws UnsupportedEncodingException 
	 * @Description: 解析进件返回信息
	* @Author lcy
	* @Time 2018-1-11 上午9:22:03
	 */
	public Map<String, String> parseMchinletMsg(String resp,String type) throws BizException, UnsupportedEncodingException {
		Map<String,String> map = new HashMap<String,String>();
		try {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(resp.getBytes(Constants.charset));
			List<Element> elements = dom4jxml.getRoot().elements();
			for(Element element : elements){
				map.put(element.getName(), element.getText());
			}
		} catch (BizException e) {
			Log4jUtil.error("解析进件返回信息异常",e);
			throw new BizException(TransReturnCode.code_9109, "解析"+ type + "进件返回信息异常:"+e.getMessage());
		}		
		return map;
	}
}
