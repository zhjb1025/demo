package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.dom4j.Element;
import org.soofa.util.StringUtils;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.security.MD5Util;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * @author lcy
 */
public class BaorcbSignMd5 {
	
	/**
	 * 
	* @Description: 组装签名参数
	* @Author lcy
	* @Time 2018-1-30  下午15:00:00
	 */
	public static String packSign(Dom4jXMLMessage dom4jxml,String Key){
		Element root = dom4jxml.getRoot();
		List<Element> elements = root.elements();
		StringBuffer sb = new StringBuffer();
		Map<String, String> mapSign = new TreeMap<String, String>(new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		});
		
		for(Element element : elements){
			if("sign".equalsIgnoreCase(element.getName())){
				continue;
			}
			if(StringUtils.isNotBlank(element.getText())){
				mapSign.put(element.getName(),element.getText());
			}
		}
		for (Map.Entry<String, String> entry:mapSign.entrySet()) {
			sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
		}
		sb.append("key=" + Key);
		Log4jUtil.info("请求参数 加密前：", sb.toString());
		return MD5Util.md5(sb.toString()).toUpperCase();
	}
	
}
