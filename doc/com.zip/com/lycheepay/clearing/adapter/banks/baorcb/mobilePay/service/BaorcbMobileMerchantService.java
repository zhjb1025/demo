 package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.lycheepay.cif.dto.agent.QueryMerchantResponseDTO;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.BaorcbHttpPost;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.HttpResponseDTO;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.MobileMerchantState;
import com.lycheepay.clearing.adapter.common.dto.MerchantReportInfo;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.CorpChannelNoService;
import com.lycheepay.clearing.adapter.common.service.biz.MobileMenchartInfoService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.model.CorpChannelNo;
import com.lycheepay.clearing.common.model.MobileMenchartInfo;
import com.lycheepay.clearing.common.model.MobileMerchWxConfig;
import com.lycheepay.clearing.common.model.MoblieIndustryCode;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;

/**
 * 
 * @Title: BaorcbMobileMerchantService.java 
 * @Description：包头农商银行进件处理
 * @Author zmm
 * @Create 2018-1-9 下午4:19:31
 * @Version
 */
@Service(ClearingAdapterAnnotationName.BAORCB_MOBILE_MERCHANTH_SERVICE)
public class BaorcbMobileMerchantService {
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	private MobileMenchartInfoService mobileMenchartInfoService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BAORCB_MOBILE_PAY_PACKAGE_SERVICE)
	private BaorcbMobilePayPackageService baorcbMobilePayPackageService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CORP_ACCOUNT_NO_REF_SERVICE)
	private CorpChannelNoService corpChannelNoService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	/**
	 * 
	* @throws BizException 
	 * @Description: 处理商户进件
	* @Author zmm
	* @Time 2018-1-9 下午4:28:46
	 */
	public ClearingResultDTO report(QueryMerchantResponseDTO queryMerchantResponseDTO,
			String corpAccountId, String channelId,Map<String, String> channelParms) throws BizException {
		
		ClearingResultDTO  clearingResultDTO = new ClearingResultDTO();
		StringBuffer wechatmsg = new StringBuffer();
		StringBuffer alipaymsg = new StringBuffer();
		
		//检验商户是否已成功报备
		List<MobileMenchartInfo> mobileMenchartInfo = mobileMenchartInfoService.selectByCorpNo(channelId,corpAccountId,MobileMerchantState.SETTLETYPE_T1,null);
		
		if(mobileMenchartInfo.size() > 0){
			throw new BizException("已报备过此商户corpAccountId:" + corpAccountId);
		}
		
		//转换经营类目
		Map<String, String> mapInds = initMobileIndustryCodeMap(queryMerchantResponseDTO,channelId,channelParms);
				
		Map<String,String> wechatmap = null;		
		Map<String,String> alipaymap = null;
		
		//如果查到的进件信息为空，则支付宝、微信都进件
		if(mobileMenchartInfo == null || mobileMenchartInfo.size() == 0){
			//进件微信
			try {
//				wechatmap = wechatmerchant(queryMerchantResponseDTO,corpAccountId,channelId,channelParms,mapInds);				
			} catch (Exception e) {
				wechatmap = new HashMap<String,String>();
				wechatmsg.append("|微信进件异常："+ e.getMessage());
				Log4jUtil.info("微信进件异常：", e);
			}
			
			//进件支付宝	
			try {
				alipaymap = alipaymerchant(queryMerchantResponseDTO,corpAccountId,channelId,channelParms,mapInds);
			} catch (Exception e) {
				alipaymap = new HashMap<String,String>();
				alipaymsg.append("|支付宝进件异常："+ e.getMessage());
				Log4jUtil.info("支付宝进件异常：", e);
			}			
			
		} else {//否则 如果查询已进件结果中 支付方式为1：微信。 则支付宝 可以重新进件
			if(MobileMerchantState.BANK_PAYWAY_WECHAT.equalsIgnoreCase(mobileMenchartInfo.get(0).getBankPayway())){
				//进件支付宝	
				try {
					alipaymap = alipaymerchant(queryMerchantResponseDTO,corpAccountId,channelId,channelParms,mapInds);
				} catch (Exception e) {
					alipaymap = new HashMap<String,String>();
					alipaymsg.append("|支付宝进件异常："+ e.getMessage());
					Log4jUtil.info("支付宝进件异常：", e);
				}

			} else {//否则进件微信
				try {
//					wechatmap = wechatmerchant(queryMerchantResponseDTO,corpAccountId,channelId,channelParms,mapInds);					
				} catch (Exception e) {
					wechatmap = new HashMap<String,String>();
					wechatmsg.append("|微信进件异常："+ e.getMessage());
					Log4jUtil.info("微信进件异常：", e);
				}
			}
		}
		
		//微信进件成功，则保存对应信息
//		String wechatresult = "";
//		if(Constants.SUCCESS.equalsIgnoreCase(wechatmap.get("return_code")) && Constants.SUCCESS.equalsIgnoreCase(wechatmap.get("result_code"))){
//			String bankMchId = wechatmap.get("merchant_id");
//			String sub_merchant_id = wechatmap.get("sub_merchant_id");
//			
//			MerchantReportInfo mer_rep = new MerchantReportInfo();
//			mer_rep.setBankMchId(bankMchId);
//			mer_rep.setSub_merchant_id(sub_merchant_id);
//			mer_rep.setBankPayway(MobileMerchantState.BANK_PAYWAY_WECHAT);
//			mer_rep.setChannelId(channelId);
//			mer_rep.setCorpAccountId(corpAccountId);
//			mer_rep.setSettletype(MobileMerchantState.SETTLETYPE_T1);
//			mer_rep.setSub_merchant_id(sub_merchant_id);
//			mer_rep.setState(MobileMerchantState.reportstate.activation);
//			mer_rep.setMapstate(MobileMerchantState.mapstate_available);
//			
//			//保存进件成功相关信息
//			wechatresult = mobileMenchartInfoService.saveReportedInfo(mer_rep,queryMerchantResponseDTO);
//		} else {
//			if(StringUtils.isBlank(wechatmsg)){
//				wechatmsg.append("|微信进件返回信息：");
//				if(StringUtils.isNotBlank(wechatmap.get("err_code_des"))){
//					wechatmsg.append(wechatmap.get("err_code_des"));
//				} else{
//					wechatmsg.append(wechatmap.get("return_msg"));
//				}
//			}						
//		}
		
		//支付宝进件成功，则保存对应信息
		String alipayresult = "";
		if(Constants.SUCCESS.equalsIgnoreCase(alipaymap.get("return_code")) && Constants.SUCCESS.equalsIgnoreCase(alipaymap.get("result_code"))){
			String bankMchId = alipaymap.get("merchant_id");
			String sub_merchant_id = alipaymap.get("sub_merchant_id");
			
			MerchantReportInfo mer_rep = new MerchantReportInfo();
			mer_rep.setBankMchId(bankMchId);
			mer_rep.setSub_merchant_id(sub_merchant_id);
			mer_rep.setBankPayway(MobileMerchantState.BANK_PAYWAY_ALIPAY);
			mer_rep.setChannelId(channelId);
			mer_rep.setCorpAccountId(corpAccountId);
			mer_rep.setSettletype(MobileMerchantState.SETTLETYPE_T1);
			mer_rep.setState(MobileMerchantState.reportstate.activation);
			mer_rep.setMapstate(MobileMerchantState.mapstate_available);
			
			//保存进件成功相关信息
			alipayresult = mobileMenchartInfoService.saveReportedInfo(mer_rep,queryMerchantResponseDTO);
		} else{
			if(StringUtils.isBlank(alipaymsg)){
				alipaymsg.append("|支付宝进件返回信息：");
//				if(StringUtils.isNotBlank(wechatmap.get("err_code_des"))){
//					alipaymsg.append(wechatmap.get("err_code_des"));
//				} else{
//					alipaymsg.append(wechatmap.get("return_msg"));
//				}	
			}			
		}
		
		String msg = alipaymsg.append(wechatmsg).toString();
		
		if(StringUtils.isBlank(msg)){
			String resp = "进件成功:";
//			if(StringUtils.isNotBlank(wechatresult)){
//				resp = resp + "|" + wechatresult;
//			}
			if(StringUtils.isNotBlank(alipayresult)){
				resp = resp + "|" + alipayresult;
			}
			clearingResultDTO.setChannelResponseMsg(resp.replaceFirst("|", ""));
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			clearingResultDTO.setTxnStatus(TxnStatus.SUCCEED);			
		} else {
			clearingResultDTO.setChannelResponseMsg("进件失败:"+msg.toString().replaceFirst("|", ""));
			clearingResultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			clearingResultDTO.setTxnStatus(TxnStatus.FAILED);
		}

		return clearingResultDTO;
	}

	/**
	 * 转换经营类目
	 * @param queryMerchantResponseDTO
	 * @param channelId
	 * @param channelParms
	 * @return
	 * @throws BizException
	 */
	private Map<String, String> initMobileIndustryCodeMap(QueryMerchantResponseDTO queryMerchantResponseDTO,
			 String channelId,Map<String, String> channelParms) throws BizException{
		String kftCode = queryMerchantResponseDTO.getIndustryCategory();
		Map<String, String> mapIndustry = new HashMap<String, String>();
		if(StringUtils.isBlank(kftCode) || kftCode.length() <3){
			//设置默认值
			kftCode = channelParms.get(Constants.mobileparam.MCH_ULINE_INDUSTRY_CATEGROY);
		} else {
			for (int i=1; i <= 2; i++) {
				if (i==1) {
					MoblieIndustryCode moblieIndustryCode = mobileMenchartInfoService.selectMchBankCodeByPayWay(channelId, kftCode.substring(0,3), String.valueOf(i));
					mapIndustry.put("weChatInds", moblieIndustryCode.getBankCode());
				} else {
					MoblieIndustryCode moblieIndustryCode = mobileMenchartInfoService.selectMchBankCodeByPayWay(channelId, kftCode.substring(0,3), String.valueOf(i));
					mapIndustry.put("aliInds", moblieIndustryCode.getBankCode());
				}
			}
		}
		return mapIndustry;
	}
	
	/**
	 * 微信进件
	 */
	public Map<String,String> wechatmerchant(QueryMerchantResponseDTO queryMerchantResponseDTO,
			String corpAccountId, String channelId,Map<String, String> channelParms, Map<String, String> mapInds) throws Exception{
		//转换经营类目
//		Map<String, String> mapInds = initMobileIndustryCodeMap(queryMerchantResponseDTO, channelId, channelParms);
		queryMerchantResponseDTO.setIndustryCategory(mapInds.get("weChatInds"));
		
		//组装进件请求参数
		String wechatreq = baorcbMobilePayPackageService.mchinletWeChatMsg(queryMerchantResponseDTO, corpAccountId, channelId, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_MCH_MCHINLET);
		url += path;
		
		//发送进件请求
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, wechatreq);
		
		//验证返回结果
		checkResponseDTO(httpRespDTO);
		
		//解析银行返回信息
		Map<String,String> wechatmap = baorcbMobilePayPackageService.parseMchinletMsg(httpRespDTO.getReturnMsg(),"Wechat");
		
		checkResponseInfo(wechatmap);
		return wechatmap;
	}
	
	//返回结果处理判断
	private void checkResponseInfo(Map<String,String> respInfo) throws BizException {
		String return_code = respInfo.get("return_code");										//返回状态码, SUCCESS 表示成功 FAIL 表示失败 此字段是通信标识，非交易标识，交易是否成功需要查看 trade_state 来判断
		String return_msg = respInfo.get("return_msg");
		String result_code = "";
		String err_code = "" ;
		String err_code_des = "";
		if("SUCCESS".equals(return_code)) {
			result_code = respInfo.get("result_code");										//业务返回结果，SUCCESS 表示成功 FAIL 表示失败
			err_code = respInfo.get("err_code");										    //参考错误码
			err_code_des = respInfo.get("err_code_des");
			if ("SUCCESS".equals(result_code)) {
				Log4jUtil.info("进件返回码："+result_code);
			} else {
				if ("CNL00002".equals(err_code) || "CNL00003".equals(err_code)) {	
					Log4jUtil.info("进件返回参数处理==结果未知==异常：", err_code);
					Log4jUtil.info("进件返回参数处理==结果未知==异常：", err_code_des);
					throw new BizException(TransReturnCode.code_9900, err_code_des);
				 } else {
					 Log4jUtil.info("进件返回参数处理==结果失败==异常：", err_code);
					 Log4jUtil.info("进件返回参数处理==结果失败==异常：", err_code_des);
					 throw new BizException(TransReturnCode.code_9900, err_code_des);
				 }
			}
		} else {
			 Log4jUtil.info("进件返回参数处理==结果失败==异常：", return_code);
			 Log4jUtil.info("进件返回参数处理==结果失败==异常：", return_msg);
			 throw new BizException(TransReturnCode.code_9900, return_msg);
		}
		
	}
	
	/**
	 * 支付宝进件
	 */
	public Map<String,String> alipaymerchant(QueryMerchantResponseDTO queryMerchantResponseDTO,
			String corpAccountId, String channelId,Map<String, String> channelParms, Map<String, String> mapInds) throws Exception{
		//转换经营类目
//		Map<String, String> mapInds = initMobileIndustryCodeMap(queryMerchantResponseDTO, channelId, channelParms);
		queryMerchantResponseDTO.setIndustryCategory(mapInds.get("aliInds"));
		//获取结算账号信息
		BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		//组装进件请求参数
		String alipayreq = baorcbMobilePayPackageService.mchinletAlipayMsg(queryMerchantResponseDTO, corpAccountId, channelId, channelParms, bankaccountBalance);
		
		//拼接請求路徑
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_MCH_MCHINLET);
		url += path;
		
		//发送进件请求
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, alipayreq);
		
		//验证返回结果
		checkResponseDTO(httpRespDTO);

		//解析银行返回信息
		Map<String,String> alipaymap = baorcbMobilePayPackageService.parseMchinletMsg(httpRespDTO.getReturnMsg(),"Alipay");

		//解析银行返回信息
		checkResponseInfo(alipaymap);
		
		return alipaymap;
	}
	//验证返回结果
	public void checkResponseDTO(HttpResponseDTO httpRespDTO)throws BizException{
		if (httpRespDTO.isSendSuccess()==false) {
			throw new BizException(TransReturnCode.code_9108,"发请求前处理出错");
		}
		if (httpRespDTO.isRespSuccess()==false) {
			throw new BizException(TransReturnCode.code_9109,"http请求响应出错");
		}
		
	}


	/**
	 * 
	* @Description: 添加微信公众号授权目录等配置
	* @Author zmm
	* @Time 2018-1-11 下午8:58:20
	 */
	public ClearingResultDTO wxConfig(String channelId, String corpAccountId,
			String jsApiPath, String subAppId) throws Exception {
		
		ClearingResultDTO clsDto = new ClearingResultDTO();
		
		//查询渠道参数信息
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelIdNoCache(channelId);

		//初始化商户号、二级商户号
		CorpChannelNo corpChannelNo = corpChannelNoService.queryByChannelIdAndCorpNoNoCach(channelId, corpAccountId);
		AssertUtils.notNull(corpChannelNo, TransReturnCode.code_9108, "商户未进件成功,不能配置微信公众号支付!");
		
		//获取T_MOBILE_MERCHANT_BANK_INFO表记录
		MobileMenchartInfo mobileMenchartInfo = mobileMenchartInfoService.selectByBankMchId(channelId, corpChannelNo.getChannelCorpNo().split("\\|")[1], "1");

		MobileMerchWxConfig mobileMerchWxConfig = mobileMenchartInfoService.selectWxConfig(corpAccountId, channelId);
		if (mobileMerchWxConfig==null) {
			mobileMerchWxConfig = new MobileMerchWxConfig();
			mobileMerchWxConfig.setAcctId(corpAccountId);
			mobileMerchWxConfig.setMerName(mobileMenchartInfo.getMerName());
			mobileMerchWxConfig.setChannelId(channelId);
			mobileMerchWxConfig.setAppId(subAppId);
			mobileMerchWxConfig.setAuthCatalog(jsApiPath);
			mobileMerchWxConfig.setStatus(0);//0:报备中;1:成功;2:失败
			mobileMenchartInfoService.saveWxConfig(mobileMerchWxConfig);
		} else {
			mobileMerchWxConfig.setAppId(subAppId);
			mobileMerchWxConfig.setAuthCatalog(jsApiPath);
			mobileMerchWxConfig.setStatus(0);//0:报备中;1:成功;2:失败
			mobileMenchartInfoService.updateWxConfig(mobileMerchWxConfig);
		}
		try{
			//授权jsApiPath
			Map<String, String> retApiPathMsg = wxItemConfig(mobileMenchartInfo,channelParms,jsApiPath,null);
			//解析返回参数
			checkResponseInfo(retApiPathMsg);
			//subAppId
			Map<String, String> retAppIdMsg = wxItemConfig(mobileMenchartInfo,channelParms,null,subAppId);
			//解析返回参数
			checkResponseInfo(retAppIdMsg);
			
			clsDto.setChannelResponseMsg("公众号支付配置成功");
			clsDto.setChannelResponseCode(TransReturnCode.code_0000);
			clsDto.setTxnStatus(TxnStatus.SUCCEED);
			clsDto.setChannelId(channelId);
		} catch (Exception e) {
			Log4jUtil.error("公众号支付配置异常", e);
			mobileMerchWxConfig.setStatus(2);
			mobileMenchartInfoService.updateWxConfig(mobileMerchWxConfig);
			throw e;
		}
		
		mobileMerchWxConfig.setStatus(1);
		mobileMenchartInfoService.updateWxConfig(mobileMerchWxConfig);
		return clsDto;	
	}
	
	/**
	 * @param mobileMenchartInfo
	 * @param channelParms
	 * @param jsApiPath
	 * @param subAppId
	 * @return
	 * @throws Exception
	 */
	private Map<String, String> wxItemConfig(MobileMenchartInfo mobileMenchartInfo,
			Map<String, String> channelParms,String jsApiPath, String subAppId) throws Exception {
		//组装微信公众号授权目录
		String sendMsg = baorcbMobilePayPackageService.preCreateXMLWxConfigMsg(mobileMenchartInfo, channelParms, jsApiPath, subAppId);
		
		//拼接請求路徑
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_CONFIG_URL);
		url += path;
		
		//发送进件请求
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, sendMsg);
		
		//验证返回结果
		checkResponseDTO(httpRespDTO);
		
		//解析银行返回信息
		Map<String,String> retMsg = baorcbMobilePayPackageService.parseMchinletMsg(httpRespDTO.getReturnMsg(),"WeChatConfig");
		
		return retMsg ;
	}
	
}
