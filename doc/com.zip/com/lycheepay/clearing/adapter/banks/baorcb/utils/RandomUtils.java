package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.util.Random;

public class RandomUtils {
	
	/**
	 * 字母，数字，随机生成指 定长度的 随机字符串
	 * @param length
	 * @return
	 */
	public static String getRandomString(int length) {
		String base = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		Random rand = new Random();
		StringBuffer randString = new StringBuffer();
		for (int i=0; i<length; i++) {
			randString.append(base.charAt(rand.nextInt(base.length())));
		}
		return randString.toString();
	}

}
