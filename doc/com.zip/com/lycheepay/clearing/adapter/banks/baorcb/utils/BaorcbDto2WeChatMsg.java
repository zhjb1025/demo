package com.lycheepay.clearing.adapter.banks.baorcb.utils;

import java.util.Date;
import java.util.Map;
import org.dom4j.Element;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.spdbXM.mobilePay.utils.RandomUtils;
import com.lycheepay.clearing.adapter.common.constant.biz.MobileMerchantState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BDsmDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPayRefundDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;

public class BaorcbDto2WeChatMsg {
	/**
	 *被扫- 微信码支付--请求xml
	 * @param zdsmDTO
	 * @param bankSendSn
	 * @return
	 * @throws BizException 
	 */
	public static String preCreateXMLBDsmMsg(BDsmDTO bDsmDTO, String bankSendSn, Map<String, String> channelParms) throws BizException{
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			//随机字符串，不长于32位
			String nonce_str = RandomUtils.getRandomString(32);
			
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			
			// 根节点,1
			Element rootElement = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(rootElement, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(rootElement, "nonce_str", nonce_str);
			dom4jxml.addNode(rootElement, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(rootElement, "body", bDsmDTO.getTradeName());
			dom4jxml.addNode(rootElement, "merchant_trade_no", bankSendSn);
			dom4jxml.addNode(rootElement, "total_fee", bDsmDTO.getAmount().movePointRight(2).toString());
			//终端IP
			dom4jxml.addNode(rootElement, "spbill_create_ip", "127.0.0.1");
			dom4jxml.addNode(rootElement, "auth_code", bDsmDTO.getAuthCode());
			
			Log4jUtil.info("-------上传xml------:【{}】", dom4jxml.toString());
			//把数据组装好 数字签名
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			
			dom4jxml.addNode(rootElement, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error("组装报文错误【{}】", e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("-------上传报文组装xml------【{}】", dom4jxml.toString());
		return dom4jxml.toString();
	}
	/**
	 * 主动扫码 - 微信 - 支付
	 * @param zdsmDto
	 * @param bankSendSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 */
	public static String createZdsmWxpayMsg(ZDsmDTO zdsmDto, String bankSendSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		Date date = DateUtil.addSeconds(new Date(), 7200);
		String dateformat = DateUtil.formatDateByPattern(date, "yyyyMMddHHmmss");
		try {
			//随机字符串，不长于32位
			String nonce_str = RandomUtils.getRandomString(32);
			
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			
			// 根节点,1
			Element rootElement = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(rootElement, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(rootElement, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(rootElement, "body", zdsmDto.getTradeName());
			dom4jxml.addNode(rootElement, "merchant_trade_no", bankSendSn);
			dom4jxml.addNode(rootElement, "total_fee", zdsmDto.getAmount().movePointRight(2).toString());
			dom4jxml.addNode(rootElement, "spbill_create_ip", "127.0.0.1");
			dom4jxml.addNode(rootElement, "expire_time", dateformat);
			dom4jxml.addNode(rootElement, "notify_url", channelParms.get(Constants.mobileparam.CALL_BACK_URL));
			dom4jxml.addNode(rootElement, "trade_type", "NATIVE");
			dom4jxml.addNode(rootElement, "nonce_str", nonce_str);
			//把数据组装好 数字签名
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(rootElement, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error("组装报文错误【{}】", e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("-------上传报文组装xml------【{}】", dom4jxml.toString());
		return dom4jxml.toString();
	}
	/**
	 * 微信 - 公众号
	 * @param jsapiPayDTO
	 * @param bankSendSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 * 2018年2月2日 上午11:18:40
	 */
	public static String createJsapiPayMsg(JsapiPayDTO jsapiPayDTO, String bankSendSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		Date date = DateUtil.addSeconds(new Date(), 7200);
		String dateformat = DateUtil.formatDateByPattern(date, "yyyyMMddHHmmss");
		try {
			//随机字符串，不长于32位
			String nonce_str = RandomUtils.getRandomString(32);
			String tradeAmount = jsapiPayDTO.getAmount() == null ? "0" : jsapiPayDTO.getAmount().movePointRight(2).toString();
			
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			
			// 根节点,1
			Element rootElement = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(rootElement, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(rootElement, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(rootElement, "body", jsapiPayDTO.getTradeName());
			dom4jxml.addNode(rootElement, "merchant_trade_no", bankSendSn);
			dom4jxml.addNode(rootElement, "total_fee", tradeAmount);
			dom4jxml.addNode(rootElement, "spbill_create_ip", "127.0.0.1");
			dom4jxml.addNode(rootElement, "expire_time", dateformat);
			dom4jxml.addNode(rootElement, "notify_url", channelParms.get(Constants.mobileparam.CALL_BACK_URL));
			dom4jxml.addNode(rootElement, "trade_type", "JSAPI");
			dom4jxml.addNode(rootElement, "sub_appid", jsapiPayDTO.getSub_appid());
			dom4jxml.addNode(rootElement, "sub_openid", jsapiPayDTO.getUserOpenId());
			dom4jxml.addNode(rootElement, "nonce_str", nonce_str);
			//把数据组装好 数字签名
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(rootElement, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error("组装报文错误【{}】", e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("-------上传报文组装xml------【{}】", dom4jxml.toString());
		return dom4jxml.toString();
	}
	
	public static String createZdPayRufundMsg(ZDPayRefundDTO zdPayRefundDTO, String bankSendSn, BillnoSn oriBillNoSn, Map<String, String> channelParms) throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			//随机字符串，不长于32位
			String nonce_str = RandomUtils.getRandomString(32);
			String reFundFee = zdPayRefundDTO.getAmount() == null ? "0" : zdPayRefundDTO.getAmount().movePointRight(2).toString();
			String totalFee = oriBillNoSn.getAmount() == null ? "0" : oriBillNoSn.getAmount().movePointRight(2).toString();
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("xml");
			dom4jxml.setEncoding(Constants.charset);
			
			// 根节点,1
			Element rootElement = dom4jxml.getRoot();
			// 根节点,2
			dom4jxml.addNode(rootElement, "rece_org_no", channelParms.get(Constants.mobileparam.rece_org_no));
			dom4jxml.addNode(rootElement, "merchant_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(rootElement, "merchant_trade_no", oriBillNoSn.getBankSendSn());
			dom4jxml.addNode(rootElement, "merchant_refund_no", bankSendSn);
			dom4jxml.addNode(rootElement, "total_fee", totalFee);
			dom4jxml.addNode(rootElement, "refund_fee", reFundFee);
			dom4jxml.addNode(rootElement, "op_user_id", channelParms.get(MobileMerchantState.MERCHANT_NO));
			dom4jxml.addNode(rootElement, "nonce_str", nonce_str);
			//把数据组装好 数字签名
			String sign = BaorcbSignMd5.packSign(dom4jxml, channelParms.get(Constants.mobileparam.rece_org_key));
			dom4jxml.addNode(rootElement, "sign", sign);
		} catch (Exception e) {
			Log4jUtil.error("组装报文错误【{}】", e);
			throw new BizException(e, TransReturnCode.code_9108, "组装报文错误");
		}
		Log4jUtil.info("-------上传报文组装xml------【{}】", dom4jxml.toString());
		return dom4jxml.toString();
	}
	
	
	
}
