package com.lycheepay.clearing.adapter.banks.baorcb.utils;


import java.nio.charset.Charset;
import java.util.Map;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;

public class BaorcbMobilePayHttpPostMsg {
	
	public BaorcbMobilePayHttpPostMsg() {}
	
	public static String sendMsg(String url, String msg, Map<String, String> channelParms) throws BizException {
		String result = null ;
		HttpClient httpClient = null;
		PostMethod postMethod = null ;
		int statusCode ;
		try {
			httpClient = new HttpClient();
			postMethod = new PostMethod(url);
			httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(20000);
			httpClient.getHttpConnectionManager().getParams().setSoTimeout(20000);
			Log4jUtil.info("配置参数：{}", channelParms);
			Log4jUtil.info("厦门浦发银行URL:{}, 发送报文:{}", url, msg);
			postMethod.addRequestHeader("Content-Type", "application/xml; charset=utf-8");
			RequestEntity entity = new StringRequestEntity(msg, "text/xml", Constants.charset);
			postMethod.setRequestEntity(entity);
			statusCode = httpClient.executeMethod(postMethod);
		} catch (Exception e) {
			Log4jUtil.error("厦门浦发银行发送报文异常：【{}】", e.getMessage());
			throw new BizException(e, TransReturnCode.code_9108, "网络通讯故障,发送请求异常");
		}
		byte[] response = null ;
		try {
			if (statusCode != HttpStatus.SC_OK) {
				Log4jUtil.error("postMethod failed: 【{}】", postMethod.getStatusLine());
				throw new BizException("http statusCode：" + postMethod.getStatusLine());
			}
			response = postMethod.getResponseBody();
			result = new String(response, Charset.forName(Constants.charset));
			Log4jUtil.info("返回报文内容:{}", result);
			if (StringUtil.isBlank(result)) {
				Log4jUtil.error("包头农商行回执信息为空");
				throw new BizException(TransReturnCode.code_9109, "银行回执信息为空");
			}
		} catch (Exception e) {
			Log4jUtil.error("包头农商行接受报文异常：【{}】", e.getMessage());
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		} finally {
			if (postMethod != null) 
				postMethod.releaseConnection();
		}
		return result;
	}
}
