package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.handler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.unipayBJ.utils.DateUtil;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.SftpUtilByPass;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.BAORCB_MOBILEPAY_RECON_HANDLER)
public class BaorcbMobilePayReconHandler implements ReconciliationFileServiceInner {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Override
	public String getReconciliationFile(String fileSavePath, String channelId,
			String settleDate) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BAORCB", "reconFile");

		//清算日期格式校验，正确格式yyyymmdd
		settleDate = ReconciliationFileUtil.verifyInputParameters("包头农商行移动支付", fileSavePath, channelId, settleDate);
		
		//查询通道配置信息
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		
		StringBuffer sb = new StringBuffer("WM_");
		sb.append(settleDate).append("_").append(channelParms.get(Constants.mobileparam.rece_org_no)).append(".csv");
		String rcvFileName = sb.toString();
		
		Log4jUtil.info("受理机构号：{}对账文件名为：{}", channelParms.get(Constants.mobileparam.rece_org_no), rcvFileName);
		
		String localPath= channelParms.get(Constants.mobileparam.FTP_LOCAL_PATH);
		File file = new File(localPath + File.separator + settleDate);
		Log4jUtil.info("预删除的临时文件存放目录为：{}" , file.getAbsolutePath());
		
		
		
		List<ReconciliationFileDTO> list = new ArrayList<ReconciliationFileDTO>();
		String fileFullPath = null;
		try {
			if (CollectionUtils.isEmpty(channelParms)) {
                throw new ClearingAdapterBizCheckedException(BusinessCode.GET_RECONCILIATION_FILE_FAILED,"包头农商行移动支付（清算对帐）-无法获取渠道参数配置");
            }
            
            String tcRecvFilePath = channelParms.get(Constants.mobileparam.FTP_LOCAL_PATH);
			
			if (file.exists()) {
	            FileUtils.cleanDirectory(file);
	        }
			//从包头农商行SFTP下载文件到服务器目录
			String realFileName = downloadFileFromftp(rcvFileName, channelId, channelParms, settleDate);
			Log4jUtil.info("下载成功,主商户对账文件下载到本地临时目录的完整文件名为：{}", realFileName);
			
			try {
				//解析下载的对账文件，数据存入List中
				List<ReconciliationFileDTO> mainMerInfoList = parseReconFile(realFileName, channelId, settleDate);
				if (mainMerInfoList != null && mainMerInfoList.size() > 0) {
					list.addAll(mainMerInfoList);
				}
			} catch (Exception e) {
				Log4jUtil.error("解析文件异常", e.getMessage());
			}
			Log4jUtil.info("生成统一格式对账文件，对账文件总笔数为：{}", list.size());
		} catch (Exception e) {
			Log4jUtil.error(e);
		}
		//生成统一格式对账文件，放到服务器上
		fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate, list);
		return fileFullPath;
	}

	@Override
	public String convertToStandardReconciliationFile(String targetFilePath,
			String fileSavePath, String channelId, String settleDate)
			throws ClearingAdapterBizCheckedException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String downloadFileFromftp(String rcvFileName, String channelId, Map<String, String> channelParms, String dateStr)
			throws Exception {
		// 1、下载CT服务器上的文件
		String ipAddress = channelParms.get(Constants.mobileparam.FTP_IP_ADDRESS);
		String userName = channelParms.get(Constants.mobileparam.FTP_USER_NAME);
		String passWd = channelParms.get(Constants.mobileparam.FTP_PASSWORD);
		int port = Integer.parseInt(channelParms.get(Constants.mobileparam.FTP_PORT));
		String routerPath = channelParms.get(Constants.mobileparam.FTP_ROUTER_PATH);
		String localPath = channelParms.get(Constants.mobileparam.FTP_LOCAL_PATH) + File.separator + dateStr;
		String localFileName = localPath + File.separator + rcvFileName;
		try {
			Assert.notEmpty(ipAddress, "包头农商行移动支付（清算对帐）sftp服务器ftpIp不能为空");
	        Assert.notEmpty(port+"", "包头农商行移动支付（清算对帐）sftp服务器ftp端口不能为空");
	        Assert.notEmpty(passWd, "包头农商行移动支付（清算对帐）sftp客户端ftp登录密码不能为空");
	        Assert.notEmpty(userName, "包头农商行移动支付（清算对帐）sftp服务器ftp登录用户不能为空");
	        Assert.notEmpty(routerPath, "包头农商行移动支付（清算对帐）sftp服务器根目录路径不能为空");
	        Assert.notEmpty(localPath, "包头农商行移动支付（清算对帐）商户号不能为空");
	        //连接SFTP下载文件到localPath目录下
//			FtpManager.downFTP(ipAddress, userName, passWd, routerPath, localPath, rcvFileName, port);
		
	        SftpUtilByPass sf = new SftpUtilByPass(ipAddress, userName, null, passWd, Integer.valueOf(port));
	        ChannelSftp sftp = null;
	        // 如果临时目录不存在，则新建该路径
            FileProcess.createDir(localPath);
            
            Log4jUtil.info("包头农商行移动支付（清算对帐）请求下载的对账文件目录:{},文件名:{},本地存储路径" , routerPath, rcvFileName, localFileName);
        	sftp = sf.connectByPasswd();
            sftp.setFilenameEncoding("UTF-8");
            
            sf.download(routerPath, rcvFileName, localFileName, sftp);
		} catch (Exception e) {
			Log4jUtil.info(e);
		}
        
		return localFileName;
	}
	
	public List<ReconciliationFileDTO> parseReconFile(String realFileName, String channelId, String settleDate)
			throws ClearingAdapterBizCheckedException, UnsupportedEncodingException, FileNotFoundException {
		Log4jUtil.info(">>>>>>进入对账文件转换realFileName:{}", realFileName);
		if (!new File(realFileName).exists()) {
			Log4jUtil.info("包头农商行移动支付-对账单查询出错，错误信息： 找不到对账文件");
			throw new ClearingAdapterBizCheckedException(BusinessCode.FILE_NOT_FOUND, "包头农商行对账单查询出错，错误信息： 找不到对账文件");
		}
		if (new File(realFileName).length() <= 0) {
			Log4jUtil.info("包头农商行移动支付-对账单查询出错，错误信息： 对账文件名：{}内容为空", realFileName);
			return null;
		}
		Log4jUtil.info("进入对账文件转换realFileName:{}", realFileName);
		List<ReconciliationFileDTO> list = new ArrayList<ReconciliationFileDTO>();
		InputStreamReader reader = null;
		BufferedReader br = null;
		try {
			reader = new InputStreamReader(new FileInputStream(realFileName), Constants.charset);
			br = new BufferedReader(reader);
			String line = null ;
			while ((line = br.readLine()) != null) {
				String [] reCon = line.split(",");
				if (reCon == null || reCon.length < 13) {
					continue;
				}
				ReconciliationFileDTO dto = new ReconciliationFileDTO();
				dto.setBankRecvSN(reCon[8].trim());
				dto.setCheckDate(settleDate);
				if ("REFUND".equals(reCon[5].trim())) {
					dto.setBankSendId(reCon[9].trim());
				} else {
					dto.setBankSendId(reCon[7].trim());
				}
				String transDate = DateUtil.formartDate(reCon[0].trim(), DateUtil.FORMAT_DATETIME_BIAS, DateUtil.FORMAT_TRADEDATE);
				dto.setTransDate(transDate);
				dto.setAmount(new BigDecimal(reCon[11].trim()).abs().movePointLeft(2));
				dto.setBankTransState(reCon[6].trim().equals("SUCCESS") ? "00" : "01"); // 交易状态00-支付成功；01-支付失败
				dto.setPayGet(reCon[5].trim().equals("PAY") ? "get" : "pay");//PAY（正交易）REFUND（退款）
				dto.setChannelId(channelId);
				
				list.add(dto);
				
			}
		} catch (Exception e) {
			Log4jUtil.error(e);
		} finally {
			IOUtils.closeQuietly(reader);
			IOUtils.closeQuietly(br);
		}
		return list;
	}

}
