package com.lycheepay.clearing.adapter.banks.baorcb.mobilePay.service;

import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.lycheepay.clearing.adapter.banks.baorcb.constant.Constants;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.BaorcbDto2AlipayMsg;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.BaorcbDto2WeChatMsg;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.BaorcbHttpPost;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.BaorcbVerificationSignMD5;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.HttpResponseDTO;
import com.lycheepay.clearing.adapter.banks.baorcb.utils.Msg2Dto;
import com.lycheepay.clearing.adapter.banks.pinganXM.mobilePay.service.PinganXMMobilePayMQSenderService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.mapper.AdapterTxnRecordMapper;
import com.lycheepay.clearing.adapter.common.mapper.BillnoSnMapper;
import com.lycheepay.clearing.adapter.common.mapper.MobilePayInfoMapper;
import com.lycheepay.clearing.adapter.common.service.biz.AdaptMenchartService;
import com.lycheepay.clearing.adapter.common.service.biz.MobileMenchartInfoService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.common.ZdsmBackToZDPTDto;
import com.lycheepay.clearing.common.dto.trade.BDsmDTO;
import com.lycheepay.clearing.common.dto.trade.BDsmResultDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayDTO;
import com.lycheepay.clearing.common.dto.trade.JsapiPayResultDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPTradeResultDTO;
import com.lycheepay.clearing.common.dto.trade.ZDPayRefundDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmDTO;
import com.lycheepay.clearing.common.dto.trade.ZDsmResultDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.MobileMenchartInfo;
import com.lycheepay.clearing.common.model.MobilePayInfo;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * @Title: BaorcbMobilePayProcessService.java 
 * @Description：包头农商行移动支付服务处理类
 * @Author lcy
 * @Create 2018-01-30 下午13:25:38
 * @Version
 */

@Service(ClearingAdapterAnnotationName.BAORCB_MOBILE_PAY_PROCESS_SERVICE)
public class BaorcbMobilePayProcessService {
	
	@Autowired
	private MobileMenchartInfoService mobileMenchartInfoService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BAORCB_MOBILE_MERCHANTH_SERVICE)
	private BaorcbMobileMerchantService baorcbMobileMerchantService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_MAPPER)
	private BillnoSnMapper billnoSnMapper;
	
	@Autowired
	private PinganXMMobilePayMQSenderService payMQSenderService;
	
	@Autowired
	private MobilePayInfoMapper mobilePayInfoMapper;
	
	@Autowired
	private AdapterTxnRecordMapper adapterTxnRecordMapper;
	
	
	@Autowired
	@Qualifier("clearing.adapter.adaptMenchart")
	private AdaptMenchartService adaptMenchartService;
	
	/**包头农商行移动支付*/
	private final static String channelId = ChannelIdEnum.BAORCB_MOBILE_PAY.getCode();
	
	/**
	 * 多商户配置信息处理
	 * @param channelParms
	 * @param corpAccountId 
	 */
	public void merchantParms(Map<String, String> channelParms, String channelId, String bankMerchantId, boolean isD0Flag) {
		
		//直接 根据 银行商户号查
		MobileMenchartInfo mobileMenchartInfo = mobileMenchartInfoService.selectByBankMchId(channelId, bankMerchantId, null);

		//替换商户menchart 和 商户密钥
		//商户menchart
		if (!StringUtils.isBlank(mobileMenchartInfo.getShopId())
				&& !StringUtils.isBlank(mobileMenchartInfo.getPayKey())) {
			channelParms.put(Constants.mobileparam.SHOP_OPEN_ID,mobileMenchartInfo.getBankMchId());
			channelParms.put(Constants.mobileparam.SHOP_OPEN_KEY, mobileMenchartInfo.getPayKey());
		}
		Log4jUtil.info("<<<<<<交易门店openId:{}, openKey:{}", 
				channelParms.get(Constants.mobileparam.SHOP_OPEN_ID), channelParms.get(Constants.mobileparam.SHOP_OPEN_KEY));
	}
	
	/**
	 * 包头农商行支付宝支付-被动扫码
	 * @param bdsmDTO
	 * @param channelId
	 * @param bankSendSn
	 * @param channelParms
	 * @param updateBillnoSn
	 * @return
	 * @throws Exception
	 */
	public BDsmResultDTO bdsmAlipay(BDsmDTO bdsmDTO, String channelId, String bankSendSn, 
			Map<String, String> channelParms, BillnoSn updateBillnoSn) throws Exception {
		//请求参数
		String sendAliMsg = BaorcbDto2AlipayMsg.micropayXMLBDsmMsg(bdsmDTO, bankSendSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_MICROPAY);
		url += path;
		Log4jUtil.info(">>>>>>支付宝被扫报文请求路径+参数:{}", url, sendAliMsg);
		//发送被扫支付请求
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, sendAliMsg);
		//发送报文
		Log4jUtil.info(">>>>>>支付宝被扫报文响应内容:{}", httpRespDTO.getReturnMsg());
		//解析报文
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);

		return parseBdsmAliResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	
	/**
	 * 包头农商行微信支付-被动扫码
	 * @param bdsmDTO
	 * @param channelId
	 * @param bankSendSn
	 * @param channelParms
	 * @param bankMerchantId
	 * @param updateBillnoSn
	 * @return
	 * @throws BizException
	 */
	public BDsmResultDTO bdsmWechat(BDsmDTO bdsmDTO, String channelId, String bankSendSn, 
			Map<String, String> channelParms, BillnoSn updateBillnoSn) throws Exception {
		//请求参数
		String sendWeChatMsg = BaorcbDto2WeChatMsg.preCreateXMLBDsmMsg(bdsmDTO, bankSendSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_MICROPAY);
		url += path;
		Log4jUtil.info(">>>>>>支付宝被扫报文请求路径:{}", url);
		Log4jUtil.info(">>>>>>支付宝被扫报文请求参数:{}", sendWeChatMsg);
		//发送被扫支付请求
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, sendWeChatMsg);
		//发送报文
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		//解析并返回
		return parseBdsmWxResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	
	/**
	 * 支付宝主扫
	 * @param zdsmDTO
	 * @param bankSendSn
	 * @param updateBillnoSn
	 * @return
	 * @throws Exception
	 * @author lcy
	 */
	public ZDsmResultDTO zdsmAlipay(ZDsmDTO zdsmDTO, String channelId, String bankSendSn, BillnoSn updateBillnoSn, 
			Map<String, String> channelParms) throws Exception {
		
		//请求参数
		String xmlMsg = BaorcbDto2AlipayMsg.createZdsmAlipayMsg(zdsmDTO, bankSendSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_PRECREATE);
		url += path;
		Log4jUtil.info(">>>>>>支付宝主扫报文请求路径-参数:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		//解析并返回
		return parseZdsmAliResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	
	/**
	 * 微信主扫
	 * @param zdsmDTO
	 * @param bankSendSn
	 * @param updateBillnoSn
	 * @return
	 * @throws Exception
	 * @author lcy
	 */
	public ZDsmResultDTO zdsmWechat(ZDsmDTO zdsmDTO, String channelId, String bankSendSn, BillnoSn updateBillnoSn, 
			Map<String, String> channelParms) throws Exception {
		
		//请求参数
		String xmlMsg = BaorcbDto2WeChatMsg.createZdsmWxpayMsg(zdsmDTO, bankSendSn, channelParms);
		
		//发送报文
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_CREATE);
		url += path;
		Log4jUtil.info(">>>>>>微信主扫报文请求内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		//解析并返回
		return parseZdsmWxResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	
	/**
	 * 支付宝服务窗
	 * @param jsapiPayDTO
	 * @param channelId
	 * @param bankSendSn
	 * @param bankMerchantId
	 * @param channelParms
	 * @return
	 * @throws BizException
	 * @author lcy
	 */
	public JsapiPayResultDTO jsapiPayAlipay(JsapiPayDTO jsapiPayDTO, String channelId, 
			String bankSendSn, Map<String, String> channelParms, BillnoSn updateBillnoSn) throws Exception {
		//请求参数
		String xmlMsg = BaorcbDto2AlipayMsg.createJsapiPayMsg(jsapiPayDTO, bankSendSn, channelParms);
		//发送报文
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_CREATE);
		url += path;
		
		Log4jUtil.info(">>>>>>支付宝服务窗报文响应内容:{}", url, xmlMsg);
		
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		//解析并返回
		return parseJsapiAliResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	/**
	 * 微信公众号
	 * @param jsapiPayDTO
	 * @param channelId
	 * @param bankSendSn
	 * @param channelParms
	 * @param updateBillnoSn
	 * @return
	 * @throws Exception
	 */
	public JsapiPayResultDTO jsapiPayWechat(JsapiPayDTO jsapiPayDTO, String channelId, 
			String bankSendSn, Map<String, String> channelParms, BillnoSn updateBillnoSn) throws Exception {
		//请求参数
		String xmlMsg = BaorcbDto2WeChatMsg.createJsapiPayMsg(jsapiPayDTO, bankSendSn, channelParms);
		//发送报文
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_ORDERS);
		url += path;
		
		Log4jUtil.info(">>>>>>微信服务窗报文响应内容:{}", url, xmlMsg);
		
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		//解析并返回
		return parseJsapiWxResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	/**退款申请
	 * @param zdPayRefundDTO
	 * @param channelId
	 * @param oriBillNoSn
	 * @param updateBillnoSn
	 * @param channelParms
	 * @param bankSendSn
	 * @return
	 * @throws Exception
	 * 2018年2月2日 上午11:16:43
	 */
	public ClearingResultDTO zdPayRefundAli(ZDPayRefundDTO zdPayRefundDTO, String channelId, BillnoSn oriBillNoSn, BillnoSn updateBillnoSn, 
			Map<String, String> channelParms, String bankSendSn) throws Exception {
		//请求参数
		String xmlMsg = BaorcbDto2AlipayMsg.createZdPayRufundMsg(zdPayRefundDTO, bankSendSn, oriBillNoSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_REFUND);
		url += path;
		
		Log4jUtil.info(">>>>>>包头农商行移动支付退款报文响应内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		//解析并返回
		return parseZdPayRefundAliResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	/**
	 * @param zdPayRefundDTO
	 * @param channelId
	 * @param oriBillNoSn
	 * @param updateBillnoSn
	 * @param channelParms
	 * @param bankSendSn
	 * @return
	 * @throws Exception
	 * 2018年2月2日 上午11:17:24
	 */
	public ClearingResultDTO zdPayRefundWx(ZDPayRefundDTO zdPayRefundDTO, String channelId, BillnoSn oriBillNoSn, BillnoSn updateBillnoSn, 
			Map<String, String> channelParms, String bankSendSn) throws Exception {
		//请求参数
		String xmlMsg = BaorcbDto2WeChatMsg.createZdPayRufundMsg(zdPayRefundDTO, bankSendSn, oriBillNoSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_REFUNDS);
		url += path;
		
		Log4jUtil.info(">>>>>>包头农商行移动支付退款报文响应内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		//解析并返回
		return parseZdPayRefundWxResp(httpRespDTO.getReturnMsg(), updateBillnoSn, channelParms);
	}
	
	/**
	 * 退款查询
	 * @param billnoSn
	 * @return
	 * @throws BizException
	 * @author lcy
	 */
	public ZDPTradeResultDTO queryRefundRecord(BillnoSn billnoSn, Map<String, String> channelParms) throws Exception {
		if (Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(billnoSn.getBankType()))
			return queryAliRefundRecord(billnoSn, channelParms);
		else
			return queryWxRefundRecord(billnoSn, channelParms);
	}
	/**
	 * 支付宝退款查询 - 返回参数 - 解析
	 * @param billnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception
	 * 2018年2月4日 下午1:41:24
	 */
	private ZDPTradeResultDTO queryAliRefundRecord(BillnoSn billnoSn, Map<String, String> channelParms) throws Exception {
		//请求参数
		String xmlMsg = BaorcbDto2AlipayMsg.createRefundRecordMsg(billnoSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_REFUND_QUERY);
		url += path;
		
		Log4jUtil.info(">>>>>>包头农商行移动支付退款查询报文响应内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		return parseAliRefundResp(httpRespDTO.getReturnMsg(), channelParms);
	}
	/**
	 * 微信 退款查询
	 * @param billnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception 
	 */
	private ZDPTradeResultDTO queryWxRefundRecord(BillnoSn billnoSn, Map<String, String> channelParms) throws Exception {
		//请求参数  微信 请求参数 与 支付宝请求参数 一样
		String xmlMsg = BaorcbDto2AlipayMsg.createRefundRecordMsg(billnoSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_REFUNDS_QUERY);
		url += path;
		
		Log4jUtil.info(">>>>>>包头农商行移动支付退款查询报文响应内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		return parseWxRefundResp(httpRespDTO.getReturnMsg(), channelParms);
	}
	
	private ZDPTradeResultDTO parseWxRefundResp(String resultMsg, Map<String, String> channelParms){
		ZDPTradeResultDTO zdpTradeResultDTO = new ZDPTradeResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-微信-服务窗,响应报文验签成功");
					zdpTradeResultDTO = Msg2Dto.parseWxRefundQueryMsg(resultMsg, zdpTradeResultDTO);
				} else {
					Log4jUtil.error("包头农商行-微信-服务窗,响应报文验签失败");
					zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdpTradeResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				zdpTradeResultDTO.setChannelResponseMsg("解析报文异常");
				return zdpTradeResultDTO;
			}
		} else {
			zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			zdpTradeResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return zdpTradeResultDTO;
		}
		return zdpTradeResultDTO;
	}
	
	private ZDPTradeResultDTO parseAliRefundResp(String resultMsg, Map<String, String> channelParms){
		ZDPTradeResultDTO zdpTradeResultDTO = new ZDPTradeResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签成功");
					zdpTradeResultDTO = Msg2Dto.parseAliRefundQueryMsg(resultMsg, zdpTradeResultDTO);
				} else {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签失败");
					zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdpTradeResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				zdpTradeResultDTO.setChannelResponseMsg("解析报文异常");
				return zdpTradeResultDTO;
			}
		} else {
			zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			zdpTradeResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return zdpTradeResultDTO;
		}
		return zdpTradeResultDTO;
	}
	
	/**
	 * 交易查询
	 * @param billnoSn
	 * @return
	 * @throws BizException
	 * @author lcy
	 */
	public ZDPTradeResultDTO querySingleRecord(BillnoSn billnoSn, Map<String, String> channelParms) throws Exception {
		if (Constants.mobileparam.TRADE_PAY_BANKTYPE_0000002.equals(billnoSn.getBankType()))
			return queryAliSingleRecord(billnoSn, channelParms);
		else
			return queryWxSingleRecord(billnoSn, channelParms);
	}
	
	/**
	 * 支付宝订单查询 - 返回参数 - 解析
	 * @param billnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception
	 * 2018年2月4日 下午1:41:24
	 */
	private ZDPTradeResultDTO queryAliSingleRecord(BillnoSn billnoSn, Map<String, String> channelParms) throws Exception {
		//请求参数 与支付宝的请求报文一样。
		String xmlMsg = BaorcbDto2AlipayMsg.createSingleRecordMsg(billnoSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.aliPay.ALIPAY_ORDER_QUERY);
		url += path;
		
		Log4jUtil.info(">>>>>>包头农商行移动支付 订单 查询报文响应内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		return parseyAliSingleResp(httpRespDTO.getReturnMsg(), channelParms, billnoSn);
	}
	/**
	 * 微信 订单查询
	 * @param billnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception 
	 */
	private ZDPTradeResultDTO queryWxSingleRecord(BillnoSn billnoSn, Map<String, String> channelParms) throws Exception {
		//请求参数  微信 请求参数 与 支付宝请求参数 一样
		String xmlMsg = BaorcbDto2AlipayMsg.createSingleRecordMsg(billnoSn, channelParms);
		
		String url = channelParms.get(Constants.mobileparam.req_url);
		String path = channelParms.get(Constants.wechatParam.WECHAT_ORDER_QUERY);
		url += path;
		
		Log4jUtil.info(">>>>>>包头农商行移动支付 订单 查询报文响应内容:{}", url, xmlMsg);
		//发送报文
		HttpResponseDTO httpRespDTO = BaorcbHttpPost.sendMsg(url, xmlMsg);
		baorcbMobileMerchantService.checkResponseDTO(httpRespDTO);
		
		return parseWxSingleResp(httpRespDTO.getReturnMsg(), channelParms);
	}
	
	private ZDPTradeResultDTO parseWxSingleResp(String resultMsg, Map<String, String> channelParms){
		ZDPTradeResultDTO zdpTradeResultDTO = new ZDPTradeResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-微信-服务窗,响应报文验签成功");
					zdpTradeResultDTO = Msg2Dto.parseWxSingleQueryMsg(resultMsg, zdpTradeResultDTO);
				} else {
					Log4jUtil.error("包头农商行-微信-服务窗,响应报文验签失败");
					zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdpTradeResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				zdpTradeResultDTO.setChannelResponseMsg("解析报文异常");
				return zdpTradeResultDTO;
			}
		} else {
			zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			zdpTradeResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return zdpTradeResultDTO;
		}
		return zdpTradeResultDTO;
	}
	
	private ZDPTradeResultDTO parseyAliSingleResp(String resultMsg, Map<String, String> channelParms, BillnoSn billnoSn){
		ZDPTradeResultDTO zdpTradeResultDTO = new ZDPTradeResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签成功");
					zdpTradeResultDTO = Msg2Dto.parseAliSingleQueryMsg(resultMsg, zdpTradeResultDTO, billnoSn);
				} else {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签失败");
					zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdpTradeResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				zdpTradeResultDTO.setChannelResponseMsg("解析报文异常");
				return zdpTradeResultDTO;
			}
		} else {
			zdpTradeResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdpTradeResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			zdpTradeResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return zdpTradeResultDTO;
		}
		return zdpTradeResultDTO;
	}
	
	/**
	 * 
	 * @param resultMsg
	 * @param updateBillnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception
	 * 2018年2月2日 下午4:53:19
	 */
	private ClearingResultDTO parseZdPayRefundWxResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms )throws Exception{
		ClearingResultDTO resultDto = new ClearingResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签成功");
					resultDto = Msg2Dto.parseZdPayRefundWxMsg(resultMsg, resultDto, updateBillnoSn);
				} else {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签失败");
					resultDto.setTxnStatus(TxnStatus.UNKNOW);
					resultDto.setChannelResponseCode(TransReturnCode.code_9109);
					resultDto.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				resultDto.setTxnStatus(TxnStatus.UNKNOW);
				resultDto.setChannelResponseCode(TransReturnCode.code_9109);
				resultDto.setChannelResponseMsg("解析报文异常");
				return resultDto;
			}
		} else {
			resultDto.setTxnStatus(TxnStatus.UNKNOW);
			resultDto.setChannelResponseCode(TransReturnCode.code_9109);
			resultDto.setChannelResponseMsg("获取银行响应内容失败");
			return resultDto;
		}
		return resultDto;
	}
	
	/**
	 * @param resultMsg
	 * @param updateBillnoSn
	 * @param channelParms
	 * @returns
	 * @throws Exception
	 * 2018年2月2日 上午11:17:39
	 */
	private ClearingResultDTO parseZdPayRefundAliResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms )throws Exception{
		ClearingResultDTO resultDto = new ClearingResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签成功");
					resultDto = Msg2Dto.parseZdPayRefundAliMsg(resultMsg, resultDto, updateBillnoSn);
				} else {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签失败");
					resultDto.setTxnStatus(TxnStatus.UNKNOW);
					resultDto.setChannelResponseCode(TransReturnCode.code_9109);
					resultDto.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				resultDto.setTxnStatus(TxnStatus.UNKNOW);
				resultDto.setChannelResponseCode(TransReturnCode.code_9109);
				resultDto.setChannelResponseMsg("解析报文异常");
				return resultDto;
			}
		} else {
			resultDto.setTxnStatus(TxnStatus.UNKNOW);
			resultDto.setChannelResponseCode(TransReturnCode.code_9109);
			resultDto.setChannelResponseMsg("获取银行响应内容失败");
			return resultDto;
		}
		return resultDto;
	}
	
	/**
	 * 公众号
	 * @param resultMsg
	 * @param updateBillnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception
	 */
	private JsapiPayResultDTO parseJsapiWxResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms )throws Exception{
		JsapiPayResultDTO jsapiPayResultDTO = new JsapiPayResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-微信-公众号,响应报文验签成功");
					jsapiPayResultDTO = Msg2Dto.parseJsapiWxMsg(resultMsg, jsapiPayResultDTO, updateBillnoSn);
				} else {
					Log4jUtil.error("包头农商行-微信-公众号,响应报文验签失败");
					jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					jsapiPayResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				jsapiPayResultDTO.setChannelResponseMsg("解析报文异常");
				return jsapiPayResultDTO;
			}
		} else {
			jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			jsapiPayResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return jsapiPayResultDTO;
		}
		return jsapiPayResultDTO;
	}
	
	/**
	 * 服务窗
	 * @param resultMsg
	 * @param updateBillnoSn
	 * @param channelParms
	 * @return
	 * @throws Exception
	 */
	private JsapiPayResultDTO parseJsapiAliResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms )throws Exception{
		JsapiPayResultDTO jsapiPayResultDTO = new JsapiPayResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签成功");
					jsapiPayResultDTO = Msg2Dto.parseJsapiAliMsg(resultMsg, jsapiPayResultDTO, updateBillnoSn);
				} else {
					Log4jUtil.error("包头农商行-支付宝-服务窗,响应报文验签失败");
					jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					jsapiPayResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				jsapiPayResultDTO.setChannelResponseMsg("解析报文异常");
				return jsapiPayResultDTO;
			}
		} else {
			jsapiPayResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			jsapiPayResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			jsapiPayResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return jsapiPayResultDTO;
		}
		return jsapiPayResultDTO;
	}
	
	/**
	 * 解析主扫结果
	 * @param resultMsg
	 * @param updateBillnoSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 */
	private ZDsmResultDTO parseZdsmWxResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms )throws BizException{
		ZDsmResultDTO zdsmResultDTO = new ZDsmResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.error("包头农商行-微信-主动支付,响应报文验签成功");
					zdsmResultDTO = Msg2Dto.parseWxMsgZdsm(resultMsg, zdsmResultDTO, updateBillnoSn);
				} else {
					Log4jUtil.error("包头农商行-微信-主动支付,响应报文验签失败");
					zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdsmResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				zdsmResultDTO.setChannelResponseMsg("解析报文异常");
				return zdsmResultDTO;
			}
		} else {
			zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			zdsmResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return zdsmResultDTO;
		}
		return zdsmResultDTO;
	}
	/**
	 * 解析主扫结果
	 * @return
	 * @throws BizException
	 * @author lcy
	 */
	private ZDsmResultDTO parseZdsmAliResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms )throws BizException{
		ZDsmResultDTO zdsmResultDTO = new ZDsmResultDTO();
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {
					Log4jUtil.info("包头农商行-支付宝-被动支付，验签成功");
					zdsmResultDTO = Msg2Dto.parseAliMsgZdsm(resultMsg, zdsmResultDTO, updateBillnoSn);
				} else {
					Log4jUtil.error("包头农商行-支付宝-被动支付,响应报文验签失败");
					zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					zdsmResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				zdsmResultDTO.setChannelResponseMsg("解析报文异常");
				return zdsmResultDTO;
			}
		} else {
			zdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			zdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			zdsmResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return zdsmResultDTO;
		}
		
		return zdsmResultDTO;
	}	
	
	/**
	 * 解析支付宝被动扫码交易 返回报文
	 * @param resultMap
	 * @param billnoSn
	 * @return bdsmResultDTO
	 * @throws BizException
	 * @author lcy
	 */
	private BDsmResultDTO parseBdsmAliResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms) throws BizException{
		BDsmResultDTO bdsmResultDTO = new BDsmResultDTO();
		
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {    // 验签成功
					Log4jUtil.info("包头农商行-支付宝-被动支付，验签成功");
				} else {
					Log4jUtil.error("包头农商行-支付宝-被动支付,响应报文验签失败");
					bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
					bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					bdsmResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
					return bdsmResultDTO;
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				bdsmResultDTO.setChannelResponseMsg("解析报文异常");
				return bdsmResultDTO;
			}
		} else {
			bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			bdsmResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return bdsmResultDTO;
		}
		return Msg2Dto.parseAliMsgBdsm(resultMsg, bdsmResultDTO, updateBillnoSn);
	}
	
	/**
	 * 解析微信被动扫码交易 返回报文
	 * @param resultMap
	 * @param billnoSn
	 * @return bdsmResultDTO
	 * @throws BizException
	 * @author lcy
	 */
	private BDsmResultDTO parseBdsmWxResp(String resultMsg, BillnoSn updateBillnoSn, Map<String, String> channelParms) throws BizException{
		BDsmResultDTO bdsmResultDTO = new BDsmResultDTO();
		
		if (!resultMsg.isEmpty()) {
			try {
				if (BaorcbVerificationSignMD5.micropayVerificationAllSignMD5(resultMsg, channelParms)) {    // 验签成功
					Log4jUtil.info("包头农商行-支付宝-被动支付，验签成功");
				} else {
					Log4jUtil.error("包头农商行-支付宝-被动支付,响应报文验签失败");
					bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW); 
					bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
					bdsmResultDTO.setChannelResponseMsg("响应报文验签结果不通过");
					return bdsmResultDTO;
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
				bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
				bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				bdsmResultDTO.setChannelResponseMsg("解析报文异常");
				return bdsmResultDTO;
			}
		} else {
			bdsmResultDTO.setTxnStatus(TxnStatus.UNKNOW);
			bdsmResultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			bdsmResultDTO.setChannelResponseMsg("获取银行响应内容失败");
			return bdsmResultDTO;
		}
		Log4jUtil.info("包头农商行-支付宝-被动支付响应报文:", bdsmResultDTO);
		return Msg2Dto.parseMsgWechatBdsm(resultMsg, bdsmResultDTO, updateBillnoSn);
	}
	
	/**
	 * 订单终态查询，状态为成功或失败,则关闭此订单
	 * 
	 * @param billNoSn
	 * @param channelParms
	 * @throws Exception
	 */
	public void closeOrderService(BillnoSn billNoSn,ZDPTradeResultDTO zdpTradeResultDTO) throws Exception{
		//根据查询结果，更新订单状态信息
		int payState = zdpTradeResultDTO.getTxnStatus();
		String retCode = zdpTradeResultDTO.getChannelResponseCode();
		String retMsg = zdpTradeResultDTO.getChannelResponseMsg();
		
		if(TxnStatus.UNKNOW == payState){
			payState = TxnStatus.FAILED;
			retCode =TransReturnCode.code_9900;
			retMsg = "系统关闭订单";
		}

		//主动调用接口关闭订单
		updateCloseOrderInfo(billNoSn,payState,retCode,retMsg);

		sendMQToZDPingtaiPay(billNoSn, retCode, payState);
	}
	
	/**
	 * 关闭订单持久化处理
	 * 
	 * @param billNoSn
	 * @param payState
	 * @param retCode
	 * @param retMsg
	 */
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRES_NEW, timeout = 3)
	private void updateCloseOrderInfo(BillnoSn billNoSn,int payState,String retCode,String retMsg){
		Log4jUtil.info("定时任务关闭订单信息SN:{},payState:{},retCode:{},retMsg:{}", billNoSn.getSn(),payState,retCode,retMsg);
		
		adapterTxnRecordMapper.updateCallBackByTxnId(billNoSn.getSn(), null, retCode, retMsg);
		billNoSn.setPayState(String.valueOf(payState));
		billNoSn.setState(BillnoSnState.billnoRecv);
		billNoSn.setRecvTime(new Date());
		billNoSn.setChannelRtncode(retCode);	//此编码不能为空，否者核心对账全部为空
		billNoSn.setChannelRtnnote(retMsg);
		billnoSnMapper.updateOnlyUnKnowState(billNoSn);
		
		//订单关闭，减少已使用额度
		if(TxnStatus.FAILED == payState){
			adaptMenchartService.desUsedLimitsOfMenchartCfg(TxnStatus.FAILED, billNoSn.getPoolMerchantId(), billNoSn.getAmount().toString());;
		}

		MobilePayInfo mobilePayInfo = mobilePayInfoMapper.selectByPrimaryKey(billNoSn.getChannelid(), billNoSn.getSn());
		if(mobilePayInfo != null){
			mobilePayInfo.setIsClosed("1");
			mobilePayInfoMapper.update(mobilePayInfo);
		}
	}
	
	/**
	 * MQ发送到主动支付平台
	 * @param map
	 * @param billnoSn
	 * @param channelResponseCode
	 * @param status
	 */
	public void sendMQToZDPingtaiPay(BillnoSn billnoSn,String channelResponseCode,int status){
		ZdsmBackToZDPTDto resultDto = new ZdsmBackToZDPTDto();
		if(billnoSn.getAmount() != null){
			resultDto.setAmount(billnoSn.getAmount().toString());
		}
		resultDto.setActual_amount(resultDto.getAmount());
		resultDto.setBankCardType(billnoSn.getBankCardType());
		resultDto.setChannelId(channelId);
		resultDto.setChannelResponseCode(channelResponseCode);
		resultDto.setOrgTxnId(billnoSn.getSn());
		resultDto.setSettlementAccountNo(billnoSn.getCorpacctno());
		resultDto.setTxnStatus(String.valueOf(status));
		String sendmsg = JSONObject.toJSONString(resultDto);
		Log4jUtil.info("包头农商行关闭订单后返回给主动支付平台的报文：【{}】",sendmsg);
		payMQSenderService.sendMQ(sendmsg);
	}
}
