package com.lycheepay.clearing.adapter.banks.bocom.corp;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BocomCorpPublicHead;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.ReconFile310301Bean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.kft.processor.CorpBocomService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交行银企-对账文件服务类（310301也叫：历史交易明细查询）</P>
 * 
 * @author 吴高雷(13632920449)
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CORP_RECONCILIATION_FILE_SERVICE)
public class BocomCorpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_CORP_SERVICE)
	private CorpBocomService corpBocomService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	private static final String channelId = ChannelIdEnum.BOCOM_CORP.getCode();
	private static final String STR_PAY = "pay";

	/*
	 * (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner#
	 * getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 吴高雷(13632920449)
	 */
	@Override
	public String getReconciliationFile(String fileSavePath, String channelId, String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BocomCorp", "getReconciliationFile");

		final String logPrefix = "交行银企";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);

		Log4jUtil.info("-----------构建交易数据对象列表-------");
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(settleDate);

		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				settleDate, reconciliationFileDTOList);

		Log4jUtil.info("生成对账文件路径{}", fileFullPath);
		return fileFullPath;
	}

	/**
	 * <p>构建对账交易数据对象List</p>
	 * 
	 * @param settleDate
	 * @return
	 * @throws ClearingAdapterBizCheckedException
	 * @author 吴高雷(13632920449)
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(String settleDate)
			throws ClearingAdapterBizCheckedException {
		// 渠道公共参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);

		// 发送报文
		String bocomCorpReqSeqNo = sequenceManagerService.getCorpBOCOMSN(DateUtil.getCurrentDate());
		BocomCorpPublicHead sendPublicHead = corpBocomService.createSendHead("310301", bocomCorpReqSeqNo, channelParms);
		ReconFile310301Bean send310301 = corpBocomService.package310301XML(bankAccountBalanceService
				.getBankaccountBean(channelId).getAccountNo(), settleDate);

		// 创建310301报文、通过http方式发送，并接收、处理其应答
		String send310301XML = corpBocomService.create310301XML(sendPublicHead, send310301);
		ReconFile310301Bean recv310301 = corpBocomService.create310301RecvBody(corpBocomService.httpSendAndReceive(
				channelParms, send310301XML));// 初始化回执对象

		List<ReconFile310301Bean.SerialRecord> serialRecordList = recv310301.getSerialRecordList();
		ArrayList<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		for (Iterator<ReconFile310301Bean.SerialRecord> iterator = serialRecordList.iterator(); iterator.hasNext();) {
			ReconFile310301Bean.SerialRecord serialRecord = iterator.next();
			if ("0".equals(serialRecord.getStatus())) {// 状态:‘0’-正常 ‘1’- 已经被抹账。这里对账只对状态为0的
				ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
				reconciliationFileDTO.setChannelId(channelId);
				BillnoSn billnoSn = billnoSnService.getBillnoSnByBankRecvSnAndTranDate(channelId,
						serialRecord.getSerialNo(), serialRecord.getTransDate());// 根据根据渠道id、银行回执流水、交易日期查找对应的流水记录
				if (null == billnoSn) {
					Log4jUtil.info("根据渠道id:" + channelId + ",银行回执流水:" + serialRecord.getSerialNo() + ",交易日期："
							+ serialRecord.getTransDate() + "在billnoSn表中未找到对应的记录");
					continue;
				}
				if (ClearingTransType.REAL_TIME_DEDUCT.equals(billnoSn.getTranType())
						|| ClearingTransType.REAL_TIME_PAY.equals(billnoSn.getTranType())) {// 只对账单笔交易
					reconciliationFileDTO.setPayGet(STR_PAY);
					reconciliationFileDTO.setCheckDate(DateUtil.getCurrentDate());
					reconciliationFileDTO.setBankSendId(billnoSn.getBankSendSn());
					reconciliationFileDTO.setTransDate(settleDate);
					reconciliationFileDTO.setAmount(new BigDecimal(serialRecord.getAmt()));
					reconciliationFileDTO.setBankTransState("00");
					reconciliationFileDTOList.add(reconciliationFileDTO);
				}
			}
		}
		return reconciliationFileDTOList;
	}

	/*
	 * (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner#
	 * convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * @author 吴高雷(13632920449)
	 */
	@Override
	public String convertToStandardReconciliationFile(String targetFilePath, String fileSavePath, String channelId,
			String settleDate) throws ClearingAdapterBizCheckedException {
		// TODO Auto-generated method stub
		return null;
	}
}
