package com.lycheepay.clearing.adapter.banks.bocom.creditQP.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.springframework.stereotype.Service;

import SecurityHelper.SecurityMessageCrypto;

import com.lycheepay.clearing.adapter.banks.bocom.creditQP.constant.Constant;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.util.Log4jUtil;

@Service
public class BocomCreditQPSocketService {
	
	static final String channelId = ChannelIdEnum.BOCOM_CREDIT_CARD.getCode();
	
	public String sendDate(String transDataXml, String strURL, Map<String, String> channelParms) throws BizException{
		
		Log4jUtil.info("HttpPost请求参数transDataXml【{}】, strURL：【{}】", transDataXml, strURL);
		
		HttpClient httpClient = null;
		HttpPost httpPost = null;
		InputStream in = null;
		BufferedReader bufferedReader = null;
		//加解密所需参数配置
		String pubkeypathB = channelParms.get(Constant.BNK_PUB_PATH);	//银行公钥
		String prikeyPathA = channelParms.get(Constant.KFT_PRI_PATH);	//快付通私钥
		String pwdA = channelParms.get(Constant.KFT_PRI_PWD);	//快付通私钥密码
		String merNo = channelParms.get(Constant.MER_NO);// 商户号
		
		try{
			// 加密交易请求明文
			String encryptTransDataXml = SecurityMessageCrypto.MakeSecurityMessage(transDataXml, pubkeypathB, prikeyPathA, pwdA, merNo);
			
			BasicNameValuePair ver = new BasicNameValuePair("version", Constant.VERSION);
			BasicNameValuePair xml = new BasicNameValuePair("transDataXml", encryptTransDataXml);
			
			ArrayList<BasicNameValuePair> pairs = new ArrayList<BasicNameValuePair>();
			pairs.add(ver);
			pairs.add(xml);
			
			URL uRL = new URL(strURL);
			httpClient = getHttpClient(false,uRL.getPort());
			
			HttpParams httpParams = httpClient.getParams();
			HttpConnectionParams.setConnectionTimeout(httpParams, 30 * 1000);  //设定请求超时时间 30秒
			HttpConnectionParams.setSoTimeout(httpParams, 60 * 1000);	//读取超时时间 60秒

			httpPost = new HttpPost(strURL);
			httpPost.setEntity(new UrlEncodedFormEntity(pairs, Charset.forName(Constant.CHARSET)));
		}catch(Exception e){
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
		}
		
		StringBuffer result = new StringBuffer();
		try{
			HttpResponse response = httpClient.execute(httpPost);
			int statusCode = response.getStatusLine().getStatusCode();
			HttpEntity entity = response.getEntity();
			in = entity.getContent();
			bufferedReader = new BufferedReader(new InputStreamReader(in,Constant.CHARSET));
			String line = "";
			while((line = bufferedReader.readLine()) != null){
				result.append(line);
			}
			
			String httpResponse = result.toString();	//银行返回的信息
			
			Log4jUtil.info("收到http响应信息:【{}】, statusCode:【{}】", httpResponse, statusCode);
			
			if (statusCode != HttpStatus.SC_OK) {
				Log4jUtil.error("PostMethod failed, statusCode" + statusCode);
				throw new BizException(TransReturnCode.code_9109,"unable to get response,statusCode incorrect");
			}
			
			
			Dom4jXMLMessage dom4jxml = null;
			try {
				dom4jxml = Dom4jXMLMessage.parse(httpResponse.getBytes(Charset.forName(Constant.CHARSET)));
			} catch (BizException e) {
				Log4jUtil.error(e);
				throw new BizException(TransReturnCode.code_9109,"解析银行回执异常,回执结构不合法");
			}// 解析应答报文
			
			final String resultBody = dom4jxml.getNodeText("string");// 返回报文结果
			
			String decryptRtnMsg = SecurityMessageCrypto.OpenSecurityMessage(resultBody, pubkeypathB, prikeyPathA, pwdA);//解密密文
			Log4jUtil.info("解密之后的信息:{}", decryptRtnMsg);
			return decryptRtnMsg;
			
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		}finally{
			IOUtils.closeQuietly(bufferedReader);
			IOUtils.closeQuietly(in);
			if(httpPost != null)httpPost.releaseConnection();
			if(httpClient != null)httpClient.getConnectionManager().shutdown();
		}
		
	}
	
	private HttpClient getHttpClient(boolean pool, int httpsPort) {
		SSLSocketFactory sf = null;
		try {
			TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] certificate,
						String authType) {
					return true;
				}
			};
			sf = new SSLSocketFactory(acceptingTrustStrategy,SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage());
		}
		
		if(httpsPort == -1){
			httpsPort = 443;
		}
	
		Scheme sch = new Scheme("https", httpsPort, sf);
		ClientConnectionManager ccm = null;
		if (pool) {
			SchemeRegistry registry = new SchemeRegistry();
			registry.register(sch);
			ccm = new PoolingClientConnectionManager(registry);
			return new DefaultHttpClient(ccm);
		} else {
			DefaultHttpClient client = new DefaultHttpClient();
			client.getConnectionManager().getSchemeRegistry().register(sch);
			return client;
		}
	}
}