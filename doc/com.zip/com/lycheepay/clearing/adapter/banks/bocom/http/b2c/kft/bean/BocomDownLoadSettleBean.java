package com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.bean;

/**
 * 交行对账单下载Bean
 * 
 * @author aps-txy
 * @date 2011-1-16
 */
public class BocomDownLoadSettleBean {
	private String retCode;// 得到交易返回码
	private String errorMessage;// 错误信息
	private String lastErr;// 简要的错误信息
	private String totalSum;// 总金额
	private String totalNumber;// 总笔数
	private String totalFee;// 总手续费
	private String settlementFile;// 对账文件

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(final String retCode) {
		this.retCode = retCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getLastErr() {
		return lastErr;
	}

	public void setLastErr(final String lastErr) {
		this.lastErr = lastErr;
	}

	public String getTotalSum() {
		return totalSum;
	}

	public void setTotalSum(final String totalSum) {
		this.totalSum = totalSum;
	}

	public String getTotalNumber() {
		return totalNumber;
	}

	public void setTotalNumber(final String totalNumber) {
		this.totalNumber = totalNumber;
	}

	public String getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(final String totalFee) {
		this.totalFee = totalFee;
	}

	public String getSettlementFile() {
		return settlementFile;
	}

	public void setSettlementFile(final String settlementFile) {
		this.settlementFile = settlementFile;
	}
}
