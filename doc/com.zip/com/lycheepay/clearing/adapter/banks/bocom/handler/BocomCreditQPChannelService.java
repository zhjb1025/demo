package com.lycheepay.clearing.adapter.banks.bocom.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ChannelSignWithBankService;
import com.lycheepay.clearing.adapter.banks.bocom.creditQP.service.BocomCreditQPProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.SignNoService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.sign.ChannelSignApplyRequestDTO;
import com.lycheepay.clearing.common.dto.sign.ChannelSignConfirmRequstDTO;
import com.lycheepay.clearing.common.dto.sign.ChannelSignResponse;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.common.model.SignNo;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 交行信用卡快捷支付
 * @author huangxu
 *
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_QP_CHANNEL_SERVICE)
public class BocomCreditQPChannelService extends AbstractChannelService implements ChannelSignWithBankService {
	@Autowired
	private BocomCreditQPProcessService bocomCreditQPProcessService;
	
	@Autowired
	private SignNoService signNoService;

	public final static String channelId = ChannelIdEnum.BOCOM_CREDIT_QUICK_PAY_CORP.getCode();
	
	@Override
	public ChannelSignResponse cardSign(ChannelSignApplyRequestDTO channelSignApplyRequestDTO) {
		Log4jUtil.setLogClass("bocomCreditQP", "cardSign");
		Log4jUtil.info("交行信用卡快捷签约-调用生成短信验证码接口:{}", channelSignApplyRequestDTO);
		ChannelSignResponse channelSignResponse = new ChannelSignResponse();
		try {
			SignNo signNo = signNoService.select(channelSignApplyRequestDTO.getCustBankAccountNo(), channelId, "1");
			
			if (signNo != null) {
				channelSignResponse.setStatus(PayState.TxnStatus.SUCCEED);
				channelSignResponse.setResponseMsg("已经签约成功，不需要再次签约");
			} else {
				channelSignResponse = bocomCreditQPProcessService.cardSign(channelSignApplyRequestDTO);
			}
		} catch (BizException e) {
			channelSignResponse.setStatus(PayState.TxnStatus.FAILED);
			channelSignResponse.setResponseMsg(e.getMessage());
		}
		Log4jUtil.info("交行信用卡快捷签约交易返回记录:{}", channelSignResponse);
		return channelSignResponse;
	}

	@Override
	public ClearingResultDTO directDeduct(DeductDTO deduct) {
		Log4jUtil.setLogClass("bocomCreditQP", "direct");
		Log4jUtil.info(deduct);
		ClearingResultDTO dto = new ClearingResultDTO();
		try {
			SignNo signNo = signNoService.select(deduct.getBankCardNo(), channelId, "1");
			if (signNo ==  null) {
				dto.setTxnStatus(PayState.TxnStatus.FAILED);
				dto.setChannelResponseCode(TransReturnCode.code_9900);
				dto.setChannelResponseMsg("该银行卡未进行签约,不能进行交易");
				return dto;
			}
			
			dto = bocomCreditQPProcessService.directDeduct(deduct, signNo);
			dto.setChannelId(channelId);
			dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}
	
	@Override
	public ClearingResultDTO autoRealtimeRefund(RefundDTO refund) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("bocomCreditQP", "refund");
		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		try {
			dto = bocomCreditQPProcessService.autoRealtimeRefund(refund);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 签约确认接口
	 */
	@Override
	public ChannelSignResponse cardSignConfrim(ChannelSignApplyRequestDTO channelSignApplyRequestDTO, ChannelSignConfirmRequstDTO channelSignConfirmRequstDTO) {
		Log4jUtil.setLogClass("bocomCreditQP", "cardSignConfrim");
		Log4jUtil.info("交行信用卡快捷签约-调用签约接口:{}, {}", channelSignApplyRequestDTO, channelSignConfirmRequstDTO);
		ChannelSignResponse channelSignResponse = new ChannelSignResponse();
		try {
			SignNo signNo = signNoService.select(channelSignApplyRequestDTO.getCustBankAccountNo(), channelId, "1");
			
			if (signNo != null) {
				channelSignResponse.setStatus(PayState.TxnStatus.SUCCEED);
				channelSignResponse.setCode(TransReturnCode.code_0000);
				channelSignResponse.setResponseMsg("已经签约成功，不需要再次签约");
			} else {
				signNo = signNoService.select(channelSignApplyRequestDTO.getCustBankAccountNo(), channelId, "2");
				if (signNo == null) {
					channelSignResponse.setResponseMsg("未找到该银行卡待签约的信息");
					channelSignResponse.setCode(TransReturnCode.code_9900);
					channelSignResponse.setStatus(PayState.TxnStatus.FAILED);
					return channelSignResponse;
				}
				channelSignResponse = bocomCreditQPProcessService.cardSignConfrim(channelSignApplyRequestDTO, channelSignConfirmRequstDTO, signNo);
			}
		} catch (BizException e) {
			channelSignResponse.setStatus(PayState.TxnStatus.FAILED);
			channelSignResponse.setResponseMsg(e.getMessage());
		}
		Log4jUtil.info("交行信用卡快捷签约-调用签约接口,返回结果:{}", channelSignResponse);
		return channelSignResponse;
	}
}
