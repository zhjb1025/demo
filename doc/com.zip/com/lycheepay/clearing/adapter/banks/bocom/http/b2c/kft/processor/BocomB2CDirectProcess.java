package com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bocom.netpay.b2cAPI.BOCOMB2CClient;
import com.bocom.netpay.b2cAPI.BOCOMB2COPReply;
import com.bocom.netpay.b2cAPI.OpResult;
import com.bocom.netpay.b2cAPI.OpResultSet;
import com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.bean.BocomBatchOrderQueryResult;
import com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.bean.BocomDownLoadSettleBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReceiveParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交通银行网银B2C HTTP(后台直接交互:如报文验证等直接与银行交互)请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午10:56:53
 */
@Service(ClearingAdapterAnnotationName.BOCOM_B2C_DIRECT_PROCESS)
public class BocomB2CDirectProcess extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_B2C_SERVICE)
	private BocomB2CService bocomB2CService;

	private BOCOMB2CClient client = null;
	private static String channelId = ChannelIdEnum.BOCOM_B2C.getCode();

	// private static BatchRefundDistributeService batchRefundDistributeService =
	// (BatchRefundDistributeService) SpringContext
	// .getService("batchRefundDistributeService");

	// private static String configFilePath = "";
	// private String merchantOper = "";

	public ReturnState accountVerify(final Param param) throws BizException {
		String logPrefix = "";
		logPrefix = " " + param.getChannelId() + ChannelId.getNameByValue(param.getChannelId()) + " ";
		Log4jUtil.info(logPrefix + "Http渠道连接器[业务类型:" + param.getClearingTransType() + "],开始");
		return accountVerifyXml(param);
	}

	/**
	 * <p> 持卡人身份报文验证</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午11:11:41
	 */
	private ReturnState accountVerifyXml(final Param param) throws BizException {
		String logPrefix = param.getChannelId() + ChannelId.getNameByValue(param.getChannelId()) + " ";
		final BankCardVerifyDTO accountVerfy = (BankCardVerifyDTO) param.getBizBean();
		AssertUtils.notNull(accountVerfy, TransReturnCode.code_9108, logPrefix + "报文方式的账户验证数据不能为空!");
		final String card = accountVerfy.getBankCardNo(); // 银行卡号
		final String custName = accountVerfy.getCardHolderName();// 客户姓名 可选
		String certType = accountVerfy.getCertificateType();// 证件类型 可选
		final String certNo = accountVerfy.getCertificateNo();// 证件号码 可选
		AssertUtils.notNull(card, TransReturnCode.code_9108, logPrefix + "持卡人身份验证请求的银行卡号不能为空!");
		// 身份证验证
		if (StringUtils.isNotBlank(certNo)) {
			certType = "15"; // 15居民身份证 暂时只支持15验证
		}
		AssertUtils.notNull(card, TransReturnCode.code_9108, logPrefix + "持卡人身份验证请求的银行卡号不能为空!");
		AssertUtils.notNull(param.getChannelId(), TransReturnCode.code_9108, logPrefix + "渠道连接器中未得到channelId");
		final ChannelParm configFilePath = channelParmService
				.queryByPrimaryKey(new ChannelParmId(param.getChannelId(), "300001"));
		AssertUtils.notNull(configFilePath, TransReturnCode.code_9108, logPrefix + "渠道连接器中未得到configFilePath");
		final BOCOMB2CClient client = new BOCOMB2CClient();
		final ReceiveParam receiveParam = new ReceiveParam();
		final int ret = client.initialize(configFilePath.getParvalue());
		if (ret != 0) {
			// 初始化失败
			Log4jUtil.debug("初始化失败,错误信息：" + client.getLastErr());
			throw new BizException(logPrefix + "api Client初始化失败,请查看配置是否正确,或确定证书已经导入到JVM!");
		} else {
			final BOCOMB2COPReply rep = client.verifyCustID(card, custName, certType, certNo);
			if (rep == null) {
				receiveParam.setReturnState(PayState.FAILED_STR);// 通讯成功
				receiveParam.setReturnMsg("交易错误信息：帐号校验信息输入不全,户名和证件号不很全为空.");
				receiveParam.setBankPostScript("交易错误信息：帐号校验信息输入不全,户名和证件号不很全为空."); // 交易错误信息
				receiveParam.setChannelCode(TransReturnCode.code_9900);
			} else {
				receiveParam.setReturnState(PayState.SUCCEED_STR);// 通讯成功
				receiveParam.setReturnMsg(rep.getErrorMessage());
				receiveParam.setBankRetCode(rep.getRetCode());// 得到交易返回码
				receiveParam.setBankPostScript(rep.getErrorMessage()); // 交易错误信息
				final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(param
						.getChannelId(), receiveParam.getBankRetCode()));
				if (channelRtncode == null) {
					Log4jUtil.error(logPrefix + "报文方式的账户验证的返回码" + receiveParam.getBankRetCode()
							+ "在系统表CHANNEL_RTNCODE中没有对应值");
					receiveParam.setChannelCode(TransReturnCode.code_9900);
				} else {
					receiveParam.setChannelCode(channelRtncode.getKftRtncode());
				}
			}
		}
		return receiveParam;
	}

	private ReturnState sendBalance(final Param param) throws BizException {
		String logPrefix = param.getChannelId() + ChannelId.getNameByValue(param.getChannelId()) + " ";
		final Map<String, String> checkReqMap = (Map<String, String>) param.getBizBean();
		AssertUtils.notNull(checkReqMap, TransReturnCode.code_9108, logPrefix + "对账请求的数据不能为空!");
		final String settleDate = checkReqMap.get("settleDate");
		AssertUtils.notNull(settleDate, TransReturnCode.code_9108, logPrefix + "对账请求的settleDate不能为空!");
		AssertUtils.notNull(param.getChannelId(), TransReturnCode.code_9108, logPrefix + "渠道连接器中未得到channelId");
		final ChannelParm configFilePath = channelParmService
				.queryByPrimaryKey(new ChannelParmId(param.getChannelId(), "300001"));
		AssertUtils.notNull(configFilePath, TransReturnCode.code_9108, logPrefix + "渠道连接器中未得到configFilePath");
		final BOCOMB2CClient client = new BOCOMB2CClient();
		final ReceiveParam receiveParam = new ReceiveParam();
		final BocomDownLoadSettleBean retBean = new BocomDownLoadSettleBean();
		final int ret = client.initialize(configFilePath.getParvalue());
		if (ret != 0) { // 初始化失败
			Log4jUtil.debug("初始化失败,错误信息：" + client.getLastErr());
			throw new BizException(logPrefix + "api Client初始化失败,请查看配置是否正确,或确定证书已经导入到JVM!");
		} else {
			final BOCOMB2COPReply rep = client.downLoadSettlement(settleDate);// 对帐单下载
			if (rep == null) {
				AssertUtils.notNull(rep, TransReturnCode.code_9109, "交易错误信息：" + client.getLastErr());
			} else {
				retBean.setRetCode(rep.getRetCode());// 得到交易返回码
				retBean.setErrorMessage(rep.getErrorMessage());// 错误信息
				retBean.setLastErr(rep.getLastErr());// 错误信息2
				if ("0".equals(rep.getRetCode())) {// 表示交易成功
					final OpResult opr = rep.getOpResult();
					retBean.setTotalSum(opr.getValueByName("totalSum"));// 总金额
					retBean.setTotalNumber(opr.getValueByName("totalNumber"));// 总笔数
					retBean.setTotalFee(opr.getValueByName("totalFee"));// 总手续费
				}
			}
		}
		receiveParam.setReturnObj(retBean);
		return receiveParam;
	}

	private ReturnState SendQuryBatchTrans(final Param param) throws BizException {
		String logPrefix = param.getChannelId() + ChannelId.getNameByValue(param.getChannelId()) + " ";

		final Object o = param.getBizBean();// 订单号用 '|' 分割
		final String orders = (String) o;
		Log4jUtil.info("订单号为:" + orders);
		AssertUtils.notNull(param.getChannelId(), TransReturnCode.code_9108, logPrefix + "渠道连接器中未得到channelId");
		final ChannelParm configFilePath = channelParmService
				.queryByPrimaryKey(new ChannelParmId(param.getChannelId(), "300001"));
		AssertUtils.notNull(configFilePath, TransReturnCode.code_9108, logPrefix + "渠道连接器中未得到configFilePath");
		final ReceiveParam receiveParam = new ReceiveParam();
		final BOCOMB2CClient client = new BOCOMB2CClient();
		final int ret = client.initialize(configFilePath.getParvalue()); // 该代码只需调用一次
		final List<BocomBatchOrderQueryResult> retData = new ArrayList<BocomBatchOrderQueryResult>();
		if (ret != 0) {
			// 初始化失败
			Log4jUtil.debug("初始化失败,错误信息：" + client.getLastErr());
			throw new BizException(logPrefix + "api Client初始化失败,请查看配置是否正确,或确定证书已经导入到JVM!");
		} else {
			final BOCOMB2COPReply rep = client.queryOrder(orders); // 批量订单查询
			AssertUtils.notNull(rep, TransReturnCode.code_9109, "交易错误信息：" + client.getLastErr());
			receiveParam.setReturnMsg(rep.getErrorMessage());// 返回信息
			receiveParam.setBankRetCode(rep.getRetCode());
			receiveParam.setBankPostScript(rep.getErrorMessage());
			receiveParam.setReturnState(PayState.SUCCEED_STR);// 得到交易通讯码
			if ("0".equals(rep.getRetCode())) {// 表示交易成功
				receiveParam.setChannelCode(TransReturnCode.code_0000);
				final OpResultSet oprSet = rep.getOpResultSet();
				final int iNum = oprSet.getOpresultNum();
				for (int index = 0; index <= iNum - 1; index++) {
					final BocomBatchOrderQueryResult result = new BocomBatchOrderQueryResult();
					result.setOrder(oprSet.getResultValueByName(index, "order"));
					result.setOrderDate(oprSet.getResultValueByName(index, "orderDate"));
					result.setOrderTime(oprSet.getResultValueByName(index, "orderTime"));
					result.setCurType(oprSet.getResultValueByName(index, "curType"));
					result.setAmount(oprSet.getResultValueByName(index, "amount"));
					result.setTranDate(oprSet.getResultValueByName(index, "tranDate"));
					result.setTranTime(oprSet.getResultValueByName(index, "tranTime"));
					result.setTranState(oprSet.getResultValueByName(index, "tranState"));
					result.setOrderState(oprSet.getResultValueByName(index, "orderState"));
					result.setFee(oprSet.getResultValueByName(index, "fee"));
					result.setBankSerialNo(oprSet.getResultValueByName(index, "bankSerialNo"));
					result.setBankBatNo(oprSet.getResultValueByName(index, "bankBatNo"));
					result.setCardType(oprSet.getResultValueByName(index, "cardType"));
					result.setMerchantBatNo(oprSet.getResultValueByName(index, "merchantBatNo"));
					result.setMerchantComment(oprSet.getResultValueByName(index, "merchantComment"));
					result.setBankComment(oprSet.getResultValueByName(index, "bankComment"));
					retData.add(result);
				}
			} else {
				receiveParam.setChannelCode(TransReturnCode.code_9900);
			}
		}
		receiveParam.setReturnObj(retData);
		return receiveParam;
	}

	public Balance queryBanlance() {
		Balance balance = new Balance();
		BOCOMB2CClient client = getClient();
		if (client == null) {  // 初始化失败
			balance.setErrorMsg("初始化失败");
		} else {
			BOCOMB2COPReply rep = client.queryAccountBalance(); // 结算帐户查询
			if (rep == null) {
				balance.setErrorMsg("交易错误信息：" + client.getLastErr());
			} else {
				String code = rep.getRetCode(); // 得到交易返回码
				String msg = rep.getErrorMessage();
				Log4jUtil.info("交易返回码：{},交易错误信息：{}", code, msg);
				if ("0".equals(code)) {// 表示交易成功
					OpResult opr = rep.getOpResult();
					String accountNo = opr.getValueByName("settAccount");		// 得到账号
					String accountName = opr.getValueByName("accountName"); 	// 得到账号名称
					String currType = opr.getValueByName("currType");			// 得到币种
					String currBalance = opr.getValueByName("currBalance");	// 得到当前余额
					String validBalance = opr.getValueByName("validBalance");	// 得到可用余额
					Log4jUtil.info("账号:{},账号名称:{},币种:{},当前余额:{},可用余额:{}", accountNo, accountName, currType,
							currBalance, validBalance);
					balance.setAccNo(accountNo);
					balance.setAvailBanlace(validBalance);
					balance.setBalance(currBalance);
				}
			}
		}
		return balance;
	}

	public BOCOMB2CClient getClient() {
		if (client != null) {
			return client;
		} else {
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			String configFilePath = channelParms.get("300001");
			BOCOMB2CClient client = new BOCOMB2CClient();
			int ret = client.initialize(configFilePath);
			if (ret != 0) {  // 初始化失败
				Log4jUtil.error(client.getLastErr());
				client = null;
			}
			return client;
		}
	}

}
