package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import java.nio.charset.Charset;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util.LoUtils;
import com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util.MacUtil;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AmountUtils;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 消息包工具.
 * 
 * @author aps-mhc
 */
public abstract class MsgPackUtils {

	/**
	 * 创建tpdu域.
	 */
	public static void createTpduField(MsgPack msgPack, byte[] b) throws BizException {
		MsgFieldType fieldType = MsgFieldType.TPDU;
		MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(b);
		msgPack.put(field);
	}

	/**
	 * 创建head域.
	 */
	public static void createHeadField(MsgPack msgPack, byte[] b) throws BizException {
		MsgFieldType fieldType = MsgFieldType.HEAD;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(b);
		msgPack.put(field);
	}

	public static void resetMsgType(MsgPack msgPack, String newMsgType) {
		MsgField field = msgPack.getField(MsgFieldType.MSG_TYPE.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
	}

	public static void createMsgType(MsgPack msgPack, String newMsgType) {
		MsgFieldType fieldType = MsgFieldType.MSG_TYPE;
		MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
		msgPack.put(field);
	}

	public static void createAccountField(MsgPack msgPack, String accountNo) throws BizException {
		MsgFieldType fieldType = MsgFieldType.FIELD_2;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		int valueLen = accountNo.getBytes().length;
		byte[] bcdAccountNo = ByteUtils.strToBcdLeftSide(accountNo);
		byte[] bcdLen = ByteUtils.intToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bcdAccountNo));

		msgPack.putBitmapField(field);
	}


	/**
	 * 交易处理码.
	 * 
	 * @param msgPack
	 * @param tradeDealCode
	 */
	public static void createField3(MsgPack msgPack, String tradeDealCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_3;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(tradeDealCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 创建第4域交易金额
	 * 
	 * @param msgPack
	 * @param amount 交易金额, 单位:元
	 */
	public static void createField4(MsgPack msgPack, Double amount) {
		MsgFieldType fieldType = MsgFieldType.FIELD_4;

		long cent = (long) AmountUtils.format(amount * 100);
		String strAmount = Long.toString(cent);
		strAmount = StringUtils.leftPad(strAmount, fieldType.getMaxLength() * 2, '0'); // 补足编码前12位长度.
		MsgField field = MsgField.create(fieldType.getNo());
		// 设置bcd编码的交易金额.
		byte[] bcdAmount = ByteUtils.strToBcd(strAmount);
		field.setOrigMsg(bcdAmount);
		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡方系统跟踪号.
	 * 
	 * @param msgPack
	 * @param trackeCode
	 */
	public static void createField11(MsgPack msgPack, String trackeCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_11;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(trackeCode));
		msgPack.putBitmapField(field);
	}

	public static void createField12(MsgPack msgPack, String time) {
		MsgFieldType fieldType = MsgFieldType.FIELD_12;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(time));
		msgPack.putBitmapField(field);
	}

	public static void createField13(MsgPack msgPack, String date) {
		MsgFieldType fieldType = MsgFieldType.FIELD_13;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(date));
		msgPack.putBitmapField(field);
	}

	/**
	 * 卡有效期
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField14(MsgPack msgPack, String conditionCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_14;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(conditionCode));
		msgPack.putBitmapField(field);
	}

	// public static void createField15(MsgPack msgPack, String conditionCode) {
	// MsgField field = MsgField.create(MsgFieldType.FIELD_15.getNo());
	// byte[] bcd = ByteUtils.strToBcd(conditionCode);
	// field.setOrigMsg(bcd);
	//
	// msgPack.putBitmapField(field);
	// }

	/**
	 * 服务点输入方式码.
	 * 
	 * @param msgPack
	 * @param inputModeCode
	 */
	public static void createField22(MsgPack msgPack, String inputModeCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_22;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(inputModeCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 卡片序列号
	 * 
	 * @param msgPack
	 * @param inputModeCode
	 */
	public static void createField23(MsgPack msgPack, String inputModeCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_23;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(inputModeCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * NII
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	// public static void createField24(MsgPack msgPack, String inputModeCode) {
	// MsgFieldType fieldType = MsgFieldType.FIELD_24;
	// MsgField field = MsgField.create(fieldType.getNo());
	// field.setOrigMsg(ByteUtils.strToBcdRightSide(inputModeCode));
	// msgPack.putBitmapField(field);
	// }

	/**
	 * 服务点条件码.
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField25(MsgPack msgPack, String conditionCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_25;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(conditionCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 更新标志.
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField28(MsgPack msgPack, String conditionCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_28;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(conditionCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 二磁道内容
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField35(MsgPack msgPack, String rspCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_35;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 三磁道内容
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField36(MsgPack msgPack, String rspCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_36;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 系统参考号
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField37(MsgPack msgPack, String rspCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_37;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成38授权标识应答码, 请求时，同原预授权交易,加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField38(MsgPack msgPack, String rspCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_38;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成39应答码域, 加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField39(MsgPack msgPack, String rspCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_39;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡机终端标识码.
	 * 
	 * @param msgPack
	 * @param terminalCode
	 */
	public static void createField41(MsgPack msgPack, String terminalCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_41;
		MsgField field = MsgField.create(fieldType.getNo());
		terminalCode = ByteUtils.rightPadSpaceByByte(terminalCode, 8);
		field.setOrigMsg(terminalCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡方标识码.
	 * 
	 * @param msgPack
	 * @param merchantNo
	 */
	public static void createField42(MsgPack msgPack, String merchantNo) {
		MsgFieldType fieldType = MsgFieldType.FIELD_42;
		MsgField field = MsgField.create(fieldType.getNo());
		merchantNo = ByteUtils.rightPadSpaceByByte(merchantNo, 15);
		field.setOrigMsg(merchantNo.getBytes());
		msgPack.putBitmapField(field);
	}

	public static void createDefaultField44(MsgPack msgPack) {
		MsgField field = MsgField.create(MsgFieldType.FIELD_44.getNo());
		byte[] bcdLen = ByteUtils.strToBcd("01");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		msgPack.putBitmapField(field);
	}

	/**
	 * 附加响应
	 * 
	 * @param msgPack
	 * @param merchantNo
	 */
	public static void createField44(MsgPack msgPack, String merchantNo) {
		MsgFieldType fieldType = MsgFieldType.FIELD_44;
		MsgField field = MsgField.create(fieldType.getNo());
		merchantNo = ByteUtils.rightPadSpaceByByte(merchantNo, 15);
		field.setOrigMsg(merchantNo.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	// public static void createField48(MsgPack msgPack, byte[] currencyCode) {
	// MsgFieldType fieldType = MsgFieldType.FIELD_48;
	// MsgField field = MsgField.create(fieldType.getNo());
	// field.setOrigMsg(currencyCode);
	// msgPack.putBitmapField(field);
	// }

	/**
	 * 交易货币代码.
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField49(MsgPack msgPack, String currencyCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_49;
		MsgField field = MsgField.create(fieldType.getNo());
		currencyCode = ByteUtils.rightPadSpaceByByte(currencyCode, 3);
		field.setOrigMsg(currencyCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 个人密码密文
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField52(MsgPack msgPack, String currencyCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_52;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(currencyCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 如果PIN或者MAC存在则必须存在
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField53(MsgPack msgPack, String currencyCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_53;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(currencyCode.getBytes());
		msgPack.putBitmapField(field);
	}


	/**
	 * 操作员号密码 操作员号(2)+密码(4)
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField60(MsgPack msgPack, String opreatorPwd) {
		MsgFieldType fieldType = MsgFieldType.FIELD_60;
		MsgField field = MsgField.create(fieldType.getNo());

		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());
		String len = opreatorPwd.getBytes().length + "";
		while (len.length() < 4) {
			len = "0" + len;
		}
		byte[] lenOfPrefix = ByteUtils.strToBcd(len);
		byte[] value = opreatorPwd.getBytes();//
		field.setOrigMsg(ArrayUtils.addAll(lenOfPrefix, value));
		msgPack.putBitmapField(field);
	}

	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		int length = hexString.length() / 2;
		char[] hexChars = hexString.toCharArray();
		byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}

	private static byte charToByte(char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}

	/**
	 * 创建61域
	 * 
	 * @param msgPack
	 * @param idCode
	 */
	public static void createField61(MsgPack msgPack, String idCode) {
		MsgFieldType fieldType = MsgFieldType.FIELD_61;
		MsgField field = MsgField.create(fieldType.getNo());
		Log4jUtil.info("商户名称 :" + idCode);
		String idCodeLength = "" + idCode.getBytes(Charset.forName("GBK")).length;
		while (idCodeLength.length() < 4) {
			idCodeLength = "0" + idCodeLength;
		}
		byte[] field61B = ByteUtils.strToBcd(idCodeLength);
		field61B = ArrayUtils.addAll(field61B, idCode.getBytes(Charset.forName("GBK")));

		field.setOrigMsg(field61B);
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域62:6位批次号+6位票据号
	 * 
	 * @param msgPack TODO
	 * @param customValue
	 */
	public static void createField62(MsgPack msgPack, byte[] customValue) {

		MsgFieldType fieldType = MsgFieldType.FIELD_62;

		MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(customValue);

		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域:63
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField63(MsgPack msgPack, byte[] customValue) {
		MsgFieldType fieldType = MsgFieldType.FIELD_63;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue);
		msgPack.putBitmapField(field);
	}

	/**
	 * MAC.
	 * 
	 * @param msgPack
	 * @param macValue
	 */
	public static void createField64(MsgPack msgPack, String macValue) {
		MsgFieldType fieldType = MsgFieldType.FIELD_64;
		MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(macValue.getBytes());
		msgPack.putBitmapField(field);
	}

	public static void resetTpduFrom(MsgPack msgPack, String from) throws BizException {
		if (StringUtils.isEmpty(from)) {
			return;
		}

		Tpdu tpdu = msgPack.getTpdu();
		tpdu.setFrom(from);
		msgPack.setTpdu(tpdu);
	}

	public static void resetTpduTo(MsgPack msgPack, String to) throws BizException {
		if (StringUtils.isEmpty(to)) {
			return;
		}

		Tpdu tpdu = msgPack.getTpdu();
		tpdu.setTo(to);
		msgPack.setTpdu(tpdu);
	}

	/**
	 * 复制源包中的域到目标包, 源包无指定域则不复制.
	 */
	public static void copyField(MsgPack destPack, MsgPack srcPack, MsgFieldType fieldType) {
		MsgField srcField = srcPack.getField(fieldType.getNo());

		if (srcField == null) {
			return;
		}

		MsgField newField = srcField.clone();
		int bitmapIndex = fieldType.getBitmapIndex();

		if (bitmapIndex >= 0) {
			destPack.putBitmapField(newField);
		} else {
			destPack.put(newField);
		}
	}

	/**
	 * 计算mac.
	 * 
	 * @param msgPack
	 * @param posIdPrefix 终端标识前置,用于加密机中识别终端密钥数据
	 * @throws BizException
	 */
	public static void createMac(MsgPack msgPack, String workKey) throws BizException {
		MsgFieldType fieldType = MsgFieldType.FIELD_64;
		MsgField macField = msgPack.getField(fieldType.getNo());

		// 创建mac域.
		if (macField == null) {
			macField = MsgField.create(fieldType.getNo());
			msgPack.putBitmapField(macField);
		}

		// 取删除mac域后的报文数据.
		byte[] msg = msgPack.pack();
		Log4jUtil.info("msg.length :{}", msg.length);
		byte[] macData = ArrayUtils.subarray(msg, 8, msg.length); // 从第18个字节开始
		Log4jUtil.info("macData :{}", macData.length);
		Log4jUtil.info("参与mac加密的数据为：{};workKey数据为：{}", LoUtils.byte2HexStr(macData), workKey);

		String macStr = MacUtil.getMacData2(workKey, macData);
		byte[] macbs = LoUtils.hexStr2Bytes(macStr);
		AssertUtils.isTrue(macbs != null && macbs.length == 8, "消息校验错:" + macbs);
		// 设置值.
		macField.setOrigMsg(macbs);
		msgPack.putBitmapField(macField);
	}
}
