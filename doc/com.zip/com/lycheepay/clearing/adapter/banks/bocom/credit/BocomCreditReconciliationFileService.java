/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.bocom.credit;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交通银行信用卡对账文件服务类</P>
 * 
 * @author 廖四发(13554889794)
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_RECONCILIATION_FILE_SERVICE)
public class BocomCreditReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	/*
	 * (non-Javadoc)
	 * @see
	 * com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile
	 * (java.lang.String, java.lang.String, java.lang.String)
	 * @author 廖四发(13554889794)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param fileFullPath 对账文件路径
	 * @param channelId 渠道ID
	 * @param settleDate 清算日期
	 * @author 李斌(13665100450)
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String fileFullPath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		Log4jUtil.info("清算日期：" + settleDate + " , 文件路径：" + fileFullPath + " , 渠道ID：" + channelId);

		Assert.notNull(channelId, "渠道ID不能为空!");
		Assert.notNull(settleDate, "交行信用卡对账请求的queryDate不能为空!");
		Assert.notNull(fileFullPath, "没有指定交行信用卡对账文件!");
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String merChantNo = channelParms.get("100006");// 商户号
		Assert.notNull(merChantNo, "交行信用卡对账请求中商户号不能为空!");
		int duplicateCount = 0;
		try {
			Workbook wb = new HSSFWorkbook(new FileInputStream(fileFullPath));
			Sheet sheet1 = wb.getSheetAt(0);
			for (Row row : sheet1) {
				Log4jUtil.info("读取第 " + row.getRowNum() + "行记录");
				if (row.getCell(0) == null || !merChantNo.equals(row.getCell(0).toString().trim())) {
					continue;
				}
				// String merchant = row.getCell(0).toString().trim(); // 交行商户号
				// String acctNo = row.getCell(1).toString().trim(); // 账号
				String tradeDate = row.getCell(2).toString().trim(); // 交易日期
				// String tradeTime = row.getCell(3).toString().trim(); // 交易时间
				String bankRecvSn = row.getCell(4).toString().trim(); // 授权码
				// String clientCode = row.getCell(5).toString().trim(); // 终端号
				String batchNo = row.getCell(6).toString().trim(); // 批次号
				String tranType = row.getCell(7).toString().trim(); // 交易类型
				String tradeAmt = row.getCell(8).toString().trim(); // 交易金额
				// String feeAmt = row.getCell(9).toString().trim(); // 手续费金额
				// String balanceAmt = row.getCell(10).toString().trim(); // 结算金额
				// String tradeScore = row.getCell(11).toString().trim(); // 交易积分
				// String AllowanceAmt = row.getCell(12).toString().trim(); // 折抵金额
				// String payAmt = row.getCell(13).toString().trim(); // 实付金额

				ReconciliationFileDTO accBean = new ReconciliationFileDTO();
				BillnoSn billnoSn = null;
				try {
					List<BillnoSn> billnoSnList = billnoSnService.selectByBankRecvSnAndBatchNo(
							ChannelId.ChannelIdEnum.BOCOM_CREDIT_CARD.getCode(), bankRecvSn + batchNo, StringUtils
									.leftPad(batchNo, 6, "0"), settleDate, new BigDecimal(tradeAmt)
									.compareTo(BigDecimal.ZERO) > 0 ? ClearingTransType.REAL_TIME_DEDUCT
									: ClearingTransType.AUTO_REAL_TIME_REFUND, new BigDecimal(tradeAmt).abs());
					if (!billnoSnList.isEmpty()) {
						billnoSn = billnoSnList.get(0);
						if (billnoSnList.size() > 1) {
							billnoSn.setBankSendSn(duplicateCount++ + "XX" + billnoSn.getBankSendSn());
						}
					}
				} catch (Exception e) {
					Log4jUtil.error(e);
					Log4jUtil.error("bankRecvSn:{},batchNo:{},settleDate:{},tradeAmt:{}", bankRecvSn, batchNo, settleDate, tradeAmt);
					continue;
				}
				if (billnoSn != null) {
					accBean.setBankTransState("00");// 对账文件中只包括成功的记录
					accBean.setBankSendId(billnoSn.getBankSendSn()); // 授权码
					accBean.setBankRecvSN(billnoSn.getBankRecvSn());
					//accBean.setCreditBatchNo(StringUtils.leftPad(batchNo, 6, "0"));
				} else {
					Log4jUtil.info("找不到银行授权码为" + bankRecvSn + ", 渠道ID为"
							+ ChannelId.ChannelIdEnum.BOCOM_CREDIT_CARD.getCode() + ", 批次号为"
							+ StringUtils.leftPad(batchNo, 6, "0")
							+ "的原交易!");
					accBean.setBankSendId(bankRecvSn + batchNo); // 授权码
					accBean.setBankRecvSN(bankRecvSn + batchNo);
					//accBean.setCreditBatchNo(StringUtils.leftPad(batchNo, 6, "0"));
					accBean.setBankTransState("00");
				}
				accBean.setCheckDate(settleDate);// 交易日期
				accBean.setTransDate(tradeDate); // 结算日期
				accBean.setAmount(new BigDecimal(tradeAmt));// 交易金额
				accBean.setChannelId(channelId);
				Log4jUtil.info("--交行信用卡--对账交易信息为:bankSendId[" + accBean.getBankSendId() + "]tradeAmount["
						+ accBean.getAmount() + "]TranDate" + accBean.getTransDate() + "]CheckDate["
						+ accBean.getCheckDate() + "]BankTransState[" + accBean.getBankTransState() + "]");
				if (accBean.getAmount().compareTo(BigDecimal.ZERO) > 0) {
					accBean.setPayGet("get");
					reconciliationFileDTOList.add(accBean);
				} else if (accBean.getAmount().compareTo(BigDecimal.ZERO) < 0) {
					accBean.setPayGet("pay");
					reconciliationFileDTOList.add(accBean);
				}
			}
		} catch (final FileNotFoundException e) {
			Log4jUtil.error("指定交行信用卡对账文件不存在!请检查此文件:[" + fileFullPath + "]是否存在?", e);
			throw new ClearingAdapterBizCheckedException(BusinessCode.FILE_NOT_FOUND, "指定交行信用卡对账文件不存在!请检查此文件:["
					+ fileFullPath + "]是否存在?");
		} catch (final IOException e) {
			Log4jUtil.error("IOException", e);
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, e.getMessage(), e);
		}
		Log4jUtil.info("对账明细" + reconciliationFileDTOList);
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		Log4jUtil.info("进入" + logPrefix + "对账处理。传进对账文件路径参数为:[" + targetFilePath + "],渠道ID为:[" + channelId + "]对账日期为:["
				+ settleDate + "]");
		final String reconciliationDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath,
				channelId, settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + reconciliationDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix,
				targetFilePath, channelId, reconciliationDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				reconciliationDate, reconciliationFileDTOList);
		return fileFullPath;
	}
}
