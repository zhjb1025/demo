/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-28 下午3:48:25
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.bocom.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.bocom.credit.kft.processor.BocomCreditDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;



/**
 * <P>交行信用卡处理类</P>
 * 
 * @author 廖四发
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_CHANNEL_SERVICE)
public class BocomCreditChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_CREDIT_DIRECT_PROCESS)
	private BocomCreditDirectProcess bocomCreditDirectProcess;

	private static final String channelId = ChannelIdEnum.BOCOM_CREDIT_CARD.getCode();

	@Override
	public ClearingResultDTO directDeduct(DeductDTO deductDTO) throws ClearingAdapterBizCheckedException {

		Log4jUtil.setLogClass("BOCOM", "directDeduct");
		Log4jUtil.info(deductDTO);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);

		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		ReturnState returnState = null;
		try {
			returnState = bocomCreditDirectProcess.directDeduct(param);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, channelResultDTO);
		}

		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());
		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	@Override
	public ClearingResultDTO autoRealtimeRefund(RefundDTO refund) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOCOM", "autoRealtimeRefund");
		Log4jUtil.info(refund);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		param.setSn(refund.getTxnId());
		param.setBorc(refund.getBankCardType());
		param.setBizBean(refund);

		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		ReturnState returnState;
		try {
			returnState = bocomCreditDirectProcess.autoRealRefund(param);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, channelResultDTO);
		}
		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());
		
		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;

	}

	/**
	 * <p>签到</p>
	 * 
	 * @author 廖四发
	 */
	public void sign() {
		Log4jUtil.setLogClass("BOCOM", "sign");
		try {
			bocomCreditDirectProcess.dealSignIn(ChannelIdEnum.BOCOM_CREDIT_CARD.getCode());
			Log4jUtil.info(DateUtil.getCurrentChnDate() + "交行信用卡渠道自动联机签到处理成功");
		} catch (final Exception e) {
			Log4jUtil.error(e);
			Log4jUtil.info(DateUtil.getCurrentChnDate() + "交行信用卡渠道自动联机签到处理失败" + e.getMessage());
		}
	}

}
