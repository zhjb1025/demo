/*******************************************************************************
 * Project Key :Clearing-Adapter
 * Create on 2012-3-5 下午3:44:29
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.bocom.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor.BocomB2CDirectProcess;
import com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor.BocomHttpProcessor;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.NetDeductType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.common.dto.trade.NetResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交通网银B2C清算服务入口类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午10:21:11
 */
@Service(ClearingAdapterAnnotationName.BOCOM_B2C_CHANNEL_SERVICE)
public class BocomB2CChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_HTTP_PROCESSOR)
	private BocomHttpProcessor bocomHttpProcessor;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_B2C_DIRECT_PROCESS)
	private BocomB2CDirectProcess bocomB2CDirectProcess;

	public final static String channelId = ChannelIdEnum.BOCOM_B2C.getCode();

	/**
	 * PS.网银B2C代扣
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#onlineDeduct(com.lycheepay.clearing.common.dto.trade.NetDeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public NetResultDTO onlineDeduct(final NetDeductDTO deduct) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOCOM", "online");
		final HttpParam httpParam = new HttpParam();
		httpParam.setChannelId(channelId);
		httpParam
				.setClearingTransType(NetDeductType.TYPE_PAY == deduct.getType() ? ClearingTransType.NET_DEDUCT_B2C_PAY
						: ClearingTransType.NET_DEDUCT_B2C_RECHARGE);
		httpParam.setCustomerType(deduct.getAccountType());
		httpParam.setBizBean(deduct);
		HttpReturnParam httpReturnParam;
		try {
			httpReturnParam = bocomHttpProcessor.onlineDeduct(httpParam);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}

		final NetResultDTO httpProcessChannelResult = new NetResultDTO();
		httpProcessChannelResult.setActionUrl(httpReturnParam.getAction());
		httpProcessChannelResult.setParams(httpReturnParam.getParams());

		return httpProcessChannelResult;
	}

	/**
	 * 报文账户验证(PS.目前唯一一个网银报文账户验证的渠道)
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#accountVerify(com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO accountVerify(final BankCardVerifyDTO accountVerify)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOCOM", "direct");
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.MSG_ACCOUNT_VERIFY);
		param.setBizBean(accountVerify);
		ReturnState returnState;
		try {
			returnState = bocomB2CDirectProcess.accountVerify(param);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}
		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());
		channelResultDTO.setChannelId(channelId);
		
		return channelResultDTO;
	}

	// @Override
	// public BatchRefundResultDTO batchRefund(BatchRefundChannelDTO batchRefundDTO) throws
	// ClearingAdapterBizCheckedException {
	// Log4jUtil.setLogClass("BOCOM", "direct");
	// Param param = new Param();
	// param.setRepeatFlag(batchRefundDTO.getRepeatFlag());
	// param.setChannelId(batchRefundDTO.getChannelId());
	// param.setChannelTransType(ChannelTransType.PayRefund);
	// param.setTransType(batchRefundDTO.getTransType());
	//
	// if ("Y".equals(param.getRepeatFlag())) {// 若为重发，则传进来是个包号
	// param.setBizBean(batchRefundDTO.getChannelBatchid());
	// } else {
	// BatchRefund batchRefund = new BatchRefund();
	// BatchRefundId id = new BatchRefundId();
	// id.setChannelId(batchRefundDTO.getChannelId());
	// id.setRefundNetNo(batchRefundDTO.getRefundNetNo());
	// id.setRefundType(batchRefundDTO.getRefundType());
	// batchRefund.setId(id);
	// param.setBizBean(batchRefund);
	// }
	//
	// ReturnState returnState = bocomB2CDirectProcess.deal(param);
	// BatchRefundResultDTO batchRefundResultDTO = new BatchRefundResultDTO();
	// batchRefundResultDTO.setReturnState(returnState.getReturnState());
	// batchRefundResultDTO.setFileNames((List<?>) returnState.getReturnObj());
	// return batchRefundResultDTO;
	// }

	/**
	 * 获取账户余额
	 */
	public Balance queryBanlance() {
		Balance balance = null;
		try {
			balance = bocomB2CDirectProcess.queryBanlance();
		} catch (Throwable e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}
}
