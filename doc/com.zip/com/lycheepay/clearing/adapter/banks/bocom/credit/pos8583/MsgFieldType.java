package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.trade.FieldParser;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.trade.VarlenFieldParser;
import com.lycheepay.clearing.adapter.common.exception.RuntimeBizException;


/**
 * 报文域类型, 包括报文头等.
 * 
 * @author aps-mhc
 */
public final class MsgFieldType {
	private final String no;
	private final String name;

	// 最大长度,定长域适用,变长域只作为参考.
	private final int maxLength;

	// 内容的类型, BCD, BINARY或ASCII
	private final int contentType;
	private final FieldParser parser;

	public static final Map<String, MsgFieldType> ALL = new HashMap<String, MsgFieldType>();
	public static final MsgFieldType TPDU = new MsgFieldType("协议单元", "TPDU", 5, IsoType.BCD, new FieldParser());
	public static final MsgFieldType HEAD = new MsgFieldType("报文头", "HEAD", 1, IsoType.BCD, new FieldParser());
	public static final MsgFieldType MSG_TYPE = new MsgFieldType("消息类型", "MSGTYPE", 2, IsoType.BCD, new FieldParser());
	public static final MsgFieldType BITMAP = new MsgFieldType("位元表", "BITMAP", 8, IsoType.BINARY, new FieldParser());

	public static final MsgFieldType FIELD_2 = new MsgFieldType("2域", "2", 19, IsoType.BCD, new VarlenFieldParser(1));
	public static final MsgFieldType FIELD_3 = new MsgFieldType("3域", "3", 3, IsoType.BCD, new FieldParser());
	public static final MsgFieldType FIELD_4 = new MsgFieldType("4域", "4", 6, IsoType.BCD, new FieldParser());

	public static final MsgFieldType FIELD_11 = new MsgFieldType("11域", "11", 3, IsoType.BCD, new FieldParser());
	public static final MsgFieldType FIELD_12 = new MsgFieldType("12域", "12", 3, IsoType.BCD, new FieldParser());
	public static final MsgFieldType FIELD_13 = new MsgFieldType("13域", "13", 2, IsoType.BCD, new FieldParser());
	public static final MsgFieldType FIELD_14 = new MsgFieldType("14域", "14", 2, IsoType.BCD, new FieldParser());
	// public static final MsgFieldType FIELD_15 = new MsgFieldType("15域", "15", 2, IsoType.BCD, new
	// FieldParser());

	public static final MsgFieldType FIELD_22 = new MsgFieldType("22域", "22", 3, IsoType.BCD, new FieldParser());
	public static final MsgFieldType FIELD_23 = new MsgFieldType("23域", "23", 2, IsoType.BCD, new FieldParser());
	// public static final MsgFieldType FIELD_24 = new MsgFieldType("24域", "24", 2, IsoType.BCD, new
	// FieldParser());
	public static final MsgFieldType FIELD_25 = new MsgFieldType("25域", "25", 1, IsoType.BCD, new FieldParser());
	// public static final MsgFieldType FIELD_26 = new MsgFieldType("26域", "26", 1, IsoType.BCD, new
	// FieldParser());

	public static final MsgFieldType FIELD_28 = new MsgFieldType("28域", "28", 1, IsoType.ASCII, new FieldParser());

	// public static final MsgFieldType FIELD_32 = new MsgFieldType("32域", "32", 7, IsoType.BCD, new
	// VarlenFieldParser(1));
	public static final MsgFieldType FIELD_35 = new MsgFieldType("35域", "35", 37, IsoType.BCD, new VarlenFieldParser(1));
	public static final MsgFieldType FIELD_36 = new MsgFieldType("36域", "36", 104, IsoType.BCD,
			new VarlenFieldParser(2));
	public static final MsgFieldType FIELD_37 = new MsgFieldType("37域", "37", 12, IsoType.ASCII, new FieldParser());
	public static final MsgFieldType FIELD_38 = new MsgFieldType("38域", "38", 6, IsoType.ASCII, new FieldParser());
	public static final MsgFieldType FIELD_39 = new MsgFieldType("39域", "39", 2, IsoType.ASCII, new FieldParser());

	public static final MsgFieldType FIELD_41 = new MsgFieldType("41域", "41", 8, IsoType.ASCII, new FieldParser());
	public static final MsgFieldType FIELD_42 = new MsgFieldType("42域", "42", 15, IsoType.ASCII, new FieldParser());
	public static final MsgFieldType FIELD_43 = new MsgFieldType("43域", "43", 999, IsoType.ASCII,
			new VarlenFieldParser(2));
	public static final MsgFieldType FIELD_44 = new MsgFieldType("44域", "44", 128, IsoType.ASCII,
			new VarlenFieldParser(1));
	public static final MsgFieldType FIELD_49 = new MsgFieldType("49域", "49", 3, IsoType.ASCII, new FieldParser());

	public static final MsgFieldType FIELD_52 = new MsgFieldType("52域", "52", 8, IsoType.BINARY, new FieldParser());
	public static final MsgFieldType FIELD_53 = new MsgFieldType("53域", "53", 16, IsoType.BCD, new FieldParser());
	public static final MsgFieldType FIELD_55 = new MsgFieldType("55域", "55", 255, IsoType.ASCII,
			new VarlenFieldParser(2));
	public static final MsgFieldType FIELD_60 = new MsgFieldType("60域", "60", 6, IsoType.ASCII,
			new VarlenFieldParser(2));
	public static final MsgFieldType FIELD_61 = new MsgFieldType("61域", "61", 15, IsoType.ASCII, new VarlenFieldParser(
			2));
	public static final MsgFieldType FIELD_62 = new MsgFieldType("62域", "62", 24, IsoType.ASCII, new VarlenFieldParser(
			2));
	public static final MsgFieldType FIELD_63 = new MsgFieldType("63域", "63", 156, IsoType.ASCII,
			new VarlenFieldParser(2));
	public static final MsgFieldType FIELD_64 = new MsgFieldType("64域", "64", 8, IsoType.BINARY, new FieldParser());

	private MsgFieldType(String name, String no, int maxLength, int contentType, FieldParser parser) {
		this.name = name;
		this.no = no;
		this.maxLength = maxLength;
		this.contentType = contentType;
		this.parser = parser;
		parser.setFieldType(this);

		ALL.put(no, this);
	}

	public int getMaxLength() {
		return maxLength;
	}

	public FieldParser getParser() {
		return parser;
	}

	public int getContentType() {
		return contentType;
	}

	public String getName() {
		return name;
	}

	public String getNo() {
		return no;
	}

	public static MsgFieldType valueOf(String value) {
		MsgFieldType type = ALL.get(value);

		if (type == null) {
			throw new RuntimeBizException("无消息域:" + value);
		}
		return type;
	}

	/**
	 * 获取当前域在位图中的索引, 从0开始.
	 */
	public int getBitmapIndex() {
		return StringUtils.isNumeric(no) ? Integer.parseInt(no) - 1 : -1;
	}

	public static void main(String[] args) {
		System.out.print("--");
	}
}
