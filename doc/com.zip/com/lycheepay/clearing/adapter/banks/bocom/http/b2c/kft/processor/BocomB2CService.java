package com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;


/**
 * <P> 交通银行网银B2C HTTP(一般被*_DIRECT_PROCESS调用)最后服务处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午10:57:12
 */
@Service(ClearingAdapterAnnotationName.BOCOM_B2C_SERVICE)
public class BocomB2CService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	// private static ChannelRefundDao channelRefundDao = (ChannelRefundDao)
	// SpringContext.getService("channelRefundDao");
	// private static ChannelBatchRefundDao channelBatchRefundDao = (ChannelBatchRefundDao)
	// SpringContext
	// .getService("channelBatchRefundDao");
	private static final String channelId = ChannelIdEnum.BOCOM_B2C.getCode();

	// public ReturnState batchRefundByAPI(final String channelBatchid, final int i, final String
	// configFilePath,
	// final String merchantOper) throws BizException {
	//
	// final List<ChannelRefund> channelRefundList =
	// channelRefundDao.getListByChannelBatchId(channelBatchid);
	// AssertUtils.notNull(channelRefundList, "做交行退款交易时，取 channelRefund 记录出错！");
	// final ChannelRefund channelRefund = channelRefundList.get(0);
	// AssertUtils.notNull(channelRefund, "做交行退款交易时，取 渠道退款流水表（channel_Refund）记录出错！");
	// final ChannelBatchRefund channelBatchRefund = channelBatchRefundDao.findById(channelBatchid);
	// if (channelBatchRefund == null) {
	// throw new BizException(channelId + "从channel_Batch_Refund表中无法获取Channel_BatchId为：" +
	// channelBatchid + "的记录。");
	// }
	// // 获取原业务发往银行的流水（订单号）和 退款金额
	// final String bILLNoSeq = channelRefund.getBillnoSeq();
	// final BillnoSn billnoSn = billnoSnService.findById(bILLNoSeq);
	// if (billnoSn == null) {
	// Log4jUtil.info(channelId + "在渠道流水对照表中没有记录bILLNoSeq:" + bILLNoSeq);
	// }
	// final RefundBean bizBean = new RefundBean();
	// bizBean.setRefundType(channelBatchRefund.getRefundType());
	// bizBean.setBankSendSn(billnoSn.getBankSendSn());
	// bizBean.setAmount(channelRefund.getRefundAmount());
	// bizBean.setTranDate(billnoSn.getTranDate());
	// bizBean.setBillnosnSeq(billnoSn.getBillnosnSeq());
	// ReturnState rs = null;
	// rs = dealPayRefund(bizBean, configFilePath, merchantOper,
	// channelRefund.getId().getRefundSn());
	// Log4jUtil.info(channelId + "渠道返回码rs.getChannelCode()=" + rs.getChannelCode());
	// if ("0000".equals(rs.getChannelCode())) {
	// rs.setChannelCode("0000");
	// channelRefund.setState("04"); // 04- 退款成功
	// channelRefundDao.update(channelRefund);
	// channelBatchRefund.setState("03");// 03：回执全部返回
	// channelBatchRefund.setRemark(rs.getReturnMsg());
	// channelBatchRefundDao.update(channelBatchRefund);
	// } else {
	// rs.setChannelCode(TransReturnCode.code_9900);
	// channelRefund.setState("05"); // 05- 退款失败
	// channelRefundDao.update(channelRefund);
	// channelBatchRefund.setState("03");// 03：回执全部返回
	// channelBatchRefund.setRemark(rs.getReturnMsg());
	// channelBatchRefundDao.update(channelBatchRefund);
	// }
	// // 退款业务回调基础平台.
	// final List<ReturnState> returnStateList = new ArrayList<ReturnState>();
	// returnStateList.add(0, rs);
	// processBiz(channelBatchRefund.getRefundType(), returnStateList);
	// return rs;
	// }
	//
	// /**
	// * 调用平台的退款业务处理 退款业务处理回调.
	// */
	// private void processBiz(final String refundType, final List<ReturnState> returnStateList) {
	// final BaseParam baseParam = new BaseParam();
	// baseParam.setChannelId(channelId);
	// baseParam.setChannelTransType(ChannelTransType.PayRefund);
	// String logMsg = "";
	// if (refundType.equals("01")) {// 支付或充值退款
	// logMsg = "进行8021业务回调";
	// Log4jUtil.info(logMsg);
	// final Biz8021Adapter biz8021Adapter = new Biz8021Adapter();
	// biz8021Adapter.deal(baseParam, returnStateList);
	// } else if (refundType.equals("02")) {// 调账退款
	// logMsg = "进行8024业务回调";
	// Log4jUtil.info(logMsg);
	// final Biz8024Adapter biz8024Adapter = new Biz8024Adapter();
	// biz8024Adapter.deal(baseParam, returnStateList);
	// }
	// }
	//
	// /**
	// * 失败处理.
	// *
	// * @param channelBatchId
	// * @param returnState
	// * @throws BizException
	// */
	// public void updateChannelBatchRefundToFail(final String channelBatchId, final ReturnState
	// returnState) {
	// try {
	// final ChannelBatchRefund cbr = channelBatchRefundDao.findByIdWithLock(channelBatchId);
	// AssertUtils.notNull(cbr, "获取到的渠道批量退款表对象为NULL。channelBatchId为：" + channelBatchId);
	// if (cbr.getState().equals("00")) {
	// cbr.setState("09");
	// if (returnState.getBankPostScript() != null) {
	// if (returnState.getBankPostScript().length() < 255) {
	// cbr.setRemark(returnState.getBankPostScript().substring(0,
	// returnState.getBankPostScript().length() - 1));
	// } else {
	// cbr.setRemark(returnState.getBankPostScript().substring(0, 254));
	// }
	// }
	// channelBatchRefundDao.update(cbr);
	// final List<ChannelRefund> channelRefundList =
	// channelRefundDao.getListByChannelBatchId(channelBatchId);
	// AssertUtils.notNull(channelRefundList, "做交行退款交易时，取 channelRefund 记录出错！");
	// final ChannelRefund channelRefund = channelRefundList.get(0);
	// channelRefund.setState("03"); // 03- 已触发退款
	// channelRefundDao.update(channelRefund);
	// }
	// } catch (final Exception e) {
	// Log4jUtil.error(channelId + "更新ChannelBatchRefund表出错", e);
	// }
	// }
	//
	// /**
	// * 退款
	// *
	// * @param param
	// * @return
	// * @throws BizException
	// */
	// private ReturnState dealPayRefund(final RefundBean bizBean, final String configFilePath,
	// final String merchantOper,
	// final String RefundSn) throws BizException {
	// // 检查业务数据
	// AssertUtils.notNull(bizBean.getBankSendSn(), "交通网银支付退款业务Bean的流水号不能为空");
	// AssertUtils.notNull(bizBean.getAmount(), "交通网银支付退款业务Bean的退款金额不能为空");
	// AssertUtils.notNull(bizBean.getTranDate(), "交通网银支付退款业务Bean的退款日期不能为空");
	// AssertUtils.notNull(merchantOper, "交通银行网银渠道连接器中未得到merchantNo");
	// final BOCOMB2CClient client = new BOCOMB2CClient();
	// final int ret = client.initialize(configFilePath);
	// final ReturnState rs = new ReturnState();
	// if (bizBean.getRefundType().equals("01")) {
	// rs.setSn(RefundSn);
	// } else if (bizBean.getRefundType().equals("02")) {
	// rs.setSn(bizBean.getBillnosnSeq());
	// }
	// if (ret != 0) {// 初始化失败
	// Log4jUtil.debug("初始化失败,错误信息：" + client.getLastErr());
	// throw new BizException("交通银行网银api Client初始化失败,请查看交行网银配置是否正确,或确定证书已经导入到JVM!");
	// } else {
	// // 在发送到接受回执的这个过程抛出的异常的退款将不能重发.因为不知道银行端是否是成功的.象这种情况只能人工干涉.
	// try {
	// final java.text.DecimalFormat df = new java.text.DecimalFormat("0.00");//
	// ""00.00"小数点后面的0的个数表示小数点的个数
	// final String amount = df.format(bizBean.getAmount());
	// final BOCOMB2COPReply rep = client.Refund(merchantOper, bizBean.getBankSendSn(),
	// bizBean.getTranDate(),
	// amount, "快付通退款"); // 退款录入
	// if (rep == null) {
	// Log4jUtil.debug("交易错误信息：" + client.getLastErr());
	// throw new BizException("交易错误信息：" + client.getLastErr());
	// } else {
	// final String code = rep.getRetCode(); // 得到交易返回码
	// final String err = rep.getLastErr();
	// final String msg = rep.getErrorMessage();
	// Log4jUtil.debug("交易返回码：" + code);
	// Log4jUtil.debug("交易错误信息：" + msg);
	// if ("0".equals(code)) {// 表示交易成功
	// rs.setReturnState(PayState.SUCCEED_RTN);
	// rs.setChannelCode("0000");
	// rs.setBankPostScript(msg);
	// rs.setReturnMsg(msg);
	// rs.setRelTranAmount(bizBean.getAmount());
	// final OpResult opr = rep.getOpResult();
	// Log4jUtil.info("交通退款处理成功,退款的[BillnosnSeq]为:" + bizBean.getBillnosnSeq());
	// Log4jUtil.info("交通退款处理成功,退款的[serial]为:" + opr.getValueByName("serial"));// 退款流水号
	// Log4jUtil.info("交通退款处理成功,退款的[account]为:" + opr.getValueByName("account"));// 退款账号
	// Log4jUtil.info("交通退款处理成功,退款的[account]为:" + amount);// 退款金额
	// } else {
	// Log4jUtil.info("交通退款处理失败,退款的[BillnosnSeq]为:" + bizBean.getBillnosnSeq());
	// rs.setReturnState(PayState.FAILED_TRN);
	// rs.setChannelCode(TransReturnCode.code_9900);
	// rs.setBankPostScript(err);
	// rs.setReturnMsg(msg);
	// rs.setRelTranAmount(bizBean.getAmount());
	// }
	// }
	// } catch (final Exception e) {
	// Log4jUtil.info("交通退款处理失败,退款的[BillnosnSeq]为:" + bizBean.getBillnosnSeq());
	// rs.setReturnState(PayState.FAILED_TRN);
	// rs.setChannelCode(TransReturnCode.code_9900);
	// rs.setBankPostScript(e.getMessage());
	// rs.setReturnMsg(e.getMessage());
	// }
	// }
	// return rs;
	// }
	//
	// /**
	// * @deprecated 根据channelBatchid(清分包号）生成退款文件
	// * @param channelBatchid 清分包号
	// * @param number 包顺序号
	// * @return fileName
	// * @throws BizException
	// *
	// */
	// @Deprecated
	// @SuppressWarnings("unchecked")
	// public String makeBatchRefund(final String channelBatchid, final int number, final String
	// refundFilePath)
	// throws BizException {
	// final StringBuffer sbStr = new StringBuffer("");
	// final List<ChannelRefund> channelRefundList =
	// channelRefundDao.getListByChannelBatchId(channelBatchid);
	//
	// String tranDate = "";
	// String banSendSN = "";
	// String refundAmount = "";
	// for (int j = 0; j < channelRefundList.size(); j++) {
	// // 获取原业务发往银行的流水（订单号）和 退款金额
	// final String bILLNoSeq = channelRefundList.get(j).getBillnoSeq();
	// final BillnoSn billnoSn = billnoSnService.findById(bILLNoSeq);
	// if (billnoSn == null) {
	// Log4jUtil.info(channelId + "在渠道流水对照表中没有记录bILLNoSeq:" + bILLNoSeq);
	// continue;
	// }
	//
	// tranDate = billnoSn.getTranDate();
	// banSendSN = billnoSn.getBankSendSn();
	// refundAmount = String.format("%1$.2f", channelRefundList.get(j).getRefundAmount());
	// /*组退款文件明细格式：
	// * 交易日期,订单号,退单金额 示例：
	// 20110421,0000000007,0.01
	// 20110421,0000000008,0.01
	// */
	// final String split = ",";
	// sbStr.append(tranDate).append(split).append(banSendSN).append(split).append(refundAmount).append("\n");
	// }
	// // 文件名：渠道编号+年月日+4位(从1－9999）.txt
	// final String fileName = channelId + DateUtil.getCurrentDate() + formatInt(number, 4) +
	// ".txt";
	// // 带路径退款文件名
	// FileUtil.mkdir(refundFilePath, false);
	// final String fileNamePath = refundFilePath + fileName;
	// Log4jUtil.info(channelId + "渠道生成退款文件的路径如下:[" + fileNamePath + "]");
	//
	// // 生成批量退款文件到本地
	// // ComProcessXml.CreateBatchFileToLocal(fileNamePath, sbStr.toString());
	// // 更新渠道批量退款表状态01：银行已收妥
	// final ChannelBatchRefund channelBatchRefund = channelBatchRefundDao.findById(channelBatchid);
	// if (channelBatchRefund == null) {
	// throw new BizException(channelId + "从channel_Batch_Refund表中无法获取Channel_BatchId为：" +
	// channelBatchid + "的记录。");
	// }
	// channelBatchRefund.setState("01");
	// channelBatchRefundDao.update(channelBatchRefund);
	// return fileName;
	// }
	//
	// /**
	// *
	// * 生成清分包号的顺序号 如：第1包，如果生产固定3位， 则001
	// *
	// * @param number 包顺序号
	// * @param len 固定长度编号
	// * @return
	// */
	// public static String formatInt(final int number, final int len) {
	// String mask = "";
	// String returnVal = "";
	// for (int i = 0; i < len; i++) {
	// mask += "0";
	// }
	// returnVal = mask + String.valueOf(number);
	// returnVal = returnVal.substring(returnVal.length() - len, len);
	// return returnVal;
	// }

}
