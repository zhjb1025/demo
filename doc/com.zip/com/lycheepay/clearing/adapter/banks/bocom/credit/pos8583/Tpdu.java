package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 报文传输协议单元.
 * 
 * @author aps-mhc
 */
public class Tpdu {
	private String head;// ID
	private String from;// 源地址
	private String to;// 目的地址

	public Tpdu(byte[] bcdValue) throws BizException {
		// BCD码 Binary-Coded Decimal ，简称BCD，称BCD码或二-十进制代码，亦称二进码十进数。是一种二进制的数字编码形式，用二进制编码的十进制代码
		String tpdu = ByteUtils.bcdToStr(bcdValue);
		AssertUtils.isTrue(tpdu.getBytes().length == 10, "tpdu错误", tpdu);
		// TPDU（Transport Protocol Data Unit，传输协议数据单元）是POS报文的一个特定域，由三项共五个字节的信息组成,转成String的就是10个字节.
		// String中的字符占2个字节
		head = tpdu.substring(0, 2);
		to = tpdu.substring(2, 6);
		from = tpdu.substring(6, 10);
	}

	/**
	 * @param to 4位16进制数字.
	 */
	public void setTo(String to) {
		this.to = to;
	}

	/**
	 * @param to 4位16进制数字.
	 */
	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public byte[] getToByte() {
		return to.getBytes();
	}

	public String getFrom() {
		return from;
	}

	public void exchangeAddress() {
		String temp = from;
		from = to;
		to = temp;
	}

	public byte[] getBcdValue() {
		return ByteUtils.strToBcd(head.concat(to).concat(from));
	}
}
