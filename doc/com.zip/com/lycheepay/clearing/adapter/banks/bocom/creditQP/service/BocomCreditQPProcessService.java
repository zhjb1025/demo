package com.lycheepay.clearing.adapter.banks.bocom.creditQP.service;

import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.service.biz.SignNoService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.sign.ChannelSignApplyRequestDTO;
import com.lycheepay.clearing.common.dto.sign.ChannelSignConfirmRequstDTO;
import com.lycheepay.clearing.common.dto.sign.ChannelSignResponse;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.SignNo;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.adapter.banks.bocom.creditQP.constant.Constant;
import com.lycheepay.clearing.adapter.banks.bocom.creditQP.model.ComRspDTO;

@Service
public class BocomCreditQPProcessService {
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager seqService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	
	@Autowired
	private BocomCreditQPSocketService socketService;
	
	@Autowired
	private BocomCreditQPPackageService packageService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;
	
	@Autowired
	private SignNoService signNoService;
	
	public final static String channelId = ChannelIdEnum.BOCOM_CREDIT_QUICK_PAY_CORP.getCode();
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;
	
	/**
	 * 无磁无密消费(无动态码)
	 * @param deduct
	 * @return
	 * @throws BizException
	 */
	public ClearingResultDTO directDeduct(DeductDTO deduct, SignNo signNo) throws BizException {
		// 获取渠道基本参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		// 获取银行交易流水
		String bankSendSn = seqService.getBocomCreditQPSendSeq();
		// 1. 写渠道流水对照表(billno_sn)
		BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, deduct);
		// 2. 创建交易请求报文
		String xml0200Body = packageService.package0200Deduct(bankSendSn, deduct, channelParms, signNo);
		String reqMsg = Constant.HEAD + xml0200Body;
		// 3. 发送交易请并接受回执
		String tradeUrl = channelParms.get(Constant.TRADE_URL);
		String result = socketService.sendDate(reqMsg, tradeUrl,channelParms);
		// 4. 解析回执
		ComRspDTO rsp = packageService.unpackageCommonRSP(result);

		String bankRtnCode = StringUtils.trim(rsp.getReturnCode());
		
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		if("00".equals(bankRtnCode)){	//交易成功
			resultDTO.setChannelResponseMsg(rsp.getReturnMsg());
			resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			resultDTO.setTxnStatus(PayState.SUCCEED_STR);
			if(StringUtils.isBlank(resultDTO.getChannelResponseMsg())){
				resultDTO.setChannelResponseMsg("交易成功");
			}
		}else{	//交易失败
			ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, bankRtnCode));
			if (channelRtncode != null) {
				resultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
				if (StringUtils.isBlank(rsp.getReturnMsg())) {
					resultDTO.setChannelResponseMsg(channelRtncode.getChannelReamrk());
				} else {
					resultDTO.setChannelResponseMsg(rsp.getReturnMsg());
				}
			} else {
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			}
			
			if(StringUtils.isBlank(resultDTO.getChannelResponseMsg())){
				resultDTO.setChannelResponseMsg("交易失败");
			}
			
			resultDTO.setTxnStatus(PayState.FAILED_STR);
		}

		// 3. 更新渠道流水对照表(billno_sn)
		BillnoSn updateBillnoSn = new BillnoSn();
		updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
		updateBillnoSn.setChannelRtncode(StringUtils.trim(bankRtnCode));
		updateBillnoSn.setRecvTime(new Date());
		updateBillnoSn.setBankRecvSn(rsp.getAuthNo());
		updateBillnoSn.setState(BillnoSnState.billnoRecv);
		updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
		updateBillnoSn.setChannelRtnnote(resultDTO.getChannelResponseMsg());
		updateBillnoSn.setBankDate(rsp.getHostDate());  //更新银行返回时间
		billnoSnService.update(updateBillnoSn);
		return resultDTO;
	}
	
	
	
	public ClearingResultDTO autoRealtimeRefund(RefundDTO refund) throws BizException{
		//获取原交易记录
		BillnoSn obillnoSn = billnoSnService.findBillnoSn(channelId, refund.getOrgTransTxnId());
		//验证退款基本要素是否合法
		AssertUtils.notNull(obillnoSn, TransReturnCode.code_9108, "原交易流水[" + refund.getOrgTransTxnId() + "]不存在.");
		AssertUtils.notTrue(refund.getAmount().compareTo(obillnoSn.getAmount()) > 1, TransReturnCode.code_9108, "退款金额不能大于原交易金额.");
		
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String checkTime = channelParms.get(Constant.CHECK_TIME);	//日切时间 hhmiss
		
		// 生成退款交易流水
		final String bankSendSn = seqService.getBocomCreditQPSendSeq();
		
		Log4jUtil.info("退款交易记录流水号【{}】", bankSendSn);
		
		// 1. 写渠道流水对照表(billno_sn)
		BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, refund);
		
		// 2. 发送处理(当日冲正、隔日退款)
		ComRspDTO rsp = null;
		
		if (refund.getAmount().compareTo(obillnoSn.getAmount()) == 0
				&& DateUtil.getCurrentDate().equals(obillnoSn.getBankDate())
				&& beforeRiQie(checkTime)) {
			//冲正交易，其冲正金额需与原交易金额一致，否真虽然银行返回冲正成功，但是次交易并没有真正被冲正
			rsp = this.cancel(refund, bankSendSn, obillnoSn, channelParms);
		} else {
			rsp = this.reFund(refund, bankSendSn, obillnoSn, channelParms);
		}
		
		// 4. 判断冲正结果
		ClearingResultDTO clearingResult = new ClearingResultDTO();
		String bankRtnCode = StringUtils.trim(rsp.getReturnCode());
		if("00".equals(rsp.getReturnCode())){
			clearingResult.setChannelResponseMsg(rsp.getReturnMsg());
			clearingResult.setChannelResponseCode(TransReturnCode.code_0000);
			clearingResult.setTxnStatus(PayState.SUCCEED_STR);
			if(StringUtils.isBlank(clearingResult.getChannelResponseMsg())){
				clearingResult.setChannelResponseMsg("交易成功");
			}
		}else{
			ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, bankRtnCode));
			if (channelRtncode != null) {
				clearingResult.setChannelResponseCode(channelRtncode.getKftRtncode());
				if (StringUtils.isBlank(rsp.getReturnMsg())) {
					clearingResult.setChannelResponseMsg(channelRtncode.getChannelReamrk());
				} else {
					clearingResult.setChannelResponseMsg(rsp.getReturnMsg());
				}
			} else {
				clearingResult.setChannelResponseCode(TransReturnCode.code_9900);
			}
			
			if(StringUtils.isBlank(clearingResult.getChannelResponseMsg())){
				clearingResult.setChannelResponseMsg("交易失败");
			}
			clearingResult.setTxnStatus(PayState.FAILED_STR);
		}
		
		// 3. 更新渠道流水对照表(billno_sn)
		BillnoSn updateBillnoSn = new BillnoSn();
		updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
		updateBillnoSn.setChannelRtncode(StringUtils.trim(bankRtnCode));
		updateBillnoSn.setRecvTime(new Date());
		updateBillnoSn.setState(BillnoSnState.billnoRecv);
		updateBillnoSn.setPayState(String.valueOf(clearingResult.getTxnStatus()));
		updateBillnoSn.setChannelRtnnote(clearingResult.getChannelResponseMsg());
		updateBillnoSn.setBankDate(rsp.getHostDate());  //更新银行返回时间
		billnoSnService.update(updateBillnoSn);
		return clearingResult;
	}
	
	
	/**
	 * <p>判断当前时间是否在日切时间点之前，银联日切时间点为23点，因为kft系统时间和银联时间不完全一致，所以用来做判断的是日切时间点向前挪10分钟</p>
	 * 
	 * @return
	 * @author 黄旭
	 */
	private boolean beforeRiQie(String checkTime) {
		try {
			return System.currentTimeMillis() < DateUtil.getDate(DateUtil.getCurrentDate() + checkTime).getTime();
		} catch (Exception e) {
			Log4jUtil.error("退款判断日切时间出错", e);
			return false;
		}

	}
	
	/**
	 * 交易冲正(针对当日交易)
	 * @param refund 退款请求实体
	 * @param bankSendSn 重整交易渠道流水
	 * @param obillnoSn 原交易订单信息
	 * @param channelParms 渠道基础参数
	 * @return clearingResult 冲正结果
	 * @throws BizException
	 */
	private ComRspDTO cancel(RefundDTO refund, String bankSendSn, BillnoSn obillnoSn, final Map<String, String> channelParms) throws BizException{
		// 1. 创建交易请求报文
		String xml0400Body = packageService.package0400Cancel(bankSendSn, refund, obillnoSn, channelParms);
		
		String reqMsg = Constant.HEAD + xml0400Body;
		// 2. 发送交易请并接受回执
		String tradeUrl = channelParms.get(Constant.TRADE_URL);
		String result = socketService.sendDate(reqMsg, tradeUrl, channelParms);
		// 3. 解析回执
		ComRspDTO rsp = packageService.unpackageCommonRSP(result);
		
		return rsp;
	}
	
	/**
	 * 退货
	 * 1. 退货交易必须隔天，当天不能退货
	 * 2. T日交易，可以在T+1日的上午9点后退货
	 * 3. 如果业务开通部分退货功能，则每笔交易的退货次数最多为10次
	 * 4. 在线退货时间支持13个月
	 * @param refund
	 * @param bankSendSn
	 * @param obillnoSn
	 * @param channelParms
	 * @return
	 * @throws BizException
	 */
	private ComRspDTO reFund(RefundDTO refund, String bankSendSn, BillnoSn obillnoSn, final Map<String, String> channelParms) throws BizException{
		// 1. 创建交易请求报文
		String xml0220Body = packageService.package0220Cancel(bankSendSn, refund, obillnoSn, channelParms);
		
		String reqMsg = Constant.HEAD + xml0220Body;
		// 2. 发送交易请并接受回执
		String tradeUrl = channelParms.get(Constant.TRADE_URL);
		String result = socketService.sendDate(reqMsg, tradeUrl, channelParms);
		// 3. 解析回执
		ComRspDTO rsp = packageService.unpackageCommonRSP(result);
		
		return rsp;
	}



	/**
	 * 签约接口，交行信用卡，快捷需要手机验证码
	 * @param channelSignApplyRequestDTO
	 * @return
	 * @throws BizException
	 */
	public ChannelSignResponse cardSign(ChannelSignApplyRequestDTO channelSignApplyRequestDTO) throws BizException {
		// 获取渠道基本参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String bankSendSn = seqService.getBocomCreditQPSendSeq();
		// 2. 创建交易请求报文
		String traceNo = bankSendSn.substring(bankSendSn.length() - 6);  //流水号取bankSendSn后6位 6位
		String invioceNo = bankSendSn.substring(2, 8) + traceNo;  //票据号=6位批次号+6位凭证号
		String xml0200Body = packageService.package0200CardSign(bankSendSn, traceNo, invioceNo, channelSignApplyRequestDTO, channelParms);
		String reqMsg = Constant.HEAD + xml0200Body;
		// 3. 发送交易请并接受回执
		String tradeUrl = channelParms.get(Constant.TRADE_URL);
		String result = socketService.sendDate(reqMsg, tradeUrl, channelParms);
		// 4. 解析回执
		ComRspDTO rsp = packageService.unpackageCardSignRSP(result);

		String bankRtnCode = StringUtils.trim(rsp.getReturnCode());
		
		ChannelSignResponse resultDTO = new ChannelSignResponse();
		if("00".equals(bankRtnCode)){	//交易成功
			resultDTO.setResponseMsg(rsp.getReturnMsg());
			resultDTO.setCode(TransReturnCode.code_0000);
			resultDTO.setStatus(PayState.TxnStatus.SUCCEED);
			
			//交易成功
			String addDate = rsp.getAddData();
			String seri = addDate.substring(addDate.length() - 2);  //发送验证码返回的序号
			SignNo signNo = signNoService.select(channelSignApplyRequestDTO.getCustBankAccountNo(), channelId, "2");
			if (signNo != null) {
				//更新
				signNo = new SignNo(bankSendSn, channelSignApplyRequestDTO.getCustBankAccountNo(), channelId, "", new Date(), "2", bankSendSn.substring(2, 8), traceNo);
				signNo.setExtra(seri);  //使用备用字段来存储序号
				signNoService.update(signNo);
			} else {
				//保存
				signNo = new SignNo(bankSendSn, channelSignApplyRequestDTO.getCustBankAccountNo(), channelId, "", new Date(), "2", bankSendSn.substring(2, 8), traceNo);
				signNo.setExtra(seri);
				signNoService.insert(signNo);
			}
		}else{	//交易失败
			resultDTO.setResponseMsg(rsp.getReturnMsg());
			resultDTO.setCode(TransReturnCode.code_9900);
			resultDTO.setStatus(PayState.TxnStatus.FAILED);
		}
		return resultDTO;
	}



	/**
	 * 确认签约
	 * @param channelSignApplyRequestDTO
	 * @param channelSignConfirmRequstDTO
	 * @return
	 */
	public ChannelSignResponse cardSignConfrim(ChannelSignApplyRequestDTO channelSignApplyRequestDTO, ChannelSignConfirmRequstDTO channelSignConfirmRequstDTO, SignNo signNo) throws BizException {
		ChannelSignResponse resultDTO = new ChannelSignResponse();
		
		// 获取渠道基本参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String bankSendSn = seqService.getBocomCreditQPSendSeq();
		// 2. 创建交易请求报文
		String certType = channelCertTypeService.getCertType(channelId, channelSignApplyRequestDTO.getCustCertificationType());
		
		String xml0200Body = packageService.package0200CardSignConfirm(bankSendSn, channelSignApplyRequestDTO, channelParms, channelSignConfirmRequstDTO, signNo, certType);
		String reqMsg = Constant.HEAD + xml0200Body;
		// 3. 发送交易请并接受回执
		String tradeUrl = channelParms.get(Constant.TRADE_URL);
		String result = socketService.sendDate(reqMsg, tradeUrl, channelParms);
		// 4. 解析回执
		ComRspDTO rsp = packageService.unpackageCommonRSP(result);

		String bankRtnCode = StringUtils.trim(rsp.getReturnCode());
		
		
		if("00".equals(bankRtnCode)){	//交易成功
			resultDTO.setResponseMsg(rsp.getSysRtnDesc());
			resultDTO.setCode(TransReturnCode.code_0000);
			resultDTO.setStatus(PayState.TxnStatus.SUCCEED);
			
			//交易成功，更新SignNo中状态置成成功状态
			signNo.setStatus("1");
			signNo.setSgnNo(rsp.getSgnNo());  //签约号
			signNoService.update(signNo);
			
		}else{	
			//交易失败
			resultDTO.setResponseMsg(rsp.getSysRtnDesc());
			resultDTO.setCode(TransReturnCode.code_9900);
			resultDTO.setStatus(PayState.TxnStatus.FAILED);
		}
		return resultDTO;
	}
}
