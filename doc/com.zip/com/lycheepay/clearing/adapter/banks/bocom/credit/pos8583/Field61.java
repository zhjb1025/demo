package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 61域.
 * 
 * @author aps-mhc
 */
public class Field61 {
	private byte[] value;
	private String str61_1;// 批次号 n6
	private String str61_2;// 操作员号 n3
	private String str61_3;// 票据号 n6
	private String str61_4;// 卡类型 n2
	private String str61_5;// 发卡银行简称 Ans10

	public Field61(byte[] bcdValue) throws BizException {
		AssertUtils.notNull(bcdValue, "未指定域值");

		this.value = bcdValue;

	}

	/**
	 * 取批次号, 解码值第1位开始取6位.
	 * 
	 * @return
	 */
	public String get61_1() {
		if (str61_1 != null) {
			return str61_1;
		}

		final int startPos = 0;
		final int endPos = startPos + 6;
		str61_1 = new String(ArrayUtils.subarray(value, startPos, endPos));

		return str61_1;
	}

	/**
	 * 操作员号, 解码值第7位开始取3位.
	 * 
	 * @return
	 */
	public String get61_2() {
		if (str61_2 != null) {
			return str61_2;
		}
		final int startPos = 6;
		final int endPos = startPos + 3;
		str61_2 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str61_2;
	}

	/**
	 * 票据号, 解码值第10位开始取6位.
	 * 
	 * @return
	 */
	public String get61_3() {
		if (str61_3 != null) {
			return str61_3;
		}

		final int startPos = 9;
		final int endPos = startPos + 6;
		str61_3 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str61_3;
	}

	/**
	 * 卡类型, 解码值第18位开始取2位.
	 * 
	 * @return
	 */
	public String get61_4() {
		if (str61_4 != null) {
			return str61_4;
		}

		final int startPos = 17;
		final int endPos = startPos + 2;
		str61_4 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str61_4;
	}

	/**
	 * 发卡银行简称, 解码值第21位开始取10位.
	 * 
	 * @return
	 */
	public String get61_5() {
		if (str61_5 != null) {
			return str61_5;
		}

		final int startPos = 20;
		final int endPos = startPos + 10;
		str61_5 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str61_5;
	}
}
