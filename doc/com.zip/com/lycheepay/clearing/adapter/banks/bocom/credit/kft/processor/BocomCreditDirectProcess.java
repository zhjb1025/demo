package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.processor;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 交行银企信用卡交易处理
 * 
 * @author
 * @date 2012-04-13
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_DIRECT_PROCESS)
public class BocomCreditDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManager;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_CREDIT_SERVICE)
	private BocomCreditService bocomCreditService;

	/**
	 * 实时代扣
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState directDeduct(Param param) throws BizException {

		Log4jUtil.info("渠道实时代扣开始......");

		// 渠道发送流水
		String bankSendSn = sequenceManager.getBocomCreditSN();

		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);

		// 业务处理
		ReturnState returnState = bocomCreditService.dealConsume(param, bankSendSn);

		// 更新渠道流水对照表(billno_sn)
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);
		Log4jUtil.info("渠道实时代扣结束......");

		return returnState;
	}

	/**
	 * 处理结帐与签到
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public void dealSignIn(String channelId) throws BizException {

		// 渠道发送流水
		String bankSendSn = sequenceManager.getBocomCreditSN();
		// 签到
		Log4jUtil.info("交行信用卡渠道签到开始..........");
		bocomCreditService.signProcess(channelId, bankSendSn);
		Log4jUtil.info("交行信用卡渠道签到结束..........");

	}

	/**
	 * 自适应退款处理方法
	 * 
	 * @param param 业务参数实体
	 * @return
	 */
	public ReturnState autoRealRefund(Param param) throws BizException {
		String channelId = param.getChannelId();
		Log4jUtil.info("进入[" + ChannelIdEnum.BOCOM_CREDIT_CARD.getDesc() + "]" + channelId + "自适应退款处理");
		ReturnState returnState = new ReturnState();
		String bankSendSn = sequenceManager.getBocomCreditSN();
		billnoSnService.saveBillnoSn(bankSendSn, param); // bankSendSn-渠道发送银行流水
		returnState = bocomCreditService.autoRealRefund(param, bankSendSn);
		returnState.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_REFUND);
		AssertUtils.notNull(returnState, "返回给基础平台的returnState不能为NULL");
		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);// bankSendSn-渠道发送银行流水 //
																		// returnState--各自组的返回给基础平台的
		Log4jUtil.info(ChannelIdEnum.BOCOM_CREDIT_CARD.getDesc() + " 自适应退款结束......");
		return returnState;
	}

}
