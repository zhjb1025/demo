//package com.lycheepay.clearing.adapter.banks.bocom.corp.bank.util;
//
//import org.dom4j.Element;
//import org.dom4j.Node;
//
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Recv310207;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Recv210210;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Recv310601;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.RecvPublicHead;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send210201;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send210209;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send210210;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.ReconFileBean;
//import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
//
//
///**
// * <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
// * 
// * @author aps-zwm
// * @version 1.0
// */
//public class BocomCorpUtil {
//
//	/**
//	 * 创建实时代收付报文XML的方法
//	 * 
//	 * @param send210201
//	 * @return
//	 */
//	public String createSend210201XML(final Send210201 send210201) {
//		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
//		// 创建名称为“ap”根节点
//		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("ap");
//
//		// 获取根目录节点
//		final Element rootElement = dom4jxml.getRoot();
//
//		// 为根节点添加名称为“head”的子节点，其他以此类推
//		final Element HeadElement = dom4jxml.addNode(rootElement, "head", "");
//		dom4jxml.addNode(HeadElement, "tr_code", send210201.getTr_code());
//		dom4jxml.addNode(HeadElement, "corp_no", send210201.getCorp_no());
//		dom4jxml.addNode(HeadElement, "user_no", send210201.getUser_no());
//		dom4jxml.addNode(HeadElement, "req_no", send210201.getReq_no());
//		dom4jxml.addNode(HeadElement, "tr_acdt", send210201.getTr_acdt());
//		dom4jxml.addNode(HeadElement, "tr_time", send210201.getTr_time());
//		dom4jxml.addNode(HeadElement, "atom_tr_count", send210201.getAtom_tr_count());
//		dom4jxml.addNode(HeadElement, "channel", send210201.getChannel());
//		dom4jxml.addNode(HeadElement, "reserved", send210201.getReserved());
//
//		// 为根节点添加名称为“body”的子节点，其他以此类推
//		final Element BodyElement = dom4jxml.addNode(rootElement, "body", "");
//		dom4jxml.addNode(BodyElement, "pay_acno", send210201.getPay_acno());
//		dom4jxml.addNode(BodyElement, "pay_acname", send210201.getPay_acname());
//		dom4jxml.addNode(BodyElement, "rcv_bank_name", send210201.getRcv_bank_name());
//		dom4jxml.addNode(BodyElement, "rcv_acno", send210201.getRcv_acno());
//		dom4jxml.addNode(BodyElement, "rcv_acname", send210201.getRcv_acname());
//		dom4jxml.addNode(BodyElement, "rcv_exg_code", send210201.getRcv_exg_code());
//		dom4jxml.addNode(BodyElement, "rcv_bank_no", send210201.getRcv_bank_no());
//		dom4jxml.addNode(BodyElement, "cur_code", send210201.getCur_code());
//		dom4jxml.addNode(BodyElement, "amt", send210201.getAmt());
//		dom4jxml.addNode(BodyElement, "cert_no", send210201.getCert_no());
//		dom4jxml.addNode(BodyElement, "summary", send210201.getSummary());
//		dom4jxml.addNode(BodyElement, "bank_flag", send210201.getBank_flag());
//		dom4jxml.addNode(BodyElement, "area_flag", send210201.getArea_flag());
//		return dom4jxml.toString();
//	}
//
//	/**
//	 * 创建对账报文的XML的方法
//	 * 
//	 * @param send310301
//	 * @return
//	 */
//	public String createSend310301XML(final ReconFileBean send310301) {
//		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
//		// 创建名称为“ap”根节点
//		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("ap");
//
//		// 获取根目录节点
//		final Element rootElement = dom4jxml.getRoot();
//
//		// 为根节点添加名称为“head”的子节点，其他以此类推
//		final Element HeadElement = dom4jxml.addNode(rootElement, "head", "");
//		dom4jxml.addNode(HeadElement, "tr_code", send310301.getTr_code());
//		dom4jxml.addNode(HeadElement, "corp_no", send310301.getCorp_no());
//		dom4jxml.addNode(HeadElement, "user_no", send310301.getUser_no());
//		dom4jxml.addNode(HeadElement, "req_no", send310301.getReq_no());
//		dom4jxml.addNode(HeadElement, "tr_acdt", send310301.getTr_acdt());
//		dom4jxml.addNode(HeadElement, "tr_time", send310301.getTr_time());
//		dom4jxml.addNode(HeadElement, "atom_tr_count", send310301.getAtom_tr_count());
//		dom4jxml.addNode(HeadElement, "channel", send310301.getChannel());
//		dom4jxml.addNode(HeadElement, "reserved", send310301.getReserved());
//
//		// 为根节点添加名称为“body”的子节点，其他以此类推
//		final Element BodyElement = dom4jxml.addNode(rootElement, "body", "");
//		dom4jxml.addNode(BodyElement, "acno", send310301.getAcno());
//		return dom4jxml.toString();
//	}
//
//	/**
//	 * 创建批量代收报文的XML的方法
//	 * 
//	 * @param send210209
//	 * @return
//	 */
//	public String createSend210209XML(final Send210209 send210209) {
//		Dom4jXMLMessage dom4jXMLMessage = new Dom4jXMLMessage();
//
//		// 创建名称为“ap”根节点
//		dom4jXMLMessage = Dom4jXMLMessage.createDom4jXMLMessage("ap");
//
//		// 获取根目录节点
//		final Element rootElement = dom4jXMLMessage.getRoot();
//
//		// 为根节点添加名称为“head”的子节点，其他以此类推
//		final Element headElement = dom4jXMLMessage.addNode(rootElement, "head", "");
//		dom4jXMLMessage.addNode(headElement, "tr_code", send210209.getTr_code());
//		dom4jXMLMessage.addNode(headElement, "corp_no", send210209.getCorp_no());
//		dom4jXMLMessage.addNode(headElement, "user_no", send210209.getUser_no());
//		dom4jXMLMessage.addNode(headElement, "req_no", send210209.getReq_no());
//		dom4jXMLMessage.addNode(headElement, "tr_acdt", send210209.getTr_acdt());
//		dom4jXMLMessage.addNode(headElement, "tr_time", send210209.getTr_time());
//		dom4jXMLMessage.addNode(headElement, "atom_tr_count", send210209.getAtom_tr_count());
//		dom4jXMLMessage.addNode(headElement, "channel", send210209.getChannel());
//		dom4jXMLMessage.addNode(headElement, "reserved", "");
//
//		// 为根节点添加名称为“body”的子节点，其他以此类推
//		final Element bodyElement = dom4jXMLMessage.addNode(rootElement, "body", "");
//		dom4jXMLMessage.addNode(bodyElement, "dealNo", send210209.getDealNo());
//		dom4jXMLMessage.addNode(bodyElement, "recAccNo", send210209.getRecAccNo());
//		dom4jXMLMessage.addNode(bodyElement, "recAccName", send210209.getRecAccName());
//		dom4jXMLMessage.addNode(bodyElement, "totalNum", send210209.getTotalNum());
//		dom4jXMLMessage.addNode(bodyElement, "batchSum", send210209.getBatchSum());
//		dom4jXMLMessage.addNode(bodyElement, "offset", send210209.getOffset());
//		dom4jXMLMessage.addNode(bodyElement, "totalAmt", send210209.getTotalAmt());
//		dom4jXMLMessage.addNode(bodyElement, "batchSumAmt", send210209.getBatchSumAmt());
//		dom4jXMLMessage.addNode(bodyElement, "summary", send210209.getSummary());
//		dom4jXMLMessage.addNode(bodyElement, "reqReserved1", send210209.getReqReserved1());
//		dom4jXMLMessage.addNode(bodyElement, "reqReserved2", send210209.getReqReserved2());
//		dom4jXMLMessage.addNode(bodyElement, "serialNo", send210209.getSerialNo());
//		dom4jXMLMessage.addNode(bodyElement, "payAccNo", send210209.getPayAccNo());
//		dom4jXMLMessage.addNode(bodyElement, "payAccName", send210209.getPayAccName());
//		dom4jXMLMessage.addNode(bodyElement, "tranAmt", send210209.getTranAmt());
//		dom4jXMLMessage.addNode(bodyElement, "purpose", send210209.getPurpose());
//		dom4jXMLMessage.addNode(bodyElement, "contractNo", send210209.getContractNo());
//		dom4jXMLMessage.addNode(bodyElement, "rem", send210209.getRem());
//
//		return dom4jXMLMessage.toString();
//	}
//
//	/**
//	 * 创建批量代收报文的XML的方法
//	 * 
//	 * @param send210209
//	 * @return
//	 */
//	public String createSend210210XML(final Send210210 send210210) {
//
//		Dom4jXMLMessage dom4jXMLMessage = new Dom4jXMLMessage();
//
//		// 创建名称为“ap”的根节点
//		dom4jXMLMessage = Dom4jXMLMessage.createDom4jXMLMessage("ap");
//
//		// 获取根节点
//		final Element rootElement = dom4jXMLMessage.getRoot();
//
//		// 为根节点添加名称为“head”的子节点，其他以此类推
//		final Element headElement = dom4jXMLMessage.addNode(rootElement, "head", "");
//		dom4jXMLMessage.addNode(headElement, "tr_code", send210210.getTr_code());
//		dom4jXMLMessage.addNode(headElement, "corp_no", send210210.getCorp_no());
//		dom4jXMLMessage.addNode(headElement, "user_no", send210210.getUser_no());
//		dom4jXMLMessage.addNode(headElement, "req_no", send210210.getReq_no());
//		dom4jXMLMessage.addNode(headElement, "tr_acdt", send210210.getTr_acdt());
//		dom4jXMLMessage.addNode(headElement, "tr_time", send210210.getTr_time());
//		dom4jXMLMessage.addNode(headElement, "atom_tr_count", send210210.getAtom_tr_count());
//		dom4jXMLMessage.addNode(headElement, "channel", send210210.getChannel());
//		dom4jXMLMessage.addNode(headElement, "reserved", send210210.getReserved());
//
//		// 为根节点添加名称为“body”的子节点，其他以此类推
//		final Element bodyElement = dom4jXMLMessage.addNode(rootElement, "body", "");
//		dom4jXMLMessage.addNode(bodyElement, "dealNo", send210210.getDealNo());
//		dom4jXMLMessage.addNode(bodyElement, "pageSize", send210210.getPageSize());
//		dom4jXMLMessage.addNode(bodyElement, "beginPos", send210210.getBeginPos());
//
//		return dom4jXMLMessage.toString();
//	}
//
//	/**
//	 * 初始化代收付回执对象的方法
//	 * 
//	 * @param dom4jxml
//	 * @param recv210201
//	 */
//	public void createRecv210201(final Dom4jXMLMessage dom4jxml, final Recv310207 recv210201) {
//
//		final Node headNode = dom4jxml.getNode("/ap/head");
//		recv210201.setTr_code(dom4jxml.getNodeText(headNode, "tr_code"));
//		recv210201.setCorp_no(dom4jxml.getNodeText(headNode, "corp_no"));
//		recv210201.setReq_no(dom4jxml.getNodeText(headNode, "req_no"));
//		recv210201.setSerial_no(dom4jxml.getNodeText(headNode, "serial_no"));
//		recv210201.setAns_no(dom4jxml.getNodeText(headNode, "ans_no"));
//		recv210201.setNext_no(dom4jxml.getNodeText(headNode, "next_no"));
//		recv210201.setTr_acdt(dom4jxml.getNodeText(headNode, "tr_acdt"));
//		recv210201.setTr_time(dom4jxml.getNodeText(headNode, "tr_time"));
//		recv210201.setAns_code(dom4jxml.getNodeText(headNode, "ans_code"));
//		recv210201.setAns_info(dom4jxml.getNodeText(headNode, "ans_info"));
//		recv210201.setParticular_code(dom4jxml.getNodeText(headNode, "particular_code"));
//		recv210201.setParticular_info(dom4jxml.getNodeText(headNode, "particular_info"));
//		recv210201.setAtom_tr_count(dom4jxml.getNodeText(headNode, "atom_tr_count"));
//		recv210201.setReserved(dom4jxml.getNodeText(headNode, "reserved"));
//
//	}
//
//	/**
//	 * 初始化银企对账回执对象的方法
//	 * 
//	 * @param dom4jxml
//	 * @param recv310601
//	 */
//	public void createRecv310601(final Dom4jXMLMessage dom4jxml, final Recv310601 recv310601) {
//
//		final Node headNode = dom4jxml.getNode("/ap/head");
//		recv310601.setTr_code(dom4jxml.getNodeText(headNode, "tr_code"));
//		recv310601.setCorp_no(dom4jxml.getNodeText(headNode, "corp_no"));
//		recv310601.setReq_no(dom4jxml.getNodeText(headNode, "req_no"));
//		recv310601.setSerial_no(dom4jxml.getNodeText(headNode, "serial_no"));
//		recv310601.setAns_no(dom4jxml.getNodeText(headNode, "ans_no"));
//		recv310601.setNext_no(dom4jxml.getNodeText(headNode, "next_no"));
//		recv310601.setTr_acdt(dom4jxml.getNodeText(headNode, "tr_acdt"));
//		recv310601.setTr_time(dom4jxml.getNodeText(headNode, "tr_time"));
//		recv310601.setAns_code(dom4jxml.getNodeText(headNode, "ans_code"));
//		recv310601.setAns_info(dom4jxml.getNodeText(headNode, "ans_info"));
//		recv310601.setParticular_code(dom4jxml.getNodeText(headNode, "particular_code"));
//		recv310601.setParticular_info(dom4jxml.getNodeText(headNode, "particular_info"));
//		recv310601.setAtom_tr_count(dom4jxml.getNodeText(headNode, "atom_tr_count"));
//		recv310601.setReserved(dom4jxml.getNodeText(headNode, "reserved"));
//
//		final Node bodyNode = dom4jxml.getNode("/ap/body");
//		recv310601.setSerial_record(dom4jxml.getNodeText(bodyNode, "serial_record"));
//		recv310601.setField_num(dom4jxml.getNodeText(bodyNode, "field_num"));
//		recv310601.setRecord_num(dom4jxml.getNodeText(bodyNode, "record_num"));
//		recv310601.setFile_flag(dom4jxml.getNodeText(bodyNode, "file_flag"));
//		recv310601.setFilename(dom4jxml.getNodeText(bodyNode, "filename"));
//	}
//
//	/**
//	 * 初始化批量代收回执对象的方法
//	 * 
//	 * @param dom4jXMLMessage
//	 * @param recvBase
//	 */
//	public void createRecv210209(final Dom4jXMLMessage dom4jXMLMessage, final RecvPublicHead recvBase) {
//
//		final Node headNode = dom4jXMLMessage.getNode("/ap/head");
//		recvBase.setTr_code(dom4jXMLMessage.getNodeText(headNode, "tr_code"));
//		recvBase.setCorp_no(dom4jXMLMessage.getNodeText(headNode, "corp_no"));
//		recvBase.setReq_no(dom4jXMLMessage.getNodeText(headNode, "req_no"));
//		recvBase.setSerial_no(dom4jXMLMessage.getNodeText(headNode, "serial_no"));
//		recvBase.setAns_no(dom4jXMLMessage.getNodeText(headNode, "ans_no"));
//		recvBase.setNext_no(dom4jXMLMessage.getNodeText(headNode, "next_no"));
//		recvBase.setTr_acdt(dom4jXMLMessage.getNodeText(headNode, "tr_acdt"));
//		recvBase.setTr_time(dom4jXMLMessage.getNodeText(headNode, "tr_time"));
//		recvBase.setAns_code(dom4jXMLMessage.getNodeText(headNode, "ans_code"));
//		recvBase.setAns_info(dom4jXMLMessage.getNodeText(headNode, "ans_info"));
//		recvBase.setParticular_code(dom4jXMLMessage.getNodeText(headNode, "particular_code"));
//		recvBase.setParticular_info(dom4jXMLMessage.getNodeText(headNode, "particular_info"));
//		recvBase.setAtom_tr_count(dom4jXMLMessage.getNodeText(headNode, "atom_tr_count"));
//		recvBase.setReserved(dom4jXMLMessage.getNodeText(headNode, "reserved"));
//
//	}
//
//	/**
//	 * 初始化批量代收回执对象的方法
//	 * 
//	 * @param dom4jXMLMessage
//	 * @param recv210210
//	 */
//	public void createRecv210210(final Dom4jXMLMessage dom4jXMLMessage, final Recv210210 recv210210) {
//
//		final Node headNode = dom4jXMLMessage.getNode("/ap/head");
//		recv210210.setTr_code(dom4jXMLMessage.getNodeText(headNode, "tr_code"));
//		recv210210.setCorp_no(dom4jXMLMessage.getNodeText(headNode, "corp_no"));
//		recv210210.setReq_no(dom4jXMLMessage.getNodeText(headNode, "req_no"));
//		recv210210.setSerial_no(dom4jXMLMessage.getNodeText(headNode, "serial_no"));
//		recv210210.setAns_no(dom4jXMLMessage.getNodeText(headNode, "ans_no"));
//		recv210210.setNext_no(dom4jXMLMessage.getNodeText(headNode, "next_no"));
//		recv210210.setTr_acdt(dom4jXMLMessage.getNodeText(headNode, "tr_acdt"));
//		recv210210.setTr_time(dom4jXMLMessage.getNodeText(headNode, "tr_time"));
//		recv210210.setAns_code(dom4jXMLMessage.getNodeText(headNode, "ans_code"));
//		recv210210.setAns_info(dom4jXMLMessage.getNodeText(headNode, "ans_info"));
//		recv210210.setParticular_code(dom4jXMLMessage.getNodeText(headNode, "particular_code"));
//		recv210210.setParticular_info(dom4jXMLMessage.getNodeText(headNode, "particular_info"));
//		recv210210.setAtom_tr_count(dom4jXMLMessage.getNodeText(headNode, "atom_tr_count"));
//		recv210210.setReserved(dom4jXMLMessage.getNodeText(headNode, "reserved"));
//
//		final Node bodyNode = dom4jXMLMessage.getNode("/ap/body");
//		recv210210.setDealNo(dom4jXMLMessage.getNodeText(bodyNode, "dealNo"));
//		recv210210.setSerialRecord(dom4jXMLMessage.getNodeText(bodyNode, "serialRecord"));
//		recv210210.setFieldNum(dom4jXMLMessage.getNodeText(bodyNode, "fieldNum"));
//		recv210210.setRecordNum(dom4jXMLMessage.getNodeText(bodyNode, "recordNum"));
//		recv210210.setBeginPos(dom4jXMLMessage.getNodeText(bodyNode, "beginPos"));
//		recv210210.setDataEnd(dom4jXMLMessage.getNodeText(bodyNode, "dataEnd"));
//
//	}
//
// }
