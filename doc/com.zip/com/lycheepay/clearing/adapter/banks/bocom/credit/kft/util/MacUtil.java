package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util;

import java.util.Arrays;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgField;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgFieldType;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.pos8583.ByteUtils;
import com.lycheepay.clearing.util.Log4jUtil;


public class MacUtil {

	/**
	 * @param mainKey Mac密钥--16进制
	 * @param mac 主密钥
	 * @return 明文的Mac密钥--16进制:
	 * @throws BizException
	 */
	public static String getMacData2(String mkey, byte[] orgByteDate) throws BizException {

		Log4jUtil.info("需要算MAC值的数据为：" + LoUtils.byte2HexStr(orgByteDate));

		byte[] mackey = LoUtils.hexStr2Bytes(mkey);

		// 补为8的整数倍
		if (orgByteDate.length % 8 != 0) {
			orgByteDate = ArrayUtils.addAll(orgByteDate, new byte[8 - orgByteDate.length % 8]);
		}

		// 源数据转换成int数组
		int[] orgIntDate = new int[orgByteDate.length];
		for (int i = 0; i < orgByteDate.length; i++) {
			orgIntDate[i] = orgByteDate[i];
		}

		// 创建BLOCK数组MAB
		int[][] mabBlock = new int[orgByteDate.length / 8][8];

		// 赋值
		for (int i = 0; i < mabBlock.length; i++) {
			for (int j = 0; j < 8; j++) {
				mabBlock[i][j] = orgByteDate[i * 8 + j];
			}
		}

		// b. 对MAB，按每8个字节做异或（不管信息中的字符格式），如果最后不满8个字节，则添加“0X00”
		int[] tempBlock = new int[8];
		int[] temp = new int[8];
		byte[] resultBlock = new byte[8];

		for (int j = 0; j < mabBlock.length - 1; j++) {
			if (j == 0) {
				for (int i = 0; i < 8; i++) {
					tempBlock[i] = mabBlock[j][i];
				}
				for (int k = 0; k < 8; k++) {
					resultBlock[k] = (byte) tempBlock[k];
				}
			}

			byte[] encblock = J2DES.des_crypt(mackey, resultBlock);
			for (int k = 0; k < 8; k++) {
				temp[k] = encblock[k];
			}

			for (int i = 0; i < 8; i++) {
				tempBlock[i] = temp[i] ^ mabBlock[j + 1][i];
			}
			for (int i = 0; i < 8; i++) {
				resultBlock[i] = (byte) tempBlock[i];
			}
		}
		byte[] mac = J2DES.des_crypt(mackey, resultBlock);
		String resHexStr = LoUtils.byte2HexStr(mac);

		Log4jUtil.info("生成的mac值为：" + resHexStr);

		return resHexStr;
	}

	/**
	 * @param mainKey Mac密钥--16进制
	 * @param mac 主密钥
	 * @return 明文的Mac密钥--16进制:
	 * @throws BizException
	 */
	public static String getMacData(String mkey, byte[] orgByteDate) throws BizException {

		System.out.println("mkey:" + mkey);
		System.out.println("orgByteDate:" + Arrays.toString(orgByteDate));

		byte[] encblock = J2DES.des_crypt(mkey.getBytes(), orgByteDate);
		return new String(encblock);
	}

	/**
	 * 取终端密钥.
	 * 
	 * @param msgPack
	 * @return 0:ZPK, 1:ZPK校验值, 2:ZAK, 3:ZAK校验值
	 */
	public static String[] getKey(MsgPack msgPack) {
		Log4jUtil.info("解析工作密钥开始...");
		MsgField field = msgPack.getField(MsgFieldType.FIELD_44.getNo());

		if (field == null) {
			return null;
		}

		byte[] keyByte = field.getOrigValue();
		int length = keyByte.length;
		final int[] FIELD_LEN = new int[] { 54, 110 };

		// 错误的长度.
		if (!ArrayUtils.contains(FIELD_LEN, length)) {
			Log4jUtil.debug("密钥总长度错误:" + length);
			return null;
		}

		String workKey = new String(keyByte);

		Log4jUtil.debug("密钥值new String (keyByte):" + workKey);

		String key1Byte = workKey.substring(0, length / 2);
		String key2Byte = workKey.substring(length / 2, length);
		int keyType = Integer.parseInt(key1Byte.substring(0, 2));
		int key_len = Integer.parseInt(key1Byte.substring(2, 4));

		String zpkKeyByte = "";
		String zakKeyByte = "";
		String zpkCheckByte = "0000";
		String zakCheckByte = "0000";

		Log4jUtil.debug("密钥长度为:" + key_len);
		Log4jUtil.debug("密钥类型为:" + keyType);
		// 单倍密钥
		if (key_len == 23) {
			if (keyType == 98) {
				zpkKeyByte = key1Byte.substring(5, 21);
				zakKeyByte = key2Byte.substring(5, 21);
			} else {
				zakKeyByte = key1Byte.substring(5, 21);
				zpkKeyByte = key2Byte.substring(5, 21);
			}
		}
		// 双倍密钥
		if (key_len == 51) {
			if (keyType == 98) {
				zpkKeyByte = key1Byte.substring(5, 37);
				zakKeyByte = key2Byte.substring(5, 37);
				zpkCheckByte = key1Byte.substring(39, 55);
				zakCheckByte = key2Byte.substring(39, 55);
			} else {
				zakKeyByte = key1Byte.substring(5, 37);
				zpkKeyByte = key2Byte.substring(5, 37);
				zakCheckByte = key1Byte.substring(39, 55);
				zpkCheckByte = key2Byte.substring(39, 55);
			}
		}
		Log4jUtil.info("PIN密钥:" + zpkKeyByte);
		Log4jUtil.info("PIN密钥验证值:" + zpkCheckByte);
		Log4jUtil.info("work密钥:" + zakKeyByte);
		Log4jUtil.info("work密钥验证值:" + zakCheckByte);
		Log4jUtil.info("解析工作密钥结束...");

		return new String[] { zpkKeyByte, zpkCheckByte, zakKeyByte, zakCheckByte };
	}

	public static String toHexString(MsgPack msgPack) throws BizException {
		return toHexString(msgPack.getBytes());
	}

	public static String toHexString(byte[] bytes) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < bytes.length; i++) {
			String hexByte = ByteUtils.toHexString(bytes[i] & 0xff, 2);
			sb.append("[").append(hexByte.toUpperCase()).append("]");
		}
		return sb.toString();
	}

	public static String toHexString(byte[] bytes, boolean hasSeparator) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < bytes.length; i++) {
			String hexByte = ByteUtils.toHexString(bytes[i] & 0xff, 2);

			if (hasSeparator) {
				sb.append("[");
			}

			sb.append(hexByte.toUpperCase());

			if (hasSeparator) {
				sb.append("]");
			}
		}
		return sb.toString();
	}

	public static void main(String[] args) throws BizException {
		byte[] a = LoUtils.hexStr2Bytes("622759119549112300000000000000040000070701563136343532313131303030313234");

		String b = getMacData("9D38BA49EC58D351", a);
		System.out.println(b.equals("452BA571655993A2"));
	}
}
