package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;


/**
 * 报文域.
 * 
 * @author aps-mhc
 */
public class MsgField implements Cloneable {
	private int contentType;
	private String no;
	private int maxLength;

	// 原始信息, 包括长度等.
	private byte[] origMsg;

	// 原始信息中值的长度数值所占的长度, 如"9个字节"中"9"的长度为1.
	// 由解析器初始化时指定并赋值到域实体, 变长域有效.
	private boolean hasLeaderLength;
	private int lenOfLeaderLength;

	// 原始信息中的值,不包括长度标识.
	private byte[] origValue;

	// 不包括长度,并且已解压解码后的值.
	private byte[] value;

	public boolean isHasLeaderLength() {
		return hasLeaderLength;
	}

	public void setHasLeaderLength(boolean hasLeaderLength) {
		this.hasLeaderLength = hasLeaderLength;
	}

	public void setOrigValue(byte[] origValue) {
		this.origValue = origValue;
	}

	public byte[] getOrigValue() {
		if (origValue != null) {
			return origValue;
		}

		// 从原始消息中获取.
		origValue = hasLeaderLength ? ArrayUtils.subarray(origMsg, lenOfLeaderLength, origMsg.length) : origMsg;

		return origValue;
	}

	public int getContentType() {
		return contentType;
	}

	public void setContentType(int contentType) {
		this.contentType = contentType;
	}

	/**
	 * 原信息中内容的约定长度, 定长域时为最大长度, 变长域时由前导的长度标识计算得出.
	 * 
	 * @return
	 */
	private int getLeaderLengthValue() {
		// 没有前导长度标识, 表明为定长域, 返回最大长度.
		if (!hasLeaderLength) {
			return maxLength;
		}

		// 原始信息不够指定的前导长度时无法计算出值的长度, 一般在原信息不足前导长度时不会调用此方法.
		if (origMsg == null || origMsg.length < lenOfLeaderLength) {
			return 0;
		}

		byte[] lenByte = ArrayUtils.subarray(origMsg, 0, lenOfLeaderLength);

		return ByteUtils.bcdToInt(lenByte);
	}

	public int getLenOfLeaderLength() {
		return lenOfLeaderLength;
	}

	public void setLenOfLeaderLength(int leaderLength) {
		this.lenOfLeaderLength = leaderLength;
	}

	public int getOrigMsgLength() {
		return origMsg == null ? 0 : origMsg.length;
	}

	public byte[] getOrigMsg() {
		return origMsg;
	}

	/**
	 * 设置原始消息,同时置空origValue和value
	 * 
	 * @param origMsg
	 */
	public void setOrigMsg(byte[] origMsg) {
		this.origMsg = origMsg;
		this.origValue = null;
		this.value = null;
	}

	public int getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String name) {
		this.no = name;
	}

	public String getStringValue() {
		return new String(getValue());
	}

	public int getIntValue() {
		return Integer.parseInt(getStringValue());
	}

	public long getLongValue() {
		return Long.parseLong(getStringValue());
	}

	public Double getDoubleValue() {
		return Double.parseDouble(getStringValue());
	}

	private byte[] getValue() {
		if (value == null) {
			setValueFromOrigValue();
		}

		return value;
	}

	private void setValueFromOrigValue() {
		if (IsoType.ASCII == contentType || IsoType.BINARY == contentType) {
			value = getOrigValue();
		} else if (IsoType.BCD == contentType) {
			value = ByteUtils.bcdToStr(getOrigValue()).getBytes();
		}
	}

	/**
	 * 取去除长度后域内容约定的长度.
	 * 
	 * @return
	 */
	public int getShouldOrigValueLength() {
		int leaderLengthValue = getLeaderLengthValue();
		int contentType = getContentType();

		// bcd编码,leaderLengthValue表示的是明文长度,需/2取bcd编码的长度.
		if (IsoType.BCD == contentType) {
			// 偶数取一半,奇数取+1后的一半.
			return (leaderLengthValue + 1) / 2;
		}
		// 其他编码形式直接返回前导长度的值.
		else {
			return leaderLengthValue;
		}
	}

	public void setValue(byte[] value) {
		this.value = value;
	}

	public static MsgField create(String no) {
		MsgFieldType type = MsgFieldType.ALL.get(no);
		MsgField field = new MsgField();
		field.setNo(type.getNo());
		field.setMaxLength(type.getMaxLength());
		field.setContentType(type.getContentType());
		return field;
	}

	@Override
	public MsgField clone() {
		MsgField result = new MsgField();
		result.contentType = this.contentType;
		result.hasLeaderLength = this.hasLeaderLength;
		result.lenOfLeaderLength = this.lenOfLeaderLength;
		result.maxLength = this.maxLength;

		result.no = this.no;
		result.origMsg = this.origMsg;
		result.origValue = this.origValue;
		result.value = this.value;
		return result;
	}
}
