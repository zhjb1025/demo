package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.processor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.bocom.credit.kft.bean.BocomCreditBean;
import com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util.BocomCreditMsgUtilService;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 交行信用卡处理服务类
 * 
 * @author 廖四发
 * 
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_SERVICE)
public class BocomCreditService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_CREDIT_MSG_UTIL_SERVICE)
	private BocomCreditMsgUtilService bocomCreditMsgUtilService;

	private final static String channelName = ChannelIdEnum.BOCOM_CREDIT_CARD.getDesc();

	/**
	 * 签到
	 * 
	 * @param param
	 * @throws BizException
	 */
	public void signProcess(String channelId, String bankSendSn) throws BizException {

		// 创建和发送报文
		MsgPack signMsgPack = bocomCreditMsgUtilService.createSign(bankSendSn);
		MsgPack retMsgPack = bocomCreditMsgUtilService.sendMsg(signMsgPack);

		// 获取应答码
		String rspCode = retMsgPack.getFieldContent39();
		Log4jUtil.info("签到返回码：" + rspCode);
		ChannelParm channelParm = new ChannelParm();
		Date sysdate = new Date();
		// 重复签到默认也是正常的签到
		if ("00".equals(rspCode)) {
			Log4jUtil.info("交行信用卡联机签到报文持久化开始-->>");
			ChannelParmId channelParmId = new ChannelParmId(ChannelIdEnum.BOCOM_CREDIT_CARD.getCode(), "100015");
			channelParm.setId(channelParmId);
			channelParm.setParname("交行信用卡签到标志 1- 已签 0-未签");
			channelParm.setIfmodify("Y");
			channelParm.setParvalue("1");
			channelParm.setUsercode("");
			channelParm.setUpdatetime(sysdate);
			channelParm.setRemark("交行信用卡签到");
			saveChannelParm(channelParm);

			channelParmId = new ChannelParmId(ChannelIdEnum.BOCOM_CREDIT_CARD.getCode(), "100009");
			channelParm.setId(channelParmId);
			channelParm.setParname("交行信用卡批次号");
			channelParm.setParvalue(retMsgPack.getFieldContent11());
			channelParm.setUpdatetime(sysdate);
			channelParm.setRemark("交行信用卡，签到报文批次流水号");
			saveChannelParm(channelParm);

			Log4jUtil.info("交行信用卡联机签到报文持久化结束--<<");
		} else {
			throw new BizException(TransReturnCode.code_9109, channelId + ":" + channelName + "签到失败,,返回码是：" + rspCode);
		}
	}

	public void saveChannelParm(ChannelParm newChannelParm) {
		Object o = channelParmService.queryByPrimaryKey(newChannelParm.getId());
		if (null == o) {
			channelParmService.save(newChannelParm);
		} else {
			ChannelParm orgChannelParm = (ChannelParm) o;
			orgChannelParm.setParvalue(newChannelParm.getParvalue());
			channelParmService.update(orgChannelParm);
		}
	}

	/**
	 * 交行信用卡消费
	 * 
	 * @param param
	 * @param bankSendSn 渠道流水
	 * @return ReturnState
	 * @throws BizException
	 */
	public ReturnState dealConsume(Param param, String bankSendSn) throws BizException {
		String channelId = param.getChannelId();
		// 渠道公共参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		if (channelParms == null) {
			throw new BizException(TransReturnCode.code_9108, "渠道channelParm不能为空");
		}
		String batchNo = channelParms.get("100009");
		if (StringUtils.isBlank(batchNo)) {
			throw new BizException(TransReturnCode.code_9108, "渠道channelParm中的batchNo不能为空");
		}

		ReturnState returnState = new ReturnState();
		MsgPack consumeMsgPack = null;// 消费包
		MsgPack retConsumeMsgPack = null;// 消费返回包
		// 创建消费并发送,发送超时，则发消费冲正，并返回失败信息
		try {
			consumeMsgPack = bocomCreditMsgUtilService.createConsume(param, bankSendSn, channelParms);
			retConsumeMsgPack = bocomCreditMsgUtilService.sendMsg(consumeMsgPack);

		} catch (BizException e) {
			if (TransReturnCode.code_9109.equals(e.getErrorCode())) {
				return this.createFinishRush(param.getChannelId(), consumeMsgPack, retConsumeMsgPack, e, bankSendSn,
						channelParms);// 发送冲正报文
			} else {
				throw new BizException(e, e.getErrorCode(), "消费报文发送错误 :" + e.getMessage());
			}
		}

		// 返回码为Z1 表示未签到
		if ("Z1".equals(retConsumeMsgPack.getFieldContent39())) {
			Log4jUtil.info("消费发送返回Z1需先签到开始......");
			this.signProcess(channelId, bankSendSn);
			Log4jUtil.info("消费发送返回Z1需先签到结束......");
			try {
				// 重新签到后需要再查询一次channelParam获取签到后的batchNo
				channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
				consumeMsgPack = bocomCreditMsgUtilService.createConsume(param, bankSendSn, channelParms);
				Log4jUtil.info("消费发送返回Z1,再次发送消费交易报文开始......");
				retConsumeMsgPack = bocomCreditMsgUtilService.sendMsg(consumeMsgPack);
				Log4jUtil.info("消费发送返回Z1,再次发送消费交易报文结束......");
			} catch (BizException ex) {
				if (TransReturnCode.code_9109.equals(ex.getErrorCode())) {
					return this.createFinishRush(param.getChannelId(), consumeMsgPack, retConsumeMsgPack, ex,
							bankSendSn, channelParms);// 发送冲正报文
				} else {
					throw new BizException(ex, ex.getErrorCode(), "消费报文发送错误  " + ex.getMessage());
				}
			}
		}
		// 银行返回结果代码
		String respCode39 = retConsumeMsgPack.getFieldContent39();
		returnState.setBankRetCode(respCode39);

		// 设置交易结果
		this.setChannelReturnCodeAndMsg(respCode39, returnState, channelId);

		returnState.setCardType(param.getCardType()); // 卡类型
		returnState.setCreditNo(retConsumeMsgPack.getFieldContent38() + batchNo);// 授权码+批次号
		returnState.setBankRetBatchId(batchNo);// 当前批次号
		returnState.setCheckDate(DateUtil.getCurrentDate());
		return returnState;
	}

	/**
	 * 
	 * @param param 基础平台传来的参数表
	 * @param bankSendSn 发往银行的流水
	 * @return
	 * @throws BizException
	 */
	public ReturnState autoRealRefund(Param param, String bankSendSn) throws BizException {

		String channelId = param.getChannelId();
		// 渠道公共参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		if (channelParms == null) {
			throw new BizException(TransReturnCode.code_9108, "渠道channelParm不能为空");
		}
		String currentBattchNo = channelParms.get("100009");
		if (StringUtils.isBlank(currentBattchNo)) {
			throw new BizException(TransReturnCode.code_9108, "渠道channelParm中的batchNo不能为空");
		}

		MsgPack retRefundPack = new MsgPack(); // 返回的自适应退款包
		AutoRealTimeRefund autoRealTimeRefund = channelTransUtilService.getAutoRealTimeRefund(param);
		AssertUtils.notNull(autoRealTimeRefund.getOrgPaySn(), "原交易流水不能为空");
		BillnoSn orgBillnoSn = billnoSnService.getBySn(autoRealTimeRefund.getOrgPaySn());
		if (orgBillnoSn == null) {
			throw new BizException(TransReturnCode.code_9108, "原交易流水不存在");
		}
		String orgBatchNo = orgBillnoSn.getCreditbatchno();

		Log4jUtil.info("billnoSn.getRecvTime() = " + orgBillnoSn.getRecvTime());
		String recvDate = "";
		try {
			recvDate = new SimpleDateFormat("MMddHHmmss").format(orgBillnoSn.getRecvTime());
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "日期格式转化错误");
		}

		BocomCreditBean bocomCredit = new BocomCreditBean();
		String sn = sequenceManagerService.getBocomCreditSN();
		bocomCredit.setBankSendSn(sn);
		bocomCredit.setAmount(autoRealTimeRefund.getRefundAmount());
		bocomCredit.setBatchNo(orgBatchNo);
		bocomCredit.setAcctNo(autoRealTimeRefund.getRevBankCardNo());
		bocomCredit.setValidDate(autoRealTimeRefund.getExpdate());
		bocomCredit.setBankDate(recvDate);
		bocomCredit.setOrgBankSendSn(orgBillnoSn.getBankSendSn());

		Log4jUtil.info("原交易批次号：" + orgBatchNo + "; 当前批次号：" + currentBattchNo);
		// 当天当批次同一个终端才允许退款
		if (currentBattchNo.equals(orgBatchNo)
				&& autoRealTimeRefund.getRefundAmount().compareTo(orgBillnoSn.getAmount()) == 0
				&& DateUtil.getCurrentDate().equals(new SimpleDateFormat("yyyyMMdd").format(orgBillnoSn.getRecvTime()))) {
			// 发送撤销报文
			Log4jUtil.info(">>>>>>>>>>>>> 开始发送撤销报文 <<<<<<<<<<<<<");
			retRefundPack = bocomCreditMsgUtilService.sendMsg(bocomCreditMsgUtilService.createCancel(bocomCredit,
					channelParms));
		} else {
			Log4jUtil.info(">>>>>>>>>>>>> 开始发送退货报文  <<<<<<<<<<<<<");
			retRefundPack = bocomCreditMsgUtilService.sendMsg(bocomCreditMsgUtilService.createReturn(bocomCredit,
					channelParms));

		}
		// 交易结果代码
		String respCode39 = retRefundPack.getFieldContent39();
		ReturnState rs = new ReturnState();
		rs.setBankRetCode(respCode39);
		// 设置交易结果
		this.setChannelReturnCodeAndMsg(respCode39, rs, channelId);

		rs.setCreditNo(retRefundPack.getFieldContent38() + currentBattchNo);// 授权码+批次号
		rs.setBankRetBatchId(currentBattchNo);// 当前批次号
		rs.setCheckDate(DateUtil.getCurrentDate());

		return rs;
	}

	public ReturnState createFinishRush(String channelId, MsgPack msgPack, MsgPack retMsgPack, BizException e,
			String bankSendSn, Map<String, String> channelParms) throws BizException {
		Log4jUtil.info("原交易流水：" + bankSendSn);
		ReturnState rs = new ReturnState();
		rs.setChannelCode(TransReturnCode.code_9109);
		rs.setReturnState(PayState.FAILED_STR);
		try {
			MsgPack rushMsgPack = bocomCreditMsgUtilService.sendMsg(bocomCreditMsgUtilService.createFinishRush(
					retMsgPack, msgPack, channelParms));// 消费冲正
			Log4jUtil.info("冲正结果 ：" + rushMsgPack.getFieldContent39());
		} catch (BizException e1) {
			throw new BizException(e1, TransReturnCode.code_9109, "冲正发送出错,渠道流水号：" + bankSendSn + "错误信息："
					+ e1.getMessage());
		}
		return channelTransUtilService.makeReturnState(channelId, bankSendSn, e.getMessage(), e.getErrorCode());

	}

	/**
	 * 
	 * <p>解析银行返回结果，并返回渠道的交易结果</p>
	 * 
	 * @param bankRespCode 银行响应结果
	 * @param returnState
	 * @return
	 * @author 廖四发（13554889794）
	 */
	private ReturnState setChannelReturnCodeAndMsg(String bankRespCode, ReturnState returnState, String channelId) {

		if (StringUtils.isNotEmpty(bankRespCode)) {
			ChannelRtncode channelRtncode = channelRtncodeService
					.findById(new ChannelRtncodeId(channelId, bankRespCode));
			Log4jUtil.info("channelRtncode = " + channelRtncode);
			if (channelRtncode != null) { // 获取银行返回信息
				returnState.setReturnMsg(channelRtncode.getChannelReamrk());
				returnState.setChannelCode(channelRtncode.getKftRtncode());
			} else {
				returnState.setReturnMsg("交易失败，银行返回码：" + bankRespCode);
				returnState.setChannelCode(TransReturnCode.code_9109);
			}
		} else {
			// returnState.setReturnState(PayState.FAILED_STR);// 银行返回失败
			returnState.setReturnMsg("交易未知，银行返回码为空！");
			returnState.setChannelCode(TransReturnCode.code_9109);
		}

		if (TransReturnCode.code_0000.equals(returnState.getChannelCode()))
			returnState.setReturnState(PayState.SUCCEED_STR);// 银行返回成功
		else if (TransReturnCode.code_9109.equals(returnState.getChannelCode()))
			returnState.setReturnState(PayState.UNKNOW_STR);// 银行返回未知
		else
			returnState.setReturnState(PayState.FAILED_STR);// 银行返回失败
		return returnState;

	}
}
