package com.lycheepay.clearing.adapter.banks.bocom.creditQP.constant;

public class Constant {
	
	/**
	 * 基础参数
	 */
	public final static String CHARSET = "UTF-8";
	public final static String VERSION = "1.0";
	public final static String MER_NO = "100001";
	public final static String TERM_NO = "100002";
	public final static String MER_NM = "100003";
	
	public final static String BNK_PUB_PATH = "100004";	//银行公钥路径
	public final static String KFT_PRI_PATH = "100005";	//快付通私钥路径
	public final static String KFT_PRI_PWD = "100006";	//快付通私钥密码
	public final static String TRADE_URL = "100007";	//交易请求地址
	public final static String CHECK_TIME = "100008";	//日切时间hhmmss
	public final static String PYER_ACCT_ISSR_ID = "100009";  //付款方账户所属机构标识
	public final static String PYEE_ACCT_ISSR_ID = "100010";  //收款方账户所属机构标识
	
	
	public static final String SFTP_IP_ADDRESS = "100011";  //sftp服务器地址
	
	public static final String SFTP_USER_NAME = "100012";  //sftp服务器登录名
	
	public static final String SFTP_PASSWORD = "100013";  //sftp服务器密码
	
	public static final String SFTP_POST = "100014";  //sftp服务器端口
	
	public static final String LOCAL_FILE_PATH = "100015";  //sftp下载完成后，保存的临时路径
	
	public static final String FTP_PATH_PREFIX = "100016";  //sftp路径前缀 /home/admin/ftp
	
	/**
	 * 业务类代码
	 */
	public final static String MSGID_DEDUCT = "0200";
	public final static String MSGID_CANCEL = "0400";
	public final static String MSGID_REFUND = "0220";
	public final static String TRANS_CODE_DEDUCT = "180002";
	public final static String TRANS_CODE_REFUND = "999001";
	public final static String TRANS_CODE_MSG = "999100";  //动态验证码
	public final static String TRANS_CODE_SIGN = "300009";  //签约交易代码
	
	public final static String HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	
	//证件类型    01-身份证；02-军官证；03-护照；04-户口簿；05-士兵证；06-港澳来往通行证；07-台湾同胞来往内地通行证；08-临时身份证；09-外国人居留证；10-警官证；11-营业执照；12-组织机构代码证；13-税务登记证；99-其他
	public final static String CERTIFICATE_TYPE = "11";
	
	public final static String CURRENCY = "156";
	public static final String CONSUME_TYPE = "1000";  //消费类型
	public static final String MER_TYPE = "2";  //1-法人；2-其他组织；3-个体工商户；4-自然人
	public static final String MRCHNT_CTGY = "4937";  //商户行业类别  填写4937 网络支付
	public static final String CERTIFICATE_CODE = "91440300693990413M";  //商户证件编码 : 快付通的营业执照(现在已经三证合一,包括:营业执照+组织机构代码+税务登记)
	public static final String NET_ADDRESS = "快付通";  // 网络交易平台名称  
	public static final String ADDRESS = "中国";  // 地点
	public static final String OTHERS = "其它";  // 其它
	
}