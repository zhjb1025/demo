package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;


/**
 * 字节工具.
 * 
 * @author aps-mhc
 */
public abstract class ByteUtils {
	/**
	 * 字节转为二进制数组.
	 * 
	 * @param b
	 * @return
	 */
	public static byte[] byteToBinary(byte[] b) {
		if (b == null) {
			return null;
		}

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < b.length; i++) {
			sb.append(to8BitsFromByte(b[i]));
		}

		byte[] result = new byte[sb.length()];
		for (int i = 0; i < result.length; i++) {
			result[i] = (byte) Character.getNumericValue(sb.charAt(i));
		}

		return result;
	}

	/**
	 * 二进制转字节数组,每8位二进制转一个字节.
	 * 
	 * @param b
	 * @return
	 */
	public static byte[] binaryToByte(byte[] b) {
		if (b == null || b.length % 8 != 0) {
			return null;
		}

		byte[] bytes = new byte[b.length / 8];

		for (int i = 0; i < bytes.length; i++) {
			byte[] binary8Bits = ArrayUtils.subarray(b, i * 8, 8 * (i + 1));
			bytes[i] = toByteFrom8Bits(forDigit(binary8Bits, 2));
		}

		return bytes;
	}

	/**
	 * 数字转为8位二级制字符串.
	 * 
	 * @param n
	 * @return
	 */
	public static String to8BitsFromByte(byte b) {
		b |= 256;

		String s = toBinaryString(b, 8);
		int len = s.length();

		return len == 8 ? s : s.substring(len - 8, len);
	}

	private static String toBinaryString(byte b, int size) {
		return StringUtils.leftPad(Integer.toBinaryString(b), size, '0');
	}

	public static String toHexString(int i, int size) {
		return StringUtils.leftPad(Integer.toHexString(i), size, '0');
	}

	/**
	 * 8位二进制字符转为字节.
	 * 
	 * @param s
	 * @return
	 */
	public static byte toByteFrom8Bits(String s) {
		byte b = 0;

		if (s.charAt(0) == '1') {
			s = '0' + s.substring(1);
			b = Byte.parseByte(s, 2);
			b |= 128;
		} else {
			b = Byte.parseByte(s, 2);
		}

		return b;
	}

	/**
	 * 数组形式的数组转换为字符串形式.
	 * 
	 * @param b
	 * @param radix
	 * @return
	 */
	private static String forDigit(byte[] b, int radix) {
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < b.length; i++) {
			sb.append(Character.forDigit(b[i], radix));
		}

		return sb.toString();
	}

	/*
	 * public static byte[] intToBcd(int n) { if (n < 0) { return null; } if (n == 0) { return new
	 * byte[]{0}; } StringBuffer sb = new StringBuffer(); while (n > 0) { int mod = n % 10; n = n /
	 * 10; String binary = Integer.toBinaryString(mod); binary = StringUtils.leftPad(binary, 4,
	 * "0"); sb.insert(0, binary); } return null; }
	 */

	/**
	 * @函数功能: BCD码转为16进制串
	 * @输入参数: BCD码
	 * @输出结果: 16进制串
	 */
	public static String bcdToStr(byte[] bytes) {
		StringBuffer sb = new StringBuffer(bytes.length * 2);

		for (int i = 0; i < bytes.length; i++) {
			/*
			 * byte high = (byte)((bytes[i] & 0xf0) >>> 4); byte low = (byte)(bytes[i] & 0x0f);
			 * sb.append(Integer.toHexString(high).toUpperCase());
			 * sb.append(Integer.toHexString(low).toUpperCase());
			 */

			String hexString = Integer.toHexString(bytes[i] & 0xFF).toUpperCase();
			sb.append(StringUtils.leftPad(hexString, 2, '0'));
		}
		return sb.toString();
	}

	public static int bcdToInt(byte[] bytes) {
		return Integer.parseInt(bcdToStr(bytes));
	}

	/**
	 * 左靠=右补0
	 */
	public static byte[] intToBcdLeftSide(int i) {
		return strToBcdLeftSide(String.valueOf(i));
	}

	/**
	 * 右靠=左补0
	 */
	public static byte[] intToBcdRightSide(int i) {
		return strToBcdRightSide(String.valueOf(i));
	}

	/**
	 * 左靠,右补0
	 * 
	 * @函数功能: 10进制串转为BCD码,右补0.
	 * @输入参数: 10进制串
	 * @输出结果: BCD码
	 */
	public static byte[] strToBcdLeftSide(String asc) {
		if (asc.length() % 2 != 0) {
			asc += "0";
		}

		return strToBcd(asc);
	}

	/**
	 * 右靠,左补0
	 * 
	 * @函数功能: 10进制串转为BCD码,左补0.
	 * @输入参数: 10进制串
	 * @输出结果: BCD码
	 */
	public static byte[] strToBcdRightSide(String asc) {
		if (asc.length() % 2 != 0) {
			asc = "0" + asc;
		}

		return strToBcd(asc);
	}

	/**
	 * @函数功能: 10进制串转为BCD码
	 * @输入参数: 10进制串
	 * @输出结果: BCD码
	 */
	public static byte[] strToBcd(String asc) {
		int len = asc.length();

		if (len >= 2) {
			len = len / 2;
		}

		byte bbt[] = new byte[len];
		byte abt[] = asc.getBytes();

		for (int p = 0; p < asc.length() / 2; p++) {
			byte firstByte = abt[2 * p];
			byte secondByte = abt[2 * p + 1];

			int j = getIntValueFromAsc(firstByte);
			int k = getIntValueFromAsc(secondByte);

			int a = (j << 4) + k;
			bbt[p] = (byte) a;
		}
		return bbt;
	}

	private static int getIntValueFromAsc(byte asc) {
		if ((asc >= '0') && (asc <= '9')) {
			return asc - '0';
		}

		if ((asc >= 'a') && (asc <= 'z')) {
			return asc - 'a' + 0x0a;
		}

		return asc - 'A' + 0x0a;
	}

	/**
	 * 根据字节长度右补空格.
	 * 
	 * @param value
	 * @param size 补空格后的总字节长度.
	 * @return
	 */
	public static String rightPadSpaceByByte(String value, int size) {
		if (value == null) {
			return null;
		}

		int valueByteSize = value.getBytes().length;

		if (size <= valueByteSize) {
			return value;
		}

		int diffSize = size - valueByteSize;
		String diffSpace = StringUtils.rightPad(" ", diffSize);

		return value.concat(diffSpace);
	}

	public static byte[] shortToByteArray(short s) {
		byte[] shortBuf = new byte[2];
		for (int i = 0; i < 2; i++) {
			int offset = (shortBuf.length - 1 - i) * 8;
			shortBuf[i] = (byte) ((s >>> offset) & 0xff);
		}
		return shortBuf;
	}

	public static final int byteArrayToShort(byte[] b) {
		return (b[0] << 8) + (b[1] & 0xFF);
	}

	public static byte[] intToByteArray(int value) {
		byte[] b = new byte[4];
		for (int i = 0; i < 4; i++) {
			int offset = (b.length - 1 - i) * 8;
			b[i] = (byte) ((value >>> offset) & 0xFF);
		}
		return b;
	}

	public static final int byteArrayToInt(byte[] b) {
		return (b[0] << 24) + ((b[1] & 0xFF) << 16) + ((b[2] & 0xFF) << 8) + (b[3] & 0xFF);
	}

	public static String dec2Hex(int dec) {
		StringBuffer sb = new StringBuffer();
		sb.append("0x");

		for (int i = 0; i < 8; i++) {
			int tmp = (dec >> (7 - i % 8) * 4) & 0x0f;

			if (tmp < 10) {
				sb.append(tmp);
			} else {
				sb.append((char) ('A' + (tmp - 10)));
			}
		}

		return sb.toString();
	}

}
