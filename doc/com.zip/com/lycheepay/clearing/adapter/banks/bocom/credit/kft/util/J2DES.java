package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.common.constant.TransReturnCode;


/**
 * 双倍长密钥算法
 * 
 * @author aps-txy
 * @date 2011-11-1
 */
public class J2DES {

	static String DES = "DES/ECB/NoPadding";
	static String TriDes = "DESede/ECB/NoPadding";

	public static byte[] des_crypt(byte key[], byte data[]) throws BizException {

		try {
			KeySpec ks = new DESKeySpec(key);
			SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
			SecretKey ky = kf.generateSecret(ks);

			Cipher c = Cipher.getInstance(DES);
			c.init(Cipher.ENCRYPT_MODE, ky);
			return c.doFinal(data);
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "DES数据加密错误");
		}
	}

	public static byte[] des_decrypt(byte key[], byte data[]) throws BizException {

		try {
			KeySpec ks = new DESKeySpec(key);
			SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
			SecretKey ky = kf.generateSecret(ks);

			Cipher c = Cipher.getInstance(DES);
			c.init(Cipher.DECRYPT_MODE, ky);
			return c.doFinal(data);
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "DES数据加密错误");
		}
	}

	/**
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 * @throws BizException
	 */
	public static byte[] trides_crypt(byte key[], byte data[]) throws BizException {
		try {
			byte[] k = new byte[24];

			int len = data.length;
			if (data.length % 8 != 0) {
				len = data.length - data.length % 8 + 8;
			}
			byte[] needData = null;
			if (len != 0) {
				needData = new byte[len];
			}
			for (int i = 0; i < len; i++) {
				needData[i] = 0x00;
			}

			System.arraycopy(data, 0, needData, 0, data.length);

			if (key.length == 16) {
				System.arraycopy(key, 0, k, 0, key.length);
				System.arraycopy(key, 0, k, 16, 8);
			} else {
				System.arraycopy(key, 0, k, 0, 24);
			}

			KeySpec ks = new DESedeKeySpec(k);
			SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");
			SecretKey ky = kf.generateSecret(ks);

			Cipher c = Cipher.getInstance(TriDes);
			c.init(Cipher.ENCRYPT_MODE, ky);
			return c.doFinal(needData);
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "DES数据加密错误");
		}

	}

	/**
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 * @throws BizException
	 */
	public static byte[] trides_decrypt(byte key[], byte data[]) throws BizException {
		try {
			byte[] k = new byte[24];

			int len = data.length;
			if (data.length % 8 != 0) {
				len = data.length - data.length % 8 + 8;
			}
			byte[] needData = null;
			if (len != 0) {
				needData = new byte[len];
			}
			for (int i = 0; i < len; i++) {
				needData[i] = 0x00;
			}

			System.arraycopy(data, 0, needData, 0, data.length);

			if (key.length == 16) {
				System.arraycopy(key, 0, k, 0, key.length);
				System.arraycopy(key, 0, k, 16, 8);
			} else {
				System.arraycopy(key, 0, k, 0, 24);
			}
			KeySpec ks = new DESedeKeySpec(k);
			SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");
			SecretKey ky = kf.generateSecret(ks);

			Cipher c = Cipher.getInstance(TriDes);
			c.init(Cipher.DECRYPT_MODE, ky);
			return c.doFinal(needData);
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "DES数据加密错误");
		}

	}

	public static byte[] hexToBytes(String str) {
		if (str == null) {
			return null;
		} else if (str.length() < 2) {
			return null;
		} else {
			int len = str.length() / 2;
			byte[] buffer = new byte[len];
			for (int i = 0; i < len; i++) {
				buffer[i] = (byte) Integer.parseInt(str.substring(i * 2, i * 2 + 2), 16);
			}
			return buffer;
		}
	}

	public static void main(String[] args) throws BizException {
		
		
		byte[] b = des_crypt(LoUtils.hexStr2Bytes("FED3E075587FEC26"), LoUtils.hexStr2Bytes("F8A2022A61135EB6"));
		byte[] c = { 0x08, 0x30, 0x20, 0x38, 0x00, (byte) 0x80, 0x02, (byte) 0xf0, 0x00, 0x01, (byte) 0x91, 0x00, 0x00,
				0x14, 0x23, (byte) 0x99, 0x10, 0x44, 0x52, 0x06, 0x06, 0x00, 0x30, 0x30, 0x37, 0x30, 0x30, 0x30, 0x30,
				0x30, 0x30, 0x31, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32,
				0x38, 0x00, 0x30, (byte) 0xca, (byte) 0xd5, (byte) 0xb5, (byte) 0xa5, (byte) 0xb2, (byte) 0xe2,
				(byte) 0xca, (byte) 0xd4, (byte) 0xc9, (byte) 0xcc, (byte) 0xbb, (byte) 0xa7, 0x2d, 0x77, 0x6c, 0x20,
				0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x08, (byte) 0xcc,
				(byte) 0xc3, 0x2a, 0x21, 0x09, (byte) 0xe8, 0x1f, (byte) 0xe3 };

		// String mkey = "ABCDEFGH";
		String mac = MacUtil.getMacData2("4142434445464748", c);
		// /byte[] encblock = J2DES.des_crypt(mkey.getBytes(), c);
		System.out.println(mac);

	}
}
