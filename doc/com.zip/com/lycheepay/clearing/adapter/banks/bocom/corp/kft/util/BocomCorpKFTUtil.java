//package com.lycheepay.clearing.adapter.banks.bocom.corp.kft.util;
//
//import java.util.Date;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BocomCorpParam;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Recv210201;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Recv210210;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Recv310601;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.RecvBase;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send210201;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send210209;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send210210;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.Send310601;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.TrxCode;
//import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.util.BocomCorpUtil;
//import com.lycheepay.clearing.adapter.common.constant.biz.BankCardType;
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
//import com.lycheepay.clearing.common.model.BillnoSn;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelBatch;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
//import com.lycheepay.clearing.adapter.common.model.channel.Debit_Pay_Real;
//import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
//import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
//import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
//import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
//import com.lycheepay.clearing.adapter.common.service.channel.CallBizAdapter;
//import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
//import com.lycheepay.clearing.adapter.common.util.net.HttpClientAgent;
//import com.lycheepay.clearing.common.constant.TransReturnCode;
//import com.lycheepay.clearing.util.DateUtil;
//import com.lycheepay.clearing.util.Log4jUtil;
//import com.lycheepay.clearing.util.ObjectUtil;
//
//
///**
// * <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
// * 
// * @author aps-zwm
// * @version 1.0
// */
//public class BocomCorpKFTUtil {
//
//	@Autowired
//	private CallBizAdapter callBizAdapter;
//	// 获取查询channel返回码的DAO对象
//	private static ChannelRtncodeService channelRtncodeDao = (ChannelRtncodeService) SpringContext
//			.getService("channelRtncodeDao");
//	private static CkbProtocolDao ckbProtocolDao = (CkbProtocolDao) SpringContext.getService("ckbProtocolDao");
//	private static BillnoSnDao billnoSnDao = (BillnoSnDao) SpringContext.getService("billnoSnDao");
//
//	/**
//	 * 初始化实时代收付发送报文对象的方法
//	 * 
//	 * @param debit_Pay_Real
//	 * @param send210201
//	 * @param bocomCorpParam
//	 * @exception BizException
//	 */
//	public void setSend210201(final Debit_Pay_Real debit_Pay_Real, final Send210201 send210201,
//			final BocomCorpParam bocomCorpParam) throws BizException {
//		send210201.setTr_code(TrxCode.Transfer_Accounts); // 交易码（C6）
//		send210201.setCorp_no(bocomCorpParam.getCorp_no()); // 企业代码（C10）
//		send210201.setUser_no(bocomCorpParam.getUser_no()); // 企业用户号（C5）
//		send210201.setReq_no(SequenceManager.getBocommSN(DateUtil.getCurrentDate()));// 发起方序号（C20）
//		send210201.setTr_acdt(DateUtil.getCurrentDate());// 交易日期（N8）
//		send210201.setTr_time(DateUtil.getCurrentTime());// 时间（N6）
//		send210201.setAtom_tr_count("1");// 原子交易数（N8） 因为是实时支付所以填1
//		send210201.setChannel("0"); // 渠道标志（C1），填0
//		send210201.setReserved(""); // 保留字段（C1024）
//		send210201.setPay_acno(debit_Pay_Real.getOut_Account()); // 付款人帐号（C21）
//		send210201.setPay_acname(debit_Pay_Real.getOut_Account_Name()); // 付款人姓名（C60）
//		send210201.setRcv_bank_name(debit_Pay_Real.getIn_Bank_Name());// 收款方行名（C60）
//		send210201.setRcv_acno(debit_Pay_Real.getIn_Account()); // 收款人帐号（C32）
//		send210201.setRcv_acname(debit_Pay_Real.getIn_Account_Name()); // 收款人户名（C60）
//		send210201.setAmt(debit_Pay_Real.getAmount_String());// 金额（N14.2）
//		send210201.setBank_flag("0");// 银行标志 0：交行 1:他行
//		send210201.setCur_code("CNY");// 币种（C3） 仅限（CNY）
//		send210201.setCert_no(SequenceManager.getBocommSN(DateUtil.getCurrentDate())); // 企业凭证号码（C20）
//		send210201.setSummary("");// 附言（C60）
//		// 如果付款人银行的地区代码和收款人的地区代码匹配
//		if (debit_Pay_Real.getIn_Bank_Addr_No().equalsIgnoreCase(debit_Pay_Real.getOut_Bank_Addr_No())) {
//			send210201.setArea_flag("0"); // 同城
//		} else {
//			send210201.setArea_flag("1"); // 异地
//		}
//	}
//
//	/**
//	 * 为对账报文实体初始化的方法
//	 * 
//	 * @param send310601
//	 * @param bocomCorpParam
//	 * @throws BizException
//	 */
//	public void setSend310601(final Send310601 send310601, final BocomCorpParam bocomCorpParam, final String acno)
//			throws BizException {
//		send310601.setTr_code(TrxCode.Trans_Query); // 交易码（C6）
//		send310601.setCorp_no(bocomCorpParam.getCorp_no()); // 企业代码（C10）
//		send310601.setUser_no(bocomCorpParam.getUser_no()); // 企业用户号（C5）
//		send310601.setReq_no(SequenceManager.getBocommSN(DateUtil.getCurrentDate())); // 发起方序号（C20）
//		send310601.setTr_acdt(DateUtil.getCurrentDate());// 交易日期（N8）
//		send310601.setTr_time(DateUtil.getCurrentTime());// 时间（N6）
//		send310601.setAtom_tr_count("1");// 原子交易数（N8） 因为是实时支付所以填1
//		send310601.setChannel("0"); // 渠道标志（C1），填0
//		send310601.setReserved(""); // 保留字段（C1024）
//		send310601.setAcno(acno); // 帐号（C21） 填写的快付通这边的帐号（在银行注册的）
//	}
//
//	/**
//	 * 初始化批量代收付报文实体的方法
//	 * 
//	 * @param send210209 // 批量代收报文对象
//	 * @param bocomCorpParam // 系统参数对象
//	 * @param list_paybill // 批量交易记录列表
//	 * @param dealNo // 批次号
//	 * @param bankaccountBalance //快付通结算账户余额对象
//	 * @exception BizException
//	 */
//	public void setSend210209(final Send210209 send210209, final BocomCorpParam bocomCorpParam, final List<Paybill> list_paybill,
//			final String dealNo, final BankaccountBalance bankaccountBalance) throws BizException {
//		send210209.setTr_code(TrxCode.Trans_BatchGet); // 交易码（C6）
//		send210209.setCorp_no(bocomCorpParam.getCorp_no()); // 企业代码（C10）
//		send210209.setUser_no(bocomCorpParam.getUser_no()); // 企业用户号（C5）
//		send210209.setReq_no(SequenceManager.getBocommSN(DateUtil.getCurrentDate())); // 发起方序号（C20）
//		send210209.setTr_acdt(DateUtil.getCurrentDate());// 交易日期（N8）
//		send210209.setTr_time(DateUtil.getCurrentTime());// 时间（N6）
//		send210209.setAtom_tr_count("1");// 原子交易数（N8） 因为是实时支付所以填1
//		send210209.setChannel("0"); // 渠道标志（C1），填0
//		send210209.setReserved(""); // 预留字段（C1024）
//		send210209.setDealNo(dealNo); // 企业凭证号（C20）
//		send210209.setRecAccNo(bankaccountBalance.getAccountNo()); // 收款帐号（C21）
//		send210209.setRecAccName(bankaccountBalance.getAccountName()); // 收款帐号户名（C60）
//		send210209.setTotalNum(String.valueOf(list_paybill.size()));// 报文总笔数（N8）
//		send210209.setBatchSum(String.valueOf(list_paybill.size()));// 批次总笔数（N8）
//		send210209.setOffset("0"); // 偏移量（N8）
//		send210209.setSummary(""); // 摘要（C60）
//		send210209.setReqReserved1(""); // 保留字段（C60）
//		send210209.setReqReserved2(""); // 保留字段（C60）
//
//		// 拼装子序号
//		final StringBuilder serialNo = new StringBuilder();
//
//		// 拼装付款人帐号
//		final StringBuilder payAccNo = new StringBuilder();
//
//		// 拼装付款人户名
//		final StringBuilder payAccName = new StringBuilder();
//
//		// 拼装收款金额
//		final StringBuilder tranAmt = new StringBuilder();
//
//		double totalAmt = 0.0;
//
//		// 拼装业务类型
//		final StringBuilder purpose = new StringBuilder();
//
//		final StringBuilder contractNo = new StringBuilder();
//
//		for (int i = 0; i < list_paybill.size(); i++) {
//			serialNo.append(i + 1);
//			serialNo.append("|");
//
//			final Paybill paybill = list_paybill.get(i);
//
//			payAccNo.append(paybill.getPayerbankcardno());
//			payAccNo.append("|");
//			payAccName.append(paybill.getPayerbankcardname());
//			payAccName.append("|");
//
//			totalAmt += paybill.getChannelAmount();
//			tranAmt.append(paybill.getChannelAmount());
//			tranAmt.append("|");
//
//			purpose.append(paybill.getTranType());
//			purpose.append("|");
//
//			// 调用根据付款方客户号与银行帐号查询客户与银行的代收协议号的方法
//			final CkbProtocol ckbProtocol = ckbProtocolDao.getCkbProtocol(paybill.getPayercustId(),
//					paybill.getPayerbankcardno());
//
//			if (ckbProtocol != null && ckbProtocol.getProtocolNo() != null) {
//				contractNo.append(ckbProtocol.getProtocolNo());
//				contractNo.append("|");
//			} else {
//				Log4jUtil.info("批量代收处理时，有记录协议号是空的,此记录的付款人信息是：帐号：" +
//				// paybill.getPayerbankcardno() + "，户名是：" + paybill.getPayerbankcardname() +
//				// "，结算日期是：" + paybill.getSettledate());
//				throw new BizException("批量代收处理时，有记录协议号是空的,此记录的付款人信息是：帐号：" + paybill.getPayerbankcardno() + "，户名是："
//						+ paybill.getPayerbankcardname() + "，结算日期是：" + paybill.getSettledate());
//			}
//			// 调用保存批量代收明细流水的方法
//			saveBillnoSn(dealNo, paybill.getTranType(), paybill, i + 1, bankaccountBalance.getAccountNo(),
//					bankaccountBalance.getAccountName(), bankaccountBalance.getBankNo());
//
//		}
//
//		send210209.setSerialNo(serialNo.toString());// 子序号（N8）
//
//		send210209.setPayAccNo(payAccNo.toString());// 付款帐号（C32）
//
//		send210209.setPayAccName(payAccName.toString());// 付款帐号户名（C60）
//
//		// 因为我们发送一个批次的报文是一个整的批次，不拆分
//		send210209.setTotalAmt(String.valueOf(totalAmt));// 报文总金额（N14,2）
//
//		send210209.setBatchSumAmt(String.valueOf(totalAmt));// 批次总金额（N14,2）
//
//		send210209.setTranAmt(tranAmt.toString());// 收款金额（N14,2）
//
//		send210209.setPurpose(purpose.toString());// 业务类型（C4）
//
//		send210209.setContractNo(contractNo.toString());// 协议号（C40）
//
//		send210209.setRem("");// 备注（C60）
//	}
//
//	/**
//	 * 初始化批量代收查询对象的方法
//	 * 
//	 * @param send210210 //批量代收查询报文发送对象
//	 * @param bocomCorpParam //系统参数对象
//	 * @param dealNo // 企业凭证号
//	 * @throws BizException
//	 */
//	public void setSend210210(final Send210210 send210210, final BocomCorpParam bocomCorpParam, final String dealNo)
//			throws BizException {
//		send210210.setTr_code(TrxCode.Trans_BatchGetQuery); // 交易码（C6）
//		send210210.setCorp_no(bocomCorpParam.getCorp_no()); // 企业代码（C10）
//		send210210.setUser_no(bocomCorpParam.getUser_no()); // 企业用户号（C5）
//		send210210.setReq_no(SequenceManager.getBocommSN(DateUtil.getCurrentDate())); // 发起方序号（C20）
//		send210210.setTr_acdt(DateUtil.getCurrentDate());// 交易日期（N8）
//		send210210.setTr_time(DateUtil.getCurrentTime());// 时间（N6）
//		send210210.setAtom_tr_count("1");// 原子交易数（N8） 因为是实时支付所以填1
//		send210210.setChannel("0"); // 渠道标志（C1），填0
//		send210210.setReserved(""); // 预留字段（C1024）
//		send210210.setDealNo(dealNo); // 企业凭证号（C20）
//		send210210.setPageSize(""); // 查询笔数（N8）
//		send210210.setBeginPos(""); // 起始记录序数（N8）
//	}
//
//	/**
//	 * 创建实时代收付报文并发送，然后接受银行返回的结果的方法
//	 * 
//	 * @param bocomCorpUtil 用于报文发送和回执对象的工具类对象
//	 * @param bocomCorpParam 系统参数类对象
//	 * @param send210201 批量代收报文发送对象
//	 * @param recv210201 批量代收报文回执对象
//	 * @throws BizException
//	 */
//	public void creatAndSend210201Msg(final BocomCorpUtil bocomCorpUtil, final BocomCorpParam bocomCorpParam,
//			final Send210201 send210201, final Recv210201 recv210201) throws BizException {
//		// 创建实时代收付的XML
//		final String xml = bocomCorpUtil.createSend210201XML(send210201);
//		HttpClientAgent httpClientAgent = null;
//		try {
//			// 建立http连接，并获取连接对象
//			httpClientAgent = new HttpClientAgent(bocomCorpParam.getIp(), Integer.valueOf(bocomCorpParam.getPort()));
//
//			// 将要发送的报文添加到HTTP对象中
//			httpClientAgent.addParm("ReqData", xml);
//
//			// 发送报文
//			httpClientAgent.postUrl();
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e, TransReturnCode.code_9108.getValue(), e.getMessage());
//		}
//
//		try {
//			// 获取并解析银行回执
//			final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(httpClientAgent.getResponseBody());
//
//			// 调用初始化代收付回执对象的方法
//			bocomCorpUtil.createRecv210201(dom4jxml, recv210201);
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e);
//		}
//
//		finally {
//			if (httpClientAgent != null) {
//				// 释放http连接
//				httpClientAgent.releaseConnection();
//			}
//		}
//
//	}
//
//	/**
//	 * 创建银企对账报文并发送，然后接受回执的方法
//	 * 
//	 * @param bocomCorpUtil 用于报文发送和回执对象的工具类对象
//	 * @param bocomCorpParam 系统参数类对象
//	 * @param send310601 批量代收报文发送对象
//	 * @param recv310601 批量代收报文回执对象
//	 * @throws BizException
//	 */
//	public void creatAndSend310601Msg(final BocomCorpUtil bocomCorpUtil, final BocomCorpParam bocomCorpParam,
//			final Send310601 send310601, final Recv310601 recv310601) throws BizException {
//		// 创建银企对账的XML
//		final String xml = bocomCorpUtil.createSend310301XML(send310601);
//		HttpClientAgent httpClientAgent = null;
//		try {
//			// 建立http连接，并获取连接对象
//			httpClientAgent = new HttpClientAgent(bocomCorpParam.getIp(), Integer.valueOf(bocomCorpParam.getPort()));
//
//			// 将要发送的报文添加到HTTP对象中
//			httpClientAgent.addParm("ReqData", xml);
//
//			// 发送报文
//			httpClientAgent.postUrl();
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e, TransReturnCode.code_9108.getValue(), e.getMessage());
//		}
//
//		try {
//			// 接受银行回执并解析
//			final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(httpClientAgent.getResponseBody());
//
//			// 初始化银企对账结果对象
//			bocomCorpUtil.createRecv310601(dom4jxml, recv310601);
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e);
//		}
//
//		finally {
//			if (httpClientAgent != null) {
//				// 释放HTTP连接
//				httpClientAgent.releaseConnection();
//			}
//		}
//	}
//
//	/**
//	 * 创建并发送批量代收报文，并接收回执的方法
//	 * 
//	 * @param send210209 批量代收报文发送对象
//	 * @param recvBase 批量代收报文回执对象
//	 * @param bocomCorpUtil 用于报文发送和回执对象的工具类对象
//	 * @param bocomCorpParam 系统参数类对象
//	 * @throws BizException
//	 */
//	public void createAndSend210209Msg(final Send210209 send210209, final RecvBase recvBase,
//			final BocomCorpUtil bocomCorpUtil, final BocomCorpParam bocomCorpParam) throws BizException {
//		// 调用组建批量代收报文XML的方法
//		final String xml = bocomCorpUtil.createSend210209XML(send210209);
//		HttpClientAgent httpClientAgent = null;
//
//		try {
//			// 建立http连接，并获取连接对象
//			httpClientAgent = new HttpClientAgent(bocomCorpParam.getIp(), Integer.parseInt(bocomCorpParam.getPort()));
//
//			// 将要发送的报文添加到HTTP对象中
//			httpClientAgent.addParm("ReqData", xml);
//
//			// 发送报文
//			httpClientAgent.postUrl();
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e, TransReturnCode.code_9108.getValue(), e.getMessage());
//		}
//
//		try {
//			// 接受回执解析
//			final Dom4jXMLMessage dom4jXMLMessage = Dom4jXMLMessage.parse(httpClientAgent.getResponseBody());
//
//			// 调用初始化批量代收回执对象的方法
//			bocomCorpUtil.createRecv210209(dom4jXMLMessage, recvBase);
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e);
//		} finally {
//			if (httpClientAgent != null) {
//				// 释放http连接
//				httpClientAgent.releaseConnection();
//			}
//		}
//
//	}
//
//	/**
//	 * 创建并发送批量代收查询报文，然后接收回执的方法
//	 * 
//	 * @param send210210 批量代收查询报文发送对象
//	 * @param recv210210 批量代收查询报文回执对象
//	 * @param bocomCorpParam 系统参数对象
//	 * @param bocomCorpUtil 用于报文发送和回执对象的工具类对象
//	 * @throws BizException
//	 */
//	public void createAndSend210210Msg(final Send210210 send210210, final Recv210210 recv210210,
//			final BocomCorpParam bocomCorpParam, final BocomCorpUtil bocomCorpUtil) throws BizException {
//
//		// 调用创建批量代收查询XML的方法
//		final String xml = bocomCorpUtil.createSend210210XML(send210210);
//
//		HttpClientAgent httpClientAgent = null;
//
//		try {
//			// 建立http连接，并获取连接对象
//			httpClientAgent = new HttpClientAgent(bocomCorpParam.getIp(), Integer.parseInt(bocomCorpParam.getPort()));
//
//			// 将要发送的报文添加到HTTP对象中
//			httpClientAgent.addParm("ReqData", xml);
//
//			// 发送报文
//			httpClientAgent.postUrl();
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e, TransReturnCode.code_9108.getValue(), e.getMessage());
//		}
//
//		try {
//			// 接受回执解析
//			final Dom4jXMLMessage dom4jXMLMessage = Dom4jXMLMessage.parse(httpClientAgent.getResponseBody());
//
//			// 调用初始化批量代收查询回执对象的方法
//			bocomCorpUtil.createRecv210210(dom4jXMLMessage, recv210210);
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(e);
//		} finally {
//			if (httpClientAgent != null) {
//				// 释放http连接
//				httpClientAgent.releaseConnection();
//			}
//		}
//	}
//
//	/**
//	 * 初始化ReturnState的方法
//	 * 
//	 * @param channelId 渠道编号
//	 * @param billnoSn 交易流水对象
//	 * @param returnState
//	 * @param send210201 批量代收查询报文发送对象
//	 * @param recv210201 批量代收查询报文回执对象
//	 */
//	public void get210201ReturnState(final String channelId, final BillnoSn billnoSn, final ReturnState returnState,
//			final Send210201 send210201, final Recv210201 recv210201) {
//		returnState.setReturnState(PayState.SUCCEED_RTN);
//		returnState.setCheckDate(DateUtil.getCurrentDate());
//		ChannelRtncode channelRtncode = null;
//		channelRtncode = channelRtncodeDao.findById(new ChannelRtncodeId(channelId, recv210201.getParticular_code()));
//		if (null == channelRtncode) {
//			returnState.setChannelCode(TransReturnCode.code_3011.getValue());
//		} else {
//			returnState.setChannelCode(channelRtncode.getKftRtncode());
//		}
//		returnState.setBankRetCode(recv210201.getParticular_code());
//		returnState.setReturnMsg(recv210201.getParticular_info());
//		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
//		returnState.setSn(billnoSn.getSn());
//		returnState.setRelTranAmount(Double.valueOf(send210201.getAmt()));
//		returnState.setCardType(BankCardType.BANK_CARD_1); // 借记卡
//		returnState.setBankPostScript(recv210201.getParticular_info());
//		returnState.setCreditNo(recv210201.getSerial_no());
//	}
//
//	/**
//	 * 初始化批量代收ReturnState的方法
//	 * 
//	 * @param channelId 渠道编号
//	 * @param sn 序列号
//	 * @param returnState
//	 * @param recvBase
//	 */
//	public void get210209ReturnState(final Param param, final String snSeq, final ReturnState returnState,
//			final RecvBase recvBase) {
//		returnState.setReturnState(PayState.SUCCEED_RTN);
//		returnState.setCheckDate(recvBase.getTr_acdt());
//		ChannelRtncode channelRtncode = null;
//		channelRtncode = channelRtncodeDao.findById(new ChannelRtncodeId(param.getChannelId(), recvBase
//				.getParticular_code()));
//		if (null == channelRtncode) {
//			returnState.setChannelCode(TransReturnCode.code_3011.getValue());
//		} else {
//			returnState.setChannelCode(channelRtncode.getKftRtncode());
//		}
//		returnState.setBankRetCode(recvBase.getParticular_code());
//		returnState.setReturnMsg(recvBase.getParticular_info());
//		returnState.setBillnosnSeq(snSeq);
//		returnState.setSn(param.getSn());
//		returnState.setBankPostScript(recvBase.getParticular_info());
//		returnState.setCreditNo(recvBase.getSerial_no());
//
//	}
//
//	/**
//	 * 初始化ReturnState的方法
//	 * 
//	 * @param param 请求参数对象
//	 * @param snSeq 序列号
//	 * @param list_returnState
//	 * @param recv210210 批量代收查询回执对象
//	 * @throws BizException
//	 */
//	public void get210210ReturnState(final Param param, final String snSeq, final ChannelBatch channelBatch, final ReturnState returnState,
//			final Recv210210 recv210210, final ChannelBatchDao channelBatchDao) throws BizException {
//		Log4jUtil.setLogClass("channelLog", param.getChannelId() + "QTimer");
//
//		int totalNum = 0; // 总笔数
//		double totalAmt = 0.0; // 总金额
//		int successNum = 0; // 成功笔数
//		double successAmt = 0.0; // 成功总金额
//		int failNum = 0; // 失败笔数
//		double failAmt = 0.0; // 失败总金额
//		final String checkDate = ""; // 清算日期
//
//		if (recv210210.getFieldNum() == null || "".equals(recv210210.getFieldNum())) {
//			Log4jUtil.info("批量代收查询回执中没有字段数,该交易的批次号是：" + recv210210.getDealNo() +
//			// "，交易日期是：" + recv210210.getTr_acdt() + "，交易时间是" + recv210210.getTr_time());
//			throw new BizException("批量代收查询回执中没有字段数");
//		}
//
//		if (recv210210.getRecordNum() == null || "".equals(recv210210.getRecordNum())) {
//			Log4jUtil.info("批量代收查询回执中没有记录数,该交易的批次号是：" + recv210210.getDealNo() +
//			// "，交易日期是：" + recv210210.getTr_acdt() + "，交易时间是" + recv210210.getTr_time());
//			throw new BizException("批量代收查询回执中没有记录数");
//		}
//
//		totalNum = Integer.parseInt(recv210210.getRecordNum()) - 1;
//
//		returnState.setReturnState(PayState.SUCCEED_RTN);
//		returnState.setCheckDate(recv210210.getTr_acdt());
//		ChannelRtncode channelRtncode = null;
//		channelRtncode = channelRtncodeDao.findById(new ChannelRtncodeId(param.getChannelId(), recv210210
//				.getParticular_code()));
//		if (null == channelRtncode) {
//			returnState.setChannelCode(TransReturnCode.code_3011.getValue());
//		} else {
//			returnState.setChannelCode(channelRtncode.getKftRtncode());
//		}
//		returnState.setBankRetCode(recv210210.getParticular_code());
//		returnState.setReturnMsg(recv210210.getParticular_info());
//		returnState.setBillnosnSeq(snSeq);
//		returnState.setSn(param.getSn());
//		returnState.setBankPostScript(recv210210.getParticular_info());
//		returnState.setCreditNo(recv210210.getSerial_no());
//
//		final int step = Integer.parseInt(recv210210.getFieldNum());
//
//		if (recv210210.getSerialRecord() != null || !("".equals(recv210210.getSerialRecord()))) {
//			// 拆分发回的批量代收的明细结果
//			final String[] results = recv210210.getSerialRecord().split("\\|");
//
//			for (int i = 1; i < Integer.parseInt(recv210210.getRecordNum()); i++) {
//				final String orderChildSeq = results[i * step]; // 指令子序号
//				final String orderStatus = results[i * step + 1]; // 指令状态
//				final String payAccount = results[i * step + 2]; // 付款帐号（C32）
//				final String payAccountName = results[i * step + 3]; // 付款账号户名（C60）
//				final String getAmt = results[i * step + 4]; // 收款金额（N14.2）
//				final String contractNumber = results[i * step + 5]; // 合同号码（C40）
//				final String remark = results[i * step + 6]; // 备注（C120）
//				final String ebankSn = results[i * step + 7]; // 网银流水号（C8）
//				final String errorInfo = results[i * step + 8]; // 错误信息（C100）
//
//				if (getAmt == null || "".equals(getAmt)) {
//					Log4jUtil.info("批量代收查询回执的结果明细的收款金额为空，渠道批次：" + recv210210.getDealNo()
//					// + "明细序号：" + i);
//					throw new BizException("批量代收查询回执的结果明细的收款金额为空");
//				}
//
//				totalAmt += Double.parseDouble(getAmt);
//
//				// 调用根据渠道编号、批次号、渠道明细查询交易流水的方法（批次号就是返回企业凭证号、渠道明细就是明细的序号,因为交行和邮政储蓄这个方法的实现是一样的，所以使用同一个方法）
//				final BillnoSn billnoSn = billnoSnDao.corpPsbcBatchFindUnique(param.getChannelId(), recv210210.getDealNo(),
//						String.valueOf(i));
//
//				if (billnoSn == null) {
//					throw new BizException("在表 billnoSn 中找不到批量返回的交易记录，交易记录详细信息如下：" + "渠道ID：" + param.getChannelId()
//							+ "渠道批次：" + recv210210.getDealNo() + "明细序号：" + i);
//				}
//
//				if ("2".equals(orderStatus)) {
//					billnoSn.setChannelRtncode("0000");   // 渠道返回码
//					billnoSn.setChannelRtnnote("S-成功"); // 渠道返回附言
//
//					successNum += 1;
//					successAmt += Double.parseDouble(getAmt);
//				} else {
//					billnoSn.setChannelRtncode(TransReturnCode.code_9900);   // 渠道返回码
//					billnoSn.setChannelRtnnote("E-失败"); // 渠道返回附言
//
//					failNum += 1;
//					failAmt += Double.parseDouble(getAmt);
//				}
//				billnoSn.setActualAmount(Double.parseDouble(getAmt));
//				billnoSn.setRecvTime(new Date());
//				billnoSn.setState("02");
//				billnoSn.setCheckDate(recv210210.getTr_acdt());
//
//				billnoSnDao.update(billnoSn);
//
//				// 获取平台业务类型
//				final String tranType = billnoSn.getTranType();
//
//				if (tranType == null) {
//					Log4jUtil.info("异常，获取的业务类型为空值，此笔流水的渠道号是：" + billnoSn.getChannelid()
//					// +"，交易日期是："+ billnoSn.getTranDate() + "，交易金额是：" + billnoSn.getAmount() +
//					// "，对方帐号是：" + billnoSn.getOtheracctno() + "，对方账户名：" +
//					// billnoSn.getOtheracctname() + "，发送时间是：" + billnoSn.getSendTime());
//				}
//			}
//
//			channelBatch.setSucessnum((long) successNum);
//			channelBatch.setSucessamount(successAmt);
//			channelBatch.setUnsucessnum((long) failNum);
//			channelBatch.setUnsucessamount(failAmt);
//			channelBatch.setRecvTime(new Date());
//
//			if (channelBatch.getTotalnum().toString().equals(totalNum)) {
//				channelBatch.setState("03"); // 03：回执全部返回
//			} else if (totalNum > 0) {
//				channelBatch.setState("02"); // 02：回执部分返回
//			}
//
//			channelBatchDao.update(channelBatch);
//
//			Log4jUtil.info("____________________调用平台处理 CallBizAdapter.dealBatchQuery() start____________________");
//			CallBizAdapter.dealBatchQuery(param.getChannelId(), param.getChannelTransType(), channelBatch.getId()
//					.getChannelBatchid());
//			Log4jUtil.info("____________________调用平台处理 CallBizAdapter.dealBatchQuery() end____________________");
//
//		} else {
//			Log4jUtil.info("批量代收查询回执中没有结果明细,该交易的批次号是：" + recv210210.getDealNo() +
//			// "，交易日期是：" + recv210210.getTr_acdt() + "，交易时间是" + recv210210.getTr_time());
//		}
//
//	}
//
//	/**
//	 * 获取渠道参数的方法
//	 * 
//	 * @param logPrefix
//	 * @param type
//	 * @param channelParam
//	 * @param bocomCorpParam
//	 * @return
//	 * @throws BizException
//	 */
//	public Map<String, String> checkChannelParam(final String logPrefix, final String type,
//			final Map<String, String> channelParam, final BocomCorpParam bocomCorpParam) throws BizException {
//		String logMsg = "";
//		logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
//		Log4jUtil.info(logMsg);
//
//		// 获取银行CS的IP
//		bocomCorpParam.setIp(channelParam.get("100001"));
//
//		// 获取银行CS的端口号
//		bocomCorpParam.setPort(channelParam.get("100002"));
//
//		// 获取企业代码（银行提供）
//		bocomCorpParam.setCorp_no(channelParam.get("100003"));
//
//		// 获取企业用户号（银行提供）
//		bocomCorpParam.setUser_no(channelParam.get("100004"));
//
//		// 获取批量代收处理每次处理的最大记录数
//		bocomCorpParam.setMaxNum(channelParam.get("100005"));
//
//		logMsg = logPrefix + "对渠道参数检查结束。";
//		Log4jUtil.info(logMsg);
//		ObjectUtil.printPropertyString(logPrefix, bocomCorpParam);
//		return channelParam;
//
//	}
//
//	/**
//	 * 对于批量中的每个单笔支付交易流水，在批量交易过程中，需要保存到billno_sn（渠道交易流水对照表）表
//	 * 
//	 * @param totalReqSeqNo 渠道批次
//	 * @param tranType 业务类型
//	 * @param object 交易对象
//	 * @param i 批量明细序号
//	 * @param CorpAcctNo 企业账号
//	 * @param CorpAcctName 企业户名
//	 * @param CorpBankNo 企业行号
//	 * @throws BizException
//	 */
//	private void saveBillnoSn(final String totalReqSeqNo, final String tranType, final Object object, final int i,
//			final String CorpAcctNo, final String CorpAcctName, final String CorpBankNo) throws BizException {
//
//		String Sn = "";	// 平台业务流水，billnoSn 主键
//
//		String OtherAcctNo = "";	// 对方帐号
//		String OtherAcctName = "";	// 对方账户名
//		String OtherBankNo = "";	// 对方行号
//		String OtherCust_Id = "";	// 对方客户编号
//		String OtherBankAddrNo = "";// 对方开户行地区代码
//		String CreateTime = "";	// 交易的平台交易日期
//		String Orderid = "";	// 订单号
//		String Bank_Type = "";	// 行别
//		String SrcCust_Id = "";	// 发起方客户编号 业务发起者
//		Double DTranAmt = 0.0;	// 平台的交易金额Double类型
//
//		String BatchID = "";	// 批次号
//		String DetailID = "";	// 明细序号
//		String netNo = "";	// 支付场次
//		String channelId = "";   // 渠道编号
//
//		if (tranType.equals(TransType.Guarantee_Pay) || tranType.equals(TransType.Protocol_Debit_Batch)) {
//			// ============================paybill 收款交易============================
//			final Paybill paybill = (Paybill) object;
//			Sn = paybill.getSn();
//			if (paybill.getPayerbankcardno() != null) {
//				OtherAcctNo = paybill.getPayerbankcardno();
//			}
//			if (paybill.getPayerbankcardname() != null) {
//				OtherAcctName = paybill.getPayerbankcardname();
//			}
//			if (paybill.getPayerbankCode() != null) {
//				OtherBankNo = paybill.getPayerbankCode();
//			}
//			if (paybill.getPayercustId() != null) {
//				OtherCust_Id = paybill.getPayercustId();
//			}
//			if (paybill.getPayerbankaddrno() != null) {
//				OtherBankAddrNo = paybill.getPayerbankaddrno();
//			}
//			if (paybill.getCreateTime() != null) {
//				CreateTime = DateUtil.getDate(paybill.getCreateTime());
//			}
//			if (paybill.getOrderid() != null) {
//				Orderid = paybill.getOrderid();
//			}
//
//			if (paybill.getPayerbankType() != null) {
//				Bank_Type = paybill.getPayerbankType();
//			} else {
//				throw new BizException("字段：paybill.PayerbankType 不允许为空");
//			}
//			if (paybill.getSrccustId() != null) {
//				SrcCust_Id = paybill.getSrccustId();
//			} else {
//				throw new BizException("字段：paybill.getSrccustId 不允许为空");
//			}
//			if (paybill.getChannelAmount() != null) {
//				DTranAmt = paybill.getChannelAmount();
//			} else {
//				throw new BizException("字段：paybill.ChannelAmount 不允许为空");
//			}
//			BatchID = paybill.getBatchid();	// 批次号
//			DetailID = paybill.getDetailid();	// 明细序号
//			netNo = paybill.getNetNo();		// 支付场次
//			channelId = paybill.getChannelId(); // 渠道编号
//		} else if (tranType.equals(TransType.Protocol_Pay_Batch)) {
//			// ============================paybill 付款交易============================
//			final Paybill paybill = (Paybill) object;
//			Sn = paybill.getSn();
//			if (paybill.getPayeebankcardno() != null) {
//				OtherAcctNo = paybill.getPayeebankcardno();
//			}
//			if (paybill.getPayeebankcardname() != null) {
//				OtherAcctName = paybill.getPayeebankcardname();
//			}
//			if (paybill.getPayeebankCode() != null) {
//				OtherBankNo = paybill.getPayeebankCode();
//			}
//			if (paybill.getPayeecustId() != null) {
//				OtherCust_Id = paybill.getPayeecustId();
//			}
//			if (paybill.getPayeebankaddrno() != null) {
//				OtherBankAddrNo = paybill.getPayeebankaddrno();
//			}
//			if (paybill.getCreateTime() != null) {
//				CreateTime = DateUtil.getDate(paybill.getCreateTime());
//			}
//			if (paybill.getOrderid() != null) {
//				Orderid = paybill.getOrderid();
//			}
//
//			if (paybill.getPayeebankType() != null) {
//				Bank_Type = paybill.getPayeebankType();
//			} else {
//				throw new BizException("字段：paybill.PayeebankType 不允许为空");
//			}
//			if (paybill.getSrccustId() != null) {
//				SrcCust_Id = paybill.getSrccustId();
//			} else {
//				throw new BizException("字段：paybill.getSrccustId 不允许为空");
//			}
//			if (paybill.getChannelAmount() != null) {
//				DTranAmt = paybill.getChannelAmount();
//			} else {
//				throw new BizException("字段：paybill.ChannelAmount 不允许为空");
//			}
//			BatchID = paybill.getBatchid();	// 批次号
//			DetailID = paybill.getDetailid();	// 明细序号
//			netNo = paybill.getNetNo();		// 支付场次
//			channelId = paybill.getChannelId(); // 渠道编号
//		} else {
//			throw new BizException("异常，业务表记录的交易类型为：" + tranType + ";此类型不是批量业务类型");
//		}
//
//		// 写交易流水和渠道流水对照表
//		final BillnoSn billnoSn = new BillnoSn();
//		billnoSn.setBillnosnSeq(SequenceManager.getBillnoSnSeq());
//		billnoSn.setSn(Sn);
//		billnoSn.setChannelid(channelId);
//		billnoSn.setBankSendSn(netNo); // 银行订单号，这里填场次号
//		billnoSn.setTranDate(CreateTime);
//		billnoSn.setChannelBatchno(totalReqSeqNo);// 渠道批次 批量交易使用
//		billnoSn.setChannelDetail(SequenceUtil.formatSeq(i, 8));// 渠道明细 批量交易使用
//		billnoSn.setAmount(DTranAmt); // 平台交易金额
//		billnoSn.setTranType(tranType);
//		billnoSn.setState("00");	// 00：已发送 01: 已收到中心确认 02：业务回执已返回
//		billnoSn.setBatchid(BatchID); // 批次号 对应于原交易
//		billnoSn.setDetailid(DetailID);// 批量业务明细序号 对应于原交易
//		billnoSn.setSendTime(new Date());
//
//		billnoSn.setCorpacctno(CorpAcctNo); // 企业帐号 对应渠道绑定的帐号
//		billnoSn.setCorpacctname(CorpAcctName);// 企业户名 对应渠道绑定的帐号名
//		billnoSn.setCorpbankno(CorpBankNo);// 企业行号
//
//		billnoSn.setOtheracctno(OtherAcctNo);// 对方帐号
//		billnoSn.setOtheracctname(OtherAcctName);// 对方户名
//		billnoSn.setOtherbankno(OtherBankNo);// 对方行号
//		billnoSn.setOtherbankaddrno(OtherBankAddrNo);// 对方开户行地区代码
//		billnoSn.setOthercustId(OtherCust_Id);// 对方客户编号
//
//		billnoSn.setBankType(Bank_Type);// 行别(非空）
//		billnoSn.setSrccustId(SrcCust_Id);// 发起方客户编号
//		billnoSn.setOrderid(Orderid);// 订单号 转账交易无；打款账户验证时为账户验证流水的ID
//		try {
//			billnoSnDao.save(billnoSn);
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//		}
//	}
//
// }
