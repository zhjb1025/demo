package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 62域.
 * 
 * @author 廖四发
 */
public class Field62 {
	private final byte[] value;
	private String str62_1;// 6位批次号
	private String str62_2;// 6位票据号
	private String str62_3;// 6位原批次号
	private String str62_4;// 6位原票据号

	public Field62(byte[] bcdValue) throws BizException {
		AssertUtils.notNull(bcdValue, "未指定域值");

		this.value = ByteUtils.bcdToStr(bcdValue).getBytes();
	}

	/**
	 * 6位批次号, 解码值第1位开始取6位.
	 * 
	 * @return
	 */
	public String get62_1() {
		if (str62_1 != null) {
			return str62_1;
		}

		final int startPos = 4;
		final int endPos = startPos + 6;
		str62_1 = new String(ArrayUtils.subarray(value, startPos, endPos));

		return str62_1;
	}

	/**
	 * 6位票据号, 解码值第7位开始取6位.
	 * 
	 * @return
	 */
	public String get62_2() {
		if (str62_2 != null) {
			return str62_2;
		}

		final int startPos = 10;
		final int endPos = startPos + 6;
		str62_2 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str62_2;
	}

	/**
	 * 6位原批次号, 解码值第13位开始取6位.
	 * 
	 * @return
	 */
	public String get62_3() {
		if (str62_3 != null) {
			return str62_3;
		}

		final int startPos = 16;
		final int endPos = startPos + 6;
		str62_3 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str62_3;
	}

	/**
	 * 6位原票据号, 解码值第18位开始取6位.
	 * 
	 * @return
	 */
	public String get62_4() {
		if (str62_4 != null) {
			return str62_4;
		}

		final int startPos = 22;
		final int endPos = startPos + 6;
		str62_4 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str62_4;
	}
}
