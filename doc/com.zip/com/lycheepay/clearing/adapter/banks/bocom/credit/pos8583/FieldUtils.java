package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

/**
 * 报文域工具.
 * 
 * @author aps-mhc
 */
public abstract class FieldUtils {

}
