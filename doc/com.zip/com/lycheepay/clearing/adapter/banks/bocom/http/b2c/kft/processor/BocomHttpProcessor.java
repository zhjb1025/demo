package com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bocom.netpay.b2cAPI.BOCOMB2CClient;
import com.bocom.netpay.b2cAPI.BOCOMSetting;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交通银行网银B2C HTTP(后台直接交互)请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午10:24:25
 */
@Service(ClearingAdapterAnnotationName.BOCOM_HTTP_PROCESSOR)
public class BocomHttpProcessor extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	/**
	 * <p>交通银行网银B2C网银充值或者支付(扣款)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午10:28:47
	 */
	public HttpReturnParam onlineDeduct(final HttpParam httpParam) throws BizException {
		String logMsg = "";
		final String logPrefix = ChannelId.getPrefixByValue(httpParam.getChannelId());
		logMsg = "进入" + logPrefix + "渠道Http业务处理。";
		Log4jUtil.info(logMsg);
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(httpParam.getChannelId());
		final String configFilePath = channelParms.get("300001");
		final String retUrl = channelParms.get("300002");
		AssertUtils.notNull(configFilePath, logPrefix + "渠道参数中configFilePath值不能为空!");
		AssertUtils.notNull(retUrl, logPrefix + "渠道参数中retUrl值不能为空!");
		// 订单号 yyyyMMdd+ 商户自定义序列号（10位）
		final String sendBankSn = sequenceManagerService.getBocommSN(DateUtil.getCurrentDate());
		AssertUtils.notNull(sendBankSn, logPrefix + "渠道生成订单号失败,请查看数据库中是否有BOCOM_CHANNEL_SN的序列!");
		final NetDeductDTO deduct = (NetDeductDTO) httpParam.getBizBean();
		Log4jUtil.info(logPrefix + " 网银扣款http请求处理器[获得HttpReturnParam],开始");
		return send(httpParam, deduct.getAmount(), deduct.getTxnId(), configFilePath, retUrl, sendBankSn);
	}

	/**
	 * <p>交通银行网银B2C发送代扣信息处理(PS.已做修改,去除未使用用入参字段)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午10:42:41
	 */
	public HttpReturnParam send(final HttpParam httpParam, final BigDecimal txAmount, final String bizSn,
			final String configFilePath, final String retUrl, final String sendBankSn) throws BizException {
		final String logPrefix = ChannelId.getPrefixByValue(httpParam.getChannelId());
		final BOCOMB2CClient client = new BOCOMB2CClient();
		final int ret = client.initialize(configFilePath); // 该代码只需调用一次
		if (ret != 0) {
			// 初始化失败
			Log4jUtil.debug("初始化失败,错误信息：" + client.getLastErr());
			throw new BizException(logPrefix + "api Client初始化失败,请查看交行网银配置是否正确!");
		}
		final String interfaceVersion = "1.0.0.0";// 消息版本号,固定为1.0.0.0
		final String merID = BOCOMSetting.MerchantID;
		AssertUtils.notNull(merID, logPrefix + "渠道参数中MerchantID值获取失败,请查看交行网银配置B2CMerchant.xml是否正确!");
		final String orderid = sendBankSn;
		final String orderDate = DateUtil.getCurrentDate();// 商户订单日期（yyyyMMdd）
		final String orderTime = DateUtil.getCurrentTime();// 商户订单时间（HHmmss）
		final String tranType = "0";// 交易类别, 0:B2C
		final java.text.DecimalFormat df = new java.text.DecimalFormat("0.00");// ""00.00"小数点后面的0的个数表示小数点的个数
		final String amount = df.format(txAmount);
		final String curType = "CNY";// 默认为CNY
		final String orderContent = "";
		final String orderMono = "";
		final String phdFlag = "0";// 非物流
		final String notifyType = "0";// 通知方式（0 不通知 1 通知基础平台 2 抓取页面）默认为0
		final String merURL = "";
		final String goodsURL = retUrl;
		final String jumpSeconds = "3";
		final String payBatchNo = "";
		final String proxyMerName = "";
		final String proxyMerType = "";
		final String proxyMerCredentials = "";
		final String netType = "0";// 0:html渠道
		final StringBuilder sourceMsg = new StringBuilder("");
		sourceMsg.append(interfaceVersion).append("|");
		sourceMsg.append(merID).append("|");
		sourceMsg.append(orderid).append("|");
		sourceMsg.append(orderDate).append("|");
		sourceMsg.append(orderTime).append("|");
		sourceMsg.append(tranType).append("|");
		sourceMsg.append(amount).append("|");
		sourceMsg.append(curType).append("|");
		sourceMsg.append(orderContent).append("|");
		sourceMsg.append(orderMono).append("|");
		sourceMsg.append(phdFlag).append("|");
		sourceMsg.append(notifyType).append("|");
		sourceMsg.append(merURL).append("|");
		sourceMsg.append(goodsURL).append("|");
		sourceMsg.append(jumpSeconds).append("|");
		sourceMsg.append(payBatchNo).append("|");
		sourceMsg.append(proxyMerName).append("|");
		sourceMsg.append(proxyMerType).append("|");
		sourceMsg.append(proxyMerCredentials).append("|");
		sourceMsg.append(netType);
		final com.bocom.netpay.b2cAPI.NetSignServer nss = new com.bocom.netpay.b2cAPI.NetSignServer();
		final String merchantDN = BOCOMSetting.MerchantCertDN;
		try {
			nss.NSSetPlainText(sourceMsg.toString().getBytes("GBK"));
		} catch (final UnsupportedEncodingException e) {
			throw new BizException(logPrefix + "api Client运行错误,请查看交行网银配置是否正确!");
		}
		final byte bSignMsg[] = nss.NSDetachedSign(merchantDN);
		if (nss.getLastErrnum() < 0) {
			Log4jUtil.debug("ERROR:商户端签名失败");
			throw new BizException(logPrefix + "api Client运行错误,请查看交行网银配置是否正确!");
		}
		String signMsg = "";
		try {
			signMsg = new String(bSignMsg, "GBK");
		} catch (final UnsupportedEncodingException e) {
			Log4jUtil.debug("ERROR:商户端签名失败", e);
			throw new BizException(logPrefix + "api Client运行错误,请查看交行网银配置是否正确!");
		}
		final String orderUrl = BOCOMSetting.OrderURL;
		final HttpReturnParam hrp = new HttpReturnParam();
		hrp.setAction(orderUrl);
		final Map<String, String> params = new HashMap<String, String>();
		params.put("interfaceVersion", interfaceVersion);
		params.put("merID", merID);
		params.put("orderid", orderid);
		params.put("orderDate", orderDate);
		params.put("orderTime", orderTime);
		params.put("tranType", tranType);
		params.put("amount", amount);
		params.put("curType", curType);
		params.put("orderContent", orderContent);
		params.put("orderMono", orderMono);
		params.put("phdFlag", phdFlag);
		params.put("notifyType", notifyType);
		params.put("merURL", merURL);
		params.put("goodsURL", goodsURL);
		params.put("jumpSeconds", jumpSeconds);
		params.put("payBatchNo", payBatchNo);
		params.put("proxyMerName", proxyMerName);
		params.put("proxyMerType", proxyMerType);
		params.put("proxyMerCredentials", proxyMerCredentials);
		params.put("netType", netType);
		params.put("merSignMsg", signMsg);
		hrp.setParams(params);
		// 写交易流水和渠道流水对照表
		billnoSnService.save(logPrefix, sendBankSn, httpParam);
		Log4jUtil.info(logPrefix + "[" + bizSn + "]支付流水,保存到渠道流水表成功!");
		return hrp;
	}

}
