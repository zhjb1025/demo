package com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean;

/**
 * <P>交行银企-公共报文头实体类</P>
 * 
 * @author 吴高雷(13632920449)
 */
public class BocomCorpPublicHead {
	// 请求
	private String req_tr_code; // 交易码
	private String req_corp_no; // 企业代码
	private String req_user_no; // 企业用户号
	private String req_req_no; // 发起方序号
	private String req_tr_acdt; // 交易日期
	private String req_tr_time; // 时间
	private String req_atom_tr_count; // 原子交易数
	private String req_channel = "0"; // 渠道标志
	private String req_reserved; // 保留字段

	// 应答
	private String rec_tr_code; // 交易码
	private String rec_corp_no; // 企业代码
	private String rec_req_no; // 发起方序号
	private String rec_serial_no; // 交易序号
	private String rec_ans_no; // 应答流水号
	private String rec_next_no; // 下笔交易号
	private String rec_tr_acdt; // 交易日期
	private String rec_tr_time; // 时间
	private String rec_ans_code; // 返回码
	private String rec_ans_info; // 返回信息
	private String rec_particular_code; // 返回附加码
	private String rec_particular_info; // 返回附加详细信息
	private String rec_atom_tr_count; // 原子交易数
	private String rec_reserved; // 保留字段

	/**
	 * @return the req_tr_code
	 */
	public String getReq_tr_code() {
		return req_tr_code;
	}

	/**
	 * @param req_tr_code the req_tr_code to set
	 */
	public void setReq_tr_code(String req_tr_code) {
		this.req_tr_code = req_tr_code;
	}

	/**
	 * @return the req_corp_no
	 */
	public String getReq_corp_no() {
		return req_corp_no;
	}

	/**
	 * @param req_corp_no the req_corp_no to set
	 */
	public void setReq_corp_no(String req_corp_no) {
		this.req_corp_no = req_corp_no;
	}

	/**
	 * @return the req_user_no
	 */
	public String getReq_user_no() {
		return req_user_no;
	}

	/**
	 * @param req_user_no the req_user_no to set
	 */
	public void setReq_user_no(String req_user_no) {
		this.req_user_no = req_user_no;
	}

	/**
	 * @return the req_req_no
	 */
	public String getReq_req_no() {
		return req_req_no;
	}

	/**
	 * @param req_req_no the req_req_no to set
	 */
	public void setReq_req_no(String req_req_no) {
		this.req_req_no = req_req_no;
	}

	/**
	 * @return the req_tr_acdt
	 */
	public String getReq_tr_acdt() {
		return req_tr_acdt;
	}

	/**
	 * @param req_tr_acdt the req_tr_acdt to set
	 */
	public void setReq_tr_acdt(String req_tr_acdt) {
		this.req_tr_acdt = req_tr_acdt;
	}

	/**
	 * @return the req_tr_time
	 */
	public String getReq_tr_time() {
		return req_tr_time;
	}

	/**
	 * @param req_tr_time the req_tr_time to set
	 */
	public void setReq_tr_time(String req_tr_time) {
		this.req_tr_time = req_tr_time;
	}

	/**
	 * @return the req_atom_tr_count
	 */
	public String getReq_atom_tr_count() {
		return req_atom_tr_count;
	}

	/**
	 * @param req_atom_tr_count the req_atom_tr_count to set
	 */
	public void setReq_atom_tr_count(String req_atom_tr_count) {
		this.req_atom_tr_count = req_atom_tr_count;
	}

	/**
	 * @return the req_channel
	 */
	public String getReq_channel() {
		return req_channel;
	}

	/**
	 * @param req_channel the req_channel to set
	 */
	public void setReq_channel(String req_channel) {
		this.req_channel = req_channel;
	}

	/**
	 * @return the req_reserved
	 */
	public String getReq_reserved() {
		return req_reserved;
	}

	/**
	 * @param req_reserved the req_reserved to set
	 */
	public void setReq_reserved(String req_reserved) {
		this.req_reserved = req_reserved;
	}

	/**
	 * @return the rec_tr_code
	 */
	public String getRec_tr_code() {
		return rec_tr_code;
	}

	/**
	 * @param rec_tr_code the rec_tr_code to set
	 */
	public void setRec_tr_code(String rec_tr_code) {
		this.rec_tr_code = rec_tr_code;
	}

	/**
	 * @return the rec_corp_no
	 */
	public String getRec_corp_no() {
		return rec_corp_no;
	}

	/**
	 * @param rec_corp_no the rec_corp_no to set
	 */
	public void setRec_corp_no(String rec_corp_no) {
		this.rec_corp_no = rec_corp_no;
	}

	/**
	 * @return the rec_req_no
	 */
	public String getRec_req_no() {
		return rec_req_no;
	}

	/**
	 * @param rec_req_no the rec_req_no to set
	 */
	public void setRec_req_no(String rec_req_no) {
		this.rec_req_no = rec_req_no;
	}

	/**
	 * @return the rec_serial_no
	 */
	public String getRec_serial_no() {
		return rec_serial_no;
	}

	/**
	 * @param rec_serial_no the rec_serial_no to set
	 */
	public void setRec_serial_no(String rec_serial_no) {
		this.rec_serial_no = rec_serial_no;
	}

	/**
	 * @return the rec_ans_no
	 */
	public String getRec_ans_no() {
		return rec_ans_no;
	}

	/**
	 * @param rec_ans_no the rec_ans_no to set
	 */
	public void setRec_ans_no(String rec_ans_no) {
		this.rec_ans_no = rec_ans_no;
	}

	/**
	 * @return the rec_next_no
	 */
	public String getRec_next_no() {
		return rec_next_no;
	}

	/**
	 * @param rec_next_no the rec_next_no to set
	 */
	public void setRec_next_no(String rec_next_no) {
		this.rec_next_no = rec_next_no;
	}

	/**
	 * @return the rec_tr_acdt
	 */
	public String getRec_tr_acdt() {
		return rec_tr_acdt;
	}

	/**
	 * @param rec_tr_acdt the rec_tr_acdt to set
	 */
	public void setRec_tr_acdt(String rec_tr_acdt) {
		this.rec_tr_acdt = rec_tr_acdt;
	}

	/**
	 * @return the rec_tr_time
	 */
	public String getRec_tr_time() {
		return rec_tr_time;
	}

	/**
	 * @param rec_tr_time the rec_tr_time to set
	 */
	public void setRec_tr_time(String rec_tr_time) {
		this.rec_tr_time = rec_tr_time;
	}

	/**
	 * @return the rec_ans_code
	 */
	public String getRec_ans_code() {
		return rec_ans_code;
	}

	/**
	 * @param rec_ans_code the rec_ans_code to set
	 */
	public void setRec_ans_code(String rec_ans_code) {
		this.rec_ans_code = rec_ans_code;
	}

	/**
	 * @return the rec_ans_info
	 */
	public String getRec_ans_info() {
		return rec_ans_info;
	}

	/**
	 * @param rec_ans_info the rec_ans_info to set
	 */
	public void setRec_ans_info(String rec_ans_info) {
		this.rec_ans_info = rec_ans_info;
	}

	/**
	 * @return the rec_particular_code
	 */
	public String getRec_particular_code() {
		return rec_particular_code;
	}

	/**
	 * @param rec_particular_code the rec_particular_code to set
	 */
	public void setRec_particular_code(String rec_particular_code) {
		this.rec_particular_code = rec_particular_code;
	}

	/**
	 * @return the rec_particular_info
	 */
	public String getRec_particular_info() {
		return rec_particular_info;
	}

	/**
	 * @param rec_particular_info the rec_particular_info to set
	 */
	public void setRec_particular_info(String rec_particular_info) {
		this.rec_particular_info = rec_particular_info;
	}

	/**
	 * @return the rec_atom_tr_count
	 */
	public String getRec_atom_tr_count() {
		return rec_atom_tr_count;
	}

	/**
	 * @param rec_atom_tr_count the rec_atom_tr_count to set
	 */
	public void setRec_atom_tr_count(String rec_atom_tr_count) {
		this.rec_atom_tr_count = rec_atom_tr_count;
	}

	/**
	 * @return the rec_reserved
	 */
	public String getRec_reserved() {
		return rec_reserved;
	}

	/**
	 * @param rec_reserved the rec_reserved to set
	 */
	public void setRec_reserved(String rec_reserved) {
		this.rec_reserved = rec_reserved;
	}
}
