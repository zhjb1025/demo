package com.lycheepay.clearing.adapter.banks.bocom.corp.kft.processor;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BatchPayBean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BatchResultQueryBean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BocomCorpPublicHead;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.DirectPayBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.BankSendSnGenerator;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交行银企直连处理类</P>
 * 
 * @author 吴高雷(13632920449)
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CORP_DIRECT_PROCESS)
public class CorpBocomDirectProcess {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_CORP_SERVICE)
	private CorpBocomService corpBocomService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	private static final String channelId = ChannelIdEnum.BOCOM_CORP.getCode();

	/**
	 * <p>实时/单笔代付（330002）</p>
	 * 
	 * @param param
	 * @return ReturnState
	 * @author 吴高雷(13632920449)
	 * @throws BizException
	 */
	public ReturnState deal330002(Param param) throws BizException {
		Log4jUtil.info("____________________发起实时代付业务（330002） ____________________");
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		// 得到公共报头 bean 数据
		// 生成交行银企流水-商户自定义序列号
		String bocomCorpReqSeqNo = sequenceManagerService.getCorpBOCOMSN(DateUtil.getCurrentDate());
		BocomCorpPublicHead sendPublicHead = corpBocomService.createSendHead("330002", bocomCorpReqSeqNo, channelParms);

		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);

		DirectPayBean send330002 = corpBocomService.package330002XML(bocomCorpReqSeqNo, (PayOutDTO) param.getBizBean(),
				bankaccountBalance, sendPublicHead, channelParms);

		// 发送业务前，写渠道流水对照表
		BillnoSn billnoSn = corpBocomService.saveOrUpdateBillnoSn(bocomCorpReqSeqNo, param, null, 0);

		// 创建330002报文
		String send330002XML = corpBocomService.create330002XML(sendPublicHead, send330002);

		BocomCorpPublicHead recvPublicHead = new BocomCorpPublicHead();
		// 通过http方式发送，并接收、处理其应答
		DirectPayBean receiveDirectPayBean = corpBocomService.create330002RecvBody(
				corpBocomService.httpSendAndReceive(channelParms, send330002XML), recvPublicHead);

		// 根据回执组ReturnState
		ReturnState returnState = corpBocomService.get330002ReturnState(billnoSn, recvPublicHead, receiveDirectPayBean);

		// 发送业务后，更新渠道流水对照表
		corpBocomService.saveOrUpdateBillnoSn(bocomCorpReqSeqNo, param, returnState, 1);
		return returnState;
	}

	/**
	 * <p>批量代付（330003）交易</p>
	 * 
	 * @param payList
	 * @param repeatSend
	 * @return
	 * @author 吴高雷(13632920449)
	 * @throws BizException
	 */
	public BatchSendResult processBatch(String channelBatchId, List<ChannelTempBill> payList, boolean repeatSend)
			throws BizException {
		// 1. 写渠道流水对照表(billno_sn)
		List<BillnoSn> billnoSns = billnoSnService.batchSaveBillnoSNs(channelBatchId, payList,
				new BankSendSnGenerator() {
					@Override
					public String getBankSendSn() {
						return sequenceManagerService.getCorpBOCOMSN(DateUtil.getCurrentDate());
					}
				});

		// 2. 发送处理
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);// 渠道公共参数
		BocomCorpPublicHead recvPublicHead = new BocomCorpPublicHead();
		// 查询银行备付金信息
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);// 快付通绑定账号
		BocomCorpPublicHead sendPublicHead = corpBocomService.createSendHead("330003", channelBatchId, channelParms);
		BatchPayBean send330003 = corpBocomService.package330003XML(channelBatchId, billnoSns, bankaccountBalance,
				sendPublicHead, channelParms);

		// 创建330003报文
		String send330003XML = corpBocomService.create330003XML(sendPublicHead, send330003);

		// 通过http方式发送，并接收、处理其应答
		corpBocomService.createRecvHead(corpBocomService.httpSendAndReceive(channelParms, send330003XML),
				recvPublicHead);// 初始化回执对象

		// 处理银行返回结果
		String channelCode = null;
		if (StringUtils.isNotBlank(recvPublicHead.getRec_particular_code())) {
			ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(
					channelId, recvPublicHead.getRec_particular_code()));
			if (channelRtncode != null) {
				channelCode = channelRtncode.getKftRtncode();
			} else {
				channelCode = TransReturnCode.code_9900;
			}
		} else {
			throw new BizException(TransReturnCode.code_9109, "批量代付(330003)响应为空！");
		}
		BatchSendResult batchSendResult = new BatchSendResult();
		batchSendResult.setBankReturnCode(recvPublicHead.getRec_particular_code());
		batchSendResult.setBankReturnMsg(recvPublicHead.getRec_particular_info());
		if (TransReturnCode.code_0000.equals(channelCode)) { // 0000 为 ‘交易成功’
			batchSendResult.setStatus(PayState.SUCCEED_STR);  // S:成功 F:失败 T:超时
		} else {
			batchSendResult.setStatus(PayState.FAILED_STR);
		}
		Log4jUtil.info("返回批量发送给银行后的实时响应结果 " + System.getProperty("line.separator") + batchSendResult);
		return batchSendResult;
	}

	/**
	 * 
	 * <p> 批量代付交易结果查询（310200） </p>
	 * 
	 * @throws BizException
	 * @author 吴高雷(13632920449)
	 */
	public void batchRetProcess() throws BizException {
		Log4jUtil.info("____________________交行银企-批量交易结果处理 batchRetProcess____________________");
		// 渠道公共参数
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		List<String> batchIdList = channelBatchService.getCorpBatchIdList(channelId);// 查出【未全部返回结果】的批次号List
		// 生成交行银企流水-商户自定义序列号
		String bocomCorpReqSeqNo = sequenceManagerService.getCorpBOCOMSN(DateUtil.getCurrentDate());
		BocomCorpPublicHead sendPublicHead = corpBocomService.createSendHead("310200", bocomCorpReqSeqNo, channelParms);
		for (Iterator<String> iterator = batchIdList.iterator(); iterator.hasNext();) {
			String channelBatchid = iterator.next();
			Log4jUtil.info("批次【{}】发送查询报文", channelBatchid);
			BatchResultQueryBean send310200 = corpBocomService.package310200XML(channelBatchid);// 组装报文
			// 创建310200报文、
			String send310200XML = corpBocomService.create310200XML(sendPublicHead, send310200);
			BocomCorpPublicHead recvPublicHead = new BocomCorpPublicHead();
			// 通过http方式发送，并接收、处理其应答
			BatchResultQueryBean recv310200 = corpBocomService.create310200RecvBody(
					corpBocomService.httpSendAndReceive(channelParms, send310200XML), recvPublicHead);// 初始化回执对象
			corpBocomService.batchDetailProcess(recv310200.getSerialRecordBeanList());// 处理【批量交易查询】结果数据
		}
	}

	/**
	 * <p>单笔交易结果查询</p>
	 * 
	 * @param billnoSn
	 * @return ReturnState
	 * @throws BizException
	 * @author 吴高雷(13632920449)
	 */
	public ReturnState querySingleRecord(BillnoSn billnoSn) throws BizException {
		Log4jUtil.info("____________________交行银企-单笔交易结果查询处理 querySingleRecord____________________");
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		// 生成交行银企流水-商户自定义序列号
		String bocomCorpReqSeqNo = sequenceManagerService.getCorpBOCOMSN(DateUtil.getCurrentDate());
		BocomCorpPublicHead sendPublicHead = corpBocomService.createSendHead("310200", bocomCorpReqSeqNo, channelParms);
		BatchResultQueryBean send310200 = corpBocomService.package310200XML(billnoSn.getBankSendSn());// 组装报文

		// 创建310200报文
		String send310200XML = corpBocomService.create310200XML(sendPublicHead, send310200);
		BocomCorpPublicHead recvPublicHead = new BocomCorpPublicHead();

		// 通过http方式发送，并接收、处理其应答
		BatchResultQueryBean recv310200 = corpBocomService.create310200RecvBody(
				corpBocomService.httpSendAndReceive(channelParms, send310200XML), recvPublicHead);

		// 根据回执组ReturnState
		return corpBocomService.get310200ReturnState(recvPublicHead, recv310200);
	}
}
