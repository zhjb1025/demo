package com.lycheepay.clearing.adapter.banks.bocom.creditQP.model;

import org.soofa.core.model.BaseObject;

public class ComRspDTO extends BaseObject{

	private static final long serialVersionUID = -8522687206236730008L;
	
	private String returnCode;	//返回码
	private String returnMsg;	//返回码描述
	private String authNo;	//授权号
	private String addDataField;	//附加字段
	private String addData;	//附加域
	private String version;	//报文版本号
	private String hostDate;	//日期
	private String hostTime;	//时间
	
	private String TrxId;  //交易流水号
	private String BkTrxId;  //银行流水号
	private String SgnNo;  //签约号
	private String BkAcctTp;  //银行账户类型
	private String BkAcctNo;  //银行账户编号
	private String BkAcctLv1;  //银行账户等级
	private String SysRtnCd;  //系统返回码
	private String SysRtnDesc;  //系统返回说明
	private String BizStsCd;  //业务状态码
	private String BizStsDesc;  //业务状态说明
	
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMsg() {
		return returnMsg;
	}
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	public String getAuthNo() {
		return authNo;
	}
	public void setAuthNo(String authNo) {
		this.authNo = authNo;
	}
	public String getAddDataField() {
		return addDataField;
	}
	public void setAddDataField(String addDataField) {
		this.addDataField = addDataField;
	}
	public String getAddData() {
		return addData;
	}
	public void setAddData(String addData) {
		this.addData = addData;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getHostDate() {
		return hostDate;
	}
	public void setHostDate(String hostDate) {
		this.hostDate = hostDate;
	}
	public String getHostTime() {
		return hostTime;
	}
	public void setHostTime(String hostTime) {
		this.hostTime = hostTime;
	}
	public String getTrxId() {
		return TrxId;
	}
	public void setTrxId(String trxId) {
		TrxId = trxId;
	}
	public String getBkTrxId() {
		return BkTrxId;
	}
	public void setBkTrxId(String bkTrxId) {
		BkTrxId = bkTrxId;
	}
	public String getSgnNo() {
		return SgnNo;
	}
	public void setSgnNo(String sgnNo) {
		SgnNo = sgnNo;
	}
	public String getBkAcctTp() {
		return BkAcctTp;
	}
	public void setBkAcctTp(String bkAcctTp) {
		BkAcctTp = bkAcctTp;
	}
	public String getBkAcctNo() {
		return BkAcctNo;
	}
	public void setBkAcctNo(String bkAcctNo) {
		BkAcctNo = bkAcctNo;
	}
	public String getBkAcctLv1() {
		return BkAcctLv1;
	}
	public void setBkAcctLv1(String bkAcctLv1) {
		BkAcctLv1 = bkAcctLv1;
	}
	public String getSysRtnCd() {
		return SysRtnCd;
	}
	public void setSysRtnCd(String sysRtnCd) {
		SysRtnCd = sysRtnCd;
	}
	public String getSysRtnDesc() {
		return SysRtnDesc;
	}
	public void setSysRtnDesc(String sysRtnDesc) {
		SysRtnDesc = sysRtnDesc;
	}
	public String getBizStsCd() {
		return BizStsCd;
	}
	public void setBizStsCd(String bizStsCd) {
		BizStsCd = bizStsCd;
	}
	public String getBizStsDesc() {
		return BizStsDesc;
	}
	public void setBizStsDesc(String bizStsDesc) {
		BizStsDesc = bizStsDesc;
	}
}
