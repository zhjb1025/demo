package com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor;

import java.util.Map;

import com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.bean.BocomB2CParam;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelParamUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


//交行网银工具类
public class BocomKFTUtil {

	public static Map<String, String> checkChannelParam(final String logPrefix, final String type,
			final Map<String, String> channelParam, final BocomB2CParam bocomB2CParam) throws BizException {
		String key = "";
		String defaultValue = "";
		String keyName = "";
		String logMsg = "";
		logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
		Log4jUtil.info(logMsg);
		// 开始对公共必须要检查的参数进行检查
		key = "300001";
		keyName = "网银参数配置文件";
		defaultValue = "/root/bankcert/bocomm/ini/B2CMerchant.xml";
		ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		key = "300002";
		keyName = "结果返回的URL";
		defaultValue = "http://119.8.185.203/paycore/bocomHttpRspServlet";
		ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		key = "300003";
		keyName = "业务操作用户";
		defaultValue = "301310063009501";
		ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		// 公共的检查完毕

		// 设置到银行参数实体中
		bocomB2CParam.setConfigFilePath(channelParam.get("300001"));
		bocomB2CParam.setRetUrl(channelParam.get("300002"));
		bocomB2CParam.setConfigFilePath(channelParam.get("300003"));

		// if (type.equals(ChannelTransType.Real_Time_Agent_Pay)
		// || type.equals(ChannelTransType.Real_Time_Agent_Collection)
		// || type.equals(ChannelTransType.Batch_Agent_Pay)
		// || type.equals(ChannelTransType.Batch_Agent_Collection) ||
		// type.equals(ClearingTransType.Protocol_Sign)
		// || type.equals(ClearingTransType.Protocol_UnSign)) {
		//
		// } else if (type.equals(ClearingTransType.Account_Verify)) {
		// // 账户验证
		//
		// }

		logMsg = logPrefix + "对渠道参数检查结束。";
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, bocomB2CParam);
		return channelParam;
	}
}
