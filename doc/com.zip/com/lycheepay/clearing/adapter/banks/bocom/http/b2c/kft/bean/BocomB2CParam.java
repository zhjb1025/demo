package com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.bean;

public class BocomB2CParam {
	private String configFilePath;// 交通银行网银参数配置文件
	private String retUrl;// 交行参数配置文件处理结果返回的URL
	private String operUser;// 交行参数业务操作用户

	public String getConfigFilePath() {
		return configFilePath;
	}

	public void setConfigFilePath(final String configFilePath) {
		this.configFilePath = configFilePath;
	}

	public String getRetUrl() {
		return retUrl;
	}

	public void setRetUrl(final String retUrl) {
		this.retUrl = retUrl;
	}

	public String getOperUser() {
		return operUser;
	}

	public void setOperUser(final String operUser) {
		this.operUser = operUser;
	}

}
