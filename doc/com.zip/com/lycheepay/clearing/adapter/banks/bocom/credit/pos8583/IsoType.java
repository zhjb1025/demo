package com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583;

public class IsoType {
	// ISO8583协议应版本不同或各公司的实现有编码的差别
	// 如:银联8583并不是纯的ISO8583, 只是参考ISO8583, 银联的字符编码是ASCII码,而ISO8583是BCD码,两者是有差别的
	public static final int BCD = 0;
	public static final int BINARY = 1;
	public static final int ASCII = 2;
}
