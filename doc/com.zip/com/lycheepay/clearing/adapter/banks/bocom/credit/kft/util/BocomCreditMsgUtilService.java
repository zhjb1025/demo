package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.bocom.credit.kft.bean.BocomCreditBean;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgField;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgFieldType;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgPackUtils;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.DeductPayReal;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.pos8583.ByteUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.CustomerInfoDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交行信用卡消息处理工具服务
 * (严格区分Util与UtilsService,前者为简单的静态工具类,后者需要注入其他service，并且与数据库有交集;调用方可以明显区分,如果有Service,不允许new出该对象)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午8:49:21
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_MSG_UTIL_SERVICE)
public class BocomCreditMsgUtilService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	private final String channelName = ChannelIdEnum.BOCOM_CREDIT_CARD.getDesc();

	private final String channelId = ChannelIdEnum.BOCOM_CREDIT_CARD.getCode();

	/**
	 * 创建签到
	 * 
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createSign(final String bankSendSn) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 终端代码
		final String merchant = channelParms.get("100006");// 商户代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String pwdKey = channelParms.get("100013");// 商户主密钥

		// 数据验证
		validateField(conCode, "交行信用卡签到8583报文-服务电条形码", 2, 2);
		validateField(clinetCode, "交行信用卡签到8583报文-终端代码", 1, 8);
		validateField(merchant, "交行信用卡签到8583报文-商户代码", 1, 15);
		validateField(operator, "交行信用卡签到8583报文-操作员代码", 1, 6);
		validateField(pwdKey, "交行信用卡签到8583报文-商户主密钥", 1, 16);


		final SimpleDateFormat df = new SimpleDateFormat("MMdd HHmmss");
		final String[] dateArr = df.format(new Date()).split(" ");

		// 组 报文
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0820");// 消息类型
		MsgPackUtils.createField3(msgPack, "910000");// 处理码
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		MsgPackUtils.createField12(msgPack, dateArr[1]);// 时分秒
		MsgPackUtils.createField13(msgPack, dateArr[0]);// 月日
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码
		MsgPackUtils.createField60(msgPack, operator);// 操作员号密码
		// 获取需要MAC加密的64域
		MsgPackUtils.createMac(msgPack, pwdKey);
		return msgPack;
	}

	/**
	 * 
	 * 创建消费
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createConsume(final Param param, final String bankSendSn, Map<String, String> channelParms)
			throws BizException {
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 终端代码
		final String merchant = channelParms.get("100006");// 商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String workKey = channelParms.get("100014");// 工作密钥
		final String batchNo = channelParms.get("100009");// 批次号

		// 数据验证
		validateField(inputCode, "交行信用卡签到8583报文-服务点输入方式码", 3, 3);
		validateField(conCode, "交行信用卡签到8583报文-服务点条形码", 2, 2);
		validateField(clinetCode, "交行信用卡签到8583报文-终端代码", 1, 8);
		validateField(merchant, "交行信用卡签到8583报文-商户代码", 1, 15);
		validateField(currency, "交行信用卡签到8583报文-货币代码", 1, 3);
		validateField(operator, "交行信用卡签到8583报文-操作员代码", 1, 6);
		validateField(workKey, "交行信用卡签到8583报文-工作密钥", 1, 16);

		DeductDTO deductDTO = (DeductDTO) param.getBizBean(); // 代扣实体

		// 获取渠道通用交易实体
		final DeductPayReal debiPayReal = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debiPayReal);

		// 特殊域验证
		AssertUtils.checkLength(debiPayReal.getExpdate(), TransReturnCode.code_9108, channelName + "消费报文[14域]卡有效期", 4, 4);
		AssertUtils.checkLength(debiPayReal.getOut_Account(), TransReturnCode.code_9108, channelName + "消费报文[2域]卡号", 1, 19);

		// 报文组装
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		MsgPackUtils.createAccountField(msgPack, debiPayReal.getOut_Account());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "180002");// 交易处理码
		MsgPackUtils.createField4(msgPack, debiPayReal.getAmount_Num());// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		MsgPackUtils.createField14(msgPack, debiPayReal.getExpdate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码(网银支付)
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码R
		MsgPackUtils.createField60(msgPack, operator);// 操作员号密码

		CustomerInfoDTO infoDTO = deductDTO.getCustomerInfoDTO();
		String merName = "";
		if (infoDTO != null) {//先取商户名称缩写，没有再取全称
			if (StringUtils.isNotBlank(infoDTO.getCustomerShortName())) {
				merName = infoDTO.getCustomerShortName();
			} else if (StringUtils.isNotBlank(infoDTO.getCustomerName())) {
				merName = infoDTO.getCustomerName();
			}
		}
		String merchantName = channelParms.get("100018") + StringUtils.substring("-" + merName, 0, 10);// 一级商户快付通-二级商户

		MsgPackUtils.createField61(msgPack, "00N" + merchantName);

		// 组装62自定义域 ：6位批次号+6位票据号(目前票据号取的是流程号）
		byte[] field62B = ByteUtils.strToBcdRightSide("012");
		field62B = ArrayUtils.addAll(field62B, batchNo.getBytes());
		field62B = ArrayUtils.addAll(field62B, bankSendSn.getBytes());
		MsgPackUtils.createField62(msgPack, field62B);

		// 获取需要MAC加密的64域
		Log4jUtil.info("加密的MACKEY为:" + workKey);
		MsgPackUtils.createMac(msgPack, workKey);// MAC

		return msgPack;
	}

	/**
	 * 创建退货 主要是根据银行在代扣交易时候返回的检索参考号来退货
	 * 
	 * @param bizBean 退货的bean
	 * @param acctNo 信用卡号
	 * @param validdate 信用卡有效期
	 * @param recvDate 消费时银行返回的交易日期
	 * @return
	 * @throws BizException
	 */
	public MsgPack createReturn(final BocomCreditBean bocomCredit, Map<String, String> channelParms)
			throws BizException {
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 终端代码
		final String merchant = channelParms.get("100006");// 商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String batchNo = channelParms.get("100009");// 批次号
		final String workKey = channelParms.get("100014");// 工作密钥
		final String merchant_name = channelParms.get("100018");// 商户名称
		final MsgPack msgPack = new MsgPack();

		// 数据验证
		validateField(inputCode, "交行信用卡签到8583报文-服务点输入方式码", 3, 3);
		validateField(conCode, "交行信用卡签到8583报文-服务点条形码", 2, 2);
		validateField(clinetCode, "交行信用卡签到8583报文-终端代码", 1, 8);
		validateField(merchant, "交行信用卡签到8583报文-商户代码", 1, 15);
		validateField(currency, "交行信用卡签到8583报文-货币代码", 1, 3);
		validateField(operator, "交行信用卡签到8583报文-操作员代码", 1, 6);
		validateField(workKey, "交行信用卡签到8583报文-工作密钥", 1, 16);

		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0220");// 消息类型

		MsgPackUtils.createAccountField(msgPack, bocomCredit.getAcctNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "999001");// 交易处理码
		MsgPackUtils.createField4(msgPack, bocomCredit.getAmount().doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, bocomCredit.getBankSendSn());// POS终端交易流水
		MsgPackUtils.createField14(msgPack, bocomCredit.getValidDate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码
		MsgPackUtils.createField60(msgPack, operator);// 操作员号密码

		MsgPackUtils.createField61(msgPack, "00N" + merchant_name);
		// 6位批次号+6位票据号+6位原批次号+6位原票据号
		byte[] field62B = ByteUtils.strToBcdRightSide("024");
		field62B = ArrayUtils.addAll(field62B, batchNo.getBytes());
		field62B = ArrayUtils.addAll(field62B, bocomCredit.getBankSendSn().getBytes());
		field62B = ArrayUtils.addAll(field62B, bocomCredit.getBatchNo().getBytes());
		field62B = ArrayUtils.addAll(field62B, bocomCredit.getOrgBankSendSn().getBytes());
		MsgPackUtils.createField62(msgPack, field62B);
		Log4jUtil.info("batchNo :" + batchNo);
		Log4jUtil.info("bocomCredit.getBankSendSn() :" + bocomCredit.getBankSendSn());
		Log4jUtil.info("bocomCredit.getBatchNo() :" + bocomCredit.getBatchNo());
		Log4jUtil.info("bocomCredit.getOrgBankSendSn() :" + bocomCredit.getOrgBankSendSn());
		Log4jUtil.info("bocomCredit.getOrgBankSendSn().substring(6) :" + bocomCredit.getOrgBankSendSn().substring(6));
		// 组装需要MAC加密的域
		MsgPackUtils.createMac(msgPack, workKey);// MAC

		return msgPack;
	}

	/**
	 * 创建撤销
	 * 
	 * @param bizBean 退货的bean
	 * @param acctNo 信用卡号
	 * @param validdate 信用卡有效期
	 * @param recvDate 消费时银行返回的交易日期
	 * @return
	 * @throws BizException
	 */
	public MsgPack createCancel(final BocomCreditBean bocomCredit, Map<String, String> channelParms)
			throws BizException {
		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 终端代码
		final String merchant = channelParms.get("100006");// 商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String batchNo = channelParms.get("100009");// 批次号
		final String workKey = channelParms.get("100014");// 工作密钥
		final String merchant_name = channelParms.get("100018");// 商户名称

		// 数据验证
		validateField(inputCode, "交行信用卡签到8583报文-服务点输入方式码", 3, 3);
		validateField(conCode, "交行信用卡签到8583报文-服务点条形码", 2, 2);
		validateField(clinetCode, "交行信用卡签到8583报文-终端代码", 1, 8);
		validateField(merchant, "交行信用卡签到8583报文-商户代码", 1, 15);
		validateField(currency, "交行信用卡签到8583报文-货币代码", 1, 3);
		validateField(operator, "交行信用卡签到8583报文-操作员代码", 1, 6);
		validateField(workKey, "交行信用卡签到8583报文-工作密钥", 1, 16);

		Log4jUtil.info("创建撤销报文开始...");
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类
		MsgPackUtils.createAccountField(msgPack, bocomCredit.getAcctNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200002");// 交易处理码
		MsgPackUtils.createField4(msgPack, bocomCredit.getAmount().doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, bocomCredit.getBankSendSn());// POS终端交易流水
		MsgPackUtils.createField14(msgPack, bocomCredit.getValidDate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码

		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		// MsgPackUtils.createField38(msgPack, bocomCredit.getAuthorizationCode());// 原授权码
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码

		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码
		MsgPackUtils.createField60(msgPack, operator);// 操作员号密码

		MsgPackUtils.createField61(msgPack, "00N" + merchant_name);

		// 组装62自定义域 ：6位批次号+6位票据号+原票据信息
		byte[] field62B = ByteUtils.strToBcdRightSide("018");
		field62B = ArrayUtils.addAll(field62B, batchNo.getBytes());
		field62B = ArrayUtils.addAll(field62B, bocomCredit.getBankSendSn().getBytes());// POS终端交易流水
		field62B = ArrayUtils.addAll(field62B, bocomCredit.getOrgBankSendSn().getBytes());// 原交易发往银行的流水
		MsgPackUtils.createField62(msgPack, field62B);

		// 组装需要MAC加密的域
		MsgPackUtils.createMac(msgPack, workKey);// MAC
		Log4jUtil.info("创建撤销报文结束");
		return msgPack;
	}

	/**
	 * 创建 冲正
	 * 
	 * @param param
	 * @param grantFinshMsg 银行返回的消费包
	 * @return
	 * @throws BizException
	 */
	public MsgPack createFinishRush(final MsgPack grantFinshMsg, final MsgPack consumeMsgPack,
			Map<String, String> channelParms) throws BizException {

		final String inputCode = channelParms.get("100003");// 服务点输入方式码
		final String conCode = channelParms.get("100004");// 服务点条件码
		final String clinetCode = channelParms.get("100005");// 终端代码
		final String merchant = channelParms.get("100006");// 商户代码
		final String currency = channelParms.get("100007");// 货币代码
		final String operator = channelParms.get("100008");// 操作员代码
		final String batchNo = channelParms.get("100009");// 批次号
		final String workKey = channelParms.get("100014");// 工作密钥

		// 数据验证
		validateField(inputCode, "交行信用卡签到8583报文-服务点输入方式码", 3, 3);
		validateField(conCode, "交行信用卡签到8583报文-服务点条形码", 2, 2);
		validateField(clinetCode, "交行信用卡签到8583报文-终端代码", 1, 8);
		validateField(merchant, "交行信用卡签到8583报文-商户代码", 1, 15);
		validateField(currency, "交行信用卡签到8583报文-货币代码", 1, 3);
		validateField(operator, "交行信用卡签到8583报文-操作员代码", 1, 6);
		validateField(workKey, "交行信用卡签到8583报文-工作密钥", 1, 16);

		final MsgPack msgPack = new MsgPack();
		final String bankSendSn = sequenceManagerService.getBocomCreditSN();
		Log4jUtil.info("冲正流水号：" + bankSendSn);
		// 组装需加密数据域为2,3,4,11,12,13,49,38,39,41
		Log4jUtil.info("创建冲正报文开始"); // TODO

		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		Log4jUtil.info("consumeMsgPack.getFieldContent3()) :" + consumeMsgPack.getFieldContent3()); // TODO
		MsgPackUtils.createAccountField(msgPack, consumeMsgPack.getAccountNo());

		Log4jUtil.info("2域的值为 ： " + msgPack.getAccountNo());
		MsgPackUtils.createField3(msgPack, consumeMsgPack.getFieldContent3());// 原交易处理码
		MsgPackUtils.createField4(msgPack, consumeMsgPack.getAmount());// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 不同原交易
		MsgPackUtils.createField14(msgPack, consumeMsgPack.getFieldContent14());
		MsgPackUtils.createField22(msgPack, inputCode);

		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码

		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码

		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码
		MsgPackUtils.createField60(msgPack, operator);// 操作员号密码

		// 组装62自定义域 ：原批次号+原票据号
		byte[] field62B = ByteUtils.strToBcdRightSide("012");
		field62B = ArrayUtils.addAll(field62B, batchNo.getBytes());// 原批次号
		field62B = ArrayUtils.addAll(field62B, consumeMsgPack.getFieldContent11().getBytes());// 原票据号
		MsgPackUtils.createField62(msgPack, field62B);

		// 组装需要MAC加密的域
		MsgPackUtils.createMac(msgPack, workKey);// MAC
		Log4jUtil.info("创建冲正报文结束");

		return msgPack;
	}

	/**
	 * 创建公共的8583报文头信息
	 * 
	 * @param msgPack
	 * @throws BizException
	 */
	public void createHeadMsg(final MsgPack msgPack) throws BizException {
		MsgPackUtils.createHeadField(msgPack, ByteUtils.strToBcd("02"));
		MsgPackUtils.createTpduField(msgPack, ByteUtils.strToBcd("6001000100"));
	}

	/**
	 * 向目标地址发送信息
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public MsgPack sendMsg(final MsgPack msgPack) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String socketIP = channelParms.get("100001"); // 中行socketIP
		final String socketPort = channelParms.get("100002");// 中行socketPort

		byte[] bytes = msgPack.getBytes();
		final SendBySocket sendBySocket = new SendBySocket();

		final byte[] msg_end = { 03, 01 };// 报文结尾
		bytes = ArrayUtils.addAll(bytes, msg_end);
		Log4jUtil.info("调用公共的 socket 方法发送到" + channelName + "渠道的报文数据:" + ByteUtils.bcdToStr(bytes));
		final MsgPack rspMsg = sendBySocket.sendAndRecv(socketIP, socketPort, bytes);

		// MAC校验
		if (!this.validateMac(rspMsg)) {
			Log4jUtil.info("响应报文中的MAC校验错误,报文被篡改。");
			throw new BizException(TransReturnCode.code_9109, "响应报文中的MAC校验错误,报文被篡改。");
		}
		return rspMsg;
	}

	/**
	 * 组装需加密数据域为2,3,4,11,12,13,25,39,41,42,43,44,61,62
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public byte[] packMacData(final MsgPack msgPack) throws BizException {
		final byte[] bitBin = msgPack.getBitmap();
		byte[] res = new byte[] {};
		if (bitBin != null && bitBin.length >= 64) {
			res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.MSG_TYPE.getNo()).getOrigValue());
			res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.BITMAP.getNo()).getOrigValue());
			if (bitBin[1] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_2.getNo()).getOrigMsg());
			}
			if (bitBin[2] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_3.getNo()).getOrigMsg());
			}
			if (bitBin[3] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_4.getNo()).getOrigMsg());
			}
			if (bitBin[10] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_11.getNo()).getOrigMsg());
			}
			if (bitBin[11] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_12.getNo()).getOrigMsg());
			}
			if (bitBin[12] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_13.getNo()).getOrigMsg());
			}
			if (bitBin[13] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_14.getNo()).getOrigMsg());
			}
			if (bitBin[24] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_25.getNo()).getOrigMsg());
			}
			if (bitBin[36] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_37.getNo()).getOrigMsg());
			}
			if (bitBin[37] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_38.getNo()).getOrigMsg());
			}
			if (bitBin[38] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_39.getNo()).getOrigMsg());
			}
			if (bitBin[40] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_41.getNo()).getOrigMsg());
			}
			if (bitBin[41] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_42.getNo()).getOrigMsg());
			}
			if (bitBin[42] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_43.getNo()).getOrigMsg());
			}
			if (bitBin[43] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_44.getNo()).getOrigMsg());
			}
			if (bitBin[52] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_53.getNo()).getOrigMsg());
			}
			if (bitBin[60] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_61.getNo()).getOrigMsg());
			}
			if (bitBin[61] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_62.getNo()).getOrigMsg());
			}
		}
		Log4jUtil.info("需要加密的MAC数据长度为:" + res.length);

		return res;
	}

	/**
	 * 
	 * <p>验证报文公共数据是否为空，长度是否正确</p>
	 * 
	 * @param data
	 * @param message
	 * @param minLen
	 * @param maxLen
	 * @throws BizException
	 * @author 廖四发（13554889794）
	 */

	private void validateField(String data, String message, int minLen, int maxLen) throws BizException {
		AssertUtils.notEmpty(data, TransReturnCode.code_9108, message);
		AssertUtils.checkLength(data, TransReturnCode.code_9108, message, minLen, maxLen);
	}

	/**
	 * 校验响应报文中的MAC
	 * 
	 * @param rspMsg 消息包
	 * @return
	 * @throws BizException
	 */
	private boolean validateMac(final MsgPack rspMsg) throws BizException {
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String workKey = channelParms.get("100014");// 工作密钥

		boolean result = false;
		final MsgField macField = rspMsg.getField(MsgFieldType.FIELD_64.getNo());

		// 如果MAC为空则，不需要验证MAC
		if (macField == null || macField.getStringValue() == null || "".equals(macField.getStringValue())) {
			return true;
		}
		final byte[] macData = packMacData(rspMsg);

		final String mac = MacUtil.getMacData2(workKey, macData);

		// 只比较MAC前四字节
		String macSubStr = "";
		if (mac.length() >= 8) {
			macSubStr = mac.substring(0, 8);
		}
		String recvMacSubStr = "";
		if (LoUtils.byte2HexStr(macField.getOrigMsg()).length() >= 8) {
			recvMacSubStr = LoUtils.byte2HexStr(macField.getOrigMsg()).substring(0, 8);
		}

		if (macSubStr.equalsIgnoreCase(recvMacSubStr)) {
			result = true;
		}

		return result;
	}

}
