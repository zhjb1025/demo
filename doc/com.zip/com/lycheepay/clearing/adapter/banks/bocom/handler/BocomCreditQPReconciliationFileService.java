/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.bocom.handler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.bocom.creditQP.constant.Constant;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.SftpUtilByPass;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交通银行信用卡快捷对账文件</P>
 * @author lj
 * 
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CREDIT_QP_RECONCILIATION_FILE_SERVICE)
public class BocomCreditQPReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";
	
	private static final String SEPARATOR = File.separator; // File.separator /
	
	@Override
	public String getReconciliationFile(String fileSavePath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("bocomCreditQP", "getReconciliationFile");
		//校验参数
		String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		String reconciliationDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId, settleDate);
		Log4jUtil.info("本次对账日期为:{}", reconciliationDate);
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelIdNoCache(channelId);
		if (channelParms == null || channelParms.isEmpty()) {
			throw new BizException("渠道未配置相关信息");
		}
		Log4jUtil.info("渠道信息:{}", channelParms);
		//从sftp服务器下载对账文件
		String localFile = downLoadFileFromSFTP(channelParms, channelId, reconciliationDate);
		//将文件解压成一个文件
		Log4jUtil.info("最终需要解析的文件名:{}", localFile);
		
		//生成我们所需根据对账文件格式
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try {
			reconciliationFileDTOList = buildTransactionDataList(localFile, channelId, reconciliationDate);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException("生成对账文件异常" + e.getMessage());
		}
		Log4jUtil.info("生成统一格式对账文件");
		String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, reconciliationDate, reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * @param fileFullPath
	 * @param channelId
	 * @param settleDate
	 * @return
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(String fileFullPath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
		File file = new File(fileFullPath);
		if (!file.exists()) {
			throw new BizException("未发现交行对账文件");
		}
		Log4jUtil.info("开始解析对账文件");
		
		List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		InputStreamReader reader = null;
		BufferedReader bufferedReader = null;
		try {
			reader = new InputStreamReader(new FileInputStream(file), Charset.forName("GBK"));
		    bufferedReader = new BufferedReader(reader);
			String data = bufferedReader.readLine();
			while (!StringUtils.isBlank(data)) {
				String[] s = data.split("\\|");
				String checkDate = s[2];  //交易日期
				String amount = s[13];  //交易金额
				String bankSendSn = s[14];  //流水号
				
				ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
				reconciliationFileDTO.setBankTransState("00");
				reconciliationFileDTO.setCheckDate(checkDate);
				reconciliationFileDTO.setBankSendId(bankSendSn); // 订单号
				reconciliationFileDTO.setTransDate(checkDate); // 交易日期
				reconciliationFileDTO.setChannelId(channelId);
				
				BigDecimal amountB = new BigDecimal(amount);
				if (amountB.compareTo(new BigDecimal("0")) < 0) {
					reconciliationFileDTO.setAmount(amountB.abs().movePointLeft(2));// 交易金额，分转为元
					reconciliationFileDTO.setPayGet(STR_PAY);
				} else {
					reconciliationFileDTO.setAmount(amountB.abs().movePointLeft(2));// 交易金额，分转为元
					reconciliationFileDTO.setPayGet(STR_GET);
				}
				reconciliationFileDTOList.add(reconciliationFileDTO);
				data = bufferedReader.readLine();
			}
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e);
		} finally {
			IOUtils.closeQuietly(bufferedReader);
			IOUtils.closeQuietly(reader);
		}
		Log4jUtil.info("生成对账文件笔数:{}", reconciliationFileDTOList.size());
		return reconciliationFileDTOList;
	}

	/**
	 * 从sftp服务器下载对账文件到临时目录 并返回临时下载的文件路径
	 * @param channelParms
	 * @param channelId
	 * @param reconciliationDate
	 * @throws BizException
	 */
	private String downLoadFileFromSFTP(Map<String, String> channelParms, String channelId, String reconciliationDate) throws BizException {
		String ftpIP = channelParms.get(Constant.SFTP_IP_ADDRESS);
		String ftpUser = channelParms.get(Constant.SFTP_USER_NAME);
		String ftpPwd = channelParms.get(Constant.SFTP_PASSWORD);
		String ftpPort = channelParms.get(Constant.SFTP_POST);
		String ftpPathPrefix = channelParms.get(Constant.FTP_PATH_PREFIX);
		// ftpPathPrefix(/home/admin/ftp) + 商户号+日期   sftp文件路径
		String downloadDirectory = ftpPathPrefix;  // + SEPARATOR + channelParms.get(Constant.MER_NO) + SEPARATOR + reconciliationDate
		//下载文件后保存的临时目录 :/home/admin/sharedata/unipayC2B/reconciliationDate
		String localFileDirectory = channelParms.get(Constant.LOCAL_FILE_PATH) + SEPARATOR + reconciliationDate; 
		//下载的文件名
		String rcvFileName = "SDdzd_" + channelParms.get(Constant.MER_NO) + "_" + reconciliationDate + ".1";
		//创建目录
		File directory = new File(localFileDirectory);
		if (!directory.exists()) {
			Log4jUtil.info("创建临时保存目录");
			if (directory.mkdirs()) {
				Log4jUtil.info("创建目录:{} 成功", localFileDirectory);
			} else {
				Log4jUtil.error("创建目录:{} 失败", localFileDirectory);
				throw new BizException("创建目录" + localFileDirectory  + "失败");
			}
		}
		SftpUtilByPass sf = new SftpUtilByPass(ftpIP, ftpUser, null, ftpPwd, Integer.parseInt(ftpPort));
		ChannelSftp sftp = sf.connectByPasswd();
		try {
			Log4jUtil.info("sftp下载路径:{}", downloadDirectory);
			Log4jUtil.info("需要下载的文件名:{}", rcvFileName);
			Log4jUtil.info("临时保存文件的路径:{}", localFileDirectory + SEPARATOR + rcvFileName);
			sf.download(downloadDirectory, rcvFileName, localFileDirectory + SEPARATOR + rcvFileName, sftp);
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e);
		} finally {
			sf.disconnect(sftp);
		}
		return localFileDirectory + SEPARATOR + rcvFileName;
	}
	
	@Override
	public String convertToStandardReconciliationFile(String targetFilePath, String fileSavePath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
		return null;
	}

}
