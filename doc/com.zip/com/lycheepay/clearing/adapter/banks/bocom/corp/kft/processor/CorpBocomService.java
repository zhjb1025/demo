package com.lycheepay.clearing.adapter.banks.bocom.corp.kft.processor;

import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;
import org.dom4j.Node;
import org.soofa.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BatchPayBean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BatchPayBean.SendDetailRecord;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BatchResultQueryBean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BatchResultQueryBean.SerialRecordBean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.BocomCorpPublicHead;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.DirectPayBean;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.DirectPayBean.ReceiveDirectRecord;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.DirectPayBean.SendDirectRecord;
import com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean.ReconFile310301Bean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.net.HttpClientAgent;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P> 交行银企直连服务类 </P>
 * 
 * @author 吴高雷(13632920449)
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CORP_SERVICE)
public class CorpBocomService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;

	private static final String channelId = ChannelIdEnum.BOCOM_CORP.getCode();
	private static String line = System.getProperty("line.separator"); // 回车换行符

	/**
	 * <p> 组公共报文头 </p>
	 * 
	 * @param transCode
	 * @param bocomCorpReqSeqNo
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public BocomCorpPublicHead createSendHead(String transCode, String bocomCorpReqSeqNo,
			Map<String, String> channelParms) {
		String corpNo = channelParms.get("100001");
		String userNo = channelParms.get("100002");
		final BocomCorpPublicHead sendPublicHead = new BocomCorpPublicHead();
		sendPublicHead.setReq_tr_code(transCode);
		sendPublicHead.setReq_corp_no(corpNo);// 企业代码
		sendPublicHead.setReq_user_no(userNo);// 企业用户号
		sendPublicHead.setReq_req_no(bocomCorpReqSeqNo);// 发起方序号
		sendPublicHead.setReq_tr_acdt(DateUtil.getCurrentDate());// 交易日期（N8）
		sendPublicHead.setReq_tr_time(DateUtil.getCurrentTime());// 时间（N6）
		sendPublicHead.setReq_atom_tr_count("1");// 原子交易数（N8） 因为是实时支付所以填1
		sendPublicHead.setReq_channel("0"); // 渠道标志（C1），填0
		sendPublicHead.setReq_reserved(""); // 保留字段（C1024）
		Log4jUtil.info("组交行银企公共包头完成，交易类型为：" + transCode + "，交易的请求方流水号为：" + bocomCorpReqSeqNo);
		return sendPublicHead;
	}

	/**
	 * <p> 初始化330002、330003应答回执对象 </p>
	 * 
	 * @param dom4jxml
	 * @param recvPublicHead
	 * @author 吴高雷(13632920449)
	 */
	public void createRecvHead(Dom4jXMLMessage dom4jxml, BocomCorpPublicHead recvPublicHead) {
		final Node headNode = dom4jxml.getNode("/ap/head");
		recvPublicHead.setRec_tr_code(dom4jxml.getNodeText(headNode, "tr_code"));
		recvPublicHead.setRec_corp_no(dom4jxml.getNodeText(headNode, "corp_no"));
		recvPublicHead.setRec_req_no(dom4jxml.getNodeText(headNode, "req_no"));
		recvPublicHead.setRec_serial_no(dom4jxml.getNodeText(headNode, "serial_no"));
		recvPublicHead.setRec_ans_no(dom4jxml.getNodeText(headNode, "ans_no"));
		recvPublicHead.setRec_next_no(dom4jxml.getNodeText(headNode, "next_no"));
		recvPublicHead.setRec_tr_acdt(dom4jxml.getNodeText(headNode, "tr_acdt"));
		recvPublicHead.setRec_tr_time(dom4jxml.getNodeText(headNode, "tr_time"));
		recvPublicHead.setRec_ans_code(dom4jxml.getNodeText(headNode, "ans_code"));
		recvPublicHead.setRec_ans_info(dom4jxml.getNodeText(headNode, "ans_info"));
		recvPublicHead.setRec_particular_code(dom4jxml.getNodeText(headNode, "particular_code"));
		recvPublicHead.setRec_particular_info(dom4jxml.getNodeText(headNode, "particular_info"));
		recvPublicHead.setRec_atom_tr_count(dom4jxml.getNodeText(headNode, "atom_tr_count"));
		recvPublicHead.setRec_reserved(dom4jxml.getNodeText(headNode, "reserved"));
	}

	/**
	 * <p> 组330002报文体 </p>
	 * 
	 * @param bocomCorpReqSeqNo
	 * @param pay
	 * @param bankaccountBalance
	 * @param sendPublicHead
	 * @param channelParms
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public DirectPayBean package330002XML(String bocomCorpReqSeqNo, PayOutDTO pay,
			BankaccountBalance bankaccountBalance, BocomCorpPublicHead sendPublicHead, Map<String, String> channelParms) {
		String signType = channelParms.get("100003");// 签约类型：S-代付其他款项
		String busiNo = channelParms.get("100004");// 协议编号
		final DirectPayBean send330002 = new DirectPayBean();
		send330002.setCert_no(bocomCorpReqSeqNo);// 企业凭证号
		send330002.setPay_acno(bankaccountBalance.getAccountNo());// 付款账号
		send330002.setType(signType);// 签约类型
		send330002.setSum(1);// 总笔数---单笔实时交易只有1笔
		send330002.setSum_amt(set2Scale(pay.getAmount()));// 总金额
		send330002.setPay_month(sendPublicHead.getReq_tr_acdt().substring(0, 6));// 月份
		if (StringUtils.isNotBlank(pay.getOrderNote()))
			send330002.setSummary(StringUtils.substring(pay.getOrderNote(), 0, 60));// 附言
		send330002.setBusi_no(busiNo);// 协议编号
		// send330002.setMailflg(mailflg);// 传票汇总标志

		DirectPayBean.SendDirectRecord detailRecord = new SendDirectRecord();
		detailRecord.setCard_no(pay.getBankCardNo());// 卡号
		detailRecord.setAcname(pay.getCardHolderName());// 户名
		if ("0".equals(pay.getBankCardType())) {// 快付通 卡类标志:0存折 1借记卡 2信用卡
			detailRecord.setCard_flag("1");// 交行 卡/折标志 0：卡 1：存折
		} else {
			detailRecord.setCard_flag("0");// 交行 卡/折标志 0：卡 1：存折
		}
		detailRecord.setAmt(set2Scale(pay.getAmount()));
		detailRecord.setBusino(bocomCorpReqSeqNo);
		send330002.setDetailRecord(detailRecord);
		return send330002;
	}

	/**
	 * <p> 组330003报文体 </p>
	 * 
	 * @param channelBatchId
	 * @param billnoSns
	 * @param bankaccountBalance
	 * @param sendPublicHead
	 * @param channelParms
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public BatchPayBean package330003XML(String channelBatchId, List<BillnoSn> billnoSns,
			BankaccountBalance bankaccountBalance, BocomCorpPublicHead sendPublicHead, Map<String, String> channelParms) {
		String signType = channelParms.get("100003");
		String busiNo = channelParms.get("100004");

		BatchPayBean send330003 = new BatchPayBean();
		List<SendDetailRecord> sendDetailRecordList = new ArrayList<SendDetailRecord>(billnoSns.size());
		BatchPayBean.SendDetailRecord detailRecord = null;
		BigDecimal totalAmount = new BigDecimal("0");
		for (Iterator<BillnoSn> iterator = billnoSns.iterator(); iterator.hasNext();) {
			BillnoSn bill = iterator.next();
			detailRecord = new SendDetailRecord();
			detailRecord.setCard_no(bill.getOtheracctno());
			detailRecord.setAcname(bill.getOtheracctname());
			if ("0".equals(bill.getBankCardType())) {// 快付通 卡类标志:0存折 1借记卡 2信用卡
				detailRecord.setCard_flag("1");// 交行 卡/折标志 0：卡 1：存折
			} else {
				detailRecord.setCard_flag("0");// 交行 卡/折标志 0：卡 1：存折
			}
			detailRecord.setAmt(set2Scale(bill.getAmount()));
			detailRecord.setBusino(bill.getBankSendSn());
			totalAmount = totalAmount.add(bill.getAmount());
			sendDetailRecordList.add(detailRecord);
		}
		send330003.setCert_no(channelBatchId);// 企业凭证号
		send330003.setPay_acno(bankaccountBalance.getAccountNo());// 付款账号
		send330003.setType(signType);// 签约类型
		send330003.setSum(String.valueOf(billnoSns.size()));// 总笔数
		send330003.setSum_amt(set2Scale(totalAmount));// 总金额
		send330003.setPay_month(sendPublicHead.getReq_tr_acdt().substring(0, 6));// 月份
		// send330003.setSummary(summary);// 附言
		send330003.setBusi_no(busiNo);// 协议编号
		send330003.setRecordList(sendDetailRecordList);
		return send330003;
	}

	public String set2Scale(BigDecimal d) {
		return d.setScale(2, BigDecimal.ROUND_HALF_UP).toString();
	}
	/**
	 * 
	 * <p> 组装【查询批量代付结果】报文体 </p>
	 * 
	 * @param bankSendSn 批次号(即：企业凭证号)
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public BatchResultQueryBean package310200XML(String bankSendSn) {
		BatchResultQueryBean send310200 = new BatchResultQueryBean();
		send310200.setOgl_serial_no(bankSendSn);// 原流水号
		send310200.setQuery_flag("1");// 查询标志：流水号类型 ‘1’：原流水号为企业凭证号
		return send310200;
	}

	/**
	 * <p> 组装【银企对账-310301】报文体 </p>
	 * 
	 * @param accountNo
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public ReconFile310301Bean package310301XML(String accountNo, String settleDate) {
		ReconFile310301Bean send310301 = new ReconFile310301Bean();
		send310301.setAcno(accountNo);// 账号
		send310301.setStartDate(settleDate);// 开始日期
		send310301.setEndDate(settleDate);// 结束日期
		return send310301;
	}

	/**
	 * <p> 创建330002报文 </p>
	 * 
	 * @param sendPublicHead
	 * @param send330002
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public String create330002XML(BocomCorpPublicHead sendPublicHead, DirectPayBean send330002) {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("ap");// 创建名称为“ap”根节点
		final Element rootElement = dom4jxml.getRoot();// 获取根目录节点

		// 为根节点添加名称为“head”的子节点，其他以此类推
		final Element headElement = dom4jxml.addNode(rootElement, "head", "");
		dom4jxml.addNode(headElement, "tr_code", sendPublicHead.getReq_tr_code());
		dom4jxml.addNode(headElement, "corp_no", sendPublicHead.getReq_corp_no());
		dom4jxml.addNode(headElement, "user_no", sendPublicHead.getReq_user_no());
		dom4jxml.addNode(headElement, "req_no", sendPublicHead.getReq_req_no());
		dom4jxml.addNode(headElement, "tr_acdt", sendPublicHead.getReq_tr_acdt());
		dom4jxml.addNode(headElement, "tr_time", sendPublicHead.getReq_tr_time());
		dom4jxml.addNode(headElement, "atom_tr_count", sendPublicHead.getReq_atom_tr_count());
		dom4jxml.addNode(headElement, "channel", sendPublicHead.getReq_channel());
		dom4jxml.addNode(headElement, "reserved", sendPublicHead.getReq_reserved());

		// 为根节点添加名称为“body”的子节点，其他以此类推
		final Element bodyElement = dom4jxml.addNode(rootElement, "body", "");
		dom4jxml.addNode(bodyElement, "cert_no", send330002.getCert_no());
		dom4jxml.addNode(bodyElement, "pay_acno", send330002.getPay_acno());
		dom4jxml.addNode(bodyElement, "type", send330002.getType());
		dom4jxml.addNode(bodyElement, "sum", String.valueOf(send330002.getSum()));
		dom4jxml.addNode(bodyElement, "sum_amt", send330002.getSum_amt());
		dom4jxml.addNode(bodyElement, "pay_month", send330002.getPay_month());
		dom4jxml.addNode(bodyElement, "summary", send330002.getSummary());
		dom4jxml.addNode(bodyElement, "busi_no", send330002.getBusi_no());
		dom4jxml.addNode(bodyElement, "mailflg", send330002.getMailflg());

		final Element tran = dom4jxml.addNode(bodyElement, "tran", "");
		final Element rcd = dom4jxml.addNode(tran, "rcd", "");
		dom4jxml.addNode(rcd, "card_no", send330002.getDetailRecord().getCard_no());
		dom4jxml.addNode(rcd, "acname", send330002.getDetailRecord().getAcname());
		dom4jxml.addNode(rcd, "card_flag", send330002.getDetailRecord().getCard_flag());
		dom4jxml.addNode(rcd, "amt", send330002.getDetailRecord().getAmt());
		dom4jxml.addNode(rcd, "busino", send330002.getDetailRecord().getBusino());
		return dom4jxml.getRoot().asXML();
	}

	/**
	 * <p> 创建330003报文 </p>
	 * 
	 * @param sendPublicHead
	 * @param send330003
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public String create330003XML(BocomCorpPublicHead sendPublicHead, BatchPayBean send330003) {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("ap");// 创建名称为“ap”根节点
		final Element rootElement = dom4jxml.getRoot();// 获取根目录节点

		// 为根节点添加名称为“head”的子节点，其他以此类推
		final Element headElement = dom4jxml.addNode(rootElement, "head", "");
		dom4jxml.addNode(headElement, "tr_code", sendPublicHead.getReq_tr_code());
		dom4jxml.addNode(headElement, "corp_no", sendPublicHead.getReq_corp_no());
		dom4jxml.addNode(headElement, "user_no", sendPublicHead.getReq_user_no());
		dom4jxml.addNode(headElement, "req_no", sendPublicHead.getReq_req_no());
		dom4jxml.addNode(headElement, "tr_acdt", sendPublicHead.getReq_tr_acdt());
		dom4jxml.addNode(headElement, "tr_time", sendPublicHead.getReq_tr_time());
		dom4jxml.addNode(headElement, "atom_tr_count", sendPublicHead.getReq_atom_tr_count());
		dom4jxml.addNode(headElement, "channel", sendPublicHead.getReq_channel());
		dom4jxml.addNode(headElement, "reserved", sendPublicHead.getReq_reserved());

		// 为根节点添加名称为“body”的子节点，其他以此类推
		final Element bodyElement = dom4jxml.addNode(rootElement, "body", "");
		dom4jxml.addNode(bodyElement, "cert_no", send330003.getCert_no());
		dom4jxml.addNode(bodyElement, "pay_acno", send330003.getPay_acno());
		dom4jxml.addNode(bodyElement, "type", send330003.getType());
		dom4jxml.addNode(bodyElement, "sum", String.valueOf(send330003.getSum()));
		dom4jxml.addNode(bodyElement, "sum_amt", send330003.getSum_amt());
		dom4jxml.addNode(bodyElement, "pay_month", send330003.getPay_month());
		dom4jxml.addNode(bodyElement, "summary", send330003.getSummary());
		dom4jxml.addNode(bodyElement, "busi_no", send330003.getBusi_no());
		final Element tran = dom4jxml.addNode(bodyElement, "tran", "");
		for (int i = 0; i < send330003.getRecordList().size(); i++) {
			final Element rcd = dom4jxml.addNode(tran, "rcd", "");
			dom4jxml.addNode(rcd, "card_no", send330003.getRecordList().get(i).getCard_no());
			dom4jxml.addNode(rcd, "acname", send330003.getRecordList().get(i).getAcname());
			dom4jxml.addNode(rcd, "card_flag", send330003.getRecordList().get(i).getCard_flag());
			dom4jxml.addNode(rcd, "amt", send330003.getRecordList().get(i).getAmt());
			dom4jxml.addNode(rcd, "busino", send330003.getRecordList().get(i).getBusino());
		}
		return dom4jxml.getRoot().asXML();
	}

	/**
	 * <p> 创建310200报文 </p>
	 * 
	 * @param sendPublicHead
	 * @param send310200
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public String create310200XML(BocomCorpPublicHead sendPublicHead, BatchResultQueryBean send310200) {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("ap");// 创建名称为“ap”根节点
		final Element rootElement = dom4jxml.getRoot();// 获取根目录节点

		// 为根节点添加名称为“head”的子节点，其他以此类推
		final Element headElement = dom4jxml.addNode(rootElement, "head", "");
		dom4jxml.addNode(headElement, "tr_code", sendPublicHead.getReq_tr_code());
		dom4jxml.addNode(headElement, "corp_no", sendPublicHead.getReq_corp_no());
		dom4jxml.addNode(headElement, "user_no", sendPublicHead.getReq_user_no());
		dom4jxml.addNode(headElement, "req_no", sendPublicHead.getReq_req_no());
		dom4jxml.addNode(headElement, "tr_acdt", sendPublicHead.getReq_tr_acdt());
		dom4jxml.addNode(headElement, "tr_time", sendPublicHead.getReq_tr_time());
		dom4jxml.addNode(headElement, "atom_tr_count", sendPublicHead.getReq_atom_tr_count());
		dom4jxml.addNode(headElement, "channel", sendPublicHead.getReq_channel());
		dom4jxml.addNode(headElement, "reserved", sendPublicHead.getReq_reserved());

		// 为根节点添加名称为“body”的子节点，其他以此类推
		final Element bodyElement = dom4jxml.addNode(rootElement, "body", "");
		dom4jxml.addNode(bodyElement, "ogl_serial_no", send310200.getOgl_serial_no());
		dom4jxml.addNode(bodyElement, "query_flag", send310200.getQuery_flag());
		return dom4jxml.getRoot().asXML();
	}

	/**
	 * <p> 创建310301报文 </p>
	 * 
	 * @param sendPublicHead
	 * @param send310301
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public String create310301XML(BocomCorpPublicHead sendPublicHead, ReconFile310301Bean send310301) {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("ap");// 创建名称为“ap”根节点
		final Element rootElement = dom4jxml.getRoot();// 获取根目录节点

		// 为根节点添加名称为“head”的子节点，其他以此类推
		final Element headElement = dom4jxml.addNode(rootElement, "head", "");
		dom4jxml.addNode(headElement, "tr_code", sendPublicHead.getReq_tr_code());
		dom4jxml.addNode(headElement, "corp_no", sendPublicHead.getReq_corp_no());
		dom4jxml.addNode(headElement, "user_no", sendPublicHead.getReq_user_no());
		dom4jxml.addNode(headElement, "req_no", sendPublicHead.getReq_req_no());
		dom4jxml.addNode(headElement, "tr_acdt", sendPublicHead.getReq_tr_acdt());
		dom4jxml.addNode(headElement, "tr_time", sendPublicHead.getReq_tr_time());
		dom4jxml.addNode(headElement, "atom_tr_count", sendPublicHead.getReq_atom_tr_count());
		dom4jxml.addNode(headElement, "channel", sendPublicHead.getReq_channel());
		dom4jxml.addNode(headElement, "reserved", sendPublicHead.getReq_reserved());

		// 为根节点添加名称为“body”的子节点，其他以此类推
		final Element bodyElement = dom4jxml.addNode(rootElement, "body", "");
		dom4jxml.addNode(bodyElement, "acno", send310301.getAcno());
		dom4jxml.addNode(bodyElement, "start_date", send310301.getStartDate());
		dom4jxml.addNode(bodyElement, "end_date", send310301.getEndDate());
		return dom4jxml.getRoot().asXML();
	}

	/**
	 * <p> 初始化330002应答回执对象 </p>
	 * 
	 * @param dom4jxml
	 * @param recvPublicHead
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public DirectPayBean create330002RecvBody(Dom4jXMLMessage dom4jxml, BocomCorpPublicHead recvPublicHead) {
		createRecvHead(dom4jxml, recvPublicHead);
		final Node bodyNode = dom4jxml.getNode("/ap/body/tran/rcd");
		String netFlow = null;
		if (bodyNode != null) {
			netFlow = dom4jxml.getNodeText(bodyNode, "flw");// 网银流水号
		}

		ReceiveDirectRecord receiveDirectRecord = new ReceiveDirectRecord();
		receiveDirectRecord.setNetFlow(netFlow);

		DirectPayBean recv330002 = new DirectPayBean();
		recv330002.setReceDirectRecord(receiveDirectRecord);
		return recv330002;
	}

	/**
	 * <p> 初始化310200应答回执对象 </p>
	 * 
	 * @param dom4jxml
	 * @param recvPublicHead
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public BatchResultQueryBean create310200RecvBody(Dom4jXMLMessage dom4jxml, BocomCorpPublicHead recvPublicHead) {
		createRecvHead(dom4jxml, recvPublicHead);
		final Node bodyNode = dom4jxml.getNode("/ap/body");
		int recordNum = 0;
		int fieldNum = 0;
		String serialRecordStr = null;
		if (bodyNode != null) {
			recordNum = Integer.parseInt(dom4jxml.getNodeText(bodyNode, "record_num"));// 记录数
			fieldNum = Integer.parseInt(dom4jxml.getNodeText(bodyNode, "field_num"));// 字段数
			serialRecordStr = dom4jxml.getNodeText(bodyNode, "serial_record");// 带中文域名的多域串
		}
		// String fileFlag = dom4jxml.getNodeText(bodyNode, "file_flag");// 文件标志
		// ：1-文件 0-数据包,这里用0
		List<SerialRecordBean> serialRecordBeanList = new ArrayList<SerialRecordBean>(recordNum);
		SerialRecordBean serialRecordBean;
		if (StringUtils.isNotBlank(serialRecordStr)) {
			String[] msgArr = StringUtils.splitPreserveAllTokens(serialRecordStr, "|");
			for (int i = fieldNum; i < msgArr.length - 1; i += fieldNum) {
				serialRecordBean = new SerialRecordBean();
				serialRecordBean.setCorpNo(msgArr[i]);
				serialRecordBean.setOwnedMonth(msgArr[i + 1]);
				serialRecordBean.setPayerAccountNo(msgArr[i + 2]);
				serialRecordBean.setCoreDate(msgArr[i + 3]);
				serialRecordBean.setBatchNo(msgArr[i + 4]);
				serialRecordBean.setSerialId(msgArr[i + 5]);
				serialRecordBean.setPayerHolderName(msgArr[i + 6]);
				serialRecordBean.setPayerCcy(msgArr[i + 7]);
				serialRecordBean.setBusinessType(msgArr[i + 8]);
				serialRecordBean.setPayerAmt(msgArr[i + 9]);
				serialRecordBean.setPayeeAccountNo(msgArr[i + 10]);
				serialRecordBean.setPayeeHolderName(msgArr[i + 11]);
				serialRecordBean.setStatus(msgArr[i + 12]);
				serialRecordBean.setErrorReason(msgArr[i + 13]);
				serialRecordBean.setBusinessNo(msgArr[i + 14]);
				serialRecordBeanList.add(serialRecordBean);
			}
		}

		BatchResultQueryBean recv310200 = new BatchResultQueryBean();
		recv310200.setField_num(String.valueOf(fieldNum));
		recv310200.setRecord_num(String.valueOf(recordNum));
		// recv310200.setFile_flag("0");
		recv310200.setSerialRecordBeanList(serialRecordBeanList);
		return recv310200;
	}

	/**
	 * <p> 初始化310301应答回执对象 </p>
	 * 
	 * @param dom4jxml
	 * @param recvPublicHead
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public ReconFile310301Bean create310301RecvBody(Dom4jXMLMessage dom4jxml) {
		final Node bodyNode = dom4jxml.getNode("/ap/body");
		int recordNum = 0;
		int fieldNum = 0;
		String serialRecordStr = null;
		String fileFlag = null;
		if (bodyNode != null) {
			recordNum = Integer.parseInt(dom4jxml.getNodeText(bodyNode, "record_num"));// 记录数
			fieldNum = Integer.parseInt(dom4jxml.getNodeText(bodyNode, "field_num"));// 字段数
			serialRecordStr = dom4jxml.getNodeText(bodyNode, "serial_record");// 带中文域名的多域串
			fileFlag = dom4jxml.getNodeText(bodyNode, "file_flag");// 文件标志// ：1-文件 , 0-数据包
		}

		ReconFile310301Bean recv310301 = new ReconFile310301Bean();
		List<ReconFile310301Bean.SerialRecord> serialRecordList = new ArrayList<ReconFile310301Bean.SerialRecord>(
				recordNum);
		ReconFile310301Bean.SerialRecord serialRecord;
		if (StringUtils.isNotBlank(serialRecordStr)) {
			String[] msgArr = StringUtils.splitPreserveAllTokens(serialRecordStr, "|");
			for (int i = fieldNum; i < msgArr.length - 1; i = i + fieldNum) {
				serialRecord = new ReconFile310301Bean.SerialRecord();
				serialRecord.setStatus(msgArr[i]);
				serialRecord.setTransDate(msgArr[i + 1]);
				serialRecord.setTransTime(msgArr[i + 2]);
				serialRecord.setBusinessType(msgArr[i + 3]);
				serialRecord.setSerialNo(msgArr[i + 4]);
				serialRecord.setSerialSeqNo(msgArr[i + 5]);
				serialRecord.setAccountNo(msgArr[i + 6]);
				serialRecord.setAccountName(msgArr[i + 7]);
				serialRecord.setInOrOutFlag(msgArr[i + 8]);
				serialRecord.setCcy(msgArr[i + 9]);
				serialRecord.setAmt(msgArr[i + 10]);
				serialRecord.setBalance(msgArr[i + 11]);
				serialRecord.setBalance(msgArr[i + 12]);
				serialRecord.setOtherAccountNo(msgArr[i + 13]);
				serialRecord.setOtherAccountName(msgArr[i + 14]);
				serialRecord.setOtherAddress(msgArr[i + 15]);
				serialRecord.setOtherOpenBankNo(msgArr[i + 16]);
				serialRecord.setOtherOpenBankName(msgArr[i + 17]);
				serialRecord.setBillType(msgArr[i + 18]);
				serialRecord.setBillNo(msgArr[i + 19]);
				serialRecord.setBillName(msgArr[i + 20]);
				serialRecord.setBillSignDate(msgArr[i + 21]);
				serialRecord.setNote(msgArr[i + 22]);
				serialRecord.setRemark(msgArr[i + 23]);
				serialRecordList.add(serialRecord);
			}
		}

		recv310301.setFieldNum(String.valueOf(fieldNum));
		recv310301.setRecordNum(String.valueOf(recordNum));
		recv310301.setFileFlag(fileFlag);
		recv310301.setFileName("");
		recv310301.setSerialRecordList(serialRecordList);
		return recv310301;
	}

	/**
	 * <p> http方式发送报文并接收应答 </p>
	 * 
	 * @param channelParms
	 * @param sendXML
	 * @return
	 * @throws BizException
	 * @author 吴高雷(13632920449)
	 */
	public Dom4jXMLMessage httpSendAndReceive(Map<String, String> channelParms, String sendXML) throws BizException {
		String httpIp = channelParms.get("100005");
		String httpPort = channelParms.get("100006");
		String httpUrl = channelParms.get("100007");
		Log4jUtil.info("httpIp:{},httpPort:{},httpUrl:{}", httpIp, httpPort, httpUrl);
		Log4jUtil.info("sendXML:{}", sendXML);
		HttpClientAgent httpClientAgent = null;
		Dom4jXMLMessage dom4jxml = null;
		try {
			httpClientAgent = new HttpClientAgent(httpIp, Integer.valueOf(httpPort));// 建立http连接，并获取连接对象
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
		}
		try {
			httpClientAgent.postUrl(httpUrl, sendXML, "application/xml", "gbk");
			String responseBody = new String(httpClientAgent.getResponseBody(), Charset.forName("GBK"));
			Log4jUtil.info("responseBody:{}", responseBody);
			dom4jxml = Dom4jXMLMessage.parse(responseBody.getBytes());// 获取并解析银行回执
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		} finally {
			if (httpClientAgent != null) {
				httpClientAgent.releaseConnection();// 释放http连接
			}
		}
		return dom4jxml;
	}

	/**
	 * <p> 根据回执组ReturnState </p>
	 * 
	 * @param channelId
	 * @param billnoSn
	 * @param recvPublicHead
	 * @param receiveDirectPayBean
	 * @return
	 * @author 吴高雷(13632920449)
	 */
	public ReturnState get330002ReturnState(BillnoSn billnoSn, BocomCorpPublicHead recvPublicHead,
			DirectPayBean receiveDirectPayBean) {

		ChannelRtncode channelRtncode = null;
		ReturnState returnState = new ReturnState();
		returnState.setCheckDate(DateUtil.getCurrentDate());
		// 渠道返回码
		if (StringUtil.isBlank(recvPublicHead.getRec_particular_code())) {
			returnState.setChannelCode(TransReturnCode.code_9109);
		} else {
			channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, recvPublicHead
					.getRec_particular_code()));
			if (null == channelRtncode) {
				// returnState.setChannelCode(TransReturnCode.code_9900);
				// 代付结果码未知做成功处理
				returnState.setChannelCode(TransReturnCode.code_9109);
			} else {
				returnState.setChannelCode(channelRtncode.getKftRtncode());
			}
		}
		// 根据渠道返回码判断交易状态
		if (TransReturnCode.code_0000.equals(returnState.getChannelCode())) {
			returnState.setReturnState(PayState.SUCCEED_STR);
		} else if (TransReturnCode.code_9109.equals(returnState.getChannelCode())) {
			returnState.setReturnState(PayState.UNKNOW_STR);
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		// 渠道返回交易结果描述信息
		returnState.setBankRetCode(recvPublicHead.getRec_particular_code());
		if (StringUtil.isBlank(recvPublicHead.getRec_particular_info()) && channelRtncode != null) {
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
		} else {
			returnState.setReturnMsg(recvPublicHead.getRec_particular_info());
		}
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		returnState.setSn(billnoSn.getSn());
		returnState.setRelTranAmount(billnoSn.getAmount());
		returnState.setBankPostScript(recvPublicHead.getRec_particular_info());
		returnState.setCreditNo(receiveDirectPayBean.getReceDirectRecord().getNetFlow());
		return returnState;
	}

	/**
	 * <p> 根据回执组ReturnState </p>
	 * 
	 * @param recvPublicHead
	 * @param recv310200
	 * @author 吴高雷(13632920449)
	 */
	public ReturnState get310200ReturnState(BocomCorpPublicHead recvPublicHead, BatchResultQueryBean recv310200) {
		ReturnState returnState = new ReturnState();
		// 代付状态查询：0 未入账，3 可疑 --未知 F 入账成功 --成功 E 入账失败 --失败
		if (recv310200.getSerialRecordBeanList().size() > 0) {
			if ("E".equals(recv310200.getSerialRecordBeanList().get(0).getStatus())) {
				returnState.setReturnState(PayState.FAILED_STR);
			} else if ("F".equals(recv310200.getSerialRecordBeanList().get(0).getStatus())) {
				returnState.setReturnState(PayState.SUCCEED_STR);
			} else {
				returnState.setReturnState(PayState.UNKNOW_STR);
			}
		} else {
			returnState.setReturnState(PayState.UNKNOW_STR);
		}

		returnState.setCheckDate(DateUtil.getCurrentDate());
		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, recvPublicHead
				.getRec_particular_code()));
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9109);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		}
		returnState.setReturnMsg(recvPublicHead.getRec_particular_info());
		return returnState;
	}

	/**
	 * <p> 保存或更新单笔交易记录到billno_sn表 </p>
	 * 
	 * @param bocomCorpReqSeqNo 银行订单号
	 * @param param 交易参数
	 * @param returnState 返回状态 bean
	 * @param flag 保存更新标志 0保存记录 ； 1更新记录
	 * @return
	 * @throws BizException
	 * @author 吴高雷(13632920449)
	 */
	public BillnoSn saveOrUpdateBillnoSn(final String bocomCorpReqSeqNo, final Param param,
			final ReturnState returnState, final int flag) throws BizException {
		Log4jUtil.info("____________________新增或更新单笔交易记录到billno_sn表 saveOrUpdateBillnoSn 9.6____________________");
		BillnoSn billnoSn = new BillnoSn();
		if (flag == 0) { // 业务发送到银行前，保存记录到 billno_sn 表
			billnoSn = billnoSnService.saveBillnoSn(bocomCorpReqSeqNo, param);
		} else if (flag == 1) { // 业务发送成功后更新 billno_sn 表
			billnoSnService.updateBillnoSn(param, returnState, bocomCorpReqSeqNo);
		}
		Log4jUtil.info(line + "新增或更新单笔交易记录到billno_sn表完成");
		return billnoSn;
	}

	/**
	 * <p> 处理批量交易查询结果 </p>
	 * 
	 * @param detailMsgs
	 * @throws BizException
	 * @author 吴高雷(13632920449)
	 */
	public void batchDetailProcess(final List<SerialRecordBean> detailMsgs) throws BizException {
		if (detailMsgs.size() > 0) {
			BillnoSn billnoSn = null;
			// 统计合计数据，用于保存到 表
			Long sucessnum = 0L; // 成功总笔数
			BigDecimal sucessamount = BigDecimal.ZERO; // 成功总金额
			Long unsucessnum = 0L; // 失败总笔数
			BigDecimal unsucessamount = BigDecimal.ZERO; // 失败总金额
			String channelRtncode;
			String channelRtnnote;
			List<BillnoSn> batchResultBillnoSnList = new ArrayList<BillnoSn>(detailMsgs.size());
			for (SerialRecordBean detailMsg : detailMsgs) {
				final String bankSendSn = detailMsg.getBusinessNo();// 业务编号
				billnoSn = billnoSnService.getBillnoSn(channelId, bankSendSn);
				if (billnoSn == null) {
					Log4jUtil.error("在表 billnoSn 中找不到批量返回的交易记录，交易记录详细信息如下：" + "渠道ID：" + channelId + "渠道支付交易流水："
							+ bankSendSn + "交易金额：" + String.valueOf(detailMsg.getPayerAmt()));
					continue;
				}
				// 给 ChannelBatch 表做记录汇总
				if ("E".equals(detailMsg.getStatus())) {// E :入账失败
					channelRtncode = TransReturnCode.code_9900;
					channelRtnnote = detailMsg.getErrorReason();
					unsucessnum = unsucessnum + 1; // 失败总笔数
					unsucessamount = unsucessamount.add(new BigDecimal(detailMsg.getPayerAmt())); // 失败总金额
					billnoSn.setPayState(String.valueOf(PayState.TxnStatus.FAILED));// 失败2
				} else {// F:入账成功 对于批量代付其他状态(0：未入账 和 3：可疑)都当成功
					channelRtncode = TransReturnCode.code_0000;
					channelRtnnote = "S-成功";
					sucessnum = sucessnum + 1; // 成功总笔数
					sucessamount = sucessamount.add(new BigDecimal(detailMsg.getPayerAmt())); // 成功总金额
					billnoSn.setPayState(String.valueOf(PayState.TxnStatus.SUCCEED));// 成功1
				}
				billnoSn.setChannelRtncode(channelRtncode); // 渠道返回码
				billnoSn.setChannelRtnnote(channelRtnnote); // 渠道返回附言
				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
				billnoSn.setRecvTime(new Date()); // 返回时间
				billnoSn.setActualAmount(new BigDecimal(detailMsg.getPayerAmt())); // 渠道实际支付金额
				batchResultBillnoSnList.add(billnoSn);
			}
			if (batchResultBillnoSnList.size() > 0) {
				billnoSnService.batchUpdate(batchResultBillnoSnList);// 批量更新billnoSn流水表
			}
			// b3.更新ChannelBatch多个字段
			batchProcessResultNotice.process(channelId, billnoSn.getChannelBatchno(), billnoSn.getTranType(),
					sucessnum, sucessamount.doubleValue(), unsucessnum, unsucessamount.doubleValue());
		} else {
			Log4jUtil.info("未发现【批量交易】查询结果数据");
		}
	}
}
