/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.bocom.http;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.IOUtils;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.bocom.netpay.b2cAPI.BOCOMB2CClient;
import com.bocom.netpay.b2cAPI.BOCOMB2COPReply;
import com.bocom.netpay.b2cAPI.OpResult;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.bocom.http.b2c.kft.processor.BocomB2CDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交通银行B2C/B2B对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.BOCOM_HTTP_RECONCILIATION_FILE_SERVICE)
public class BocomHttpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_B2C_DIRECT_PROCESS)
	private BocomB2CDirectProcess bocomB2CDirectProcess;

	private static String channelId = ChannelIdEnum.BOCOM_B2C.getCode();

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOCOM", "httpCheck");
		Log4jUtil.info("进入交行网银对账处理。传进文件保存路径参数为:[{}],渠道ID为:[{}]对账日期为:[{}]", fileSavePath, channelId, settleDate);
		AssertUtils.notNull(channelId, TransReturnCode.code_9108, "渠道ID");
		AssertUtils.notNull(fileSavePath, TransReturnCode.code_9108, "对账文件保存路径");
		final String reconciliationDate = ReconciliationFileUtil.checkSettleDate(settleDate, "");
		Log4jUtil.info("本次对账日期为：{}", reconciliationDate);
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		// 用交行网银下载对账单
		try{
			String fileFullPathName = downFile(settleDate);

			reconciliationFileDTOList = buildTransactionDataList("bocom",
					fileFullPathName, channelId, settleDate);
		}catch(Exception e){
			Log4jUtil.error(e);
		}

		Log4jUtil.info("生成统一格式对账文件");

		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				reconciliationDate, reconciliationFileDTOList);
		return fileFullPath;
	}

	private String downFile(String settleDate) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String checkFilePath = channelParms.get("300005");
		String filepath = checkFilePath + settleDate + File.separatorChar + DateUtil.getCurrentDateTime();
		BOCOMB2CClient client = bocomB2CDirectProcess.getClient();
		if (client == null) {  // 初始化失败
			throw new BizException("初始化失败");
		} else {
			BOCOMB2COPReply rep = client.downLoadSettlement(settleDate, "UTF-8");// 对帐单下载
			if (rep == null) {
				String err = client.getLastErr();
				throw new BizException("交易错误信息：" + err);
			} else {
				String code = rep.getRetCode(); // 得到交易返回码
				String msg = rep.getErrorMessage();
				Log4jUtil.info("交易返回码：" + code);
				Log4jUtil.info("交易错误信息：" + msg);
				if ("0".equals(code)) {// 表示交易成功
					OpResult opr = rep.getOpResult();
					String totalSum = opr.getValueByName("totalSum"); // 总金额
					String totalNumber = opr.getValueByName("totalNumber"); // 总笔数
					String totalFee = opr.getValueByName("totalFee"); // 总手续费BOCOM_B2C_Settlement_20140701
					String settlementFile = opr.getValueByName("settlementFile"); // 对帐文件内容
					File file = new File(filepath);
					try {
						FileUtils.writeStringToFile(file, settlementFile, "UTF-8");
					} catch (IOException e) {
						throw new BizException(e);
					}
					Log4jUtil.info("总金额：{},总笔数：{},总手续费：{}", totalSum, totalNumber, totalFee);
				}
			}
		}
		return filepath;
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param targetFilePath 对账目标文件路径
	 * @param channelId 渠道ID
	 * @param reconciliationDate 对账日期
	 * @author 李斌(13665100450)
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String targetFilePath,
			final String channelId, final String reconciliationDate) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();

		File file = new File(targetFilePath);
		if (!file.exists())
			return reconciliationFileDTOList;
		BufferedReader bufferedReader = null;
		try {
			final InputStreamReader reader = new InputStreamReader(new FileInputStream(file));
			bufferedReader = new BufferedReader(reader);
		} catch (final FileNotFoundException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.FILE_NOT_FOUND, "错误：找不到" + logPrefix + "对账文件："
					+ targetFilePath, e);
		}
		try {// 循环对文本逐行处理
			int currLine = 0;
			String data = null;
			int i = 0; // 保存 对账记录数
			while ((data = bufferedReader.readLine()) != null) {
				currLine++; // 对账文件 行循环
				Log4jUtil.info(logPrefix + "对账文件第" + currLine + "行文件内容为：" + data);
				if (data.trim().startsWith("4114")) {
					final ReconciliationFileDTO accBean = new ReconciliationFileDTO();
					// 定长，格式如下
					// 消费
					// 23/11/20/19/11/20 /15 /18/12
					// 23 34 54 73 84 104 119 137 148
					// 订单号 订单日期 交易日期-时间 支付流水号 卡类型 交易金额 商户手续费 实际结算金额 商户批次号
					final String bankSendSn = data.substring(2, 22); // 订单号
					final String checkDate = data.substring(25, 33);
					final String strTradeAmount = data.substring(85, 102); // 订单金额
					final BigDecimal tradeAmount = new BigDecimal(strTradeAmount.trim()); // 订单金额
					accBean.setCheckDate(checkDate);
					accBean.setBankSendId(bankSendSn); // 订单号
					accBean.setTransDate(checkDate); // 交易日期
					accBean.setAmount(tradeAmount);// 交易金额
					accBean.setBankTransState("00");
					accBean.setPayGet(STR_GET);
					accBean.setChannelId(channelId);
					i++;
					String logMsg = logPrefix + "将对账文件中第" + currLine + "行数据构造accBean，添加到accBeanList的第" + i + "条记录:";
					logMsg = logMsg + " checkDate:" + accBean.getCheckDate() + " BankSendSn:" + accBean.getBankSendId();
					logMsg = logMsg + " TranDate:" + accBean.getTransDate() + " TradeAmount:" + accBean.getAmount();
					Log4jUtil.info(logMsg);
					reconciliationFileDTOList.add(accBean);
				} else if (data.trim().startsWith("20")) {
					final ReconciliationFileDTO accBean = new ReconciliationFileDTO();
					// 定长，格式如下
					// 消费
					// 23/11/20/19/11/20 /15 /18/12
					// 23 34 54 73 84 104 119 137 148
					// 订单号 订单日期 交易日期-时间 支付流水号 卡类型 交易金额 商户手续费 实际结算金额 商户批次号
					final String originalTxnId = data.substring(73, 94); // 原始订单号
					final String strTradeAmount = data.substring(56, 70); // 订单金额
					final BigDecimal tradeAmount = new BigDecimal(strTradeAmount.trim()); // 订单金额
					accBean.setCheckDate(reconciliationDate);
					accBean.setTransDate(reconciliationDate); // 交易日期
					accBean.setAmount(tradeAmount);// 交易金额
					accBean.setBankTransState("00");
					accBean.setPayGet(STR_PAY);
					accBean.setChannelId(channelId);
					accBean.setOriginalTxnId(originalTxnId);
					i++;
					String logMsg = logPrefix + "将对账文件中第" + currLine + "行数据构造accBean，添加到accBeanList的第" + i + "条记录:";
					logMsg = logMsg + " checkDate:" + accBean.getCheckDate() + " originalTxnId:" + accBean.getOriginalTxnId();
					logMsg = logMsg + " TranDate:" + accBean.getTransDate() + " TradeAmount:" + accBean.getAmount();
					Log4jUtil.info(logMsg);
					reconciliationFileDTOList.add(accBean);
				} else {
					Log4jUtil.info("此行数据不是对账数据，跳过！");
					continue;
				}

			}
		} catch (final IOException e) {
			Log4jUtil.error(logPrefix + "IOException", e);
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix + "网银对账失败,文件:["
					+ targetFilePath + "]", e);
		} finally {
			IOUtils.closeQuietly(bufferedReader);
		}
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix,
				targetFilePath, channelId, queryDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

}
