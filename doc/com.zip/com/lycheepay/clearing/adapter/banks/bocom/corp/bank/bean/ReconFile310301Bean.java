package com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean;

import java.util.List;


/**
 * <P>银企对账(历史交易明细查询（310301）)-报文体实体类</P>
 * 
 * @author 吴高雷(13632920449)
 */
public class ReconFile310301Bean {
	// 请求
	private String acno;// 账号
	private String startDate;// 开始日期
	private String endDate;// 结束日期

	// 应答
	private String fieldNum;// 字段数
	private String recordNum;// 记录数
	private String fileFlag;// 文件标志：1-文件 0-数据包
	private String fileName;// 文件名
	private List<SerialRecord> serialRecordList;// 循环体Bean集合

	public static class SerialRecord {
		private String status;// 状态
		private String transDate;// 交易日期
		private String transTime;// 交易时间
		private String businessType;// 业务类型
		private String serialNo;// 流水号
		private String serialSeqNo;// 流水序号
		private String accountNo;// 账号
		private String accountName;// 户名
		private String inOrOutFlag;// 收支标志
		private String ccy;// 币种
		private String amt;// 交易金额
		private String balance;// 余额
		private String userfulBalance;// 可用余额
		private String otherAccountNo;// 对方账号
		private String otherAccountName;// 对方户名
		private String otherAddress;// 对方地址
		private String otherOpenBankNo;// 对方开户行行号
		private String otherOpenBankName;// 对方开户行行名
		private String billType;// 票据种类
		private String billNo;// 票据号码
		private String billName;// 票据名称
		private String billSignDate;// 票据签发日期
		private String note;// 附言
		private String remark;// 备注

		/**
		 * @return the status
		 */
		public String getStatus() {
			return status;
		}

		/**
		 * @param status the status to set
		 */
		public void setStatus(String status) {
			this.status = status;
		}

		/**
		 * @return the transDate
		 */
		public String getTransDate() {
			return transDate;
		}

		/**
		 * @param transDate the transDate to set
		 */
		public void setTransDate(String transDate) {
			this.transDate = transDate;
		}

		/**
		 * @return the transTime
		 */
		public String getTransTime() {
			return transTime;
		}

		/**
		 * @param transTime the transTime to set
		 */
		public void setTransTime(String transTime) {
			this.transTime = transTime;
		}

		/**
		 * @return the businessType
		 */
		public String getBusinessType() {
			return businessType;
		}

		/**
		 * @param businessType the businessType to set
		 */
		public void setBusinessType(String businessType) {
			this.businessType = businessType;
		}

		/**
		 * @return the serialNo
		 */
		public String getSerialNo() {
			return serialNo;
		}

		/**
		 * @param serialNo the serialNo to set
		 */
		public void setSerialNo(String serialNo) {
			this.serialNo = serialNo;
		}

		/**
		 * @return the serialSeqNo
		 */
		public String getSerialSeqNo() {
			return serialSeqNo;
		}

		/**
		 * @param serialSeqNo the serialSeqNo to set
		 */
		public void setSerialSeqNo(String serialSeqNo) {
			this.serialSeqNo = serialSeqNo;
		}

		/**
		 * @return the accountNo
		 */
		public String getAccountNo() {
			return accountNo;
		}

		/**
		 * @param accountNo the accountNo to set
		 */
		public void setAccountNo(String accountNo) {
			this.accountNo = accountNo;
		}

		/**
		 * @return the accountName
		 */
		public String getAccountName() {
			return accountName;
		}

		/**
		 * @param accountName the accountName to set
		 */
		public void setAccountName(String accountName) {
			this.accountName = accountName;
		}

		/**
		 * @return the inOrOutFlag
		 */
		public String getInOrOutFlag() {
			return inOrOutFlag;
		}

		/**
		 * @param inOrOutFlag the inOrOutFlag to set
		 */
		public void setInOrOutFlag(String inOrOutFlag) {
			this.inOrOutFlag = inOrOutFlag;
		}

		/**
		 * @return the ccy
		 */
		public String getCcy() {
			return ccy;
		}

		/**
		 * @param ccy the ccy to set
		 */
		public void setCcy(String ccy) {
			this.ccy = ccy;
		}

		/**
		 * @return the amt
		 */
		public String getAmt() {
			return amt;
		}

		/**
		 * @param amt the amt to set
		 */
		public void setAmt(String amt) {
			this.amt = amt;
		}

		/**
		 * @return the balance
		 */
		public String getBalance() {
			return balance;
		}

		/**
		 * @param balance the balance to set
		 */
		public void setBalance(String balance) {
			this.balance = balance;
		}

		/**
		 * @return the userfulBalance
		 */
		public String getUserfulBalance() {
			return userfulBalance;
		}

		/**
		 * @param userfulBalance the userfulBalance to set
		 */
		public void setUserfulBalance(String userfulBalance) {
			this.userfulBalance = userfulBalance;
		}

		/**
		 * @return the otherAccountNo
		 */
		public String getOtherAccountNo() {
			return otherAccountNo;
		}

		/**
		 * @param otherAccountNo the otherAccountNo to set
		 */
		public void setOtherAccountNo(String otherAccountNo) {
			this.otherAccountNo = otherAccountNo;
		}

		/**
		 * @return the otherAccountName
		 */
		public String getOtherAccountName() {
			return otherAccountName;
		}

		/**
		 * @param otherAccountName the otherAccountName to set
		 */
		public void setOtherAccountName(String otherAccountName) {
			this.otherAccountName = otherAccountName;
		}

		/**
		 * @return the otherAddress
		 */
		public String getOtherAddress() {
			return otherAddress;
		}

		/**
		 * @param otherAddress the otherAddress to set
		 */
		public void setOtherAddress(String otherAddress) {
			this.otherAddress = otherAddress;
		}

		/**
		 * @return the otherOpenBankNo
		 */
		public String getOtherOpenBankNo() {
			return otherOpenBankNo;
		}

		/**
		 * @param otherOpenBankNo the otherOpenBankNo to set
		 */
		public void setOtherOpenBankNo(String otherOpenBankNo) {
			this.otherOpenBankNo = otherOpenBankNo;
		}

		/**
		 * @return the otherOpenBankName
		 */
		public String getOtherOpenBankName() {
			return otherOpenBankName;
		}

		/**
		 * @param otherOpenBankName the otherOpenBankName to set
		 */
		public void setOtherOpenBankName(String otherOpenBankName) {
			this.otherOpenBankName = otherOpenBankName;
		}

		/**
		 * @return the billType
		 */
		public String getBillType() {
			return billType;
		}

		/**
		 * @param billType the billType to set
		 */
		public void setBillType(String billType) {
			this.billType = billType;
		}

		/**
		 * @return the billNo
		 */
		public String getBillNo() {
			return billNo;
		}

		/**
		 * @param billNo the billNo to set
		 */
		public void setBillNo(String billNo) {
			this.billNo = billNo;
		}

		/**
		 * @return the billName
		 */
		public String getBillName() {
			return billName;
		}

		/**
		 * @param billName the billName to set
		 */
		public void setBillName(String billName) {
			this.billName = billName;
		}

		/**
		 * @return the billSignDate
		 */
		public String getBillSignDate() {
			return billSignDate;
		}

		/**
		 * @param billSignDate the billSignDate to set
		 */
		public void setBillSignDate(String billSignDate) {
			this.billSignDate = billSignDate;
		}

		/**
		 * @return the note
		 */
		public String getNote() {
			return note;
		}

		/**
		 * @param note the note to set
		 */
		public void setNote(String note) {
			this.note = note;
		}

		/**
		 * @return the remark
		 */
		public String getRemark() {
			return remark;
		}

		/**
		 * @param remark the remark to set
		 */
		public void setRemark(String remark) {
			this.remark = remark;
		}

	}

	public String getAcno() {
		return acno;
	}

	public void setAcno(final String acno) {
		this.acno = acno;
	}

	/**
	 * @return the fieldNum
	 */
	public String getFieldNum() {
		return fieldNum;
	}

	/**
	 * @param fieldNum the fieldNum to set
	 */
	public void setFieldNum(String fieldNum) {
		this.fieldNum = fieldNum;
	}

	/**
	 * @return the recordNum
	 */
	public String getRecordNum() {
		return recordNum;
	}

	/**
	 * @param recordNum the recordNum to set
	 */
	public void setRecordNum(String recordNum) {
		this.recordNum = recordNum;
	}

	/**
	 * @return the fileFlag
	 */
	public String getFileFlag() {
		return fileFlag;
	}

	/**
	 * @param fileFlag the fileFlag to set
	 */
	public void setFileFlag(String fileFlag) {
		this.fileFlag = fileFlag;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * @return the serialRecordList
	 */
	public List<SerialRecord> getSerialRecordList() {
		return serialRecordList;
	}

	/**
	 * @param serialRecordList the serialRecordList to set
	 */
	public void setSerialRecordList(List<SerialRecord> serialRecordList) {
		this.serialRecordList = serialRecordList;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
