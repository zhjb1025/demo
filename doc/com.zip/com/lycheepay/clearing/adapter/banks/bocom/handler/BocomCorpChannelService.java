package com.lycheepay.clearing.adapter.banks.bocom.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.bocom.corp.kft.processor.CorpBocomDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>交行银企清算服务入口类</P>
 * 
 * @author 吴高雷(13632920449)
 */
@Service(ClearingAdapterAnnotationName.BOCOM_CORP_CHANNEL_SERVICE)
public class BocomCorpChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOCOM_CORP_DIRECT_PROCESS)
	private CorpBocomDirectProcess corpBocomDirectProcess;

	private static final String channelId = ChannelIdEnum.BOCOM_CORP.getCode();

	/**
	 * 单笔代付（330002）交易
	 * 
	 * @author 吴高雷(13632920449)
	 */
	@Override
	public ClearingResultDTO directPay(PayOutDTO pay) {
		Log4jUtil.setLogClass("bocomCorp", "directPay");
		Log4jUtil.info("渠道ID【{}】,交易类型【单笔/实时代付】, 开始处理 ", channelId);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		param.setSn(pay.getTxnId());
		param.setCardType(pay.getBankCardType());
		param.setBorc(pay.getAccountType());
		param.setBizBean(pay);

		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		ReturnState returnState = null;
		try {
			returnState = corpBocomDirectProcess.deal330002(param);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, channelResultDTO);
		}

		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());
		Log4jUtil.info(channelResultDTO);
		Log4jUtil.info("渠道ID【{}】,交易类型【单笔/实时代付】, 结束处理 ", channelId);
		return channelResultDTO;
	}

	/**
	 * 批量代付（330003）交易
	 * 
	 * @author 吴高雷(13632920449)
	 */
	@Override
	public BatchSendResult processBatch(String channelBatchId, List<ChannelTempBill> payList, boolean repeatSend) {
		Log4jUtil.setLogClass("bocomCorp", "processBatch");
		Log4jUtil.info("渠道ID【{}】,交易类型【批量代付交易】,渠道批次号【{}】 开始处理 ", channelId, channelBatchId);
		BatchSendResult batchSendResult = null;
		try {
			batchSendResult = corpBocomDirectProcess.processBatch(channelBatchId, payList, repeatSend);
		} catch (Exception e) {
			Log4jUtil.error("批量代付异常：", e);
			return ChannelResultUtil.exceptionToResult(e, batchSendResult);
		}
		Log4jUtil.info("渠道ID【{}】,交易类型【批量代付交易】,渠道批次号【{}】 结束处理 ", channelId, channelBatchId);
		return batchSendResult;
	}

	/**
	 * 批量交易结果查询（310200） -定时任务处理
	 * 
	 * @author 吴高雷(13632920449)
	 */
	@Override
	public void timeQueryBatchTransResult() {
		Log4jUtil.setLogClass("bocomCorp", "timeQueryBatchTransResult");
		Log4jUtil.info("渠道ID【{}】,交易类型【批量代付交易结果查询】 开始处理 ", channelId);
		try {
			corpBocomDirectProcess.batchRetProcess();
		} catch (BizException e) {
			Log4jUtil.error("批量代付交易结果查询异常：", e);
		}
		Log4jUtil.info("渠道ID【{}】,交易类型【批量代付交易结果查询】 结束处理 ", channelId);
	}

	/**
	 * 单笔交易结果查询（310200）
	 * 
	 * @author 吴高雷(13632920449)
	 */
	@Override
	public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) {
		Log4jUtil.setLogClass("bocomCorp", "querySingleRecord");
		Log4jUtil.info("渠道ID【{}】,交易类型【单笔交易结果查询】, 开始处理 ", channelId);
		ReturnState returnState = null;
		try {
			returnState = corpBocomDirectProcess.querySingleRecord(billnoSn);
		} catch (Exception e) {
			Log4jUtil.error("单笔交易结果查询异常：", e);
		}
		final ClearingResultDTO clearingResultDTO = new ClearingResultDTO();
		clearingResultDTO.setChannelId(channelId);
		clearingResultDTO.setTxnStatus(returnState.getReturnState());// 银行相应通讯状态(超时：T、成功：S、失败：F)
		clearingResultDTO.setChannelResponseCode(returnState.getChannelCode());// 渠道返回给业务层状态码
		clearingResultDTO.setChannelResponseMsg(returnState.getReturnMsg());// 渠道响应信息（响应信息描述）
		clearingResultDTO.setSettlementDate(returnState.getCheckDate());// 渠道结算日期
		Log4jUtil.info(clearingResultDTO);
		Log4jUtil.info("渠道ID【{}】,交易类型【单笔交易结果查询】 结束处理 ", channelId);
		return clearingResultDTO;
	}

	@Override
	public int getMaxNum() {
		return 500;
	}
}
