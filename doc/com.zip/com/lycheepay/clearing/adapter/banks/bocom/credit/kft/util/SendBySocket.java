package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.util;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import org.apache.commons.io.IOUtils;

import com.lycheepay.clearing.adapter.banks.bocom.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.StringUtil;


public class SendBySocket {
	private int timeout = 60000;// 单位毫秒，6000。 业务交易超时，，用于传输数据时
	private int connectOutTime = 60000;// 单位毫秒，6000。 用于刚开始建立链接时,一般不需要改变此值

	public int getConnectOutTime() {
		return connectOutTime;
	}

	public void setConnectOutTime(int connectOutTime) {
		this.connectOutTime = connectOutTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public MsgPack sendAndRecv(String socketIp, String socketPort, byte[] sendMsg) throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:" + sendMsg);
		Socket socket = connect(socketIp, socketPort);
		try {
			socket.getOutputStream().write(sendMsg);
			socket.getOutputStream().flush();
		}catch (Exception e) {
			this.disconnect(socket);
			// 发送不成功，抛错误代码为9106
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
		}
		try {
			byte[] msg = IOUtils.toByteArray(socket.getInputStream());
			MsgPack pack = new MsgPack();
			pack = unpackMsg(pack, msg, socketIp);
			return pack;
			// }
		} catch (Exception e) {
			Log4jUtil.error(e, e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
		} finally {
			this.disconnect(socket);
		}
	}

	// public MsgPack sendAndRecv(String socketIp, String socketPort, byte[] sendMsg) throws
	// BizException
	// {
	// MsgPack pack = new MsgPack();
	// byte[] msg = { 0x02, 0x01, 0x01, 0x60, 0x01, 0x00, 0x01, 0x00, 0x08, 0x30, 0x20, 0x38, 0x00,
	// (byte) 0x80, 0x02,
	// (byte) 0xf0,
	// 0x00, 0x01, (byte) 0x91, 0x00, 0x00,
	// 0x14, 0x23, (byte) 0x99, 0x10, 0x44, 0x52, 0x06, 0x06, 0x00, 0x30, 0x30, 0x37, 0x30, 0x30,
	// 0x30, 0x30,
	// 0x30, 0x30, 0x31, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32,
	// 0x32, 0x32,
	// 0x38, 0x00, 0x30, (byte) 0xca, (byte) 0xd5, (byte) 0xb5, (byte) 0xa5, (byte) 0xb2, (byte)
	// 0xe2,
	// (byte) 0xca, (byte) 0xd4, (byte) 0xc9, (byte) 0xcc, (byte) 0xbb, (byte) 0xa7, 0x2d, 0x77,
	// 0x6c, 0x20,
	// 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x08,
	// (byte) 0xcc,
	// (byte) 0xc3, 0x2a, 0x21, 0x09, (byte) 0xe8, 0x1f, (byte) 0xe3,
	// 0x67,
	// (byte) 0x88, (byte) 0x8e, (byte) 0xa4, (byte) 0x41, (byte) 0x35, (byte) 0x7f, 0x01, 0x03,
	// (byte) 0x97 };
	//
	// pack = unpackMsg(pack, msg, socketIp);
	// return pack;
	// }

	/**
	 * 解包.
	 * 
	 * @param pack 未完成的包.
	 * @param msg 网络一次读到的字节流,可能为多个消息包(包括不完整的)
	 * @throws BizException
	 */
	private MsgPack unpackMsg(MsgPack pack, byte[] msg, String socketIp) throws BizException {
		try {
			Log4jUtil.info("execute unpackMsg() 方法，解包开始。");
			if (null == msg) {
				return pack;
			}
			int msgLen = msg.length;
			int unpackedLen = 0;
			while (unpackedLen < msgLen) {
				Log4jUtil.info("=====msgLen=" + msgLen + "===============unpackedLen=" + unpackedLen);
				unpackedLen += pack.unpack(msg);
				// 解包完成, 派发消息包, 并初始化新的空包.
				if (pack.isFull()) {
					Log4jUtil.info("=====xxxxxxxxxxxxxxxxxxxxxxx=====");
					Log4jUtil.debug(StringUtil.r("收到完整消息包并派发给处理线程,socketIp:{?},消息:{?}", socketIp,
							MacUtil.toHexString(pack)));
					return pack;
				}
			}
			Log4jUtil.info("execute unpackMsg() 方法，解包完成。");
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "解包失败");
		}
		return pack;
	}

	/**
	 * 连接服务器 socket
	 * 
	 * @param socketPort
	 * @param socketIp
	 * @throws BizException
	 */
	private Socket connect(String socketIp, String socketPort) throws BizException {
		Socket socket = null;
		AssertUtils.notNull(socketIp, TransReturnCode.code_9108, "SocketIP不能为空!");
		AssertUtils.notNull(socketPort, TransReturnCode.code_9108, "SocketPort不能为空!");
		try {
			socket = new Socket();
			SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
			socket.connect(socketAddress, connectOutTime);
			socket.setSoTimeout(timeout);
			Log4jUtil.info("connected!");
		} catch (Exception e) {
			// 链接不成功，抛错误代码为9108
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9103, "通讯异常,连接 socket server 失败！！" + e.getMessage());
		}
		return socket;
	}

	/**
	 * 断开服务器 socket
	 * 
	 * @throws BizException
	 */
	private void disconnect(Socket socket) throws BizException {
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "断开 socket server 失败！！");
		}
	}

	public static void main(String[] args) throws BizException, CloneNotSupportedException {
		SendBySocket ss = new SendBySocket();
		Socket sk = ss.connect("113.106.63.97", "12001");
		ss.disconnect(sk);

		// int[][] numeight={{100,200,300,400},{500,600,700,800},{900,1000,1100,1200}};
		// System.out.println(numeight[0][2]);
		// System.out.println(numeight[1][2]);
		// System.out.println(numeight[2][1]);
		// System.out.println(numeight[2]);

	}
}
