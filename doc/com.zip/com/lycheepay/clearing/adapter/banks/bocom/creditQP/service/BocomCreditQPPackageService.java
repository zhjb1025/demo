package com.lycheepay.clearing.adapter.banks.bocom.creditQP.service;

import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.stereotype.Service;
import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.CertificateType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.sign.ChannelSignApplyRequestDTO;
import com.lycheepay.clearing.common.dto.sign.ChannelSignConfirmRequstDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.SignNo;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.adapter.banks.bocom.creditQP.constant.Constant;
import com.lycheepay.clearing.adapter.banks.bocom.creditQP.model.ComRspDTO;

/**
 * 打包服务类
 * @author huangxu
 *
 */
@Service
public class BocomCreditQPPackageService {
	
	static final String channelId = ChannelIdEnum.BOCOM_CREDIT_CARD.getCode();
	
	/**
	 * 无磁无密消费(不含动态码)
	 * @return
	 */
	public String package0200Deduct(String bankSendSn, DeductDTO deduct, Map<String, String> channelParms, SignNo signNo){
		
		String merNo = channelParms.get(Constant.MER_NO);// 商户号
		String termNo = channelParms.get(Constant.TERM_NO);// 终端号
		String merNm = channelParms.get(Constant.MER_NM);	//商户名称
		String traceNo = bankSendSn.substring(bankSendSn.length() - 6);	//流水号
		String invioceNo = bankSendSn.substring(2,8) + traceNo;	//票据号
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(Constant.CHARSET);
		//创建根节点
		Element rootElement = document.addElement("transData");
		rootElement.addElement("version").setText(Constant.VERSION); // 版本号
		rootElement.addElement("msgId").setText(Constant.MSGID_DEDUCT); // 消息类型
		rootElement.addElement("transCode").setText(Constant.TRANS_CODE_DEDUCT); // 交易代码
		rootElement.addElement("cardNo").setText(deduct.getBankCardNo()); // 卡号
		rootElement.addElement("expiryDate").setText(deduct.getCreditCardEndDate()); // 有效期,格式：YYMM,根据商户的属性选填
		rootElement.addElement("merNo").setText(merNo);
		rootElement.addElement("termNo").setText(termNo);
		rootElement.addElement("traceNo").setText(traceNo); // 流水号,商户自定义6位流水号(可重复提交)
		
		String amount = deduct.getAmount().multiply(new BigDecimal("100")).setScale(0).toString();
		rootElement.addElement("amount").setText(amount); // 交易金额(分)
		
		rootElement.addElement("invioceNo").setText(invioceNo); // 票据号,每天唯一
		
		rootElement.addElement("TrxId").setText(bankSendSn); // 交易流水号
		rootElement.addElement("TrxDtTm").setText(getDate()); // 交易时间
		rootElement.addElement("TrxAmt").setText(amount); // 交易时间
		rootElement.addElement("TrxCcyCd").setText(Constant.CURRENCY); // 交易时间CURRENCY
		rootElement.addElement("TrxTp").setText(Constant.CONSUME_TYPE); //1000-消费；2000-转账；3000-购买投资理财等金融类产品；4000-其他
		rootElement.addElement("SgnNo").setText(signNo.getSgnNo());  //签约协议号
		rootElement.addElement("PyerNm").setText(deduct.getCardHolderName());  //付款人姓名
		rootElement.addElement("PyerAcctId").setText(deduct.getBankCardNo());  //付款人账户
		rootElement.addElement("PyerAcctTp").setText(getBkAcctTp(deduct.getBankCardType()));  //付款方账户类型
		rootElement.addElement("PyerAcctIssrId").setText(channelParms.get(Constant.PYER_ACCT_ISSR_ID));  //付款方账户所属机构标识
		//rootElement.addElement("PyerTrxTrmTp").setText("99");  //付款方交易终端类型
		//rootElement.addElement("PyerTrxTrmNo").setText("");  //付款方交易终端编码
		rootElement.addElement("CardCvn2").setText(deduct.getCvv2());  //卡片校验码
		rootElement.addElement("CardExprDt").setText(deduct.getCreditCardEndDate());  //卡片有效期
		rootElement.addElement("PyeeNm").setText(deduct.getSettlementAccount().getHolderName());  //（收款方,备付金）
		rootElement.addElement("PyeeAcctId").setText(deduct.getSettlementAccount().getAccountNo());  //收款方账户
		rootElement.addElement("PyeeAcctTp").setText(getBkAcctTp(deduct.getSettlementAccount().getAccountType() + ""));  //收款方账户类型
		rootElement.addElement("PyeeAcctIssrId").setText(channelParms.get(Constant.PYEE_ACCT_ISSR_ID));  //收款方账户所属机构标识
		rootElement.addElement("MrchntNm").setText(deduct.getCustomerInfoDTO().getCustomerName());  //商户名称
		rootElement.addElement("MrchntNo").setText(deduct.getCustomerInfoDTO().getCorpAccountId());  //商户编码
		rootElement.addElement("MrchntTp").setText(Constant.MER_TYPE);  //1-法人；2-其他组织；3-个体工商户；4-自然人
		rootElement.addElement("MrchntCertTp").setText(Constant.CERTIFICATE_TYPE);  //证件类型
		rootElement.addElement("MrchntCertId").setText(Constant.CERTIFICATE_CODE);  //证件编码
		rootElement.addElement("MrchntCtgyCd").setText(Constant.MRCHNT_CTGY);  //商户行业类别
		rootElement.addElement("OrdrId").setText(bankSendSn);  //订单编码
		rootElement.addElement("OrdrDesc").setText(StringUtils.isBlank(deduct.getOrderNote()) ? "订单详情为空" : deduct.getOrderNote());  //订单详情
		
		String addDataField = "Ver04TT" + Constant.TRANS_CODE_DEDUCT + "SO" + StringUtils.leftPad(String.valueOf(bankSendSn.getBytes(Charset.forName("GBK")).length), 2, '0') + bankSendSn + 
				"MC" + Constant.MRCHNT_CTGY +
				"MM" + StringUtils.leftPad(String.valueOf(deduct.getCustomerInfoDTO().getCustomerName().getBytes(Charset.forName("GBK")).length), 2, '0') + deduct.getCustomerInfoDTO().getCustomerName() +
				"MD" + StringUtils.leftPad(String.valueOf(deduct.getCustomerInfoDTO().getCorpAccountId().getBytes(Charset.forName("GBK")).length), 2, '0') + deduct.getCustomerInfoDTO().getCorpAccountId() +
				"TP" + StringUtils.leftPad(String.valueOf(Constant.NET_ADDRESS.getBytes(Charset.forName("GBK")).length), 2, '0') + Constant.NET_ADDRESS +
				"TA" + StringUtils.leftPad(String.valueOf(Constant.ADDRESS.getBytes(Charset.forName("GBK")).length), 2, '0') + Constant.ADDRESS +
				"OT" + StringUtils.leftPad(String.valueOf(Constant.OTHERS.getBytes(Charset.forName("GBK")).length), 2, '0') + Constant.OTHERS;
		rootElement.addElement("addDataField").setText(addDataField); // 附加字段
		
		String addData = "00ZM" + StringUtils.leftPad(String.valueOf(merNm.getBytes(Charset.forName("GBK")).length), 2, '0') + merNm + "O" + bankSendSn;
		rootElement.addElement("addData").setText(addData); // 附加域
		
		return rootElement.asXML();
	}
	
	
	public String package0400Cancel(String bankSendSn, RefundDTO refund, BillnoSn obillnoSn, final Map<String, String> channelParms){
		
		String merNo = channelParms.get(Constant.MER_NO);// 商户号
		String termNo = channelParms.get(Constant.TERM_NO);// 终端号
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(Constant.CHARSET);
		//创建根节点
		Element rootElement = document.addElement("transData");
		rootElement.addElement("version").setText(Constant.VERSION); // 版本号
		rootElement.addElement("msgId").setText(Constant.MSGID_CANCEL); // 消息类型
		rootElement.addElement("transCode").setText(Constant.TRANS_CODE_DEDUCT); // 交易代码,原交易的交易代码
		rootElement.addElement("cardNo").setText(refund.getBankCardNo()); // 卡号
		if(!StringUtils.isBlank(refund.getCreditCardEndDate())){
			rootElement.addElement("expiryDate").setText(refund.getCreditCardEndDate()); // 有效期,格式：YYMM,根据商户的属性选填
		}
		rootElement.addElement("merNo").setText(merNo);
		rootElement.addElement("termNo").setText(termNo);
		
		String oTraceNo = obillnoSn.getBankSendSn().substring(obillnoSn.getBankSendSn().length() - 6);
		rootElement.addElement("traceNo").setText(oTraceNo); // 原流水号
		
		String amount = refund.getAmount().multiply(new BigDecimal("100")).setScale(0).toString();
		rootElement.addElement("amount").setText(amount); // 交易金额(分)
		
		String oInvioceNo = obillnoSn.getBankSendSn().substring(2,8) + oTraceNo;
		rootElement.addElement("invioceNo").setText(oInvioceNo); // 被冲正交易的：票据号, 6位批次号+6位凭证号
		
		rootElement.addElement("addDataField").setText(""); // 附加字段
		rootElement.addElement("addData").setText(""); // 附加域
		
		return rootElement.asXML();
	}
	
	public String package0220Cancel(String bankSendSn, RefundDTO refund, BillnoSn obillnoSn, final Map<String, String> channelParms){
		
		String merNo = channelParms.get(Constant.MER_NO);// 商户号
		String termNo = channelParms.get(Constant.TERM_NO);// 终端号
		String traceNo = bankSendSn.substring(bankSendSn.length() - 6);	//流水号
		String invioceNo = bankSendSn.substring(2, 8) + traceNo;	//票据号
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(Constant.CHARSET);
		//创建根节点
		Element rootElement = document.addElement("transData");
		rootElement.addElement("version").setText(Constant.VERSION); // 版本号
		rootElement.addElement("msgId").setText(Constant.MSGID_REFUND); // 消息类型
		rootElement.addElement("transCode").setText(Constant.TRANS_CODE_REFUND); // 交易代码
		rootElement.addElement("cardNo").setText(refund.getBankCardNo()); // 卡号
		rootElement.addElement("merNo").setText(merNo);	//商户号
		rootElement.addElement("termNo").setText(termNo);	//终端号
		rootElement.addElement("traceNo").setText(traceNo);
		
		String amount = refund.getAmount().multiply(new BigDecimal("100")).setScale(0, BigDecimal.ROUND_HALF_UP).toString();
		rootElement.addElement("amount").setText(amount); // 交易金额(分)
		
		//rootElement.addElement("authNo").setText(obillnoSn.getBankRecvSn());
		
		String oTraceNo = obillnoSn.getBankSendSn().substring(obillnoSn.getBankSendSn().length() - 6);
		String oInvioceNo = obillnoSn.getBankSendSn().substring(2, 8) + oTraceNo;
		invioceNo = invioceNo + oInvioceNo;
		rootElement.addElement("invioceNo").setText(invioceNo); // 票据号, 6位批次号+6位凭证号+6位原批次号+6位原凭证号
		
		rootElement.addElement("TrxId").setText(bankSendSn);  //交易流水号
		rootElement.addElement("OriTrxId").setText(obillnoSn.getBankSendSn());  //原交易流水号
		rootElement.addElement("TrxDtTm").setText(getDate());  //交易时间
		rootElement.addElement("RfdTrxAmt").setText(amount);  //退款金额
		rootElement.addElement("TrxCcyCd").setText(Constant.CURRENCY);  //交易货币代码
		
		String addData = "00ZM00O" + bankSendSn;
		rootElement.addElement("addData").setText(addData); // 附加域
		
		return rootElement.asXML();
	}
	
	public ComRspDTO unpackageCommonRSP(String xml) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(xml.getBytes(Charset.forName(Constant.CHARSET)));
		} catch (BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "解析银行回执异常");
		}// 解析应答报文
		final Node nodeRoot = dom4jxml.getNode("transData");
		final String returnCode = dom4jxml.getNodeText(nodeRoot, "returnCode");// 返回码
		final String returnMsg = dom4jxml.getNodeText(nodeRoot, "returnMsg");// 返回码描述
		final String authNo = dom4jxml.getNodeText(nodeRoot, "authNo");	//授权号,用于退款交易
		final String SgnNo = dom4jxml.getNodeText(nodeRoot, "SgnNo");  //签约协议号
		final String SysRtnCd = dom4jxml.getNodeText(nodeRoot, "SysRtnCd");  //系统返回码
		final String SysRtnDesc = dom4jxml.getNodeText(nodeRoot, "SysRtnDesc");  //系统返回说明
		final String BizStsCd = dom4jxml.getNodeText(nodeRoot, "BizStsCd");  //业务返回码
		final String BizStsDesc = dom4jxml.getNodeText(nodeRoot, "BizStsDesc");  //业务返回说明
		final String hostDate = dom4jxml.getNodeText(nodeRoot, "hostDate");  //银行返回交易时间 格式：yyyyMMdd
		ComRspDTO rsp = new ComRspDTO();
		rsp.setReturnCode(returnCode);
		rsp.setReturnMsg(returnMsg);
		rsp.setAuthNo(authNo);
		rsp.setSgnNo(SgnNo);
		rsp.setSysRtnCd(SysRtnCd);
		rsp.setSysRtnDesc(SysRtnDesc);
		rsp.setBizStsCd(BizStsCd);
		rsp.setBizStsDesc(BizStsDesc);
		rsp.setHostDate(hostDate);
		
		return rsp;
	}
	
	/**
	 * 5.4获取手机验证代码——银行生成非跳转签约时使用的动态验证码
	 * @param xml
	 * @return
	 * @throws BizException
	 */
	public ComRspDTO unpackageCardSignRSP(String xml) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(xml.getBytes(Charset.forName(Constant.CHARSET)));
		} catch (BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "解析银行回执异常");
		}// 解析应答报文
		final Node nodeRoot = dom4jxml.getNode("transData");
		final String returnCode = dom4jxml.getNodeText(nodeRoot, "returnCode");// 返回码
		final String addData = dom4jxml.getNodeText(nodeRoot, "addData");  //附加域00+12位手续费+3位错误代码 手机号后四位+2位验证代码序号
		
		ComRspDTO rsp = new ComRspDTO();
		rsp.setReturnCode(returnCode);
		rsp.setAddData(addData);
		
		return rsp;
	}

	/**
	 * 签约，这里调用生成验证码接口，生成验证码给用户
	 * @param bankSendSn
	 * @param channelSignApplyRequestDTO
	 * @param channelParms
	 * @return
	 */
	public String package0200CardSign(String bankSendSn, String traceNo, String invioceNo, ChannelSignApplyRequestDTO channelSignApplyRequestDTO, Map<String, String> channelParms) {
		String merNo = channelParms.get(Constant.MER_NO);// 商户号
		String termNo = channelParms.get(Constant.TERM_NO);// 终端号
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(Constant.CHARSET);
		//创建根节点
		Element rootElement = document.addElement("transData");
		rootElement.addElement("version").setText(Constant.VERSION); // 版本号
		rootElement.addElement("msgId").setText(Constant.MSGID_DEDUCT); // 消息类型
		rootElement.addElement("transCode").setText(Constant.TRANS_CODE_MSG); // 交易代码
		rootElement.addElement("cardNo").setText(channelSignApplyRequestDTO.getCustBankAccountNo()); // 卡号
		rootElement.addElement("expiryDate").setText(channelSignApplyRequestDTO.getCustCardValidDate()); // 有效期,格式：YYMM,根据商户的属性选填
		rootElement.addElement("merNo").setText(merNo);
		rootElement.addElement("termNo").setText(termNo);
		rootElement.addElement("traceNo").setText(traceNo); // 流水号,商户自定义6位流水号(可重复提交)
		
		rootElement.addElement("invioceNo").setText(invioceNo); // 票据号,每天唯一
		
		String addData = "00WN" + StringUtils.leftPad(String.valueOf(channelSignApplyRequestDTO.getCustName().getBytes(Charset.forName("GBK")).length), 2, '0') + channelSignApplyRequestDTO.getCustName() + "T" + channelSignApplyRequestDTO.getCustBindPhoneNo() + "D" + StringUtils.leftPad(String.valueOf(getCertificateType(channelSignApplyRequestDTO.getCustCertificationType()).getBytes(Charset.forName("GBK")).length) + channelSignApplyRequestDTO.getCustID().getBytes(Charset.forName("GBK")).length, 2, '0') + getCertificateType(channelSignApplyRequestDTO.getCustCertificationType()) + channelSignApplyRequestDTO.getCustID();
		Log4jUtil.info("调用手机验证码-签约接口时产生的额外信息:{}", addData);
		rootElement.addElement("addData").setText(addData); // 附加域
		
		return rootElement.asXML();
	}
	
	/**
	 * 根据证件类型转换成交行快捷所对应的证件类型
	 * @param type
	 * @return
	 */
	public static String getCertificateType(String type) {
		if (CertificateType.IDENTITY_CARD.equals(type)) {
			return "SSNO";  //身份证
		}
		if (CertificateType.CHINA_PASSPORT.equals(type)) {
			return "PSPT";  //护照
		}
		if (CertificateType.MILITARY_ID.equals(type)) {
			return "SSN3";  //军人证
		}
		if (CertificateType.POLICE_ID.equals(type)) {
			return "SSN4";  //警官证
		}
		
		return "OTHR";
	}


	/**
	 * 根据内部定义的账户类型转换成广发定义的账户类型值
	 * @param bkAcctTp
	 * @return
	 */
	public static String getBkAcctTp(String bkAcctTp) {
		if (BankCardType.BANK_BOOK.equals(bkAcctTp)) {
			return null;
		} else if (BankCardType.DEBIT_CARD.equals(bkAcctTp)) {
			return "0";
		} else if (BankCardType.CREDIT_CARD.equals(bkAcctTp)) {
			return "1";
		} else {
			return null;
		}
	}
	
	/**
	 * 组装确认签约接口
	 * @param bankSendSn
	 * @param channelSignApplyRequestDTO
	 * @param channelParms
	 * @param channelSignConfirmRequstDTO
	 * @return
	 */
	public String package0200CardSignConfirm(String bankSendSn, ChannelSignApplyRequestDTO channelSignApplyRequestDTO, Map<String, String> channelParms, ChannelSignConfirmRequstDTO channelSignConfirmRequstDTO, SignNo signNo, String certType) {
		String merNo = channelParms.get(Constant.MER_NO);// 商户号
		String termNo = channelParms.get(Constant.TERM_NO);// 终端号
		String traceNo = bankSendSn.substring(bankSendSn.length() - 6);	//流水号
		String invioceNo = bankSendSn.substring(2,8) + traceNo;	//票据号
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding(Constant.CHARSET);
		//创建根节点
		Element rootElement = document.addElement("transData");
		rootElement.addElement("version").setText(Constant.VERSION); // 版本号
		rootElement.addElement("msgId").setText(Constant.MSGID_DEDUCT); // 消息类型
		rootElement.addElement("transCode").setText(Constant.TRANS_CODE_SIGN); // 交易代码
		rootElement.addElement("cardNo").setText(channelSignApplyRequestDTO.getCustBankAccountNo()); // 卡号
		rootElement.addElement("expiryDate").setText(channelSignApplyRequestDTO.getCustCardValidDate()); // 有效期,格式：YYMM,根据商户的属性选填
		rootElement.addElement("merNo").setText(merNo);
		rootElement.addElement("termNo").setText(termNo);
		rootElement.addElement("traceNo").setText(traceNo); // 流水号,商户自定义6位流水号(可重复提交)
		rootElement.addElement("amount").setText("0");  //金额固定用0
		rootElement.addElement("invioceNo").setText(invioceNo); // 票据号,每天唯一
		
	
		rootElement.addElement("TrxDtTm").setText(getDate()); // 交易时间
		rootElement.addElement("CstmrNm").setText(channelSignApplyRequestDTO.getCustName()); // 客户名称
		rootElement.addElement("BkAcctTp").setText(getBkAcctTp(channelSignApplyRequestDTO.getCustAccountCreditOrDebit())); // 银行账户类型
		rootElement.addElement("BkAcctNo").setText(channelSignApplyRequestDTO.getCustBankAccountNo()); // 银行账户
		rootElement.addElement("CardCvn2").setText(channelSignApplyRequestDTO.getCustCardCvv2()); // 卡片验证码
		rootElement.addElement("CardExprDt").setText(channelSignApplyRequestDTO.getCustCardValidDate()); // 卡片有效期
		rootElement.addElement("IDTp").setText(StringUtils.isBlank(certType) ? "99" : certType); // 证件类型
		rootElement.addElement("IDNo").setText(channelSignApplyRequestDTO.getCustID()); // 证件号码
		rootElement.addElement("MobNo").setText(channelSignApplyRequestDTO.getCustBindPhoneNo()); // 手机号
		
		String addData = "00WN" + StringUtils.leftPad(String.valueOf(channelSignApplyRequestDTO.getCustName().getBytes(Charset.forName("GBK")).length), 2, '0') + channelSignApplyRequestDTO.getCustName() + "M" + "00P" + signNo.getExtra() + channelSignConfirmRequstDTO.getIdentifyingCode() + signNo.getBatchNo() + signNo.getVoucherNo();
		Log4jUtil.info("调用手机验证码-签约接口时产生的额外信息:{}", addData);
		rootElement.addElement("addData").setText(addData); // 附加域
		
		return rootElement.asXML();
	}
	
	public static String getDate() {
		Date date = new Date();
		return new SimpleDateFormat("yyyy-MM-dd").format(date) + "T" + new SimpleDateFormat("HH:mm:ss").format(date);
	}
}
