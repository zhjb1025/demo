package com.lycheepay.clearing.adapter.banks.bocom.credit.kft.bean;

import java.math.BigDecimal;


public class BocomCreditBean {
	private String acctNo; // 信用卡账号
	private String acctName; // 信用卡账户名
	private BigDecimal amount = BigDecimal.ZERO; // 交易金额
	private String validDate; // 信用卡账号有效期
	private String bankSendSn; // 发往银行的交易流水号
	private String orgBankSendSn; // 原交易发往银行的流水(退货和撤销中用到)
	private String bankRecvSn; // 银行返回的交易流水号
	private String batchNo; // 批次号
	private String authorizationCode; // 消费交易中银行返回的授权码
	private String bankDate; // 银行返回的交易时间(MMddHHmmss)

	public String getAcctName() {
		return acctName;
	}

	public void setAcctName(String acctName) {
		this.acctName = acctName;
	}

	public String getAcctNo() {
		return acctNo;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public String getBankDate() {
		return bankDate;
	}

	public String getBankRecvSn() {
		return bankRecvSn;
	}

	public String getBankSendSn() {
		return bankSendSn;
	}

	public String getBatchNo() {
		return batchNo;
	}


	public String getOrgBankSendSn() {
		return orgBankSendSn;
	}

	public String getValidDate() {
		return validDate;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public void setAuthorizationCode(String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public void setBankDate(String bankDate) {
		this.bankDate = bankDate;
	}

	public void setBankRecvSn(String bankRecvSn) {
		this.bankRecvSn = bankRecvSn;
	}

	public void setBankSendSn(String bankSendSn) {
		this.bankSendSn = bankSendSn;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public void setOrgBankSendSn(String orgBankSendSn) {
		this.orgBankSendSn = orgBankSendSn;
	}

	public void setValidDate(String validDate) {
		this.validDate = validDate;
	}

}
