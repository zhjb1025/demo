package com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean;

/**
 * <P>单笔/实时代付（330002）-报文体实体</P>
 * 
 * @author 吴高雷(13632920449)
 */
public class DirectPayBean {
	// 请求
	private String cert_no;// 企业凭证号
	private String pay_acno;// 付款账号
	private String type;// 签约类型
	private int sum;// 总笔数
	private String sum_amt;// 总金额
	private String pay_month;// 月份
	private String summary;// 附言
	private String busi_no;// 协议编号
	private String mailflg;// 传票汇总标志 Y：汇总，N：不汇总。默认为Y：汇总
	private SendDirectRecord detailRecord;// 扣款明细信息

	// 应答
	private String eBankBatFlw;// 网银批次号
	private String eBankSucSum;// 成功笔数
	private String eBankFailSum;// 失败笔数
	private String eBankUnknowSum;// 可疑笔数
	private ReceiveDirectRecord receDirectRecord;// 应答明细

	/**
	 * @return the eBankBatFlw
	 */
	public String geteBankBatFlw() {
		return eBankBatFlw;
	}

	/**
	 * @param eBankBatFlw the eBankBatFlw to set
	 */
	public void seteBankBatFlw(String eBankBatFlw) {
		this.eBankBatFlw = eBankBatFlw;
	}

	/**
	 * @return the eBankSucSum
	 */
	public String geteBankSucSum() {
		return eBankSucSum;
	}

	/**
	 * @param eBankSucSum the eBankSucSum to set
	 */
	public void seteBankSucSum(String eBankSucSum) {
		this.eBankSucSum = eBankSucSum;
	}

	/**
	 * @return the eBankFailSum
	 */
	public String geteBankFailSum() {
		return eBankFailSum;
	}

	/**
	 * @param eBankFailSum the eBankFailSum to set
	 */
	public void seteBankFailSum(String eBankFailSum) {
		this.eBankFailSum = eBankFailSum;
	}

	/**
	 * @return the eBankUnknowSum
	 */
	public String geteBankUnknowSum() {
		return eBankUnknowSum;
	}

	/**
	 * @param eBankUnknowSum the eBankUnknowSum to set
	 */
	public void seteBankUnknowSum(String eBankUnknowSum) {
		this.eBankUnknowSum = eBankUnknowSum;
	}

	/**
	 * @return the receDirectRecord
	 */
	public ReceiveDirectRecord getReceDirectRecord() {
		return receDirectRecord;
	}

	/**
	 * @param receDirectRecord the receDirectRecord to set
	 */
	public void setReceDirectRecord(ReceiveDirectRecord receDirectRecord) {
		this.receDirectRecord = receDirectRecord;
	}

	/**
	 * <P>应答明细记录</P>
	 * 
	 * @author 吴高雷(13632920449)
	 */
	public static class ReceiveDirectRecord {
		private String cardNo;// 卡号
		private String successFlag;// 成功标志
		private String netFlow;// 网银流水号

		/**
		 * @return the cardNo
		 */
		public String getCardNo() {
			return cardNo;
		}

		/**
		 * @param cardNo the cardNo to set
		 */
		public void setCardNo(String cardNo) {
			this.cardNo = cardNo;
		}

		/**
		 * @return the successFlag
		 */
		public String getSuccessFlag() {
			return successFlag;
		}

		/**
		 * @param successFlag the successFlag to set
		 */
		public void setSuccessFlag(String successFlag) {
			this.successFlag = successFlag;
		}

		/**
		 * @return the netFlow
		 */
		public String getNetFlow() {
			return netFlow;
		}

		/**
		 * @param netFlow the netFlow to set
		 */
		public void setNetFlow(String netFlow) {
			this.netFlow = netFlow;
		}
	}

	/**
	 * <P>请求明细记录</P>
	 * 
	 * @author 吴高雷(13632920449)
	 */
	public static class SendDirectRecord {
		private String card_no;// 卡号
		private String acname;// 户名
		private String card_flag;// 卡/折标志
		private String amt;// 金额
		private String busino;// 业务编号

		/**
		 * @return the card_no
		 */
		public String getCard_no() {
			return card_no;
		}

		/**
		 * @param card_no the card_no to set
		 */
		public void setCard_no(String card_no) {
			this.card_no = card_no;
		}

		/**
		 * @return the acname
		 */
		public String getAcname() {
			return acname;
		}

		/**
		 * @param acname the acname to set
		 */
		public void setAcname(String acname) {
			this.acname = acname;
		}

		/**
		 * @return the card_flag
		 */
		public String getCard_flag() {
			return card_flag;
		}

		/**
		 * @param card_flag the card_flag to set
		 */
		public void setCard_flag(String card_flag) {
			this.card_flag = card_flag;
		}

		/**
		 * @return the amt
		 */
		public String getAmt() {
			return amt;
		}

		/**
		 * @param amt the amt to set
		 */
		public void setAmt(String amt) {
			this.amt = amt;
		}

		/**
		 * @return the busino
		 */
		public String getBusino() {
			return busino;
		}

		/**
		 * @param busino the busino to set
		 */
		public void setBusino(String busino) {
			this.busino = busino;
		}
	}

	/**
	 * @return the cert_no
	 */
	public String getCert_no() {
		return cert_no;
	}

	/**
	 * @param cert_no the cert_no to set
	 */
	public void setCert_no(String cert_no) {
		this.cert_no = cert_no;
	}

	/**
	 * @return the pay_acno
	 */
	public String getPay_acno() {
		return pay_acno;
	}

	/**
	 * @param pay_acno the pay_acno to set
	 */
	public void setPay_acno(String pay_acno) {
		this.pay_acno = pay_acno;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the sum
	 */
	public int getSum() {
		return sum;
	}

	/**
	 * @param sum the sum to set
	 */
	public void setSum(int sum) {
		this.sum = sum;
	}

	/**
	 * @return the sum_amt
	 */
	public String getSum_amt() {
		return sum_amt;
	}

	/**
	 * @param sum_amt the sum_amt to set
	 */
	public void setSum_amt(String sum_amt) {
		this.sum_amt = sum_amt;
	}

	/**
	 * @return the pay_month
	 */
	public String getPay_month() {
		return pay_month;
	}

	/**
	 * @param pay_month the pay_month to set
	 */
	public void setPay_month(String pay_month) {
		this.pay_month = pay_month;
	}

	/**
	 * @return the summary
	 */
	public String getSummary() {
		return summary;
	}

	/**
	 * @param summary the summary to set
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}

	/**
	 * @return the busi_no
	 */
	public String getBusi_no() {
		return busi_no;
	}

	/**
	 * @param busi_no the busi_no to set
	 */
	public void setBusi_no(String busi_no) {
		this.busi_no = busi_no;
	}

	/**
	 * @return the mailflg
	 */
	public String getMailflg() {
		return mailflg;
	}

	/**
	 * @param mailflg the mailflg to set
	 */
	public void setMailflg(String mailflg) {
		this.mailflg = mailflg;
	}

	/**
	 * @return the detailRecord
	 */
	public SendDirectRecord getDetailRecord() {
		return detailRecord;
	}

	/**
	 * @param detailRecord the detailRecord to set
	 */
	public void setDetailRecord(SendDirectRecord detailRecord) {
		this.detailRecord = detailRecord;
	}
}
