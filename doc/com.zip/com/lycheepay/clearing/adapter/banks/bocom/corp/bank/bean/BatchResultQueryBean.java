package com.lycheepay.clearing.adapter.banks.bocom.corp.bank.bean;

import java.util.List;


/**
 * <P>批量代付交易结果查询（310200）- 报文体实体</P>
 * 
 * @author 吴高雷(13632920449)
 */
public class BatchResultQueryBean {
	// 请求
	private String ogl_serial_no;// 流水号：对应330002 接口企业凭证号
	private String query_flag;// 查询标志 流水号类型‘1’：原流水号为企业凭证号 ‘2’：原流水号为网银流水号

	// 应答
	String field_num;// 字段数
	String record_num;// 记录数
	String file_flag;// 文件标志
	String filename;// 文件名
	String serial_record;// 带中文域名的多域串-循环体格式:企业流水号|所属月份|付款账号|会计核心日期|批次流水号|序号|付款户名|付款币种|业务类型|付款金额|收款卡号|收款户名|状态|错误原因|业务编号|
	private List<SerialRecordBean> serialRecordBeanList;

	public static class SerialRecordBean {
		private String corpNo;// 企业流水号
		private String ownedMonth;// 所属月份
		private String payerAccountNo;// 付款账号
		private String coreDate;// 会计核心日期
		private String batchNo;// 批次流水号
		private String serialId;// 序号
		private String payerHolderName;// 付款户名
		private String payerCcy;// 付款币种
		private String businessType;// 业务类型
		private String payerAmt;// 付款金额
		private String payeeAccountNo;// 收款卡号
		private String payeeHolderName;// 收款户名
		private String status;// 状态
		private String errorReason;// 错误原因
		private String businessNo;// 业务编号

		/**
		 * @return the corpNo
		 */
		public String getCorpNo() {
			return corpNo;
		}

		/**
		 * @param corpNo the corpNo to set
		 */
		public void setCorpNo(String corpNo) {
			this.corpNo = corpNo;
		}

		/**
		 * @return the ownedMonth
		 */
		public String getOwnedMonth() {
			return ownedMonth;
		}

		/**
		 * @param ownedMonth the ownedMonth to set
		 */
		public void setOwnedMonth(String ownedMonth) {
			this.ownedMonth = ownedMonth;
		}

		/**
		 * @return the payerAccountNo
		 */
		public String getPayerAccountNo() {
			return payerAccountNo;
		}

		/**
		 * @param payerAccountNo the payerAccountNo to set
		 */
		public void setPayerAccountNo(String payerAccountNo) {
			this.payerAccountNo = payerAccountNo;
		}

		/**
		 * @return the coreDate
		 */
		public String getCoreDate() {
			return coreDate;
		}

		/**
		 * @param coreDate the coreDate to set
		 */
		public void setCoreDate(String coreDate) {
			this.coreDate = coreDate;
		}

		/**
		 * @return the batchNo
		 */
		public String getBatchNo() {
			return batchNo;
		}

		/**
		 * @param batchNo the batchNo to set
		 */
		public void setBatchNo(String batchNo) {
			this.batchNo = batchNo;
		}

		/**
		 * @return the serialId
		 */
		public String getSerialId() {
			return serialId;
		}

		/**
		 * @param serialId the serialId to set
		 */
		public void setSerialId(String serialId) {
			this.serialId = serialId;
		}

		/**
		 * @return the payerHolderName
		 */
		public String getPayerHolderName() {
			return payerHolderName;
		}

		/**
		 * @param payerHolderName the payerHolderName to set
		 */
		public void setPayerHolderName(String payerHolderName) {
			this.payerHolderName = payerHolderName;
		}

		/**
		 * @return the payerCcy
		 */
		public String getPayerCcy() {
			return payerCcy;
		}

		/**
		 * @param payerCcy the payerCcy to set
		 */
		public void setPayerCcy(String payerCcy) {
			this.payerCcy = payerCcy;
		}

		/**
		 * @return the businessType
		 */
		public String getBusinessType() {
			return businessType;
		}

		/**
		 * @param businessType the businessType to set
		 */
		public void setBusinessType(String businessType) {
			this.businessType = businessType;
		}

		/**
		 * @return the payerAmt
		 */
		public String getPayerAmt() {
			return payerAmt;
		}

		/**
		 * @param payerAmt the payerAmt to set
		 */
		public void setPayerAmt(String payerAmt) {
			this.payerAmt = payerAmt;
		}

		/**
		 * @return the payeeAccountNo
		 */
		public String getPayeeAccountNo() {
			return payeeAccountNo;
		}

		/**
		 * @param payeeAccountNo the payeeAccountNo to set
		 */
		public void setPayeeAccountNo(String payeeAccountNo) {
			this.payeeAccountNo = payeeAccountNo;
		}

		/**
		 * @return the payeeHolderName
		 */
		public String getPayeeHolderName() {
			return payeeHolderName;
		}

		/**
		 * @param payeeHolderName the payeeHolderName to set
		 */
		public void setPayeeHolderName(String payeeHolderName) {
			this.payeeHolderName = payeeHolderName;
		}

		/**
		 * @return the status
		 */
		public String getStatus() {
			return status;
		}

		/**
		 * @param status the status to set
		 */
		public void setStatus(String status) {
			this.status = status;
		}

		/**
		 * @return the errorReason
		 */
		public String getErrorReason() {
			return errorReason;
		}

		/**
		 * @param errorReason the errorReason to set
		 */
		public void setErrorReason(String errorReason) {
			this.errorReason = errorReason;
		}

		/**
		 * @return the businessNo
		 */
		public String getBusinessNo() {
			return businessNo;
		}

		/**
		 * @param businessNo the businessNo to set
		 */
		public void setBusinessNo(String businessNo) {
			this.businessNo = businessNo;
		}
	}

	/**
	 * @return the ogl_serial_no
	 */
	public String getOgl_serial_no() {
		return ogl_serial_no;
	}

	/**
	 * @param ogl_serial_no the ogl_serial_no to set
	 */
	public void setOgl_serial_no(String ogl_serial_no) {
		this.ogl_serial_no = ogl_serial_no;
	}

	/**
	 * @return the query_flag
	 */
	public String getQuery_flag() {
		return query_flag;
	}

	/**
	 * @param query_flag the query_flag to set
	 */
	public void setQuery_flag(String query_flag) {
		this.query_flag = query_flag;
	}

	/**
	 * @return the field_num
	 */
	public String getField_num() {
		return field_num;
	}

	/**
	 * @param field_num the field_num to set
	 */
	public void setField_num(String field_num) {
		this.field_num = field_num;
	}

	/**
	 * @return the record_num
	 */
	public String getRecord_num() {
		return record_num;
	}

	/**
	 * @param record_num the record_num to set
	 */
	public void setRecord_num(String record_num) {
		this.record_num = record_num;
	}

	/**
	 * @return the file_flag
	 */
	public String getFile_flag() {
		return file_flag;
	}

	/**
	 * @param file_flag the file_flag to set
	 */
	public void setFile_flag(String file_flag) {
		this.file_flag = file_flag;
	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the serial_record
	 */
	public String getSerial_record() {
		return serial_record;
	}

	/**
	 * @param serial_record the serial_record to set
	 */
	public void setSerial_record(String serial_record) {
		this.serial_record = serial_record;
	}

	/**
	 * @return the serialRecordBeanList
	 */
	public List<SerialRecordBean> getSerialRecordBeanList() {
		return serialRecordBeanList;
	}

	/**
	 * @param serialRecordBeanList the serialRecordBeanList to set
	 */
	public void setSerialRecordBeanList(List<SerialRecordBean> serialRecordBeanList) {
		this.serialRecordBeanList = serialRecordBeanList;
	}
}
