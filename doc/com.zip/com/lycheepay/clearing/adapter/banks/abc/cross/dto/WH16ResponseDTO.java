package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH16ResponseDTO extends AbcCrossBeanBase {

	public WH16ResponseDTO() {
		super.addField(new AbcCrossBeanField("transCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("procCode", 6, true, ' '));
		super.addField(new AbcCrossBeanField("termID", 8, true, ' '));
		super.addField(new AbcCrossBeanField("merID", 10, true, ' '));
		super.addField(new AbcCrossBeanField("respCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("respMsg", 60, true, ' '));
		super.addField(new AbcCrossBeanField("status", 1, true, ' '));
		super.addField(new AbcCrossBeanField("transDate", 8, true, ' '));
		super.addField(new AbcCrossBeanField("transTime", 6, true, ' '));
		super.addField(new AbcCrossBeanField("bizType", 1, true, ' '));
		super.addField(new AbcCrossBeanField("buyCurrency", 2, true, ' '));
		super.addField(new AbcCrossBeanField("sellCurrency", 2, true, ' '));
		super.addField(new AbcCrossBeanField("buyAmount", 16, true, ' '));
		super.addField(new AbcCrossBeanField("sellAmount", 16, true, ' '));
		super.addField(new AbcCrossBeanField("dealAmount", 16, true, ' '));
		super.addField(new AbcCrossBeanField(AbcCrossConstant.STRING_MD5, 32, true, ' '));

	}

	public String getTransCode() {
		return data.get("transCode");
	}

	public void setTransCode(String transCode) {
		data.put("transCode", transCode);
	}

	public String getProcCode() {
		return data.get("procCode");
	}

	public void setProcCode(String procCode) {
		data.put("procCode", procCode);
	}

	public String getTermID() {
		return data.get("termID");
	}

	public void setTermID(String termID) {
		data.put("termID", termID);
	}

	public String getMerID() {
		return data.get("merID");
	}

	public void setMerID(String merID) {
		data.put("merID", merID);
	}

	public String getRespCode() {
		return data.get("respCode");
	}

	public void setRespCode(String respCode) {
		data.put("respCode", respCode);
	}

	public String getRespMsg() {
		return data.get("respMsg");
	}

	public void setRespMsg(String respMsg) {
		data.put("respMsg", respMsg);
	}

	public String getStatus() {
		return data.get("status");
	}

	public void setStatus(String status) {
		data.put("status", status);
	}

	public String getTransDate() {
		return data.get("transDate");
	}

	public void setTransDate(String transDate) {
		data.put("transDate", transDate);
	}

	public String getTransTime() {
		return data.get("transTime");
	}

	public void setTransTime(String transTime) {
		data.put("transTime", transTime);
	}

	public String getBizType() {
		return data.get("bizType");
	}

	public void setBizType(String bizType) {
		data.put("bizType", bizType);
	}

	public String getBuyCurrency() {
		return data.get("buyCurrency");
	}

	public void setBuyCurrency(String buyCurrency) {
		data.put("buyCurrency", buyCurrency);
	}

	public String getSellCurrency() {
		return data.get("sellCurrency");
	}

	public void setSellCurrency(String sellCurrency) {
		data.put("sellCurrency", sellCurrency);
	}

	public String getBuyAmount() {
		return data.get("buyAmount");
	}

	public void setBuyAmount(String buyAmount) {
		data.put("buyAmount", buyAmount);
	}

	public String getSellAmount() {
		return data.get("sellAmount");
	}

	public void setSellAmount(String sellAmount) {
		data.put("sellAmount", sellAmount);
	}

	public String getDealAmount() {
		return data.get("dealAmount");
	}

	public void setDealAmount(String dealAmount) {
		data.put("dealAmount", dealAmount);
	}

}
