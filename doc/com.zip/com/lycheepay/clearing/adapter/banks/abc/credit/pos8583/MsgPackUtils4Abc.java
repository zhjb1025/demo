package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lycheepay.clearing.adapter.banks.abc.credit.kft.util.AbcCreditMsgUtilService;
import com.lycheepay.clearing.adapter.banks.abc.credit.kft.util.J2DES;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AmountUtils;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 消息包工具.
 * 
 * @author aps-wiz
 */
public abstract class MsgPackUtils4Abc {
	private static final Logger logger = LoggerFactory.getLogger(MsgPackUtils4Abc.class);

	/**
	 * 创建tpdu域.
	 */
	public static void createTpduField(final MsgPack4Abc msgPack4Abc, final byte[] b) throws BizException {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.TPDU;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());

		field.setOrigMsg(b);
		msgPack4Abc.put(field);
	}

	// /**
	// * 创建head域.
	// */
	// public static void createHeadField(MsgPack4Abc msgPack4Abc, byte[] b)
	// throws BizException {
	// MsgFieldType4Abc fieldType = MsgFieldType4Abc.HEAD;
	// MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
	// field.setOrigMsg(b);
	// msgPack4Abc.put(field);
	// }

	public static void resetMsgType(final MsgPack4Abc MsgPack4Abc, final String newMsgType) {
		final MsgField4Abc field = MsgPack4Abc.getField(MsgFieldType4Abc.MSG_TYPE.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
	}

	public static void createMsgType(final MsgPack4Abc MsgPack4Abc, final String newMsgType) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.MSG_TYPE;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());

		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
		MsgPack4Abc.put(field);
	}

	public static void createField2(final MsgPack4Abc MsgPack4Abc, final String accountNo) throws BizException {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_2;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		final int valueLen = accountNo.getBytes().length;
		final byte[] bcdAccountNo = ByteUtils.strToBcdLeftSide(accountNo);
		final byte[] bcdLen = ByteUtils.intToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bcdAccountNo));

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 交易处理码.
	 * 
	 * @param MsgPack4Abc
	 * @param tradeDealCode
	 */
	public static void createField3(final MsgPack4Abc msgPack4Abc, final String tradeDealCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_3;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(tradeDealCode));
		msgPack4Abc.putBitmapField(field);
	}

	/**
	 * 创建第4域交易金额
	 * 
	 * @param MsgPack4Abc
	 * @param amount 交易金额, 单位:元
	 */
	public static void createField4(final MsgPack4Abc MsgPack4Abc, final Double amount) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_4;

		final long cent = (long) AmountUtils.format(amount * 100);
		String strAmount = Long.toString(cent);
		strAmount = StringUtils.leftPad(strAmount, fieldType.getMaxLength() * 2, '0'); // 补足编码前12位长度.
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		// 设置bcd编码的交易金额.
		final byte[] bcdAmount = ByteUtils.strToBcd(strAmount);
		field.setOrigMsg(bcdAmount);
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 重置第4域交易金额
	 * 
	 * @param MsgPack4Abc
	 * @param amount 交易金额, 单位:元
	 */
	public static void resetField4(final MsgPack4Abc MsgPack4Abc, final Double amount) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_4;

		final long cent = (long) AmountUtils.format(amount * 100);
		String strAmount = Long.toString(cent);
		strAmount = StringUtils.leftPad(strAmount, fieldType.getMaxLength() * 2, '0'); // 补足编码前12位长度.
		final MsgField4Abc field = MsgPack4Abc.getField(fieldType.getNo());

		// 设置bcd编码的交易金额.
		final byte[] bcdAmount = ByteUtils.strToBcd(strAmount);
		field.setOrigMsg(bcdAmount);
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 受卡方系统跟踪号.
	 * 
	 * @param MsgPack4Abc
	 * @param trackeCode
	 */
	public static void createField11(final MsgPack4Abc MsgPack4Abc, final String trackeCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_11;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(trackeCode));
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField12(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_12.getNo());
		final byte[] bcd = ByteUtils.strToBcd("000000");
		field.setOrigMsg(bcd);
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField12(final MsgPack4Abc MsgPack4Abc, final String time) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_12.getNo());
		final byte[] bcd = ByteUtils.strToBcd(time);
		field.setOrigMsg(bcd);
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField13(final MsgPack4Abc MsgPack4Abc, final String date) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_13.getNo());
		final byte[] bcd = ByteUtils.strToBcd(date);
		field.setOrigMsg(bcd);
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField13(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_13.getNo());
		final byte[] bcd = ByteUtils.strToBcd("0000");
		field.setOrigMsg(bcd);
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField14(final MsgPack4Abc MsgPack4Abc, final String trackeCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_14;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(trackeCode));
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField15(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_15.getNo());
		final byte[] bcd = ByteUtils.strToBcd("0000");
		field.setOrigMsg(bcd);

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 服务点输入方式码.
	 * 
	 * @param MsgPack4Abc
	 * @param inputModeCode
	 */
	public static void createField22(final MsgPack4Abc MsgPack4Abc, final String inputModeCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_22;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(inputModeCode.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 服务点输入方式码.
	 * 
	 * @param MsgPack4Abc
	 * @param inputModeCode
	 */
	public static void createField22Abc(final MsgPack4Abc MsgPack4Abc, final String inputModeCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_22;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(inputModeCode));
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField23(final MsgPack4Abc MsgPack4Abc, final String trackeCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_23;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		// field.setOrigMsg(ByteUtils.strToBcd(trackeCode));
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(trackeCode));
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 交换指示符和服务代码
	 * 
	 * @param MsgPack4Abc
	 * @param conditionCode
	 */
	public static void createField24(final MsgPack4Abc MsgPack4Abc, final String conditionCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_24;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(conditionCode));
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 服务点条件码.
	 * 
	 * @param MsgPack4Abc
	 * @param conditionCode
	 */
	public static void createField25(final MsgPack4Abc MsgPack4Abc, final String conditionCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_25;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(conditionCode.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 服务点条件码.
	 * 
	 * @param MsgPack4Abc
	 * @param conditionCode
	 */
	public static void createField25Abc(final MsgPack4Abc MsgPack4Abc, final String conditionCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_25;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(conditionCode));
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField32(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_32.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("01");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField35(final MsgPack4Abc MsgPack4Abc, final String conditionCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_35;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		String valueLen = conditionCode.length() + "";
		while (valueLen.length() < 2) {
			valueLen = "0" + valueLen;
		}
		final byte[] bcdLen = ByteUtils.strToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, ByteUtils.strToBcdRightSide(conditionCode)));
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField36(final MsgPack4Abc MsgPack4Abc, final String conditionCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_36;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		String valueLen = conditionCode.length() + "";
		while (valueLen.length() < 4) {
			valueLen = "0" + valueLen;
		}
		final byte[] bcdLen = ByteUtils.strToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, ByteUtils.strToBcdRightSide(conditionCode)));
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField37(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_37.getNo());
		field.setOrigMsg("000000000000".getBytes());

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 生成37检索参考号,加入到包中.
	 * 
	 * @param MsgPack4Abc
	 * @param bytes
	 */
	public static void createField37(final MsgPack4Abc MsgPack4Abc, final String rspCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_37;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 生成38授权标识应答码, 请求时，同原预授权交易,加入到包中.
	 * 
	 * @param MsgPack4Abc
	 * @param bytes
	 */
	public static void createField38(final MsgPack4Abc MsgPack4Abc, final String rspCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_38;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 生成39应答码域, 加入到包中.
	 * 
	 * @param MsgPack4Abc
	 * @param bytes
	 */
	public static void createField39(final MsgPack4Abc MsgPack4Abc, final String rspCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_39;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 受卡机终端标识码.
	 * 
	 * @param MsgPack4Abc
	 * @param terminalCode
	 */
	public static void createField41(final MsgPack4Abc MsgPack4Abc, final String terminalCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_41;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(terminalCode.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 受卡方标识码.
	 * 
	 * @param MsgPack4Abc
	 * @param merchantNo
	 */
	public static void createField42(final MsgPack4Abc MsgPack4Abc, final String merchantNo) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_42;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(merchantNo.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField44(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_44.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("01");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		MsgPack4Abc.putBitmapField(field);
	}

	public static void createField44(final MsgPack4Abc MsgPack4Abc, final String customValue) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_44;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd(customValue);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 交易代码.
	 * 
	 * @param MsgPack4Abc
	 * @param currencyCode
	 */
	public static void createField48(final MsgPack4Abc MsgPack4Abc, final String currencyCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_48;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());

		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		String valueLen = currencyCode.getBytes().length + "";
		while (valueLen.length() < 4) {
			valueLen = "0" + valueLen;
		}
		// byte[] bcdAccountNo = ByteUtils.strToBcdRightSide(currencyCode);
		final byte[] bcdLen = ByteUtils.strToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, currencyCode.getBytes()));
		// field.setOrigMsg(ByteUtils.strToBcdRightSide(currencyCode));
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 附加数据.
	 * 
	 * @param MsgPack4Abc
	 * @param currencyCode
	 */
	public static void createField48Power(final MsgPack4Abc MsgPack4Abc, final byte[] currencyCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_48;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());

		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		String valueLen = currencyCode.length + "";
		while (valueLen.length() < 4) {
			valueLen = "0" + valueLen;
		}
		// byte[] bcdAccountNo = ByteUtils.strToBcdRightSide(currencyCode);
		final byte[] bcdLen = ByteUtils.strToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, currencyCode));
		// field.setOrigMsg(ByteUtils.strToBcdRightSide(currencyCode));
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 交易货币代码.
	 * 
	 * @param MsgPack4Abc
	 * @param currencyCode
	 */
	public static void createField49(final MsgPack4Abc MsgPack4Abc, final String currencyCode) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_49;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());

		// field.setHasLeaderLength(true);
		// field
		// .setLenOfLeaderLength(fieldType.getParser()
		// .getLenOfLeaderLength());
		//
		// // 设置值.
		// int lenSize = field.getLenOfLeaderLength() * 2;
		// byte[] tempbytes=ByteUtils.strToBcdRightSide(currencyCode);
		// String lengthValue = StringUtils.leftPad(String.valueOf(tempbytes.length),
		// lenSize, '0');
		// byte[] bcdLen = ByteUtils.strToBcd(lengthValue);
		// field.setOrigMsg(ArrayUtils.addAll(bcdLen, tempbytes));

		// field.setOrigMsg(ByteUtils.strToBcdRightSide(currencyCode));
		field.setOrigMsg(currencyCode.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 生成57自定义域, 加入到包中.
	 * 
	 * @param MsgPack4Abc
	 * @param bytes
	 */
	public static void createField57(final MsgPack4Abc MsgPack4Abc, final byte[] bytes) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_57;

		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		// 设置值.
		final int lenSize = field.getLenOfLeaderLength() * 2;
		final String lengthValue = StringUtils.leftPad(String.valueOf(bytes.length), lenSize, '0');
		final byte[] bcdLen = ByteUtils.strToBcd(lengthValue);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bytes));

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 自定义域.
	 * 
	 * @param MsgPack4Abc
	 * @param customValue
	 */
	public static void createField60(final MsgPack4Abc MsgPack4Abc, final byte[] customValue) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_60;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(customValue);
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 自定义域.
	 * 
	 * @param MsgPack4Abc
	 * @param customValue
	 */
	public static void createField60AbcSignIn(final MsgPack4Abc MsgPack4Abc, final String customValue) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_60;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		final byte[] tempBytes = new byte[customValue.getBytes().length + 2];
		String len = (tempBytes.length - 2) / 2 + "";
		while (len.length() < 4) {
			len = "0" + len;
		}

		Log4jUtil.info("======================len==" + len);
		Log4jUtil.info("======================customValue==" + customValue);
		System.arraycopy(customValue.getBytes(), 0, tempBytes, 2, customValue.getBytes().length);
		// ABC固定长度
		// tempBytes[0]=0x00;
		// tempBytes[1]=0x06;
		final byte[] lenOfPrefix = ByteUtils.strToBcd(len);
		final byte[] value = hexStringToBytes(customValue);
		field.setOrigMsg(ArrayUtils.addAll(lenOfPrefix, value));
		// field.setOrigMsg(value);
		String x = "", y = "", z = "";
		final byte[] mm = field.getOrigMsg();
		for (int i = 0; i < mm.length; i++) {
			x += AbcCreditMsgUtilService.encodehex(mm[i]) + " ";
			y += field.getOrigMsg()[i] + " ";
			z += AbcCreditMsgUtilService.encodehex(mm[i]);
		}

		Log4jUtil.info("======================x" + x);
		Log4jUtil.info("======================y" + y);
		Log4jUtil.info("======================z" + z);
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 自定义域.
	 * 
	 * @param MsgPack4Abc
	 * @param customValue
	 */
	public static void createField60AbcConsume(final MsgPack4Abc MsgPack4Abc, final String customValue) {
		Log4jUtil.info("======================Consume==");
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_60;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());
		String len = customValue.getBytes().length / 2 + "";
		while (len.length() < 4) {
			len = "0" + len;
		}

		Log4jUtil.info("======================len==" + len);
		Log4jUtil.info("======================customValue==" + customValue);
		// System.arraycopy(customValue.getBytes(), 0, tempBytes, 2,
		// customValue.getBytes().length);
		// ABC固定长度
		// tempBytes[0]=0x00;
		// tempBytes[1]=0x06;
		final byte[] lenOfPrefix = ByteUtils.strToBcd(len);
		final byte[] value = hexStringToBytes(customValue);
		field.setOrigMsg(ArrayUtils.addAll(lenOfPrefix, value));
		String x = "", y = "", z = "";
		final byte[] mm = field.getOrigMsg();
		for (int i = 0; i < mm.length; i++) {
			x += AbcCreditMsgUtilService.encodehex(mm[i]) + " ";
			y += field.getOrigMsg()[i] + " ";
			z += AbcCreditMsgUtilService.encodehex(mm[i]);
		}

		Log4jUtil.info("======================x" + x);
		Log4jUtil.info("======================y" + y);
		Log4jUtil.info("======================z" + z);
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 自定义域61:交易类型码+批次号
	 * 
	 * @param MsgPack4Abc
	 * @param customValue
	 */
	public static void createField61(final MsgPack4Abc MsgPack4Abc, final String customValue) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_61;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(customValue.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * 自定义域:身份证ID或贷记卡（或准贷记卡）的3位校验位.
	 * 
	 * @param MsgPack4Abc
	 * @param customValue
	 */
	public static void createField62(final MsgPack4Abc MsgPack4Abc, final String customValue) {
		Log4jUtil.info("======================62==");
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_62;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());
		// byte[] tempBytes = new byte[customValue.getBytes().length + 2];
		String len = customValue.getBytes().length / 2 + "";
		while (len.length() < 4) {
			len = "0" + len;
		}

		final byte[] lenOfPrefix = ByteUtils.strToBcd(len);
		field.setOrigMsg(ArrayUtils.addAll(lenOfPrefix, ByteUtils.strToBcdLeftSide(customValue)));
		String x = "", y = "", z = "";
		final byte[] mm = field.getOrigMsg();
		for (int i = 0; i < mm.length; i++) {
			x += AbcCreditMsgUtilService.encodehex(mm[i]) + " ";
			y += field.getOrigMsg()[i] + " ";
			z += AbcCreditMsgUtilService.encodehex(mm[i]);
		}

		Log4jUtil.info("======================x" + x);
		Log4jUtil.info("======================y" + y);
		Log4jUtil.info("======================z" + z);
		// field.setOrigMsg(ByteUtils.strToBcdLeftSide(customValue));
		// field.setOrigMsg(customValue.getBytes());
		MsgPack4Abc.putBitmapField(field);

	}

	/**
	 * 自定义域:63
	 * 
	 * @param MsgPack4Abc
	 * @param customValue
	 */
	public static void createField63(final MsgPack4Abc MsgPack4Abc, final String customValue) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_63;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(customValue.getBytes());
		MsgPack4Abc.putBitmapField(field);
	}

	public static void createDefaultField63(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgField4Abc.create(MsgFieldType4Abc.FIELD_63.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("0001");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		MsgPack4Abc.putBitmapField(field);
	}

	/**
	 * MAC.
	 * 
	 * @param MsgPack4Abc
	 * @param macValue
	 */
	public static void createField64(final MsgPack4Abc MsgPack4Abc, final byte[] macValue) {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_64;
		final MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());
		field.setOrigMsg(macValue);
		// Log4jUtil
		// .info("======================MsgPack4Abc.putBitmapField(field);=");
		MsgPack4Abc.putBitmapField(field);
		// Log4jUtil
		// .info("======================MsgPack4Abc.putBitmapField(field);=");
	}

	// /**
	// * 计算mac.
	// *
	// * @param MsgPack4Abc
	// * @param posIdPrefix
	// * 终端标识前置,用于加密机中识别终端密钥数据
	// * @throws BizException
	// */
	// public static void mac(MsgPack4Abc MsgPack4Abc, String posIdPrefix)
	// throws BizException {
	// MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_64;
	// MsgField4Abc macField = MsgPack4Abc.getField(fieldType.getNo());
	//
	// // 取删除mac域后的报文数据.
	// byte[] msg = MsgPack4Abc.pack();
	// byte[] macData = ArrayUtils.subarray(msg, 13, msg.length); //
	// 从第14个字节开始
	// String posId = getPosId(MsgPack4Abc, posIdPrefix);
	// //TODO
	// String macString ="";
	// //String macString = new MpsMsgEncrypt().mac(posId, macData);
	// //XXX Leon AssertisTrue(macString != null && macString.length() == 8, "消息校验错:"
	// + macString);
	//
	// byte[] newMac = macString.getBytes();
	//
	// if (logger.isDebugEnabled()) {
	// StringBuilder sb = new StringBuilder();
	// sb.append("原mac:").append(macField == null ? "无" :
	// toHexString(macField.getOrigValue()));
	// sb.append(",新mac:").append(toHexString(newMac));
	// logger.debug(sb.toString());
	// }
	//
	// // 创建mac域.
	// if (macField == null) {
	// macField = MsgField4Abc.create(fieldType.getNo());
	// }
	//
	// // 设置值.
	// macField.setOrigMsg(newMac);
	// MsgPack4Abc.putBitmapField(macField);
	// }

	public static void resetTpduFrom(final MsgPack4Abc MsgPack4Abc, final String from) throws BizException {
		if (StringUtils.isEmpty(from)) {
			return;
		}

		final Tpdu tpdu = MsgPack4Abc.getTpdu();
		tpdu.setFrom(from);
		MsgPack4Abc.setTpdu(tpdu);
	}

	public static void resetTpduTo(final MsgPack4Abc MsgPack4Abc, final String to) throws BizException {
		if (StringUtils.isEmpty(to)) {
			return;
		}

		final Tpdu tpdu = MsgPack4Abc.getTpdu();
		tpdu.setTo(to);
		MsgPack4Abc.setTpdu(tpdu);
	}

	/**
	 * 复制源包中的域到目标包, 源包无指定域则不复制.
	 */
	public static void copyField(final MsgPack4Abc destPack, final MsgPack4Abc srcPack, final MsgFieldType4Abc fieldType) {
		final MsgField4Abc srcField = srcPack.getField(fieldType.getNo());

		if (srcField == null) {
			return;
		}

		final MsgField4Abc newField = srcField.clone();
		final int bitmapIndex = fieldType.getBitmapIndex();

		if (bitmapIndex >= 0) {
			destPack.putBitmapField(newField);
		} else {
			destPack.put(newField);
		}
	}

	/**
	 * 取终端zak密钥存到加密机中.
	 * 
	 * @throws BizException
	 */
	public static void saveKey(final MsgPack4Abc MsgPack4Abc, final String posIdPrefix) throws BizException {
		final String posId = getPosId(MsgPack4Abc, posIdPrefix);
		logger.debug("posId:" + posId);

		final String[] keys = getKey(MsgPack4Abc);
		logger.debug("keys:" + ArrayUtils.toString(keys));

		if (keys == null || keys.length != 4) {
			logger.debug("无key,不需保存");
			return;
		}

		// 保存zak.
		// TODO
		// int saveResult = new MpsMsgEncrypt().saveZAK(posId, keys[2],
		// keys[3]);
		// //XXX Leon AssertisTrue(saveResult == 0, "密钥保存失败:" + saveResult);
	}

	private static String getPosId(final MsgPack4Abc MsgPack4Abc, final String posIdPrefix) {
		MsgField4Abc field = MsgPack4Abc.getField(MsgFieldType4Abc.FIELD_42.getNo());
		final String merchantNo = field.getStringValue();
		field = MsgPack4Abc.getField(MsgFieldType4Abc.FIELD_41.getNo());
		final String terminalNo = field.getStringValue();

		return posIdPrefix + merchantNo + terminalNo;
	}

	/**
	 * 取终端密钥.
	 * 
	 * @param MsgPack4Abc
	 * @return 0:ZPK, 1:ZPK校验值, 2:ZAK, 3:ZAK校验值
	 */
	public static String[] getKey(final MsgPack4Abc MsgPack4Abc) {
		final MsgField4Abc field = MsgPack4Abc.getField(MsgFieldType4Abc.FIELD_62.getNo());

		if (field == null) {
			return null;
		}

		final byte[] keyByte = field.getOrigValue();
		final int length = keyByte.length;
		final int[] FIELD_LEN = new int[] { 24, 40, 56 };

		// 错误的长度.
		if (!ArrayUtils.contains(FIELD_LEN, length)) {
			logger.debug("密钥总长度错误:" + length);
			return null;
		}

		// 密钥长度为24,40,56时校验值长度都为4.
		// zpk和zak只取前8个字节.
		final int KEY_LEN = 8;
		final int CHECK_LEN = 4;
		final byte[] zpkByte = ArrayUtils.subarray(keyByte, 0, length / 2);
		final byte[] zpkKeyByte = ArrayUtils.subarray(zpkByte, 0, KEY_LEN);
		final byte[] zpkCheckByte = ArrayUtils.subarray(zpkByte, zpkByte.length - CHECK_LEN, zpkByte.length);

		final byte[] zakByte = ArrayUtils.subarray(keyByte, length / 2, length);
		final byte[] zakKeyByte = ArrayUtils.subarray(zakByte, 0, KEY_LEN);
		final byte[] zakCheckByte = ArrayUtils.subarray(zakByte, zakByte.length - CHECK_LEN, zakByte.length);

		return new String[] { toHexString(zpkKeyByte, false), toHexString(zpkCheckByte, false),
				toHexString(zakKeyByte, false), toHexString(zakCheckByte, false) };
	}

	public static String toHexString(final MsgPack4Abc MsgPack4Abc) throws BizException {
		return toHexString(MsgPack4Abc.getBytes());
	}

	public static String toHexString(final byte[] bytes) {
		final StringBuilder sb = new StringBuilder();

		for (final byte b : bytes) {
			final String hexByte = ByteUtils.toHexString(b & 0xff, 2);
			sb.append("[").append(hexByte.toUpperCase()).append("]");
		}
		return sb.toString();
	}

	public static String toHexString(final byte[] bytes, final boolean hasSeparator) {
		final StringBuilder sb = new StringBuilder();

		for (final byte b : bytes) {
			final String hexByte = ByteUtils.toHexString(b & 0xff, 2);

			if (hasSeparator) {
				sb.append("[");
			}

			sb.append(hexByte.toUpperCase());

			if (hasSeparator) {
				sb.append("]");
			}
		}
		return sb.toString();
	}

	public static byte[] hexStringToBytes(String hexString) {
		if (hexString == null || hexString.equals("")) {
			return null;
		}
		hexString = hexString.toUpperCase();
		final int length = hexString.length() / 2;
		final char[] hexChars = hexString.toCharArray();
		final byte[] d = new byte[length];
		for (int i = 0; i < length; i++) {
			final int pos = i * 2;
			d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
		}
		return d;
	}

	private static byte charToByte(final char c) {
		return (byte) "0123456789ABCDEF".indexOf(c);
	}

	/**
	 * 计算mac.
	 * 
	 * @param msgPack
	 * @param posIdPrefix 终端标识前置,用于加密机中识别终端密钥数据
	 * @throws BizException
	 */
	public static void create64mac(final MsgPack4Abc MsgPack4Abc, final byte[] macKey) throws Exception {
		final MsgFieldType4Abc fieldType = MsgFieldType4Abc.FIELD_64;
		MsgField4Abc field = MsgField4Abc.create(fieldType.getNo());

		final byte[] msg = MsgPack4Abc.pack();
		AbcCreditMsgUtilService.displayByteArray(msg, "完整报文为");

		final byte[] macData = ArrayUtils.subarray(msg, 7, msg.length);
		Log4jUtil.info("参与mac加密的数据为：{}", AbcCreditMsgUtilService.byte2HexStr(macData));

		final byte[] Mab = getMacDate(macData);
		AbcCreditMsgUtilService.displayByteArray(Mab, "全报文的按位异或运算结果Mab");
		final byte[] field64 = J2DES.des_crypt(macKey, Mab);

		AbcCreditMsgUtilService.displayByteArray(field64, "64域完整结果，MAC运算结果");

		// 创建mac域.
		if (field == null) {
			field = MsgField4Abc.create(fieldType.getNo());
		}

		// 设置值.
		field.setOrigMsg(field64);
		MsgPack4Abc.putBitmapField(field);

	}

	public static byte[] getMacDate(byte[] orgByteDate) {
		// byte[] mackey=LoUtils.hexStr2Bytes(mkey);

		// 补为8的整数倍
		if (orgByteDate.length % 8 != 0) {
			orgByteDate = ArrayUtils.addAll(orgByteDate, new byte[8 - orgByteDate.length % 8]);
		}

		// 源数据转换成int数组
		final int[] orgIntDate = new int[orgByteDate.length];
		for (int i = 0; i < orgByteDate.length; i++) {
			orgIntDate[i] = orgByteDate[i];
			// orgIntDate[i] = ByteUtils.getIntValueFromAsc(orgByteDate[i]);
			// System.out.print(orgIntDate[i]);
			// System.out.print(" ");
		}

		// 创建BLOCK数组MAB
		final int[][] mabBlock = new int[orgByteDate.length / 8][8];
		// System.out.println("拆分MAB的块数：" + mabBlock.length);

		// 赋值
		for (int i = 0; i < mabBlock.length; i++) {
			for (int j = 0; j < 8; j++) {
				mabBlock[i][j] = orgByteDate[i * 8 + j];
				// System.out.print(mabBlock[i][j]);
				// System.out.print(" ");
			}
		}

		// b. 对MAB，按每8个字节做异或（不管信息中的字符格式），如果最后不满8个字节，则添加“0X00”
		final byte[] tempBlock = new byte[8];
		for (int j = 0; j < mabBlock.length - 1; j++) {
			for (int i = 0; i < 8; i++) {
				if (j == 0) {
					tempBlock[i] = (byte) (mabBlock[j][i] ^ mabBlock[j + 1][i]);
				} else {
					tempBlock[i] = (byte) (tempBlock[i] ^ mabBlock[j + 1][i]);
				}
				// MsgUtil4Abc.displayByteArray(tempBlock,"全报文每轮按位异或运算tempBlock结果");
			}
			Log4jUtil.info("*******************************" + j);
		}
		return tempBlock;
	}
}
