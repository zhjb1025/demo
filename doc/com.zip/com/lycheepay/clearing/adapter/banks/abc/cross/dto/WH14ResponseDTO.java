package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH14ResponseDTO extends AbcCrossBeanBase {

	public WH14ResponseDTO() {
		super.addField(new AbcCrossBeanField("transCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("procCode", 6, true, ' '));
		super.addField(new AbcCrossBeanField("termID", 8, true, ' '));
		super.addField(new AbcCrossBeanField("merID", 10, true, ' '));
		super.addField(new AbcCrossBeanField("respCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("respMsg", 60, true, ' '));
		super.addField(new AbcCrossBeanField(AbcCrossConstant.STRING_MD5, 32, true, ' '));

	}

	public String getTransCode() {
		return data.get("transCode");
	}

	public void setTransCode(String transCode) {
		data.put("transCode", transCode);
	}

	public String getProcCode() {
		return data.get("procCode");
	}

	public void setProcCode(String procCode) {
		data.put("procCode", procCode);
	}

	public String getTermID() {
		return data.get("termID");
	}

	public void setTermID(String termID) {
		data.put("termID", termID);
	}

	public String getMerID() {
		return data.get("merID");
	}

	public void setMerID(String merID) {
		data.put("merID", merID);
	}

	public String getRespCode() {
		return data.get("respCode");
	}

	public void setRespCode(String respCode) {
		data.put("respCode", respCode);
	}

	public String getRespMsg() {
		return data.get("respMsg");
	}

	public void setRespMsg(String respMsg) {
		data.put("respMsg", respMsg);
	}

}
