package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import java.nio.charset.Charset;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;


/**
 * <P>发送报文到农行CT</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-15 下午5:19:44
 */
@Service(ClearingAdapterAnnotationName.ABC_SEND2CT_VC)
public class AbcSend2CT_Vc {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	private static String channelId = ChannelIdEnum.ABC_CORP.getCode();

	/**
	 * 发送数据到服务器 socket
	 * 
	 * @param sendMsg 要发送的农企报文（不含报文报头）
	 * @throws BizException
	 */
	public String launch(final String sendMsg) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String SocketIP = channelParms.get("100010");
		String SocketPort = channelParms.get("100011");
		// 加包头
		final String xmlHead = addSpaceForNum(sendMsg);
		final String sendMsgAll = xmlHead + sendMsg;
		final SendBySocket sendBySocket = new SendBySocket();
		sendBySocket.setTimeout(600 * 1000); // 超时时间 60 秒
		String xmlStr = sendBySocket.sendAndRecv(SocketIP, SocketPort, sendMsgAll);
		// return StringUtils.substring(xmlStr, 7);
		return xmlStr;
	}
	
	public String launchBFJ(final String sendMsg) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String SocketIP = channelParms.get("100042");
		String SocketPort = channelParms.get("100043");
		// 加包头
		final String xmlHead = addSpaceForNum(sendMsg);
		final String sendMsgAll = xmlHead + sendMsg;
		final SendBySocket sendBySocket = new SendBySocket();
		sendBySocket.setTimeout(600 * 1000); // 超时时间 60 秒
		String xmlStr = sendBySocket.sendAndRecv(SocketIP, SocketPort, sendMsgAll);
		// return StringUtils.substring(xmlStr, 7);
		return xmlStr;
	}

	/**
	 * 生成包头的7个字节 -- 固定为7个字节长，第1字节为是否加密标志（0-不加密，1-加密）。后6个字节是数据包的长度
	 * 
	 * @param str 原字符串
	 * @param strLength 补串后的长度
	 * @return 补过空格后的字符串
	 */
	private String addSpaceForNum(final String xmlInfo) {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String encryptTag = channelParms.get("100013");
		String str = String.valueOf(xmlInfo.getBytes(Charset.forName("GBK")).length);
		return StringUtils.rightPad(encryptTag.trim() + str, 7); // 返回包头：第1字节为是否加密标志（0-不加密，1-加密），后6个字节是数据包的长度。
	}
}
