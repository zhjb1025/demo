package com.lycheepay.clearing.adapter.banks.abc.handler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.soofa.tx.service.BaseService;
import org.springframework.stereotype.Service;

import com.abc.pay.client.JSON;
import com.abc.pay.client.ebus.SettleRequest;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.util.Log4jUtil;
/**
 * 农行网银对账文件下载
 * @author lj
 *
 */
@Service(ClearingAdapterAnnotationName.ABC_NET_RECONCILIATION_FILE_SERVICE)
public class AbcNetReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	@Override
	public String getReconciliationFile(String fileSavePath, String channelId, String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC_NET", "getReconFile");
		String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try{
			reconciliationFileDTOList = buildTransactionDataList(channelId, settleDate);
		} catch(Exception e){
			Log4jUtil.error(e);
//			throw new ClearingAdapterBizCheckedException(e.getMessage(), e.getMessage());
		}
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");

		String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate, reconciliationFileDTOList);
		
		return fileFullPath;

	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @author 李斌(13665100450)
	 * @param resultXml 银行返回xml回执
	 * @param channelId 渠道ID
	 * @param channelParms 渠道参数
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
		List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		SettleRequest settleRequest = new SettleRequest();
		//日期格式 YYYY/MM/DD
		try {
			settleRequest.dicRequest.put("SettleDate", new SimpleDateFormat("yyyy/MM/dd").format(new SimpleDateFormat("yyyyMMdd").parse(settleDate)));
			settleRequest.dicRequest.put("ZIP", "0");  ///不压缩
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new ClearingAdapterBizCheckedException(e.getMessage(), e.getMessage());
		}
		//第一个商户号的对账文件
		reconciliationFileDTOList = this.extendPostRequest(reconciliationFileDTOList, settleRequest, 1, settleDate, channelId);
		//第二个商户号的对账文件
		reconciliationFileDTOList = this.extendPostRequest(reconciliationFileDTOList, settleRequest, 2, settleDate, channelId);
		
		Log4jUtil.info("总共获取的对账文件条数为:{}", reconciliationFileDTOList.size());
		return reconciliationFileDTOList;
	}

	private List<ReconciliationFileDTO> extendPostRequest(List<ReconciliationFileDTO> reconciliationFileDTOList, SettleRequest settleRequest, int count, String settleDate, String channelId) throws ClearingAdapterBizCheckedException {
		JSON result = settleRequest.extendPostRequest(count);
		if ("0000".equals(result.GetKeyValue("ReturnCode"))) {
			//成功获取
			String details = result.GetKeyValue("DetailRecords");//"商户号|交易类型|订单编号|交易时间|交易金额|商户账号|商户动账金额|客户账号|账户类型|商户回佣手续费|商户分期手续费|会计日期|主机流水号|9014流水号|原订单号^^103884100120003|Sale|4118032814090200000000092|20180328141339|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|327566556|3SECEP01135943783928|^^103884100120003|Sale|4118032816550200000000134|20180328165630|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|415037676|3SECEP01163506964150|^^103884100120003|Sale|4118032816520200000000132|20180328165325|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|413496464|3SECEP01164927290722|^^103884100120003|Sale|4118032817200200000000136|20180328172151|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|426474632|3SECEP01170717769159|^^103884100120003|Sale|4118032817460200000000139|20180328174932|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|437362957|3SECEP01173356756300|^^103884100120003|Sale|4118032818050200000000145|20180328180536|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|442948991|3SECEP01175128712528|^^103884100120003|Sale|4118032818070200000000146|20180328180934|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|444374257|3SECEP01180550123698|";//
			Log4jUtil.info("获取的对账文件内容为:{}", details);
			String[] datas = details.split("\\^\\^");
			for (int i = 0;i < datas.length;i++) {
				if (i == 0) {
					continue;
				}
				String[] contents = datas[i].split("\\|");
				ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
				reconciliationFileDTO.setBankTransState("00");
				reconciliationFileDTO.setCheckDate(settleDate);
				reconciliationFileDTO.setBankSendId(contents[2]); // 订单号
				reconciliationFileDTO.setTransDate(contents[3].substring(0, 8)); // 交易日期
				reconciliationFileDTO.setAmount(new BigDecimal(contents[4]));// 元
				reconciliationFileDTO.setChannelId(channelId);
				if ("Sale".equalsIgnoreCase(contents[1])) {
					reconciliationFileDTO.setPayGet(STR_GET);
				} else if ("Refund".equalsIgnoreCase(contents[1])) {
					reconciliationFileDTO.setPayGet(STR_PAY);
				} else {
					Log4jUtil.error("不支持的交易类型:{}", contents[1]);
					reconciliationFileDTO.setPayGet(STR_PAY);
				}
				Log4jUtil.info("第" + i + "条对账文件内容为:{}", reconciliationFileDTO);
				reconciliationFileDTOList.add(reconciliationFileDTO);
			}
		} else {
			if ("AP5491".equalsIgnoreCase(result.GetKeyValue("ReturnCode"))) {
				//对账下载过于频繁
				Log4jUtil.error("获取对账文件失败:errCode {}, errMessage {}" , result.GetKeyValue("ReturnCode"), result.GetKeyValue("ErrorMessage"));
				throw new ClearingAdapterBizCheckedException("获取对账文件失败:errCode " + result.GetKeyValue("ReturnCode"), " ErrorMessage " + result.GetKeyValue("ErrorMessage"));
			} else {
				//其它错误不抛出异常
				Log4jUtil.error("获取对账文件失败:errCode {}, errMessage {}" , result.GetKeyValue("ReturnCode"), result.GetKeyValue("ErrorMessage"));
			}
		}
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}
	
	public static void main(String[] args) throws ClearingAdapterBizCheckedException {
		//商户号|交易类型|订单编号|交易时间|交易金额|商户账号|商户动账金额|客户账号|账户类型|商户回佣手续费|商户分期手续费|会计日期|主机流水号|9014流水号|原订单号^^103884100120003|Sale|4118032814090200000000092|20180328141339|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|327566556|3SECEP01135943783928|^^103884100120003|Sale|4118032816550200000000134|20180328165630|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|415037676|3SECEP01163506964150|^^103884100120003|Sale|4118032816520200000000132|20180328165325|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|413496464|3SECEP01164927290722|^^103884100120003|Sale|4118032817200200000000136|20180328172151|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|426474632|3SECEP01170717769159|^^103884100120003|Sale|4118032817460200000000139|20180328174932|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|437362957|3SECEP01173356756300|^^103884100120003|Sale|4118032818050200000000145|20180328180536|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|442948991|3SECEP01175128712528|^^103884100120003|Sale|4118032818070200000000146|20180328180934|0.01|41011200040004999|0.01|6228480018713367078|401|0.00|0.00|20180328|444374257|3SECEP01180550123698|
		new AbcNetReconciliationFileService().getReconciliationFile("D:\\WORK\\log", ChannelIdEnum.ABC_NET.getCode(), "20180329");
	}
}
