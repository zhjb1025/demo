package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class CT2ERP_PublicBean {

	// CT2ERP请求报文公共字段
	private String TransCode; // 交易代码
	private String ReqSeqNo; // 请求方流水号
	private String RespSource; // 返回来源
	private String RespSeqNo; // 应答流水号
	private String RespDate; // 返回日期
	private String RespTime; // 返回时间
	private String RespCode; // 返回码
	private String RespInfo; // 返回信息
	private String RxtInfo; // 返回扩展信息
	private String FileFlag; // 数据文件标识
	private String RecordNum; // 记录数
	private String FieldNum; // 字段数
	private String RespPrvData; // 私有数据区
	private String BatchFileName; // 批量文件名

	public String getTransCode() {
		return TransCode;
	}

	public void setTransCode(final String transCode) {
		TransCode = transCode;
	}

	public String getReqSeqNo() {
		return ReqSeqNo;
	}

	public void setReqSeqNo(final String reqSeqNo) {
		ReqSeqNo = reqSeqNo;
	}

	public String getRespSource() {
		return RespSource;
	}

	public void setRespSource(final String respSource) {
		RespSource = respSource;
	}

	public String getRespSeqNo() {
		return RespSeqNo;
	}

	public void setRespSeqNo(final String respSeqNo) {
		RespSeqNo = respSeqNo;
	}

	public String getRespDate() {
		return RespDate;
	}

	public void setRespDate(final String respDate) {
		RespDate = respDate;
	}

	public String getRespTime() {
		return RespTime;
	}

	public void setRespTime(final String respTime) {
		RespTime = respTime;
	}

	public String getRespCode() {
		return RespCode;
	}

	public void setRespCode(final String respCode) {
		RespCode = respCode;
	}

	public String getRespInfo() {
		return RespInfo;
	}

	public void setRespInfo(final String respInfo) {
		RespInfo = respInfo;
	}

	public String getRxtInfo() {
		return RxtInfo;
	}

	public void setRxtInfo(final String rxtInfo) {
		RxtInfo = rxtInfo;
	}

	public String getFileFlag() {
		return FileFlag;
	}

	public void setFileFlag(final String fileFlag) {
		FileFlag = fileFlag;
	}

	public String getRecordNum() {
		return RecordNum;
	}

	public void setRecordNum(final String recordNum) {
		RecordNum = recordNum;
	}

	public String getFieldNum() {
		return FieldNum;
	}

	public void setFieldNum(final String fieldNum) {
		FieldNum = fieldNum;
	}

	public String getRespPrvData() {
		return RespPrvData;
	}

	public void setRespPrvData(final String respPrvData) {
		RespPrvData = respPrvData;
	}

	public String getBatchFileName() {
		return BatchFileName;
	}

	public void setBatchFileName(final String batchFileName) {
		BatchFileName = batchFileName;
	}

}
