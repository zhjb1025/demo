package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.banks.abc.credit.kft.util.AbcCreditMsgUtilService;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>构建发往农业银行的报文域.</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午3:28:37
 */
public class MsgField4Abc implements Cloneable {
	private int contentType;
	private String no;
	private int maxLength;

	// 原始信息, 包括长度等.
	private byte[] origMsg;

	// 原始信息中值的长度数值所占的长度, 如"9个字节"中"9"的长度为1.
	// 由解析器初始化时指定并赋值到域实体, 变长域有效.
	private boolean hasLeaderLength;
	private int lenOfLeaderLength;

	// 原始信息中的值,不包括长度标识.
	private byte[] origValue;

	// 不包括长度,并且已解压解码后的值.
	private byte[] value;

	public boolean isHasLeaderLength() {
		return hasLeaderLength;
	}

	public void setHasLeaderLength(final boolean hasLeaderLength) {
		this.hasLeaderLength = hasLeaderLength;
	}

	public void setOrigValue(final byte[] origValue) {
		this.origValue = origValue;
	}

	public byte[] getOrigValue() {
		if (origValue != null) {
			return origValue;
		}

		// 从原始消息中获取.
		origValue = hasLeaderLength ? ArrayUtils.subarray(origMsg, lenOfLeaderLength, origMsg.length) : origMsg;

		return origValue;
	}

	public int getContentType() {
		return contentType;
	}

	public void setContentType(final int contentType) {
		this.contentType = contentType;
	}

	/**
	 * 原信息中内容的约定长度, 定长域时为最大长度, 变长域时由前导的长度标识计算得出.
	 * 
	 * @return
	 */
	private int getLeaderLengthValue() {
		// 没有前导长度标识, 表明为定长域, 返回最大长度.
		if (!hasLeaderLength) {
			return maxLength;
		}

		// 原始信息不够指定的前导长度时无法计算出值的长度, 一般在原信息不足前导长度时不会调用此方法.
		if (origMsg == null || origMsg.length < lenOfLeaderLength) {
			return 0;
		}

		final byte[] lenByte = ArrayUtils.subarray(origMsg, 0, lenOfLeaderLength);

		return ByteUtils.bcdToInt(lenByte);
	}

	public int getLenOfLeaderLength() {
		return lenOfLeaderLength;
	}

	public void setLenOfLeaderLength(final int leaderLength) {
		this.lenOfLeaderLength = leaderLength;
	}

	public int getOrigMsgLength() {
		return origMsg == null ? 0 : origMsg.length;
	}

	public byte[] getOrigMsg() {
		return origMsg;
	}

	/**
	 * 设置原始消息,同时置空origValue和value
	 * 
	 * @param origMsg
	 */
	public void setOrigMsg(final byte[] origMsg) {
		this.origMsg = origMsg;
		this.origValue = null;
		this.value = null;
	}

	public int getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(final int maxLength) {
		this.maxLength = maxLength;
	}

	public String getNo() {
		return no;
	}

	public void setNo(final String name) {
		this.no = name;
	}

	public int getRealLength() {
		int realLength = 0;
		if (lenOfLeaderLength > 0) {
			final byte[] lenByte = ArrayUtils.subarray(origMsg, 0, lenOfLeaderLength);
			realLength = Integer.parseInt(bcd2Str(lenByte));
		} else {
			realLength = -111;
		}
		return realLength;
	}

	public String getStringValue() {

		if (hasLeaderLength) {
			final byte[] preValue = ArrayUtils.subarray(origMsg, 0 + lenOfLeaderLength, 0 + lenOfLeaderLength
					+ getRealLength());
			Log4jUtil.info("=========长度方法==" + getRealLength());
			String x = "", y = "";
			for (final byte element : preValue) {
				y += AbcCreditMsgUtilService.encodehex(element) + " ";
				x += AbcCreditMsgUtilService.encodehex(element) + "";
			}
			Log4jUtil.info("=========preValue==" + y);
			Log4jUtil.info("=========x==" + x);
			return x;
			// return new String(preValue);
		} else {
			return new String(getValue());
		}

	}

	public int getIntValue() {
		return Integer.parseInt(getStringValue());
	}

	public long getLongValue() {
		return Long.parseLong(getStringValue());
	}

	public Double getDoubleValue() {
		return Double.parseDouble(getStringValue());
	}

	private byte[] getValue() {
		if (value == null) {
			setValueFromOrigValue();
		}

		return value;
	}

	private void setValueFromOrigValue() {
		if (IsoType.ASCII == contentType || IsoType.BINARY == contentType) {
			value = getOrigValue();
		} else if (IsoType.BCD == contentType) {
			value = ByteUtils.bcdToStr(getOrigValue()).getBytes();
		}
	}

	/**
	 * 取去除长度后域内容约定的长度.
	 * 
	 * @return
	 */
	public int getShouldOrigValueLength() {
		final int leaderLengthValue = getLeaderLengthValue();
		final int contentType = getContentType();

		// bcd编码,leaderLengthValue表示的是明文长度,需/2取bcd编码的长度.
		if (IsoType.BCD == contentType) {
			// 偶数取一半,奇数取+1后的一半.
			return (leaderLengthValue + 1) / 2;
		}
		// 其他编码形式直接返回前导长度的值.
		else {
			return leaderLengthValue;
		}
	}

	public void setValue(final byte[] value) {
		this.value = value;
	}

	public static MsgField4Abc create(final String no) {
		final MsgFieldType4Abc type = MsgFieldType4Abc.ALL.get(no);
		final MsgField4Abc field = new MsgField4Abc();
		field.setNo(type.getNo());
		field.setMaxLength(type.getMaxLength());
		field.setContentType(type.getContentType());

		return field;
	}

	@Override
	public MsgField4Abc clone() {
		final MsgField4Abc result = new MsgField4Abc();
		result.contentType = this.contentType;
		result.hasLeaderLength = this.hasLeaderLength;
		result.lenOfLeaderLength = this.lenOfLeaderLength;
		result.maxLength = this.maxLength;

		result.no = this.no;
		result.origMsg = this.origMsg;
		result.origValue = this.origValue;
		result.value = this.value;
		return result;
	}

	public static String bcd2Str(final byte[] bytes) {
		final StringBuilder temp = new StringBuilder(bytes.length * 2);

		for (final byte b : bytes) {
			temp.append((byte) ((b & 0xf0) >> 4));
			temp.append((byte) (b & 0x0f));
		}
		return temp.toString().substring(0, 1).equals("0") ? temp.toString().substring(1) : temp.toString();
	}

}
