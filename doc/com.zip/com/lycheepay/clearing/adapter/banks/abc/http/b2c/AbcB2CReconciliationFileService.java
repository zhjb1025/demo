/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.http.b2c;

import java.math.BigDecimal;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.soofa.tx.service.BaseService;
import org.springframework.stereotype.Service;

import com.hitrust.trustpay.client.TrxResponse;
import com.hitrust.trustpay.client.b2c.SettleFile;
import com.hitrust.trustpay.client.b2c.SettleRequest;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行B2C对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.ABC_B2C_RECONCILIATION_FILE_SERVICE)
public class AbcB2CReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		final String reconciliationDate = queryDate.substring(0, 4) + "/" + queryDate.substring(4, 6) + "/"
				+ queryDate.substring(6);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + reconciliationDate);

		// 生成商户对账单下载请求对象
		final SettleRequest tRequest = new SettleRequest();
		tRequest.setSettleDate(reconciliationDate); // 对账日期YYYY/MM/DD （必要信息）
		tRequest.setSettleType(SettleFile.SETTLE_TYPE_TRX);// 对账类型 （必要信息）

		Log4jUtil.info(logPrefix + "发送对账单下载请求到银行。");
		// 传送商户对账单下载请求并取得对账单
		final TrxResponse tResponse = tRequest.postRequest();

		// 判断商户对账单下载结果状态，进行后续操作
		if (tResponse.isSuccess()) {
			Log4jUtil.info(logPrefix + "成功收到银行返回的对账单对象tResponse。");

			// 商户对账单下载成功，生成对账单对象
			final SettleFile tSettleFile = new SettleFile(tResponse);

			/*5、若交易成功，则使用交易结果对象生成交易对账单对象
			com.hitrust.trustpay.client.SettleFile 
			 SettleDate    对账日期 
			 SettleType    对账类型 
			 NumOfPayments 该批次支付成功的交易总笔数 
			 SumOfPayAmount  该批次支付成功的交易总金额 
			 NumOfRefunds  该批次退货成功的交易总笔数 
			 SumOfRefundAmount  该批次退货成功的交易总金额 
			String tDate = tSettleFile.getSettleDate();  //注意格式需要转换成对账对象的 yyyyMMdd格式
			tDate = tDate.replaceAll("/", "");

			 6、使用交易对账单对象的 getDetailRecords()方法取得交易明细，每笔交易明细为字符
			串类型，使用逗号分隔不同的字段。字段信息如下： 
				 交易类型  P:支付交易  R:退货交易   订单号  交易金额  凭证号  交易时间 */
			final String[] tRecords = tSettleFile.getDetailRecords();
			logResponseResult(logPrefix, tSettleFile, tRecords);

			String tDate = tSettleFile.getSettleDate();
			tDate = tDate.replaceAll("/", "");
			final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(tRecords, tDate,
					channelId);
			Log4jUtil.info(logPrefix + "生成统一格式对账文件");

			final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
					queryDate, reconciliationFileDTOList);
			return fileFullPath;
		} else {
			final String errorMsg = logPrefix + "下载对账单出错!ReturnCode:" + tResponse.getReturnCode() + " ErrorMessage:"
					+ tResponse.getErrorMessage();
			Log4jUtil.error(errorMsg);
			throw new ClearingAdapterBizCheckedException(BusinessCode.GET_RECONCILIATION_FILE_FAILED, errorMsg);
		}
	}

	/**
	 * <p>记录银行返回对账元素</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param tSettleFile 银行响应对账文件对象
	 * @param tRecords 对账记录字符串数组
	 * @author 李斌(13665100450)
	 */
	private void logResponseResult(final String logPrefix, final SettleFile tSettleFile, final String[] tRecords) {
		String logMsg = logPrefix + "对账明细共有：" + tRecords.length + "行记录。\n";
		logMsg = logMsg + "对账日期:" + tSettleFile.getSettleDate() + "\n";
		logMsg = logMsg + "对账类型:" + tSettleFile.getSettleType() + "\n";
		logMsg = logMsg + "该批次支付成功的交易总笔数:" + tSettleFile.getNumOfPayments() + "\n";
		logMsg = logMsg + "该批次支付成功的交易总金额:" + tSettleFile.getSumOfPayAmount() + "\n";
		logMsg = logMsg + "该批次退货成功的交易总笔数:" + tSettleFile.getNumOfRefunds() + "\n";
		logMsg = logMsg + "该批次退货成功的交易总金额:" + tSettleFile.getSumOfRefundAmount() + "\n";
		Log4jUtil.info(logMsg);
		String mx = "\n";
		for (int i = 0; i < tRecords.length; i++) {
			mx = mx + "明细" + (i + 1) + ":" + tRecords[i].toString() + "\n";
		}
		Log4jUtil.info(mx);
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param tRecords
	 * @author 李斌(13665100450)
	 * @param reconciliationDate
	 * @param channelId
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String[] tRecords,
			final String reconciliationDate, final String channelId) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		final Format format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		for (int i = 0; i < tRecords.length; i++) {
			String tradeDate;
			final ReconciliationFileDTO ReconciliationFileDTO = new ReconciliationFileDTO();
			final String[] detail = tRecords[i].split(",");
			if (detail[0].toString().trim().substring(detail[0].toString().trim().length() - 1).equals("R")) {
				Log4jUtil.info("第" + (i + 1) + "条明细为退款数据。该数据不进行对账处理。订单号为：" + detail[1].toString() + " 金额为："
						+ detail[2].toString() + " 交易时间为：" + detail[4].toString());
				continue;
			}
			ReconciliationFileDTO.setChannelId(channelId);
			ReconciliationFileDTO.setBankSendId(detail[1].toString()); // 渠道（银行）端的流水(订单号)
			ReconciliationFileDTO.setAmount(new BigDecimal(detail[2]));// 交易金额
			if (ReconciliationFileDTO.getAmount().compareTo(BigDecimal.ZERO) > 0) {
				ReconciliationFileDTO.setPayGet(STR_GET);
			} else {
				ReconciliationFileDTO.setPayGet(STR_PAY);
			}
			try {
				tradeDate = DateUtil.getDate((Date) format.parseObject(detail[4].toString()));
			} catch (final ParseException e) {
				throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, "解析交易日期["
						+ detail[4].toString() + "]失败");
			}
			ReconciliationFileDTO.setTransDate(tradeDate); // 交易日期,长度为 8 位
			ReconciliationFileDTO.setBankTransState("00");
			ReconciliationFileDTO.setCheckDate(reconciliationDate);
			String logMsg = "用明细" + (i + 1) + "构造ReconciliationFileDTO，添加到reconciliationFileDTOList的第" + (i + 1)
					+ "条记录:";
			logMsg = logMsg + " checkDate:" + ReconciliationFileDTO.getCheckDate() + " BankSendSn:"
					+ ReconciliationFileDTO.getBankSendId();
			logMsg = logMsg + " TranDate:" + ReconciliationFileDTO.getTransDate() + " TradeAmount:"
					+ ReconciliationFileDTO.getAmount();
			Log4jUtil.info(logMsg);
			reconciliationFileDTOList.add(ReconciliationFileDTO);
		}
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

}
