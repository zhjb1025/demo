package com.lycheepay.clearing.adapter.banks.abc.http.b2b;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;


/**
 * <P>农业银行B2B HTTP(后台直接交互)请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 上午10:30:56
 */
@Service(ClearingAdapterAnnotationName.ABC_B2B_DIRECT_PROCESS)
public class AbcB2BDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

}
// XXX Batch 批量代付By:Leon.Qiu[2012-6-18 上午10:33:14]
// @Override
// public ReturnState deal(final Param param) throws BizException {
// String logMsg = "";
// final String channelId = param.getChannelId();
// final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
// logMsg = "进入" + logPrefix + "渠道业务处理。";
// Log4jUtil.info(logMsg);
// if (param.getChannelTransType().equals(ChannelTransType.Qury_Single_Trans)) {
// // 单笔查询
// return this.queryOrder(logPrefix, channelId, param);
// } else if (param.getChannelTransType().equals("settle")) { // 下载和自动对账，由定时任务处理，不在此调用
// return this.settle(logPrefix, channelId, param.getSn());
// } else if (param.getChannelTransType().equals(ChannelTransType.PayRefund)) { // 退货
// if (param.getTransType().equals(TransType.NetPay_Refund)
// || param.getTransType().equals(TransType.Direct_Refund)) {
// return this.batchRefund(param);
// }
// throw new BizException(logPrefix + "错误的业务类型:" + param.getChannelTransType() + ":" +
// param.getTransType());
// } else {
// throw new BizException("错误的业务类型:" + param.getChannelTransType() + ":" +
// param.getTransType());
// }
// }

// XXX Batch 批量代付By:Leon.Qiu[2012-6-18 上午10:33:14]
// /**
// * 批量退款、包括批量退款重发
// *
// * @param param
// * @return ReturnState
// * @throws BizException
// */
// private ReturnState batchRefund(final Param param) throws BizException {
// final CreatBatchRefundFile creatBatchRefundFile = new CreatBatchRefundFile();
// final String fileNamePrefix = param.getChannelId();
// final ReturnState returnState = creatBatchRefundFile.batchRefund(param, fileNamePrefix, 4,
// "CSV", 0);
// return returnState;
// }

// XXX 对账 批量代付By:Leon.Qiu[2012-6-18 上午10:33:14]
// /**
// * 农行B2B网银对账（支付、退货）
// *
// * @param settleDate
// * @return
// * @throws BizException
// */
// private ReturnState settle(final String logPrefix, final String channelId, String settleDate)
// throws BizException {
// String logMsg = "";
// logMsg = "进入" + logPrefix + "对账处理。传进对账日期参数为：" + settleDate;
// Log4jUtil.info(logMsg);
// if (settleDate.length() == 0) { // 如果不传入日期，则选择前一天的日期为清算日期的交易
// settleDate = DateUtil.getDate(DateUtil.addDays(new Date(), -1));
// Log4jUtil.info("传进日期为空。自动设置对账日期为：" + settleDate + "。继续对账处理。");
// } else if (settleDate.length() != 8) {
// throw new BizException("错误：对账日期：" + settleDate + "长度不是8位，" + logPrefix + "对账处理中止。");
// }
// logMsg = logPrefix + "本次对账日期为：" + settleDate;
// Log4jUtil.info(logMsg);
//
// final ArrayList<AccBean> accBeanList = new ArrayList<AccBean>();
// // 1、取得商户对账单下载所需要的信息
// final String tMerchantRemarks = "";
// String tMerchantTrnxDate = settleDate.substring(0, 4) + "/" + settleDate.substring(4, 6) +
// "/"
// + settleDate.substring(6);// 对账单日期
//
// // 2、生成下载交易记录请求对象
// final DownloadTrnxRequest tDownloadTrnxRequest = new DownloadTrnxRequest();
// tDownloadTrnxRequest.setMerchantTrnxDate(tMerchantTrnxDate); // 设定商户交易编号
// // （必要信息）
// tDownloadTrnxRequest.setMerchantRemarks(tMerchantRemarks); // 设定商户备注信息
//
// // 3、传送下载交易记录
// logMsg = logPrefix + "发送对账单下载请求到银行。";
// Log4jUtil.info(logMsg);
// ObjectUtil.printPropertyString(logPrefix, tDownloadTrnxRequest);
// final TrxResponse tTrxResponse = tDownloadTrnxRequest.postRequest();
// ObjectUtil.printPropertyString(logPrefix, tTrxResponse);
// if (tTrxResponse.isSuccess() || tTrxResponse.getReturnCode().equals("2602")) {
// logMsg = logPrefix + "成功收到银行返回的对账单对象TrxResponse。";
// Log4jUtil.info(logMsg);
// /*
// * 4、若下载交易记录请求执行成功，则可以取得交易明细，每笔交易明细为字符串类型，使用 逗号分隔不同的字段。字段信息依次如下： 交易类型
// * 目前只提供直接支付（FUND_TRANSFER）一种交易类型 商户交易编号 交易金额 交易时间 交易状态 成功（2）、失败（3）、作废（5）
// */
// final XMLDocument tDetailRecords = new XMLDocument(tTrxResponse.getValue("TrnxDetail"));
// final ArrayList<?> tRecords = tDetailRecords.getDocuments("TrnxRecord");
// final String[] iRecord = new String[tRecords.size()];
// final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
// // if (tRecords.size() > 0) {
//
// String mx = "\n";
// for (int i = 0; i < tRecords.size(); i++) {
// mx = mx + "明细" + (i + 1) + ":" + tRecords.get(i).toString() + "\n";
// }
// Log4jUtil.info(mx);
// for (int i = 0; i < tRecords.size(); i++) {
// iRecord[i] = ((XMLDocument) tRecords.get(i)).toString();
// final AccBean accBean = new AccBean();
// final String[] detail = iRecord[i].split(",");
// // if
// //
// (detail[0].toString().trim().substring(detail[0].toString().trim().length()-1).equals("R")){
// // logMsg = "第" +(i+1)+"条明细为退款数据。该数据不进行对账处理。订单号为："+detail[1].toString()+
// // " 金额为："+detail[2].toString() +" 交易时间为："+detail[4].toString();
// Log4jUtil.info(logMsg);
// // continue;
// // }
// accBean.setCheckDate(settleDate);
// accBean.setBankSendSn(detail[1].toString()); // 渠道（银行）端的流水(订单号)
// accBean.setTradeAmount(Double.valueOf(detail[2]));// 交易金额
// if (accBean.getTradeAmount() > 0) {
// accBean.setPay_get("get");
// } else {
// // accBean.setTradeAmount(Math.abs(accBean.getTradeAmount()));
// accBean.setPay_get("pay");
// }
// try {
// tMerchantTrnxDate = DateUtil.getDate(format.parse(detail[3].toString()));
// } catch (final ParseException e) {
// Log4jUtil.error( e);
// throw new BizException(e);
// }
// accBean.setTranDate(tMerchantTrnxDate); // 账务日期
// String bankTradestate = "";
//
// if (detail[4].trim().substring(0, 1).equals("2")) { // 2 成功、3 失败、5 作废。。
// // 什么情况下为作废单？退款的是否为作废单？
// bankTradestate = "00";
// } else if ((detail[4].trim().substring(0, 1).equals("3") || (detail[4].trim().substring(0, 1)
// .equals("5")))) {
// bankTradestate = "01";
// }
//
// accBean.setBankTradestate(bankTradestate);// 渠道（银行）交易状态
// // 00-支付成功；01-支付失败；02-超时；和
// logMsg = "用明细" + (i + 1) + "构造accBean，添加到accBeanList的第" + (i + 1) + "条记录:";
// logMsg = logMsg + " checkDate:" + accBean.getCheckDate() + " BankSendSn:" +
// accBean.getBankSendSn();
// logMsg = logMsg + " TranDate:" + accBean.getTranDate() + " TradeAmount:" +
// accBean.getTradeAmount();
// Log4jUtil.info(logMsg);
// accBeanList.add(accBean);
// }
// logMsg = logPrefix + "调用公用对账方法accUtilService.createFileAndCheck";
// Log4jUtil.info(logMsg);
// final int Ret = accUtilService.createFileAndCheck(accBeanList, channelId, settleDate);// 对账结果
// // 成功0、失败1
// if (Ret != 0) {
// Log4jUtil.info(logPrefix + "对账出错！");
// }
// final ReturnState returnState = new ReturnState();
// returnState.setReturnState(PayState.SUCCEED_RTN);
// returnState.setBankRetCode(tTrxResponse.getReturnCode());
// returnState.setBankPostScript(tTrxResponse.getErrorMessage());
// ChannelRtncode channelRtncode = null;
// channelRtncode = channelRtncodeDao.findById(new ChannelRtncodeId(channelId,
// tTrxResponse.getReturnCode()));
// if (channelRtncode == null) {
// logMsg = "表  channel_rtncode 没有对应的" + channelId + "银行返回信息" + tTrxResponse.getReturnCode();
// Log4jUtil.info(logMsg);
// returnState.setReturnMsg(logMsg);
// returnState.setChannelCode(TransReturnCode.code_9900);
// } else {
// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
// returnState.setChannelCode(channelRtncode.getKftRtncode());
// }
// ObjectUtil.printPropertyString(logPrefix, returnState);
// return returnState;
// // }
// // else {
// // throw new BizException("无当日对账数据!ReturnCode:" +
// // tTrxResponse.getReturnCode() + " ErrorMessage:" +
// // tTrxResponse.getErrorMessage());
// // }
// } else {
// logMsg = logPrefix + "下载对账单出错!ReturnCode:" + tTrxResponse.getReturnCode() + " ErrorMessage:"
// + tTrxResponse.getErrorMessage();
// Log4jUtil.error(logMsg);
// throw new BizException(logMsg);
// }
// }
//
// /**
// * 交易查询
// *
// * @param param
// * @return
// * @throws BizException
// */
// private ReturnState queryOrder(final String logPrefix, final String channelId, final Param
// param)
// throws BizException {
// String logMsg;
// logMsg = "开始" + logPrefix + "订单查询处理。";
// Log4jUtil.info(logMsg);
// // 1、取得商户订单查询所需要的信息 订单号
// String sn = "";// 本系统交易流水号
// String tMerchantTrnxNo = "";// 先获取原订单号，再到billno查发往银行的订单号
// String tMerchantRemarks = "";
// // 根据不同的业务，取不同的实体,获取订单号
// if (param.getTransType().equals(TransType.Direct_Pay) ||
// param.getTransType().equals(TransType.Guarantee_Pay)
// || param.getTransType().equals(TransType.Protocol_Debit_Real)) {
// final Paybill paybill = (Paybill) param.getBizBean();
// if (paybill == null) {
// throw new BizException(logPrefix + "获取到的支付对象为NULL。");
// }
// ObjectUtil.printPropertyString(logPrefix, paybill);
// sn = paybill.getSn();
// tMerchantRemarks = sn;
// } else if (param.getTransType().equals(TransType.Recharge)) {
// final Rechargebill rechargeBill = (Rechargebill) param.getBizBean();
// if (rechargeBill == null) {
// throw new BizException(logPrefix + "获取到的充值对象为NULL。");
// }
// ObjectUtil.printPropertyString(logPrefix, rechargeBill);
// sn = rechargeBill.getSn();
// tMerchantRemarks = sn;
// } else {
// logMsg = logPrefix + "错误的交易类型。";
// Log4jUtil.info(logMsg);
// throw new BizException(logMsg);
// }
// tMerchantTrnxNo = billnoSnService.findBankSendSnBySn(sn);
// AssertUtils.notEmpty(tMerchantTrnxNo, logPrefix + "查询不到发往银行的交易流水号！");
//
// // 2、生成交易查询请求对象
// final QueryTrnxRequest tQueryTrnxRequest = new QueryTrnxRequest();
// tQueryTrnxRequest.setMerchantTrnxNo(tMerchantTrnxNo); // 设定商户交易编号（必要信息）
// tQueryTrnxRequest.setMerchantRemarks(tMerchantRemarks); // 设定商户备注信息
// final ReturnState returnState = new ReturnState();
// // 3、传送交易查询请求并取得支付网址
// logMsg = logPrefix + "向银行发起交易流水为：" + sn + " 订单号为:" + tMerchantTrnxNo + "查询请求。";
// Log4jUtil.info(logMsg);
// ObjectUtil.printPropertyString(logPrefix, tQueryTrnxRequest);
// final TrxResponse tTrxResponse = tQueryTrnxRequest.postRequest();
// ObjectUtil.printPropertyString(logPrefix, tTrxResponse);
// if (tTrxResponse.isSuccess()) {
// logMsg = logPrefix + "成功获取到银行返回的的B2B订单查询对象。";
// Log4jUtil.info(logMsg);
// // 4、交易查询请求提交成功
// // out.println("TrnxType = [" + tTrxResponse.getValue("TrnxType" ) +
// // "]<br>");
// // out.println("TrnxAMT = [" + tTrxResponse.getValue("TrnxAMT" ) +
// // "]<br>");
// // out.println("MerchantID = [" + tTrxResponse.getValue("MerchantID"
// // ) + "]<br>");
// // out.println("MerchantTrnxNo = [" +
// // tTrxResponse.getValue("MerchantTrnxNo") + "]<br>");
// // out.println("ReturnCode = [" +
// // tTrxResponse.getValue("ReturnCode") + "]<br>");
// returnState.setReturnState(PayState.SUCCEED_RTN);
// returnState.setSn(sn);// 原交易流水
// final String bankRetCode = ChannelTransType.Qury_Single_Trans +
// tTrxResponse.getValue("ReturnCode");
// returnState.setBankRetCode(bankRetCode);// 银行返回状态
// returnState.setBankPostScript(tTrxResponse.getErrorMessage());
// // 转换错误码
// ChannelRtncode channelRtncode = null;
// channelRtncode = channelRtncodeDao.findById(new ChannelRtncodeId(channelId, bankRetCode));
// if (channelRtncode == null) {
// logMsg = logPrefix + "表  channel_rtncode 没有对应的" + channelId + "银行返回信息" + bankRetCode;
// Log4jUtil.info(logMsg);
// returnState.setReturnMsg(logMsg);
// returnState.setChannelCode(TransReturnCode.code_9900);
// } else {
// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
// returnState.setChannelCode(channelRtncode.getKftRtncode());
// }
// ObjectUtil.printPropertyString(logPrefix, returnState);
// return returnState;
// } else {
// logMsg = logPrefix + "向银行发起订单查询请求失败,SN：" + sn + " ReturnCode:" + tTrxResponse.getReturnCode()
// + " ErrorMessage:" + tTrxResponse.getErrorMessage();
// Log4jUtil.info(logMsg);
// // 5、交易查询请求提交失败，商户自定后续动作
// throw new BizException(logMsg);
// }
// }
