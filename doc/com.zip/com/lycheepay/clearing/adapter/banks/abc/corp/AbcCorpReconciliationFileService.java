/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.corp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.CorpAbcC503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C503;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.Erp2CTPublicService;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行银企对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_RECONCILIATION_FILE_SERVICE)
public class AbcCorpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ERP2_CT_PUBLIC_SERVICE)
	private Erp2CTPublicService erp2ctPublicService;

	@Autowired
	private ERP2CT_C503 eRP2CT_C503;

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC", "check");
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);
		String resultXml = "";
		// 从参数表取得平台的账号；省市代码；货币单位；最后交易的时间截
		final Map<String, String> channelParms = channelParamService.queryCodeParamsMapByChannelId(channelId);
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try{
			Log4jUtil.info("____________________________ C503 实时业务对账处理 start ____________________________________");
			ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
			final ERP2CT_C503Bean eRP2CT_C503Bean = new ERP2CT_C503Bean();

			// 生成农行银企流水
			final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
			// 商户自定义序列号
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("C503", abcReqSeqNo);

			// 组503报文数据
			final String KftProv = channelParms.get("100008");
			final String KftCur = channelParms.get("100009");
			String AccStartTime = channelParms.get("100037");
			AccStartTime = queryDate + "000000000000";// 对哪天的账，就传那天的时间
			Log4jUtil.info("取得的对账的时间戳是：" + AccStartTime);
			// 做实时业务对账处理时，快付通平台账户信息使用充值的业务类型(TransType.Recharge)来取账户信息
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId); // TODO
																													// 这里类型原来是Recharge，待修改

			eRP2CT_C503Bean.setDbAccNo(bankaccountBalance.getAccountNo());
			// eRP2CT_C503Bean.setDbAccNo("026900049999999");

			// 026900049999999
			eRP2CT_C503Bean.setDbProv(KftProv);
			eRP2CT_C503Bean.setDbCur(KftCur);
			eRP2CT_C503Bean.setStartTime(AccStartTime.trim());// 末笔时间戳，用于增量查询
			eRP2CT_C503Bean.setStartDate(queryDate);
			eRP2CT_C503Bean.setEndDate(queryDate);
			eRP2CT_C503Bean.setLastJrnNo("");

			// 组数据成功后，发送 C503 报文,同时取得返回的 C503 报文resultXml
			resultXml = eRP2CT_C503.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C503Bean);
			
			reconciliationFileDTOList = buildTransactionDataList(resultXml, channelId,
					channelParms);
			
		}catch(Exception e){
			Log4jUtil.error(e);
		}

		Log4jUtil.info(logPrefix + "生成统一格式对账文件");

		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				settleDate, reconciliationFileDTOList);
		return fileFullPath;

	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @author 李斌(13665100450)
	 * @param resultXml 银行返回xml回执
	 * @param channelId 渠道ID
	 * @param channelParms 渠道参数
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String resultXml, final String channelId,
			final Map<String, String> channelParms) throws ClearingAdapterBizCheckedException {
		final String ftpServer = channelParms.get("100029");
		final String ftpPassword = channelParms.get("100030");
		final String ftpUser = channelParms.get("100031");
		final String abcRecvFile = channelParms.get("100033");
		final String line = System.getProperty("line.separator");
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		// 解释C503报文，生成 accBeanList，再进行实时业务自动对账。
		// 单笔对账处理bean
		// private String checkDate; //帐务日期
		// private String bankSendSn; //渠道（银行）端的流水(订单号)
		// private String tranDate; //交易日期,长度为 8 位
		// private double tradeAmount; //交易金额
		// private String bankTradestate; //渠道（银行）交易状态 00-支付成功；01-支付失败；02-超时；和 Channel_CheckDetail
		// 表使用的状态代码一致

		final String RecvC503XmlInfo = resultXml;
		Document document = null;
		try {
			document = DocumentHelper.parseText(RecvC503XmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
		}
		final List<CorpAbcC503Bean> corpAbcC503BeanList = new ArrayList<CorpAbcC503Bean>();// C503实体为元素的arrayList

		String RespCode = ""; // 返回码 ： 0000交易成功
		String RecordNum = ""; // 记录数
		String TransCode = "";// 交易代码
		// String ReqSeqNo = "";// 请求方流水号
		String RespSource = "";// 返回来源
		String RespSeqNo = "";// 应答流水号
		String RespDate = "";// 返回日期
		String RespTime = "";// 返回时间
		String RespInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String FileFlag = "";// 数据文件标识
		String FieldNum = "";// 字段数
		String RespPrvData = "";// 私有数据区
		String BatchFileName = "";// 批量文件名

		// 获取应答报文公共字段
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/TransCode") != null) {
			TransCode = document.selectSingleNode("/ap/TransCode").getText();  // 交易代码
		}
		if (document.selectSingleNode("/ap/Cme/RecordNum") != null) {
			RecordNum = document.selectSingleNode("/ap/Cme/RecordNum").getText(); // 记录数
		}
		// 判断返回码和记录数，如果返回了交易明细数据 ，则做下面组装 noticeList 的操作
		if (RespCode.equals("0000") && Integer.parseInt(RecordNum) > 0) {
			if (document.selectSingleNode("/ap/ReqSeqNo") != null) {
				document.selectSingleNode("/ap/ReqSeqNo").getText();  	// 请求方流水号
			}
			if (document.selectSingleNode("/ap/RespSource") != null) {
				RespSource = document.selectSingleNode("/ap/RespSource").getText();// 返回来源
			}
			if (document.selectSingleNode("/ap/RespSeqNo") != null) {
				RespSeqNo = document.selectSingleNode("/ap/RespSeqNo").getText();  // 应答流水号
			}
			if (document.selectSingleNode("/ap/RespDate") != null) {
				RespDate = document.selectSingleNode("/ap/RespDate").getText();    // 返回日期
			}
			if (document.selectSingleNode("/ap/RespTime") != null) {
				RespTime = document.selectSingleNode("/ap/RespTime").getText();    // 返回时间
			}
			if (document.selectSingleNode("/ap/RxtInfo") != null) {
				RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText();      // 返回扩展信息
			}
			if (document.selectSingleNode("/ap/FileFlag") != null) {
				FileFlag = document.selectSingleNode("/ap/FileFlag").getText();    // 数据文件标识
			}

			if (document.selectSingleNode("/ap/Cme/FieldNum") != null) {
				FieldNum = document.selectSingleNode("/ap/Cme/FieldNum").getText();   // 字段数
			}
			if (document.selectSingleNode("/ap/Cmp/RespPrvData") != null) {
				RespPrvData = document.selectSingleNode("/ap/Cmp/RespPrvData").getText(); // 私有数据区
			}
			if (document.selectSingleNode("/ap/Cmp/BatchFileName") != null) {
				BatchFileName = document.selectSingleNode("/ap/Cmp/BatchFileName").getText();// 批量文件名
			}

			Log4jUtil.info("C503 RespPrvData:" + RespPrvData);
			Log4jUtil.info("C503 BatchFileName:" + BatchFileName);

			// C503报文明细要素共36项：
			String Prov = "";
			String AccNo = "";
			String Ccy = "";
			String TrDate = "";
			String TimeStab = " ";  // 交易时间戳，不可空字段，因此至少要保存一个空串
			String TrJrn = "";
			String Name = "";
			String TrType = "";
			String TrFrom = "";
			String TrBankNo = "";
			String AmtIndex = "";
			String OppProv = "";
			String OppAccNo = "";
			String OppCcy = "";
			String OppName = "";
			String OppBkName = "";
			String CshIndex = "";
			String ErrDate = "";
			String ErrVchNo = "";
			String Amt = "";
			String Bal = "";
			String PreAmt = "";
			String TotChg = "";
			String VoucherType = "";
			String VoucherProv = "";
			String VoucherBat = "";
			String VoucherNo = "";
			String CustRef = "";
			String TrCode = "";
			String Teller = "";
			String VchNo = "";
			String Abs = "";
			String Cmt = "";
			String SpFlag = "";
			String FmtCode = "";
			String SpecInfo = "";
			int intPos = 0;			// 字符串的位置
			String oneField = "";	// 取得单个字段的值

			// 处理对账的数据（分为：有文件 和 没有文件两种，如果没有文件，数据会保存在变量RespPrvData中）
			if (FileFlag.equals("1")) { // 以文件方式返回明细（即RespPrvData节点的内容放在文件中）,此时FileFlag=1
				// 1、下载CT服务器上的文件
				final FtpManager ftpManager = new FtpManager();
				ftpManager.setServer(ftpServer);
				ftpManager.setPassword(ftpPassword);
				ftpManager.setUser(ftpUser);
				ftpManager.setFilename(BatchFileName);
				ftpManager.setLocalPath(abcRecvFile); // 下载到本地的文件夹
				ftpManager.setPath(""); // 远程目录，就是FTP用户的默认目录
				ftpManager.getMyFile_actionPerformed();
				Log4jUtil.info("农行银企C503报文(对账报文):" + BatchFileName + "已下载到本地");

				// 2、把文件存内容入变量 RespPrvData 中
				RespPrvData = readFileByChars(abcRecvFile + File.separator + BatchFileName);
			}

			// 处理C503返回的报文，组调用‘对账’参数
			while (RespPrvData.length() > 100) {
				for (int j = 0; (j < 36); j++) {
					intPos = RespPrvData.indexOf("|");
					oneField = RespPrvData.substring(0, intPos);
					RespPrvData = RespPrvData.substring(intPos + 1);

					if (j == 0) {
						Prov = oneField;
					}// 省市代号
					else if (j == 1) {
						AccNo = oneField;
					}// 账号
					else if (j == 2) {
						Ccy = oneField;
					}// 货币码
					else if (j == 3) {
						TrDate = oneField;
					}// 交易日期
					else if (j == 4) {
						TimeStab = oneField;
					}// 交易时间戳
					else if (j == 5) {
						TrJrn = oneField;
					}// 日志号
					else if (j == 6) {
						Name = oneField;
					}// 户名
					else if (j == 7) {
						TrType = oneField;
					}// 交易类别
					else if (j == 8) {
						TrFrom = oneField;
					}// 交易来源
					else if (j == 9) {
						TrBankNo = oneField;
					}// 交易行行号
					else if (j == 10) {
						AmtIndex = oneField;
					}// 发生额标志
					else if (j == 11) {
						OppProv = oneField;
					}// 对方账号省市代码
					else if (j == 12) {
						OppAccNo = oneField;
					}// 对方账号
					else if (j == 13) {
						OppCcy = oneField;
					}// 对方账号货币码
					else if (j == 14) {
						OppName = oneField;
					}// 对方账号户名
					else if (j == 15) {
						OppBkName = oneField;
					}// 对方账号开户行名
					else if (j == 16) {
						CshIndex = oneField;
					}// 现转标志
					else if (j == 17) {
						ErrDate = oneField;
					}// 错账日期
					else if (j == 18) {
						ErrVchNo = oneField;
					}// 错账凭证号
					else if (j == 19) {
						Amt = oneField;
					}// 交易金额
					else if (j == 20) {
						Bal = oneField;
					}// 账户余额
					else if (j == 21) {
						PreAmt = oneField;
					}// 上笔余额
					else if (j == 22) {
						TotChg = oneField;
					}// 手续费总额
					else if (j == 23) {
						VoucherType = oneField;
					}// 凭证种类
					else if (j == 24) {
						VoucherProv = oneField;
					}// 凭证省市代码
					else if (j == 25) {
						VoucherBat = oneField;
					}// 凭证批次号
					else if (j == 26) {
						VoucherNo = oneField;
					}// 凭证号
					else if (j == 27) {
						CustRef = oneField;
					}// 户参考号 ============== 这个就是 billnoSn 的Ban_Send_SN 发往银行端的流水
					else if (j == 28) {
						TrCode = oneField;
					}// 交易码
					else if (j == 29) {
						Teller = oneField;
					}// 柜员号
					else if (j == 30) {
						VchNo = oneField;
					}// 传票号
					else if (j == 31) {
						Abs = oneField;
					}// 摘要
					else if (j == 32) {
						Cmt = oneField;
					}// 附言
					else if (j == 33) {
						SpFlag = oneField;
					}// 特殊信息标志
					else if (j == 34) {
						FmtCode = oneField;
					}// 格式码
					else if (j == 35) {
						SpecInfo = oneField;
					}// 特殊信息
					else {
					}
				}

				if (Amt.equals("Amt") == false) {
					if (OppAccNo.trim().length() > 0 && CustRef.trim().length() > 0 && OppName.trim().length() > 0
							&& TrBankNo.trim().length() > 0
					/* && (TrCode.trim().equals("25B6") || TrCode.trim().equals("7528")) */

					) {
						if (!"0".equals(CustRef)) {// 返回0时，可能是农行快捷系统内部调用农行银企充保证金,不需要关注
							final ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
							reconciliationFileDTO.setBankSendId(CustRef);// 银行流水号
							reconciliationFileDTO.setBankTransState("00");// 渠道（银行）交易状态
																			// 00-支付成功；01-支付失败；02-超时；和
							// Channel_CheckDetail 表使用的状态代码一致
							reconciliationFileDTO.setCheckDate(TrDate);// 也保存交易日期
							reconciliationFileDTO.setAmount(new BigDecimal(Amt));// 金额
							reconciliationFileDTO.setTransDate(TrDate);// 交易日期
							reconciliationFileDTO.setChannelId(channelId);
							// ========================= 对账标志处理 =========================
							if (reconciliationFileDTO.getAmount().compareTo(BigDecimal.ZERO) == -1) {
								reconciliationFileDTO.setPayGet(STR_PAY);
							} else if (reconciliationFileDTO.getAmount().compareTo(BigDecimal.ZERO) == 1) {
								reconciliationFileDTO.setPayGet(STR_GET);
							}
							reconciliationFileDTOList.add(reconciliationFileDTO);
						}
					}
					final CorpAbcC503Bean corpAbcC503Bean = new CorpAbcC503Bean();
					corpAbcC503Bean.setProv(Prov);// 省市代号
					corpAbcC503Bean.setAccNo(AccNo);// 账号
					corpAbcC503Bean.setCcy(Ccy);// 货币码
					corpAbcC503Bean.setTrDate(TrDate);// 交易日期
					corpAbcC503Bean.setTimeStab(TimeStab);// 交易时间戳
					corpAbcC503Bean.setTrJrn(TrJrn);// 日志号
					corpAbcC503Bean.setName(Name);// 户名
					corpAbcC503Bean.setTrType(TrType);// 交易类别
					corpAbcC503Bean.setTrFrom(TrFrom);// 交易来源
					corpAbcC503Bean.setTrBankNo(TrBankNo);// 交易行行号
					corpAbcC503Bean.setAmtIndex(AmtIndex);// 发生额标志
					corpAbcC503Bean.setOppProv(OppProv);// 对方账号省市代码
					corpAbcC503Bean.setOppAccNo(OppAccNo);// 对方账号
					corpAbcC503Bean.setOppCcy(OppCcy);// 对方账号货币码
					corpAbcC503Bean.setOppName(OppName);// 对方账号户名
					corpAbcC503Bean.setOppBkName(OppBkName);// 对方账号开户行名
					corpAbcC503Bean.setCshIndex(CshIndex);// 现转标志
					corpAbcC503Bean.setErrDate(ErrDate);// 错账日期
					corpAbcC503Bean.setErrVchNo(ErrVchNo);// 错账凭证号
					corpAbcC503Bean.setAmt(Amt);// 交易金额
					corpAbcC503Bean.setBal(Bal);// 账户余额
					corpAbcC503Bean.setPreAmt(PreAmt);// 上笔余额
					corpAbcC503Bean.setTotChg(TotChg);// 手续费总额
					corpAbcC503Bean.setVoucherType(VoucherType);// 凭证种类
					corpAbcC503Bean.setVoucherProv(VoucherProv);// 凭证省市代码
					corpAbcC503Bean.setVoucherBat(VoucherBat);// 凭证批次号
					corpAbcC503Bean.setVoucherNo(VoucherNo);// 凭证号
					corpAbcC503Bean.setCustRef(CustRef);// 户参考号 ============== 这个就是 billnoSn
														// 的Ban_Send_SN 发往银行端的流水
					corpAbcC503Bean.setTrCode(TrCode);// 交易码
					corpAbcC503Bean.setTeller(Teller);// 柜员号
					corpAbcC503Bean.setVchNo(VchNo);// 传票号
					corpAbcC503Bean.setAbs(Abs);// 摘要
					corpAbcC503Bean.setCmt(Cmt);// 附言
					corpAbcC503Bean.setSpFlag(SpFlag);// 特殊信息标志
					corpAbcC503Bean.setFmtCode(FmtCode);// 格式码
					corpAbcC503Bean.setSpecInfo(SpecInfo);// 特殊信息
					corpAbcC503BeanList.add(corpAbcC503Bean);
				}
			} // 结束循环，把 TimeStab 交易时间戳 写到数据库中
			final ChannelParm channelParm = channelParamService
					.queryByPrimaryKey(new ChannelParmId(channelId, "100037"));
			String startTime = DateUtil.getDate(DateUtil.addDays(new Date(), -1));
			startTime = startTime + "000000000000";
			if (TimeStab.compareTo(startTime) < 0) { // 把两者中，值小的存放到 时间戳 字段中
				startTime = TimeStab;
			}
			channelParm.setParvalue(startTime);
			channelParamService.update(channelParm);
		} else if (RespCode.equals("2002")) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.TRANSACTION_QUERY_FAILED, "农行银企对账查询出错，交易返回错误信息: "
					+ RespInfo + "操作员未签到，请做签到操作后再做其他交易");
		} else if (!(RespCode.equals("0000"))) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.TRANSACTION_QUERY_FAILED, "农行银企对账查询出错，农行业务交易代码: "
					+ TransCode + ";交易返回码： " + RespCode + "；交易返回错误信息: " + RespInfo);
		}

		Log4jUtil.info(line + "_______________________________对账返回数据_________________________________");
		for (int i = 0; i < reconciliationFileDTOList.size(); i++) {
			Log4jUtil.info(line + (i + 1) + " 银行流水号: " + reconciliationFileDTOList.get(i).getBankSendId());
			Log4jUtil.info(line + (i + 1) + " 渠道（银行）交易状态: " + reconciliationFileDTOList.get(i).getBankTransState());
			Log4jUtil.info(line + (i + 1) + " 帐务日期: " + reconciliationFileDTOList.get(i).getCheckDate());
			Log4jUtil.info(line + (i + 1) + " 金额: " + reconciliationFileDTOList.get(i).getAmount());
			Log4jUtil.info(line + (i + 1) + " 交易日期: " + reconciliationFileDTOList.get(i).getTransDate());
			Log4jUtil.info(line + "________________________________________________________________");
		}
		Log4jUtil.info("________________________________C503所有记录（含收、付款记录）________________________________");
		for (int i = 0; i < corpAbcC503BeanList.size(); i++) {
			Log4jUtil.info("________________________________________________________________");
			Log4jUtil.info((i + 1) + ":省市代号        :" + corpAbcC503BeanList.get(i).getProv());// 省市代号
			Log4jUtil.info((i + 1) + ":账号            :" + corpAbcC503BeanList.get(i).getAccNo());// 账号
			Log4jUtil.info((i + 1) + ":货币码          :" + corpAbcC503BeanList.get(i).getCcy());// 货币码
			Log4jUtil.info((i + 1) + ":交易日期        :" + corpAbcC503BeanList.get(i).getTrDate());// 交易日期
			Log4jUtil.info((i + 1) + ":交易时间戳      :" + corpAbcC503BeanList.get(i).getTimeStab());// 交易时间戳
			Log4jUtil.info((i + 1) + ":日志号          :" + corpAbcC503BeanList.get(i).getTrJrn());// 日志号
			Log4jUtil.info((i + 1) + ":户名            :" + corpAbcC503BeanList.get(i).getName());// 户名
			Log4jUtil.info((i + 1) + ":交易类别        :" + corpAbcC503BeanList.get(i).getTrType());// 交易类别
			Log4jUtil.info((i + 1) + ":交易来源        :" + corpAbcC503BeanList.get(i).getTrFrom());// 交易来源
			Log4jUtil.info((i + 1) + ":交易行行号      :" + corpAbcC503BeanList.get(i).getTrBankNo());// 交易行行号
			Log4jUtil.info((i + 1) + ":发生额标志      :" + corpAbcC503BeanList.get(i).getAmtIndex());// 发生额标志
			Log4jUtil.info((i + 1) + ":对方账号省市代码:" + corpAbcC503BeanList.get(i).getOppProv());// 对方账号省市代码
			Log4jUtil.info((i + 1) + ":对方账号        :" + corpAbcC503BeanList.get(i).getOppAccNo());// 对方账号
			Log4jUtil.info((i + 1) + ":对方账号货币码  :" + corpAbcC503BeanList.get(i).getOppCcy());// 对方账号货币码
			Log4jUtil.info((i + 1) + ":对方账号户名    :" + corpAbcC503BeanList.get(i).getOppName());// 对方账号户名
			Log4jUtil.info((i + 1) + ":对方账号开户行名:" + corpAbcC503BeanList.get(i).getOppBkName());// 对方账号开户行名
			Log4jUtil.info((i + 1) + ":现转标志        :" + corpAbcC503BeanList.get(i).getCshIndex());// 现转标志
			Log4jUtil.info((i + 1) + ":错账日期        :" + corpAbcC503BeanList.get(i).getErrDate());// 错账日期
			Log4jUtil.info((i + 1) + ":错账凭证号      :" + corpAbcC503BeanList.get(i).getErrVchNo());// 错账凭证号
			Log4jUtil.info((i + 1) + ":交易金额        :" + corpAbcC503BeanList.get(i).getAmt());// 交易金额
			Log4jUtil.info((i + 1) + ":账户余额        :" + corpAbcC503BeanList.get(i).getBal());// 账户余额
			Log4jUtil.info((i + 1) + ":上笔余额        :" + corpAbcC503BeanList.get(i).getPreAmt());// 上笔余额
			Log4jUtil.info((i + 1) + ":手续费总额      :" + corpAbcC503BeanList.get(i).getTotChg());// 手续费总额
			Log4jUtil.info((i + 1) + ":凭证种类        :" + corpAbcC503BeanList.get(i).getVoucherType());// 凭证种类
			Log4jUtil.info((i + 1) + ":凭证省市代码    :" + corpAbcC503BeanList.get(i).getVoucherProv());// 凭证省市代码
			Log4jUtil.info((i + 1) + ":凭证批次号      :" + corpAbcC503BeanList.get(i).getVoucherBat());// 凭证批次号
			Log4jUtil.info((i + 1) + ":凭证号          :" + corpAbcC503BeanList.get(i).getVoucherNo());// 凭证号
			Log4jUtil.info((i + 1) + ":户参考号 	:" + corpAbcC503BeanList.get(i).getCustRef());// 户参考号
																							// ==============
																							// 这个就是
																							// billnoSn
																							// 的Ban_Send_SN
																							// 发往银行端的流水
			Log4jUtil.info((i + 1) + ":交易码          :" + corpAbcC503BeanList.get(i).getTrCode());// 交易码
			Log4jUtil.info((i + 1) + ":柜员号          :" + corpAbcC503BeanList.get(i).getTeller());// 柜员号
			Log4jUtil.info((i + 1) + ":传票号          :" + corpAbcC503BeanList.get(i).getVchNo());// 传票号
			Log4jUtil.info((i + 1) + ":摘要            :" + corpAbcC503BeanList.get(i).getAbs());// 摘要
			Log4jUtil.info((i + 1) + ":附言            :" + corpAbcC503BeanList.get(i).getCmt());// 附言
			Log4jUtil.info((i + 1) + ":特殊信息标志    :" + corpAbcC503BeanList.get(i).getSpFlag());// 特殊信息标志
			Log4jUtil.info((i + 1) + ":格式码          :" + corpAbcC503BeanList.get(i).getFmtCode());// 格式码
			Log4jUtil.info((i + 1) + ":特殊信息        :" + corpAbcC503BeanList.get(i).getSpecInfo());// 特殊信息
		}
		Log4jUtil.info("_______________________________ END _________________________________");
		return reconciliationFileDTOList;
	}

	/**
	 * 以字符为单位读取文件，常用于读文本，数字等类型的文件
	 * 
	 * @param 文件名
	 * @return 文件内容
	 */
	private static String readFileByChars(final String fileName) {
		final File file = new File(fileName);
		String RetFileContent = ""; // 返回值，保存文件中数据
		Reader reader = null;
		try {
			Log4jUtil.info("以字符为单位读取农行银企对账文件，一次读一个字节：");
			reader = new InputStreamReader(new FileInputStream(file));
			int tempchar;
			final StringBuffer sb = new StringBuffer();
			while ((tempchar = reader.read()) != -1) {
				sb.append((char) tempchar);
			}

			RetFileContent = sb.toString();
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, e.getMessage());
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (final IOException e) {
					Log4jUtil.error(e);
					throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, e.getMessage());
				}
			}
		}
		return RetFileContent;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

}
