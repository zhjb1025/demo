/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.credit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.abc.credit.kft.processor.AbcCreditCorpParam;
import com.lycheepay.clearing.adapter.banks.abc.credit.kft.util.AbcCreditKFTUtil;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.constant.biz.SysparmConst;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ClearParamsService;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行信用卡对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.ABC_CREDIT_RECONCILIATION_FILE_SERVICE)
public class AbcCreditReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CLEAR_PARAMS_SERVICE)
	private ClearParamsService sysParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);
		final String fileName = "KFT_" + queryDate + "_CSD.txt";
		final String fileFullPathName = downloadFile(logPrefix, channelId, fileName);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix, channelId,
				queryDate, fileFullPathName);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * <p>下载对账文件</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param channelId 渠道ID
	 * @param fileName 文件名
	 * @return 对账文件路径
	 * @throws ClearingAdapterBizCheckedException
	 * @author 李斌(13665100450)
	 */
	private String downloadFile(final String logPrefix, final String channelId, final String fileName)
			throws ClearingAdapterBizCheckedException {
		final Map<String, String> channelParam = channelParamService.queryCodeParamsMapByChannelId(channelId);
		final AbcCreditKFTUtil abcCreditKFTUtil = new AbcCreditKFTUtil();
		final AbcCreditCorpParam abcCreditCorpParam = new AbcCreditCorpParam();
		abcCreditKFTUtil.checkChannelParam(logPrefix, "settle", channelParam, abcCreditCorpParam);

		final String accPath = sysParmService.getParmValue(SysparmConst.CHANNEL_RECON_FILE_DIR) + "accPath" + channelId + File.separator;
		final FtpManager fm = new FtpManager();
		fm.setServer(abcCreditCorpParam.getFtpServer());
		fm.setPassword(abcCreditCorpParam.getFtpPassword());
		fm.setUser(abcCreditCorpParam.getFtpUser());
		fm.setFilename(fileName);
		fm.setLocalPath(accPath); // 下载到本地的文件夹
		fm.setPath(abcCreditCorpParam.getFtpPath().trim()); // 远程目录，就是FTP用户的默认目录
		fm.getMyFile_actionPerformed("bin");
		return accPath + fileName;
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @author 李斌(13665100450)
	 * @param logPrefix 日志前缀
	 * @param channelId 渠道ID
	 * @param fileName 对账文件名
	 * @param reconciliationDate 清算日期
	 * @param fileFullPathName 对账文件全路径
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String channelId,
			final String reconciliationDate, final String fileFullPathName) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		Log4jUtil.info(logPrefix + "准备生成对账对象。");
		String fileName;
		if (fileFullPathName.lastIndexOf("/") == -1) {
			fileName = fileFullPathName.substring(fileFullPathName.lastIndexOf("\\") + 1);
		} else {
			fileName = fileFullPathName.substring(fileFullPathName.lastIndexOf("/") + 1);
		}
		checkFileName(logPrefix, fileName, reconciliationDate);
		BufferedReader bufferedReader = null;
		try {
			// 循环对文本逐行处理
			// CountBean countBean = new CountBean();
			int currLine = 0;
			String data = null;

			final InputStreamReader reader = new InputStreamReader(new FileInputStream(fileFullPathName), "utf-8");
			bufferedReader = new BufferedReader(reader);
			int i = 0; // ArrayList 记录数
			BigDecimal amount = BigDecimal.ZERO;
			while ((data = bufferedReader.readLine()) != null) {
				final ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
				currLine++; // 对账文件 行循环
				Log4jUtil.info(logPrefix + "对账文件第 " + currLine + " 行文件内容为：" + data);
				if (0 < data.trim().length()) {
					final String[] currentLineData = data.split("\\|!", -1);
					// 文件头放在文件的第一行；格式为：
					// 转帐（代扣）合计笔数|转帐（代扣）合计金额|转帐（代付）合计笔数|转帐（代付）合计金额|
					// 文件体从文件的第二行开始， 一条明细记录为一行；格式为：
					// 交易时间|金额|单位编号|协议编号|工行帐号|户名|交易流水号|第三方流水号|
					// 文件结束标志放在文件的最后一行；固定值为9个A：
					// AAAAAAAAA
					if (currLine == 1) {
						if (currentLineData.length < 22) {// 22
							continue;
						}
					}
					if (currentLineData[0].equals("AAAAAAAAA")) {
						Log4jUtil.info(logPrefix + "遇到文件结束符，退出循环。继续提交处理");
						break;
					}
					if (1 < currentLineData.length) {
						// 交易时间|金额|单位编号|协议编号|工行帐号|户名|交易流水号|第三方流水号|
						// String tradeTime = currentLineData[0].trim();// 交易时间
						final String tradeDate = currentLineData[4].trim();// 交易时间
						if (!DateUtil.isValidDate(tradeDate, "yyyymmdd")) {
							// 若不是合法交易时间，则直接跳过该行
							Log4jUtil.info(logPrefix + "该行不是合法的交易数据,日期格式不对。");
							continue;
						}
						if (currentLineData.length < 22) {
							// 元素不完整
							Log4jUtil.info(logPrefix + "该行元素不完整，不是合法的交易数据。");
							continue;
						}
						final String reflectedNo = currentLineData[17].trim();// 订单号
						final String amtTrade = currentLineData[8].trim();// 交易金额
						// 单位为元
						amount = amount.add(new BigDecimal(amtTrade));
						reconciliationFileDTO.setBankTransState("00");
						reconciliationFileDTO.setCheckDate(reconciliationDate);
						String orderNo = billnoSnService.findBankSendSnByBankRecvSn(channelId, reflectedNo);
						if (StringUtils.isBlank(orderNo)) {
							orderNo = reflectedNo;
						}
						Log4jUtil.info("根据系统参考号和渠道ID查询订单号，订单号为：" + orderNo);
						reconciliationFileDTO.setChannelId(channelId);
						reconciliationFileDTO.setBankSendId(orderNo); // 订单号
						reconciliationFileDTO.setTransDate(reconciliationDate); // 交易日期
						reconciliationFileDTO.setAmount(new BigDecimal(amtTrade));// 交易金额
						reconciliationFileDTO.setPayGet(STR_PAY);// 全部记为代付，只在银行有，我们无时改标志才有效，记录在代付上去（此处因为工行给的对账明细里没告知该笔业务到底是代收还是代付）
						i++;
						String logMsg = logPrefix + "将对账文件中第" + currLine + "行数据构造accBean，添加到accBeanList的第" + i + "条记录:";
						logMsg = logMsg + " checkDate:" + reconciliationFileDTO.getCheckDate() + " BankSendSn:"
								+ reconciliationFileDTO.getBankSendId();
						logMsg = logMsg + " TranDate:" + reconciliationFileDTO.getTransDate() + " TradeAmount:"
								+ reconciliationFileDTO.getAmount();
						Log4jUtil.info(logMsg);
						reconciliationFileDTOList.add(reconciliationFileDTO);
					}
				}
			}// while
			Log4jUtil.info(logPrefix + "本次共成功生成 " + i + "行对账明细。总金额为：" + String.format("%1$.2f", amount));
		} catch (final IOException e) {
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix + "对账失败,文件:["
					+ fileFullPathName + "]" + e, e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();
				}// 关闭文件
			} catch (final IOException e) {
				throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix
						+ "对账失败,关闭文件流出错文件:[" + fileFullPathName + "]" + e, e);
			}
		}
		return reconciliationFileDTOList;
	}

	/**
	 * <p>检查对账文件名</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param fileName 文件名
	 * @param reconciliationDate 清算日期
	 * @throws ClearingAdapterBizCheckedException
	 * @author 李斌(13665100450)
	 */
	private void checkFileName(final String logPrefix, final String fileName, final String reconciliationDate)
			throws ClearingAdapterBizCheckedException {
		final String[] filenamedata = fileName.split("\\_");
		if (filenamedata.length < 3) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, logPrefix
					+ "对账失败,文件:[" + fileName + "]文件名格式有误。");
		}
		// 中间是对账日期
		final String transDate = filenamedata[1];
		Log4jUtil.info("transDate:" + transDate);
		Log4jUtil.info("transDate:" + transDate);
		if (!DateUtil.isValidDate(transDate, "yyyyMMdd")) {
			final String logMsg = logPrefix + "文件名中不包括合法的日期。";
			Log4jUtil.info(logMsg);
			throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, logMsg);
		}
		if (!transDate.equals(reconciliationDate)) {
			final String logMsg = logPrefix + "文件名中的日期" + transDate + "和选择的对账日期" + reconciliationDate + "不对应。";
			Log4jUtil.info(logMsg);
			throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, logMsg);
		}
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix, channelId,
				queryDate, targetFilePath);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

}
