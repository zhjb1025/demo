package com.lycheepay.clearing.adapter.banks.abc.cross.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class AbcCrossThreadPool {
	
	private static ExecutorService pool = Executors.newCachedThreadPool();
	
	public static void launch(Runnable worker){
		pool.execute(worker);
	}
	
	public static void shutdown(){
		pool.shutdown();
	}

}
