package com.lycheepay.clearing.adapter.banks.abc.http.b2c;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;


/**
 * <P>农业银行B2C 部分服务类(PS.目前用于批量处理)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 下午4:01:23
 */
@Service(ClearingAdapterAnnotationName.ABC_B2C_SERVICE)
public class AbcB2CService extends BaseWithoutAuditLogService {
	// XXX Batch By:Leon.Qiu[2012-6-18 下午4:04:20] 目前用于批量 待凯锋修改
	// private static String logMsg = "";
	// private static ChannelRefundDao channelRefundDao = (ChannelRefundDao)
	// SpringContext.getService("channelRefundDao");
	// private static ChannelBatchRefundDao channelBatchRefundDao = (ChannelBatchRefundDao)
	// SpringContext
	// .getService("channelBatchRefundDao");
	//
	// @Autowired
	// @Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	// private ChannelRtncodeService channelRtncodeService;
	//
	// @Autowired
	// @Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	// private BillnoSnService billnoSnService;
	//
	// /**
	// * 发送银行失败时，把状态更改为09.描述为银行返回前250位
	// *
	// * @param channelBatchId
	// * @param returnState
	// * @throws BizException
	// */
	// public void updateChannelBatchRefundToFail(final String logPrefix, final String
	// channelBatchId,
	// final ReturnState returnState) throws BizException {
	// try {
	// final ChannelBatchRefund cbr = channelBatchRefundDao.findByIdWithLock(channelBatchId);
	// if (cbr == null) {
	// throw new BizException(logPrefix + "获取到的渠道批量退款表对象为NULL。channelBatchId为：" + channelBatchId);
	// }
	// if (cbr.getState().equals("00") && !returnState.getChannelCode().equals("0000")) {
	// cbr.setState("09");
	// if (returnState.getBankPostScript().length() < 255) {
	// cbr.setRemark(returnState.getBankPostScript().substring(0,
	// returnState.getBankPostScript().length() - 1));
	// } else {
	// cbr.setRemark(returnState.getBankPostScript().substring(0, 254));
	// }
	// channelBatchRefundDao.update(cbr);
	// }
	// } catch (final Exception e) {
	// Log4jUtil.error(logPrefix + "更新ChannelBatchRefund表出错。", e);
	// }
	// }
	//
	// /**
	// * 根据channelBatchid由表ChannelBatchRefund获取到相关记录，用Refund_net_no、Refund_type、
	// * Channel_Id结合表channel_Refund获取到相关明细，组向银行发送的批量退款
	// *
	// * @param channelBatchid
	// * @return
	// * @throws BizException
	// */
	// public ReturnState senDBatchRefund(final String logPrefix, final String channelId, final
	// String channelBatchid)
	// throws BizException {
	// logMsg = logPrefix + "开始发送Channel_BatchId为：" + channelBatchid + "的批量退款批次。";
	// Log4jUtil.info(logMsg);
	// final ChannelBatchRefund channelBatchRefund = channelBatchRefundDao.findById(channelBatchid);
	// if (channelBatchRefund == null) {
	// throw new BizException(logPrefix + "从channel_Batch_Refund表中无法获取Channel_BatchId为：" +
	// channelBatchid + "的记录。");
	// }
	// if (!channelBatchRefund.getState().equals("00") &&
	// !channelBatchRefund.getState().equals("09")) {
	// throw new BizException(logPrefix + "根据参数channelBatchid" + channelBatchid +
	// "在表channel_Batch_Refund中得到的状态为："
	// + channelBatchRefund.getState() + ",非00：已发送和09: 交易失败。不能再次触发，处理中止。");
	// }
	// final List<ChannelRefund> channelRefundList =
	// channelRefundDao.getListByChannelBatchId(channelBatchid);
	// logMsg = logPrefix + "开始生成批量退款对象。";
	// Log4jUtil.info(logMsg);
	// Double iTotalAmount = 0.00;
	// int iTotalCount = 0;
	// final ArrayList tOrderList = new ArrayList();
	// for (int j = 0; j < channelRefundList.size(); j++) {
	// String banSendSN;// 原业务发往银行的记录
	// final String bILLNoSeq = channelRefundList.get(j).getBillnoSeq();
	// final BillnoSn billnoSn = billnoSnService.findById(bILLNoSeq);
	// if (billnoSn == null) {
	// logMsg = logPrefix + "在渠道流水对照表中没有记录bILLNoSeq:" + bILLNoSeq;
	// Log4jUtil.info(logMsg);
	// continue;
	// }
	// banSendSN = billnoSn.getBankSendSn();
	// final String[] torder = new String[2];
	// torder[0] = banSendSN;
	// torder[1] = String.format("%1$.2f", channelRefundList.get(j).getRefundAmount());
	// tOrderList.add(torder);
	// logMsg = logPrefix + "添加退款明细：BankSendSn:" + torder[0];
	// logMsg = logMsg + " Amount:" + torder[1];
	// Log4jUtil.info(logMsg);
	// iTotalAmount = AmountUtils.add(iTotalAmount, channelRefundList.get(j).getRefundAmount());
	// }
	// iTotalCount = tOrderList.size();
	// // 2、生成超期退款请求对象
	// logMsg = logPrefix + "生成批量退款请求对象OverdueRefundRequest。";
	// Log4jUtil.info(logMsg);
	// final String tRemark = "批量退款"; // 备注
	// final OverdueRefundRequest tOverdueRequest = new OverdueRefundRequest();
	// tOverdueRequest.setTotalCount(iTotalCount); // 总笔数 （必要信息）
	// tOverdueRequest.setTotalAmount(iTotalAmount); // 总金额 （必要信息）
	// tOverdueRequest.setRemark(tRemark);// 备注
	// tOverdueRequest.setOrderDital(tOrderList);
	//
	// final ReturnState returnState = new ReturnState();
	// // 3、传送超期退款请求并取得结果
	// // logMsg =
	// //
	// logPrefix+"向银行发起批量退款请求。总笔数为："+tOverdueRequest.getTotalCount()+" 总金额："+String.format("%1$.2f",tOverdueRequest.getTotalAmount());
	// Log4jUtil.info(logMsg);
	// ObjectUtil.printPropertyString(logPrefix, tOverdueRequest);
	// final TrxResponse tResponse = tOverdueRequest.postRequest();
	// ObjectUtil.printPropertyString(logPrefix, tResponse);
	// // 4、判断超期退款结果状态，进行后续操作
	// if (tResponse.isSuccess()) {
	// final String bankBatchId = tResponse.getValue("SerialNumber");
	// // 5、超期退款成功
	// logMsg = logPrefix + "向银行发起批量退款请求成功。收到回执：";
	// logMsg = " TrxType:" + tResponse.getValue("TrxType");
	// logMsg = logMsg + " TotalCount:" + tResponse.getValue("TotalCount");
	// logMsg = logMsg + " TotalAmount:" + tResponse.getValue("TotalAmount");
	// logMsg = logMsg + " SerialNumber:" + bankBatchId;
	// logMsg = logMsg + " HostDate:" + tResponse.getValue("HostDate");
	// logMsg = logMsg + " HostTime:" + tResponse.getValue("HostTime");
	// logMsg = logMsg + " ReturnCode:" + tResponse.getReturnCode();
	// logMsg = logMsg + " ResultMessage:" + tResponse.getErrorMessage();
	// Log4jUtil.info(logMsg);
	// // 需要更改channel_Batch_Refund里的状态为01：银行已收妥，Bank_BatchId为tResponse.getValue("SerialNumber")
	// logMsg = logPrefix + "更改表channel_Batch_Refund的state为：01 。Bank_BatchId为：" + bankBatchId;
	// Log4jUtil.info(logMsg);
	// channelBatchRefund.setState("01");
	// channelBatchRefund.setBankBatchid(bankBatchId);
	// channelBatchRefundDao.update(channelBatchRefund);
	//
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// returnState.setSn(channelBatchid);
	// final String bankRetCode = "0000";
	// returnState.setBankRetCode(bankRetCode);// 银行返回状态
	// returnState.setBankPostScript(tResponse.getErrorMessage());// 银行返回状态
	//
	// ChannelRtncode channelRtncode = null;
	// channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
	// bankRetCode));
	// if (channelRtncode == null) {
	// logMsg = logPrefix + "表  channel_rtncode 没有对应的" + channelId + "银行返回信息" + bankRetCode;
	// Log4jUtil.info(logMsg);
	// returnState.setReturnMsg(logMsg);
	// returnState.setChannelCode(TransReturnCode.code_9900);
	// } else {
	// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
	// returnState.setChannelCode(channelRtncode.getKftRtncode());
	// }
	// } else {
	// logMsg = logPrefix + "向银行发起批量退款失败。ReturnCode:" + tResponse.getReturnCode() + " ErrorMessage:"
	// + tResponse.getErrorMessage();
	// Log4jUtil.info(logMsg);
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// returnState.setSn(channelBatchid);
	// final String bankRetCode = tResponse.getReturnCode();
	// returnState.setBankRetCode(bankRetCode);// 银行返回状态
	// returnState.setBankPostScript(tResponse.getErrorMessage());// 银行返回状态
	//
	// ChannelRtncode channelRtncode = null;
	// channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
	// bankRetCode));
	// if (channelRtncode == null) {
	// logMsg = logPrefix + "表  channel_rtncode 没有对应的" + channelId + "银行返回信息" + bankRetCode;
	// Log4jUtil.info(logMsg);
	// returnState.setReturnMsg(logMsg);
	// returnState.setChannelCode(TransReturnCode.code_9900);
	// } else {
	// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
	// returnState.setChannelCode(channelRtncode.getKftRtncode());
	// }
	// }
	// ObjectUtil.printPropertyString(logPrefix, returnState);
	// // 获取发往银行的数据包
	// return returnState;
	// }
	//
	// public List<ReturnState> senDBatchRefundQuery(final String logPrefix, final String channelId,
	// final ChannelBatchRefund channelBatchRefund) throws BizException {
	// logMsg = logPrefix + "向银行发起批量退款查询。";
	// Log4jUtil.info(logMsg);
	// ChannelBatchRefund cbr = new ChannelBatchRefund();
	// cbr = channelBatchRefundDao.findByIdWithLock(channelBatchRefund.getChannelBatchid());
	// if (cbr == null) {
	// throw new BizException("根据ChannelBatchid:" + channelBatchRefund.getChannelBatchid()
	// + " 锁表ChannelBatchRefund失败。");
	// }
	// ObjectUtil.printPropertyString(logPrefix, cbr);
	// final List<ReturnState> returnStateList = new ArrayList<ReturnState>();
	// final String tSerialNumber = cbr.getBankBatchid();
	// if (tSerialNumber == null || tSerialNumber.length() < 1) {
	// throw new BizException(logPrefix + "获取到的银行批次号为NULL.");
	// }
	// final String refundNetNo = cbr.getRefundNetNo();
	// final String refundType = cbr.getRefundType();
	// // 2、生成超期退款结果查询请求对象
	// final QueryOverdueRefundRequest tQueryBatchRequest = new QueryOverdueRefundRequest();
	// tQueryBatchRequest.setSerialNumber(tSerialNumber); // 设定超期退款结果查询请求的流水号（必要信息）
	//
	// // 3、传送超期退款结果查询请求并取得结果
	// logMsg = logPrefix + "向银行发起流水号为：" + tSerialNumber + " 的查询批量退款请求。";
	// Log4jUtil.info(logMsg);
	// ObjectUtil.printPropertyString(logPrefix, tQueryBatchRequest);
	// final TrxResponse tResponse = tQueryBatchRequest.postRequest();
	// ObjectUtil.printPropertyString(logPrefix, tResponse);
	// // 4、判断超期退款结果查询状态，进行后续操作
	// if (tResponse.isSuccess()) {
	// logMsg = logPrefix + "查询批量退款请求成功。开始生成批量对象OverdueBatch";
	// Log4jUtil.info(logMsg);
	// // //5、生成批量对象
	// final OverdueBatch tBatch = new OverdueBatch(new
	// XMLDocument(tResponse.getValue("QueryOverdueRefund")));
	// logMsg = logPrefix + "生成批量对象OverdueBatch成功。";
	// logMsg = logMsg + "批量退款流水号:" + tBatch.getSerialNumber();
	// logMsg = logMsg + "批量退款总金额:" + tBatch.getRefundAmount();
	// logMsg = logMsg + "批量退款总笔数:" + tBatch.getRefundCount();
	// logMsg = logMsg + "批量退款状态:" + tBatch.getStatus();
	// logMsg = logMsg + "\n开始获取订单明细。";
	// Log4jUtil.info(logMsg);
	// // 6、取得订单明细
	// final ArrayList tOrders = tBatch.getOrder();
	// for (int i = 0; i < tOrders.size(); i++) {
	// // 需要更新channel_Refund表里的状态。以及组业务需要的ReturnStateList
	// final ReturnState returnState = new ReturnState();
	// final Order tOrder = (Order) tOrders.get(i);
	// logMsg = logPrefix + "退款明细 " + (i + 1) + " 订单号：" + tOrder.getOrderNo();
	// logMsg = logMsg + " 订单金额:" + tOrder.getOrderAmount();
	// logMsg = logMsg + " 退款金额:" + tOrder.getRefundAmount();
	// logMsg = logMsg + " 订单状态:" + tOrder.getOrderStatus();
	// logMsg = logMsg + " 订单退款失败原因:" + tOrder.getOrderDesc();
	// Log4jUtil.info(logMsg);
	// final BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, tOrder.getOrderNo());
	// if (billnoSn == null) {
	// logMsg = logPrefix + "渠道ID【" + channelId + "】中的订单号【" + tOrder.getOrderNo() +
	// "】在渠道流水对照表中没有记录.";
	// Log4jUtil.info(logMsg);
	// continue;
	// }
	// final String billnosnSeq = billnoSn.getBillnosnSeq();
	// // 查找channel_Refund表记录
	// final ChannelRefund channelRefund = channelRefundDao.getByBillnoSeqForLock(refundNetNo,
	// refundType,
	// channelId, billnosnSeq);
	// if (channelRefund == null) {
	// logMsg = logPrefix + "在表ChannelRefund表中找不到，场次为：" + refundNetNo + " 退款类型为：" + refundType +
	// " 渠道ID为:"
	// + channelId + " 渠道流水为：" + billnosnSeq + " 的相关记录。";
	// Log4jUtil.info(logMsg);
	// continue;
	// }
	// if (tOrder.getRefundAmount() != channelRefund.getRefundAmount()) {
	// logMsg = logPrefix + "银行返回的退款金额 " + tOrder.getRefundAmount() + " 与原记录金额 "
	// + channelRefund.getRefundAmount() + " 不相符。渠道流水为：" + billnosnSeq;
	// Log4jUtil.info(logMsg);
	// continue;
	// }
	// if (channelRefund.getState().equals("4") || channelRefund.getState().equals("5")) {
	// logMsg = logPrefix + "场次为：" + refundNetNo + " 退款类型为：" + refundType + " 渠道ID为:" + channelId
	// + " 渠道流水为：" + billnosnSeq + " 的相关记录状态为：" + channelRefund.getState() + "，此笔不再处理。";
	// Log4jUtil.info(logMsg);
	// continue;
	// }
	// if (cbr.getRefundType().equals("01")) {
	// returnState.setSn(channelRefund.getId().getRefundSn());
	// } else if (cbr.getRefundType().equals("02")) {
	// returnState.setSn(channelRefund.getBillnoSeq());
	// }
	// returnState.setRelTranAmount(tOrder.getRefundAmount());
	// returnState.setBankPostScript(tOrder.getOrderDesc());
	// returnState.setBankRetCode(tOrder.getOrderStatus());
	// if (tOrder.getOrderStatus().equals("1")) {
	// // 处理成功
	// channelRefund.setState("04");
	// returnState.setChannelCode("0000");
	// } else if (tOrder.getOrderStatus().equals("2")) {
	// // 处理失败
	// channelRefund.setState("05");
	// returnState.setChannelCode("9999");
	// } else {
	// // 未处理
	// continue;
	// }
	// channelRefundDao.update(channelRefund);
	// logMsg = logPrefix + "向returnStateList添加第" + (i + 1) + "条记录ReturnState，其中SN:" +
	// returnState.getSn()
	// + " ChannelCode:" + returnState.getChannelCode();
	// Log4jUtil.info(logMsg);
	// returnStateList.add(returnState);
	// }
	// if (returnStateList.size() != cbr.getTotalNum()) {
	// // 部分业务已返回业务状态
	// cbr.setState("02");
	// } else {
	// // 全部业务已返回业务状态
	// cbr.setState("03");
	// }
	// // 更新表channelBatchRefund状态
	// channelBatchRefundDao.update(cbr);
	// return returnStateList;
	// } else {
	// // 7、超期退款结果查询失败
	// logMsg = logPrefix + "向银行发起查询批量退款失败。ReturnCode:" + tResponse.getReturnCode() +
	// " ErrorMessage:"
	// + tResponse.getErrorMessage();
	// Log4jUtil.info(logMsg);
	// throw new BizException(logMsg);
	// }
	//
	// }

}
