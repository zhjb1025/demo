package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_CQLA36Bean {
	// ERP2CT_CQLA36Bean 按请求流水号查询人行监管报表稽核结果（CQLA36）请求报文字段
	
	private String SerialDate;	// 查询报表日期
	private String SerialNo; // 原流水号
	private String FileSplit; //分隔符
	
	public String getSerialDate() {
		return SerialDate;
	}
	public void setSerialDate(String serialDate) {
		SerialDate = serialDate;
	}
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	public String getFileSplit() {
		return FileSplit;
	}
	public void setFileSplit(String fileSplit) {
		FileSplit = fileSplit;
	}
	
}
