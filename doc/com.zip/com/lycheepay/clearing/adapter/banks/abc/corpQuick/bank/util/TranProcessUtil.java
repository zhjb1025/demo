package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util;

import java.nio.charset.Charset;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatFileResultQueryReq;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatFileResultQueryRsp;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatchTrasNoticeRsp;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.RequestBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.ResponeBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util.BatchNoticeBean;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.StringProcess;
import com.lycheepay.clearing.adapter.common.util.net.FormatTransfer;
import com.lycheepay.clearing.adapter.common.util.net.SendBySocket;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


@Service("abcquick.tranProcessUtil")
public class TranProcessUtil {

	/**
	 * 根据传入的请求 bean，发送交易，返回结果给调用者
	 * 
	 * @param socketIP 发送数据的服务器IP
	 * @param socketPort 发送数据的服务器端口
	 * @param requestBean 发送的 bean
	 * @return ReturnState 返回 ReturnState
	 * @throws BizException 业务异常
	 */
	public ResponeBean trans(String socketIP, String socketPort, RequestBean requestBean, String md5CodeKey,
			String transType) throws BizException {

		String revInfo; // 保存快捷平台交易返回的数据

		if (transType.equals(ClearingTransType.REAL_TIME_DEDUCT)
				|| transType.equals(ClearingTransType.MSG_ACCOUNT_VERIFY)
				|| transType.equals(ClearingTransType.AUTO_REAL_TIME_REFUND)) {
			revInfo = tranSend(socketIP, socketPort, requestBean, md5CodeKey);
			AssertUtils.notEmpty(revInfo, TransReturnCode.code_9109, "农行快捷系统返回的信息为空，请联系银行");
			return tranResultProcess(revInfo, md5CodeKey);
		} else if (transType.equals(ClearingTransType.REAL_TIME_PAY) || "recharge".equals(transType)
				|| "PayRefund".equals(transType)) {
			revInfo = tranSendPay(socketIP, socketPort, requestBean, md5CodeKey);
			AssertUtils.notEmpty(revInfo, TransReturnCode.code_9109, "农行快捷系统返回的信息为空，请联系银行");
			ResponeBean responeBean = new ResponeBean();
			try {
				responeBean = tranResultProcessPay(revInfo, md5CodeKey);
			} catch (Exception e) {
				Log4jUtil.error(e.getMessage(), e);
				throw new BizException(e, TransReturnCode.code_9109,
						TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
			}
			return responeBean;
		} else if ("rush".equals(transType)) { // 冲正
			revInfo = tranSend_rush(socketIP, socketPort, requestBean, md5CodeKey);
			AssertUtils.notEmpty(revInfo, TransReturnCode.code_9109, "农行快捷系统返回的信息为空，请联系银行");
			return tranResultProcess_rush(revInfo, md5CodeKey);
		} else {
			throw new BizException(TransReturnCode.code_9108, "传入了错误的渠道交易类型" + transType);
		}

	}

	/**
	 * 冲正回执信息解析
	 * 
	 * @param revInfo
	 * @param md5CodeKey
	 * @return
	 * @throws BizException
	 */
	private ResponeBean tranResultProcess_rush(String revInfo, String md5CodeKey) throws BizException {
		ResponeBean responeBean = new ResponeBean();
		revInfo = revInfo.substring(4);// 返回报表前4位是数据长度，去掉。
		responeBean.setTranCode(new String(revInfo.getBytes(), 0, 4));
		responeBean.setProcessCode(new String(revInfo.getBytes(), 4, 6));
		responeBean.setTerminateCode(new String(revInfo.getBytes(), 10, 8));
		responeBean.setMerchantCode(new String(revInfo.getBytes(), 18, 15));
		responeBean.setBizCode(new String(revInfo.getBytes(), 33, 2));
		responeBean.setAccount(new String(revInfo.getBytes(), 35, 19));
		responeBean.setAmt(new String(revInfo.getBytes(), 54, 12));
		responeBean.setSysTrack(new String(revInfo.getBytes(), 66, 20));
		responeBean.setTranTime(new String(revInfo.getBytes(), 86, 6));
		responeBean.setTranDate(new String(revInfo.getBytes(), 92, 8));
		responeBean.setSettleDate(new String(revInfo.getBytes(), 100, 8));
		responeBean.setReceiverTag(new String(revInfo.getBytes(), 108, 11));
		responeBean.setSysCode(new String(revInfo.getBytes(), 119, 20));
		// responeBean.setCardValidDate(new String(revInfo.getBytes(),139,4));
		// responeBean.setAuthorCode(new String(revInfo.getBytes(),143,2));
		responeBean.setCurrencyCode(new String(revInfo.getBytes(), 139, 3));
		responeBean.setRetCode(new String(revInfo.getBytes(), 142, 2));
		responeBean.setAppendData(new String(revInfo.getBytes(), 144, 25));
		// responeBean.setAppendAmt(new String(revInfo.getBytes(),175,20));
		responeBean.setMd5Code(new String(revInfo.getBytes(), 169, 32));

		Log4jUtil.info("-----------冲正回执信息解析如下：");
		Log4jUtil.info("交易码: " + responeBean.getTranCode());// 1 交易码 4 0210
		Log4jUtil.info("处理码: " + responeBean.getProcessCode());// 2 处理码 6 330000-身份验证
		Log4jUtil.info("终端号: " + responeBean.getTerminateCode());// 3 终端号 8
		Log4jUtil.info("商户号: " + responeBean.getMerchantCode());// 4 商户号 15
		Log4jUtil.info("业务代码: " + responeBean.getBizCode());// 5 业务代码 2
		Log4jUtil.info("主账号: " + responeBean.getAccount());// 6 主账号 19 左对齐右补空格
		Log4jUtil.info("交易金额: " + responeBean.getAmt());// 7 交易金额 12 以分为单位不含小数点长度不足左补零
														// 000000010000为100.00
		Log4jUtil.info("系统跟踪号: " + responeBean.getSysTrack());// 8 系统跟踪号 20
		Log4jUtil.info("交易时间: " + responeBean.getTranTime());// 9 交易时间 6 hhmmss
		Log4jUtil.info("交易日期: " + responeBean.getTranDate());// 10 交易日期 8 YYYYMMDD
		Log4jUtil.info("清算日期: " + responeBean.getSettleDate());// 11 清算日期 8 YYYYMMDD
		Log4jUtil.info("受理方标识码: " + responeBean.getReceiverTag());// 12 受理方标识码 11 01030000041
		Log4jUtil.info("系统参考号: " + responeBean.getSysCode());// 13 系统参考号 20
		// Log4jUtil.info("卡有效期: "+responeBean.getCardValidDate());//14 卡有效期 4 YYMM
		// Log4jUtil.info("授权码: "+responeBean.getAuthorCode());//15 授权码 2
		Log4jUtil.info("货币代码: " + responeBean.getCurrencyCode());// 16 货币代码 3
		Log4jUtil.info("返回码: " + responeBean.getRetCode());// 17 返回码 2
		Log4jUtil.info("附加响应数据: " + responeBean.getAppendData());// 18 附加响应数据 25 左对齐右补空格
																	// 如果为余额查询交易，并且账号为商户对公账号时，返回商户当天代付和退货可用余额（以分为单位不含小数点）。
		// Log4jUtil.info("附加金额: "+responeBean.getAppendAmt());//19 附加金额 20 以分为单位不含小数点长度不足左补零
		// 000000010000为100.00
		Log4jUtil.info("MD5密码: " + responeBean.getMd5Code());// 20 MD5密码 32
		String md5Str1 = responeBean.getTranCode() + responeBean.getProcessCode() + responeBean.getTerminateCode()
				+ responeBean.getMerchantCode() + responeBean.getBizCode() + responeBean.getAccount()
				+ responeBean.getAmt() + responeBean.getSysTrack() + responeBean.getTranTime()
				+ responeBean.getTranDate() + responeBean.getSettleDate() + responeBean.getReceiverTag()
				+ responeBean.getSysCode() + responeBean.getCurrencyCode() + responeBean.getRetCode()
				+ responeBean.getAppendData();
		// 计算 MD5 码
		String md5Code = md5Created(md5Str1, md5CodeKey);
		Log4jUtil.info("计算的MD5码（不含MD5字段）:" + md5Code);// 20 MD5密码 32
		if (md5Code.equals(responeBean.getMd5Code()) == false) {
			throw new BizException(TransReturnCode.code_9109, "错误：报文中含有的MD5码与计算得到的MD5码不符");
		}
		return responeBean;
	}

	/**
	 * 冲正
	 * 
	 * @param socketIP
	 * @param socketPort
	 * @param requestBean
	 * @param md5CodeKey
	 * @return
	 * @throws BizException
	 */
	private String tranSend_rush(String socketIP, String socketPort, RequestBean requestBean, String md5CodeKey)
			throws BizException {
		// 请报报文的长度为 4 + 152 = 156
		String sendInfo; // 保存快捷平台交易发送的数据
		if (requestBean.getTranCode().length() != 4) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的交易码是" + requestBean.getTranCode() + ";长度不是4位");
		}
		if (requestBean.getProcessCode().length() != 6) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的处理码是" + requestBean.getProcessCode()
					+ ";长度不是6位");
		}
		if (requestBean.getBizCode().length() != 2) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的业务代码是" + requestBean.getBizCode() + ";长度不是2位");
		}
		if (requestBean.getCurrencyCode().length() != 3) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的货币代码是" + requestBean.getCurrencyCode()
					+ ";长度不是3位");
		}

		StringBuffer sb = new StringBuffer();
		sb.append(requestBean.getTranCode());
		sb.append(requestBean.getProcessCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getTerminateCode(), 8));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantCode(), 15));
		sb.append(requestBean.getBizCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getAccount(), 19));
		sb.append(FormatTransfer.setLStrFormat(requestBean.getAmt(), 12)); // 以分为单位不含小数点
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getSysTrack(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getInputCode(), 3));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getCardValidDate(), 4));// YYMM
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getAuthorCode(), 2));
		sb.append("06");
		sb.append(requestBean.getCurrencyCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantStream(), 20));
		sb.append(md5Created(sb.toString(), md5CodeKey));
		sendInfo = "0152" + sb.toString();
		Log4jUtil.info("发送到农行快捷系统的数据为：" + sendInfo);
		if (sendInfo.getBytes(Charset.forName("GBK")).length != 156) {
			throw new BizException(TransReturnCode.code_9108, "错误，组好的发送报文长度是"
					+ sendInfo.getBytes(Charset.forName("GBK")).length + ";不是规定的156");
		}
		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo);
	}

	/**
	 * 发送请求bean给快捷系统，返回快捷系统的结果字符串
	 * 
	 * @param requestBean 快捷系统的请求 bean
	 * @return 快捷系统返回的结果字符串
	 * @throws BizException
	 */
	private String tranSend(String socketIP, String socketPort, RequestBean requestBean, String md5CodeKey)
			throws BizException {
		// 请报报文的长度为 4 + 315 = 319
		String sendInfo; // 保存快捷平台交易发送的数据
		if (requestBean.getTranCode().length() != 4) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的交易码是" + requestBean.getTranCode() + ";长度不是4位");
		}
		if (requestBean.getProcessCode().length() != 6) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的处理码是" + requestBean.getProcessCode()
					+ ";长度不是6位");
		}
		if (requestBean.getBizCode().length() != 2) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的业务代码是" + requestBean.getBizCode() + ";长度不是2位");
		}
		if (requestBean.getCurrencyCode().length() != 3) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的货币代码是" + requestBean.getCurrencyCode()
					+ ";长度不是3位");
		}
		if (StringUtils.trim(requestBean.getAccount()).length() > 19) {
			throw new BizException(TransReturnCode.code_9108, "账号" + requestBean.getAccount() + "长度错误，最长19位");
		}

		StringBuffer sb = new StringBuffer();
		sb.append(requestBean.getTranCode());
		sb.append(requestBean.getProcessCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getTerminateCode(), 8));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantCode(), 15));
		sb.append(requestBean.getBizCode());
		sb.append(StringProcess.addRightSpaceForNum(StringUtils.trim(requestBean.getAccount()), 19));
		sb.append(FormatTransfer.setLStrFormat(requestBean.getAmt(), 12)); // 以分为单位不含小数点
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getSysTrack(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getTranDate(), 8));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getInputCode(), 3));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getOriSysCode(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getCardValidDate(), 4));// YYMM
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getAuthorCode(), 2));
		sb.append(StringProcess.addRightSpaceForNum(StringSub.toLengthNoPadding(requestBean.getRemark(), 8), 10));
		sb.append(StringProcess.addRightSpaceForNum(StringUtils.trim(requestBean.getAccName()), 70));
		sb.append(requestBean.getCurrencyCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantStream(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getIdCard(), 22));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getTerminateStreamCode(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMobile(), 15));
		sb.append(md5Created(sb.toString(), md5CodeKey));
		sendInfo = "0315" + sb.toString();
		Log4jUtil.info("发送到农行快捷系统的数据为：" + sendInfo);
		if (sendInfo.getBytes(Charset.forName("GBK")).length != 319) {
			throw new BizException(TransReturnCode.code_9108, "错误，组好的发送报文长度是"
					+ sendInfo.getBytes(Charset.forName("GBK")).length + ";不是规定的319");
		}
		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo);
	}

	/**
	 * 发送请求bean给快捷系统，返回快捷系统的结果字符串
	 * 
	 * @param requestBean 快捷系统的请求 bean
	 * @return 快捷系统返回的结果字符串
	 * @throws BizException
	 */
	private String tranSendPay(String socketIP, String socketPort, RequestBean requestBean, String md5CodeKey)
			throws BizException {
		// 请报报文的长度为 4 + 287 = 291
		String sendInfo; // 保存快捷平台交易发送的数据
		if (requestBean.getTranCode().length() != 4) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的交易码是" + requestBean.getTranCode() + ";长度不是4位");
		}
		if (requestBean.getProcessCode().length() != 6) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的处理码是" + requestBean.getProcessCode()
					+ ";长度不是6位");
		}
		if (requestBean.getBizCode().length() != 2) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的业务代码是" + requestBean.getBizCode() + ";长度不是2位");
		}
		if (requestBean.getCurrencyCode().length() != 3) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的货币代码是" + requestBean.getCurrencyCode()
					+ ";长度不是3位");
		}
		if (StringUtils.trim(requestBean.getAccount()).length() > 19) {
			throw new BizException(TransReturnCode.code_9108, "账号" + requestBean.getAccount() + "长度错误，最长19位");
		}

		StringBuffer sb = new StringBuffer();
		sb.append(requestBean.getTranCode());
		sb.append(requestBean.getProcessCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getTerminateCode(), 8));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantCode(), 15));
		sb.append(requestBean.getBizCode());
		sb.append(StringProcess.addRightSpaceForNum(StringUtils.trim(requestBean.getAccount()), 19));
		sb.append(FormatTransfer.setLStrFormat(requestBean.getAmt(), 12)); // 以分为单位不含小数点
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getSysTrack(), 20));
		// sb.append(StringProcess.addRightSpaceForNum(requestBean.getTranDate(),8));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getInputCode(), 3));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getOriSysCode(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getCardValidDate(), 4));// YYMM
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getAuthorCode(), 2));
		sb.append(StringProcess.addRightSpaceForNum(StringSub.toLengthNoPadding(requestBean.getRemark(), 8), 10));
		sb.append(StringProcess.addRightSpaceForNum(StringUtils.trim(requestBean.getAccName()), 70));
		sb.append(requestBean.getCurrencyCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantStream(), 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getIdCard(), 22));
		// sb.append(StringProcess.addRightSpaceForNum(requestBean.getTerminateStreamCode(),20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMobile(), 15));
		sb.append(md5Created(sb.toString(), md5CodeKey));
		sendInfo = "0287" + sb.toString();
		Log4jUtil.info("发送到农行快捷系统的数据为：" + sendInfo);
		if (sendInfo.getBytes(Charset.forName("GBK")).length != 291) {
			throw new BizException(TransReturnCode.code_9108, "错误，组好的发送报文长度是"
					+ sendInfo.getBytes(Charset.forName("GBK")).length + ";不是规定的291");
		}
		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo);
	}

	/**
	 * 解释快捷系统返回的结果字符串，组返回bean(ResponeBean)
	 * 
	 * @param revInfo 快捷系统返回的结果字符串
	 * @param md5CodeKey 快捷系统MD5 key
	 * @return ResponeBean 快捷系统的结果bean
	 * @throws BizException
	 */
	private ResponeBean tranResultProcess(String revInfo, String md5CodeKey) throws BizException {
		ResponeBean responeBean = new ResponeBean();
		revInfo = revInfo.substring(4);// 返回报表前4位是数据长度，去掉。
		responeBean.setTranCode(new String(revInfo.getBytes(), 0, 4));
		responeBean.setProcessCode(new String(revInfo.getBytes(), 4, 6));
		responeBean.setTerminateCode(new String(revInfo.getBytes(), 10, 8));
		responeBean.setMerchantCode(new String(revInfo.getBytes(), 18, 15));
		responeBean.setBizCode(new String(revInfo.getBytes(), 33, 2));
		responeBean.setAccount(new String(revInfo.getBytes(), 35, 19));
		responeBean.setAmt(new String(revInfo.getBytes(), 54, 12));
		responeBean.setSysTrack(new String(revInfo.getBytes(), 66, 20));
		responeBean.setTranTime(new String(revInfo.getBytes(), 86, 6));
		responeBean.setTranDate(new String(revInfo.getBytes(), 92, 8));
		responeBean.setSettleDate(new String(revInfo.getBytes(), 100, 8));
		responeBean.setReceiverTag(new String(revInfo.getBytes(), 108, 11));
		responeBean.setSysCode(new String(revInfo.getBytes(), 119, 20));
		responeBean.setCardValidDate(new String(revInfo.getBytes(), 139, 4));
		responeBean.setAuthorCode(new String(revInfo.getBytes(), 143, 2));
		responeBean.setCurrencyCode(new String(revInfo.getBytes(), 145, 3));
		responeBean.setRetCode(new String(revInfo.getBytes(), 148, 2));
		responeBean.setAppendData(new String(revInfo.getBytes(), 150, 25));
		responeBean.setAppendAmt(new String(revInfo.getBytes(), 175, 20));
		responeBean.setMd5Code(new String(revInfo.getBytes(), 195, 32));

		Log4jUtil.info("快捷系统返回报文如下：");
		Log4jUtil.info("交易码: " + responeBean.getTranCode());// 1 交易码 4 0210
		Log4jUtil.info("处理码: " + responeBean.getProcessCode());// 2 处理码 6 330000-身份验证
		Log4jUtil.info("终端号: " + responeBean.getTerminateCode());// 3 终端号 8
		Log4jUtil.info("商户号: " + responeBean.getMerchantCode());// 4 商户号 15
		Log4jUtil.info("业务代码: " + responeBean.getBizCode());// 5 业务代码 2
		Log4jUtil.info("主账号: " + responeBean.getAccount());// 6 主账号 19 左对齐右补空格
		Log4jUtil.info("交易金额: " + responeBean.getAmt());// 7 交易金额 12 以分为单位不含小数点长度不足左补零
														// 000000010000为100.00
		Log4jUtil.info("系统跟踪号: " + responeBean.getSysTrack());// 8 系统跟踪号 20
		Log4jUtil.info("交易时间: " + responeBean.getTranTime());// 9 交易时间 6 hhmmss
		Log4jUtil.info("交易日期: " + responeBean.getTranDate());// 10 交易日期 8 YYYYMMDD
		Log4jUtil.info("清算日期: " + responeBean.getSettleDate());// 11 清算日期 8 YYYYMMDD
		Log4jUtil.info("受理方标识码: " + responeBean.getReceiverTag());// 12 受理方标识码 11 01030000041
		Log4jUtil.info("系统参考号: " + responeBean.getSysCode());// 13 系统参考号 20
		Log4jUtil.info("卡有效期: " + responeBean.getCardValidDate());// 14 卡有效期 4 YYMM
		Log4jUtil.info("授权码: " + responeBean.getAuthorCode());// 15 授权码 2
		Log4jUtil.info("货币代码: " + responeBean.getCurrencyCode());// 16 货币代码 3
		Log4jUtil.info("返回码: " + responeBean.getRetCode());// 17 返回码 2
		Log4jUtil.info("附加响应数据: " + responeBean.getAppendData());// 18 附加响应数据 25 左对齐右补空格
																	// 如果为余额查询交易，并且账号为商户对公账号时，返回商户当天代付和退货可用余额（以分为单位不含小数点）。
		Log4jUtil.info("附加金额: " + responeBean.getAppendAmt());// 19 附加金额 20 以分为单位不含小数点长度不足左补零
																// 000000010000为100.00
		Log4jUtil.info("MD5密码: " + responeBean.getMd5Code());// 20 MD5密码 32
		String md5Str1 = responeBean.getTranCode() + responeBean.getProcessCode() + responeBean.getTerminateCode()
				+ responeBean.getMerchantCode() + responeBean.getBizCode() + responeBean.getAccount()
				+ responeBean.getAmt() + responeBean.getSysTrack() + responeBean.getTranTime()
				+ responeBean.getTranDate() + responeBean.getSettleDate() + responeBean.getReceiverTag()
				+ responeBean.getSysCode() + responeBean.getCardValidDate() + responeBean.getAuthorCode()
				+ responeBean.getCurrencyCode() + responeBean.getRetCode() + responeBean.getAppendData()
				+ responeBean.getAppendAmt();
		// String md5Str2 = responeBean.getTranCode()+responeBean.getProcessCode()
		// +responeBean.getTerminateCode()+responeBean.getMerchantCode()
		// +responeBean.getBizCode()+responeBean.getAccount()+responeBean.getAmt()
		// +responeBean.getSysTrack()+responeBean.getTranTime()+responeBean.getTranDate()
		// +responeBean.getSettleDate()+responeBean.getReceiverTag()+responeBean.getSysCode()
		// +responeBean.getCardValidDate()+responeBean.getAuthorCode()+responeBean.getCurrencyCode()
		// +responeBean.getRetCode()+responeBean.getAppendData()+responeBean.getAppendAmt()
		// +responeBean.getMd5Code();
		// String md5Code1 =ChannelMD5CreateForKey.hmacSign(md5Str1,md5CodeKey);
		// String md5Code2 =ChannelMD5CreateForKey.hmacSign(md5Str2,md5CodeKey);

		// Log4jUtil.info("原报文（不含MD5字段）:"+md5Str1);//20 MD5密码 32
		// Log4jUtil.info("原报文（含MD5字段）: "+md5Str2);//20 MD5密码 32
		// 计算 MD5 码
		String md5Code = md5Created(md5Str1, md5CodeKey);
		Log4jUtil.info("计算的MD5码（不含MD5字段）:" + md5Code);// 20 MD5密码 32
		if (md5Code.equals(responeBean.getMd5Code()) == false) {
			throw new BizException(TransReturnCode.code_9109, "错误：报文中含有的MD5码与计算得到的MD5码不符");
		}
		return responeBean;
	}

	/**
	 * 解释快捷系统返回的结果字符串，组返回bean(ResponeBean)
	 * 
	 * @param revInfo 快捷系统返回的结果字符串
	 * @param md5CodeKey 快捷系统MD5 key
	 * @return ResponeBean 快捷系统的结果bean
	 * @throws BizException
	 */
	private ResponeBean tranResultProcessPay(String revInfo, String md5CodeKey) throws BizException {
		ResponeBean responeBean = new ResponeBean();
		revInfo = revInfo.substring(4);// 返回报表前4位是数据长度，去掉。
		responeBean.setTranCode(new String(revInfo.getBytes(), 0, 4));
		responeBean.setProcessCode(new String(revInfo.getBytes(), 4, 6));
		responeBean.setTerminateCode(new String(revInfo.getBytes(), 10, 8));
		responeBean.setMerchantCode(new String(revInfo.getBytes(), 18, 15));
		responeBean.setBizCode(new String(revInfo.getBytes(), 33, 2));
		responeBean.setAccount(new String(revInfo.getBytes(), 35, 19));
		responeBean.setAmt(new String(revInfo.getBytes(), 54, 12));
		responeBean.setSysTrack(new String(revInfo.getBytes(), 66, 20));
		responeBean.setTranTime(new String(revInfo.getBytes(), 86, 6));
		responeBean.setTranDate(new String(revInfo.getBytes(), 92, 8));
		responeBean.setSettleDate(new String(revInfo.getBytes(), 100, 8));
		responeBean.setReceiverTag(new String(revInfo.getBytes(), 108, 11));
		responeBean.setSysCode(new String(revInfo.getBytes(), 119, 20));
		// responeBean.setCardValidDate(new String(revInfo.getBytes(),139,4));
		// responeBean.setAuthorCode(new String(revInfo.getBytes(),143,2));
		responeBean.setCurrencyCode(new String(revInfo.getBytes(), 139, 3));
		responeBean.setRetCode(new String(revInfo.getBytes(), 142, 2));
		responeBean.setAppendData(new String(revInfo.getBytes(), 144, 25));
		// responeBean.setAppendAmt(new String(revInfo.getBytes(),175,20));
		responeBean.setMd5Code(new String(revInfo.getBytes(), 169, 32));

		Log4jUtil.info("快捷系统返回报文如下：");
		Log4jUtil.info("交易码: " + responeBean.getTranCode());// 1 交易码 4 0210
		Log4jUtil.info("处理码: " + responeBean.getProcessCode());// 2 处理码 6 330000-身份验证
		Log4jUtil.info("终端号: " + responeBean.getTerminateCode());// 3 终端号 8
		Log4jUtil.info("商户号: " + responeBean.getMerchantCode());// 4 商户号 15
		Log4jUtil.info("业务代码: " + responeBean.getBizCode());// 5 业务代码 2
		Log4jUtil.info("主账号: " + responeBean.getAccount());// 6 主账号 19 左对齐右补空格
		Log4jUtil.info("交易金额: " + responeBean.getAmt());// 7 交易金额 12 以分为单位不含小数点长度不足左补零
														// 000000010000为100.00
		Log4jUtil.info("系统跟踪号: " + responeBean.getSysTrack());// 8 系统跟踪号 20
		Log4jUtil.info("交易时间: " + responeBean.getTranTime());// 9 交易时间 6 hhmmss
		Log4jUtil.info("交易日期: " + responeBean.getTranDate());// 10 交易日期 8 YYYYMMDD
		Log4jUtil.info("清算日期: " + responeBean.getSettleDate());// 11 清算日期 8 YYYYMMDD
		Log4jUtil.info("受理方标识码: " + responeBean.getReceiverTag());// 12 受理方标识码 11 01030000041
		Log4jUtil.info("系统参考号: " + responeBean.getSysCode());// 13 系统参考号 20
		// Log4jUtil.info("卡有效期: "+responeBean.getCardValidDate());//14 卡有效期 4 YYMM
		// Log4jUtil.info("授权码: "+responeBean.getAuthorCode());//15 授权码 2
		Log4jUtil.info("货币代码: " + responeBean.getCurrencyCode());// 16 货币代码 3
		Log4jUtil.info("返回码: " + responeBean.getRetCode());// 17 返回码 2
		Log4jUtil.info("附加响应数据: " + responeBean.getAppendData());// 18 附加响应数据 25 左对齐右补空格
																	// 如果为余额查询交易，并且账号为商户对公账号时，返回商户当天代付和退货可用余额（以分为单位不含小数点）。
		// Log4jUtil.info("附加金额: "+responeBean.getAppendAmt());//19 附加金额 20 以分为单位不含小数点长度不足左补零
		// 000000010000为100.00
		Log4jUtil.info("MD5密码: " + responeBean.getMd5Code());// 20 MD5密码 32
		String md5Str1 = responeBean.getTranCode() + responeBean.getProcessCode() + responeBean.getTerminateCode()
				+ responeBean.getMerchantCode() + responeBean.getBizCode() + responeBean.getAccount()
				+ responeBean.getAmt() + responeBean.getSysTrack() + responeBean.getTranTime()
				+ responeBean.getTranDate() + responeBean.getSettleDate() + responeBean.getReceiverTag()
				+ responeBean.getSysCode() + responeBean.getCurrencyCode() + responeBean.getRetCode()
				+ responeBean.getAppendData();
		// 计算 MD5 码
		String md5Code = md5Created(md5Str1, md5CodeKey);
		Log4jUtil.info("计算的MD5码（不含MD5字段）:" + md5Code);// 20 MD5密码 32
		if (md5Code.equals(responeBean.getMd5Code()) == false) {
			throw new BizException(TransReturnCode.code_9109, "错误：报文中含有的MD5码与计算得到的MD5码不符");
		}
		return responeBean;
	}

	/**
	 * 把传入的字符串转为大写
	 * 
	 * @param str
	 * @return
	 */
	public String toUpper(String str) {
		int size = str.length();
		char[] chs = str.toCharArray();
		for (int i = 0; i < size; i++) {
			// if (chs[i] <= 'Z' && chs[i] >= 'A') {
			// chs[i] = (char) (chs[i] + 32);
			// } else
			if (chs[i] <= 'z' && chs[i] >= 'a') {
				chs[i] = (char) (chs[i] - 32);
			}
		}
		return new String(chs);
	}

	/**
	 * 得到快捷系统要求的MD5码
	 * 
	 * @param str 报文
	 * @param md5CodeKey MD5 Key
	 * @return MD5码
	 * @throws BizException
	 */
	public String md5Created(String str, String md5CodeKey) throws BizException {
		// 计算 MD5 码，把报文串加上KEY,再计算 MD5 码，再把 MD5码 转换为大写字母
		Md5 md51 = new Md5();
		md51.md5s(str + md5CodeKey);
		return toUpper(md51.str);
	}

	public BatchTrasNoticeRsp transNotice(String socketIP, String socketPort, BatchNoticeBean batchNoticeBean,
			String md5CodeKey) throws BizException {
		String revInfo = this.tranSendNotice_pay(socketIP, socketPort, batchNoticeBean, md5CodeKey);
		AssertUtils.notEmpty(revInfo, TransReturnCode.code_9109, "农行快捷系统返回的信息为空，请联系银行");
		return this.tranNoticeResult_pay(revInfo, md5CodeKey);
	}

	/**
	 * 文件接收通知交易
	 * 
	 * @param socketPort
	 * @param batchNoticeBean
	 * @param md5CodeKey
	 * @return
	 * @throws BizException
	 */
	private String tranSendNotice_pay(String socketIP, String socketPort, BatchNoticeBean batchNoticeBean,
			String md5CodeKey) throws BizException {
		/**
		 * 
		 1 交易代码 4 2 商户代码 5 3 项目号 5 4 支付标志 2 5 交易请求日期 8 6 交易请求时间 6 7 文件序号 4 8 文件大小 10 9 总笔数 10 10
		 * 总金额 18
		 * 
		 */

		// 请报报文的长度为 4 + 72 = 76

		AssertUtils.checkLength(batchNoticeBean.getTransCode(), TransReturnCode.code_9108, "交易代码", 4, 4);
		AssertUtils.checkLength(batchNoticeBean.getMerchantCode(), TransReturnCode.code_9108, "商户代码", 5, 5);
		AssertUtils.checkLength(batchNoticeBean.getProjectCode(), TransReturnCode.code_9108, "项目号", 1, 5);
		AssertUtils.checkLength(batchNoticeBean.getPayFlag(), TransReturnCode.code_9108, "支付标志", 2, 2);
		AssertUtils.checkLength(batchNoticeBean.getTransReqDate(), TransReturnCode.code_9108, "交易请求日期", 8, 8);
		AssertUtils.checkLength(batchNoticeBean.getTransReqTime(), TransReturnCode.code_9108, "交易请求时间", 6, 6);
		AssertUtils.checkLength(batchNoticeBean.getFileNumber(), TransReturnCode.code_9108, "文件序号", 4, 4);

		StringBuffer sb = new StringBuffer();
		sb.append(batchNoticeBean.getTransCode());
		sb.append(batchNoticeBean.getMerchantCode());
		sb.append(StringProcess.addRightSpaceForNum(batchNoticeBean.getProjectCode(), 5));
		sb.append(batchNoticeBean.getPayFlag());
		sb.append(batchNoticeBean.getTransReqDate());
		sb.append(batchNoticeBean.getTransReqTime());
		sb.append(FormatTransfer.setLStrFormat(batchNoticeBean.getFileNumber(), 4));
		sb.append(FormatTransfer.setLStrFormat(
				(new java.text.DecimalFormat("0").format(batchNoticeBean.getFileSize())), 10));
		sb.append(FormatTransfer.setLStrFormat(batchNoticeBean.getTotalNum(), 10));
		sb.append(FormatTransfer.setLStrFormat(batchNoticeBean.getTotalAmt(), 18));

		String sendInfo = "0072" + sb.toString();
		Log4jUtil.info("发送到农行快捷系统的数据为：" + sendInfo);
		if (sendInfo.getBytes(Charset.forName("GBK")).length != 76) {
			throw new BizException(TransReturnCode.code_9109, "错误，组好的发送报文长度是"
					+ sendInfo.getBytes(Charset.forName("GBK")).length + ";不是规定的76");
		}
		SendBySocket sendBySocket = new SendBySocket();
		return sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo);
	}

	/**
	 * 文件接收通知交易 返回信息
	 * 
	 * @param revInfo
	 * @param md5CodeKey
	 * @return
	 * @throws BizException
	 */
	private BatchTrasNoticeRsp tranNoticeResult_pay(String revInfo, String md5CodeKey) throws BizException {
		/**
		 * 1 银行流水号 20 2 交易日期 8 3 交易时间 6 4 文件名 30 5 返回码 4 6 返回信息 30
		 */

		BatchTrasNoticeRsp resBean = new BatchTrasNoticeRsp();
		revInfo = revInfo.substring(4);// 返回报表前4位是数据长度，去掉。
		resBean.setBackSeq(new String(revInfo.getBytes(), 0, 20));
		resBean.setTranDate(new String(revInfo.getBytes(), 20, 8));
		resBean.setTranTime(new String(revInfo.getBytes(), 28, 6));
		resBean.setFileName(new String(revInfo.getBytes(), 34, 30));
		resBean.setRetCode(new String(revInfo.getBytes(), 64, 4));
		resBean.setRetMsg(StringUtils.trim(new String(revInfo.getBytes(), 68, 30)));

		Log4jUtil.info("快捷系统返回报文如下：");
		Log4jUtil.info("银行流水号: " + resBean.getBackSeq());// 1 银行流水号 20 YYYYMMDD
		Log4jUtil.info("交易日期: " + resBean.getTranDate());// 2 交易日期 8 YYYYMMDD
		Log4jUtil.info("交易时间:" + resBean.getTranTime());// 3 交易时间 6 hhmmss
		Log4jUtil.info("文件名: " + resBean.getFileName());// 4 文件名 30
		Log4jUtil.info("返回码: " + resBean.getRetCode());// 5 返回码 4
		Log4jUtil.info("返回信息: " + resBean.getRetMsg());// 6 返回信息 30
		return resBean;
	}

	/**
	 * 批量文件结果查询
	 * 
	 * @param socketIP
	 * @param socketPort
	 * @param req
	 * @param md5CodeKey
	 * @return
	 * @throws BizException
	 */
	public BatFileResultQueryRsp batFileResultQuery(String socketIP, String socketPort, BatFileResultQueryReq req,
			String md5CodeKey) throws BizException {
		/**
		 * 
		 1 交易代码 4 2 原银行流水号 20
		 */

		// 请报报文的长度为 4 + 24 = 28

		AssertUtils.checkLength(req.getTranCode(), TransReturnCode.code_9108, "交易代码", 4, 4);
		AssertUtils.checkLength(req.getBackSeq(), TransReturnCode.code_9108, "原银行流水号", 20, 20);

		StringBuffer sb = new StringBuffer();
		sb.append(req.getTranCode());
		sb.append(StringProcess.addRightSpaceForNum(String.valueOf(req.getBackSeq()), 20));
		String sendInfo = "0024" + sb.toString();
		Log4jUtil.info("发送到农行快捷系统的数据为：" + sendInfo);
		if (sendInfo.getBytes(Charset.forName("GBK")).length != 28) {
			throw new BizException(TransReturnCode.code_9109, "错误，组好的发送报文长度是"
					+ sendInfo.getBytes(Charset.forName("GBK")).length + ";不是规定的28");
		}

		SendBySocket sendBySocket = new SendBySocket();
		String revInfo = sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo);

		/**
		 * 1 文件名 30 2 文件大小 10 3 总笔数 10 4 总金额 18 5 成功总笔数 10 6 成功总金额 18 7 交易日期 8 8 交易时间 6 9 返回码 4 10
		 * 返回信息 30
		 */

		BatFileResultQueryRsp resBean = new BatFileResultQueryRsp();
		revInfo = revInfo.substring(4);// 返回报表前4位是数据长度，去掉。

		resBean.setFileNameRcv(new String(revInfo.getBytes(), 0, 30).trim());
		resBean.setFileSize(new String(revInfo.getBytes(), 30, 10).trim());
		resBean.setTotalNum(new String(revInfo.getBytes(), 40, 10).trim());
		resBean.setTotalAmt(new String(revInfo.getBytes(), 50, 18).trim());
		resBean.setTotalNumSuc(new String(revInfo.getBytes(), 68, 10).trim());
		resBean.setTotalAmtSuc(new String(revInfo.getBytes(), 78, 18).trim());
		resBean.setTranDate(new String(revInfo.getBytes(), 96, 8).trim());
		resBean.setTranTime(new String(revInfo.getBytes(), 104, 6).trim());
		resBean.setRetCode(new String(revInfo.getBytes(), 110, 4).trim());
		resBean.setRetMsg(new String(revInfo.getBytes(), 114, 30).trim());

		Log4jUtil.info("快捷系统返回报文如下：");
		Log4jUtil.info("文件名: " + resBean.getFileNameRcv());
		Log4jUtil.info("文件大小: " + resBean.getFileSize());
		Log4jUtil.info("总笔数: " + resBean.getTotalNum());
		Log4jUtil.info("总金额: " + resBean.getTotalAmt());
		Log4jUtil.info("成功总笔数: " + resBean.getTotalNumSuc());
		Log4jUtil.info("成功总金额: " + resBean.getTotalAmtSuc());
		Log4jUtil.info("交易日期: " + resBean.getTranDate());
		Log4jUtil.info("交易时间:" + resBean.getTranTime());
		Log4jUtil.info("返回码: " + resBean.getRetCode());
		Log4jUtil.info("返回信息: " + resBean.getRetMsg());
		return resBean;
	}
	
	/**
	 * 信用卡账户验证
	 * 发送请求bean给快捷系统，返回快捷系统的结果字符串
	 * @param requestBean 快捷系统的请求 bean
	 * @return 快捷系统返回的结果ResponeBean
	 * @throws BizException
	 */
	public ResponeBean creditCardAccountVerify(String socketIP, String socketPort, RequestBean requestBean, String md5CodeKey)
			throws BizException {

		if (requestBean.getTranCode().length() != 4) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的交易码是" + requestBean.getTranCode() + ";长度不是4位");
		}
		if (requestBean.getProcessCode().length() != 6) {
			throw new BizException(TransReturnCode.code_9108, "交易码错误，传入的处理码是" + requestBean.getProcessCode()
					+ ";长度不是6位");
		}
		if (StringUtils.trim(requestBean.getAccount()).length() > 19) {
			throw new BizException(TransReturnCode.code_9108, "账号" + requestBean.getAccount() + "长度错误，最长19位");
		}
		StringBuilder sb = new StringBuilder();
		sb.append(requestBean.getTranCode());
		sb.append(requestBean.getProcessCode());
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getTerminateCode(), 8));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMerchantCode(), 15));
		sb.append(StringProcess.addRightSpaceForNum(StringUtils.trim(requestBean.getAccount()), 19));
		sb.append(StringProcess.addRightSpaceForNum(StringUtils.trim(requestBean.getAccName()), 70));
		// sb.append(StringProcess.addRightSpaceForNum(requestBean.getCardValidDate(), 4));// YYMM
		// sb.append(StringProcess.addRightSpaceForNum(requestBean.getAuthorCode(), 3));
		// sb.append(StringProcess.addRightSpaceForNum("S", 1));//S-按银联标准校验后6位，不送按默认全部校验
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getCardValidDate(), 4));// YYMM
		sb.append("   ");// CVV 不校验
		sb.append(" ");// S-按银联标准校验后6位，不送按默认全部校验
		sb.append(StringProcess.addRightSpaceForNum("", 20));
		sb.append(StringProcess.addRightSpaceForNum(requestBean.getMobile(), 15));
		sb.append(md5Created(sb.toString(), md5CodeKey));
		String sendInfo = "0197" + sb.toString();
		Log4jUtil.info("发送到农行快捷系统的数据为：" + sendInfo);
		if (sendInfo.getBytes(Charset.forName("GBK")).length != 201) {// 请报报文的长度为 4 + 197 = 201
			throw new BizException(TransReturnCode.code_9108, "错误，组好的发送报文长度是"
					+ sendInfo.getBytes(Charset.forName("GBK")).length + ";不是规定的201");
		}
		SendBySocket sendBySocket = new SendBySocket();
		String revInfo = sendBySocket.sendAndRecv(socketIP, socketPort, sendInfo);
		
		ResponeBean responeBean = new ResponeBean();
		revInfo = revInfo.substring(4);// 返回报表前4位是数据长度，去掉。
		responeBean.setTranCode(new String(revInfo.getBytes(), 0, 4));
		responeBean.setProcessCode(new String(revInfo.getBytes(), 4, 6));
		responeBean.setTerminateCode(new String(revInfo.getBytes(), 10, 8));
		responeBean.setMerchantCode(new String(revInfo.getBytes(), 18, 15));
		responeBean.setTranTime(new String(revInfo.getBytes(), 33, 6));
		responeBean.setTranDate(new String(revInfo.getBytes(), 39, 8));
		responeBean.setRetCode(new String(revInfo.getBytes(), 47, 2));
		responeBean.setMd5Code(new String(revInfo.getBytes(), 49, 32));

		Log4jUtil.info("快捷系统返回报文如下：");
		Log4jUtil.info("交易码: " + responeBean.getTranCode());// 1 交易码 4 0210
		Log4jUtil.info("处理码: " + responeBean.getProcessCode());// 2 处理码 6 330000-身份验证
		Log4jUtil.info("终端号: " + responeBean.getTerminateCode());// 3 终端号 8
		Log4jUtil.info("商户号: " + responeBean.getMerchantCode());// 4 商户号 15
		Log4jUtil.info("交易时间: " + responeBean.getTranTime());// 5 交易时间 6 hhmmss
		Log4jUtil.info("交易日期: " + responeBean.getTranDate());// 6 交易日期 8 YYYYMMDD
		Log4jUtil.info("返回码: " + responeBean.getRetCode());// 7 返回码 2
		Log4jUtil.info("MD5密码: " + responeBean.getMd5Code());// 8 MD5密码 32
		String md5Str1 = responeBean.getTranCode() + responeBean.getProcessCode() + responeBean.getTerminateCode()
				+ responeBean.getMerchantCode() + responeBean.getTranTime()
				+ responeBean.getTranDate() + responeBean.getRetCode();
		// 计算 MD5 码
		String md5Code = md5Created(md5Str1, md5CodeKey);
		Log4jUtil.info("计算的MD5码（不含MD5字段）:" + md5Code);// 20 MD5密码 32
		if (!md5Code.equals(responeBean.getMd5Code())) {
			throw new BizException(TransReturnCode.code_9109, "错误：报文中含有的MD5码与计算得到的MD5码不符");
		}
		return responeBean;
	}
}
