package com.lycheepay.clearing.adapter.banks.abc.http.b2b;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hitrust.b2b.trustpay.client.TrxResponse;
import com.hitrust.b2b.trustpay.client.b2b.FundTransferRequest;
import com.hitrust.b2b.trustpay.client.b2b.TrnxInfo;
import com.hitrust.b2b.trustpay.client.b2b.TrnxItems;
import com.hitrust.b2b.trustpay.client.b2b.TrnxRemarks;
import com.lycheepay.clearing.adapter.banks.abc.http.AbcUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


/**
 * <P>农业银行网银B2B HTTP请求处理器</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-16 下午6:10:38
 */
@Service(ClearingAdapterAnnotationName.ABC_B2B_HTTP_PROCESSOR)
public class AbcB2BHttpProcessor extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	/**
	 * <p>农业银行B2B网银代收</p>
	 * 
	 * @param httpParam
	 * @return
	 * @author 邱林 Leon.Qiu 2012-6-16 下午6:21:11
	 * @throws BizException
	 */
	public HttpReturnParam onlineDeduct(final HttpParam httpParam) throws BizException {
		Map<String, String> channelParam = new HashMap<String, String>();
		String logMsg = "";
		final String channelId = httpParam.getChannelId();
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		logMsg = "进入" + logPrefix + "渠道Http业务处理。";
		Log4jUtil.info(logMsg);
		// 获取渠道对应参数
		channelParam = channelParmService.queryCodeParamsMapByChannelId(channelId);
		// 支付或担保支付或者充值
		return b2BPay(logPrefix, channelId, httpParam, channelParam);
	}

	/**
	 * <p>B2B 支付</p>
	 * 
	 * @param logPrefix
	 * @param channelId
	 * @param httpParam
	 * @param channelParam
	 * @return
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-6-16 下午6:42:41
	 */
	private HttpReturnParam b2BPay(final String logPrefix, final String channelId, final HttpParam httpParam,
			Map<String, String> channelParam) throws BizException {
		String logMsg = "进入" + logPrefix + "支付业务处理。";
		Log4jUtil.info(logMsg);
		final AbcUtil abcUtil = new AbcUtil();
		channelParam = abcUtil.checkChannelParam(logPrefix, ClearingTransType.NET_DEDUCT_B2B, channelParam);
		// 1、取得支付请求所需要的信息
		/*	   MerchantTrnxNo      商户交易编号（必要信息） 
		   TrnxDate          交易日期（必要信息）    
		   TrnxTime               交易时间（必要信息） 
		   TrnxAmount        交易金额（必要信息）  
		   AccountDBNo       收款方账号（必要信息） 
		   AccountDBName      收款方账户名   
		   AccountDBBank      收款方账户开户行联行号   
		   TrnxInfo               交易信息对象（必要信息）  
		   ResultNotifyURL      交易结果接收页面网址（必要信息）  
		   MerchantRemarks      商户备注信息 */
		final String tMerchantTrnxNo = sequenceManagerService.getAbcChannelSN(DateUtil.getCurrentDate());
		String tTrnxDate = "";
		String tTrnxTime = "";
		String tAccountDBNo = "";// 收款方账号（必要信息）
		String tAccountDBName = "";// 收款方账户名
		// tAccountDBName = new String(tAccountDBName.getBytes("ISO-8859-1"), "gb2312");
		String tAccountDBBank = "";// 收款方账户开户行联行号
		String tResultNotifyURL = "";
		String tMerchantRemarks = "";
		BigDecimal tTrnxAmount = BigDecimal.ZERO;
		String sn = "";
		String corpAcctNo = "";			// 企业帐号 对应渠道绑定的帐号
		String corpAcctName = "";		// 企业户名 对应渠道绑定的帐号名
		String corpBankNo = "";			// 企业行号

		logMsg = "获取" + logPrefix + "充值对象。";
		Log4jUtil.info(logMsg);
		final NetDeductDTO onlineDeductChannelDTO = (NetDeductDTO) httpParam.getBizBean();
		if (onlineDeductChannelDTO == null) {
			throw new BizException(logPrefix + "获取到的支付对象为NULL。");
		}
		ObjectUtil.printPropertyString(logPrefix, onlineDeductChannelDTO);
		tTrnxAmount = onlineDeductChannelDTO.getAmount();
		tTrnxDate = new SimpleDateFormat("yyyy/MM/dd").format(onlineDeductChannelDTO.getCreatedTime());
		tTrnxTime = new SimpleDateFormat("HH:mm:ss").format(onlineDeductChannelDTO.getCreatedTime());
		sn = onlineDeductChannelDTO.getTxnId();
		tMerchantRemarks = onlineDeductChannelDTO.getOrderRemark();// 订单备注
		if (tMerchantRemarks == null) {
			tMerchantRemarks = sn;
		}

		// 1、生成交易信息对象 com.hitrust.b2b.trustpay.client.b2b.TrnxInfo
		final TrnxInfo tTrnxInfo = new TrnxInfo();
		// 生成交易备注信息对象 com.hitrust.b2b.trustpay.client.b2b.TrnxInfo.TrnxRemarks，并把TrnxRemarks对象加入到
		// TrnxInfo对象中（可选信息，如果不需要显示备注信息，只需要创建一个空的TrnxRemarks对象）
		final TrnxRemarks tTrnxRemarks = new TrnxRemarks();
		// tTrnxRemarks.addTrnxRemark(new TrnxRemark("合同号", "555000000"));
		// 生成交易明细对象 com.hitrust.b2b.trustpay.client.b2b.TrnxInfo.TrnxItems，并把 TrnxItems对象加入到
		// TrnxInfo对象中（可选信息，如果不需要显示交易明细信息，只需要创建一个空的TrnxItems对象）
		final TrnxItems tTrnxItems = new TrnxItems();
		// tTrnxItems.addTrnxItem(new TrnxItem("0001", "显示器", 1000.00f, 2));
		ObjectUtil.printPropertyString(logPrefix, tTrnxRemarks);
		ObjectUtil.printPropertyString(logPrefix, tTrnxItems);
		tTrnxInfo.setTrnxOpr("TrnxOperator0001"); // TrnxOpr
													// 交易人员（可选信息）（提供买方操作员在商户的交易网站上输入姓名或员工代码，便于买方在后续交易中知道此交易是由谁发起的）
		tTrnxInfo.setTrnxRemarks(tTrnxRemarks);
		tTrnxInfo.setTrnxItems(tTrnxItems);
		ObjectUtil.printPropertyString(logPrefix, tTrnxInfo);
		logMsg = logPrefix + "获取快付通收款账户信息。";
		Log4jUtil.info(logMsg); // 得到KFT账户资料
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		if (bankaccountBalance == null) {
			throw new BizException(logPrefix + "获取不到得到KFT在渠道为:" + channelId + " 交易类型为："
					+ ClearingTransType.NET_DEDUCT_B2B + "的账户资料。");
		}
		corpAcctNo = bankaccountBalance.getAccountNo();	// 企业帐号--对应渠道绑定的帐号
		corpAcctName = bankaccountBalance.getAccountName();// 企业帐号名--对应渠道绑定的帐号名
		corpBankNo = bankaccountBalance.getBankNo();	// 企业行号--对应渠道绑定帐号所属的行号
		tAccountDBNo = corpAcctNo;
		tAccountDBName = corpAcctName;
		tAccountDBBank = corpBankNo;
		// 3、生成直接支付请求对象
		logMsg = logPrefix + "生成支付请求对象FundTransferRequest。";
		Log4jUtil.info(logMsg);
		final FundTransferRequest tFundTransferRequest = new FundTransferRequest();
		tFundTransferRequest.setTrnxInfo(tTrnxInfo); // 设定交易细项 （必要信息）
		tFundTransferRequest.setMerchantTrnxNo(tMerchantTrnxNo); // 设定商户交易编号 （必要信息）
		tFundTransferRequest.setTrnxAmount(DecimalUtil.formatToDouble(tTrnxAmount)); // 设定交易金额
																						// （必要信息）
		tFundTransferRequest.setTrnxDate(tTrnxDate); // 设定交易日期 （必要信息）
		tFundTransferRequest.setTrnxTime(tTrnxTime); // 设定交易时间 （必要信息）
		tFundTransferRequest.setAccountDBNo(tAccountDBNo); // 设定收款方账号 （必要信息）
		tFundTransferRequest.setAccountDBName(tAccountDBName); // 设定收款方账户名 （必要信息）
		tFundTransferRequest.setAccountDBBank(tAccountDBBank); // 设定收款方账户开户行联行号（必要信息）

		Log4jUtil.info("收款账户：" + tAccountDBNo + "收款户名：" + tAccountDBName + "联行号：" + tAccountDBBank);
		tResultNotifyURL = channelParam.get("100001");
		tFundTransferRequest.setResultNotifyURL(tResultNotifyURL); // 设定交易结果回传网址（必要信息）
		tFundTransferRequest.setMerchantRemarks(tMerchantRemarks); // 设定商户备注信息

		// 4、传送直接支付请求并取得支付网址
		logMsg = logPrefix + "向银行发起支付请求。流水号为：" + sn + "订单号为：" + tMerchantTrnxNo;
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, tFundTransferRequest);
		final TrxResponse tTrxResponse = tFundTransferRequest.postRequest();
		ObjectUtil.printPropertyString(logPrefix, tTrxResponse);
		final HttpReturnParam hrp = new HttpReturnParam();
		if (tTrxResponse.isSuccess()) {
			// 5、直接支付请求提交成功,将客户端导向出示买方企业客户证书页面（下面注释的4行程序的参数值商户仍然可以取到）
			// out.println("TrnxType       = [" + tTrxResponse.getValue("TrnxType" ) + "]<br>");
			// out.println("TrnxAMT        = [" + tTrxResponse.getValue("TrnxAMT" ) + "]<br>");
			// out.println("MerchantID     = [" + tTrxResponse.getValue("MerchantID" ) + "]<br>");
			// out.println("MerchantTrnxNo = [" + tTrxResponse.getValue("MerchantTrnxNo") +
			// "]<br>");
			try {
				// httpParam.getResponse().sendRedirect(tTrxResponse.getValue("PaymentURL"));
				hrp.setAction(tTrxResponse.getValue("PaymentURL"));
			} catch (final Exception e) {
				Log4jUtil.info(logPrefix + e.getMessage());
				throw new BizException(logPrefix + e.getMessage());
			}
		} else {
			throw new BizException(logPrefix + "发送支付信息出错!ReturnCode:" + tTrxResponse.getReturnCode() + " ErrorMessage:"
					+ tTrxResponse.getErrorMessage());
		}
		// 写交易流水和渠道流水对照表,单笔查询不执行此操作
		billnoSnService.save(logPrefix, tMerchantTrnxNo, httpParam);

		return hrp;
	}

}
