package com.lycheepay.clearing.adapter.banks.abc.corp.bank.util;

import org.dom4j.DocumentHelper;
import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_CFRA33Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcSend2CT_Vc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;

@Service
public class ERP2CT_CFRA33 {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_SEND2CT_VC)
	private AbcSend2CT_Vc abcSend2CT_Vc;
	/**
	 * 创建农行CFRA33报文，并发送到CT
	 * 
	 * @author huangxu
	 * @param eRP2CT_PublicBean
	 * @param eRP2CT_CFRA33Bean
	 * @date 2015-08-23
	 * @return CQLA33应答报文
	 * @throws BizException
	 */
	public String sendXMLFile(final ERP2CT_PublicBean eRP2CT_PublicBean, final ERP2CT_CFRA33Bean eRP2CT_CFRA33Bean)
			throws BizException {
		// 使用DocumentHelper.createDocument方法建立一个文档实例
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 使用addElement方法方法创建根元素
		final Element apElement = document.addElement("ap");

		// 使用addElement方法向ap元素添加TransCode子元素
		final Element TransCode = apElement.addElement("TransCode");
		TransCode.setText(eRP2CT_PublicBean.getTransCode());

		// 使用addElement方法向ap元素添加ChannelType子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element ChannelType = apElement.addElement("ChannelType");
		ChannelType.setText("ERP");

		// 使用addElement方法向ap元素添加CorpNo子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element CorpNo = apElement.addElement("CorpNo");
		CorpNo.setText("");	//6681502043345318

		// 使用addElement方法向ap元素添加OpNo子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element OpNo = apElement.addElement("OpNo");
		OpNo.setText("");

		// 使用addElement方法向ap元素添加AuthNo子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element AuthNo = apElement.addElement("AuthNo");
		AuthNo.setText("");

		// 使用addElement方法向ap元素添加ReqSeqNo子元素
		final Element ReqSeqNo = apElement.addElement("ReqSeqNo");
		ReqSeqNo.setText(eRP2CT_PublicBean.getReqSeqNo());

		// 使用addElement方法向ap元素添加ReqDate子元素
		final Element ReqDate = apElement.addElement("ReqDate");
		ReqDate.setText("");

		// 使用addElement方法向ap元素添加ReqTime子元素
		final Element ReqTime = apElement.addElement("ReqTime");
		ReqTime.setText("");

		// 使用addElement方法向ap元素添加Sign子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element Sign = apElement.addElement("Sign");
		Sign.setText("");

		// 使用addElement方法向ap元素添加Version子元素
		final Element VersionElement = apElement.addElement("Version");
		final Element CcVersion = VersionElement.addElement("CcVersion");
		CcVersion.setText(eRP2CT_PublicBean.getCcVersion());

		// 使用addElement方法向ap元素添加Corp子元素
		final Element CorpElement = apElement.addElement("Corp");
		
		final Element PayComNo = CorpElement.addElement("PayComNo");
		PayComNo.setText(eRP2CT_PublicBean.getPayComNo());
		
		final Element PayComName = CorpElement.addElement("PayComName");
		PayComName.setText(eRP2CT_CFRA33Bean.getPayComName());
		
		final Element CorpType = CorpElement.addElement("CorpType");
		CorpType.setText(eRP2CT_CFRA33Bean.getCorpType());

		final Element SerialDate = CorpElement.addElement("SerialDate");
		SerialDate.setText(eRP2CT_CFRA33Bean.getSerialDate());
		
		// 使用addElement方法向ap元素添加Cmp子元素
		final Element CmpElement = apElement.addElement("Cmp");

		final Element BatchFileName = CmpElement.addElement("BatchFileName");
		BatchFileName.setText(eRP2CT_CFRA33Bean.getBatchFileName());

		// 使用addElement方法向ap元素添加Mode子元素
		final Element Mode = apElement.addElement("Mode");
		Mode.setText(eRP2CT_CFRA33Bean.getMode());
		
		// 使用addElement方法向ap元素添加FileLineNum子元素
		final Element FileLineNum = apElement.addElement("FileLineNum");
		FileLineNum.setText(String.valueOf(eRP2CT_CFRA33Bean.getFileLineNum()));
		
		// 使用addElement方法向ap元素添加FileTag子元素
		final Element FileTag = apElement.addElement("FileTag");

		final Element FileSplit = FileTag.addElement("FileSplit");
		FileSplit.setText(eRP2CT_CFRA33Bean.getFileSplit());
		
		// 使用addElement方法向ap元素添加FileFlag子元素
		final Element FileFlag = apElement.addElement("FileFlag");
		FileFlag.setText(eRP2CT_CFRA33Bean.getFileFlag());
		
		final String xmlInfo = document.asXML();
		final int begin = xmlInfo.indexOf("<ap>");
		final String CFRA33Info = xmlInfo.substring(begin, xmlInfo.length());

		Log4jUtil.info("CFRA33Info : " + CFRA33Info);
		String resultXml = abcSend2CT_Vc.launchBFJ(CFRA33Info);
		
		return resultXml;
	}
}
