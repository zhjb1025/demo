package com.lycheepay.clearing.adapter.banks.abc.credit.service;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;


/**
 * <P>农业银行信用卡渠道参数服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午3:24:56
 */
@Service(ClearingAdapterAnnotationName.ABC_CREDIT_CHANNEL_PARM_SERVICE)
public class AbcCreditChannelParmService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	/**
	 * <p>保存渠道参数信息</p>
	 * 
	 * @param newChannelParm
	 * @author 邱林 Leon.Qiu 2012-6-19 下午3:25:24
	 */
	public void saveChannelParm(final ChannelParm newChannelParm) {
		final Object o = channelParmService.queryByPrimaryKey(newChannelParm.getId());
		if (null == o) {
			channelParmService.save(newChannelParm);
		} else {
			final ChannelParm orgChannelParm = (ChannelParm) o;
			orgChannelParm.setParvalue(newChannelParm.getParvalue());
			channelParmService.update(orgChannelParm);
		}
	}
}
