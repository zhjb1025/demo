package com.lycheepay.clearing.adapter.banks.abc.cross.dto.base;

public final class AbcCrossBeanField {

	/**
	 * 字段名称
	 */
	private final String fieldName;
	/**
	 * 字段总长度
	 */
	private final int fieldLength;
	/**
	 * 对齐方向
	 */
	private boolean fieldPad2Right;
	/**
	 * 补齐字符
	 */
	private final char fieldPadding;

	public AbcCrossBeanField(String fieldName, int fieldLength, boolean fieldPad2Right, char fieldPadding) {
		super();
		this.fieldName = fieldName;
		this.fieldLength = fieldLength;
		this.fieldPad2Right = fieldPad2Right;
		this.fieldPadding = fieldPadding;
	}

	public boolean isFieldPad2Right() {
		return fieldPad2Right;
	}

	public void setFieldPad2Right(boolean fieldPad2Right) {
		this.fieldPad2Right = fieldPad2Right;
	}

	public String getFieldName() {
		return fieldName;
	}

	public int getFieldLength() {
		return fieldLength;
	}

	public char getFieldPadding() {
		return fieldPadding;
	}

}
