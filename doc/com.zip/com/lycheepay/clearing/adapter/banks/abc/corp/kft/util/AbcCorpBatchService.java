package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C410Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C410;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean.BatchBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean.SendResultBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行银企批量处理服务类(农行银企批量交易处理 —— 生成批量文件，上传文件到CT服务器，保存或更新数据到 billnoSn、Channel_Batch、Channel_Settle_Cmd
 * 表中, 根据返回结果更新表)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-25 下午5:25:57
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_BATCH_SERVICE)
public class AbcCorpBatchService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManager;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ERP2_CT_PUBLIC_SERVICE)
	private Erp2CTPublicService erp2CTPublicService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.PARSE_ABC_XML_SERVICE)
	private ParseAbcXmlService parseAbcXmlService;

	@Autowired
	private ERP2CT_C410 eRP2CT_C410;

	private static String channelId = ChannelIdEnum.ABC_CORP.getCode();
	// private static String abcSendFile;
	// private static String ftpServer;
	// private static String ftpPassword;;
	// private static String ftpUser;
	// private static String KftProv;
	// private static String KftCur;
	private static DecimalFormat df1 = new DecimalFormat("0.00");

	String line = System.getProperty("line.separator"); // 回车换行符
	String Log_Text; // 保存错误信息，用于保存日志

	/**
	 * 生成批量处理文件，FTP到服务器,保存记录到 billnoSn表并发送交易
	 * 
	 * @param paybillList
	 * @return 处理结果
	 * @throws ClearingAdapterBizCheckedException
	 */
	public BatchBean sendBatch(final List<ChannelTempBill> payList) throws ClearingAdapterBizCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String channelId = ChannelIdEnum.ABC_CORP.getCode();
		String KftProv = channelParms.get("100008");
		String KftCur = channelParms.get("100009");

		final BatchBean batchBean = new BatchBean();
		ReturnState returnState = new ReturnState(); // 返回结果的 bean
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_C410Bean eRP2CT_C410Bean = new ERP2CT_C410Bean();

		/*
		 * 批量交易 和 批量查询 的关联字段有(billnoSn表） 1、Channelid(channelId);//渠道ID
		 * 2、ChannelBatchno(totalReqSeqNo); // 银行订单号(同一批的批量业务相同）
		 * 3、OthercustId(OtherCust_Id);//对方客户编号 4、Otheracctno(OtherAcctNo);// 对方帐号
		 * 5、Otheracctname(OtherAcctName);// 对方户名
		 */

		// 生成农行银企流水(同时是(Channel_Batch表的Channel_BatchId；BILLNo_SN表的Channel_BatchNo）
		// String totalReqSeqNo = SequenceManager.getCorpAbcSN(DateUtil.getCurrentDate());//农行银企流水
		// 商户自定义序列号
		final String totalReqSeqNo = payList.get(0).getChannelBatchId();

		// 把银行流水和支付场次设置成同一个值（支付场次），如果一个场次要分为多个批次，则不用这种方式。
		String batchFileName = "";
		final String trantype = payList.get(0).getTransType();
		if (ClearingTransType.BATCH_DEDUCT.equals(trantype)) {// 代扣
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2CTPublicService.createErp2CTPublic("C410", totalReqSeqNo);
			// 组C410报文数据
			batchFileName = totalReqSeqNo + "_C410.txt"; // 批量文件名
		} else {
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2CTPublicService.createErp2CTPublic("C405", totalReqSeqNo);
			// 组C405报文数据
			batchFileName = totalReqSeqNo + "_C405.txt"; // 批量文件名

		}

		// 取得平台的账户信息
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		final String CorpAcctNo = bankaccountBalance.getAccountNo();
		final String CorpAcctName = bankaccountBalance.getAccountName();
		final String CorpBankNo = bankaccountBalance.getBankNo();

		// 生成批量处理文件，FTP到服务器,保存记录到 billnoSn表。
		SendResultBean sendResultBean = new SendResultBean();
		sendResultBean = createFtpSend(totalReqSeqNo, trantype, payList, batchFileName, CorpAcctNo, CorpAcctName,
				CorpBankNo); // 返回值为 "总记录数|总金额"

		if (sendResultBean.getTotalNum().equals("0") == false) { // 如果返回记录不为0
			// 生成批量文件，及得到总笔数；总金额
			// String totalNum =numAmt.substring(0, numAmt.indexOf("|")); //总笔数
			// String amt=numAmt.substring(numAmt.indexOf("|")+1, numAmt.length());//总金额
			// 获取快付通平台账户信息

			eRP2CT_C410Bean.setAmt(sendResultBean.getTotalAmt()); // 总金额
			eRP2CT_C410Bean.setFileFlag("1"); // 文件标志 #固定为1
			eRP2CT_C410Bean.setBookingDate(""); // 预约日期
			eRP2CT_C410Bean.setBookingTime(""); // 预约时间
			eRP2CT_C410Bean.setBookingFlag("0");// 预约标志 #固定为0-不预约
			eRP2CT_C410Bean.setPostscript("农业银行"); // 附言
			eRP2CT_C410Bean.setTotalNum(sendResultBean.getTotalNum());// 总笔数
			eRP2CT_C410Bean.setDbAccName(CorpAcctName); // 平台户名
			// CorpAcctNo = CorpAbcAccountProcess.proAccount(CorpAcctNo);// 把账号处理成农行的要求
			eRP2CT_C410Bean.setDbAccNo(CorpAcctNo); // 平台账号
			eRP2CT_C410Bean.setDbProv(KftProv); // 平台帐号省市代码
			eRP2CT_C410Bean.setDbCur(KftCur); // 平台货币码
			eRP2CT_C410Bean.setBatchFileName(batchFileName); // 批量文件名

			// 组数据成功后，发送 C410 报文,同时取得返回的 C410 报文resultXml

			String resultXml = eRP2CT_C410.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C410Bean);

			// 解释C410报文，写返回的bean ReturnState
			returnState = parseAbcXmlService.processRtnXml(resultXml);
			returnState.setRelTranAmount(new BigDecimal(sendResultBean.getTotalAmt())); // 业务金额总计

			// 发送业务后，更新:渠道流水对照表 billnoSn ;更新 channel_batch 表; 如果银行返回交易失败，则要调用基础平台处理
			// updateBatchSend(trantype,totalReqSeqNo,returnState);

		} else {  // 生成批理文件失败，返回失败结果
			returnState.setBankRetCode(TransReturnCode.code_9900);
			returnState.setCardType(BankCardType.CREDIT_CARD);
			returnState.setChannelCode(TransReturnCode.code_9900);
			returnState.setCheckDate(DateUtil.getDate(new Date()));
			returnState.setRelTranAmount(BigDecimal.ZERO);
			returnState.setReturnMsg("批量业务记录数为0条");
			returnState.setReturnState(PayState.FAILED_STR);
			returnState.setSn(totalReqSeqNo);
		}
		batchBean.setReturnState(returnState);
		batchBean.setTotalReqSeqNo(totalReqSeqNo);
		batchBean.setTrantype(trantype);
		return batchBean;
	}

	// ////////////////////////////////////////////////////////////////////

	/**
	 * 生成批量处理文件，FTP到服务器,保存记录到 billnoSn表。
	 * 
	 * @param totalReqSeqNo 农行银企流水;同时是(Channel_Batch表的Channel_BatchId；BILLNo_SN表的Channel_BatchNo）
	 * @param transtype 交易类型
	 * @param netNo 支付场次
	 * @param batchFileName 批量文件名
	 * @param CorpAcctNo 平台账号
	 * @param CorpAcctName 平台户名
	 * @param CorpBankNo 平台行号
	 * @return 返回值为 "总记录数|总金额"
	 * @throws BizException
	 */
	private SendResultBean createFtpSend(final String totalReqSeqNo, final String trantype,
			final List<ChannelTempBill> payList, final String batchFileName, final String CorpAcctNo,
			final String CorpAcctName, final String CorpBankNo) throws BizException {
		final SendResultBean sendResultBean = new SendResultBean();
		sendResultBean.setTotalNum(String.valueOf(payList.size()).trim()); // 返回总记录数

		// 1、 生成批量代收业务文件，保存记录到 billnoSn表，返回总金额
		sendResultBean.setTotalAmt(createBillnosnBatchFile(totalReqSeqNo, trantype, payList, batchFileName, CorpAcctNo,
				CorpAcctName, CorpBankNo));

		// 2、 FTP 文件到服务器
		uploadFile(batchFileName);

		return sendResultBean;
	}

	private void uploadFile(final String batchFileName) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String abcSendFile = channelParms.get("100032");
		String ftpServer = channelParms.get("100029");
		String ftpPassword = channelParms.get("100030");
		String ftpUser = channelParms.get("100031");
		final FtpManager ftpManager = new FtpManager();
		ftpManager.setServer(ftpServer);
		ftpManager.setPassword(ftpPassword);
		ftpManager.setUser(ftpUser);
		ftpManager.setFilename(batchFileName);
		// ftpManager.setLocalPath(abcSendFile + File.separator + batchFileName); // 本地文件（相对路径）
		ftpManager.setLocalPath(abcSendFile); // 本地文件夹（相对路径的目录）
		ftpManager.setPath(""); 	// 远程目录，不用设置，FTP 用户默认的目录就是要上传文件的目录
		try {
			ftpManager.putMyFile_actionPerformed();
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException("上传文件" + batchFileName + "出错！！");
		}

		Log4jUtil.info("农行银企报文:" + batchFileName + "已上传到服务器");

	}

	/**
	 * 生成批量代收业务文件，保存记录到 billnoSn表，返回总金额
	 * 
	 * @param abcReqSeqNo 请求方流水号(批量业务C405,C410 和 批量返回结果1972是用这个做关联的)
	 * @param trantype 平台业务类型
	 * @param objectlList 批量业务的 list
	 * @param CorpAcctNo,CorpAcctName,CorpBankNo KFT账户信息
	 * @param fileName 批量业务文件名
	 * @return String 批量业务的总金额
	 * @throws BizException
	 */
	private String createBillnosnBatchFile(final String totalReqSeqNo, final String trantype,
			final List<ChannelTempBill> payList, final String fileName, final String CorpAcctNo,
			final String CorpAcctName, final String CorpBankNo) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String abcSendFile = channelParms.get("100032");
		// 文件字段 4 个
		String otherCustId;// 客户编号 C20
		String otherBankCardNo;// 客户账号 C30
		String otherBankCardName;// 客户姓名 C32
		String channelAmount;// 交易金额 N18.2
		String note = "代发保费";// 摘要 C30 不赋值
		note = addSpaceForNum(note, 30); // 长度 30
		final StringBuffer sbStr = new StringBuffer("");
		BigDecimal dAmtTotal = BigDecimal.ZERO;
		// DecimalFormat df1 = new DecimalFormat("0.00");
		for (int i = 0; i < payList.size(); i++) {
			otherCustId = payList.get(i).getCustomerId();
			otherCustId = addSpaceForNum(otherCustId, 20);

			otherBankCardName = payList.get(i).getBankAccountHolder();
			otherBankCardName = addSpaceForNum(otherBankCardName, 32);

			otherBankCardNo = payList.get(i).getBankAccountNo();
			otherBankCardNo = AbcCorpAccountProcess.proAccount(otherBankCardNo);
			otherBankCardNo = addSpaceForNum(otherBankCardNo, 30);

			channelAmount = df1.format(payList.get(i).getAmount());
			channelAmount = addSpaceForNum(channelAmount, 18);

			dAmtTotal = dAmtTotal.add(payList.get(i).getAmount());

			sbStr.append(otherCustId).append(otherBankCardName).append(otherBankCardNo).append(channelAmount)
					.append(note).append(line);

		}
		saveBillnoSn(totalReqSeqNo, trantype, payList, CorpAcctNo, CorpAcctName, CorpBankNo);

		String fileStr = sbStr.toString();// 保存文件内容
		Log4jUtil.info("______批量业务的批量文件内容：____");
		Log4jUtil.info(fileStr);

		try {// CreateAccFile方法生成文件，返回文件名(含上级文件夹)，返回参数这里用不着
			createBatchFile(abcSendFile, fileName, fileStr); // 路径+文件名+文件内容
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException("生成批量代收文件 [" + fileName + "] 异常：" + e.getMessage());
		}
		return df1.format(dAmtTotal);
	}

	/**
	 * 生成文件
	 * 
	 * @param filePath 文件所在的文件夹
	 * @param fileName 文件名称
	 * @param fileValue文件内容
	 * @return 文件名（含相对路径文件夹）
	 * @throws BizException
	 */
	private String createBatchFile(final String filePath, final String fileName, final String fileValue)
			throws BizException {
		final String AccFile = filePath + File.separator + fileName; // 含相对路径的文件名
		try {
			FileUtils.writeStringToFile(new File(AccFile), fileValue, "GBK");
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException("生成文件出错！！" + e.getMessage());
		}
		return AccFile;
	}

	/**
	 * 保存批量交易到billno_sn表
	 * 
	 * @param totalReqSeqNo 渠道批次(批量业务C405,C410 和 批量返回结果1972是用这个做关联的) BILLNo_SN.Channel_BatchNo ;
	 *            Channel_Batch.Channel_BatchId
	 * @param tranType 业务类型
	 * @param object 交易对象
	 * @param i 批量明细序号
	 * @throws BizException
	 */
	private void saveBillnoSn(final String totalReqSeqNo, final String tranType, final List<ChannelTempBill> payList,
			final String CorpAcctNo, final String CorpAcctName, final String CorpBankNo) throws BizException {
		List<BillnoSn> billNoList = new ArrayList<BillnoSn>(payList.size());
		for (int i = 0; i < payList.size(); i++) {
			ChannelTempBill paybill = payList.get(i);
			final String Sn = paybill.getBizBillSn();	// 平台业务流水，billnoSn 主键
			final String OtherAcctNo = paybill.getBankAccountNo();	// 对方帐号
			final String OtherAcctName = paybill.getBankAccountHolder();	// 对方账户名
			final String OtherBankNo = paybill.getBankCode();	// 对方行号
			final String OtherCust_Id = paybill.getCustomerId();	// 对方客户编号
			final String OtherBankAddrNo = paybill.getBankAreaCode();// 对方开户行地区代码
			final String CreateTime = DateUtil.getDate(paybill.getCreateTime());	// 交易的平台交易日期
			final String Orderid = paybill.getBizTxnId();// 业务平台订单号
			final String bankType = paybill.getBankType();	// 行别
			final String SrcCust_Id = "";	// 发起方客户编号 业务发起者
			final String BatchID = paybill.getChannelBatchId();	// 批次号
			final String DetailID = "";	// 明细序号
			final String netNo = paybill.getTaskId();	// 支付场次

			// 写交易流水和渠道流水对照表
			final BillnoSn billnoSn = new BillnoSn();
			billnoSn.setBillnosnSeq(sequenceManager.getBillnoSnSeq());
			billnoSn.setSn(Sn);
			billnoSn.setChannelid(channelId);
			billnoSn.setBankSendSn(netNo); // 银行订单号，这里填场次号
			billnoSn.setTranDate(CreateTime);
			billnoSn.setChannelBatchno(totalReqSeqNo);// 渠道批次 批量交易使用
			billnoSn.setChannelDetail(String.format("%08d", (i + 1)));// 渠道明细 批量交易使用
			billnoSn.setAmount(paybill.getAmount()); // 平台交易金额
			billnoSn.setTranType(tranType);
			billnoSn.setState(BillnoSnState.billnoSend);	// 00：已发送 01: 已收到中心确认 02：业务回执已返回
			billnoSn.setBatchid(BatchID); // 批次号 对应于原交易
			billnoSn.setDetailid(DetailID);// 批量业务明细序号 对应于原交易
			billnoSn.setSendTime(new Date());
			billnoSn.setCorpacctno(CorpAcctNo); // 企业帐号 对应渠道绑定的帐号
			billnoSn.setCorpacctname(CorpAcctName);// 企业户名 对应渠道绑定的帐号名
			billnoSn.setCorpbankno(CorpBankNo);// 企业行号

			billnoSn.setOtheracctno(OtherAcctNo);// 对方帐号
			billnoSn.setOtheracctname(OtherAcctName);// 对方户名
			billnoSn.setOtherbankno(OtherBankNo);// 对方行号
			billnoSn.setOtherbankaddrno(OtherBankAddrNo);// 对方开户行地区代码
			billnoSn.setOthercustId(OtherCust_Id);// 对方客户编号

			billnoSn.setBankType(bankType);// 行别(非空）
			billnoSn.setSrccustId(SrcCust_Id);// 发起方客户编号
			billnoSn.setOrderid(Orderid);// 业务平台订单号
			billnoSn.setBankCardType(paybill.getCardType() != null ? paybill.getCardType().toString()
					: BankCardType.UNDISTINGUISH);
			billNoList.add(billnoSn);
		}
		try {
			billnoSnService.batchSave(billNoList);
		} catch (final Exception e) {
			Log4jUtil.error(e);
		}
	}

	/**
	 * 返回补过空格，变为定长字符串的串
	 * 
	 * @param str 原字符串
	 * @param strLength 补串后的长度
	 * @return 补过空格后的字符串
	 */
	private String addSpaceForNum(String xmlInfo, final int StrLength) {
		int strLen = xmlInfo.getBytes(Charset.forName("GBK")).length;
		if (strLen < StrLength) {
			final StringBuffer sb = new StringBuffer();
			while (strLen < StrLength) {
				sb.append(" ");// 加入空格
				strLen++;
			}
			// 从参数表中取出加密 tag
			xmlInfo = xmlInfo + sb.toString();
		}
		return xmlInfo; // 返回补过空格，变为定长字符串的串
	}

	/**
	 * 批量重发，生成的 C410、C405 批量报文，批量文件，并发送出去( C410、C405 两种交易很多东西可以通用)
	 * 
	 * @param channelBatchNo 渠道批次号;批量交易使用；同时也是原批量交易的【请求方流水号】
	 * @param trantype 业务类型
	 * @return 处理结果
	 * @throws ClearingAdapterBizCheckedException
	 */
	public ReturnState send_batch_ReSend(final String channelBatchNo, final String trantype)
			throws ClearingAdapterBizCheckedException {// FIXME
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String channelId = ChannelIdEnum.ABC_CORP.getCode();
		String abcSendFile = channelParms.get("100032");
		String KftProv = channelParms.get("100008");
		String KftCur = channelParms.get("100009");
		ReturnState returnState = new ReturnState(); // 返回结果的 bean

		final Erp2CTPublicService eRP2CT_Public = new Erp2CTPublicService();
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_C410Bean eRP2CT_C410Bean = new ERP2CT_C410Bean();

		String batchFileName = ""; // 批量文件名
		// 得到公共报头 bean 数据
		if (trantype.equals(ClearingTransType.REAL_TIME_DEDUCT)) {
			eRP2CT_PublicBean = eRP2CT_Public.createErp2CTPublic("C410", channelBatchNo);
			batchFileName = channelBatchNo + "_C410.txt"; // 批量文件名
			// 用 billnoSn 表组批量文件
		} else {
			eRP2CT_PublicBean = eRP2CT_Public.createErp2CTPublic("C405", channelBatchNo);
			batchFileName = channelBatchNo + "_C405.txt"; // 批量文件名
			// 用 billnoSn 表组批量文件
		}
		// 组C410报文数据
		// 取得平台的账户信息
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		final String CorpAcctNo = bankaccountBalance.getAccountNo();
		final String CorpAcctName = bankaccountBalance.getAccountName();

		// 生成批量文件，及得到总笔数；总金额
		// 把 billnoSn 的记录拿出来，然后组批量文件。
		// 、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、
		String otherCustId;// 客户编号 C20
		String otherBankCardNo;// 客户账号 C30
		String otherBankCardName;// 客户姓名 C32
		String channelAmount;// 交易金额 N18.2
		String note = "代发保费";// 摘要 C30 不赋值
		note = addSpaceForNum(note, 30); // 长度 30
		String fileStr;// 保存文件内容
		final StringBuffer sbStr = new StringBuffer("");
		BigDecimal dAmtTotal = BigDecimal.ZERO;
		final List<BillnoSn> billnoSnList = billnoSnService.findByChanneiIdAndchannelBatchIdAndTranType(channelId,
				channelBatchNo, trantype); // 总笔数
		for (int i = 0; i < billnoSnList.size(); i++) {
			otherCustId = billnoSnList.get(i).getOthercustId();
			otherCustId = addSpaceForNum(otherCustId, 20);

			otherBankCardName = billnoSnList.get(i).getOtheracctname();
			otherBankCardName = addSpaceForNum(otherBankCardName, 32);

			otherBankCardNo = billnoSnList.get(i).getOtheracctno();
			otherBankCardNo = AbcCorpAccountProcess.proAccount(otherBankCardNo);
			otherBankCardNo = addSpaceForNum(otherBankCardNo, 30);

			channelAmount = df1.format(billnoSnList.get(i).getAmount());
			channelAmount = addSpaceForNum(channelAmount, 18);

			dAmtTotal = dAmtTotal.add(billnoSnList.get(i).getAmount());

			sbStr.append(otherCustId).append(otherBankCardName).append(otherBankCardNo).append(channelAmount)
					.append(note).append(line);
		}
		fileStr = sbStr.toString();
		Log4jUtil.info("___________________批量重发业务的批量文件内容：___________________");
		Log4jUtil.info(fileStr);

		try {// CreateAccFile方法生成文件，返回文件名(含上级文件夹)，返回参数这里用不着
			createBatchFile(abcSendFile, batchFileName, fileStr); // 路径+文件名+文件内容
		} catch (final BizException e) {
			Log4jUtil.error(e);
			throw new BizException("生成批量代收文件 [" + batchFileName + "] 异常：" + e.getMessage());
		}

		// 、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、、

		final String totalNum = String.valueOf(billnoSnList.size()); // 总笔数
		if (totalNum.equals("0") == false) {
			final String amt = df1.format(dAmtTotal);	// 总金额
			eRP2CT_C410Bean.setAmt(amt); // 总金额 总金额待计算
			eRP2CT_C410Bean.setFileFlag("1"); // 文件标志 #固定为1
			eRP2CT_C410Bean.setBookingDate(""); // 预约日期
			eRP2CT_C410Bean.setBookingTime(""); // 预约时间
			eRP2CT_C410Bean.setBookingFlag("0");// 预约标志 #固定为0-不预约
			eRP2CT_C410Bean.setPostscript("农业银行"); // 附言
			eRP2CT_C410Bean.setTotalNum(totalNum);// 总笔数
			eRP2CT_C410Bean.setDbAccName(CorpAcctName); // 平台户名
			eRP2CT_C410Bean.setDbAccNo(CorpAcctNo); // 平台账号
			eRP2CT_C410Bean.setDbProv(KftProv); // 平台帐号省市代码
			eRP2CT_C410Bean.setDbCur(KftCur); // 平台货币码
			eRP2CT_C410Bean.setBatchFileName(batchFileName); // 批量文件名

			// 组数据成功后，发送 C410 报文,同时取得返回的 C410 报文resultXml
			final String resultXml = eRP2CT_C410.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C410Bean);

			// 解释C410报文，写返回的bean ReturnState
			returnState = parseAbcXmlService.processBatchRtnXml(resultXml);
			returnState.setRelTranAmount(new BigDecimal(amt)); // 业务金额总计

			// 发送业务后，更新:渠道流水对照表 billnoSn ;更新 channel_batch 表; 如果银行返回交易失败，则要调用基础平台处理
			// updateBatchSend(trantype, channelBatchNo, returnState);

			// 批量重发不更新指令表，因此，下面两句代码不执行。
			// String netNo = channelBatchDao.getNetNo(channelId, channelBatchNo);//通过渠道批次号查找批量业务场次号
			// updateChannelSettleCmd(netNo,trantype,"02"); // 更新指令表
		} else { // 批量业务记录数为0条，返回失败结果
			returnState.setBankRetCode(TransReturnCode.code_9900);
			returnState.setCardType(BankCardType.CREDIT_CARD);
			returnState.setChannelCode(TransReturnCode.code_9900);
			returnState.setCheckDate(DateUtil.getDate(new Date()));
			returnState.setRelTranAmount(BigDecimal.ZERO);
			returnState.setReturnMsg("批量业务记录数为0条");
			returnState.setReturnState(PayState.FAILED_STR);
			returnState.setSn(channelBatchNo);
		}
		return returnState;
	}
}
