package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.trade.FieldParser4Abc;
import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.trade.VarlenFieldParser4Abc;
import com.lycheepay.clearing.adapter.common.exception.RuntimeBizException;


/**
 * <P>构建农业银行发送报文域类型, 包括报文头等信息</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午3:30:01
 */
public final class MsgFieldType4Abc {
	private final String no;
	private final String name;

	// 最大长度,定长域适用,变长域只作为参考.
	private final int maxLength;

	// 内容的类型, BCD, BINARY或ASCII
	private final int contentType;
	private final FieldParser4Abc parser;

	public static final Map<String, MsgFieldType4Abc> ALL = new HashMap<String, MsgFieldType4Abc>();
	public static final MsgFieldType4Abc TPDU = new MsgFieldType4Abc("协议单元", "TPDU", 5, IsoType.BCD,
			new FieldParser4Abc());
	// public static final MsgFieldType4Abc HEAD = new MsgFieldType4Abc("报文头", "HEAD", 6,
	// IsoType.BCD, new FieldParser4Abc());
	public static final MsgFieldType4Abc MSG_TYPE = new MsgFieldType4Abc("消息类型", "MSGTYPE", 2, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc BITMAP = new MsgFieldType4Abc("位元表", "BITMAP", 8, IsoType.BINARY,
			new FieldParser4Abc());

	public static final MsgFieldType4Abc FIELD_2 = new MsgFieldType4Abc("2域", "2", 19, IsoType.BCD,
			new VarlenFieldParser4Abc(1));
	public static final MsgFieldType4Abc FIELD_3 = new MsgFieldType4Abc("3域", "3", 3, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_4 = new MsgFieldType4Abc("4域", "4", 6, IsoType.BCD,
			new FieldParser4Abc());

	public static final MsgFieldType4Abc FIELD_11 = new MsgFieldType4Abc("11域", "11", 3, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_12 = new MsgFieldType4Abc("12域", "12", 3, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_13 = new MsgFieldType4Abc("13域", "13", 2, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_14 = new MsgFieldType4Abc("14域", "14", 2, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_15 = new MsgFieldType4Abc("15域", "15", 2, IsoType.BCD,
			new FieldParser4Abc());

	public static final MsgFieldType4Abc FIELD_22 = new MsgFieldType4Abc("22域", "22", 2, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_23 = new MsgFieldType4Abc("23域", "23", 2, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_24 = new MsgFieldType4Abc("24域", "24", 2, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_25 = new MsgFieldType4Abc("25域", "25", 1, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_26 = new MsgFieldType4Abc("26域", "26", 1, IsoType.BCD,
			new FieldParser4Abc());

	public static final MsgFieldType4Abc FIELD_32 = new MsgFieldType4Abc("32域", "32", 7, IsoType.BCD,
			new VarlenFieldParser4Abc(1));
	public static final MsgFieldType4Abc FIELD_35 = new MsgFieldType4Abc("35域", "35", 37, IsoType.BCD,
			new VarlenFieldParser4Abc(1));
	public static final MsgFieldType4Abc FIELD_36 = new MsgFieldType4Abc("36域", "36", 104, IsoType.BCD,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_37 = new MsgFieldType4Abc("37域", "37", 12, IsoType.ASCII,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_38 = new MsgFieldType4Abc("38域", "38", 6, IsoType.ASCII,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_39 = new MsgFieldType4Abc("39域", "39", 2, IsoType.ASCII,
			new FieldParser4Abc());

	public static final MsgFieldType4Abc FIELD_41 = new MsgFieldType4Abc("41域", "41", 8, IsoType.ASCII,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_42 = new MsgFieldType4Abc("42域", "42", 15, IsoType.ASCII,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_44 = new MsgFieldType4Abc("44域", "44", 26, IsoType.ASCII,
			new VarlenFieldParser4Abc(1));
	public static final MsgFieldType4Abc FIELD_48 = new MsgFieldType4Abc("48域", "48", 6, IsoType.ASCII,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_49 = new MsgFieldType4Abc("49域", "49", 3, IsoType.ASCII,
			new FieldParser4Abc());

	public static final MsgFieldType4Abc FIELD_52 = new MsgFieldType4Abc("52域", "52", 8, IsoType.BINARY,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_53 = new MsgFieldType4Abc("53域", "53", 8, IsoType.BCD,
			new FieldParser4Abc());
	public static final MsgFieldType4Abc FIELD_55 = new MsgFieldType4Abc("55域", "55", 255, IsoType.ASCII,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_57 = new MsgFieldType4Abc("57域", "57", 220, IsoType.ASCII,
			new VarlenFieldParser4Abc(2));

	public static final MsgFieldType4Abc FIELD_60 = new MsgFieldType4Abc("60域", "60", 999, IsoType.HEX,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_61 = new MsgFieldType4Abc("61域", "61", 48, IsoType.HEX,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_62 = new MsgFieldType4Abc("62域", "62", 12, IsoType.ASCII,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_63 = new MsgFieldType4Abc("63域", "63", 999, IsoType.HEX,
			new VarlenFieldParser4Abc(2));
	public static final MsgFieldType4Abc FIELD_64 = new MsgFieldType4Abc("64域", "64", 8, IsoType.BINARY,
			new FieldParser4Abc());

	private MsgFieldType4Abc(final String name, final String no, final int maxLength, final int contentType,
			final FieldParser4Abc parser) {
		this.name = name;
		this.no = no;
		this.maxLength = maxLength;
		this.contentType = contentType;
		this.parser = parser;
		parser.setFieldType(this);

		ALL.put(no, this);
	}

	public int getMaxLength() {
		return maxLength;
	}

	public FieldParser4Abc getParser() {
		return parser;
	}

	public int getContentType() {
		return contentType;
	}

	public String getName() {
		return name;
	}

	public String getNo() {
		return no;
	}

	public static MsgFieldType4Abc valueOf(final String value) {
		final MsgFieldType4Abc type = ALL.get(value);

		if (type == null) {
			throw new RuntimeBizException("无消息域:" + value);
		}
		return type;
	}

	/**
	 * 获取当前域在位图中的索引, 从0开始.
	 */
	public int getBitmapIndex() {
		return StringUtils.isNumeric(no) ? Integer.parseInt(no) - 1 : -1;
	}
}
