package com.lycheepay.clearing.adapter.banks.abc.corp.bank.util;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcSend2CT_Vc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;


@Service
public class ERP2CT_C503 {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_SEND2CT_VC)
	private AbcSend2CT_Vc abcSend2CT_Vc;
	/**
	 * 创建农行C503报文，并发送到CT
	 * 
	 * @author aps-kxj
	 * @param eRP2CT_PublicBean
	 * @param eRP2CT_C503Bean
	 * @date 2011-03-19
	 * @return C503应答报文
	 * @throws BizException
	 */
	public String sendXMLFile(final ERP2CT_PublicBean eRP2CT_PublicBean, final ERP2CT_C503Bean eRP2CT_C503Bean)
			throws BizException {
		// 使用DocumentHelper.createDocument方法建立一个文档实例
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 使用addElement方法方法创建根元素
		final Element apElement = document.addElement("ap");

		// 使用addElement方法向ap元素添加TransCode子元素
		final Element TransCode = apElement.addElement("TransCode");
		TransCode.setText(eRP2CT_PublicBean.getTransCode());

		// 使用addElement方法向ap元素添加ChannelType子元素
		final Element ChannelType = apElement.addElement("ChannelType");
		ChannelType.setText(eRP2CT_PublicBean.getChannelType());

		// 使用addElement方法向ap元素添加CorpNo子元素
		final Element CorpNo = apElement.addElement("CorpNo");
		CorpNo.setText(eRP2CT_PublicBean.getCorpNo());

		// 使用addElement方法向ap元素添加OpNo子元素
		final Element OpNo = apElement.addElement("OpNo");
		OpNo.setText(eRP2CT_PublicBean.getOpNo());

		// 使用addElement方法向ap元素添加AuthNo子元素
		final Element AuthNo = apElement.addElement("AuthNo");
		AuthNo.setText(eRP2CT_PublicBean.getAuthNo());

		// 使用addElement方法向ap元素添加__子元素
		final Element ReqSeqNo = apElement.addElement("ReqSeqNo");
		ReqSeqNo.setText(eRP2CT_PublicBean.getReqSeqNo());

		// 使用addElement方法向ap元素添加__子元素
		final Element ReqDate = apElement.addElement("ReqDate");
		ReqDate.setText(eRP2CT_PublicBean.getReqDate());

		// 使用addElement方法向ap元素添加ReqTime子元素
		final Element ReqTime = apElement.addElement("ReqTime");
		ReqTime.setText(eRP2CT_PublicBean.getReqTime());

		// 使用addElement方法向ap元素添加Sign子元素
		final Element Sign = apElement.addElement("Sign");
		Sign.setText(eRP2CT_PublicBean.getSign());

		// 使用addElement方法向ap元素添加Version子元素
		final Element VersionElement = apElement.addElement("Version");
		final Element CcVersion = VersionElement.addElement("CcVersion");
		CcVersion.setText(eRP2CT_PublicBean.getCcVersion());

		// 使用addElement方法向ap元素添加Channel子元素
		final Element ChannelElement = apElement.addElement("Channel");

		final Element LastJrnNo = ChannelElement.addElement("LastJrnNo");
		LastJrnNo.setText(eRP2CT_C503Bean.getLastJrnNo());

		// 使用addElement方法向ap元素添加Cmp子元素
		final Element CmpElement = apElement.addElement("Cmp");

		final Element DbAccNo = CmpElement.addElement("DbAccNo");
		DbAccNo.setText(eRP2CT_C503Bean.getDbAccNo());

		final Element DbProv = CmpElement.addElement("DbProv");
		DbProv.setText(eRP2CT_C503Bean.getDbProv());

		final Element DbCur = CmpElement.addElement("DbCur");
		DbCur.setText(eRP2CT_C503Bean.getDbCur());

		final Element StartTime = CmpElement.addElement("StartTime");
		StartTime.setText(eRP2CT_C503Bean.getStartTime());

		// 使用addElement方法向ap元素添加Corp子元素
		final Element CorpElement = apElement.addElement("Corp");

		final Element StartDate = CorpElement.addElement("StartDate");
		StartDate.setText(eRP2CT_C503Bean.getStartDate());

		final Element EndDate = CorpElement.addElement("EndDate");
		EndDate.setText(eRP2CT_C503Bean.getEndDate());

		final String xmlInfo = document.asXML();
		final int begin = xmlInfo.indexOf("<ap>");
		final String C503Info = xmlInfo.substring(begin, xmlInfo.length());

		Log4jUtil.info("C503Info : " + C503Info);
		String resultXml = abcSend2CT_Vc.launch(C503Info);
		/*
		二、使用Dom4j
		1.Xml字符串--->Xml Document【org.dom4j.Document】
		     String xmlStr = "";
		     Documenet doc = DocumentHelper.parseText(xmlStr);
		2.Xml Document--->Xml字符串
		     String xmlStr = document.asXml();
		*/

		// 生成文件
		/*     XMLWriter output;
		     //输出格式化
		     OutputFormat format = OutputFormat.createPrettyPrint();
		     format.setEncoding("GBK");
		     try {
		         output = new XMLWriter(new FileWriter("d:/ERP2CT_C503.XML"), format);
		         output.write(document);
		         output.close();
		     } catch (IOException e) {
		         Log4jUtil.error( e);
		     }*/
		return resultXml;
	}
}
