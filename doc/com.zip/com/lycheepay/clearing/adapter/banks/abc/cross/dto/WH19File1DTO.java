package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH19File1DTO extends AbcCrossBeanBase {

	public WH19File1DTO() {
		super.addField(new AbcCrossBeanField("businessSource", 0, true, ' '));
		super.addField(new AbcCrossBeanField("businessRefNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("paymentType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("ourCertificateType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("certificateNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("ourCustomerName", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranOpponentType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranOpponentName", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranCurrency", 0, true, ' '));
		super.addField(new AbcCrossBeanField("amount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("ourCusPayCardNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("ourCusPayCardAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("exchangeRate", 0, true, ' '));
		super.addField(new AbcCrossBeanField("exchangeAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("ourCusRMBCardNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("otherAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("otherCardNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("payeeCardNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("settlementType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("paygetPurpose", 0, true, ' '));
		super.addField(new AbcCrossBeanField("paymentSource", 0, true, ' '));
		super.addField(new AbcCrossBeanField("isSpecialArea", 0, true, ' '));
		super.addField(new AbcCrossBeanField("actualCurrency", 0, true, ' '));
		super.addField(new AbcCrossBeanField("actualAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("dometicCurrency", 0, true, ' '));
		super.addField(new AbcCrossBeanField("dometicAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("abroadCurrency", 0, true, ' '));
		super.addField(new AbcCrossBeanField("abroadAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("creditNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("creditCDate", 0, true, ' '));
		super.addField(new AbcCrossBeanField("term", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tradeTime", 0, true, ' '));
		super.addField(new AbcCrossBeanField("declareType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("declareBankNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("operationType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("extendNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("bankAddress", 0, true, ' '));
		super.addField(new AbcCrossBeanField("applyDepartment", 0, true, ' '));
	}

	public String getBusinessSource() {
		return data.get("businessSource");
	}

	public void setBusinessSource(String businessSource) {
		data.put("businessSource", businessSource);
	}

	public String getBusinessRefNo() {
		return data.get("businessRefNo");
	}

	public void setBusinessRefNo(String businessRefNo) {
		data.put("businessRefNo", businessRefNo);
	}

	public String getPaymentType() {
		return data.get("paymentType");
	}

	public void setPaymentType(String paymentType) {
		data.put("paymentType", paymentType);
	}

	public String getOurCertificateType() {
		return data.get("ourCertificateType");
	}

	public void setOurCertificateType(String ourCertificateType) {
		data.put("ourCertificateType", ourCertificateType);
	}

	public String getCertificateNo() {
		return data.get("certificateNo");
	}

	public void setCertificateNo(String certificateNo) {
		data.put("certificateNo", certificateNo);
	}

	public String getOurCustomerName() {
		return data.get("ourCustomerName");
	}

	public void setOurCustomerName(String ourCustomerName) {
		data.put("ourCustomerName", ourCustomerName);
	}

	public String getTranOpponentType() {
		return data.get("tranOpponentType");
	}

	public void setTranOpponentType(String tranOpponentType) {
		data.put("tranOpponentType", tranOpponentType);
	}

	public String getTranOpponentName() {
		return data.get("tranOpponentName");
	}

	public void setTranOpponentName(String tranOpponentName) {
		data.put("tranOpponentName", tranOpponentName);
	}

	public String getTranCurrency() {
		return data.get("tranCurrency");
	}

	public void setTranCurrency(String tranCurrency) {
		data.put("tranCurrency", tranCurrency);
	}

	public String getAmount() {
		return data.get("amount");
	}

	public void setAmount(String amount) {
		data.put("amount", amount);
	}

	public String getOurCusPayCardNo() {
		return data.get("ourCusPayCardNo");
	}

	public void setOurCusPayCardNo(String ourCusPayCardNo) {
		data.put("ourCusPayCardNo", ourCusPayCardNo);
	}

	public String getOurCusPayCardAmount() {
		return data.get("ourCusPayCardAmount");
	}

	public void setOurCusPayCardAmount(String ourCusPayCardAmount) {
		data.put("ourCusPayCardAmount", ourCusPayCardAmount);
	}

	public String getExchangeRate() {
		return data.get("exchangeRate");
	}

	public void setExchangeRate(String exchangeRate) {
		data.put("exchangeRate", exchangeRate);
	}

	public String getExchangeAmount() {
		return data.get("exchangeAmount");
	}

	public void setExchangeAmount(String exchangeAmount) {
		data.put("exchangeAmount", exchangeAmount);
	}

	public String getOurCusRMBCardNo() {
		return data.get("ourCusRMBCardNo");
	}

	public void setOurCusRMBCardNo(String ourCusRMBCardNo) {
		data.put("ourCusRMBCardNo", ourCusRMBCardNo);
	}

	public String getOtherAmount() {
		return data.get("otherAmount");
	}

	public void setOtherAmount(String otherAmount) {
		data.put("otherAmount", otherAmount);
	}

	public String getOtherCardNo() {
		return data.get("otherCardNo");
	}

	public void setOtherCardNo(String otherCardNo) {
		data.put("otherCardNo", otherCardNo);
	}

	public String getPayeeCardNo() {
		return data.get("payeeCardNo");
	}

	public void setPayeeCardNo(String payeeCardNo) {
		data.put("payeeCardNo", payeeCardNo);
	}

	public String getSettlementType() {
		return data.get("settlementType");
	}

	public void setSettlementType(String settlementType) {
		data.put("settlementType", settlementType);
	}

	public String getPaygetPurpose() {
		return data.get("paygetPurpose");
	}

	public void setPaygetPurpose(String paygetPurpose) {
		data.put("paygetPurpose", paygetPurpose);
	}

	public String getPaymentSource() {
		return data.get("paymentSource");
	}

	public void setPaymentSource(String paymentSource) {
		data.put("paymentSource", paymentSource);
	}

	public String getIsSpecialArea() {
		return data.get("isSpecialArea");
	}

	public void setIsSpecialArea(String isSpecialArea) {
		data.put("isSpecialArea", isSpecialArea);
	}

	public String getActualCurrency() {
		return data.get("actualCurrency");
	}

	public void setActualCurrency(String actualCurrency) {
		data.put("actualCurrency", actualCurrency);
	}

	public String getActualAmount() {
		return data.get("actualAmount");
	}

	public void setActualAmount(String actualAmount) {
		data.put("actualAmount", actualAmount);
	}

	public String getDometicCurrency() {
		return data.get("dometicCurrency");
	}

	public void setDometicCurrency(String dometicCurrency) {
		data.put("dometicCurrency", dometicCurrency);
	}

	public String getDometicAmount() {
		return data.get("dometicAmount");
	}

	public void setDometicAmount(String dometicAmount) {
		data.put("dometicAmount", dometicAmount);
	}

	public String getAbroadCurrency() {
		return data.get("abroadCurrency");
	}

	public void setAbroadCurrency(String abroadCurrency) {
		data.put("abroadCurrency", abroadCurrency);
	}

	public String getAbroadAmount() {
		return data.get("abroadAmount");
	}

	public void setAbroadAmount(String abroadAmount) {
		data.put("abroadAmount", abroadAmount);
	}

	public String getCreditNo() {
		return data.get("creditNo");
	}

	public void setCreditNo(String creditNo) {
		data.put("creditNo", creditNo);
	}

	public String getCreditCDate() {
		return data.get("creditCDate");
	}

	public void setCreditCDate(String creditCDate) {
		data.put("creditCDate", creditCDate);
	}

	public String getTerm() {
		return data.get("term");
	}

	public void setTerm(String term) {
		data.put("term", term);
	}

	public String getTradeTime() {
		return data.get("tradeTime");
	}

	public void setTradeTime(String tradeTime) {
		data.put("tradeTime", tradeTime);
	}

	public String getDeclareType() {
		return data.get("declareType");
	}

	public void setDeclareType(String declareType) {
		data.put("declareType", declareType);
	}

	public String getDeclareBankNo() {
		return data.get("declareBankNo");
	}

	public void setDeclareBankNo(String declareBankNo) {
		data.put("declareBankNo", declareBankNo);
	}

	public String getOperationType() {
		return data.get("operationType");
	}

	public void setOperationType(String operationType) {
		data.put("operationType", operationType);
	}

	public String getExtendNo() {
		return data.get("extendNo");
	}

	public void setExtendNo(String extendNo) {
		data.put("extendNo", extendNo);
	}

	public String getBankAddress() {
		return data.get("bankAddress");
	}

	public void setBankAddress(String bankAddress) {
		data.put("bankAddress", bankAddress);
	}

	public String getApplyDepartment() {
		return data.get("applyDepartment");
	}

	public void setApplyDepartment(String applyDepartment) {
		data.put("applyDepartment", applyDepartment);
	}
}
