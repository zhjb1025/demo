package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_1972Bean {

	// ERP2CT_1972 查询工资处理结果（1972） 请求报文字段
	private String CustomNo; // #原代发工资交易的请求号

	public String getCustomNo() {
		return CustomNo;
	}

	public void setCustomNo(final String customNo) {
		CustomNo = customNo;
	}

}
