package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;

public class Md5 {
	private static final Logger logger = Logger.getLogger(Md5.class);
	public String str;
	public static final String ENCODE = "GBK"; // UTF-8 快捷系统 编码格式是 GBK；

	public String md5s(String plainText) throws BizException {

		try {
			plainText = new String(plainText.getBytes("GBK"), ENCODE);
		} catch (UnsupportedEncodingException e1) {
			logger.error("把要加密的字符串转为["+ENCODE+"]码出错！");
			e1.printStackTrace();
			throw new BizException("把要加密的字符串转为GBK码出错！");
		}

		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.update(plainText.getBytes(Charset.forName("GBK")));
			byte b[] = md.digest();

			int i;

			StringBuffer buf = new StringBuffer("");
			for (int offset = 0; offset < b.length; offset++) {
				i = b[offset];
				if (i < 0)
					i += 256;
				if (i < 16)
					buf.append("0");
				buf.append(Integer.toHexString(i));
			}
			str = buf.toString();
		} catch (NoSuchAlgorithmException e) {
			Log4jUtil.error(e);
		}
		return str;
	}

	public static void main(String agrs[]) {
		Md5 md51 = new Md5();
		try {
			md51.md5s("214213213213213");
		} catch (BizException e) {
			Log4jUtil.error(e);
		}// 计算 MD5 码
	}

}