package com.lycheepay.clearing.adapter.banks.abc.cross.thread;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.lycheepay.clearing.adapter.banks.abc.cross.service.process.AbcCrossProcessService;
import com.lycheepay.clearing.util.Log4jUtil;


public abstract class AbcCrossWorker {

	protected final AbcCrossProcessService abcCrossProcessService;

	protected final JmsTemplate mqSender;

	protected AbcCrossWorker(AbcCrossProcessService abcCrossProcessService, JmsTemplate mqSender) {
		this.abcCrossProcessService = abcCrossProcessService;
		this.mqSender = mqSender;
	}

	protected void sendMQ(final String msg) {
		Log4jUtil.info("==start发送消息==内容：{}", msg);
		try {
			mqSender.send(new MessageCreator() {
				@Override
				public Message createMessage(Session session) throws JMSException {
					TextMessage message = session.createTextMessage(msg);
					return message;
				}
			});
		} catch (JmsException e) {
			Log4jUtil.error(e);
			Log4jUtil.info("==发送消息失败==内容：{}", msg);
		}
		Log4jUtil.info("==end发送消息==");
	}

}
