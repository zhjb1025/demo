package com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean;

import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;


public class BatchBean {
	// updateBatchSend(trantype,totalReqSeqNo,returnState);
	private String trantype;
	private String totalReqSeqNo;
	private ReturnState returnState;

	public String getTrantype() {
		return trantype;
	}

	public void setTrantype(final String trantype) {
		this.trantype = trantype;
	}

	public String getTotalReqSeqNo() {
		return totalReqSeqNo;
	}

	public void setTotalReqSeqNo(final String totalReqSeqNo) {
		this.totalReqSeqNo = totalReqSeqNo;
	}

	public ReturnState getReturnState() {
		return returnState;
	}

	public void setReturnState(final ReturnState returnState) {
		this.returnState = returnState;
	}

}
