package com.lycheepay.clearing.adapter.banks.abc.cross.service.process;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH14RequestDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH14ResponseDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH16RequestDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH16ResponseDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH19RequestDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH19ResponseDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.file.AbcCrossFileConvertor;
import com.lycheepay.clearing.adapter.banks.abc.cross.service.bank.AbcCrossBankService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.service.biz.SwiftCodeService;
import com.lycheepay.clearing.adapter.common.util.SftpUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.PayForeignExchangeDTO;
import com.lycheepay.clearing.common.dto.trade.UploadInfoDTO;
import com.lycheepay.clearing.common.model.BankTypeInfoWithSwiftCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;

@Service
public class AbcCrossProcessService {
	
	@Autowired
	private AbcCrossBankService abcCrossBankService;
	
	@Autowired
	private	SwiftCodeService swiftCodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager seqService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;
	
	public final String channelId = ChannelIdEnum.ABC_CROSS_PAY.getCode();

	public ClearingResultDTO transWH16(String bankSN) {
		Log4jUtil.info("[WH16:入参]{}", bankSN);

		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		ClearingResultDTO resultDTO = new ClearingResultDTO();

		try {

			WH16RequestDTO req = new WH16RequestDTO();
			req.setMerID(params.get(AbcCrossConstant.PARM_USR_MER_ID));
			req.setProcCode(AbcCrossConstant.PROC_CODE);
			req.setSeqNo(bankSN);
			req.setTermID(params.get(AbcCrossConstant.PARM_USR_TERM_ID));
			req.setTransCode(AbcCrossConstant.TRAN_CODE_WH16);
			req.setTransType(params.get(AbcCrossConstant.PARM_VAR_TRANTYPE));

			Log4jUtil.info("[WH16:req]{}", req.toString());

			WH16ResponseDTO resp = new WH16ResponseDTO();
			resp = abcCrossBankService.transfer(req, resp);

			Log4jUtil.info("[WH16:resp]{}", resp.toString());

			resultDTO.setChannelId(channelId);
			resultDTO.setChannelResponseCode(resp.getRespCode());
			resultDTO.setChannelResponseMsg(resp.getRespMsg().trim() + "[Status]" + resp.getStatus());

			if(PayState.SUCCEED_CODE.equals(resp.getRespCode())){
				if ("0".equals(resp.getStatus())) {
					resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				} else if ("579E".contains(resp.getStatus())) {
					resultDTO.setTxnStatus(PayState.FAILED_STR);
				} else {
					resultDTO.setTxnStatus(PayState.UNKNOW_STR);
				}
			}else{
				resultDTO.setTxnStatus(PayState.FAILED_STR);
			}

			if (resultDTO.getTxnStatus() != 3) {//非未知状态时记录不作修改
				BillnoSn updateBillnoSn = new BillnoSn();
				updateBillnoSn.setBillnosnSeq(bankSN);
				updateBillnoSn.setRecvTime(new Date());
				updateBillnoSn.setState(BillnoSnState.billnoRecv);
				updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
				updateBillnoSn.setChannelRtncode(resp.getRespCode());
				updateBillnoSn.setChannelRtnnote(resp.getRespMsg());
				billnoSnService.update(updateBillnoSn);
				Log4jUtil.info("[WH16:DB]{}", updateBillnoSn);
			}
		} catch (Exception ex) {
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg(ex.getMessage());
			Log4jUtil.error(ex);
		}
		Log4jUtil.info("[WH16:Return]{}", resultDTO.toString());
		return resultDTO;
	}

	public ClearingResultDTO transWH19(PayForeignExchangeDTO request) {
		Log4jUtil.info("[WH19:入参]{}", request.toString());

		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		WH19RequestDTO req = new WH19RequestDTO();
		
		BillnoSn record = null;

		try {
			String seq = seqService.getAbcCrossSN();
			Log4jUtil.info("[WH19:seq]{}", seq);

			req.setTransCode(AbcCrossConstant.TRAN_CODE_WH19);
			req.setProcCode(AbcCrossConstant.PROC_CODE);
			req.setTermID(params.get(AbcCrossConstant.PARM_USR_TERM_ID));
			req.setMerID(params.get(AbcCrossConstant.PARM_USR_MER_ID));
			req.setSeqNo(createSeqNo(params.get(AbcCrossConstant.PARM_USR_MER_ID), seq));
			req.setPayType(params.get(AbcCrossConstant.PARM_VAR_PAYTYPE));
			req.setBizType(params.get(AbcCrossConstant.PARM_VAR_BIZTYPE));
			req.setCurrency(request.getCurrency());
			req.setAmount(request.getAmount().toString());
			req.setApplyNo("");
			req.setRemitDest(params.get(AbcCrossConstant.PARM_VAR_REMITDEST));
			req.setRemitPurpose(params.get(AbcCrossConstant.PARM_VAR_REMITPURPOSE));
			req.setRecvBankNo(convertBankNo2Swift(params.get(AbcCrossConstant.PARM_VAR_RECVBANKNO)));//暂时固定
			req.setRecvDPBankNo(convertBankNo2Swift(params.get(AbcCrossConstant.PARM_VAR_RECVDPBANKNO)));//暂时固定
			req.setRecvIPBankNo("");//目前为空
			req.setAgencyBankNo1("");//目前为空
			req.setAgencyBankNo2("");//目前为空
			req.setPayeeType(params.get(AbcCrossConstant.PARM_VAR_PAYEETYPE));
			req.setPayeeAccount(request.getPayeeAccount());
			req.setPayeeName(request.getPayeeName() + "|" + request.getPayeeAddress());
			req.setAccountABD(params.get(AbcCrossConstant.PARM_VAR_ACCOUNTABD));
			req.setPayeeBankType(convertBankNo2Swift(request.getPayeeBankType()));
			req.setFeePayer(params.get(AbcCrossConstant.PARM_VAR_FEEPAYER));
			req.setSignIO(params.get(AbcCrossConstant.PARM_VAR_SIGNIO));
			req.setBizSort(params.get(AbcCrossConstant.PARM_VAR_BIZSORT));
			req.setPayeeCountry(request.getPayeeCountry());
			req.setRemark(request.getRemark());
			req.setRemarkNote("");
			req.setFileCount(String.valueOf(request.getFileItemCount()));
			req.setMerName(request.getMerchantName());
			
			record = billnoSnService.saveBillnoSn(req.getSeqNo(), channelId, request);
			Log4jUtil.info("[WH19:DB]seq:{}", req.getSeqNo());
			
			//设置字段默认值进行转换处理
			HashMap<String, String> def = new HashMap<String, String>();
			def.put("otherCardNo", params.get(AbcCrossConstant.PARM_VAR_ACCOUNTNO));

			AbcCrossFileConvertor convertor = new AbcCrossFileConvertor(req.getSeqNo(), seq, request.getFileName().get("file1"), params.get(AbcCrossConstant.PARM_USR_FTP_LOCAL_PATH), def);
			String uploadFile1Name = convertor.convertWH19File1();
			Log4jUtil.info("[WH19:file1]{}", uploadFile1Name);

			convertor = new AbcCrossFileConvertor(req.getSeqNo(), seq, request.getFileName().get("file2"), params.get(AbcCrossConstant.PARM_USR_FTP_LOCAL_PATH));
			String uploadFile2Name = convertor.convertWH19File2();
			Log4jUtil.info("[WH19:file2]{}", uploadFile2Name);

			uploadFile2FTP(uploadFile1Name);
			uploadFile2FTP(uploadFile2Name);

			Log4jUtil.info("[WH19:Upload]");

			req.setFile1(uploadFile1Name);
			req.setFile2(uploadFile2Name);

			Log4jUtil.info("[WH19:req]{}", req.toString());

			WH19ResponseDTO resp = new WH19ResponseDTO();
			resp = abcCrossBankService.transfer(req, resp);

			Log4jUtil.info("[WH19:resp]{}", resp.toString());

			resultDTO.setChannelId(channelId);
			resultDTO.setChannelResponseCode(resp.getRespCode());
			resultDTO.setChannelResponseMsg(resp.getRespMsg().trim());
			if ("0000".equals(resp.getRespCode())) {
				resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				record.setPayState("1");
			} else {
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				record.setPayState("2");
			}

		} catch (Exception ex) {
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg(ex.getMessage());
			Log4jUtil.error(ex);
		}
		
		Log4jUtil.info("[WH19:Return]{}", resultDTO.toString());
		return resultDTO;
	}
	
	public ClearingResultDTO transWH14(UploadInfoDTO request) {
		Log4jUtil.info("[WH14:入参]Channel:{},File:{}", request.getChannelId(), request.getFilePath());
		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		ClearingResultDTO resultDTO = new ClearingResultDTO();

		try {
			AbcCrossFileConvertor convertor = new AbcCrossFileConvertor("", seqService.getAbcCrossSN(), request.getFilePath(), params.get(AbcCrossConstant.PARM_USR_FTP_LOCAL_PATH));

			String uploadFileName = convertor.convertWH14File();

			Log4jUtil.info("[WH14:file]{}", uploadFileName);

			uploadFile2FTP(uploadFileName);

			Log4jUtil.info("[WH14:Upload]");

			WH14RequestDTO req = new WH14RequestDTO();
			req.setTransCode(AbcCrossConstant.TRAN_CODE_WH14);
			req.setProcCode(AbcCrossConstant.PROC_CODE);
			req.setTermID(params.get(AbcCrossConstant.PARM_USR_TERM_ID));
			req.setMerID(params.get(AbcCrossConstant.PARM_USR_MER_ID));
			req.setFile(uploadFileName);

			Log4jUtil.info("[WH14:req]{}", req.toString());

			WH14ResponseDTO resp = new WH14ResponseDTO();
			resp = abcCrossBankService.transfer(req, resp);

			Log4jUtil.info("[WH14:resp]{}", resp.toString());

			resultDTO.setChannelResponseCode(resp.getRespCode());
			resultDTO.setChannelResponseMsg(resp.getRespMsg().trim());
		} catch (Exception ex) {
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg(ex.getMessage());
			Log4jUtil.error(ex);
		}

		Log4jUtil.info("[WH14:Return]{}", resultDTO.toString());
		return resultDTO;
	}

	/**
	 * (H+六位年月日+商户号后两位+3位序号)
	 */
	private String createSeqNo(String merid, String seq) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		StringBuilder sb = new StringBuilder("H");//prefix
		sb.append(sdf.format(new Date()));
		sb.append(merid.substring(merid.length() - 2));
		sb.append(seq);
		return sb.toString();
	}
	
	
	
	private void uploadFile2FTP(String filename) throws Exception{
		Map<String,String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		SftpUtil sf = new SftpUtil(params.get(AbcCrossConstant.PARM_SYS_FTP_IP), params.get(AbcCrossConstant.PARM_SYS_FTP_USER), params.get(AbcCrossConstant.PARM_SYS_FTP_PWD), Integer.parseInt(params.get(AbcCrossConstant.PARM_SYS_FTP_PORT)));
		ChannelSftp sftp = sf.connectByPasswd();
		String filepath = params.get(AbcCrossConstant.PARM_USR_FTP_LOCAL_PATH) + filename;
		Log4jUtil.info("--发送文件本地路径：{} ", filepath);
		Log4jUtil.info("--Sftp服务器上行目录：{}", params.get(AbcCrossConstant.PARM_USR_FTP_REMOTE_PATH));
		sf.upload(params.get(AbcCrossConstant.PARM_USR_FTP_REMOTE_PATH), filepath, sftp);
		sf.disconnect(sftp);
		Log4jUtil.info("--文件:" + filename + "已上传到服务器");
	}
	
	private String convertBankNo2Swift(String bankNo) throws BizException{
		BankTypeInfoWithSwiftCode swift = swiftCodeService.queryBankTypeInfoWithSwiftCode(bankNo);
		if(swift == null){
			throw new BizException("未找到行号对应的SWIFT信息！");
		}
		return swift.getSwiftCode();
	}

}
