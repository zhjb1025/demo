package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.processor;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatFileResultQueryReq;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatFileResultQueryRsp;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatchTrasNoticeRsp;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.RequestBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.ResponeBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util.TranProcessUtil;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util.BatchNoticeBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.RefundBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.SftpUtilByPass;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;
import com.lycheepay.clearing.util.ObjectUtil;


@Service(ClearingAdapterAnnotationName.ABC_CORP_QUICK_MSGDEAL)
public class CorpAbcQuickMsgDeal {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	private static String channelId = ChannelIdEnum.ABC_QUICK_PAY.getCode();

	@Autowired
	@Qualifier("abcquick.tranProcessUtil")
	private TranProcessUtil tranProcess;
	/**
	 * 
	 * @param bizBean
	 * @param refundSn
	 * @param accountNo
	 * @return
	 * @throws BizException
	 */
	public ReturnState dealPayRefund(RefundBean bizBean, String refundSn, String accountNo, String accountName)
			throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String currencyCode = channelParms.get("200004");
		String bizCode_02 = channelParms.get("200006");// 02 新增加02_代收付业务代码
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort
		ReturnState rs = new ReturnState(); // 保存返回给回执处理器的结果变量
		AssertUtils.notNull(bizBean, TransReturnCode.code_9108, "实时代付请求数据中的交易业务bean[bizBean]不能为空!");

		String account = accountNo; // 入账银行卡号
		String accName = accountName;// 入账客户姓名 可选
		String channelAmt = MoneyUtil.getFenString(bizBean.getAmount());
		String idCard = "";

		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("0220");// OK 1 交易码 4
		requestBean.setProcessCode("200000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setBizCode(bizCode_02);// OK 5 业务代码 2 Y
		requestBean.setAccount(account);// OK 6 主账号 19 左对齐右补空格 Y
		requestBean.setAmt(channelAmt);// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		requestBean.setSysTrack(bizBean.getBankSendSn());// 8 系统跟踪号 20 左对齐右补空格 Y
		requestBean.setInputCode("012");// OK 9 输入方式码 3 Y
		requestBean.setOriSysCode(bizBean.getBankRecvSn());// 10 原系统参考号 20
		// 左对齐右补空格 C
		requestBean.setCardValidDate("");// 11 卡有效期 4 左对齐右补空格 YYMM C
		requestBean.setAuthorCode("");// OK 12 授权码 2 左对齐右补空格 O
		requestBean.setRemark("退款交易");// OK 13 摘要 10 左对齐右补空格 C
		requestBean.setAccName(accName);// 14 户名 70 左对齐右补空格 Y
		requestBean.setCurrencyCode(currencyCode);// OK 15 货币代码 3 Y
		requestBean.setMerchantStream(bizBean.getBillnosnSeq());// 16 商户交易流水号 20 左对齐右补空格
		requestBean.setIdCard(idCard);// 证件类型+证件号码

		ResponeBean responeBean = new ResponeBean();
		Log4jUtil.info("实时代付请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, requestBean);
		try {
			responeBean = tranProcess.trans(socketIP, socketPort, requestBean, md5CodeKey, "PayRefund");
		} catch (BizException e) {
			Log4jUtil.error(e);
			Log4jUtil.info("-----------交易处理【超时】,进入冲正处理:");
			if (e.getErrorCode().equals(TransReturnCode.code_9109)
					|| e.getErrorCode().equals(TransReturnCode.code_9108)) {
				ResponeBean rb = null;
				// String msg = "交易处理超时,后续的冲正交易失败 ！";
				try {
					AbcCorpQuickDirectProcess p = new AbcCorpQuickDirectProcess();
					rb = tranProcess.trans(socketIP, socketPort, p.buildRushBean(requestBean), md5CodeKey, "rush");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				if (rb != null && rb.getRetCode().equals("00")) {
					// msg = "交易处理超时,后续的冲正已成功！";
					throw new BizException(TransReturnCode.code_9109, e.getMessage());
				} else {
					throw new BizException(TransReturnCode.code_9109, e.getMessage());
					// msg = "冲正失败或超时，原退款交易默认为成功！";
					// // 超时情况下组ReturnState
					// rs = new ReturnState();
					// rs.setReturnState(PayState.SUCCEED_RTN);
					// rs.setReturnMsg("超时作成功处理！"); // 银行响应信息
					// rs.setBankPostScript("超时作成功处理！");
					// rs.setChannelCode("0000"); // 渠道返回给业务层状态码
					// rs.setCardType(BankCardType.UNDISTINGUISH); // 卡类型
					// rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
					// rs.setRelTranAmount(new BigDecimal(Double.valueOf(requestBean.getAmt()) /
					// 100)); // 实际扣款金额
				}
			} else {
				throw new BizException(TransReturnCode.code_9109, e.getMessage());
			}
		}

		// 有回执信息下组ReturnState
		if (!StringUtil.isBlank(responeBean.getRetCode())) {

			ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回
			channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, responeBean.getRetCode()));
			String channelCode = TransReturnCode.code_9900, respInfo = "";
			if (channelRtncode == null) {
				channelCode = TransReturnCode.code_9900;
			} else {
				channelCode = channelRtncode.getKftRtncode();
				respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
			}

			rs.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
			rs.setReturnMsg(respInfo); // 银行响应信息
			rs.setBankPostScript(respInfo);
			rs.setCreditNo(responeBean.getSysCode()); // 银行返回凭证号码（银行端流水）
			rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
			rs.setCardType(BankCardType.UNDISTINGUISH); // 卡类型
			rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
			rs.setRelTranAmount(new BigDecimal(Double.valueOf(responeBean.getAmt()) / 100)); // 实际扣款金额

			if (responeBean.getRetCode().equals("00")) {
				rs.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
				rs.setBankPostScript("退款成功");
				rs.setReturnMsg("退款成功");
				Log4jUtil.info("农行快捷系统退款处理成功,退款的[BillnosnSeq]为:" + bizBean.getBillnosnSeq());
			} else {
				rs.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
			}
		}
		return rs;
	}

	/**
	 * 发送文件名：商户号_项目号_代收代付（01/02）_YYMMDD_NNNN.SRC 接收文件名：商户号_项目号_代收代付（01/02）_YYMMDD_NNNN.RCV
	 * 
	 * @param trantype
	 * @return
	 */
	public BatchNoticeBean createFileName(String trantype, String srcOrRcv) {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String projectCode = channelParms.get("200007");
		BatchNoticeBean b = new BatchNoticeBean();
		StringBuffer fname = new StringBuffer(merchantID).append("_").append(projectCode).append("_");

		if (trantype.equals("2001")) {
			fname.append("01");
			b.setPayFlag("01");
		} else if (trantype.equals("2003")) {
			fname.append("02");
			b.setPayFlag("02");
		}

		String transReqDate = DateUtil.getCurrentDate();
		String transReqTime = DateUtil.getCurrentTime();
		String fileNumber = sequenceManagerService.getCorpAbcQuickBatchFileSN().substring(4);

		fname.append("_").append(transReqDate.substring(2)).append("_");
		fname.append(fileNumber);

		if (srcOrRcv.equals("SRC")) {
			fname.append(".SRC");
		} else if (srcOrRcv.equals("RCV")) {
			fname.append(".RCV");
		}

		b.setTransCode("PL01");
		b.setMerchantCode(merchantID);
		b.setProjectCode(projectCode);
		b.setTransReqDate(transReqDate);
		b.setTransReqTime(transReqTime);
		b.setFileNumber(fileNumber);
		b.setFileName(fname.toString());

		return b;
	}

	/**
	 * 
	 * @param batchFileName
	 * @throws BizException
	 */
	public void uploadFile(String batchFileName) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ftpIP = channelParms.get("200014");
		String ftpUser = channelParms.get("200015");
		String ftpPwd = channelParms.get("200016");
		String batchFileDir = channelParms.get("200018");// 批量交易ftp银行端路径
		String batchLocalFilepath = channelParms.get("200021");// 批量交易ftp本地端路径
		FtpManager ftpManager = new FtpManager();
		ftpManager.setServer(ftpIP);
		ftpManager.setPassword(ftpPwd);
		ftpManager.setUser(ftpUser);
		ftpManager.setFilename(batchFileName);

		ftpManager.setLocalPath(batchLocalFilepath); // 本地文件夹（相对路径的目录）
		ftpManager.setPath(batchFileDir); // 远程目录，不用设置，FTP 用户默认的目录就是要上传文件的目录

		Log4jUtil.info("待发送文件本地路径：{} ", batchLocalFilepath);
		Log4jUtil.info("ftp服务器IP：{}，账号：{}，密码：{}，相对目录：{}", ftpIP, ftpUser, ftpPwd, batchFileDir);

		try {
			ftpManager.putMyFile_actionPerformed_binary();
		} catch (BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "上传文件" + batchFileName + "出错！！");
		}
		Log4jUtil.info("农行快捷系统报文:" + batchFileName + "已上传到服务器");
	}

	/**
	 * 上传到Sftp服务器
	 * 
	 * @param batchFileName
	 * @throws BizException
	 */
	public void uploadFileToSftp(String batchFileName) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ftpIP = channelParms.get("200014");
		String ftpUser = channelParms.get("200015");
		String ftpPwd = channelParms.get("200016");
		String batchFileDir = channelParms.get("200018");// 批量交易ftp银行端路径
		String batchLocalFilepath = channelParms.get("200021");// 批量交易ftp本地端路径

		SftpUtilByPass sf = new SftpUtilByPass(ftpIP, ftpUser, null, ftpPwd, 22);
		ChannelSftp sftp = sf.connectByPasswd();
		sf.upload(batchFileDir, batchLocalFilepath + File.separator + batchFileName, sftp);
		sf.disconnect(sftp);

		Log4jUtil.info("--发送文件本地路径：{} ", batchLocalFilepath);
		Log4jUtil.info("--Sftp服务器IP：{}，账号：{}，密码：{}，相对目录：{}", ftpIP, ftpUser, ftpPwd, batchFileDir);
		Log4jUtil.info("--农行快捷系统报文:" + batchFileName + "已上传到服务器");
	}

	/**
	 * 生成文件
	 * 
	 * @param filePath 文件所在的文件夹
	 * @param fileName 文件名称
	 * @param fileValue文件内容
	 * @return 文件名（含相对路径文件夹）
	 * @throws BizException
	 */
	private String createBatchFile(String filePath, String fileName, String fileValue) throws BizException {
		// PrintWriter pw=null;
		// FileProcess.createDir(filePath); // 如果文件夹不存在，创建文件夹
		String AccFile = filePath + File.separator + fileName; // 含相对路径的文件名
		try {
			// pw = new PrintWriter(AccFile);
			FileUtils.writeStringToFile(new File(AccFile), fileValue, "GBK");
		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "生成文件出错！！" + e.getMessage());
		}
		// pw.write(fileValue);
		// pw.flush();
		// pw.close();
		return AccFile;
	}

	/**
	 * 
	 * @param fileName
	 * @param fileStr
	 * @return
	 * @throws BizException
	 */
	public String createBatchFile(String fileName, String fileStr) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String batchLocalFilepath = channelParms.get("200021");// 批量交易ftp本地端路径
		Log4jUtil.info("batchLocalFilepath：" + batchLocalFilepath + "; fileName：" + fileName);
		return createBatchFile(batchLocalFilepath, fileName, fileStr);
	}

	/**
	 * 
	 * @param batchNoticeBean
	 * @return
	 * @throws BizException
	 */
	public ReturnState sendBatchTrasNotice(BatchNoticeBean batchNoticeBean) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String md5CodeKey = channelParms.get("200003");
		String socketIP_batch = channelParms.get("200012"); // 批量交易用到的socketIP
		String socketPort_batch = channelParms.get("200013"); // 批量交易用到的socketPort
		Log4jUtil.info("批量代收付通知请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, batchNoticeBean);
		BatchTrasNoticeRsp rsp = tranProcess.transNotice(socketIP_batch, socketPort_batch, batchNoticeBean, md5CodeKey);


		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, rsp.getRetCode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode != null) {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		ReturnState rs = new ReturnState();
		if (TransReturnCode.code_0000.equals(channelCode)) {
			rs.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			rs.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		}
		rs.setBankRetCode(rsp.getRetCode()); // 银行返回代码
		rs.setReturnMsg(respInfo); // 银行响应信息
		rs.setBankPostScript(rsp.getRetMsg());
		rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
		rs.setReturnObj(rsp.getBackSeq());

		return rs;
	}

	/**
	 * 批量文件结果查询与处理
	 * 
	 * @param param
	 * @throws BizException
	 */
	public BatFileResultQueryRsp batRetDeal(Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String md5CodeKey = channelParms.get("200003");
		String socketIP_batch = channelParms.get("200012"); // 批量交易用到的socketIP
		String socketPort_batch = channelParms.get("200013"); // 批量交易用到的socketPort
		String batchLocalFilepath = channelParms.get("200021");// 批量交易ftp本地端路径
		// 批量文件结果查询
		String channelBatchNo = (String) param.getBizBean();

		AssertUtils.notNull(channelBatchNo, TransReturnCode.code_9108, "批量文件结果查询请求参数中的渠道批次ID不能为空");

		String bankBatchId = channelBatchService.getBankBatchid(channelId, channelBatchNo);
		AssertUtils.notNull(bankBatchId, TransReturnCode.code_9108,
				StringUtil.r("批量文件结果查询请求参数中的【渠道批次ID】：{?}对应的【银行原银行流水号】为空,不允许发起查询", channelBatchNo));

		BatFileResultQueryReq req = new BatFileResultQueryReq("PL02", bankBatchId);
		BatFileResultQueryRsp rsp = tranProcess.batFileResultQuery(socketIP_batch, socketPort_batch, req,
				md5CodeKey);

		// BatFileResultQueryRsp rsp = new BatFileResultQueryRsp();
		// rsp.setTranDate("20120529");

		// 如果返回0000表示回盘文件已生成，可以取文件。
		if (!"0000".equals(rsp.getRetCode())) {
			Log4jUtil.info("批量文件结果查询-【渠道批次ID】为：{}的批次未回盘,无结果文件可以下载", channelBatchNo);
			// throw new BizException("ECDB", msg);
			return rsp;
		}

		String batchFileRcv = rsp.getFileNameRcv().replace(".SRC", ".RCV");
		// String batchFileRcv = "01016_01_01_120529_0063.RCV";
		AssertUtils.notNull(batchFileRcv, TransReturnCode.code_9109,
				StringUtil.r("批量文件结果查询-【渠道批次ID】为：{?}的批次已经回盘，但是未获得文件名，无结果文件可以下载", channelBatchNo));

		// 从银行FTP服务器获取批量结果文件
		// 如果文件夹不存在，创建文件夹
		if (FileProcess.createDir(batchLocalFilepath) == false) {
			throw new BizException(TransReturnCode.code_9108, "创建文件夹【" + batchLocalFilepath + "】 出错！！");
		}

		// 下载
		this.downloadFileFromSftp(batchFileRcv);

		String fullFileName = batchLocalFilepath + File.separator + batchFileRcv;
		rsp.setFileNameRcvPath(fullFileName);
		Log4jUtil.info("返回的文件（含相对路径）为：" + fullFileName);

		return rsp;
	}

	/**
	 * 下载Sftp服务器文件
	 * 
	 * @param rcvFileName
	 * @throws BizException
	 */
	public void downloadFileFromSftp(String rcvFileName) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ftpIP = channelParms.get("200014");
		String ftpUser = channelParms.get("200015");
		String ftpPwd = channelParms.get("200016");
		String batchFileDir = channelParms.get("200018");// 批量交易ftp银行端路径
		String batchLocalFilepath = channelParms.get("200021");// 批量交易ftp本地端路径
		SftpUtilByPass sf = new SftpUtilByPass(ftpIP, ftpUser, null, ftpPwd, 22);
		ChannelSftp sftp = sf.connectByPasswd();
		sf.download(batchFileDir, rcvFileName, batchLocalFilepath + File.separator + rcvFileName, sftp);
		sf.disconnect(sftp);

		Log4jUtil.info("--Sftp服务器IP：{}，账号：{}，密码：{}，相对目录：{} ,下载文件：{}", ftpIP, ftpUser, ftpPwd, batchFileDir, rcvFileName);
		Log4jUtil.info("--保存到本地路径：{} ", batchLocalFilepath);
		Log4jUtil.info("--农行快捷系统批量结果文件:【{}】已下载到本地", rcvFileName);
	}
}