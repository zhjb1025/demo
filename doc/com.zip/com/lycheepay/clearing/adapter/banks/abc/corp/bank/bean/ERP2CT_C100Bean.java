package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_C100Bean {

	// ERP2CT_C100 企业操作员签到请求报文
	private String OpPwd; // 企业操作员密码
	private String OpNewPwd; // 操作员IC卡密码
	private String MsgPort; // 企业操作员接收通知端口

	public String getOpPwd() {
		return OpPwd;
	}

	public void setOpPwd(final String opPwd) {
		OpPwd = opPwd;
	}

	public String getOpNewPwd() {
		return OpNewPwd;
	}

	public void setOpNewPwd(final String opNewPwd) {
		OpNewPwd = opNewPwd;
	}

	public String getMsgPort() {
		return MsgPort;
	}

	public void setMsgPort(final String msgPort) {
		MsgPort = msgPort;
	}

}
