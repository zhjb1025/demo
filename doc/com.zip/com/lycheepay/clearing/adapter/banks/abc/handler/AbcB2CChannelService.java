/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-2-9 上午11:05:51
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.http.b2c.AbcB2CHttpProcessor;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.NetDeductType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.common.dto.trade.NetResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行网银B2C清算服务入口类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 上午10:51:41
 */
@Service(ClearingAdapterAnnotationName.ABC_B2C_CHANNEL_SERVICE)
public class AbcB2CChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_B2C_HTTP_PROCESSOR)
	private AbcB2CHttpProcessor abcB2CHttpProcessor;

	public final static String channelId = ChannelIdEnum.ABC_B2C.getCode();

	/**
	 * PS.B2C网银代扣服务
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#onlineDeduct(com.lycheepay.clearing.common.dto.trade.NetDeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public NetResultDTO onlineDeduct(final NetDeductDTO deduct) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC", "online");
		final HttpParam httpParam = new HttpParam();
		httpParam.setChannelId(ChannelIdEnum.ABC_B2C.getCode());
		httpParam
				.setClearingTransType(NetDeductType.TYPE_PAY == deduct.getType() ? ClearingTransType.NET_DEDUCT_B2C_PAY
						: ClearingTransType.NET_DEDUCT_B2C_RECHARGE);
		httpParam.setCustomerType(deduct.getAccountType());
		httpParam.setBizBean(deduct);
		HttpReturnParam httpReturnParam;
		try {
			httpReturnParam = abcB2CHttpProcessor.onlineDeduct(httpParam);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}
		final NetResultDTO httpProcessChannelResult = new NetResultDTO();
		httpProcessChannelResult.setActionUrl(httpReturnParam.getAction());
		httpProcessChannelResult.setParams(httpReturnParam.getParams());
		return httpProcessChannelResult;
	}

	/**
	 * PS.农业银行网银账户验证
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#onlineAccountVerify(com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public NetResultDTO onlineAccountVerify(final BankCardVerifyDTO accountVerify)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC", "online");
		final HttpParam httpParam = new HttpParam();
		httpParam.setChannelId(channelId);
		httpParam.setClearingTransType(ClearingTransType.ONLINE_ACCOUNT_VERIFY);
		httpParam.setBizBean(accountVerify);
		HttpReturnParam httpReturnParam;
		try {
			httpReturnParam = abcB2CHttpProcessor.onlineAccountVerify(httpParam);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}

		final NetResultDTO httpProcessChannelResult = new NetResultDTO();
		httpProcessChannelResult.setActionUrl(httpReturnParam.getAction());
		httpProcessChannelResult.setParams(httpReturnParam.getParams());
		return httpProcessChannelResult;
	}

	// XXX Batch By:Leon.Qiu[2012-6-18 上午10:52:40]
	// @Override
	// public BatchRefundResultDTO batchRefund(final BatchRefundChannelDTO batchRefundDTO)
	// throws ClearingAdapterBizCheckedException {
	// Log4jUtil.setLogClass("ABC", "direct");
	// final Param param = new Param();
	// param.setRepeatFlag(batchRefundDTO.getRepeatFlag());
	// param.setChannelId(batchRefundDTO.getChannelId());
	// param.setChannelTransType(ChannelTransType.PayRefund);
	// param.setTransType(batchRefundDTO.getTransType());
	//
	// if ("Y".equals(param.getRepeatFlag())) {// 若为重发，则传进来是个包号
	// param.setBizBean(batchRefundDTO.getChannelBatchid());
	// } else {
	// final BatchRefund batchRefund = new BatchRefund();
	// final BatchRefundId id = new BatchRefundId();
	// id.setChannelId(batchRefundDTO.getChannelId());
	// id.setRefundNetNo(batchRefundDTO.getRefundNetNo());
	// id.setRefundType(batchRefundDTO.getRefundType());
	// batchRefund.setId(id);
	// param.setBizBean(batchRefund);
	// }
	//
	// final AbcB2CDirectProcess abcB2CDirectProcess = new AbcB2CDirectProcess();
	// final ReturnState returnState = abcB2CDirectProcess.deal(param);
	// final BatchRefundResultDTO batchRefundResultDTO = new BatchRefundResultDTO();
	// batchRefundResultDTO.setReturnState(returnState.getReturnState());
	// batchRefundResultDTO.setFileNames((List<?>) returnState.getReturnObj());
	// return batchRefundResultDTO;
	// }

	/**
	 * <p>农行发送批量退款查询 定时任务处理</p>
	 * 
	 * @author 张凯锋(13816608861)
	 */
	public void timeQueryBatchRefundResult() {
		Log4jUtil.setLogClass("ABC", "timeQueryBatchRefundResult");
		/*
		 * ChannelBatchRefundDao channelBatchRefundDao = (ChannelBatchRefundDao) SpringContext
		 * .getService("channelBatchRefundDao"); List<ChannelBatchRefund> channelBatchRefundList =
		 * channelBatchRefundDao.getByChannelId(channelId); Param param = new Param();
		 * param.setChannelId(channelId); param.setChannelTransType("batchRefundQuery");
		 * param.setBizBean(channelBatchRefundList); abcB2CHttpProcessor.deal(param);
		 */
	}
}