package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 60域. 自定义域
 * 
 * @author aps-mhc
 */
public class Field60 {
	private final byte[] value;
	private String str60_1;// 交易类型码 n2
	private String str60_2;// 批次号 n6

	public Field60(final byte[] bcdValue) throws BizException {
		AssertUtils.notNull(bcdValue, "未指定域值");

		this.value = ByteUtils.bcdToStr(bcdValue).getBytes();
	}

	/**
	 * 取交易类型码, 解码值第1位开始取2位.
	 * 
	 * @return
	 */
	public String get60_1() {
		if (str60_1 != null) {
			return str60_1;
		}

		final int startPos = 0;
		final int endPos = startPos + 2;
		str60_1 = new String(ArrayUtils.subarray(value, startPos, endPos));

		return str60_1;
	}

	/**
	 * 取批次号, 解码值第3位开始取6位.
	 * 
	 * @return
	 */
	public String get60_2() {
		if (str60_2 != null) {
			return str60_2;
		}

		final int startPos = 2;
		final int endPos = startPos + 6;
		str60_2 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str60_2;
	}
}
