package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行银企组装公共包服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-15 下午6:23:17
 */
@Service(ClearingAdapterAnnotationName.ERP2_CT_PUBLIC_SERVICE)
public class Erp2CTPublicService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	private static String channelId = ChannelIdEnum.ABC_CORP.getCode();

	/**
	 * 获取公共包头 bean
	 * 
	 * @category param TransCode 农行银企交易代码
	 * @param ReqSeqNo 请求方流水号
	 * @return 组好的公共包头bean
	 * @throws BizException
	 * @throws ClearingAdapterBizCheckedException
	 */
	public ERP2CT_PublicBean createErp2CTPublic(final String TransCode, final String ReqSeqNo) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ChannelType = channelParms.get("100002").trim();
		String CorpNo = channelParms.get("100003");
		String OpNo = channelParms.get("100004");
		String AuthNo = channelParms.get("100005");
		String Sign = channelParms.get("100012");
		final ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();

		AssertUtils.notNull(ChannelType, TransReturnCode.code_9108, "农行银企渠道参数中ChannelType值不能为空!");
		AssertUtils.notNull(CorpNo, TransReturnCode.code_9108, "农行银企渠道参数中CorpNo值不能为空!");
		AssertUtils.notNull(OpNo, TransReturnCode.code_9108, "农行银企渠道请求中OpNoe值不能为空!");
		AssertUtils.notNull(AuthNo, TransReturnCode.code_9108, "农行银企渠道请求中AuthNo值不能为空!");
		AssertUtils.notNull(Sign, TransReturnCode.code_9108, "农行银企渠道请求中Sign值不能为空!");

		eRP2CT_PublicBean.setTransCode(TransCode);
		eRP2CT_PublicBean.setChannelType(ChannelType);
		eRP2CT_PublicBean.setCorpNo(CorpNo);
		eRP2CT_PublicBean.setOpNo(OpNo);
		eRP2CT_PublicBean.setAuthNo(AuthNo);
		eRP2CT_PublicBean.setReqSeqNo(ReqSeqNo);
		eRP2CT_PublicBean.setReqDate(DateUtil.getCurrentDate());
		eRP2CT_PublicBean.setReqTime(DateUtil.getCurrentTime());
		// eRP2CT_PublicBean.setReqDate("20110420"); // TODO 测试环境，交易日期全改为 20110420,上线后改回来
		// eRP2CT_PublicBean.setReqTime(DateUtil.getCurrentTime()); // 测试环境，交易日期全改为 20110420
		eRP2CT_PublicBean.setSign(Sign);
		eRP2CT_PublicBean.setCcVersion("2"); // CC报文版本,固定为 2
		// eRP2CT_PublicBean.setCcVersion("1"); // CC报文版本,固定为 2
		Log4jUtil.info("组农行银企公共包头成功，交易类型为：" + TransCode + "，交易的请求方流水号为：" + ReqSeqNo);
		return eRP2CT_PublicBean;
	}
	
	public ERP2CT_PublicBean createErp2CTPublic4SettlementReport(final String TransCode, final String ReqSeqNo) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String PayComNo = channelParms.get("100038").trim();	//支付机构签约编号
		AssertUtils.notNull(PayComNo, TransReturnCode.code_9108, "农行银企渠道参数中PayComNo值不能为空!");
		
		final ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		eRP2CT_PublicBean.setTransCode(TransCode);
		eRP2CT_PublicBean.setReqSeqNo(ReqSeqNo);
		eRP2CT_PublicBean.setReqDate(DateUtil.getCurrentDate());
		eRP2CT_PublicBean.setReqTime(DateUtil.getCurrentTime());
		eRP2CT_PublicBean.setCcVersion("2"); // CC报文版本,固定为 2
		eRP2CT_PublicBean.setPayComNo(PayComNo);
		Log4jUtil.info("组农行银企备付金报表上报请求公共包头成功，交易类型为：" + TransCode + "，交易的请求方流水号为：" + ReqSeqNo);
		return eRP2CT_PublicBean;
	}

}
