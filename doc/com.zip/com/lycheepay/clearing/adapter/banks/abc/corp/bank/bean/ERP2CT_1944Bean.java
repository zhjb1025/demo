package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_1944Bean {

	// ERP2CT_1944 查询金融交易处理状态（1944） 请求报文字段
	private String SerialNo; // 原交易ERP请求流水号

	public String getSerialNo() {
		return SerialNo;
	}

	public void setSerialNo(final String serialNo) {
		SerialNo = serialNo;
	}

}
