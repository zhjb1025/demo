package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util;

public class SequenceUtil {

	
	public static String formatSeq(int sequence,int formatLen) {
		String formatStr = "%0"+formatLen+"d";//"%08d"
		String sRet = String.format(formatStr, sequence);
		return sRet;
	}

	public static void main(String[] args) {
		String disp = SequenceUtil.formatSeq(1,12);
		System.out.println(disp);
	}
}
