package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 61域.
 * 
 * @author aps-mhc
 */
public class Field61 {
	private final byte[] value;
	private String str61_1;// 原批号 n6
	private String str61_2;// 原POS流水号 n6

	public Field61(final byte[] bcdValue) throws BizException {
		AssertUtils.notNull(bcdValue, "未指定域值");

		this.value = ByteUtils.bcdToStr(bcdValue).getBytes();
	}

	/**
	 * 取交易类型码, 解码值第1位开始取6位.
	 * 
	 * @return
	 */
	public String get61_1() {
		if (str61_1 != null) {
			return str61_1;
		}

		final int startPos = 0;
		final int endPos = startPos + 6;
		str61_1 = new String(ArrayUtils.subarray(value, startPos, endPos));

		return str61_1;
	}

	/**
	 * 取批次号, 解码值第7位开始取6位.
	 * 
	 * @return
	 */
	public String get61_2() {
		if (str61_2 != null) {
			return str61_2;
		}

		final int startPos = 6;
		final int endPos = startPos + 6;
		str61_2 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str61_2;
	}
}
