package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_CQLA35Bean {
	// ERP2CT_CQLA35Bean 按请求流水号查询人行监管报表处理状态（CQLA35）请求报文字段
	
	private String SerialDate;	// 查询报表日期
	private String SerialNo; // 原流水号
	
	public String getSerialDate() {
		return SerialDate;
	}
	public void setSerialDate(String serialDate) {
		SerialDate = serialDate;
	}
	public String getSerialNo() {
		return SerialNo;
	}
	public void setSerialNo(String serialNo) {
		SerialNo = serialNo;
	}
	
}
