package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH19RequestDTO extends AbcCrossBeanBase {

	public WH19RequestDTO() {
		super.addField(new AbcCrossBeanField("transCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("procCode", 6, true, ' '));
		super.addField(new AbcCrossBeanField("termID", 8, true, ' '));
		super.addField(new AbcCrossBeanField("merID", 10, true, ' '));
		super.addField(new AbcCrossBeanField("seqNo", 12, true, ' '));
		super.addField(new AbcCrossBeanField("payType", 1, true, ' '));
		super.addField(new AbcCrossBeanField("bizType", 1, true, ' '));
		super.addField(new AbcCrossBeanField("currency", 3, true, ' '));
		super.addField(new AbcCrossBeanField("amount", 16, true, ' '));
		super.addField(new AbcCrossBeanField("applyNo", 30, true, ' '));
		// /
		super.addField(new AbcCrossBeanField("remitDest", 1, true, ' '));
		super.addField(new AbcCrossBeanField("remitPurpose", 1, true, ' '));
		super.addField(new AbcCrossBeanField("recvBankNo", 35, true, ' '));
		super.addField(new AbcCrossBeanField("recvDPBankNo", 35, true, ' '));
		super.addField(new AbcCrossBeanField("recvIPBankNo", 35, true, ' '));
		super.addField(new AbcCrossBeanField("agencyBankNo1", 35, true, ' '));
		super.addField(new AbcCrossBeanField("agencyBankNo2", 35, true, ' '));
		super.addField(new AbcCrossBeanField("payeeType", 1, true, ' '));
		super.addField(new AbcCrossBeanField("payeeAccount", 32, true, ' '));
		super.addField(new AbcCrossBeanField("payeeName", 150, true, ' '));
		super.addField(new AbcCrossBeanField("accountABD", 1, true, ' '));
		super.addField(new AbcCrossBeanField("payeeBankType", 150, true, ' '));
		super.addField(new AbcCrossBeanField("feePayer", 4, true, ' '));
		super.addField(new AbcCrossBeanField("signIO", 1, true, ' '));
		super.addField(new AbcCrossBeanField("bizSort", 4, true, ' '));
		super.addField(new AbcCrossBeanField("payeeCountry", 3, true, ' '));
		super.addField(new AbcCrossBeanField("remark", 135, true, ' '));
		super.addField(new AbcCrossBeanField("remarkNote", 135, true, ' '));
		// /
		super.addField(new AbcCrossBeanField("file1", 50, true, ' '));
		super.addField(new AbcCrossBeanField("file2", 50, true, ' '));
		super.addField(new AbcCrossBeanField("fileCount", 10, true, ' '));
		super.addField(new AbcCrossBeanField("merName", 100, true, ' '));
		super.addField(new AbcCrossBeanField(AbcCrossConstant.STRING_MD5, 32, true, ' '));
	}

	public String getTransCode() {
		return data.get("transCode");
	}

	public void setTransCode(String transCode) {
		data.put("transCode", transCode);
	}

	public String getProcCode() {
		return data.get("procCode");
	}

	public void setProcCode(String procCode) {
		data.put("procCode", procCode);
	}

	public String getTermID() {
		return data.get("termID");
	}

	public void setTermID(String termID) {
		data.put("termID", termID);
	}

	public String getMerID() {
		return data.get("merID");
	}

	public void setMerID(String merID) {
		data.put("merID", merID);
	}

	public String getSeqNo() {
		return data.get("seqNo");
	}

	public void setSeqNo(String seqNo) {
		data.put("seqNo", seqNo);
	}

	public String getPayType() {
		return data.get("payType");
	}

	public void setPayType(String payType) {
		data.put("payType", payType);
	}

	public String getBizType() {
		return data.get("bizType");
	}

	public void setBizType(String bizType) {
		data.put("bizType", bizType);
	}

	public String getCurrency() {
		return data.get("currency");
	}

	public void setCurrency(String currency) {
		data.put("currency", currency);
	}

	public String getAmount() {
		return data.get("amount");
	}

	public void setAmount(String amount) {
		data.put("amount", amount);
	}

	public String getApplyNo() {
		return data.get("applyNo");
	}

	public void setApplyNo(String applyNo) {
		data.put("applyNo", applyNo);
	}

	public String getRemitDest() {
		return data.get("remitDest");
	}

	public void setRemitDest(String remitDest) {
		data.put("remitDest", remitDest);
	}

	public String getRemitPurpose() {
		return data.get("remitPurpose");
	}

	public void setRemitPurpose(String remitPurpose) {
		data.put("remitPurpose", remitPurpose);
	}

	public String getRecvBankNo() {
		return data.get("recvBankNo");
	}

	public void setRecvBankNo(String recvBankNo) {
		data.put("recvBankNo", recvBankNo);
	}

	public String getRecvDPBankNo() {
		return data.get("recvDPBankNo");
	}

	public void setRecvDPBankNo(String recvDPBankNo) {
		data.put("recvDPBankNo", recvDPBankNo);
	}

	public String getRecvIPBankNo() {
		return data.get("recvIPBankNo");
	}

	public void setRecvIPBankNo(String recvIPBankNo) {
		data.put("recvIPBankNo", recvIPBankNo);
	}

	public String getAgencyBankNo1() {
		return data.get("agencyBankNo1");
	}

	public void setAgencyBankNo1(String agencyBankNo1) {
		data.put("agencyBankNo1", agencyBankNo1);
	}

	public String getAgencyBankNo2() {
		return data.get("agencyBankNo2");
	}

	public void setAgencyBankNo2(String agencyBankNo2) {
		data.put("agencyBankNo2", agencyBankNo2);
	}

	public String getPayeeType() {
		return data.get("payeeType");
	}

	public void setPayeeType(String payeeType) {
		data.put("payeeType", payeeType);
	}

	public String getPayeeAccount() {
		return data.get("payeeAccount");
	}

	public void setPayeeAccount(String payeeAccount) {
		data.put("payeeAccount", payeeAccount);
	}

	public String getPayeeName() {
		return data.get("payeeName");
	}

	public void setPayeeName(String payeeName) {
		data.put("payeeName", payeeName);
	}

	public String getAccountABD() {
		return data.get("accountABD");
	}

	public void setAccountABD(String accountABD) {
		data.put("accountABD", accountABD);
	}

	public String getPayeeBankType() {
		return data.get("payeeBankType");
	}

	public void setPayeeBankType(String payeeBankType) {
		data.put("payeeBankType", payeeBankType);
	}

	public String getFeePayer() {
		return data.get("feePayer");
	}

	public void setFeePayer(String feePayer) {
		data.put("feePayer", feePayer);
	}

	public String getSignIO() {
		return data.get("signIO");
	}

	public void setSignIO(String signIO) {
		data.put("signIO", signIO);
	}

	public String getBizSort() {
		return data.get("bizSort");
	}

	public void setBizSort(String bizSort) {
		data.put("bizSort", bizSort);
	}

	public String getPayeeCountry() {
		return data.get("payeeCountry");
	}

	public void setPayeeCountry(String payeeCountry) {
		data.put("payeeCountry", payeeCountry);
	}

	public String getRemark() {
		return data.get("remark");
	}

	public void setRemark(String remark) {
		data.put("remark", remark);
	}

	public String getRemarkNote() {
		return data.get("remarkNote");
	}

	public void setRemarkNote(String remarkNote) {
		data.put("remarkNote", remarkNote);
	}

	public String getFile1() {
		return data.get("file1");
	}

	public void setFile1(String file1) {
		data.put("file1", file1);
	}

	public String getFile2() {
		return data.get("file2");
	}

	public void setFile2(String file2) {
		data.put("file2", file2);
	}

	public String getFileCount() {
		return data.get("fileCount");
	}

	public void setFileCount(String fileCount) {
		data.put("fileCount", fileCount);
	}
	
	public String getMerName() {
		return data.get("merName");
	}

	public void setMerName(String merName) {
		data.put("merName", merName);
	}

}
