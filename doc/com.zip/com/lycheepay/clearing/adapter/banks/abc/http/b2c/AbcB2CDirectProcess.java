package com.lycheepay.clearing.adapter.banks.abc.http.b2c;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;


/**
 * <P>农业银行B2C HTTP(后台直接交互)请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 下午3:55:44
 */
@Service(ClearingAdapterAnnotationName.ABC_B2C_DIRECT_PROCESS)
public class AbcB2CDirectProcess extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_B2C_SERVICE)
	private AbcB2CService abcB2CService;
	// XXX Batch By:Leon.Qiu[2012-6-18 下午4:04:20] 目前用于批量 待凯锋修改

	// private static BatchRefundDistributeService batchRefundDistributeService =
	// (BatchRefundDistributeService) SpringContext
	// .getService("batchRefundDistributeService");
	//
	// public ReturnState deal(final Param param) throws BizException {
	// String logMsg = "";
	// Map<String, String> channelParam = new Map<String, String>();
	// final String channelId = param.getChannelId();
	// final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
	// logMsg = "进入" + logPrefix + "渠道业务处理。";
	// Log4jUtil.info(logMsg);
	// channelParam = (Map<String, String>)
	// channelParmService.getChannelParam(channelId);
	// // if (channelParam == null) throw new BizException(logPrefix + "无法获取渠道参数配置。");
	// // channelParam = (Map) channelParmDao.getChannelParam(channelId);
	// if (param.getChannelTransType().equals(ChannelTransType.Qury_Single_Trans)) {
	// // 单笔查询
	// return this.queryOrder(logPrefix, channelId, param);
	// } else if (param.getChannelTransType().equals("settle")) { // 下载和自动对账，由定时任务处理，不在此调用
	// return this.settle(logPrefix, channelId, param.getSn());
	// } else if (param.getChannelTransType().equals("batchRefundQuery")) {
	// final List<ChannelBatchRefund> channelBatchRefundList = (List<ChannelBatchRefund>)
	// param.getBizBean();
	// return this.queryBatchRefund(logPrefix, channelId, channelBatchRefundList);
	// } else if (param.getChannelTransType().equals(ChannelTransType.PayRefund)) { // 退货
	// if (param.getTransType().equals(ClearingTransType.NetPay_Refund)
	// || param.getTransType().equals(ClearingTransType.Direct_Refund)) {
	// return this.batchRefund(logPrefix, channelId, param, channelParam);
	// }
	// throw new BizException(logPrefix + "错误的业务类型:" + param.getChannelTransType() + ":" +
	// param.getTransType());
	// } else {
	// throw new BizException(logPrefix + "错误的业务类型:" + param.getChannelTransType() + ":" +
	// param.getTransType());
	// }
	// }
	//
	// /**
	// * B2C取消支付
	// *
	// * @param param
	// * @return
	// * @throws BizException
	// */
	// private ReturnState voidPayment(final String logPrefix, final String channelId, final Param
	// param)
	// throws BizException {
	// String logMsg = "";
	// final String sn = "";
	// final ReturnState returnState = new ReturnState();
	// // 1、取得取消支付所需要的信息
	// final String tOrderNo = param.getSn();
	//
	// // 2、生成取消支付请求对象
	// final VoidPaymentRequest tRequest = new VoidPaymentRequest();
	// tRequest.setOrderNo(tOrderNo); // 订单号（必要信息）
	//
	// // 3、传送取消支付请求并取得取消支付结果
	// final TrxResponse tResponse = tRequest.postRequest();
	//
	// // 4、判断取消支付结果状态，进行后续操作
	// if (tResponse.isSuccess()) {
	// // 5、取消支付成功
	// logMsg = "TrxType:" + tResponse.getValue("TrxType");
	// logMsg = logMsg + " OrderNo:" + tResponse.getValue("OrderNo");
	// logMsg = logMsg + " PayAmount:" + tResponse.getValue("PayAmount");
	// logMsg = logMsg + " BatchNo:" + tResponse.getValue("BatchNo");
	// logMsg = logMsg + " VoucherNo:" + tResponse.getValue("VoucherNo");
	// logMsg = logMsg + " HostDate:" + tResponse.getValue("HostDate");
	// logMsg = logMsg + " HostTime:" + tResponse.getValue("HostTime");
	// Log4jUtil.info(logMsg);
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// returnState.setSn(sn);// 原交易流水
	// final String bankRetCode = "0000";
	// returnState.setBankRetCode(bankRetCode);// 银行返回状态
	// returnState.setBankPostScript(tResponse.getErrorMessage());// 银行返回状态
	//
	// ChannelRtncode channelRtncode = null;
	// channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
	// bankRetCode));
	// if (channelRtncode == null) {
	// logMsg = "表  channel_rtncode 没有对应的" + logPrefix + "银行返回信息" + bankRetCode;
	// Log4jUtil.info(logMsg);
	// returnState.setReturnMsg(logMsg);
	// returnState.setChannelCode(TransReturnCode.code_9900);
	// } else {
	// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
	// returnState.setChannelCode(channelRtncode.getKftRtncode());
	// }
	// ObjectUtil.printPropertyString(logPrefix, returnState);
	// } else {
	// logMsg = logPrefix + "向银行发起取消支付请求失败,SN：" + sn + " ReturnCode:" + tResponse.getReturnCode()
	// + " ErrorMessage:" + tResponse.getErrorMessage();
	// Log4jUtil.info(logMsg);
	// throw new BizException(logMsg);
	// }
	// return returnState;
	// }
	//
	// /**
	// * 查询批量退款业务状态
	// *
	// * @param channelBatchRefundList
	// * @throws BizException
	// */
	// private ReturnState queryBatchRefund(final String logPrefix, final String channelId,
	// final List<ChannelBatchRefund> channelBatchRefundList) throws BizException {
	// String logMsg = "";
	// logMsg = "进入" + logPrefix + "查询批量退款处理。共需要向银行发送" + channelBatchRefundList.size() + "次。";
	// Log4jUtil.info(logMsg);
	// for (int i = 0; i < channelBatchRefundList.size(); i++) {
	// List<ReturnState> returnStateList = new ArrayList<ReturnState>();
	// try {
	// returnStateList = abcB2CService.senDBatchRefundQuery(logPrefix, channelId,
	// channelBatchRefundList.get(i));
	// } catch (final BizException e) {
	// if (i != channelBatchRefundList.size()) {
	// logMsg = logPrefix + "向银行发起批次号为：" + channelBatchRefundList.get(i).getBankBatchid()
	// + "的批量退款查询发生错误。继续发起别的批次查询。错误描述为：" + e.getMessage();
	// } else {
	// logMsg = logPrefix + "向银行发起批次号为：" + channelBatchRefundList.get(i).getBankBatchid()
	// + "的批量退款查询发生错误。错误描述为：" + e.getMessage();
	// }
	// Log4jUtil.info(logMsg);
	// }
	// if (returnStateList != null && returnStateList.size() > 0) {
	// // 进行业务回调
	// final BaseParam baseParam = new BaseParam();
	// baseParam.setChannelId(channelId);
	// if (channelBatchRefundList.get(i).getRefundType().equals("01")) {
	// logMsg = logPrefix + "进行8021业务回调。";
	// Log4jUtil.info(logMsg);
	// final Biz8021Adapter biz8021Adapter = new Biz8021Adapter();
	// biz8021Adapter.deal(baseParam, returnStateList);
	// } else if (channelBatchRefundList.get(i).getRefundType().equals("02")) {
	// logMsg = logPrefix + "进行8024业务回调。";
	// Log4jUtil.info(logMsg);
	// final Biz8024Adapter biz8024Adapter = new Biz8024Adapter();
	// biz8024Adapter.deal(baseParam, returnStateList);
	// }
	// }
	// }
	// logMsg = logPrefix + "查询批量退款处理结束。";
	// Log4jUtil.info(logMsg);
	// final ReturnState returnState = new ReturnState();
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// return returnState;
	// }
	//
	// /**
	// * B2C批量退款、包括批量退款重发
	// *
	// * @param param
	// * @return ReturnState
	// * @throws BizException
	// */
	// private ReturnState batchRefund(final String logPrefix, final String channelId, final Param
	// param,
	// Map<String, String> channelParam) throws BizException {
	// String logMsg = "";
	// logMsg = "进入" + logPrefix + "批量退款处理。";
	// Log4jUtil.info(logMsg);
	// final AbcUtil abcUtil = new AbcUtil();
	// channelParam = abcUtil.checkChannelParam(logPrefix, ChannelTransType.PayRefund,
	// channelParam);
	// final int maxNum = Integer.valueOf(channelParam.get("100013"));
	// List<String> channelBatchIdList = new ArrayList<String>();
	// try {// 开始进行清分
	// channelBatchIdList = batchRefundDistributeService.batchRefund(param, maxNum);
	// } catch (final Exception e) {
	// // 清分失败，则需要更新状态
	// if (param.getRepeatFlag().equals("N")) {// 非重发的时候才需要进行状态变更
	// batchRefundDistributeService.updateBatchRefund(param);
	// }
	// throw new BizException(logPrefix + "批量退款处理失败。");
	// }
	// final List<ReturnState> returnStateList = new ArrayList<ReturnState>();
	// Boolean allSuccess = true;
	// if (channelBatchIdList != null) {
	// for (int i = 0; i < channelBatchIdList.size(); i++) {
	// ReturnState returnState = new ReturnState();
	// try {
	// returnState = abcB2CService.senDBatchRefund(logPrefix, channelId, channelBatchIdList.get(i));
	// } catch (final BizException b) {
	// continue;
	// }
	// if (!returnState.getBankRetCode().equals("0000")) {
	// // 若发送失败，则需要更改表
	// logMsg = logPrefix + "向银行发起批量退款请求失败,Channel_BatchId：" + channelBatchIdList.get(i)
	// + "更改ChannelBatchRefund表状态为09.";
	// Log4jUtil.info(logMsg);
	// abcB2CService.updateChannelBatchRefundToFail(logPrefix, channelBatchIdList.get(i),
	// returnState);
	// }
	// returnStateList.add(returnState);
	// if (!returnState.getChannelCode().equals("0000")) {
	// allSuccess = false;
	// }
	// }
	// }
	// final ReturnState returnState = new ReturnState();
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// if (allSuccess) {
	// returnState.setChannelCode("0000");
	// } else {
	// returnState.setChannelCode("9999");
	// }
	// returnState.setReturnObj(returnStateList);
	// ObjectUtil.printPropertyString(logPrefix, returnState);
	// return returnState;
	// }
	//
	// /**
	// * B2C退货
	// *
	// * @param param
	// * @return
	// * @throws BizException
	// */
	// private ReturnState refund(final String logPrefix, final String channelId, final Param param)
	// throws BizException {
	// String logMsg = "";
	// logMsg = "进入" + logPrefix + "退货处理。";
	// Log4jUtil.info(logMsg);
	// final String sn = "";
	// final ReturnState returnState = new ReturnState();
	// RefundBean refundBean = new RefundBean();
	// refundBean = (RefundBean) param.getBizBean();
	//
	// // 1、取得退货所需要的信息
	// final String tOrderNo = refundBean.getBankSendSn();
	// final String tNewOrderNo = SequenceManager.getAbcChannelSN(DateUtil.getCurrentDate());
	// final double tTrxAmount = refundBean.getAmount();
	//
	// // 2、生成退货请求对象
	// final RefundRequest tRequest = new RefundRequest();
	// tRequest.setOrderNo(tOrderNo); // 订单号 （必要信息）
	// tRequest.setNewOrderNo(tNewOrderNo); // 新订单号 （必要信息）
	// tRequest.setTrxAmount(tTrxAmount); // 退货金额 （必要信息）
	//
	// // 3、传送退货请求并取得退货结果
	// final TrxResponse tResponse = tRequest.postRequest();
	// // 4、判断退货结果状态，进行后续操作
	// if (tResponse.isSuccess()) {
	// // 5、退货成功
	// logMsg = "TrxType:" + tResponse.getValue("TrxType");
	// logMsg = logMsg + " OrderNo:" + tResponse.getValue("OrderNo");
	// logMsg = logMsg + " NewOrderNo:" + tResponse.getValue("NewOrderNo");
	// logMsg = logMsg + " TrxAmount:" + tResponse.getValue("TrxAmount");
	// logMsg = logMsg + " BatchNo:" + tResponse.getValue("BatchNo");
	// logMsg = logMsg + " VoucherNo:" + tResponse.getValue("VoucherNo");
	// logMsg = logMsg + " HostDate:" + tResponse.getValue("HostDate");
	// logMsg = logMsg + " HostTime:" + tResponse.getValue("HostTime");
	// logMsg = logMsg + " iRspRef:" + tResponse.getValue("iRspRef");
	// Log4jUtil.info(logMsg);
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// returnState.setSn(sn);// 原交易流水
	// final String bankRetCode = "0000";
	// returnState.setBankRetCode(bankRetCode);// 银行返回状态
	// returnState.setBankPostScript(tResponse.getErrorMessage());// 银行返回状态
	//
	// ChannelRtncode channelRtncode = null;
	// channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
	// bankRetCode));
	// if (channelRtncode == null) {
	// logMsg = "表  channel_rtncode 没有对应的" + logPrefix + "银行返回信息" + bankRetCode;
	// Log4jUtil.info(logMsg);
	// returnState.setReturnMsg(logMsg);
	// returnState.setChannelCode(TransReturnCode.code_9900);
	// } else {
	// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
	// returnState.setChannelCode(channelRtncode.getKftRtncode());
	// }
	// ObjectUtil.printPropertyString(logPrefix, returnState);
	// } else {
	// logMsg = logPrefix + "向银行发起退货请求失败,SN：" + sn + " ReturnCode:" + tResponse.getReturnCode() +
	// " ErrorMessage:"
	// + tResponse.getErrorMessage();
	// Log4jUtil.info(logMsg);
	// throw new BizException(logMsg);
	// }
	// return returnState;
	//
	// }
	//
	// /**
	// * B2C订单查询
	// *
	// * @param param
	// * @return
	// * @throws BizException
	// */
	// private ReturnState queryOrder(final String logPrefix, final String channelId, final Param
	// param)
	// throws BizException {
	// String logMsg = "";
	// logMsg = "开始" + logPrefix + "订单查询处理。";
	// Log4jUtil.info(logMsg);
	// // 1、取得商户订单查询所需要的信息 订单号
	// String sn = "";
	// String tOrderNo = "";// 先获取原订单号，再到billno查发往银行的订单号
	// // 根据不同的业务，取不同的实体,获取订单号
	// if (param.getTransType().equals(ClearingTransType.Direct_Pay)
	// || param.getTransType().equals(ClearingTransType.Guarantee_Pay)
	// || param.getTransType().equals(ClearingTransType.Protocol_Debit_Real)) {
	// logMsg = logPrefix + "获取待查询的支付对象。";
	// Log4jUtil.info(logMsg);
	// final Paybill paybill = (Paybill) param.getBizBean();
	// if (paybill == null) {
	// throw new BizException(logPrefix + "获取到的支付对象为NULL。");
	// }
	// sn = paybill.getSn();
	// } else if (param.getTransType().equals(ClearingTransType.Recharge)) {
	// logMsg = logPrefix + "获取待查询的充值对象。";
	// Log4jUtil.info(logMsg);
	// final Rechargebill rechargeBill = (Rechargebill) param.getBizBean();
	// if (rechargeBill == null) {
	// throw new BizException(logPrefix + "获取到的充值对象为NULL。");
	// }
	// sn = rechargeBill.getSn();
	// } else {
	// logMsg = logPrefix + "错误的交易类型。";
	// Log4jUtil.info(logMsg);
	// throw new BizException(logMsg);
	// }
	// tOrderNo = billnoSnService.findBankSendSnBySn(sn);
	// AssertUtils.notEmpty(tOrderNo, logPrefix + "根据交易流水：" + sn + " 查询不到发往银行的订单号！");
	// final ReturnState returnState = new ReturnState();
	// final String tQueryType = "1";
	// boolean tEnableDetailQuery = false;
	// if (tQueryType.equals("1")) {
	// tEnableDetailQuery = true;
	// }
	// // 2、生成商户订单查询请求对象
	// final QueryOrderRequest tRequest = new QueryOrderRequest();
	// tRequest.setOrderNo(tOrderNo); // 订单号 （必要信息）
	// tRequest.enableDetailQuery(tEnableDetailQuery); // 是否查询详细信息 （必要信息）
	//
	// // 3、传送商户订单查询请求并取得订单查询结果
	// logMsg = logPrefix + "向银行发起交易流水为：" + sn + " 订单号为:" + tOrderNo + "查询请求。";
	// Log4jUtil.info(logMsg);
	// final TrxResponse tResponse = tRequest.postRequest();
	// // 4、判断商户订单查询结果状态，进行后续操作
	// if (tResponse.isSuccess()) {
	// logMsg = logPrefix + "成功获取到银行返回的的B2C订单查询对象。";
	// Log4jUtil.info(logMsg);
	// // 5、生成订单对象
	// final Order tOrder = new Order(new XMLDocument(tResponse.getValue("Order")));
	// // //6、取得订单明细
	// // ArrayList tOrderItems = tOrder.getOrderItems();
	// // for (int i = 0; i < tOrderItems.size(); i++) {
	// // OrderItem tOrderItem = (OrderItem) tOrderItems.get(i);
	// // }
	// returnState.setReturnState(PayState.SUCCEED_RTN);
	// returnState.setSn(sn);// 原交易流水
	// final String bankRetCode = ChannelTransType.Qury_Single_Trans + tOrder.getOrderStatus();
	// returnState.setBankRetCode(bankRetCode);// 银行返回状态
	// returnState.setBankPostScript(tResponse.getErrorMessage());// 银行返回状态
	// /* 订单状态 前面加上 ChannelTransType 810202
	// 00：订单已取消
	// 01：订单已建立，等待支付
	// 02：消费者已支付，等待支付结果
	// 03：订单已支付（支付成功）
	// 04：订单已结算（支付成功）
	// 05：订单已退款
	// 99：订单支付失败 */
	// // 取得渠道返回信息，存入param.returnMsg 中
	// ChannelRtncode channelRtncode = null;
	// channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
	// bankRetCode));
	// if (channelRtncode == null) {
	// logMsg = "表  channel_rtncode 没有对应的" + logPrefix + "银行返回信息" + bankRetCode;
	// Log4jUtil.info(logMsg);
	// returnState.setReturnMsg(logMsg);
	// returnState.setChannelCode(TransReturnCode.code_9900);
	// } else {
	// returnState.setReturnMsg(channelRtncode.getChannelReamrk());
	// returnState.setChannelCode(channelRtncode.getKftRtncode());
	// }
	// ObjectUtil.printPropertyString(logPrefix, returnState);
	// return returnState;
	// } else {
	// logMsg = logPrefix + "向银行发起订单查询请求失败,SN：" + sn + " ReturnCode:" + tResponse.getReturnCode()
	// + " ErrorMessage:" + tResponse.getErrorMessage();
	// Log4jUtil.info(logMsg);
	// throw new BizException(logMsg);
	// }
	// }
}
