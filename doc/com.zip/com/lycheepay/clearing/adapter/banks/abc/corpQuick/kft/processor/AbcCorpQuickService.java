package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.processor;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util.SequenceUtil;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util.TranProcessUtil;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util.BatchBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util.BatchNoticeBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.RefundBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.AmountUtils;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;


@Service(ClearingAdapterAnnotationName.ABC_CORP_QUICK_SERVICE)
public class AbcCorpQuickService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_QUICK_MSGDEAL)
	private CorpAbcQuickMsgDeal corpAbcQuickMsgDeal;

	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;

	private final static String channelId = ChannelIdEnum.ABC_QUICK_PAY.getCode();

	private final String line = System.getProperty("line.separator"); // 回车换行符
	private final String vline = "|"; // 分隔符

	@Autowired
	@Qualifier("abcquick.tranProcessUtil")
	private TranProcessUtil tranProcess;

	/**
	 * 
	 * @param trantype
	 * @param objectList
	 * @param string
	 * @return
	 * @throws BizException
	 */
	public BatchBean sendBatch(String trantype, List<ChannelTempBill> objectList, String channelBatchid)
			throws BizException {
		BatchBean batchBean = new BatchBean();

		BatchNoticeBean b = corpAbcQuickMsgDeal.createFileName(trantype, "SRC");
		String batchFileName = b.getFileName();

		// 取得平台的账户信息
		BankaccountBalance acc = bankAccountBalanceService.getBankaccountBean(channelId);
		AssertUtils.notNull(acc, TransReturnCode.code_9108, "农行快捷取得平台的账户信息失败！channelBankAccount的交易类型为：" + trantype);
		String CorpAcctNo = acc.getAccountNo();
		String CorpAcctName = acc.getAccountName();
		String CorpBankNo = acc.getBankNo();

		// 生成批量处理文件，FTP到服务器,保存记录到 billnoSn表。
		String channelBatchNo = channelBatchid;
		b = this.createFtpSend(b, channelBatchNo, trantype, objectList, batchFileName, CorpAcctNo, CorpAcctName,
				CorpBankNo); // 返回值为 "总记录数|总金额"

		// 文件接收通知交易,发送与接收
		ReturnState noticeRs = this.sendBatchNotice(b);

		batchBean.setReturnState(noticeRs);
		batchBean.setChannelBatchNo(channelBatchNo);
		batchBean.setTrantype(trantype);
		return batchBean;
	}

	private ReturnState sendBatchNotice(BatchNoticeBean batchNoticeBean) throws BizException {
		return corpAbcQuickMsgDeal.sendBatchTrasNotice(batchNoticeBean);
	}

	/**
	 * 
	 * @param channelBatchNo
	 * @param trantype
	 * @param objectList
	 * @param batchFileName
	 * @param corpAcctNo
	 * @param corpAcctName
	 * @param corpBankNo
	 * @return
	 * @throws BizException
	 */
	private BatchNoticeBean createFtpSend(BatchNoticeBean b, String channelBatchNo, String trantype,
			List<ChannelTempBill> objectList, String batchFileName, String corpAcctNo, String corpAcctName,
			String corpBankNo) throws BizException {

		double[] rs = this.createBillnosnBatchFile(channelBatchNo, trantype, objectList, batchFileName, corpAcctNo,
				corpAcctName, corpBankNo);

		// 1、 生成批量代收业务文件，保存记录到 billnoSn表，返回总金额
		java.text.DecimalFormat df = new java.text.DecimalFormat("0");// ""0.00"小数点后面的0的个数表示小数点的个数
		b.setTotalNum(String.valueOf(objectList.size()).trim()); // 返回总记录数
		b.setTotalAmt(df.format(rs[0] * 100));
		b.setFileSize(rs[1]);

		// 2、 FTP 文件到服务器
		corpAbcQuickMsgDeal.uploadFileToSftp(batchFileName);
		return b;
	}

	/**
	 * @param channelBatchNo
	 * @param trantype
	 * @param paybillList
	 * @param batchFileName
	 * @param corpAcctNo
	 * @param corpAcctName
	 * @param corpBankNo
	 * @return
	 */
	private double[] createBillnosnBatchFile(String channelBatchNo, String trantype, List<ChannelTempBill> billList,
			String fileName,
			String corpAcctNo, String corpAcctName, String corpBankNo) throws BizException {
		// 文件字段4个
		String banckSendSn;// 流水号 20C
		String otherBankCardNo;// 客户账号 C20
		String channelAmount;// 交易金额 N18.2
		String otherBankCardName;// 客户姓名 C70

		String fileStr;// 保存文件内容
		Double dAmtTotal = 0.0;

		// 文件体：流水号|账号|金额|户名|证件类型|证件号|
		StringBuilder sbContent = new StringBuilder();// 临时内容变量

		ChannelTempBill paybill = null;
		List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>(billList.size());
		for (int i = 0; i < billList.size(); i++) {
			paybill = billList.get(i);

			banckSendSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());
			// banckSendSn = addSpaceForNum(banckSendSn, 20);// 流水号 20C

			otherBankCardNo = proAccount(paybill.getBankAccountNo());
			// otherBankCardNo = addSpaceForNum(otherBankCardNo, 20);// 账号 20C

			channelAmount = MoneyUtil.getFenString(paybill.getAmount());
			// channelAmount = addSpaceForNum(channelAmount, 18);// 金额 18N

			otherBankCardName = paybill.getBankAccountHolder();
			// otherBankCardName = addSpaceForNum(otherBankCardName, 70);// 户名 70C

			dAmtTotal = dAmtTotal + paybill.getAmount().doubleValue();

			// 文件体：流水号|账号|金额|户名|证件类型|证件号|
			sbContent.append(banckSendSn).append(vline).append(otherBankCardNo).append(vline).append(channelAmount)
					.append(vline).append(otherBankCardName).append(vline).append(vline).append(vline).append(line);
			billNoSnList.add(toBillnoSn(banckSendSn.trim(), channelBatchNo, trantype, paybill, i, corpAcctNo,
					corpAcctName, corpBankNo));
		}
		billnoSnService.batchSave(billNoSnList);
		// 文件头：总笔数|总金额|
		StringBuilder sbHead = new StringBuilder();

		// String strAmtTotal = addSpaceForNum(MoneyUtil.getFenString(new BigDecimal(dAmtTotal)),
		// 18);
		String strAmtTotal = MoneyUtil.getFenString(new BigDecimal(dAmtTotal));
		sbHead.append(billList.size()).append(vline).append(strAmtTotal).append(vline).append(line);

		String headAndContent = sbHead.append(sbContent).toString();

		// 文件尾：MD5校验码
		String md5 = this.enCrypt(headAndContent);

		fileStr = headAndContent + md5;
		Log4jUtil.info("批量业务的批量文件内容:");
		Log4jUtil.info(fileStr);

		try {
			Log4jUtil.info("批量业务的批量文件文件名:" + fileName);
			// CreateAccFile方法生成文件，返回文件名(含上级文件夹)，返回参数这里用不着
			corpAbcQuickMsgDeal.createBatchFile(fileName, fileStr); // 文件名+文件内容
		} catch (BizException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9108, "生成批量代收文件 [" + fileName + "] 异常：" + e.getMessage());
		}
		double[] rs = new double[2];
		rs[0] = dAmtTotal;
		rs[1] = fileStr.getBytes(Charset.forName("GBK")).length;
		return rs;
	}

	/**
	 * 加密
	 * 
	 * @param string
	 * @return
	 * @throws BizException
	 */
	private String enCrypt(String data) throws BizException {
		ChannelParm md5key = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "200003"));
		AssertUtils.notNull(md5key, TransReturnCode.code_9108, "未得到md5CodeKey");
		return tranProcess.md5Created(data, md5key.getParvalue());
	}

	/**
	 * 
	 * @param banckSendSn
	 * @param channelBatchNo
	 * @param tranType
	 * @param object
	 * @param i
	 * @param corpAcctNo
	 * @param corpAcctName
	 * @param corpBankNo
	 * @throws BizException
	 */
	private BillnoSn toBillnoSn(String banckSendSn, String channelBatchNo, String tranType, ChannelTempBill paybill,
			int i, String corpAcctNo, String corpAcctName, String corpBankNo) throws BizException {

		String otherAcctNo = paybill.getBankAccountNo(); // 对方帐号
		String otherAcctName = paybill.getBankAccountHolder(); // 对方账户名
		String otherBankNo = paybill.getBankCode(); // 对方行号
		String otherCust_Id = paybill.getCustomerId(); // 对方客户编号
		String otherBankAddrNo = paybill.getBankAreaCode();// 对方开户行地区代码
		String createTime = DateUtil.getDate(paybill.getCreateTime()); // 交易的平台交易日期
		String bank_Type = paybill.getBankType(); // 行别
		// String orderid = ""; // 订单号
		// String srcCust_Id = ""; // 发起方客户编号 业务发起者

		String batchID = paybill.getChannelBatchId(); // 批次号
		String detailID = String.valueOf(i + 1); // 明细序号

		// 写交易流水和渠道流水对照表
		BillnoSn billnoSn = new BillnoSn();
		billnoSn.setBillnosnSeq(sequenceManagerService.getBillnoSnSeq());
		billnoSn.setSn(paybill.getBizBillSn());// 平台业务流水，billnoSn 主键
		billnoSn.setChannelid(channelId);
		billnoSn.setBankSendSn(banckSendSn); // 银行订单号，这里填场次号
		billnoSn.setTranDate(createTime);
		// billnoSn.setCheckDate(DateUtil.getCurrentDate()); //轧差日期 收到回执报文后更新
		billnoSn.setChannelBatchno(channelBatchNo);// 渠道批次 批量交易使用
		billnoSn.setChannelDetail(SequenceUtil.formatSeq((i + 1), 8));// 渠道明细
		// 批量交易使用
		// billnoSn.setBankRecvSn(returnState.getSn()); // 接收流水
		billnoSn.setAmount(paybill.getAmount()); // 平台交易金额
		// billnoSn.setActualAmount(returnState.getRelTranAmount());//实际交易金额
		billnoSn.setTranType(tranType);
		billnoSn.setState(BillnoSnState.billnoSend); // 00：已发送 01: 已收到中心确认 02：业务回执已返回
		billnoSn.setBatchid(batchID); // 批次号 对应于原交易
		billnoSn.setDetailid(detailID);// 批量业务明细序号 对应于原交易
		// billnoSn.setChannelRtncode(returnState.getBankRetCode()); //渠道返回码
		// billnoSn.setChannelRtnnote(returnState.getReturnMsg()); //渠道返回附言
		billnoSn.setSendTime(new Date());
		// billnoSn.setRecvTime(new Date()); //返回时间

		billnoSn.setCorpacctno(corpAcctNo); // 企业帐号 对应渠道绑定的帐号
		billnoSn.setCorpacctname(corpAcctName);// 企业户名 对应渠道绑定的帐号名
		billnoSn.setCorpbankno(corpBankNo);// 企业行号

		billnoSn.setOtheracctno(otherAcctNo);// 对方帐号
		billnoSn.setOtheracctname(otherAcctName);// 对方户名
		billnoSn.setOtherbankno(otherBankNo);// 对方行号
		billnoSn.setOtherbankaddrno(otherBankAddrNo);// 对方开户行地区代码
		billnoSn.setOthercustId(otherCust_Id);// 对方客户编号

		billnoSn.setBankType(bank_Type);// 行别(非空）
		// billnoSn.setSrccustId(srcCust_Id);// 发起方客户编号
		// billnoSn.setFeecode("");//费项代码(只有同城用到)
		// billnoSn.setFeedesc("");//费项说明(只有同城用到)
		billnoSn.setOrderid(paybill.getBizTxnId());// 订单号
		billnoSn.setBankCardType(paybill.getCardType() != null ? paybill.getCardType().toString()
				: BankCardType.UNDISTINGUISH);
		return billnoSn;
	}

	/**
	 * 
	 * @param otherBankCardNo
	 * @return
	 */
	public String proAccount(String oriAccount) {
		// if (oriAccount.length() < 10) {
		// Log4jUtil.info("账号:" + oriAccount + "长度小于10，不做账号处理，返回传入账号");
		// return oriAccount;
		// }
		// String newAccount = "";
		// 处理原则
		// 1、卡是19位
		// 2、存折是17个数字
		// 3、卡就是95599，6228开头的
		// if (oriAccount.length() == 19) {
		// newAccount = oriAccount;
		// } else if (oriAccount.contains("-")) {
		// newAccount = oriAccount;
		// } else {
		// newAccount = oriAccount.substring(0, 2) + "-" + oriAccount.substring(2);
		// }
		return oriAccount;
	}

	/**
	 * 处理批量业务查询返回的交易
	 * 
	 * @param channelBatchId 农行快捷系统请求渠道批次ID
	 * @param fileNameRcvPath 批量结果文件（含相对路径）
	 * @param tranDate
	 * @throws BizException
	 */
	public void predeal(String channelBatchId, String fileNameRcvPath, String checkDate) throws BizException {
		// 统计合计数据，用于保存到 表
		Long totalNumSuc = 0L; // 成功总笔数
		Double totalAmtSuc = 0.0; // 成功总金额
		Long totalNumFail = 0L; // 失败总笔数
		Double totalAmtFail = 0.0; // 失败总金额
		// String tranType = ""; // 平台业务类型

		// 文件头：总笔数|总金额|成功笔数|成功金额|手续费|
		String numR = "", numSucR = "";
		double amtR = 0.0, amtSucR = 0.0, feeR = 0.0;

		// 文件体：流水号|账号|新账号|金额|本异地标志|返回码|返回信息|
		String bankSn = "";// 流水号
		String account = "";// 账号
		String newAccount = "";// 新账号
		double amt = 0.0;// 交易金额
		String adrFalg = "";// 本异地标志
		String retCode = "";// 返回码
		String retMsg = "";// 返回信息
		Double doubleAmt = 0.0;// 交易金额 Double 类型

		BillnoSn billnoSn = new BillnoSn();

		String s = null; // 判断文件是否读完
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(fileNameRcvPath),
					Charset.forName("GBK")));
		} catch (FileNotFoundException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "错误：找不到农行银企批量文件：" + fileNameRcvPath);
		}

		try {
			// 文件头：总笔数|总金额|成功笔数|成功金额|手续费|
			s = bufferedReader.readLine();
			String[] es = s.split("\\|");
			numR = es[0].trim();
			amtR = Double.valueOf(es[1].trim()) / 100;
			numSucR = es[2].trim();
			amtSucR = Double.valueOf(es[3].trim()) / 100;
			feeR = Double.valueOf(es[4].trim()) / 100;

			Log4jUtil.info("-----------文件头信息---总笔数:" + numR + " 总金额:" + amtR + " 成功笔数:" + numSucR + " 成功金额:" + amtSucR
					+ " 手续费:" + feeR);
		} catch (IOException e1) {
			Log4jUtil.error(e1);
		}

		// 文件体：流水号|账号|新账号|金额|本异地标志|返回码|返回信息|
		try {
			int n = 1;
			List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>();
			while ((s = bufferedReader.readLine()) != null) {
				n++;
				String[] es = s.split("\\|");
				if (es.length < 7)
					continue;

				bankSn = es[0].trim();
				account = es[1].trim();
				newAccount = es[2].trim();
				amt = Double.valueOf(es[3].trim()) / 100;

				adrFalg = es[4].trim(); // S-成功 E-失败
				retCode = es[5].trim();
				retMsg = es[6].trim();

				Log4jUtil.info("-----------第" + n + "行的明细-----bankSn:" + bankSn + " account:" + account
						+ " newAccount:" + newAccount + " amt:" + amt + " adrFalg:" + adrFalg + " retCode:" + retCode
						+ " retMsg:" + retMsg);

				doubleAmt = amt;

				// 更新billnoSn表;Channel_Batch表
				billnoSn = billnoSnService.getBillnoSn(channelId, bankSn);
				AssertUtils.notNull(billnoSn, TransReturnCode.code_9108, "在表 billnoSn 中找不到批量返回的交易记录，交易记录详细信息如下："
						+ "渠道ID：" + channelId + "渠道批次："
						+ channelBatchId + "对方客户编号：" + bankSn + "对方户名：" + account + "对方帐号：" + newAccount + "交易金额："
						+ amt);

				// 给 ChannelBatch 表做记录汇总
				if (retCode.equals("0000")) {
					totalNumSuc = totalNumSuc + 1; // SucessNum 成功总笔数
					totalAmtSuc = totalAmtSuc + amt; // 成功总金额
					billnoSn.setPayState("1");// 成功1
				} else {
					totalNumFail = totalNumFail + 1; // UnSucessNum 失败总笔数
					totalAmtFail = totalAmtFail + amt; // 失败总金额
					billnoSn.setPayState("2");// 失败2
				}

				// b2.更新billnoSn表的STATE字段
				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
				billnoSn.setRecvTime(new Date()); // 返回时间
				billnoSn.setActualAmount(new BigDecimal(doubleAmt)); // 渠道实际支付金额
				billnoSn.setCheckDate(checkDate); // 收到回执报文后更新
				billnoSn.setBankRecvSn(bankSn);// 银行返回的流水号
				billnoSn.setChannelRtncode(retCode);
				billnoSn.setChannelRtnnote(retMsg); // 渠道返回附言
				billNoSnList.add(billnoSn);
			}
			billnoSnService.batchUpdateByPrimary(billNoSnList);

			// 循环结束,检查数据
			if (Long.valueOf(numR) == (totalNumSuc + totalNumFail) && AmountUtils.et(amtSucR, totalAmtSuc)
					&& AmountUtils.et(amtR, totalAmtSuc + totalAmtFail)) {
			} else {
				Log4jUtil.info("批量交易结果文件中的文件头与文件体不笔数或金额不相符，请人工检查结果文件是否正确。");
			}

			// 更新ChannelBatch多个字段
			batchProcessResultNotice.process(channelId, channelBatchId, billnoSn.getTranType(), totalNumSuc,
					totalAmtSuc, totalNumFail, totalAmtFail);

			// // 获取平台业务类型
			// tranType = billnoSn.getTranType();
			// AssertUtils.notNull(tranType, "异常，获取的业务类型为空值");
			// // 更新ChannelBatch多个字段 ；找到ChannelBatch表唯一记录;更新ChannelBatch表记录
			// ChannelBatch channelBatch = new ChannelBatch();
			// channelBatch = channelBatchService.findById(new ChannelBatchId(channelId,
			// channelBatchId));
			// AssertUtils.notNull(channelBatch, "在表 channelBatch 中找不到批量返回的交易记录，交易记录详细信息如下：" +
			// "渠道ID：" + channelId
			// + "渠道批次：" + channelBatchId);
			// Long totalamount = channelBatch.getTotalnum(); // 总笔数
			// if ((totalNumSuc + totalNumFail) == totalamount) {
			// channelBatch.setState("03"); // 03：回执全部返回
			// } else if ((totalNumSuc + totalNumFail) > 0) {
			// channelBatch.setState("02"); // 02：回执部分返回
			// } else {
			// // 不修改表的状态字段
			// }
			// channelBatch.setSucessnum(totalNumSuc);
			// channelBatch.setSucessamount(totalAmtSuc);
			// channelBatch.setUnsucessnum(totalNumFail);
			// channelBatch.setUnsucessamount(totalAmtFail);
			// channelBatchService.save(channelBatch);

			// Log4jUtil.info("调用平台处理 CallBizAdapter.dealBatchQuery() start...");
			// CallBizAdapter.dealBatchQuery(channelId, tranType, channelBatchId);
			// Log4jUtil.info("调用平台处理 CallBizAdapter.dealBatchQuery() end...");
		} catch (IOException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "错误：读文件’" + fileNameRcvPath + "‘出错！");
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					Log4jUtil.error("文件关闭异常！", e);
					throw new BizException(TransReturnCode.code_9109, "错误：文件’" + fileNameRcvPath + "关闭异常！");
				}
			}
		}
	}

	/**
	 * 处理批量业务查询返回的交易
	 * 
	 * @param channelBatchId 农行快捷系统请求渠道批次ID
	 * @param fileNameRcvPath 批量结果文件（含相对路径）
	 * @param tranDate
	 * @throws BizException
	 */
	public void predealFail(String channelBatchId, String checkDate, String rtnNote, String retCode, Double totalAmt)
			throws BizException {

		Log4jUtil.info("---【渠道批次ID】为：{}的 批交易全部失败处理开始---", channelBatchId);
		List<BillnoSn> list = billnoSnService.findBillnoSnByChanneiIdAndBatchId(channelId, channelBatchId);
		if (list == null || list.size() == 0) {
			throw new BizException(TransReturnCode.code_9108, StringUtil.r("【渠道批次ID】为：{?}的批次 在渠道流水表中没有找到记录",
					channelBatchId));
		}

		Double totalAmtFail = 0d;
		BillnoSn billnoSn = new BillnoSn();
		for (int i = 0; i < list.size(); i++) {
			billnoSn = list.get(i);
			totalAmtFail = totalAmtFail + billnoSn.getAmount().doubleValue();
		}


		Long totalNumSuc = 0L, totalNumFail = (long) list.size();
		Double totalAmtSuc = 0d;


		// 检查批次总金额是否与回执报文相同.
		Log4jUtil.info("---------检查批次总金额是否与回执报文相同..");
		if (!AmountUtils.equals(totalAmt, totalAmtFail)) {
			throw new BizException(TransReturnCode.code_9109, StringUtil.r(
					"【渠道批次ID】为：{?}的批次总金额是:{?},银行回执的总金额是:{?},两者不一致,请人工核实!", channelBatchId,
					totalAmtFail.doubleValue(), totalAmt.doubleValue()));
		}

		// 批量更新billnoSn
		Log4jUtil.info("---------批量更新billnoSn 开始..");
		billnoSnService.updateByChannelBatchId(channelBatchId, channelId, BillnoSnState.billnoRecv, retCode, rtnNote,
				"2", new Date(), checkDate);
		Log4jUtil.info("---------批量更新billnoSn 完成");

		// 更新ChannelBatch多个字段
		Log4jUtil.info("---------更新ChannelBatch多个字段  开始..");
		batchProcessResultNotice.process(channelId, channelBatchId, billnoSn.getTranType(), totalNumSuc, totalAmtSuc,
				totalNumFail, totalAmtFail);
		Log4jUtil.info("---------更新ChannelBatch多个字段  结束..");
	}

	/**
	 * 
	 * @Description: 实时退款
	 * @param newBankSendSn
	 * @param autoRealTimeRefund
	 * @return
	 * @throws BizException
	 */
	public ReturnState RealTimeRefund(String bankSendSnNew, AutoRealTimeRefund autoRealTimeRefund, BillnoSn billnoSn)
			throws BizException {
		RefundBean bizBean = new RefundBean();
		String accountNo = autoRealTimeRefund.getRevBankCardNo();
		String accountName = autoRealTimeRefund.getRevBankCardName();

		bizBean.setAmount(autoRealTimeRefund.getRefundAmount());
		bizBean.setRefundType("01");

		bizBean.setBankSendSn(bankSendSnNew);
		bizBean.setBankRecvSn(billnoSn.getBankRecvSn());
		bizBean.setTranDate(billnoSn.getTranDate());
		bizBean.setBillnosnSeq(billnoSn.getBillnosnSeq());

		ReturnState rs = null;
		rs = corpAbcQuickMsgDeal.dealPayRefund(bizBean, autoRealTimeRefund.getSn(), accountNo, accountName);
		return rs;
	}
}
