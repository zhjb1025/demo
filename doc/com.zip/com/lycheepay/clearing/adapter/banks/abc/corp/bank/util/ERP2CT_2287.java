package com.lycheepay.clearing.adapter.banks.abc.corp.bank.util;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_2287Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcSend2CT_Vc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;


@Service
public class ERP2CT_2287 {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_SEND2CT_VC)
	private AbcSend2CT_Vc abcSend2CT_Vc;
	/**
	 * 创建农行2287报文
	 * 
	 * @author aps-kxj
	 * @param queryParam
	 * @date 2011-03-19
	 * @return 2287报文
	 * @throws BizException
	 */
	public String sendXMLFile(final ERP2CT_PublicBean eRP2CT_PublicBean, final ERP2CT_2287Bean eRP2CT_2287Bean)
			throws BizException {
		// 使用DocumentHelper.createDocument方法建立一个文档实例
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 使用addElement方法方法创建根元素
		final Element apElement = document.addElement("ap");

		// 使用addElement方法向ap元素添加TransCode子元素
		final Element TransCode = apElement.addElement("TransCode");
		TransCode.setText(eRP2CT_PublicBean.getTransCode());

		// 使用addElement方法向ap元素添加ChannelType子元素
		final Element ChannelType = apElement.addElement("ChannelType");
		ChannelType.setText(eRP2CT_PublicBean.getChannelType());

		// 使用addElement方法向ap元素添加CorpNo子元素
		final Element CorpNo = apElement.addElement("CorpNo");
		CorpNo.setText(eRP2CT_PublicBean.getCorpNo());

		// 使用addElement方法向ap元素添加OpNo子元素
		final Element OpNo = apElement.addElement("OpNo");
		OpNo.setText(eRP2CT_PublicBean.getOpNo());

		// 使用addElement方法向ap元素添加Version子元素
		final Element ChannelElement = apElement.addElement("Channel");
		final Element Online = ChannelElement.addElement("Online");
		Online.setText("");

		// 使用addElement方法向ap元素添加AuthNo子元素
		final Element AuthNo = apElement.addElement("AuthNo");
		AuthNo.setText(eRP2CT_PublicBean.getAuthNo());

		// 使用addElement方法向ap元素添加__子元素
		final Element ReqSeqNo = apElement.addElement("ReqSeqNo");
		ReqSeqNo.setText(eRP2CT_PublicBean.getReqSeqNo());

		// 使用addElement方法向ap元素添加__子元素
		final Element ReqDate = apElement.addElement("ReqDate");
		ReqDate.setText(eRP2CT_PublicBean.getReqDate());

		// 使用addElement方法向ap元素添加ReqTime子元素
		final Element ReqTime = apElement.addElement("ReqTime");
		ReqTime.setText(eRP2CT_PublicBean.getReqTime());

		// 使用addElement方法向ap元素添加Sign子元素
		final Element Sign = apElement.addElement("Sign");
		Sign.setText(eRP2CT_PublicBean.getSign());

		// 使用addElement方法向ap元素添加Version子元素
		final Element VersionElement = apElement.addElement("Version");
		final Element CcVersion = VersionElement.addElement("CcVersion");
		CcVersion.setText(eRP2CT_PublicBean.getCcVersion());

		// 使用addElement方法向ap元素添加Amt子元素
		final Element AmtName = apElement.addElement("Amt");
		AmtName.setText(eRP2CT_2287Bean.getAmt());

		// 使用addElement方法向ap元素添加Corp子元素
		final Element CorpElement = apElement.addElement("Corp");

		final Element BookingDateName = CorpElement.addElement("BookingDate");
		BookingDateName.setText(eRP2CT_2287Bean.getBookingDate());

		final Element BookingTimeName = CorpElement.addElement("BookingTime");
		BookingTimeName.setText(eRP2CT_2287Bean.getBookingTime());

		final Element BookingFlagName = CorpElement.addElement("BookingFlag");
		BookingFlagName.setText(eRP2CT_2287Bean.getBookingFlag());

		final Element PostscriptName = CorpElement.addElement("Postscript");
		PostscriptName.setText(eRP2CT_2287Bean.getPostscript());

		Element CrAccNameName = CorpElement.addElement("CrAccName");
		CrAccNameName.setText(eRP2CT_2287Bean.getCrAccName());

		final Element CrBankNameName = CorpElement.addElement("CrBankName");
		CrBankNameName.setText(eRP2CT_2287Bean.getCrBankName());

		final Element CrActCodeName = CorpElement.addElement("CrActCode");
		CrActCodeName.setText(eRP2CT_2287Bean.getCrActCode());

		final Element CshDraFlagName = CorpElement.addElement("CshDraFlag");
		CshDraFlagName.setText(eRP2CT_2287Bean.getCshDraFlag());

		final Element VoucherTypeName = CorpElement.addElement("VoucherType");
		VoucherTypeName.setText(eRP2CT_2287Bean.getVoucherType());

		final Element VoucherNoName = CorpElement.addElement("VoucherNo");
		VoucherNoName.setText(eRP2CT_2287Bean.getVoucherNo());

		// Element AgtDbIndName = CorpElement.addElement("AgtDbInd");
		// AgtDbIndName.setText(eRP2CT_2287Bean.getAgtDbInd());
		//
		// Element AgtDbProvName = CorpElement.addElement("AgtDbProv");
		// AgtDbProvName.setText(eRP2CT_2287Bean.getAgtDbProv());
		//
		// Element AgtDbAccNoName = CorpElement.addElement("AgtDbAccNo");
		// AgtDbAccNoName.setText(eRP2CT_2287Bean.getAgtDbAccNo());
		//
		// Element AgtDbCurName = CorpElement.addElement("AgtDbCur");
		// AgtDbCurName.setText(eRP2CT_2287Bean.getAgtDbCur());
		//
		// Element AgtDbNameName = CorpElement.addElement("AgtDbName");
		// AgtDbNameName.setText(eRP2CT_2287Bean.getAgtDbName());
		//
		// Element PostscriptResName = CorpElement.addElement("PostscriptRes");
		// PostscriptResName.setText(eRP2CT_2287Bean.getPostscriptRes());

		// 使用addElement方法向ap元素添加Cmp子元素
		final Element CmpElement = apElement.addElement("Cmp");

		final Element DbAccNoName = CmpElement.addElement("DbAccNo");
		DbAccNoName.setText(eRP2CT_2287Bean.getDbAccNo());

		final Element DbProvName = CmpElement.addElement("DbProv");
		DbProvName.setText(eRP2CT_2287Bean.getDbProv());

		final Element DbCurName = CmpElement.addElement("DbCur");
		DbCurName.setText(eRP2CT_2287Bean.getDbCur());

		final Element DbLogAccNoName = CmpElement.addElement("DbLogAccNo");
		DbLogAccNoName.setText(eRP2CT_2287Bean.getDbLogAccNo());

		final Element CrAccNoName = CmpElement.addElement("CrAccNo");
		CrAccNoName.setText(eRP2CT_2287Bean.getCrAccNo());
		// CrAccNoName.setText("003600460011590");

		final Element CrProvName = CmpElement.addElement("CrProv");
		CrProvName.setText(eRP2CT_2287Bean.getCrProv());
		// CrProvName.setText("41");

		final Element CrCurName = CmpElement.addElement("CrCur");
		CrCurName.setText(eRP2CT_2287Bean.getCrCur());

		final Element ConFlagName = CmpElement.addElement("ConFlag");
		ConFlagName.setText(eRP2CT_2287Bean.getConFlag());

		// 使用addElement方法向ap元素添加Version子元素
		// Element CmeElement = apElement.addElement("Cme");
		// Element CcIp = CmeElement.addElement("CcIp");
		// CcIp.setText("172.100.0.121");

		final String xmlInfo = document.asXML();
		final int begin = xmlInfo.indexOf("<ap>");
		String xml2287Info = xmlInfo.substring(begin, xmlInfo.length());
		Log4jUtil.info("Xml2287Info : " + xml2287Info);
		String resultXml = abcSend2CT_Vc.launch(xml2287Info);
		/*
		二、使用Dom4j
		1.Xml字符串--->Xml Document【org.dom4j.Document】
		     String xmlStr = "";
		     Documenet doc = DocumentHelper.parseText(xmlStr);
		2.Xml Document--->Xml字符串
		     String xmlStr = document.asXml();
		*/
		// 生成文件
		/*        XMLWriter output;
		        //输出格式化
		        OutputFormat format = OutputFormat.createPrettyPrint();
		        format.setEncoding("GBK");
		        try {
		            output = new XMLWriter(new FileWriter("d:/ERP2CT_2287.XML"), format);
		            output.write(document);
		            output.close();
		        } catch (IOException e) {
		            Log4jUtil.error( e);
		        }*/

		return resultXml;
	}
}
