package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_2287Bean {

	// ERP2CT_2287 费用报销（2287） 请求报文字段
	private String Amt;  // 金额
	private String BookingDate;  // 预约日期
	private String BookingTime;  // 预约时间
	private String BookingFlag;  // 预约标志
	private String CrActCode;  // 借记卡帐户序号 #固定值 0000
	private String CshDraFlag;  // 钞汇标志 #0 - 钞 1 - 汇
	private String VoucherType;  // 凭证种类 # 固定值 0
	private String VoucherNo;  // 凭证号 # 固定值 0
	private String AgtDbInd;  // 集中代理支付标志
	private String AgtDbProv;  // 内部省市代码
	private String AgtDbAccNo;  // 内部账号
	private String AgtDbCur;  // 内部货币码
	private String AgtDbName;  // 内部户名
	private String PostscriptRes;  // 附言预留
	private String DbAccNo;  // 借方账号
	private String DbProv;  // 借方省市代码
	private String DbCur;  // 借方货币号
	private String DbLogAccNo;  // 借方逻辑帐号
	private String CrAccNo;  // 贷方账号
	private String CrProv;  // 贷方省市代码
	private String CrCur;  // 贷方货币号
	private String ConFlag;  // 贷方户名校验标志
	private String Postscript;  // 贷方户名校验标志

	private String CrAccName;  // 贷方户名
	private String CrBankName;  // 贷方开户行行名

	public String getAmt() {
		return Amt;
	}

	public void setAmt(final String amt) {
		Amt = amt;
	}

	public String getBookingDate() {
		return BookingDate;
	}

	public void setBookingDate(final String bookingDate) {
		BookingDate = bookingDate;
	}

	public String getBookingTime() {
		return BookingTime;
	}

	public void setBookingTime(final String bookingTime) {
		BookingTime = bookingTime;
	}

	public String getBookingFlag() {
		return BookingFlag;
	}

	public void setBookingFlag(final String bookingFlag) {
		BookingFlag = bookingFlag;
	}

	public String getCrActCode() {
		return CrActCode;
	}

	public void setCrActCode(final String crActCode) {
		CrActCode = crActCode;
	}

	public String getCshDraFlag() {
		return CshDraFlag;
	}

	public void setCshDraFlag(final String cshDraFlag) {
		CshDraFlag = cshDraFlag;
	}

	public String getVoucherType() {
		return VoucherType;
	}

	public void setVoucherType(final String voucherType) {
		VoucherType = voucherType;
	}

	public String getVoucherNo() {
		return VoucherNo;
	}

	public void setVoucherNo(final String voucherNo) {
		VoucherNo = voucherNo;
	}

	public String getAgtDbInd() {
		return AgtDbInd;
	}

	public void setAgtDbInd(final String agtDbInd) {
		AgtDbInd = agtDbInd;
	}

	public String getAgtDbProv() {
		return AgtDbProv;
	}

	public void setAgtDbProv(final String agtDbProv) {
		AgtDbProv = agtDbProv;
	}

	public String getAgtDbAccNo() {
		return AgtDbAccNo;
	}

	public void setAgtDbAccNo(final String agtDbAccNo) {
		AgtDbAccNo = agtDbAccNo;
	}

	public String getAgtDbCur() {
		return AgtDbCur;
	}

	public void setAgtDbCur(final String agtDbCur) {
		AgtDbCur = agtDbCur;
	}

	public String getAgtDbName() {
		return AgtDbName;
	}

	public void setAgtDbName(final String agtDbName) {
		AgtDbName = agtDbName;
	}

	public String getPostscriptRes() {
		return PostscriptRes;
	}

	public void setPostscriptRes(final String postscriptRes) {
		PostscriptRes = postscriptRes;
	}

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

	public String getDbLogAccNo() {
		return DbLogAccNo;
	}

	public void setDbLogAccNo(final String dbLogAccNo) {
		DbLogAccNo = dbLogAccNo;
	}

	public String getCrAccNo() {
		return CrAccNo;
	}

	public void setCrAccNo(final String crAccNo) {
		CrAccNo = crAccNo;
	}

	public String getCrProv() {
		return CrProv;
	}

	public void setCrProv(final String crProv) {
		CrProv = crProv;
	}

	public String getCrCur() {
		return CrCur;
	}

	public void setCrCur(final String crCur) {
		CrCur = crCur;
	}

	public String getConFlag() {
		return ConFlag;
	}

	public void setConFlag(final String conFlag) {
		ConFlag = conFlag;
	}

	public String getPostscript() {
		return Postscript;
	}

	public void setPostscript(final String postscript) {
		Postscript = postscript;
	}

	public String getCrAccName() {
		return CrAccName;
	}

	public void setCrAccName(final String crAccName) {
		CrAccName = crAccName;
	}

	public String getCrBankName() {
		return CrBankName;
	}

	public void setCrBankName(final String crBankName) {
		CrBankName = crBankName;
	}

}
