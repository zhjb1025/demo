package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH19File2DTO extends AbcCrossBeanBase {

	public WH19File2DTO() {
		super.addField(new AbcCrossBeanField("businessSource", 0, true, ' '));
		super.addField(new AbcCrossBeanField("businessRefNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranOpponentCountry", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranNature", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranNoFir", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranAmountFir", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranRemarkFir", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranNoSec", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranAmountSec", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tranRemarkSec", 0, true, ' '));
		super.addField(new AbcCrossBeanField("isBondedItems", 0, true, ' '));
		super.addField(new AbcCrossBeanField("applyPerson", 0, true, ' '));
		super.addField(new AbcCrossBeanField("applyPhone", 0, true, ' '));
		super.addField(new AbcCrossBeanField("applyTime", 0, true, ' '));
		super.addField(new AbcCrossBeanField("contractNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("invoiceNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("transportationNo", 0, true, ' '));
		super.addField(new AbcCrossBeanField("contractAmount", 0, true, ' '));
		super.addField(new AbcCrossBeanField("operationType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("ourCertificateType", 0, true, ' '));
	}

	public String getBusinessSource() {
		return data.get("businessSource");
	}

	public void setBusinessSource(String businessSource) {
		data.put("businessSource", businessSource);
	}

	public String getBusinessRefNo() {
		return data.get("businessRefNo");
	}

	public void setBusinessRefNo(String businessRefNo) {
		data.put("businessRefNo", businessRefNo);
	}

	public String getTranOpponentCountry() {
		return data.get("tranOpponentCountry");
	}

	public void setTranOpponentCountry(String tranOpponentCountry) {
		data.put("tranOpponentCountry", tranOpponentCountry);
	}

	public String getTranType() {
		return data.get("tranType");
	}

	public void setTranType(String tranType) {
		data.put("tranType", tranType);
	}

	public String getTranNature() {
		return data.get("tranNature");
	}

	public void setTranNature(String tranNature) {
		data.put("tranNature", tranNature);
	}

	public String getTranNoFir() {
		return data.get("tranNoFir");
	}

	public void setTranNoFir(String tranNoFir) {
		data.put("tranNoFir", tranNoFir);
	}

	public String getTranAmountFir() {
		return data.get("tranAmountFir");
	}

	public void setTranAmountFir(String tranAmountFir) {
		data.put("tranAmountFir", tranAmountFir);
	}

	public String getTranRemarkFir() {
		return data.get("tranRemarkFir");
	}

	public void setTranRemarkFir(String tranRemarkFir) {
		data.put("tranRemarkFir", tranRemarkFir);
	}

	public String getTranNoSec() {
		return data.get("tranNoSec");
	}

	public void setTranNoSec(String tranNoSec) {
		data.put("tranNoSec", tranNoSec);
	}

	public String getTranAmountSec() {
		return data.get("tranAmountSec");
	}

	public void setTranAmountSec(String tranAmountSec) {
		data.put("tranAmountSec", tranAmountSec);
	}

	public String getTranRemarkSec() {
		return data.get("tranRemarkSec");
	}

	public void setTranRemarkSec(String tranRemarkSec) {
		data.put("tranRemarkSec", tranRemarkSec);
	}

	public String getIsBondedItems() {
		return data.get("isBondedItems");
	}

	public void setIsBondedItems(String isBondedItems) {
		data.put("isBondedItems", isBondedItems);
	}

	public String getApplyPerson() {
		return data.get("applyPerson");
	}

	public void setApplyPerson(String applyPerson) {
		data.put("applyPerson", applyPerson);
	}

	public String getApplyPhone() {
		return data.get("applyPhone");
	}

	public void setApplyPhone(String applyPhone) {
		data.put("applyPhone", applyPhone);
	}

	public String getApplyTime() {
		return data.get("applyTime");
	}

	public void setApplyTime(String applyTime) {
		data.put("applyTime", applyTime);
	}

	public String getContractNo() {
		return data.get("contractNo");
	}

	public void setContractNo(String contractNo) {
		data.put("contractNo", contractNo);
	}

	public String getInvoiceNo() {
		return data.get("invoiceNo");
	}

	public void setInvoiceNo(String invoiceNo) {
		data.put("invoiceNo", invoiceNo);
	}

	public String getTransportationNo() {
		return data.get("transportationNo");
	}

	public void setTransportationNo(String transportationNo) {
		data.put("transportationNo", transportationNo);
	}

	public String getContractAmount() {
		return data.get("contractAmount");
	}

	public void setContractAmount(String contractAmount) {
		data.put("contractAmount", contractAmount);
	}

	public String getOperationType() {
		return data.get("operationType");
	}

	public void setOperationType(String operationType) {
		data.put("operationType", operationType);
	}

	public String getOurCertificateType() {
		return data.get("ourCertificateType");
	}

	public void setOurCertificateType(String ourCertificateType) {
		data.put("ourCertificateType", ourCertificateType);
	}
}
