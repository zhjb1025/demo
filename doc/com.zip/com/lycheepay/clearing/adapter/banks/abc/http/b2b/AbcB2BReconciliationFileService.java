/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.http.b2b;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.soofa.tx.service.BaseService;
import org.springframework.stereotype.Service;

import com.hitrust.b2b.trustpay.client.TrxResponse;
import com.hitrust.b2b.trustpay.client.XMLDocument;
import com.hitrust.b2b.trustpay.client.b2b.DownloadTrnxRequest;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行B2B对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.ABC_B2B_RECONCILIATION_FILE_SERVICE)
public class AbcB2BReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		final String reconciliationDate = queryDate.substring(0, 4) + "/" + queryDate.substring(4, 6) + "/"
				+ queryDate.substring(6);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + reconciliationDate);

		// 生成下载交易记录请求对象
		final DownloadTrnxRequest tDownloadTrnxRequest = new DownloadTrnxRequest();
		tDownloadTrnxRequest.setMerchantTrnxDate(reconciliationDate); // 设定商户交易编号（必要信息）
		tDownloadTrnxRequest.setMerchantRemarks(""); // 设定商户备注信息

		Log4jUtil.info(logPrefix + "发送对账单下载请求到银行。");
		// 传送商户对账单下载请求并取得对账单
		final TrxResponse tTrxResponse = tDownloadTrnxRequest.postRequest();

		// 判断商户对账单下载结果状态，进行后续操作
		if (tTrxResponse.isSuccess() || tTrxResponse.getReturnCode().equals("2602")) {
			Log4jUtil.info(logPrefix + "成功收到银行返回的对账单对象TrxResponse。");

			/*
			 * 4、若下载交易记录请求执行成功，则可以取得交易明细，每笔交易明细为字符串类型，使用 逗号分隔不同的字段。字段信息依次如下： 交易类型
			 * 目前只提供直接支付（FUND_TRANSFER）一种交易类型 商户交易编号 交易金额 交易时间 交易状态 成功（2）、失败（3）、作废（5）
			 */
			final XMLDocument tDetailRecords = new XMLDocument(tTrxResponse.getValue("TrnxDetail"));
			final ArrayList<?> tRecords = tDetailRecords.getDocuments("TrnxRecord");

			logResponseResult(logPrefix, tRecords);

			final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(tRecords, queryDate,
					channelId);
			Log4jUtil.info(logPrefix + "生成统一格式对账文件");

			final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
					queryDate, reconciliationFileDTOList);
			return fileFullPath;
		} else {
			final String errorMsg = logPrefix + "下载对账单出错!ReturnCode:" + tTrxResponse.getReturnCode() + " ErrorMessage:"
					+ tTrxResponse.getErrorMessage();
			Log4jUtil.error(errorMsg);
			throw new ClearingAdapterBizCheckedException(BusinessCode.GET_RECONCILIATION_FILE_FAILED, errorMsg);
		}
	}

	/**
	 * <p>记录银行返回对账元素</p>
	 * 
	 * @param logPrefix
	 * @param tRecords
	 * @author 李斌(13665100450)
	 */
	private void logResponseResult(final String logPrefix, final ArrayList<?> tRecords) {
		String mx = "\n";
		for (int i = 0; i < tRecords.size(); i++) {
			mx = mx + "明细" + (i + 1) + ":" + tRecords.get(i).toString() + "\n";
		}
		Log4jUtil.info(mx);
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param tRecords
	 * @author 李斌(13665100450)
	 * @param reconciliationDate
	 * @param channelId
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final ArrayList<?> tRecords, final String settleDate,
			final String channelId) throws ClearingAdapterBizCheckedException {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		final String[] iRecord = new String[tRecords.size()];
		for (int i = 0; i < tRecords.size(); i++) {
			iRecord[i] = ((XMLDocument) tRecords.get(i)).toString();
			final ReconciliationFileDTO reconciliationFileDTO = new ReconciliationFileDTO();
			final String[] detail = iRecord[i].split(",");
			reconciliationFileDTO.setChannelId(channelId);
			reconciliationFileDTO.setCheckDate(settleDate);
			reconciliationFileDTO.setBankSendId(detail[1].toString()); // 渠道（银行）端的流水(订单号)
			reconciliationFileDTO.setAmount(new BigDecimal(detail[2]));// 交易金额
			if (reconciliationFileDTO.getAmount().compareTo(BigDecimal.ZERO) > 0) {
				reconciliationFileDTO.setPayGet(STR_GET);
			} else {
				reconciliationFileDTO.setPayGet(STR_PAY);
			}
			String tMerchantTrnxDate;
			try {
				tMerchantTrnxDate = DateUtil.getDate(format.parse(detail[3].toString()));
			} catch (final ParseException e) {
				throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, "解析交易日期["
						+ detail[3].toString() + "]失败");
			}
			reconciliationFileDTO.setTransDate(tMerchantTrnxDate); // 账务日期
			String bankTradestate = "";

			if (detail[4].trim().substring(0, 1).equals("2")) { // 2 成功、3 失败、5 作废。。
				bankTradestate = "00";
			} else if ((detail[4].trim().substring(0, 1).equals("3") || (detail[4].trim().substring(0, 1).equals("5")))) {
				bankTradestate = "01";
			}

			reconciliationFileDTO.setBankTransState(bankTradestate);// 渠道（银行）交易状态
			// 00-支付成功；01-支付失败；02-超时；和
			String logMsg = "用明细" + (i + 1) + "构造ReconciliationFileDTO，添加到reconciliationFileDTOList的第" + (i + 1)
					+ "条记录:";
			logMsg = logMsg + " checkDate:" + reconciliationFileDTO.getCheckDate() + " BankSendSn:"
					+ reconciliationFileDTO.getBankSendId();
			logMsg = logMsg + " TranDate:" + reconciliationFileDTO.getTransDate() + " TradeAmount:"
					+ reconciliationFileDTO.getAmount();
			Log4jUtil.info(logMsg);
			reconciliationFileDTOList.add(reconciliationFileDTO);
		}
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

}
