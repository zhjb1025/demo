package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

/**
 * <p>农行银企直连备付金上报参数常量</p>
 * @author huangxu
 *
 */
public interface AbcCorpBFJParm {
	String PAY_COM_NAME = "快付通";	//支付机构名称
	String FILE_SPLIT = "|";	//文件列分隔符
	String HAS_FILE = "1";	//文件标识; 1-有; 0:没有;
	String CORP_TYPE = "1";	//支付机构类型; 0-存管行; 1-合作行; (可空)
	String MODE = "0";	//判别模式; 0-非替代模式;1-替代模式;
	int REPORT_LATEST_UPLOAD_DAYS_PER_MONTH = 5;	//报表最晚上报时间(每个月5号上报上个月的报表)
}
