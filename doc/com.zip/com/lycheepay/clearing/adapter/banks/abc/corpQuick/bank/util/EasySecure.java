package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class EasySecure
{
	/**
	 * 摘要
	 * 
	 * @param 需要摘要的数据
	 * @return
	 * @throws NoSuchAlgorithmException
	 */

	public static byte[] digest(String alm,byte[] data) throws NoSuchAlgorithmException
	{
        MessageDigest md5 = MessageDigest.getInstance(alm);
        md5.update(data);
        return md5.digest();		
	}
	
	
	/**
	 * MD5摘要
	 * 
	 * @param 需要摘要的数据
	 * @return
	 * @throws NoSuchAlgorithmException
	 */

	public static byte[] md5digest(byte[] data) throws NoSuchAlgorithmException
	{
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        md5.update(data);
        return md5.digest();		
	}
}

