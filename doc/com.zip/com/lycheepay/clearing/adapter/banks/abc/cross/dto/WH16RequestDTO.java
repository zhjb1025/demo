package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH16RequestDTO extends AbcCrossBeanBase {

	public WH16RequestDTO() {
		super.addField(new AbcCrossBeanField("transCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("procCode", 6, true, ' '));
		super.addField(new AbcCrossBeanField("termID", 8, true, ' '));
		super.addField(new AbcCrossBeanField("merID", 10, true, ' '));
		super.addField(new AbcCrossBeanField("transType", 1, true, ' '));
		super.addField(new AbcCrossBeanField("seqNo", 20, true, ' '));
		super.addField(new AbcCrossBeanField(AbcCrossConstant.STRING_MD5, 32, true, ' '));

	}

	public String getTransCode() {
		return data.get("transCode");
	}

	public void setTransCode(String transCode) {
		data.put("transCode", transCode);
	}

	public String getProcCode() {
		return data.get("procCode");
	}

	public void setProcCode(String procCode) {
		data.put("procCode", procCode);
	}

	public String getTermID() {
		return data.get("termID");
	}

	public void setTermID(String termID) {
		data.put("termID", termID);
	}

	public String getMerID() {
		return data.get("merID");
	}

	public void setMerID(String merID) {
		data.put("merID", merID);
	}

	public String getTransType() {
		return data.get("transType");
	}

	public void setTransType(String transType) {
		data.put("transType", transType);
	}

	public String getSeqNo() {
		return data.get("seqNo");
	}

	public void setSeqNo(String seqNo) {
		data.put("seqNo", seqNo);
	}

}
