package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean;

public class RequestBean {
	// 请求： 字段赋值标志：Y表示必输，C表示可选，O表示可以不输。
	// 序号 字段 长度 格式 身份验证
	String tranCode = "";// 1 交易码 4 Y
	String processCode = "";// 2 处理码 6 330000
	String terminateCode = "";// 3 终端号 8 左对齐右补空格 Y
	String merchantCode = "";// 4 商户号 15 左对齐右补空格 Y
	String bizCode = "";// 5 业务代码 2 Y
	String account = "";// 6 主账号 19 左对齐右补空格 Y
	String amt = "";// 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
	String sysTrack = "";// 8 系统跟踪号 20 左对齐右补空格 Y
	String tranDate = "";// 9 交易日期 8 YYYYMMDD C
	String inputCode = "";// 10 输入方式码 3 Y
	String oriSysCode = "";// 11 原系统参考号 20 左对齐右补空格 C
	String cardValidDate = "";// 12 卡有效期 4 左对齐右补空格 YYMM C
	String authorCode = "";// 13 授权码 2 左对齐右补空格 O
	String remark = "";// 14 摘要 10 左对齐右补空格 C
	String accName = "";// 15 户名 70 左对齐右补空格 Y
	String currencyCode = "";// 16 货币代码 3 Y
	String merchantStream = "";// 17 商户交易流水号 20 左对齐右补空格 Y
	String idCard = "";// 18 证件类型+证件号码 22 左对齐右补空格 Y
	String terminateStreamCode = "";// 19 农行终端流水号 20 左对齐右补空格 C
	String mobile = "";// 20 手机号 15 左对齐右补空格 C
	String md5Code = "";// 21 MD5密码 32 Y

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(final String tranCode) {
		this.tranCode = tranCode;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(final String processCode) {
		this.processCode = processCode;
	}

	public String getTerminateCode() {
		return terminateCode;
	}

	public void setTerminateCode(final String terminateCode) {
		this.terminateCode = terminateCode;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(final String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public String getBizCode() {
		return bizCode;
	}

	public void setBizCode(final String bizCode) {
		this.bizCode = bizCode;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(final String account) {
		this.account = account;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(final String amt) {
		this.amt = amt;
	}

	public String getSysTrack() {
		return sysTrack;
	}

	public void setSysTrack(final String sysTrack) {
		this.sysTrack = sysTrack;
	}

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(final String tranDate) {
		this.tranDate = tranDate;
	}

	public String getInputCode() {
		return inputCode;
	}

	public void setInputCode(final String inputCode) {
		this.inputCode = inputCode;
	}

	public String getOriSysCode() {
		return oriSysCode;
	}

	public void setOriSysCode(final String oriSysCode) {
		this.oriSysCode = oriSysCode;
	}

	public String getCardValidDate() {
		return cardValidDate;
	}

	public void setCardValidDate(final String cardValidDate) {
		this.cardValidDate = cardValidDate;
	}

	public String getAuthorCode() {
		return authorCode;
	}

	public void setAuthorCode(final String authorCode) {
		this.authorCode = authorCode;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(final String remark) {
		this.remark = remark;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(final String accName) {
		this.accName = accName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(final String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getMerchantStream() {
		return merchantStream;
	}

	public void setMerchantStream(final String merchantStream) {
		this.merchantStream = merchantStream;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(final String idCard) {
		this.idCard = idCard;
	}

	public String getTerminateStreamCode() {
		return terminateStreamCode;
	}

	public void setTerminateStreamCode(final String terminateStreamCode) {
		this.terminateStreamCode = terminateStreamCode;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(final String mobile) {
		this.mobile = mobile;
	}

	public String getMd5Code() {
		return md5Code;
	}

	public void setMd5Code(final String md5Code) {
		this.md5Code = md5Code;
	}
}
