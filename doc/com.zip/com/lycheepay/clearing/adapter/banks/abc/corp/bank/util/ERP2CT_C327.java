package com.lycheepay.clearing.adapter.banks.abc.corp.bank.util;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C327Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcSend2CT_Vc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;


@Service
public class ERP2CT_C327 {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_SEND2CT_VC)
	private AbcSend2CT_Vc abcSend2CT_Vc;
	/**
	 * 创建农行C327报文，并发送到CT
	 * 
	 * @author aps-kxj
	 * @param queryParam
	 * @date 2011-03-19
	 * @return C327报文
	 * @throws BizException
	 */
	public String sendXMLFile(final ERP2CT_PublicBean eRP2CT_PublicBean, final ERP2CT_C327Bean eRP2CT_C327Bean)
			throws BizException {
		// 使用DocumentHelper.createDocument方法建立一个文档实例
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 使用addElement方法方法创建根元素
		final Element apElement = document.addElement("ap");

		// 使用addElement方法向ap元素添加TransCode子元素
		final Element TransCode = apElement.addElement("TransCode");
		TransCode.setText(eRP2CT_PublicBean.getTransCode());

		// 使用addElement方法向ap元素添加ChannelType子元素
		final Element ChannelType = apElement.addElement("ChannelType");
		ChannelType.setText(eRP2CT_PublicBean.getChannelType());

		// 使用addElement方法向ap元素添加CorpNo子元素
		final Element CorpNo = apElement.addElement("CorpNo");
		CorpNo.setText(eRP2CT_PublicBean.getCorpNo());

		// 使用addElement方法向ap元素添加OpNo子元素
		final Element OpNo = apElement.addElement("OpNo");
		OpNo.setText(eRP2CT_PublicBean.getOpNo());

		// 使用addElement方法向ap元素添加AuthNo子元素
		final Element AuthNo = apElement.addElement("AuthNo");
		AuthNo.setText(eRP2CT_PublicBean.getAuthNo());

		// 使用addElement方法向ap元素添加__子元素
		final Element ReqSeqNo = apElement.addElement("ReqSeqNo");
		ReqSeqNo.setText(eRP2CT_PublicBean.getReqSeqNo());

		// 使用addElement方法向ap元素添加__子元素
		final Element ReqDate = apElement.addElement("ReqDate");
		ReqDate.setText(eRP2CT_PublicBean.getReqDate());

		// 使用addElement方法向ap元素添加ReqTime子元素
		final Element ReqTime = apElement.addElement("ReqTime");
		ReqTime.setText(eRP2CT_PublicBean.getReqTime());

		// 使用addElement方法向ap元素添加Sign子元素
		final Element Sign = apElement.addElement("Sign");
		Sign.setText(eRP2CT_PublicBean.getSign());

		// 使用addElement方法向ap元素添加Version子元素
		final Element VersionElement = apElement.addElement("Version");
		final Element CcVersion = VersionElement.addElement("CcVersion");
		CcVersion.setText(eRP2CT_PublicBean.getCcVersion());

		// 使用addElement方法向ap元素添加Amt子元素
		final Element AmtName = apElement.addElement("Amt");
		AmtName.setText(eRP2CT_C327Bean.getAmt());

		// 使用addElement方法向ap元素添加Cmp子元素
		final Element CmpElement = apElement.addElement("Cmp");

		final Element DbAccNoName = CmpElement.addElement("DbAccNo");
		DbAccNoName.setText(eRP2CT_C327Bean.getDbAccNo());

		final Element DbProvName = CmpElement.addElement("DbProv");
		DbProvName.setText(eRP2CT_C327Bean.getDbProv());

		final Element DbCurName = CmpElement.addElement("DbCur");
		DbCurName.setText(eRP2CT_C327Bean.getDbCur());

		final Element CrAccNoName = CmpElement.addElement("CrAccNo");
		CrAccNoName.setText(eRP2CT_C327Bean.getCrAccNo());

		final Element CrProvName = CmpElement.addElement("CrProv");
		CrProvName.setText(eRP2CT_C327Bean.getCrProv());

		final Element CrCurName = CmpElement.addElement("CrCur");
		CrCurName.setText(eRP2CT_C327Bean.getCrCur());

		final Element CrLogAccNoName = CmpElement.addElement("CrLogAccNo");
		CrLogAccNoName.setText(eRP2CT_C327Bean.getCrLogAccNo());

		final Element ConFlagName = CmpElement.addElement("ConFlag");
		ConFlagName.setText(eRP2CT_C327Bean.getConFlag());

		// 使用addElement方法向ap元素添加Corp子元素
		final Element CorpElement = apElement.addElement("Corp");

		final Element DbAccNameName = CorpElement.addElement("DbAccName");
		DbAccNameName.setText(eRP2CT_C327Bean.getDbAccName());

		final Element CrAccNameName = CorpElement.addElement("CrAccName");
		CrAccNameName.setText(eRP2CT_C327Bean.getCrAccName());

		final Element CshDraFlagName = CorpElement.addElement("CshDraFlag");
		CshDraFlagName.setText(eRP2CT_C327Bean.getCshDraFlag());

		final Element ExchangeTypeName = CorpElement.addElement("ExchangeType");
		ExchangeTypeName.setText(eRP2CT_C327Bean.getExchangeType());

		final Element PostscriptName = CorpElement.addElement("Postscript");
		PostscriptName.setText(eRP2CT_C327Bean.getPostscript());

		final String xmlInfo = document.asXML();
		final int begin = xmlInfo.indexOf("<ap>");
		final String XmlC327Info = xmlInfo.substring(begin, xmlInfo.length());

		Log4jUtil.info("XmlC327Info : " + XmlC327Info);
		String resultXml = abcSend2CT_Vc.launch(XmlC327Info);
		/*
		二、使用Dom4j
		1.Xml字符串--->Xml Document【org.dom4j.Document】
		     String xmlStr = "";
		     Documenet doc = DocumentHelper.parseText(xmlStr);
		2.Xml Document--->Xml字符串
		     String xmlStr = document.asXml();
		*/

		// 生成文件
		/*	        XMLWriter output;
			        //输出格式化
			        OutputFormat format = OutputFormat.createPrettyPrint();
			        format.setEncoding("GBK");
			        try {
			            output = new XMLWriter(new FileWriter("d:/ERP2CT_C327.XML"), format);
			            output.write(document);
			            output.close();
			        } catch (IOException e) {
			            Log4jUtil.error( e);
			        }*/

		return resultXml;  // TODO 刚写完此方法，待测试。
	}
}
