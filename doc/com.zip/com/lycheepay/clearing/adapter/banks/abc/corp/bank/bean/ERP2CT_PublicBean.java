package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_PublicBean {

	// ERP2CT请求报文公共字段
	private String TransCode; // 交易代码
	private String ChannelType; // 渠道标志
	private String CorpNo; // 企业技监局号码
	private String OpNo; // 企业操作员编号
	private String AuthNo; // 认证码
	private String ReqSeqNo; // 请求方流水号
	private String ReqDate; // 请求日期
	private String ReqTime; // 请求时间
	private String Sign; // 数字签名
	private String CcVersion; // CC报文版本
	
	private String PayComNo; // 支付公司编号, 即'支付机构签约编号', 备付金报表上报必填

	public String getTransCode() {
		return TransCode;
	}

	public void setTransCode(final String transCode) {
		TransCode = transCode;
	}

	public String getChannelType() {
		return ChannelType;
	}

	public void setChannelType(final String channelType) {
		ChannelType = channelType;
	}

	public String getCorpNo() {
		return CorpNo;
	}

	public void setCorpNo(final String corpNo) {
		CorpNo = corpNo;
	}

	public String getOpNo() {
		return OpNo;
	}

	public void setOpNo(final String opNo) {
		OpNo = opNo;
	}

	public String getAuthNo() {
		return AuthNo;
	}

	public void setAuthNo(final String authNo) {
		AuthNo = authNo;
	}

	public String getReqSeqNo() {
		return ReqSeqNo;
	}

	public void setReqSeqNo(final String reqSeqNo) {
		ReqSeqNo = reqSeqNo;
	}

	public String getReqDate() {
		return ReqDate;
	}

	public void setReqDate(final String reqDate) {
		ReqDate = reqDate;
	}

	public String getReqTime() {
		return ReqTime;
	}

	public void setReqTime(final String reqTime) {
		ReqTime = reqTime;
	}

	public String getSign() {
		return Sign;
	}

	public void setSign(final String sign) {
		Sign = sign;
	}

	public String getCcVersion() {
		return CcVersion;
	}

	public void setCcVersion(final String ccVersion) {
		CcVersion = ccVersion;
	}

	public String getPayComNo() {
		return PayComNo;
	}

	public void setPayComNo(String payComNo) {
		PayComNo = payComNo;
	}

}
