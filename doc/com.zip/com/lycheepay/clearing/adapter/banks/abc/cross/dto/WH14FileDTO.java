package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH14FileDTO extends AbcCrossBeanBase {

	public WH14FileDTO() {
		super.addField(new AbcCrossBeanField("orgCode", 0, true, ' '));
		super.addField(new AbcCrossBeanField("customerCode", 0, true, ' '));
		super.addField(new AbcCrossBeanField("companyName", 0, true, ' '));
		super.addField(new AbcCrossBeanField("busiPlaceCode", 0, true, ' '));
		super.addField(new AbcCrossBeanField("alphaCode", 0, true, ' '));
		super.addField(new AbcCrossBeanField("abroadCountry", 0, true, ' '));
		super.addField(new AbcCrossBeanField("economyType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("tradeType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("exchangeBureauCode", 0, true, ' '));
		super.addField(new AbcCrossBeanField("isSpecialArea", 0, true, ' '));
		super.addField(new AbcCrossBeanField("enterpriseType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("applyType", 0, true, ' '));
		super.addField(new AbcCrossBeanField("institutionAddress", 0, true, ' '));
		super.addField(new AbcCrossBeanField("zipCode", 0, true, ' '));
		super.addField(new AbcCrossBeanField("contactPerson", 0, true, ' '));
		super.addField(new AbcCrossBeanField("contactPhone", 0, true, ' '));
	}

	public String getOrgCode() {
		return data.get("orgCode");
	}

	public void setOrgCode(String orgCode) {
		data.put("orgCode", orgCode);
	}

	public String getCustomerCode() {
		return data.get("customerCode");
	}

	public void setCustomerCode(String customerCode) {
		data.put("customerCode", customerCode);
	}

	public String getCompanyName() {
		return data.get("companyName");
	}

	public void setCompanyName(String companyName) {
		data.put("companyName", companyName);
	}

	public String getBusiPlaceCode() {
		return data.get("busiPlaceCode");
	}

	public void setBusiPlaceCode(String busiPlaceCode) {
		data.put("busiPlaceCode", busiPlaceCode);
	}

	public String getAlphaCode() {
		return data.get("alphaCode");
	}

	public void setAlphaCode(String alphaCode) {
		data.put("alphaCode", alphaCode);
	}

	public String getAbroadCountry() {
		return data.get("abroadCountry");
	}

	public void setAbroadCountry(String abroadCountry) {
		data.put("abroadCountry", abroadCountry);
	}

	public String getEconomyType() {
		return data.get("economyType");
	}

	public void setEconomyType(String economyType) {
		data.put("economyType", economyType);
	}

	public String getTradeType() {
		return data.get("tradeType");
	}

	public void setTradeType(String tradeType) {
		data.put("tradeType", tradeType);
	}

	public String getExchangeBureauCode() {
		return data.get("exchangeBureauCode");
	}

	public void setExchangeBureauCode(String exchangeBureauCode) {
		data.put("exchangeBureauCode", exchangeBureauCode);
	}

	public String getIsSpecialArea() {
		return data.get("isSpecialArea");
	}

	public void setIsSpecialArea(String isSpecialArea) {
		data.put("isSpecialArea", isSpecialArea);
	}

	public String getEnterpriseType() {
		return data.get("enterpriseType");
	}

	public void setEnterpriseType(String enterpriseType) {
		data.put("enterpriseType", enterpriseType);
	}

	public String getApplyType() {
		return data.get("applyType");
	}

	public void setApplyType(String applyType) {
		data.put("applyType", applyType);
	}

	public String getInstitutionAddress() {
		return data.get("institutionAddress");
	}

	public void setInstitutionAddress(String institutionAddress) {
		data.put("institutionAddress", institutionAddress);
	}

	public String getZipCode() {
		return data.get("zipCode");
	}

	public void setZipCode(String zipCode) {
		data.put("zipCode", zipCode);
	}

	public String getContactPerson() {
		return data.get("contactPerson");
	}

	public void setContactPerson(String contactPerson) {
		data.put("contactPerson", contactPerson);
	}

	public String getContactPhone() {
		return data.get("contactPhone");
	}

	public void setContactPhone(String contactPhone) {
		data.put("contactPhone", contactPhone);
	}
}
