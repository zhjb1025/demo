package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.processor;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.BatFileResultQueryRsp;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.RequestBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean.ResponeBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util.TranProcessUtil;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util.BatchBean;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util.RechargeToAbcBean;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.MoneyUtil;
import com.lycheepay.clearing.util.ObjectUtil;


/**
 * <P> 农业银行快捷支付银企直连处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 下午6:04:51
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_QUICK_DIRECT_PROCESS)
public class AbcCorpQuickDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_QUICK_SERVICE)
	private AbcCorpQuickService abcCorpQuickService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_QUICK_MSGDEAL)
	private CorpAbcQuickMsgDeal ccbRepayMsgDeal;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	private static String channelId = ChannelIdEnum.ABC_QUICK_PAY.getCode();

	private final String line = System.getProperty("line.separator"); // 回车换行符

	@Autowired
	@Qualifier("abcquick.tranProcessUtil")
	private TranProcessUtil tranProcess;
	/**
	 * 
	 * <p>账户验证</p>
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 * @throws NoSuchAlgorithmException
	 * @author 汤兴友 xytang
	 */
	public ReturnState accountVerify(Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String currencyCode = channelParms.get("200004");
		String bizCode_01 = channelParms.get("200005");// OK
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort
		ReturnState returnState = new ReturnState(); // 保存返回给回执处理器的结果变量
		// 商户自定义序列号
		String merchantStream = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());// 农行银企流水
		final BankCardVerifyDTO accountVerfy = (BankCardVerifyDTO) param.getBizBean();
		AssertUtils.notNull(accountVerfy, TransReturnCode.code_9108, "农行快捷报文方式的账户验证数据不能为空!");

		final String account = accountVerfy.getBankCardNo(); // 银行卡号
		final String accName = accountVerfy.getCardHolderName();// 客户姓名 可选
		String certType = accountVerfy.getCertificateType();// 证件类型 可选
		final String certNo = accountVerfy.getCertificateNo();// 证件号码 可选
		final String tranDate = DateUtil.getCurrentDate();

		// 把快付通证件类型转换为快捷系统证件类型
		AssertUtils.notNull(account, TransReturnCode.code_9108, "持卡人身份验证请求的银行卡号不能为空!");
		AssertUtils.notNull(accName, TransReturnCode.code_9108, "持卡人身份验证请求的银行卡户名不能为空!");
		AssertUtils.notNull(certType, TransReturnCode.code_9108, "持卡人身份验证请求的证件类型不能为空!");
		AssertUtils.notNull(certNo, TransReturnCode.code_9108, "持卡人身份验证请求的证件号码不能为空!");

		certType = channelCertTypeService.getCertType(channelId, certType);
		String idCard = certType + certNo;

		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("0200");// OK 1 交易码 4
		requestBean.setProcessCode("330000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setBizCode(bizCode_01);// OK 5 业务代码 2 Y
		requestBean.setAccount(account);// OK 6 主账号 19 左对齐右补空格 Y
		requestBean.setAmt("");// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		requestBean.setSysTrack("");// 8 系统跟踪号 20 左对齐右补空格 Y
		requestBean.setTranDate(tranDate);// OK 9 交易日期 8 YYYYMMDD C
		requestBean.setInputCode("012");// OK 10 输入方式码 3 Y
		requestBean.setOriSysCode("");// 11 原系统参考号 20 左对齐右补空格 C
		requestBean.setCardValidDate("");// 12 卡有效期 4 左对齐右补空格 YYMM C
		requestBean.setAuthorCode("");// OK 13 授权码 2 左对齐右补空格 O
		requestBean.setRemark("");// OK 14 摘要 10 左对齐右补空格 C 限制最多四个汉字
		requestBean.setAccName(accName);// 15 户名 70 左对齐右补空格 Y
		requestBean.setCurrencyCode(currencyCode);// OK 16 货币代码 3 Y
		requestBean.setMerchantStream(merchantStream);// 17 商户交易流水号 20 左对齐右补空格
		// Y
		requestBean.setIdCard(idCard);// 18 证件类型+证件号码 22 左对齐右补空格 Y
		requestBean.setTerminateStreamCode("");// 19 农行终端流水号 20
		// 左对齐右补空格 C
		requestBean.setMobile("");// 20 手机号 15 左对齐右补空格 C

		// TODO param.getClearingTransType() 有待调整
		ResponeBean responeBean = tranProcess.trans(socketIP, socketPort, requestBean, md5CodeKey, param.getClearingTransType());

		// TransReturnCode.code_0000.getValue();
		if (responeBean.getRetCode().equals("00")) {
			returnState.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			returnState.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回
		// 9900 给平台
		channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId, responeBean
				.getRetCode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		// returnState.setReturnState(PayState.SUCCEED_RTN); //银行返回状态---超时：T、成功：S、失败：F
		returnState.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
		returnState.setReturnMsg(respInfo); // 银行响应信息
		returnState.setBankPostScript(respInfo);
		returnState.setCreditNo(""); // 银行返回凭证号码（银行端流水）
		returnState.setSn(""); // 平台业务流水
		returnState.setChannelCode(channelCode); // 渠道返回给业务层状态码
		returnState.setCardType(""); // 卡类型
		returnState.setReturnObj(""); // 返回的实体对象
		returnState.setCheckDate(""); // 渠道结算日期
		returnState.setRelTranAmount(BigDecimal.ZERO); // 实际扣款金额
		returnState.setBillnosnSeq("");
		return returnState;
	}

	/**
	 * 
	 * <p>实时代扣</p>
	 * 
	 * @param param
	 * @return
	 * @author 汤兴友 xytang
	 * @throws BizException
	 */
	public ReturnState directDeduct(Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String currencyCode = channelParms.get("200004");
		String bizCode_02 = channelParms.get("200006");// 02 新增加02_代收付业务代码
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort
		Log4jUtil.info("渠道ID{},渠道业务{}开始处理", channelId, param.getClearingTransType());


		DeductDTO directDeduct = (DeductDTO) param.getBizBean();
		AssertUtils.notNull(directDeduct, TransReturnCode.code_9108, "实时代扣请求数据中的交易业务bean[DeductDTO]不能为空!");

		String account = directDeduct.getBankCardNo(); // 银行卡号
		String accName = directDeduct.getCardHolderName();// 客户姓名 可选
		// 需要以分为单位的字符串
		String channelAmt = DecimalUtil.formatFenStringByYuan(directDeduct.getAmount()); // 渠道交易金额
		String toBankSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());// 农行银企交易流水-商户自定义序列号
		String tranDate = DateUtil.getCurrentDate();
		String remark = directDeduct.getOrderNote();

		String certType = StringUtil.getNotNullValue(directDeduct.getCertificateType());// 证件类型
		String certNo = StringUtil.getNotNullValue(directDeduct.getCertificateNo());// 证件号码

		String idCard = "";
		if (StringUtils.isNotBlank(certNo) && StringUtils.isNotBlank(certType)) {
			certType = channelCertTypeService.getCertType(channelId, certType);
			idCard = certType + certNo;
		}

		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("0200");// OK 1 交易码 4
		requestBean.setProcessCode("000000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setBizCode(bizCode_02);// OK 5 业务代码 2 Y
		requestBean.setAccount(account);// OK 6 主账号 19 左对齐右补空格 Y
		requestBean.setAmt(channelAmt);// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		requestBean.setSysTrack(toBankSn);// 8 系统跟踪号 20 左对齐右补空格 Y
		requestBean.setTranDate(tranDate);// OK 9 交易日期 8 YYYYMMDD C
		requestBean.setInputCode("012");// OK 10 输入方式码 3 Y
		requestBean.setOriSysCode("");// 11 原系统参考号 20 左对齐右补空格 C
		if (BankCardType.CREDIT_CARD.equals(directDeduct.getBankCardType())) {
			requestBean.setCardValidDate(StringUtils.defaultString(directDeduct.getCreditCardEndDate(), ""));// 12 卡有效期 4 左对齐右补空格 YYMM C
		}else{
			requestBean.setCardValidDate("");// 12 卡有效期 4 左对齐右补空格 YYMM C
		}
		requestBean.setAuthorCode("");// OK 13 授权码 2 左对齐右补空格 O
		requestBean.setRemark(remark);// OK 14 摘要 10 左对齐右补空格 C 限制最多四个汉字
		requestBean.setAccName(accName);// 15 户名 70 左对齐右补空格 Y
		requestBean.setCurrencyCode(currencyCode);// OK 16 货币代码 3 Y
		requestBean.setMerchantStream(directDeduct.getTxnId());// 17 商户交易流水号 20 左对齐右补空格
		requestBean.setIdCard(idCard);// 证件类型+证件号码
		requestBean.setTerminateStreamCode("");// 19 农行终端流水号 20

		// 保存到渠道流水表中
		BillnoSn billnoSn = billnoSnService.saveBillnoSn(toBankSn, param);

		ResponeBean responeBean = new ResponeBean();


		Log4jUtil.info("实时代扣请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, requestBean);

		ReturnState rs = new ReturnState(); // 保存返回给回执处理器的结果变量
		try {
			responeBean = tranProcess
					.trans(socketIP, socketPort, requestBean, md5CodeKey, param.getClearingTransType());
		} catch (BizException e) {
			Log4jUtil.error("~代扣交易异常:", e);
			rs.setChannelCode(e.getErrorCode()); // 渠道返回给业务层状态码
			rs.setReturnState(PayState.UNKNOW_STR);

			// code_9109异常需要做冲正处理
			if (e.getErrorCode().equals(TransReturnCode.code_9109)) {
				Log4jUtil.info("-----------交易处理【超时】,进入冲正处理:");
				ResponeBean rb = null;
				String msg = "交易处理超时,后续的冲正交易失败 ！";
				try {
					rb = tranProcess.trans(socketIP, socketPort, buildRushBean(requestBean), md5CodeKey, "rush");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				if (rb != null && rb.getRetCode().equals("00")) {
					msg = "交易处理超时,后续的冲正交易已成功！";
					rs.setReturnState(PayState.FAILED_STR);
				}
				Log4jUtil.info("-----------" + msg);
			}

			rs.setReturnMsg(e.getMessage()); // 银行响应信息
			rs.setBankPostScript(e.getMessage());
			rs.setSn(billnoSn.getSn()); // 平台业务流水
			rs.setCardType(param.getCardType()); // 卡类型
			rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
			if (responeBean != null && StringUtils.isNotBlank(responeBean.getAmt()))
				rs.setRelTranAmount(new BigDecimal(responeBean.getAmt()).divide(BigDecimal.valueOf(100))); // 实际扣款金额
			rs.setBillnosnSeq(billnoSn.getBillnosnSeq());
			return rs;
		}

		if (responeBean.getRetCode().equals("00")) {
			rs.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			rs.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回
		channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId, responeBean
				.getRetCode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		rs.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
		rs.setReturnMsg(respInfo); // 银行响应信息
		rs.setBankPostScript(respInfo);
		rs.setCreditNo(responeBean.getSysCode()); // 银行返回凭证号码（银行端参考号）
		rs.setSn(billnoSn.getSn()); // 平台业务流水
		rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
		rs.setCardType(param.getCardType()); // 卡类型
		rs.setCheckDate(responeBean.getSettleDate()); // 渠道结算日期
		rs.setRelTranAmount(new BigDecimal(responeBean.getAmt()).divide(BigDecimal.valueOf(100))); // 实际扣款金额
		rs.setBillnosnSeq(billnoSn.getBillnosnSeq());
		// 更新流水对照表
		billnoSnService.updateBillnoSn(param, rs, toBankSn);

		return rs;
	}

	/**
	 * 
	 * <p>实时代付+ 充值 + 重发代付</p>
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 * @author 汤兴友 xytang
	 */
	public ReturnState directPay(final Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String retCode_exceed = channelParms.get("200022");
		String rechargeAccount = channelParms.get("200023");
		String rechargeAccName = channelParms.get("200024");
		Log4jUtil.info("渠道ID{},渠道业务{}开始处理", channelId, param.getClearingTransType());
		ReturnState rs = realTimeAgentPay(param);

		if (StringUtils.isNotBlank(retCode_exceed) && retCode_exceed.equals(rs.getBankRetCode())) {
			try {
				Log4jUtil.info("-------删除先前失败记录-----");
				billnoSnService.deleteById(rs.getBillnosnSeq());
			} catch (Exception e) {
				Log4jUtil.error("billnoSnService.deleteById异常:", e);
			}

			PayOutDTO bill = (PayOutDTO) param.getBizBean();
			Log4jUtil.info("-----------余额不足或透支超后做充值交易-----------");
			// 先充值
			Param rechargeParam = new Param();
			RechargeToAbcBean bean = new RechargeToAbcBean(bill.getAmount().doubleValue(), rechargeAccount,
					rechargeAccName);
			rechargeParam.setBizBean(bean);
			ReturnState rechargeRs = this.rechargeToAbcInnerAccount(rechargeParam);

			if (!rechargeRs.getChannelCode().equals(TransReturnCode.code_0000)) {
				throw new BizException(TransReturnCode.code_9108, "退款前的充值操作失败;" + rechargeRs.getBankPostScript());
			}
			Log4jUtil.info("-----------充值交易完成，【重发】实时代付交易-----------");

			rs = realTimeAgentPay(param);
		}
		return rs;
	}

	/**
	 * 
	 * @Description: 单笔代付
	 * @param param
	 * @return
	 */
	private ReturnState realTimeAgentPay(Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String currencyCode = channelParms.get("200004");
		String bizCode_02 = channelParms.get("200006");// 02 新增加02_代收付业务代码
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort

		Log4jUtil.info("-----------进入实时代付 方法-----------");

		PayOutDTO paybill = (PayOutDTO) param.getBizBean();
		AssertUtils.notNull(paybill, TransReturnCode.code_9108, "实时代付请求数据中的交易业务bean[PayOutDTO]不能为空!");

		ReturnState rs = new ReturnState(); // 保存返回给回执处理器的结果变量

		String account = paybill.getBankCardNo(); // 入账银行卡号
		String accName = paybill.getCardHolderName();// 入账客户姓名 可选
		String channelAmt = MoneyUtil.getFenString(paybill.getAmount()); // 渠道交易金额
		String toBankSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());// 农行银企交易流水-商户自定义序列号
		String remark = paybill.getOrderNote();
		if (StringUtils.isBlank(remark))
			remark = "实时代付";

		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("0220");// OK 1 交易码 4
		requestBean.setProcessCode("470000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setBizCode(bizCode_02);// OK 5 业务代码 2 Y
		requestBean.setAccount(account);// OK 6 主账号 19 左对齐右补空格 Y
		requestBean.setAmt(channelAmt);// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		requestBean.setSysTrack(toBankSn);// 8 系统跟踪号 20 左对齐右补空格 Y
		requestBean.setInputCode("012");// OK 9 输入方式码 3 Y
		requestBean.setOriSysCode("");// 10 原系统参考号 20 左对齐右补空格 C
		requestBean.setCardValidDate("");// 11 卡有效期 4 左对齐右补空格 YYMM C
		requestBean.setAuthorCode("");// OK 12 授权码 2 左对齐右补空格 O
		requestBean.setRemark(remark);// OK 13 摘要 10 左对齐右补空格 C 限制最多四个汉字
		requestBean.setAccName(accName);// 14 户名 70 左对齐右补空格 Y
		requestBean.setCurrencyCode(currencyCode);// OK 15 货币代码 3 Y
		requestBean.setMerchantStream(paybill.getTxnId());// 16 商户交易流水号 20 左对齐右补空格
		requestBean.setIdCard("");// 证件类型+证件号码

		// 保存到渠道流水表中
		final BillnoSn billnoSn = billnoSnService.saveBillnoSn(toBankSn, param);

		ResponeBean responeBean = new ResponeBean();


		Log4jUtil.info("实时代付请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, requestBean);
		try {
			responeBean = tranProcess
					.trans(socketIP, socketPort, requestBean, md5CodeKey, param.getClearingTransType());
		} catch (BizException e) {
			Log4jUtil.error("-----------交易处理【超时】,进入冲正处理:", e);
			if (e.getErrorCode().equals(TransReturnCode.code_9109)
					|| e.getErrorCode().equals(TransReturnCode.code_9108)) {
				ResponeBean rb = null;
				try {
					rb = tranProcess.trans(socketIP, socketPort, buildRushBean(requestBean), md5CodeKey, "rush");
				} catch (Exception e1) {
					Log4jUtil.error("冲正处理异常:", e1);
				}
				if (rb != null && rb.getRetCode().equals("00")) {
					rs = new ReturnState();
					rs.setReturnState(PayState.FAILED_STR);
					rs.setChannelCode(TransReturnCode.code_9109); // 银行响应信息
					rs.setReturnMsg("交易处理超时,后续的冲正交易已成功！" + e.getMessage());
				} else {
					throw new BizException(TransReturnCode.code_9109, e.getMessage());
				}
				Log4jUtil.info("交易处理超时,后续的冲正交易失败 ！");
			} else {
				throw new BizException(TransReturnCode.code_9109, e.getMessage());
			}
		}

		// 有回执信息下组ReturnState
		if (StringUtils.isNotBlank(responeBean.getRetCode())) {
			if ("00".equals(responeBean.getRetCode())) {
				rs.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
			} else {
				rs.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
			}

			ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, responeBean
					.getRetCode()));
			String channelCode = TransReturnCode.code_9900, respInfo = "";
			if (channelRtncode == null) {
				channelCode = TransReturnCode.code_9900;
			} else {
				channelCode = channelRtncode.getKftRtncode();
				respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
			}

			rs.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
			rs.setReturnMsg(respInfo); // 银行响应信息
			rs.setBankPostScript(respInfo);
			rs.setCreditNo(responeBean.getSysTrack()); // 银行返回凭证号码（银行端流水）
			rs.setSn(billnoSn.getSn()); // 平台业务流水
			rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
			rs.setCardType(param.getCardType()); // 卡类型
			rs.setCheckDate(responeBean.getSettleDate()); // 渠道结算日期
			rs.setRelTranAmount(new BigDecimal(responeBean.getAmt()).divide(BigDecimal.valueOf(100))); // 实际扣款金额
			rs.setBillnosnSeq(billnoSn.getBillnosnSeq());
		}
		// 更新流水对照表
		billnoSnService.updateBillnoSn(param, rs, toBankSn);

		return rs;
	}

	/**
	 * 
	 * @Description: 充值-保证金【银行后台转账不记录到基础平台】
	 *               充值：如果商户某个业务当天代付金额大于代收金额时，需先从商户对公账号转一笔资金到农行内部账号才能做代付和退货交易。
	 *               （充值交易是为了防止透支，每天需先预计一下当天有多少退货交易，需充值足够多的金额才能做退货交易。
	 *               例如：你们预计今天共有100万退货交易，那你们必须先做一笔100多万的充值交易，需做退货交易，晚上我们批处理后自动将余额转到你们对公账号。）
	 * @param param
	 * @return
	 */
	private ReturnState rechargeToAbcInnerAccount(Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String currencyCode = channelParms.get("200004");
		String bizCode_02 = channelParms.get("200006");// 02 新增加02_代收付业务代码
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort
		String rechargeAmt = channelParms.get("200025");

		Log4jUtil.info("-----------进入充值 方法-----------");

		ReturnState rs = new ReturnState(); // 保存返回给回执处理器的结果变量

		RechargeToAbcBean bean = (RechargeToAbcBean) param.getBizBean();
		AssertUtils.notNull(bean, TransReturnCode.code_9108, "实时代付请求数据中的交易业务bean[paybill]不能为空!");

		double rechargeAmt_ = bean.getRechargeAmount();
		if (StringUtils.isNotBlank(rechargeAmt) && !"0".equals(rechargeAmt)) {
			rechargeAmt_ = rechargeAmt_ + Double.parseDouble(rechargeAmt);
		}

		String account = bean.getPayerbankcardno(); // 充值交易时为商户对公账号
		String channelAmt = MoneyUtil.getFenString(new BigDecimal(rechargeAmt_)); // 渠道交易金额
		String toBankSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());// 农行银企交易流水-商户自定义序列号
		String remark = "".equals(bean.getOrdernote()) ? "充保证金" : bean.getOrdernote();
		String idCard = "";

		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("0220");// OK 1 交易码 4
		requestBean.setProcessCode("500000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setBizCode(bizCode_02);// OK 5 业务代码 2 Y
		requestBean.setAccount(account);// OK 6 主账号 19 左对齐右补空格 Y
		requestBean.setAccName(bean.getPayerbankcardName());// 户名
		requestBean.setAmt(channelAmt);// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		requestBean.setSysTrack(toBankSn);// 8 系统跟踪号 20 左对齐右补空格 Y
		requestBean.setInputCode("012");// OK 9 输入方式码 3 Y
		requestBean.setOriSysCode("");// 10 原系统参考号 20 左对齐右补空格 C
		requestBean.setCardValidDate("");// 11 卡有效期 4 左对齐右补空格 YYMM C
		requestBean.setAuthorCode("");// OK 12 授权码 2 左对齐右补空格 O
		requestBean.setRemark(remark);// OK 13 摘要 10 左对齐右补空格 C 限制最多四个汉字
		requestBean.setCurrencyCode(currencyCode);// OK 15 货币代码 3 Y
		requestBean.setMerchantStream(toBankSn);//
		requestBean.setIdCard(idCard);// 证件类型+证件号码

		// 保存到渠道流水表中,内部进行无需保存
		// CorpBillnoSn corpBillnoSn = new CorpBillnoSn();
		// BillnoSn billnoSn = corpBillnoSn.saveBillnoSn(toBankSn,param);

		ResponeBean responeBean = new ResponeBean();


		Log4jUtil.info("充值请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, requestBean);
		responeBean = tranProcess.trans(socketIP, socketPort, requestBean, md5CodeKey, "recharge");

		if (responeBean.getRetCode().equals("00")) {
			rs.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			rs.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回
		channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId, responeBean
				.getRetCode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		rs.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
		rs.setReturnMsg(respInfo); // 银行响应信息
		rs.setBankPostScript(respInfo);
		rs.setCreditNo(responeBean.getSysTrack()); // 银行返回凭证号码（银行端流水）
		rs.setSn(toBankSn); // 平台业务流水
		rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
		rs.setCardType(param.getCardType()); // 卡类型
		rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
		rs.setRelTranAmount(new BigDecimal(responeBean.getAmt()).divide(BigDecimal.valueOf(100))); // 实际扣款金额
		rs.setBillnosnSeq(toBankSn);

		// 更新流水对照表
		// corpBillnoSn.UpdateBillnoSn(param, rs, toBankSn);

		Log4jUtil.info("-----------充值结束-----------");

		try { // 要求第次延时 100毫秒
			Thread.sleep(100);
		} catch (InterruptedException e) {
			Log4jUtil.error("延时函数 【Thread.currentThread().sleep(100)】 出错！", e);
		}

		return rs;
	}

	/**
	 * 
	 * <p>自适应退款</p>
	 * 
	 * @param param
	 * @return
	 * @author 汤兴友 xytang
	 * @throws BizException
	 */
	public ReturnState dealAutoRealtimeRefund(Param param) throws BizException {
		ReturnState rs = new ReturnState();
		try {
			AutoRealTimeRefund autoRealTimeRefund = channelTransUtilService.getAutoRealTimeRefund(param);
			// 通过param来判断是走撤销或是走交易退款
			BillnoSn billnoSnOrg = (BillnoSn) billnoSnService.findBillnoSn(autoRealTimeRefund.getOrgTransChannelId(),
					autoRealTimeRefund.getOrgPaySn());
			AssertUtils.notNull(billnoSnOrg, TransReturnCode.code_9108,
					"渠道流水对照表中没有找到原流水号:" + autoRealTimeRefund.getOrgPaySn());
			String tranDate = billnoSnOrg.getTranDate();
			String curDate = DateUtil.getCurrentDate();

			/**
			 * 由于与银行的结算时间与00:00:00存在偏差，所以要交易失败后，要考虑其他方式的退款。
			 */
			if (tranDate.equals(curDate)) {// 撤消 --撤销失败再考虑用退款交易
				rs = this.dealRevoke(param, autoRealTimeRefund);
				rs.setClearingTransType(ClearingTransType.AUTO_REFUND_DEBEIT_CANCLE);
				if (!rs.getChannelCode().equals(TransReturnCode.code_0000)) {
					Log4jUtil.info("-----------撤销失败再考虑用退款交易-----------");
					rs = this.dealRealTimeRefund(param, autoRealTimeRefund, billnoSnOrg);
				}
			} else {// 实时退款 -- 退款失败再考虑用撤销交易
				rs = this.dealRealTimeRefund(param, autoRealTimeRefund, billnoSnOrg);
				if (!rs.getChannelCode().equals(TransReturnCode.code_0000)) {
					rs.setClearingTransType(ClearingTransType.AUTO_REFUND_DEBEIT_REFUND);
					Log4jUtil.info("-----------退款失败再考虑用撤销交易-----------");
					rs = this.dealRevoke(param, autoRealTimeRefund);
				}
			}

		} catch (BizException e) {
			Log4jUtil.error(e);
			throw e;
		}
		return rs;
	}

	/**
	 * 实时退款(含充值 ,重发)
	 * 
	 * @return
	 * @throws BizException
	 */
	private ReturnState dealRealTimeRefund(Param param, AutoRealTimeRefund refund, BillnoSn billnoSnOrg)
			throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String retCode_exceed = channelParms.get("200022");
		String rechargeAccount = channelParms.get("200023");
		String rechargeAccName = channelParms.get("200024");
		ReturnState rs = dealRealTimeRefund_(param, refund, billnoSnOrg);
		if (StringUtils.isNotBlank(retCode_exceed) && retCode_exceed.equals(rs.getBankRetCode())) {
			try {
				Log4jUtil.info("-------删除先前失败记录-----");
				billnoSnService.deleteById(rs.getBillnosnSeq());
			} catch (Exception e) {
				Log4jUtil.error(e);
			}
			Param rechargeParam = new Param();
			Log4jUtil.info("-----------余额不足或透支超后做充值交易-----------");
			// 先充值
			RechargeToAbcBean bean = new RechargeToAbcBean(refund.getRefundAmount().doubleValue(), rechargeAccount,
					rechargeAccName);
			rechargeParam.setBizBean(bean);
			ReturnState rechargeRs = this.rechargeToAbcInnerAccount(rechargeParam);

			if (!rechargeRs.getChannelCode().equals(TransReturnCode.code_0000)) {
				throw new BizException(TransReturnCode.code_9108, "退款前的充值操作失败;" + rechargeRs.getBankPostScript());
			}
			Log4jUtil.info("-----------充值交易完成，【重发】实时退款交易-----------");

			rs = dealRealTimeRefund_(param, refund, billnoSnOrg);
		}
		return rs;
	}

	/**
	 * 实时退款
	 * 
	 * @return
	 * @throws BizException
	 */
	private ReturnState dealRealTimeRefund_(Param param, AutoRealTimeRefund refund, BillnoSn billnoSnOrg)
			throws BizException {
		// 写Billno_sn表
		String newBankSendSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());
		BillnoSn saveBillnoSn = billnoSnService.saveBillnoSn(newBankSendSn, param);

		ReturnState rs = abcCorpQuickService.RealTimeRefund(newBankSendSn, refund, billnoSnOrg);
		// 更新billno_sn
		billnoSnService.updateBillnoSn(param, rs, newBankSendSn);
		rs.setBillnosnSeq(saveBillnoSn.getBillnosnSeq());
		return rs;
	}

	/**
	 * 
	 * @Description: 撤消
	 * @param autoRealTimeRefund
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState dealRevoke(Param param, AutoRealTimeRefund autoRealTimeRefund) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String currencyCode = channelParms.get("200004");
		String bizCode_02 = channelParms.get("200006");// 02 新增加02_代收付业务代码
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort
		Log4jUtil.info("-----------进入撤消 方法-----------");

		ReturnState rs = new ReturnState(); // 保存返回给回执处理器的结果变量

		// Paybill paybill = (Paybill) payBillService.findById(autoRealTimeRefund.getOrgPaySn());
		// AssertUtils.notNull(paybill, "渠道流水对照表中没有找到原流水号:" + autoRealTimeRefund.getOrgPaySn());

		// 根据channelId和 原交易流水查询渠道流水的方法
		BillnoSn billnoSnOrg = billnoSnService.findBillnoSn(autoRealTimeRefund.getOrgTransChannelId(),
				autoRealTimeRefund.getOrgPaySn());
		AssertUtils.notNull(billnoSnOrg, TransReturnCode.code_9108,
				"渠道流水对照表中没有找到原流水号:" + autoRealTimeRefund.getOrgPaySn());
		AssertUtils.notNull(billnoSnOrg.getBankRecvSn(), TransReturnCode.code_9108,
				StringUtil.r("原交易{?}的渠道流水对照表中BankRecvSn参数不能为空", autoRealTimeRefund.getOrgPaySn()));

		String account = autoRealTimeRefund.getRevBankCardNo(); // 银行卡号
		String accName = autoRealTimeRefund.getRevBankCardName();// 客户姓名 可选

		String channelAmt = MoneyUtil.getFenString(autoRealTimeRefund.getOrgAmount()); // 渠道交易金额
		String toBankSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());// 农行银企交易流水-商户自定义序列号
		String tranDate = DateUtil.getCurrentDate();
		String remark = autoRealTimeRefund.getOrgPayerRemark();

		String idCard = "";
		// IdType +"#" + IdNo +"#"+BeginDate + "#" +EndDate +" #" +Cvv2
		// AccountExtraData accountExtraData = new AccountExtraData(paybill.getAccountExtraData());
		// String certType = autoRealTimeRefund.getIdType();// 证件类型
		// String certNo = autoRealTimeRefund.getIdNo();// 证件号码
		// AssertUtils.notEmpty(certType, "证件类型不能为空");
		// AssertUtils.notEmpty(certNo, "证件号码不能为空");
		// certType = channelCertTypeService.getCertType(channelId, certType);
		// String idCard = certType + certNo;

		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("0200");// OK 1 交易码 4
		requestBean.setProcessCode("200000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setBizCode(bizCode_02);// OK 5 业务代码 2 Y
		requestBean.setAccount(account);// OK 6 主账号 19 左对齐右补空格 Y
		requestBean.setAmt(channelAmt);// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		requestBean.setSysTrack(toBankSn);// 8 系统跟踪号 20 左对齐右补空格 Y
		requestBean.setTranDate(tranDate);// OK 9 交易日期 8 YYYYMMDD C
		requestBean.setInputCode("012");// OK 10 输入方式码 3 Y

		requestBean.setOriSysCode(billnoSnOrg.getBankRecvSn());// 11 原系统参考号 20 左对齐右补空格 C
		requestBean.setCardValidDate("");// 12 卡有效期 4 左对齐右补空格 YYMM C
		requestBean.setAuthorCode("");// OK 13 授权码 2 左对齐右补空格 O
		requestBean.setRemark(remark);// OK 14 摘要 10 左对齐右补空格 C 限制最多四个汉字
		requestBean.setAccName(accName);// 15 户名 70 左对齐右补空格 Y
		requestBean.setCurrencyCode(currencyCode);// OK 16 货币代码 3 Y
		requestBean.setMerchantStream(autoRealTimeRefund.getOrgPaySn());// 17 商户交易流水号 20 左对齐右补空格
		requestBean.setIdCard(idCard);// 证件类型+证件号码
		requestBean.setTerminateStreamCode("");// 19 农行终端流水号 20

		// 保存到渠道流水表中
		BillnoSn billnoSn = billnoSnService.saveBillnoSn(toBankSn, param);

		ResponeBean responeBean = new ResponeBean();

		Log4jUtil.info("撤消请求发往到银行.");
		ObjectUtil.printPropertyString(channelId, requestBean);
		try {
			responeBean = tranProcess.trans(socketIP, socketPort, requestBean, md5CodeKey,
					ClearingTransType.AUTO_REAL_TIME_REFUND);
		} catch (BizException e) {
			Log4jUtil.error(e);
			Log4jUtil.info("-----------交易处理【超时】,进入冲正处理:");
			if (e.getErrorCode().equals(TransReturnCode.code_9109)
					|| e.getErrorCode().equals(TransReturnCode.code_9108)) {
				ResponeBean rb = null;
				String msg = "交易处理超时,后续的冲正交易失败 ！";
				try {
					rb = tranProcess.trans(socketIP, socketPort, buildRushBean(requestBean), md5CodeKey, "rush");
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				if (rb != null && rb.getRetCode().equals("00")) {
					msg = "交易处理超时,后续的冲正交易已成功！";
					throw new BizException(TransReturnCode.code_9109, msg);
				} else {
					throw new BizException(TransReturnCode.code_9109, e.getMessage());
					// msg = "冲正失败或超时，原撤销交易默认为成功！";
					// // 超时情况下组ReturnState
					// rs = new ReturnState();
					// rs.setReturnState(PayState.SUCCEED_RTN);
					// rs.setReturnMsg("超时作成功处理！"); // 银行响应信息
					// rs.setBankPostScript("超时作成功处理！");
					// rs.setSn(billnoSn.getSn()); // 平台业务流水
					// rs.setChannelCode("0000"); // 渠道返回给业务层状态码
					// rs.setCardType(param.getCardType()); // 卡类型
					// rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
					// rs.setRelTranAmount(new BigDecimal(Double.valueOf(requestBean.getAmt()) /
					// 100)); // 实际扣款金额
					// rs.setBillnosnSeq(billnoSn.getBillnosnSeq());
				}
			} else {
				throw new BizException(TransReturnCode.code_9109, e.getMessage());
			}
		}

		// 有回执信息下组ReturnState
		if (StringUtils.isNotBlank(responeBean.getRetCode())) {

			ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回
			channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId,
					responeBean.getRetCode()));
			String channelCode = TransReturnCode.code_9900, respInfo = "";
			if (channelRtncode == null) {
				channelCode = TransReturnCode.code_9900;
			} else {
				channelCode = channelRtncode.getKftRtncode();
				respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
			}

			rs.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
			rs.setReturnMsg(respInfo); // 银行响应信息
			rs.setBankPostScript(respInfo);
			rs.setCreditNo(responeBean.getSysCode()); // 银行返回凭证号码（银行端流水）
			rs.setSn(billnoSn.getSn()); // 平台业务流水
			rs.setChannelCode(channelCode); // 渠道返回给业务层状态码
			rs.setCardType(param.getCardType()); // 卡类型
			rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
			rs.setRelTranAmount(new BigDecimal(Double.valueOf(responeBean.getAmt()) / 100)); // 实际扣款金额
			rs.setBillnosnSeq(billnoSn.getBillnosnSeq());
			if (responeBean.getRetCode().equals("00")) {
				rs.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
				rs.setBankPostScript("撤消成功");
				rs.setReturnMsg("撤消成功");
				Log4jUtil.info("农行快捷撤销处理成功,撤消的[BillnosnSeq]为:" + billnoSn.getBillnosnSeq());
			} else {
				rs.setReturnState(PayState.FAILED_STR);
			}
		}
		// 更新流水对照表
		billnoSnService.updateBillnoSn(param, rs, toBankSn);
		return rs;
	}

	/**
	 * 批量代收付
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public ReturnState batchBizDeal(Param param, boolean repeatSend, String channelBatchId) throws BizException {
		ReturnState returnState = new ReturnState(); // 返回结果的 bean
		String trantype = param.getClearingTransType();

		if (repeatSend) { // 批量重发交易
			Log4jUtil.info("-----------批量重发交易，批量业务的批次号：" + channelBatchId);
			returnState = send_batch_ReSend(param, trantype, channelBatchId);
		} else { // 批量交易
			returnState = batchDistributeSend(param, trantype, channelBatchId);
		}
		return returnState;
	}

	/**
	 * 
	 * @param param
	 * @param trantype
	 * @return
	 */
	private ReturnState batchDistributeSend(Param param, String trantype, String channelBatchId) throws BizException {
		List<ChannelTempBill> bizObjectList = (List<ChannelTempBill>) param.getBizBean();

		// 此批次号的交易记录数为0
		if (bizObjectList == null || bizObjectList.size() == 0)
			return this.makeFailReturn();

		// 发送交易(生成批量处理文件，FTP到服务器,保存记录到 billnoSn表并发送交易。)
		BatchBean batchBean = abcCorpQuickService.sendBatch(trantype, bizObjectList, channelBatchId);
		// 更新交易结果
		// abcCorpQuickService.updateBatchSend(batchBean.getTrantype(),
		// batchBean.getChannelBatchNo(),
		// batchBean.getReturnState());

		return batchBean.getReturnState();
	}

	/**
	 * 批量重发
	 * 
	 * @param channelBatchId
	 * @param trantype
	 * @return
	 * @throws BizException
	 */
	private ReturnState send_batch_ReSend(Param param, String trantype, String channelBatchId) throws BizException {
		List<ChannelTempBill> bizObjectList = (List<ChannelTempBill>) param.getBizBean();

		// 此批次号的交易记录数为0
		if (bizObjectList == null || bizObjectList.size() == 0)
			return this.makeFailReturn();

		// 发送交易(生成批量处理文件，FTP到服务器,保存记录到 billnoSn表并发送交易。)
		BatchBean batchBean = abcCorpQuickService.sendBatch(trantype, bizObjectList, channelBatchId);
		// 更新交易结果
		// abcCorpQuickService.updateBatchSend(batchBean.getTrantype(),
		// batchBean.getChannelBatchNo(),
		// batchBean.getReturnState());

		return batchBean.getReturnState();
	}

	/**
	 * 
	 * @return
	 */
	private ReturnState makeFailReturn() {
		ReturnState rs = new ReturnState();
		rs.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		rs.setBankRetCode("9999"); // 银行返回代码
		rs.setReturnMsg("清分得到的 channelBatchIdList 为空，没有批量记录"); // 银行响应信息
		rs.setBankPostScript("清分得到的 channelBatchIdList 为空，没有批量记录");// 银行返回信息
		rs.setSn(""); // 平台业务流水
		rs.setChannelCode(TransReturnCode.code_9900); // 渠道返回给业务层状态码
		rs.setCardType(""); // 卡类型
		rs.setReturnObj(""); // 返回的实体对象
		rs.setCheckDate(DateUtil.getCurrentDate()); // 渠道结算日期
		rs.setRelTranAmount(new BigDecimal(0.0)); // 实际扣款金额
		rs.setBillnosnSeq(""); // 业务表流水
		return rs;
	}

	/**
	 * 根据原requestBean创建冲正的requestBean
	 * 
	 * @param requestBean
	 * @return
	 */
	public RequestBean buildRushBean(RequestBean rb) {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String currencyCode = channelParms.get("200004");
		RequestBean rushRb = new RequestBean();

		// String bankSendSn = sequenceManagerService.getCorpAbcQuickSN(DateUtil.getCurrentDate());
		rushRb.setTranCode("0400");// OK 1 交易码 4
		rushRb.setProcessCode(rb.getProcessCode());// OK 2 处理码 6
		rushRb.setTerminateCode(rb.getTerminateCode());// 3 终端号 8 左对齐右补空格 Y
		rushRb.setMerchantCode(rb.getMerchantCode());// 4 商户号 15 左对齐右补空格 Y
		rushRb.setBizCode(rb.getBizCode());// OK 5 业务代码 2 Y
		rushRb.setAccount(rb.getAccount());// OK 6 主账号 19 左对齐右补空格 Y
		rushRb.setAmt(rb.getAmt());// OK 7 交易金额 12 以分为单位不含小数点 长度不足左补零 C
		rushRb.setSysTrack(rb.getSysTrack());// 8 系统跟踪号 20 左对齐右补空格 Y
		rushRb.setInputCode(rb.getInputCode());// OK 10 输入方式码 3 Y
		rushRb.setCardValidDate(rb.getCardValidDate());// 12 卡有效期 4 左对齐右补空格 YYMM
														// C
		rushRb.setAuthorCode(rb.getAuthorCode());// OK 13 授权码 2 左对齐右补空格 O
		rushRb.setCurrencyCode(currencyCode);// OK 16 货币代码 3 Y
		rushRb.setMerchantStream(rb.getMerchantStream());// 17 商户交易流水号 20 左对齐右补空格
		return rushRb;
	}

	/**
	 * 农行快捷系统批量交易结果处理 -- 批量交易结果文件下载,并更新批量交易记录
	 * 
	 * @throws BizException
	 */
	public void batchRetProcess() throws BizException {
		Log4jUtil.info("农行快捷系统批量交易结果处理 batchRetProcess");

		List<String> batchIdList = new ArrayList<String>();
		batchIdList = channelBatchService.getCorpBatchIdList(channelId);

		Log4jUtil.info(line + "农行快捷系统要查询的批理业务交易结果的批次号start");
		for (int i = 0; i < batchIdList.size(); i++) {
			Log4jUtil.info(line + "批次号 " + (i + 1) + " : " + batchIdList.get(i));
		}
		Log4jUtil.info(line + "农行快捷系统要查询的批处理业务交易结果的批次号end");

		// 2、根据批量交易的批次号list，做批量交易结果 处理
		Log4jUtil.info(line + "农行快捷系统批理交易结果处理开始");
		String channelBatchId = "";
		for (int i = 0; i < batchIdList.size(); i++) {
			channelBatchId = batchIdList.get(i);
			Param param = new Param();
			param.setBizBean(channelBatchId); // 参数是 Channel_batch.channel_batchId

			Log4jUtil.info("----------开始处理渠道批次：" + channelBatchId);

			BatFileResultQueryRsp rsp = null;
			try {
				rsp = ccbRepayMsgDeal.batRetDeal(param);
			} catch (BizException e) {
				Log4jUtil.error("错误信息：", e);
				continue;
			}

			if ("0000".equals(rsp.getRetCode())) {
				// 回盘成功
				// 用事务处理批量返回数据
				abcCorpQuickService.predeal(channelBatchId, rsp.getFileNameRcvPath(), rsp.getTranDate());
			} else {
				// 回盘失败
				if (rsp.getRetMsg().contains("批交易全部失败")) {
					try {
						abcCorpQuickService.predealFail(channelBatchId, rsp.getTranDate(), rsp.getRetMsg(),
								rsp.getRetCode(), Double.valueOf(rsp.getTotalAmt()) / 100);
					} catch (BizException e) {
						Log4jUtil.info("渠道批次为:{}的交易结果处理失败:{}", channelBatchId, e.getMessage());
					}
				} else {
					Log4jUtil.info("渠道批次为:{}的交易结果 银行未生成,待下次处理.", channelBatchId);
					continue;
				}
			}
			Log4jUtil.info("渠道批次为:{}的交易结果处理完成", channelBatchId);
		}
		Log4jUtil.info(line + "农行快捷系统批理交易结果处理完成");
	}
	
	/**
	 * 
	 * <p>信用卡账户验证</p>
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 * @throws NoSuchAlgorithmException
	 */
	public ReturnState creditCardAccountVerify(Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String merchantID = channelParms.get("200001");
		String terminateCode = channelParms.get("200002");
		String md5CodeKey = channelParms.get("200003");
		String socketIP = channelParms.get("200010"); // socketIP
		String socketPort = channelParms.get("200011");// socketPort
		ReturnState returnState = new ReturnState(); // 保存返回给回执处理器的结果变量
		// 商户自定义序列号
		final BankCardVerifyDTO accountVerfy = (BankCardVerifyDTO) param.getBizBean();
		AssertUtils.notNull(accountVerfy, TransReturnCode.code_9108, "农行快捷报文方式的账户验证数据不能为空!");

		final String account = accountVerfy.getBankCardNo(); // 银行卡号
		final String accName = accountVerfy.getCardHolderName();// 客户姓名 可选
		final String certNo = accountVerfy.getCertificateNo();// 证件号码 可选
		final String mobile = accountVerfy.getPhoneNumber();// 手机号码 可选

		// 把快付通证件类型转换为快捷系统证件类型
		AssertUtils.notNull(account, TransReturnCode.code_9108, "持卡人身份验证请求的银行卡号不能为空!");
		AssertUtils.notNull(accName, TransReturnCode.code_9108, "持卡人身份验证请求的银行卡户名不能为空!");
		// AssertUtils.notNull(certNo, TransReturnCode.code_9108, "持卡人身份验证请求的证件号码不能为空!");
		AssertUtils.notNull(mobile, TransReturnCode.code_9108, "持卡人身份验证请求的手机号码不能为空!");
		
		RequestBean requestBean = new RequestBean();

		requestBean.setTranCode("1136");// OK 1 交易码 4
		requestBean.setProcessCode("000000");// OK 2 处理码 6
		requestBean.setTerminateCode(terminateCode);// 3 终端号 8 左对齐右补空格 Y
		requestBean.setMerchantCode(merchantID);// 4 商户号 15 左对齐右补空格 Y
		requestBean.setAccount(account);// OK 5主账号 19 左对齐右补空格 Y
		requestBean.setAccName(accName);// 6 户名 70 左对齐右补空格 Y
		requestBean.setCardValidDate(StringUtils.defaultString(accountVerfy.getCreditCardExpiryDate(), ""));// 7 卡有效期 4 YYMM C
		requestBean.setAuthorCode("");//8 授权码 3 CVV2/CVN2/CVD2 C
//		requestBean.set("");//9校验方式S-按银联标准校验后6位，不送按默认全部校验 Y
		requestBean.setIdCard(certNo);// 10  证件号码
		requestBean.setMobile(mobile);//11 手机号 15 左对齐右补空格 C
		
		ResponeBean responeBean = tranProcess.creditCardAccountVerify(socketIP, socketPort, requestBean, md5CodeKey);

		// TransReturnCode.code_0000.getValue();
		if (responeBean.getRetCode().equals("00")) {
			returnState.setReturnState(PayState.SUCCEED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		} else {
			returnState.setReturnState(PayState.FAILED_STR); // 银行返回状态---超时：T、成功：S、失败：F
		}

		ChannelRtncode channelRtncode = (ChannelRtncode) channelRtncodeService.findById(new ChannelRtncodeId(channelId, responeBean.getRetCode()));
		String channelCode = TransReturnCode.code_9900, respInfo = "";
		if (channelRtncode == null) {
			channelCode = TransReturnCode.code_9900;
		} else {
			channelCode = channelRtncode.getKftRtncode();
			respInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100);
		}

		// returnState.setReturnState(PayState.SUCCEED_RTN); //银行返回状态---超时：T、成功：S、失败：F
		returnState.setBankRetCode(responeBean.getRetCode()); // 银行返回代码
		returnState.setReturnMsg(respInfo); // 银行响应信息
		returnState.setBankPostScript(respInfo);
		returnState.setCreditNo(""); // 银行返回凭证号码（银行端流水）
		returnState.setSn(""); // 平台业务流水
		returnState.setChannelCode(channelCode); // 渠道返回给业务层状态码
		returnState.setCardType(""); // 卡类型
		returnState.setReturnObj(""); // 返回的实体对象
		returnState.setCheckDate(""); // 渠道结算日期
		returnState.setRelTranAmount(BigDecimal.ZERO); // 实际扣款金额
		returnState.setBillnosnSeq("");
		
		return returnState;
	}

}
