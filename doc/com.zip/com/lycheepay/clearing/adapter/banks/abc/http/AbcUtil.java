package com.lycheepay.clearing.adapter.banks.abc.http;

import java.util.Map;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelParamUtil;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.util.Log4jUtil;


public class AbcUtil {

	/**
	 * 检查参数配置
	 * 
	 * @param logPrefix
	 * @param type
	 * @param channelParam
	 * @return
	 * @throws BizException
	 */
	public Map<String, String> checkChannelParam(final String logPrefix, final String type,
			final Map<String, String> channelParam) throws BizException {
		String key = "";
		String defaultValue = "";
		String keyName = "";
		String logMsg = "";
		logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
		Log4jUtil.info(logMsg);

		if (type.equals(ClearingTransType.NET_DEDUCT_B2C_PAY) || type.equals(ClearingTransType.NET_DEDUCT_B2C_RECHARGE)) {
			// 网银支付
			key = "100001";
			keyName = "处理结果返回URL";
			defaultValue = "https://cashier.lycheepay.com/abcServlet";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100002";
			keyName = "页面处理结果返回URL";
			defaultValue = "https://cashier.lycheepay.com/abcHttpServlet";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100004";
			keyName = "商品种类";
			defaultValue = "1";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100005";
			keyName = "单笔最大金额";
			defaultValue = "10000000";
			final String sMaxAmount = channelParam.get("100005");
			if (!StringUtil.isNumeric(sMaxAmount) || sMaxAmount == null) {
				logMsg = logPrefix + "获取到渠道参数中的【" + key + "】【" + keyName + "】非合法数字。默认填写为：" + defaultValue;
				Log4jUtil.info(logMsg);
				channelParam.put(key, defaultValue);
			}

			key = "100006";
			keyName = "支付类型";
			defaultValue = "A";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100007";
			keyName = "商户通知方式";
			defaultValue = "1";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100008";
			keyName = "支付接入方式";
			defaultValue = "1";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100010";
			keyName = "产品ID";
			defaultValue = "888888";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100011";
			keyName = "产品名称";
			defaultValue = "快付通支付款";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			key = "100012";
			keyName = "产品名称";
			defaultValue = "快付通充值款";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		} else if (type.equals(ClearingTransType.NET_DEDUCT_B2B)) {
			key = "100001";
			keyName = "处理结果返回URL";
			defaultValue = "https://cashier.lycheepay.com/abcB2BServlet";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

		} else if (type.equals(ClearingTransType.ONLINE_ACCOUNT_VERIFY)) {
			// 网银验证
			key = "100002";
			keyName = "页面处理结果返回URL";
			defaultValue = "https://cashier.lycheepay.com/abcHttpServlet";
			ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);

			// } else if (type.equals(ChannelTransType.Net_Bank_Pay + "99")) {
			// 支付回执
			// 暂时回执不通过此处进行检验

			// } else if (type.equals(ChannelTransType.PayRefund)) {
			//
			// key = "100013";
			// keyName = "每批退款最大笔数";
			// defaultValue = "100";
			// final String sMaxAmount = channelParam.get("100013");
			// if (!StringUtil.isNumeric(sMaxAmount) || sMaxAmount == null) {
			// logMsg = logPrefix + "获取到渠道参数中的【" + key + "】【" + keyName + "】非合法数字。默认填写为：" +
			// defaultValue;
			// Log4jUtil.info(logMsg);
			// channelParam.put(key, defaultValue);
			// }
		}
		logMsg = logPrefix + "对渠道参数检查结束。";
		Log4jUtil.info(logMsg);
		return channelParam;

	}
}