package com.lycheepay.clearing.adapter.banks.abc.credit.kft.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.ByteUtils;
import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.MsgPack4Abc;
import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.MsgPackUtils4Abc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.DeductPayReal;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行消息处理工具服务类<(严格区分Util与UtilsService,前者为简单的静态工具类,后者需要注入其他service，并且与数据库有交集;调用方可以明显区分,
 * 如果有Service,不允许new出该对象)/P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 上午3:59:36
 */
@Service(ClearingAdapterAnnotationName.ABC_CREDIT_MSG_UTIL_SERVICE)
public class AbcCreditMsgUtilService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManager;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	/**
	 * 
	 * 创建联机签到请求 MsgPack
	 * 
	 * @param param 基础平台传给渠道的param(调用此方法是请注入非静态方法)
	 * @param bankSendSn 渠道发送流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack4Abc createSignInMsgPack4Abc() throws BizException {

		final MsgPack4Abc msgPack4Abc = new MsgPack4Abc();
		// 签到
		// MsgPackUtils4Abc.createHeadField(msgPack4Abc,
		// ByteUtils.strToBcd(""));
		MsgPackUtils4Abc.createTpduField(msgPack4Abc, ByteUtils.strToBcd("6000000000"));
		MsgPackUtils4Abc.createMsgType(msgPack4Abc, "0800");// 消息类型
		MsgPackUtils4Abc.createField3(msgPack4Abc, "940000");// 交易处理码
		MsgPackUtils4Abc.createField25Abc(msgPack4Abc, "14");// 服务点条件码 --//
		// 电子商务，代码：51；

		final ChannelParm mechineCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100003"));
		MsgPackUtils4Abc.createField41(msgPack4Abc, mechineCode.getParvalue());// 受卡机终端标识码-终端代码

		final ChannelParm mechantCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100004"));
		MsgPackUtils4Abc.createField42(msgPack4Abc, mechantCode.getParvalue());// 受卡方标识码-商户代码

		final ChannelParm operatorCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100011"));
		MsgPackUtils4Abc.createField60AbcConsume(msgPack4Abc, operatorCode.getParvalue());// 操作员号

		// 计算64域，MAC的值，签到报文是不需要用到 mac 值的。

		return msgPack4Abc;
	}

	public static void displayByteArray(final byte[] byteArray, final String name) {
		String x = "", y = "", z = "";
		for (final byte element : byteArray) {
			x += encodehex(element) + " ";
			y += element + " ";
			z += encodehex(element);
		}

		Log4jUtil.info("=======x===" + name + "=========" + x);
		Log4jUtil.info("=======y===" + name + "=========" + y);
		Log4jUtil.info("=======z===" + name + "=========" + z);
	}

	/**
	 * 
	 * 创建撤销请求 MsgPack
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道发送流水
	 * @returnc
	 * @throws BizException
	 */
	public MsgPack4Abc createCancelMsgPack4Abc(final BillnoSn billnoSn) throws BizException {
		// 用公共方法，将基础平台的实体转换成渠道默认实体

		final String mainAccount = billnoSn.getOtheracctno();
		final Double tranAmount = DecimalUtil.formatToDouble(billnoSn.getActualAmount());
		final String organizedSysreflectedSn = billnoSn.getBankRecvSn();
		Log4jUtil.info("农行信用卡退款：billnosn======" + "==mainAccount===" + mainAccount + "==tranAmount===" + tranAmount
				+ "==organizedSysreflectedSn===" + organizedSysreflectedSn);
		// 创建消费交易消息
		final MsgPack4Abc msgPack4Abc = new MsgPack4Abc();
		// 创建TPDU
		MsgPackUtils4Abc.createTpduField(msgPack4Abc, ByteUtils.strToBcd("6000000000"));
		// 创建交易类型
		MsgPackUtils4Abc.createMsgType(msgPack4Abc, "0200");
		// 主账号
		MsgPackUtils4Abc.createField2(msgPack4Abc, mainAccount);
		// 交易处理码
		MsgPackUtils4Abc.createField3(msgPack4Abc, "02A000");
		// 交易金额
		MsgPackUtils4Abc.createField4(msgPack4Abc, tranAmount);
		// 受卡方系统跟踪号-POS流水号
		Log4jUtil.info("sequenceManager.getAbcCreditPosSN()===" + sequenceManager.getAbcCreditPosSN());
		final String newPosSn = StringUtils.leftPad(sequenceManager.getAbcCreditPosSN(), 6, "0");
		MsgPackUtils4Abc.createField11(msgPack4Abc, newPosSn);

		final Calendar cale = Calendar.getInstance();
		MsgPackUtils4Abc.createField12(msgPack4Abc, new SimpleDateFormat("HHmmss").format(cale.getTime()));
		MsgPackUtils4Abc.createField13(msgPack4Abc, new SimpleDateFormat("MMdd").format(cale.getTime()));

		// 服务点输入方式码
		MsgPackUtils4Abc.createField22Abc(msgPack4Abc, "902");
		// 交换指示符和服务代码
		MsgPackUtils4Abc.createField24(msgPack4Abc, "120");
		// 服务点条件码
		MsgPackUtils4Abc.createField25Abc(msgPack4Abc, "14");
		// 二磁道数据
		MsgPackUtils4Abc.createField35(msgPack4Abc, "0000000000000000000000000000000000000");
		// 三磁道数据
		MsgPackUtils4Abc
				.createField36(msgPack4Abc,
						"00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");

		// 系统参考号 在请求交易中，填写原交易系统参考号
		Log4jUtil.info("系统参考号===" + organizedSysreflectedSn);
		MsgPackUtils4Abc.createField37(msgPack4Abc, organizedSysreflectedSn);

		// 受卡机终端标识码-终端代码
		final ChannelParm mechineCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100003"));
		MsgPackUtils4Abc.createField41(msgPack4Abc, mechineCode.getParvalue());
		// 受卡方标识码-商户代码
		final ChannelParm mechantCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100004"));
		MsgPackUtils4Abc.createField42(msgPack4Abc, mechantCode.getParvalue());
		// 交易货币代码 默认
		MsgPackUtils4Abc.createField49(msgPack4Abc, "156");

		// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		final ChannelParm operatorCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100012"));
		MsgPackUtils4Abc.createField60AbcConsume(msgPack4Abc, operatorCode.getParvalue());
		// 凭证号批次号
		final ChannelParm pzSn = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200001"));
		MsgPackUtils4Abc.createField62(msgPack4Abc, pzSn.getParvalue());
		checkSignReturnDate(pzSn);
		// MAC
		MsgPackUtils4Abc.createField64(msgPack4Abc, new byte[0]);
		final ChannelParm workKey = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200003"));
		final byte[] workKey_last8 = hexToBytes(workKey.getParvalue().substring(50, 66));

		// 显示
		displayByteArray(workKey_last8, "workKey_last8");

		// 返回macKey
		final byte[] macKey = getMacKEY(workKey_last8);

		// 显示
		displayByteArray(macKey, "macKey");

		if (macKey == null) {
			Log4jUtil.info("The mac key is null,please check the reason -:),Send message process is broken!!!");
			return null;
		}
		try {
			MsgPackUtils4Abc.create64mac(msgPack4Abc, macKey);
			Log4jUtil.info("Mac process success");
		} catch (final Exception e) {
			Log4jUtil.info("Mac process failed, please check the reason -:),Send message process is broken!!!"
					+ e.getMessage());
			return null;
		}

		Log4jUtil.info("农行信用卡组报文撤销cancel结束--<<");
		return msgPack4Abc;// 发送报文
	}

	/**
	 * 创建公共的8583报文头信息
	 * 
	 * @param MsgPack4Abc
	 * @throws BizException
	 */
	public void createHeadMsg(final MsgPack4Abc MsgPack4Abc) throws BizException {
		MsgPackUtils4Abc.createTpduField(MsgPack4Abc, ByteUtils.strToBcd("6000000000"));
		// MsgPackUtils4Abc.createHeadField(MsgPack4Abc, ByteUtils
		// .strToBcd("6001013000"));
	}

	/**
	 * 用HEX形式显示
	 * 
	 * @integer 将要用HEX形式显示的字节
	 */
	public static String encodehex(final int integer) {
		final StringBuffer buf = new StringBuffer(2);
		if ((integer & 0xff) < 0x10) {
			buf.append("0");
		}
		buf.append(Long.toString(integer & 0xff, 16));
		return buf.toString();
	}

	/**
	 * HEX字符串，每2个一组转成十六进制字节
	 * 
	 * @param String 要转成十六进制数组的字符串
	 */
	public static byte[] hexToBytes(final String s) {
		final byte[] bytes = new byte[s.length() / 2];
		for (int i = 0; i < bytes.length; i++) {
			bytes[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
		}
		return bytes;
	}

	/**
	 * bytes转换成十六进制字符串
	 * 
	 * @param b
	 * @return
	 */
	public static String byte2HexStr(final byte[] b) {
		String hs = "";
		String stmp = "";
		for (final byte element : b) {
			stmp = (Integer.toHexString(element & 0XFF));
			if (stmp.length() == 1) {
				hs = hs + "0" + stmp;
			} else {
				hs = hs + stmp;
			}
		}
		return hs.toUpperCase();
	}

	/**
	 * 用成分1，2，3解密MAC主密钥.
	 * 
	 * @param encodeKEY_field61 签到报文第61域返回的最后8个字节，传入之前已经截取完毕
	 */
	private byte[] getMacKEY(final byte[] encodeKEY_field61) {
		final ChannelParm Key1 = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100005"));
		final ChannelParm Key2 = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100007"));
		final ChannelParm Key3 = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100009"));
		final byte[] K1 = hexToBytes(Key1.getParvalue());
		final byte[] K2 = hexToBytes(Key2.getParvalue());
		final byte[] K3 = hexToBytes(Key3.getParvalue());
		final byte[] masterKey = hexToBytes(Key1.getParvalue());

		for (int i = 0; i < K1.length; i++) {
			masterKey[i] = (byte) (K1[i] ^ K2[i] ^ K3[i]);
		}

		byte[] macKey = new byte[encodeKEY_field61.length];

		displayByteArray(masterKey, "masterKey成分1，2，3异或结果");

		final byte[] masterKeyComplete = new byte[masterKey.length + 8];
		Log4jUtil.info("masterKey==len====" + masterKey.length);
		System.arraycopy(masterKey, 0, masterKeyComplete, 0, masterKey.length);
		System.arraycopy(masterKey, 0, masterKeyComplete, masterKey.length, 8);
		Log4jUtil.info("masterKeyComplete=len=" + masterKeyComplete.length);

		displayByteArray(masterKeyComplete, "masterKeyComplete KEY1==KEY3  ");
		try {
			macKey = J2DES.trides_decrypt(masterKey, encodeKEY_field61);
			return macKey;
		} catch (final Exception e) {
			Log4jUtil.info("the method getMacKEY got an exception, please check the reason -:), return macKey as null "
					+ e.getMessage());
			return null;
		}

	}

	/**
	 * 
	 * 创建MOTO消费报文 MsgPack4Abc(调用此方法是请注入非静态方法)
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道发送流水
	 * @return
	 * @throws Exception
	 */
	public MsgPack4Abc createMOTOConsumeMsgPack4Abc(final Param param) throws BizException {
		// 用公共方法，将基础平台的实体转换成渠道默认实体
		final DeductPayReal debit_Pay_Real = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debit_Pay_Real);

		final String mainAccount = debit_Pay_Real.getOut_Account();
		final Double tranAmount = debit_Pay_Real.getAmount_Num();
		final String expireDate = debit_Pay_Real.getExpdate();
		final String lastThree = debit_Pay_Real.getCvv2();

		// 创建消费交易消息
		final MsgPack4Abc msgPack4Abc = new MsgPack4Abc();
		// 创建TPDU
		MsgPackUtils4Abc.createTpduField(msgPack4Abc, ByteUtils.strToBcd("6000000000"));
		// 创建交易类型
		MsgPackUtils4Abc.createMsgType(msgPack4Abc, "0200");
		// 主账号
		MsgPackUtils4Abc.createField2(msgPack4Abc, mainAccount);
		// 交易处理码
		MsgPackUtils4Abc.createField3(msgPack4Abc, "00A000");
		// 交易金额
		MsgPackUtils4Abc.createField4(msgPack4Abc, tranAmount);
		// 受卡方系统跟踪号-POS流水号
		Log4jUtil.info("sequenceManager.getAbcCreditPosSN()===" + sequenceManager.getAbcCreditPosSN());
		final String newPosSn = StringUtils.leftPad(sequenceManager.getAbcCreditPosSN(), 6, "0");
		MsgPackUtils4Abc.createField11(msgPack4Abc, newPosSn);

		final Calendar cale = Calendar.getInstance();
		MsgPackUtils4Abc.createField12(msgPack4Abc, new SimpleDateFormat("HHmmss").format(cale.getTime()));
		MsgPackUtils4Abc.createField13(msgPack4Abc, new SimpleDateFormat("MMdd").format(cale.getTime()));
		// 卡有效期
		MsgPackUtils4Abc.createField14(msgPack4Abc, expireDate);
		// 服务点输入方式码
		MsgPackUtils4Abc.createField22Abc(msgPack4Abc, "012");
		// 卡顺序号
		// MsgPackUtils4Abc.createField23(msgPack4Abc, lastThree);
		// 服务点条件码
		MsgPackUtils4Abc.createField25Abc(msgPack4Abc, "08");
		// 受卡机终端标识码-终端代码
		final ChannelParm mechineCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100003"));
		MsgPackUtils4Abc.createField41(msgPack4Abc, mechineCode.getParvalue());
		// 受卡方标识码-商户代码
		final ChannelParm mechantCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100004"));
		MsgPackUtils4Abc.createField42(msgPack4Abc, mechantCode.getParvalue());
		// 附加数据
		MsgPackUtils4Abc.createField48(msgPack4Abc, lastThree);
		// 交易货币代码 默认
		MsgPackUtils4Abc.createField49(msgPack4Abc, "156");

		// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		final ChannelParm operatorCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100011"));
		MsgPackUtils4Abc.createField60AbcConsume(msgPack4Abc, operatorCode.getParvalue());
		// 凭证号批次号
		final ChannelParm pzSn = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200001"));
		MsgPackUtils4Abc.createField62(msgPack4Abc, pzSn.getParvalue());

		checkSignReturnDate(pzSn);

		// MAC
		MsgPackUtils4Abc.createField64(msgPack4Abc, new byte[0]);
		final ChannelParm workKey = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200003"));
		final byte[] workKey_last8 = hexToBytes(workKey.getParvalue().substring(50, 66));

		// 显示
		displayByteArray(workKey_last8, "workKey_last8");

		// 返回macKey
		final byte[] macKey = getMacKEY(workKey_last8);

		// 显示
		displayByteArray(macKey, "macKey");

		if (macKey == null) {
			Log4jUtil.info("The mac key is null,please check the reason -:),Send message process is broken!!!");
			return null;
		}
		try {
			MsgPackUtils4Abc.create64mac(msgPack4Abc, macKey);
			Log4jUtil.info("Mac process success");
		} catch (final Exception e) {
			Log4jUtil.info("Mac process failed, please check the reason -:),Send message process is broken!!!"
					+ e.getMessage());
			return null;
		}

		return msgPack4Abc;
	}

	private void checkSignReturnDate(final ChannelParm channelParm) throws BizException {
		final Date localDate = new Date();
		final Date signInDate = channelParm.getUpdatetime();

		final long between = (localDate.getTime() - signInDate.getTime()) / 1000;// 除以1000是为了转换成秒
		Log4jUtil.info("签到时间与当前的时间差：" + between + "  毫秒");
		final long day1 = between / (24 * 3600);
		Log4jUtil.info("签到时间与当前的时间差：" + day1 + "  天");
		final long hour1 = between % (24 * 3600) / 3600;
		Log4jUtil.info("签到时间与当前的时间差：" + hour1 + "  小时");
		if (!(day1 < 1 && hour1 < 24)) {
			// 自定义1234567表示，今天没有签到
			throw new BizException("1234567", "签到返回参数的日期不是今天");
		}
	}

	/**
	 * <p>(调用此方法是请注入非静态方法)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午4:57:34
	 */
	public MsgPack4Abc createRejectMsgPack4Abc(final BillnoSn billnoSn) throws BizException {
		// 用公共方法，将基础平台的实体转换成渠道默认实体
		final String expireDate = billnoSn.getValiddate();
		final String organnizedPzBatchId = billnoSn.getCreditbatchno();
		final String mainAccount = billnoSn.getOtheracctno();
		final Double tranAmount = DecimalUtil.formatToDouble(billnoSn.getActualAmount());
		final String organizedSysreflectedSn = billnoSn.getBankRecvSn();

		Log4jUtil.info("农行信用卡退款：billnosn===2===" + "==mainAccount===" + mainAccount + "==tranAmount===" + tranAmount
				+ "==expireDate===" + expireDate + "==organizedSysreflectedSn===" + organizedSysreflectedSn
				+ "==organnizedPzBatchId===" + organnizedPzBatchId);

		// 创建消费交易消息
		final MsgPack4Abc msgPack4Abc = new MsgPack4Abc();
		// 创建TPDU
		MsgPackUtils4Abc.createTpduField(msgPack4Abc, ByteUtils.strToBcd("6000000000"));
		// 创建交易类型
		MsgPackUtils4Abc.createMsgType(msgPack4Abc, "0220");
		// 主账号
		MsgPackUtils4Abc.createField2(msgPack4Abc, mainAccount);
		// 交易处理码
		MsgPackUtils4Abc.createField3(msgPack4Abc, "2000B0");
		// 交易金额
		MsgPackUtils4Abc.createField4(msgPack4Abc, tranAmount);
		// 受卡方系统跟踪号-POS流水号
		Log4jUtil.info("sequenceManager.getAbcCreditPosSN()===" + sequenceManager.getAbcCreditPosSN());
		final String newPosSn = StringUtils.leftPad(sequenceManager.getAbcCreditPosSN(), 6, "0");
		MsgPackUtils4Abc.createField11(msgPack4Abc, newPosSn);

		// 卡有效期
		MsgPackUtils4Abc.createField14(msgPack4Abc, expireDate);
		// 服务点输入方式码
		MsgPackUtils4Abc.createField22Abc(msgPack4Abc, "012");
		// 卡顺序号
		// MsgPackUtils4Abc.createField23(msgPack4Abc, lastThree);
		// 服务点条件码
		MsgPackUtils4Abc.createField25Abc(msgPack4Abc, "14");
		// 系统参考号 在请求交易中，填写原交易系统参考号
		Log4jUtil.info("系统参考号===" + organizedSysreflectedSn);
		MsgPackUtils4Abc.createField37(msgPack4Abc, organizedSysreflectedSn);

		// 受卡机终端标识码-终端代码
		final ChannelParm mechineCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100003"));
		MsgPackUtils4Abc.createField41(msgPack4Abc, mechineCode.getParvalue());
		// 受卡方标识码-商户代码
		final ChannelParm mechantCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100004"));
		MsgPackUtils4Abc.createField42(msgPack4Abc, mechantCode.getParvalue());
		// // 附加数据
		// MsgPackUtils4Abc.createField48(msgPack4Abc, lastThree);
		// 交易货币代码 默认
		MsgPackUtils4Abc.createField49(msgPack4Abc, "156");

		// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		final ChannelParm operatorCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100011"));
		MsgPackUtils4Abc.createField60AbcConsume(msgPack4Abc, operatorCode.getParvalue());
		// 凭证号批次号
		// ChannelParm pzSn = (ChannelParm) channelParmService
		// .findById(new ChannelParmId("5001030000", "200001"));
		// MsgPackUtils4Abc.createField62(msgPack4Abc, pzSn.getParvalue());
		MsgPackUtils4Abc.createField62(msgPack4Abc, organnizedPzBatchId);

		// MAC
		MsgPackUtils4Abc.createField64(msgPack4Abc, new byte[0]);
		final ChannelParm workKey = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200003"));
		checkSignReturnDate(workKey);
		final byte[] workKey_last8 = hexToBytes(workKey.getParvalue().substring(50, 66));

		// 显示
		displayByteArray(workKey_last8, "workKey_last8");

		// 返回macKey
		final byte[] macKey = getMacKEY(workKey_last8);

		// 显示
		displayByteArray(macKey, "macKey");

		if (macKey == null) {
			Log4jUtil.info("The mac key is null,please check the reason -:),Send message process is broken!!!");
			return null;
		}
		try {
			MsgPackUtils4Abc.create64mac(msgPack4Abc, macKey);
			Log4jUtil.info("Mac process success");
		} catch (final Exception e) {
			Log4jUtil.info("Mac process failed, please check the reason -:),Send message process is broken!!!"
					+ e.getMessage());
			return null;
		}

		return msgPack4Abc;
	}

	/**
	 * <p>代扣冲正交易</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-25 下午4:03:53
	 */
	public MsgPack4Abc createDueHedgingMsgPack4Abc(final Param param, final String organizedPOSSN,
			final String organizedDealCode) throws BizException {
		// 用公共方法，将基础平台的实体转换成渠道默认实体
		final DeductPayReal debit_Pay_Real = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debit_Pay_Real);

		final String mainAccount = debit_Pay_Real.getOut_Account();

		// 创建消费交易消息
		final MsgPack4Abc msgPack4Abc = new MsgPack4Abc();
		// 创建TPDU
		MsgPackUtils4Abc.createTpduField(msgPack4Abc, ByteUtils.strToBcd("6000000000"));
		// 创建交易类型
		MsgPackUtils4Abc.createMsgType(msgPack4Abc, "0420");
		// 主账号
		MsgPackUtils4Abc.createField2(msgPack4Abc, mainAccount);
		// 交易处理码//原交易处理吗
		MsgPackUtils4Abc.createField3(msgPack4Abc, organizedDealCode);
		// 交易金额
		// MsgPackUtils4Abc.createField4(msgPack4Abc, tranAmount);
		// 受卡方系统跟踪号-POS流水号
		Log4jUtil.info("sequenceManager.getAbcCreditPosSN()===" + sequenceManager.getAbcCreditPosSN());
		final String newPosSn = StringUtils.leftPad(sequenceManager.getAbcCreditPosSN(), 6, "0");
		MsgPackUtils4Abc.createField11(msgPack4Abc, newPosSn);

		// // 卡有效期
		// MsgPackUtils4Abc.createField14(msgPack4Abc, expireDate);
		// 服务点输入方式码
		// MsgPackUtils4Abc.createField22Abc(msgPack4Abc, "012");
		// 卡顺序号
		// MsgPackUtils4Abc.createField23(msgPack4Abc, lastThree);
		// 交换指示符和服务代码
		MsgPackUtils4Abc.createField24(msgPack4Abc, "120");
		// 服务点条件码
		MsgPackUtils4Abc.createField25Abc(msgPack4Abc, "14");
		// 系统参考号 在请求交易中，填写原交易系统参考号
		// Log4jUtil.info("系统参考号填写原交易POS流水号==="
		// + organizedSysreflectedSn);
		// MsgPackUtils4Abc.createField37(msgPack4Abc, organizedSysreflectedSn);

		// 受卡机终端标识码-终端代码
		final ChannelParm mechineCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100003"));
		MsgPackUtils4Abc.createField41(msgPack4Abc, mechineCode.getParvalue());
		// 受卡方标识码-商户代码
		final ChannelParm mechantCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100004"));
		MsgPackUtils4Abc.createField42(msgPack4Abc, mechantCode.getParvalue());

		// 凭证号批次号
		final ChannelParm pzSn = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200001"));
		final String batchid = pzSn.getParvalue().substring(12);
		Log4jUtil.info("batchid===" + batchid);
		final byte[] batchid_array = hexToBytes(batchid);
		final byte[] organizedPOSSN_array = organizedPOSSN.getBytes();
		// new String( ArrayUtils.subarray(batchid,6,batchid.length))
		final byte[] batchid_organizedPOSSN = new byte[batchid_array.length + organizedPOSSN_array.length];
		System.arraycopy(batchid_array, 0, batchid_organizedPOSSN, 0, batchid_array.length);
		System.arraycopy(organizedPOSSN_array, 0, batchid_organizedPOSSN, batchid_array.length,
				organizedPOSSN_array.length);

		displayByteArray(batchid_organizedPOSSN, "结果");
		// 附加数据//原交易POS流水
		MsgPackUtils4Abc.createField48Power(msgPack4Abc, batchid_organizedPOSSN);
		// 交易货币代码 默认
		MsgPackUtils4Abc.createField49(msgPack4Abc, "156");

		// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		final ChannelParm operatorCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100011"));
		MsgPackUtils4Abc.createField60AbcSignIn(msgPack4Abc, operatorCode.getParvalue());
		// // 凭证号批次号
		// ChannelParm pzSn = (ChannelParm) channelParmService
		// .findById(new ChannelParmId("5001030000", "200001"));
		// MsgPackUtils4Abc.createField62(msgPack4Abc, pzSn.getParvalue());
		// MAC
		MsgPackUtils4Abc.createField64(msgPack4Abc, new byte[0]);
		final ChannelParm workKey = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200003"));
		checkSignReturnDate(workKey);
		final byte[] workKey_last8 = hexToBytes(workKey.getParvalue().substring(50, 66));

		// 显示
		displayByteArray(workKey_last8, "workKey_last8");

		// 返回macKey
		final byte[] macKey = getMacKEY(workKey_last8);

		// 显示
		displayByteArray(macKey, "macKey");

		if (macKey == null) {
			Log4jUtil.info("The mac key is null,please check the reason -:),Send message process is broken!!!");
			return null;
		}
		try {
			MsgPackUtils4Abc.create64mac(msgPack4Abc, macKey);
			Log4jUtil.info("Mac process success");
		} catch (final Exception e) {
			Log4jUtil.info("Mac process failed, please check the reason -:),Send message process is broken!!!"
					+ e.getMessage());
			return null;
		}

		return msgPack4Abc;
	}

	/**
	 * 
	 * 创建结算通知/联机签退报文 MsgPack4Abc
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道发送流水
	 * @return
	 * @throws Exception
	 */
	public MsgPack4Abc createSettleNoticeMsgPack4Abc(final String field48) throws BizException {

		// 创建消费交易消息
		final MsgPack4Abc msgPack4Abc = new MsgPack4Abc();
		// 创建TPDU
		MsgPackUtils4Abc.createTpduField(msgPack4Abc, ByteUtils.strToBcd("6000000000"));
		// 创建交易类型
		MsgPackUtils4Abc.createMsgType(msgPack4Abc, "0520");
		// 交易处理码
		MsgPackUtils4Abc.createField3(msgPack4Abc, "980000");
		// 受卡方系统跟踪号-POS流水号
		Log4jUtil.info("sequenceManager.getAbcCreditPosSN()===" + sequenceManager.getAbcCreditPosSN());
		final String newPosSn = StringUtils.leftPad(sequenceManager.getAbcCreditPosSN(), 6, "0");
		MsgPackUtils4Abc.createField11(msgPack4Abc, newPosSn);
		// 服务点条件码
		MsgPackUtils4Abc.createField25Abc(msgPack4Abc, "14");
		// 受卡机终端标识码-终端代码
		final ChannelParm mechineCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100003"));
		MsgPackUtils4Abc.createField41(msgPack4Abc, mechineCode.getParvalue());
		// 受卡方标识码-商户代码
		final ChannelParm mechantCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100004"));
		MsgPackUtils4Abc.createField42(msgPack4Abc, mechantCode.getParvalue());
		// 附加数据
		MsgPackUtils4Abc.createField48Power(msgPack4Abc, field48.getBytes());
		// 交易货币代码 默认
		MsgPackUtils4Abc.createField49(msgPack4Abc, "156");

		// 身份证ID或贷记卡（或准贷记卡）的3位校验位
		final ChannelParm operatorCode = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "100011"));
		MsgPackUtils4Abc.createField60AbcConsume(msgPack4Abc, operatorCode.getParvalue());
		// 凭证号批次号
		final ChannelParm pzSn = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200001"));
		MsgPackUtils4Abc.createField62(msgPack4Abc, pzSn.getParvalue());
		// MAC
		MsgPackUtils4Abc.createField64(msgPack4Abc, new byte[0]);
		final ChannelParm workKey = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200003"));
		checkSignReturnDate(workKey);
		final byte[] workKey_last8 = hexToBytes(workKey.getParvalue().substring(50, 66));

		// 显示
		displayByteArray(workKey_last8, "workKey_last8");

		// 返回macKey
		final byte[] macKey = getMacKEY(workKey_last8);

		// 显示
		displayByteArray(macKey, "macKey");

		if (macKey == null) {
			Log4jUtil.info("The mac key is null,please check the reason -:),Send message process is broken!!!");
			return null;
		}
		try {
			MsgPackUtils4Abc.create64mac(msgPack4Abc, macKey);
			Log4jUtil.info("Mac process success");
		} catch (final Exception e) {
			Log4jUtil.info("Mac process failed, please check the reason -:),Send message process is broken!!!"
					+ e.getMessage());
			return null;
		}

		return msgPack4Abc;
	}
}
