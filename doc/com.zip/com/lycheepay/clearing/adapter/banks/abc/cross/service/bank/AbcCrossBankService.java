package com.lycheepay.clearing.adapter.banks.abc.cross.service.bank;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;
import com.lycheepay.clearing.adapter.banks.abc.cross.socket.SocketConnector;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.adapter.common.util.security.CryptorUtil;
import com.lycheepay.clearing.adapter.common.util.security.JDigest;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 
 * <P>银行端服务</P>
 * @author 王瑞
 */

@Service
public class AbcCrossBankService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	public final static String channelId = ChannelIdEnum.ABC_CROSS_PAY.getCode();

	/**
	 * 
	 * <p>服务的主方法</p>
	 * @param req 通用类型
	 * @param resp 适配类型
	 * @return
	 * @throws IOException
	 * @throws BizException
	 * @author 王瑞
	 */
	public <T extends AbcCrossBeanBase> T transfer(AbcCrossBeanBase req, T resp) throws IOException, BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		SocketConnector socket = new SocketConnector();
		byte[] ret = socket.sendAndRecv(channelParms.get(AbcCrossConstant.PARM_SYS_SOCKET_IP),
				channelParms.get(AbcCrossConstant.PARM_SYS_SOCKET_PORT), bulidBodyByte(req));
		explainBodyByte(ret, resp);
		if(checkVaild(resp)){
			return resp;
		}else{
			throw new BizException("银行验签失败！");
		}
	}

	private byte[] bulidBodyByte(AbcCrossBeanBase dto) {
		Log4jUtil.info("[DTO->BYTE]");
		try {
			byte[] body = bulidBodyByte(dto, false);
			Log4jUtil.info("OriginByte[{}]", new String(body));
			String md5 = calcMD5String(body);
			dto.getData().put(AbcCrossConstant.STRING_MD5, md5);
			body = bulidBodyByte(dto, true);
			Log4jUtil.info("FinalByte[{}]", new String(body));
			return body;
		} catch (IOException e) {
			//此处正常情况不会出现异常，拦截掉。
			e.printStackTrace();
			return null;
		}
	}

	private byte[] bulidBodyByte(AbcCrossBeanBase dto, boolean isWithMD5) throws IOException {
		Log4jUtil.info("[DTO->BYTE](MD5:{})", isWithMD5);
		ByteArrayOutputStream body = new ByteArrayOutputStream(dto.getDefineLength());
		for (AbcCrossBeanField field : dto.getFields()) {
			if (!isWithMD5) {
				if (AbcCrossConstant.STRING_MD5.equals(field.getFieldName())) {
					continue;
				}
			}
			byte[] value = StringUtil.getNotNullValue(dto.getData().get(field.getFieldName())).getBytes("GBK");
			Log4jUtil.info("FieldName[{}],Value[{}]", field.getFieldName(), dto.getData().get(field.getFieldName()));
			if (field.getFieldLength() == 0) {
				body.write(value);
				Log4jUtil.debug("FieldLen:{},CurrLen:{},Full.", field.getFieldLength(), value.length);
			} else if (value.length > field.getFieldLength()) {
				body.write(value, 0, field.getFieldLength());
				Log4jUtil.debug("FieldLen:{},CurrLen:{},Cut.", field.getFieldLength(), value.length);
			} else {
				Log4jUtil.debug("FieldLen:{},CurrLen:{},Padding.", field.getFieldLength(), value.length);
				if (field.isFieldPad2Right()) {
					body.write(value);
					for (int i = value.length; i < field.getFieldLength(); i++) {
						body.write(field.getFieldPadding());
					}
				} else {
					for (int i = value.length; i < field.getFieldLength(); i++) {
						body.write(field.getFieldPadding());
					}
					body.write(value);
				}
			}
		}
		return body.toByteArray();
	}

	private String calcMD5String(byte[] body) {
		Log4jUtil.info("[BYTE->MD5]");
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		try {
			Log4jUtil.debug("CalcByte:{}", new String(body,"GBK"));
			ByteArrayOutputStream s = new ByteArrayOutputStream();
			s.write(body);
			s.write(channelParms.get(AbcCrossConstant.PARM_USR_MD5_KEY).getBytes());
			byte[] md5Byte = JDigest.digestMD5(s.toByteArray());
			String md5Str = CryptorUtil.bytesToHexString(md5Byte);
			md5Str = md5Str.toUpperCase();
			Log4jUtil.debug("FinalMD5:{}", md5Str);
			return md5Str;
		} catch (Exception e) {
			Log4jUtil.error(e);
			return null;
		}
	}

	public AbcCrossBeanBase explainBodyByte(byte[] body, AbcCrossBeanBase dto) throws IOException {
		Log4jUtil.info("[BYTE->DTO]");
		ByteArrayInputStream s = new ByteArrayInputStream(body);
		for (AbcCrossBeanField field : dto.getFields()) {
			byte[] value = new byte[field.getFieldLength()];
			int read = s.read(value);
			dto.getData().put(field.getFieldName(), new String(value, "GBK"));
			Log4jUtil.debug("Read:{},[{}]=[{}]", read, field.getFieldName(), new String(value, "GBK"));
		}
		Log4jUtil.info(dto.toString());
		return dto;
	}

	public boolean checkVaild(AbcCrossBeanBase dto) {
		try {
			Log4jUtil.info("[MD5-Check]");
			Log4jUtil.info("RemoteMD5:{}", dto.getData().get(AbcCrossConstant.STRING_MD5));
			byte[] body = bulidBodyByte(dto, false);
			String md5 = calcMD5String(body);
			Log4jUtil.info("LocalMD5:{}", md5);
			if (md5.equals(dto.getData().get(AbcCrossConstant.STRING_MD5))) {
				Log4jUtil.info("[MD5-Pass]");
				return true;
			}
		} catch (IOException e) {
			Log4jUtil.error(e);
		}
		Log4jUtil.info("[MD5-Fail]");
		return false;
	}

}
