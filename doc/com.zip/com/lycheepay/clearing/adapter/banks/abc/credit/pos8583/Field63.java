package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 63域.
 * 
 * @author aps-txy
 */
public class Field63 {
	private final byte[] value;
	private String str63_1;// 国际信用卡公司代码 an3
	private String str63_2;// 自定义域2 ans…120

	public Field63(final byte[] bcdValue) throws BizException {
		AssertUtils.notNull(bcdValue, "未指定域值");

		this.value = ByteUtils.bcdToStr(bcdValue).getBytes();
	}

	/**
	 * 国际信用卡公司代码, 解码值第1位开始取3位.
	 * 
	 * @return
	 */
	public String get63_1() {
		if (str63_1 != null) {
			return str63_1;
		}

		final int startPos = 0;
		final int endPos = startPos + 3;
		str63_1 = new String(ArrayUtils.subarray(value, startPos, endPos));

		return str63_1;
	}

	/**
	 * TODO 取批次号, 解码值第7位开始取6位.
	 * 
	 * @return
	 */
	public String get63_2() {
		if (str63_2 != null) {
			return str63_2;
		}

		final int startPos = 3;
		final int endPos = startPos + 6;
		str63_2 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str63_2;
	}
}
