/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-2-9 上午11:05:51
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.http.b2b.AbcB2BHttpProcessor;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.common.dto.trade.NetResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行 B2B 清算服务入口类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-16 下午5:47:58
 */
@Service(ClearingAdapterAnnotationName.ABC_B2B_CHANNEL_SERVICE)
public class AbcB2BChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_B2B_HTTP_PROCESSOR)
	private AbcB2BHttpProcessor abcB2BHttpProcessor;

	/**
	 * PS.B2B网银代扣服务
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#onlineDeduct(com.lycheepay.clearing.common.dto.trade.NetDeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public NetResultDTO onlineDeduct(final NetDeductDTO deduct) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC", "online");
		final HttpParam httpParam = new HttpParam();
		httpParam.setChannelId(ChannelIdEnum.ABC_B2B.getCode());
		httpParam.setClearingTransType(ClearingTransType.NET_DEDUCT_B2B);
		httpParam.setCustomerType(deduct.getAccountType());
		httpParam.setBizBean(deduct);
		HttpReturnParam httpReturnParam;
		try {
			httpReturnParam = abcB2BHttpProcessor.onlineDeduct(httpParam);
		} catch (final Exception e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}
		final NetResultDTO httpProcessChannelResult = new NetResultDTO();
		httpProcessChannelResult.setActionUrl(httpReturnParam.getAction());
		httpProcessChannelResult.setParams(httpReturnParam.getParams());

		return httpProcessChannelResult;
	}

	// /**
	// * @see
	// com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#batchRefund(com.lycheepay.clearing.common.dto.BatchRefundChannelDTO)
	// * @author 邱林 Leon.Qiu
	// */
	// @Override
	// public BatchRefundResultDTO batchRefund(final BatchRefundChannelDTO batchRefundDTO)
	// throws ClearingAdapterBizCheckedException {
	// Log4jUtil.setLogClass("ABC", "direct");
	// final Param param = new Param();
	// param.setRepeatFlag(batchRefundDTO.getRepeatFlag());
	// param.setChannelId(batchRefundDTO.getChannelId());
	// param.setChannelTransType(ChannelTransType.PayRefund);
	// param.setTransType(batchRefundDTO.getTransType());
	//
	// if ("Y".equals(param.getRepeatFlag())) {// 若为重发，则传进来是个包号
	// param.setBizBean(batchRefundDTO.getChannelBatchid());
	// } else {
	// final BatchRefund batchRefund = new BatchRefund();
	// final BatchRefundId id = new BatchRefundId();
	// id.setChannelId(batchRefundDTO.getChannelId());
	// id.setRefundNetNo(batchRefundDTO.getRefundNetNo());
	// id.setRefundType(batchRefundDTO.getRefundType());
	// batchRefund.setId(id);
	// param.setBizBean(batchRefund);
	// }
	//
	// final AbcB2BDirectProcess abcB2BDirectProcess = new AbcB2BDirectProcess();
	// final ReturnState returnState = abcB2BDirectProcess.deal(param);
	// final BatchRefundResultDTO batchRefundResultDTO = new BatchRefundResultDTO();
	// batchRefundResultDTO.setReturnState(returnState.getReturnState());
	// batchRefundResultDTO.setFileNames((List<?>) returnState.getReturnObj());
	// return batchRefundResultDTO;
	// }
	// XXX Batch By:Leon.Qiu[2012-6-18 上午10:26:26]

}
