package com.lycheepay.clearing.adapter.banks.abc.cross.dto.base;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public abstract class AbcCrossBeanBase {

	// 顺序要求
	private final ArrayList<AbcCrossBeanField> fields = new ArrayList<AbcCrossBeanField>();
	protected final LinkedHashMap<String, String> data = new LinkedHashMap<String, String>();

	// 子类构造使用
	protected void addField(AbcCrossBeanField field) {
		this.fields.add(field);
		this.data.put(field.getFieldName(), null);
	}

	// 子类构造使用
	protected void addField(AbcCrossBeanField field, String defaultValue) {
		this.fields.add(field);
		this.data.put(field.getFieldName(), defaultValue);
	}
	
	public ArrayList<AbcCrossBeanField> getFields() {
		return fields;
	}

	public LinkedHashMap<String, String> getData() {
		return data;
	}

	public int getDefineLength() {
		int length = 0;
		for (AbcCrossBeanField item : fields) {
			length += item.getFieldLength();
		}
		return length;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (AbcCrossBeanField item : fields) {
			sb.append("\n");
			sb.append("[" + item.getFieldName() + "]");
			sb.append("=");
			sb.append("[" + data.get(item.getFieldName()) + "]");
		}
		return sb.toString();
	}
	
	
}
