package com.lycheepay.clearing.adapter.banks.abc.cross.file;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;

import com.alibaba.fastjson.JSONObject;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH14FileDTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH19File1DTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.WH19File2DTO;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.util.Log4jUtil;

public final class AbcCrossFileConvertor {
	
	private final String filepathin;
	private final String filepathout;
	private final String sn;
	private final String seq;
	private final String SEPARATOR = "|!";  
	private final String LINEENTER = "\r\n"; 
	
	private Map<String,String> defaultValue = null;
	
	public AbcCrossFileConvertor(String sn, String seq, String filepathin, String filepathout) {
		this.sn = sn;
		this.seq = seq;
		this.filepathin = filepathin;
		this.filepathout = filepathout;
	}
	
	public AbcCrossFileConvertor(String sn, String seq, String filepathin, String filepathout, Map<String,String> defaultValue) {
		this.sn = sn;
		this.seq = seq;
		this.filepathin = filepathin;
		this.filepathout = filepathout;
		this.defaultValue = defaultValue;
	}
	
	public String convertWH19File1() throws Exception{
		ArrayList<AbcCrossBeanBase> list = convert2BeanList(new WH19File1DTO());
		int count = 0;
		for(AbcCrossBeanBase dto : list){
			dto.getData().put("businessRefNo", buildItemSN(++count));//写入申报参考号
			setDefaultValue(dto);
		}
		String fileName = createWH19File1Name(list.size());
		String filePath = filepathout + fileName;
		writeFile(list, filePath);
		return fileName;
	}
	
	public String convertWH19File2() throws Exception{
		ArrayList<AbcCrossBeanBase> list = convert2BeanList(new WH19File2DTO());
		int count = 0;
		for(AbcCrossBeanBase dto : list){
			dto.getData().put("businessRefNo", buildItemSN(++count));//写入申报参考号
			setDefaultValue(dto);
		}
		String fileName = createWH19File2Name(list.size());
		String filePath = filepathout + fileName;
		writeFile(list, filePath);
		return fileName;
	}
	
	public String convertWH14File() throws Exception{
		ArrayList<AbcCrossBeanBase> list = convert2BeanList(new WH14FileDTO());
		String fileName = createWH14FileName(list.size());
		String filePath = filepathout + fileName;
		writeFile(list, filePath);
		return fileName;
	}	
	
	private void writeFile(ArrayList<AbcCrossBeanBase> list, String filePath) throws IOException{
		FileOutputStream os = new FileOutputStream(filePath);
		for(AbcCrossBeanBase item : list){
			ByteArrayOutputStream body = new ByteArrayOutputStream();
			for (AbcCrossBeanField field : item.getFields()) {
				byte[] value = StringUtil.getNotNullValue(item.getData().get(field.getFieldName())).getBytes("GBK");
				if (field.getFieldLength() == 0) {
					body.write(value);
				} else if (value.length > field.getFieldLength()){
					body.write(value, 0, field.getFieldLength());
				} else{
					if (field.isFieldPad2Right()) {
						body.write(value);
						for (int i = value.length; i < field.getFieldLength(); i++) {
							body.write(field.getFieldPadding());
						}
					} else {
						for (int i = value.length; i < field.getFieldLength(); i++) {
							body.write(field.getFieldPadding());
						}
						body.write(value);
					}
				}
				body.write(SEPARATOR.getBytes());//分隔符
			}
			body.write(LINEENTER.getBytes());//换行
			body.writeTo(os);//逐行输出
		}
		os.close();
	}
	
	private ArrayList<AbcCrossBeanBase> convert2BeanList(AbcCrossBeanBase type) throws Exception{
		ArrayList<AbcCrossBeanBase> result = new ArrayList<AbcCrossBeanBase>();
		for(String item : readFile()){
			Log4jUtil.info("[FileConv]{}", item);
			
			JSONObject json = (JSONObject)JSONObject.parse(item);
			
			AbcCrossBeanBase dto = type.getClass().newInstance();
			
			for(Entry<String,String> kv : dto.getData().entrySet()){
				Log4jUtil.debug("[FileConv][{}]<-[{}]",kv.getKey(),json.get(kv.getKey()));
				kv.setValue(StringUtil.getNotNullValue((String)json.get(kv.getKey())));
			}
			
			result.add(dto);
		}
		return result;
	}
	
	private ArrayList<String> readFile() throws IOException{
		ArrayList<String> result = new ArrayList<String>();
		FileInputStream is = new FileInputStream(filepathin);
		BufferedReader reader = new BufferedReader(new InputStreamReader(is,"UTF-8"));
		for (String line = reader.readLine(); line != null; line = reader.readLine()){
			if(line.length() > 0){//过滤空行
				result.add(line);
			}
		}
		reader.close();
		return result;
	}
	
	private String buildItemSN(int seq){
		String init = "0000";
		StringBuilder sb = new StringBuilder(init);
		sb.append(seq);
		sb = new StringBuilder(sb.substring(sb.length() - init.length()));
		sb.insert(0, sn);
		return sb.toString();
	}
	
	/**
	 * WH19_汇出汇入类型_BASE_8位日期_条数_序号.txt
	 */
	private String createWH19File1Name(int count){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		StringBuilder sb = new StringBuilder("WH19");//prefix
		sb.append('_');
		sb.append('1');
		sb.append('_');
		sb.append("BASE");
		sb.append('_');
		sb.append(sdf.format(new Date()));
		sb.append('_');
		sb.append(count);
		sb.append('_');
		sb.append(seq);
		sb.append(".txt");
		return sb.toString();
	}
	
	/**
	 * WH19_汇出汇入类型_EXT_8位日期_条数_序号.txt
	 */
	private String createWH19File2Name(int count){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		StringBuilder sb = new StringBuilder("WH19");//prefix
		sb.append('_');
		sb.append('1');
		sb.append('_');
		sb.append("EXT");
		sb.append('_');
		sb.append(sdf.format(new Date()));
		sb.append('_');
		sb.append(count);
		sb.append('_');
		sb.append(seq);
		sb.append(".txt");
		return sb.toString();
	}
	
	/**
	 * WH14_8位日期_条数_序号.txt
	 */
	private String createWH14FileName(int count){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		StringBuilder sb = new StringBuilder("WH14");//prefix
		sb.append('_');
		sb.append(sdf.format(new Date()));
		sb.append('_');
		sb.append(count);
		sb.append('_');
		sb.append(seq);
		sb.append(".txt");
		return sb.toString();
	}
	
	/**
	 * 写入预设值
	 */
	private void setDefaultValue(AbcCrossBeanBase dto){
		if(defaultValue != null){
			for(Entry<String,String> kv : defaultValue.entrySet()){
				dto.getData().put(kv.getKey(), kv.getValue());
			}
		}
	}

}
