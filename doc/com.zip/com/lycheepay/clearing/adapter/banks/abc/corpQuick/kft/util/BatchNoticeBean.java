package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util;

/**
 * 文件接收通知Bean <p>Description:</p> <p>Copyright: Copyright (c) 2011</p>
 * 
 * @author aps-txy
 * @version 1.0
 */

public class BatchNoticeBean {
	private String transCode;// 交易代码
	private String merchantCode;// 商户代码
	private String projectCode;// 项目号
	private String payFlag;// 支付标志
	private String transReqDate;// 交易请求日期
	private String transReqTime;// 交易请求时间
	private String fileNumber;// 文件序号
	private double fileSize;// 文件大小
	private String totalNum;// 总笔数
	private String totalAmt;// 总金额
	private String fileName;// 总金额

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(final String transCode) {
		this.transCode = transCode;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(final String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(final String projectCode) {
		this.projectCode = projectCode;
	}

	public String getPayFlag() {
		return payFlag;
	}

	public void setPayFlag(final String payFlag) {
		this.payFlag = payFlag;
	}

	public String getTransReqDate() {
		return transReqDate;
	}

	public void setTransReqDate(final String transReqDate) {
		this.transReqDate = transReqDate;
	}

	public String getTransReqTime() {
		return transReqTime;
	}

	public void setTransReqTime(final String transReqTime) {
		this.transReqTime = transReqTime;
	}

	public String getFileNumber() {
		return fileNumber;
	}

	public void setFileNumber(final String fileNumber) {
		this.fileNumber = fileNumber;
	}

	public double getFileSize() {
		return fileSize;
	}

	public void setFileSize(final double fileSize) {
		this.fileSize = fileSize;
	}

	public String getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(final String totalNum) {
		this.totalNum = totalNum;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(final String totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(final String fileName) {
		this.fileName = fileName;
	}

}
