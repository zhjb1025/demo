package com.lycheepay.clearing.adapter.banks.abc.handler;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.credit.kft.processor.AbcCreditDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P> 农业银行信用卡银企直连渠道服务</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午3:05:40
 */
@Service(ClearingAdapterAnnotationName.ABC_CREDIT_CHANNEL_SERVICE)
public class AbcCreditChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CREDIT_DIRECT_PROCESS)
	private AbcCreditDirectProcess abcCreditDirectProcess;

	private static final String channelId = ChannelIdEnum.ABC_CREDIT_CARD.getCode();

	/**
	 * PS.实时代扣
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC", "credit");
		Log4jUtil.info(deductDTO);
		final Param param = new Param();
		param.setChannelId(ChannelIdEnum.ABC_CREDIT_CARD.getCode());
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);
		ReturnState returnState;
		try {
			returnState = abcCreditDirectProcess.directDeduct(param);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}

		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	/**
	 * PS.自适应退款
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#autoRealtimeRefund(com.lycheepay.clearing.common.dto.trade.RefundDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO autoRealtimeRefund(final RefundDTO refund) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("ABC", "credit");
		Log4jUtil.info(refund);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		param.setSn(refund.getTxnId());
		param.setBorc(refund.getBankCardType());
		param.setBizBean(refund);
		ReturnState returnState;
		try {
			returnState = abcCreditDirectProcess.autoRealtimeRefund(param);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}

		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(returnState.getClearingTransType());
		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	/**
	 * PS.农行行用卡联机签到
	 * 
	 * @author 邱林 Leon.Qiu
	 */
	public ClearingResultDTO sign() {
		Log4jUtil.setLogClass("ABC", "creditSign");
		try {
			// 只做退签，这里默认写成156001000000000122000000000000000
			abcCreditDirectProcess.settleNotice("156001000000000122000000000000000");
			abcCreditDirectProcess.signIn();
			Log4jUtil.info(new Date() + "农行信用卡渠道自动联机签到处理成功");
		} catch (final Exception e) {
			Log4jUtil.error(new Date() + "农行信用卡渠道自动联机签到处理失败", e);
		}
		return null;
	}

	// TODO 批量退款
	// @Override
	// public BatchRefundResultDTO batchRefund(final BatchRefundChannelDTO batchRefundDTO)
	// throws ClearingAdapterBizCheckedException {
	// Log4jUtil.setLogClass("ABC", "credit");
	// final Param param = new Param();
	// param.setRepeatFlag(batchRefundDTO.getRepeatFlag());
	// param.setChannelId(batchRefundDTO.getChannelId());
	// param.setClearingTransType(ClearingTransType.BATCH_PAY);
	//
	// if ("Y".equals(param.getRepeatFlag())) {// 若为重发，则传进来是个包号
	// param.setBizBean(batchRefundDTO.getChannelBatchid());
	// } else {
	// final BatchRefund batchRefund = new BatchRefund();
	// final BatchRefundId id = new BatchRefundId();
	// id.setChannelId(batchRefundDTO.getChannelId());
	// id.setRefundNetNo(batchRefundDTO.getRefundNetNo());
	// id.setRefundType(batchRefundDTO.getRefundType());
	// batchRefund.setId(id);
	// param.setBizBean(batchRefund);
	// }
	//
	// final AbcCreditDirectProcess abcCreditDirectProcess = new AbcCreditDirectProcess();
	// final ReturnState returnState = abcCreditDirectProcess.deal(param);
	// final BatchRefundResultDTO batchRefundResultDTO = new BatchRefundResultDTO();
	// batchRefundResultDTO.setReturnState(returnState.getReturnState());
	// batchRefundResultDTO.setFileNames((List<?>) returnState.getReturnObj());
	// return batchRefundResultDTO;
	// }

}
