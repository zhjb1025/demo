package com.lycheepay.clearing.adapter.banks.abc.corp.bank.util;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_CQLA36Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcSend2CT_Vc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class ERP2CT_CQLA36 {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_SEND2CT_VC)
	private AbcSend2CT_Vc abcSend2CT_Vc;
	
	/**
	 * 创建农行CQLA36报文，并发送到CT
	 * 
	 * @author huangxu
	 * @param eRP2CT_PublicBean
	 * @param eRP2CT_CQLA35Bean
	 * @date 2015-08-23
	 * @return CQLA36应答报文
	 * @throws BizException
	 */
	public String sendXMLFile(final ERP2CT_PublicBean eRP2CT_PublicBean, final ERP2CT_CQLA36Bean eRP2CT_CQLA36Bean)
			throws BizException {
		// 使用DocumentHelper.createDocument方法建立一个文档实例
		final Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 使用addElement方法方法创建根元素
		final Element apElement = document.addElement("ap");

		// 使用addElement方法向ap元素添加TransCode子元素
		final Element TransCode = apElement.addElement("TransCode");
		TransCode.setText(eRP2CT_PublicBean.getTransCode());

		// 使用addElement方法向ap元素添加ChannelType子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element ChannelType = apElement.addElement("ChannelType");
		ChannelType.setText("ERP");

		// 使用addElement方法向ap元素添加CorpNo子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element CorpNo = apElement.addElement("CorpNo");
		CorpNo.setText("");

		// 使用addElement方法向ap元素添加OpNo子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element OpNo = apElement.addElement("OpNo");
		OpNo.setText("");

		// 使用addElement方法向ap元素添加AuthNo子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element AuthNo = apElement.addElement("AuthNo");
		AuthNo.setText("");

		// 使用addElement方法向ap元素添加ReqSeqNo子元素
		final Element ReqSeqNo = apElement.addElement("ReqSeqNo");
		ReqSeqNo.setText(eRP2CT_PublicBean.getReqSeqNo());

		// 使用addElement方法向ap元素添加ReqDate子元素
		final Element ReqDate = apElement.addElement("ReqDate");
		ReqDate.setText("");

		// 使用addElement方法向ap元素添加ReqTime子元素
		final Element ReqTime = apElement.addElement("ReqTime");
		ReqTime.setText("");

		// 使用addElement方法向ap元素添加Sign子元素(CT请求时, 由CT填写, 企业送空即可)
		final Element Sign = apElement.addElement("Sign");
		Sign.setText("");

		// 使用addElement方法向ap元素添加Version子元素
		final Element VersionElement = apElement.addElement("Version");
		final Element CcVersion = VersionElement.addElement("CcVersion");
		CcVersion.setText(eRP2CT_PublicBean.getCcVersion());

		// 使用addElement方法向ap元素添加Corp子元素
		final Element CorpElement = apElement.addElement("Corp");
		
		final Element PayComNo = CorpElement.addElement("PayComNo");
		PayComNo.setText(eRP2CT_PublicBean.getPayComNo());

		final Element SerialDate = CorpElement.addElement("SerialDate");
		SerialDate.setText(eRP2CT_CQLA36Bean.getSerialDate());
		
		// 使用addElement方法向ap元素添加FileTag子元素
		final Element FileTagElement = apElement.addElement("FileTag");

		final Element FileSplit = FileTagElement.addElement("FileSplit");
		FileSplit.setText(eRP2CT_CQLA36Bean.getFileSplit());
		
		// 使用addElement方法向ap元素添加FileTag子元素
		final Element CmeElement = apElement.addElement("Cme");

		final Element SerialNo = CmeElement.addElement("SerialNo");
		SerialNo.setText(eRP2CT_CQLA36Bean.getSerialNo());
		
		final String xmlInfo = document.asXML();
		final int begin = xmlInfo.indexOf("<ap>");
		final String CQLA35Info = xmlInfo.substring(begin, xmlInfo.length());

		Log4jUtil.info("CQLA35Info : " + CQLA35Info);
		String resultXml = abcSend2CT_Vc.launchBFJ(CQLA35Info);
		
		return resultXml;
	}
}
