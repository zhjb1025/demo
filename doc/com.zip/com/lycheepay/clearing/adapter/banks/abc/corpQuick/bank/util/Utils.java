package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;

public class Utils {
	/**
	 * 加密处理Md5(msg)
	 * */
	public static String getSecMsg(String msg) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		String secmsg = "";
		byte[] hash = EasySecure.md5digest((msg).getBytes("GBK"));
		StringBuffer outStrBuf = new StringBuffer(32);
		for (int i = 0; i < hash.length; i++) {
			int v = hash[i] & 0xFF;
			if (v < 16) {
				outStrBuf.append('0');
			}
			outStrBuf.append(Integer.toString(v, 16).toLowerCase());
		}
		secmsg = outStrBuf.toString();
		return secmsg;
	}

	/**
	 * 截取字符串
	 * 
	 * @param value
	 * @param charNumber
	 * @return
	 */
	public static String cutString(String value, int charNumber) {
		if (value == null) {
			return "";
		}
		if (charNumber < value.getBytes(Charset.forName("GBK")).length) {
			return new String(value.getBytes(Charset.forName("GBK")), 0, charNumber);
		} else {
			return value;
		}
	}
}
