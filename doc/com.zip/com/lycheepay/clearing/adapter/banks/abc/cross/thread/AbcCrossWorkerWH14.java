package com.lycheepay.clearing.adapter.banks.abc.cross.thread;

import org.springframework.jms.core.JmsTemplate;

import com.alibaba.fastjson.JSONObject;
import com.lycheepay.clearing.adapter.banks.abc.cross.service.process.AbcCrossProcessService;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.UploadInfoDTO;
import com.lycheepay.clearing.util.Log4jUtil;


public class AbcCrossWorkerWH14 extends AbcCrossWorker implements Runnable {

	private final UploadInfoDTO uploadInfoDTO;

	public AbcCrossWorkerWH14(AbcCrossProcessService abcCrossProcessService, JmsTemplate mqSender, UploadInfoDTO uploadInfoDTO) {
		super(abcCrossProcessService, mqSender);
		this.uploadInfoDTO = uploadInfoDTO;
	}

	@Override
	public void run() {
		Log4jUtil.setLogClass("ABC_CROSS", "UploadService");
		ClearingResultDTO result = null;
		try {
			result = abcCrossProcessService.transWH14(uploadInfoDTO);
			Log4jUtil.info("[WorkerWH14]{}", result.toString());
		} catch (Exception e) {
			Log4jUtil.error(e);
			result = new ClearingResultDTO();
			result.setChannelResponseCode(TransReturnCode.code_9109);
			result.setChannelResponseMsg(e.getMessage());
		}
		JSONObject json = new JSONObject();
		json.put("txnId", uploadInfoDTO.getTxnId());
		json.put("channelResponseCode", result.getChannelResponseCode());
		json.put("channelResponseMsg", result.getChannelResponseMsg());
		Log4jUtil.info("[WorkerWH14]{}", json.toJSONString());
		super.sendMQ(json.toJSONString());
	}

}
