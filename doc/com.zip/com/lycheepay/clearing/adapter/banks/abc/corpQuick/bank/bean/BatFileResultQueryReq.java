package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean;

public class BatFileResultQueryReq {
	String tranCode;// 1 交易代码 4
	String backSeq;// 2 原银行流水号 20

	public BatFileResultQueryReq(final String tranCode, final String backSeq) {
		super();
		this.tranCode = tranCode;
		this.backSeq = backSeq;
	}

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(final String tranCode) {
		this.tranCode = tranCode;
	}

	public String getBackSeq() {
		return backSeq;
	}

	public void setBackSeq(final String backSeq) {
		this.backSeq = backSeq;
	}
}
