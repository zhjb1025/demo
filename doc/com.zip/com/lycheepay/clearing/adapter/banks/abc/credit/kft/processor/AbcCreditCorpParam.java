package com.lycheepay.clearing.adapter.banks.abc.credit.kft.processor;

public class AbcCreditCorpParam {
	private String Ip;// IP地址
	private String port;// 端口号
	private String transadd;// 交易地点
	private String timeOut;// 链接超时时间，毫秒
	private String ftpServer;
	private String ftpUser;
	private String ftpPassword;
	private String ftpPath;

	public String getFtpPath() {
		return ftpPath;
	}

	public void setFtpPath(final String ftpPath) {
		this.ftpPath = ftpPath;
	}

	public String getFtpServer() {
		return ftpServer;
	}

	public void setFtpServer(final String ftpServer) {
		this.ftpServer = ftpServer;
	}

	public String getFtpUser() {
		return ftpUser;
	}

	public void setFtpUser(final String ftpUser) {
		this.ftpUser = ftpUser;
	}

	public String getFtpPassword() {
		return ftpPassword;
	}

	public void setFtpPassword(final String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}

	public String getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(final String timeOut) {
		this.timeOut = timeOut;
	}

	public String getTransadd() {
		return transadd;
	}

	public void setTransadd(final String transadd) {
		this.transadd = transadd;
	}

	public String getIp() {
		return Ip;
	}

	public void setIp(final String ip) {
		Ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(final String port) {
		this.port = port;
	}

}
