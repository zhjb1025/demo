package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util;

import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;


public class BatchBean {
	// updateBatchSend(trantype,totalReqSeqNo,returnState);
	private String trantype;
	private String channelBatchNo;
	private ReturnState returnState;

	public String getTrantype() {
		return trantype;
	}

	public void setTrantype(final String trantype) {
		this.trantype = trantype;
	}

	public String getChannelBatchNo() {
		return channelBatchNo;
	}

	public void setChannelBatchNo(final String channelBatchNo) {
		this.channelBatchNo = channelBatchNo;
	}

	public ReturnState getReturnState() {
		return returnState;
	}

	public void setReturnState(final ReturnState returnState) {
		this.returnState = returnState;
	}

}
