package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_7506Bean {

	// ERP2CT_7506 企业操作员签到请求报文
	private String DbAccNo; // 账号
	private String DbProv; // 省市代码
	private String DbCur; // 货币号

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

}
