package com.lycheepay.clearing.adapter.banks.abc.cross.thread;

import org.springframework.jms.core.JmsTemplate;

import com.lycheepay.clearing.adapter.banks.abc.cross.service.process.AbcCrossProcessService;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.PayForeignExchangeDTO;
import com.lycheepay.clearing.util.Log4jUtil;


public class AbcCrossWorkerWH19 extends AbcCrossWorker implements Runnable {

	private final PayForeignExchangeDTO payForeignExchangeDTO;

	public AbcCrossWorkerWH19(AbcCrossProcessService abcCrossProcessService, JmsTemplate mqSender, PayForeignExchangeDTO payForeignExchangeDTO) {
		super(abcCrossProcessService, mqSender);
		this.payForeignExchangeDTO = payForeignExchangeDTO;
	}

	@Override
	public void run() {
		Log4jUtil.setLogClass("ABC_CROSS", "ChannelService");
		try {
			ClearingResultDTO result = abcCrossProcessService.transWH19(payForeignExchangeDTO);
			Log4jUtil.info("[WorkerWH19]{}", result.toString());
		} catch (Exception e) {
			Log4jUtil.error(e);
		}
	}

}
