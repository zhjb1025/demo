package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

/**
 * 银企直连参数统一封装Bean <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @version 1.0
 */
public class AbcCorpParm {
	String TransCode = "TransCode";		// 农行银企接口交易代码
	String ChannelType = "0";		// 农行银企接口渠道标志
	String CorpNo = "6681501010629086";		// 农行银企接口企业技监局号码
	String OpNo = "1001";		// 农行银企接口企业操作员编号
	String AuthNo = "455FFA47B15CCC9563BFDEC83867E8B5";	// 农行银企接口认证码
	String className = "paycore.channel.impl.AbcChnlInner";	// 农行银企接口内部实现类名
	String KftAccNo = "KftAccNo";		// 农行银企接口KFT平台账号
	String KftProv = "41";		// 农行银企接口KFT平台省市代码
	String KftCur = "01";		// 农行银企接口KFT平台货币号
	String SocketIP = "172.100.0.121";		// 农行银企接口SocketIP
	String SocketPort = "3837";		// 农行银企接口Socket端口
	String Sign = "";		// 农行银企接口数字签名
	String encryptTag = "0";		// 农行银企接口加密标志
	String ConFlag = "0";		// "农行银企接口合约校验标志0-不校验 1-校验"
	String DbAccNo = "DbAccNo";		// 农行银企接口借方账号
	String DbProv = "41";		// 农行银企接口借方省市代码
	String DbCur = "01";		// 农行银企接口借方货币号
	String CrAccNo = "CrAccNo";		// 农行银企接口贷方账号
	String CrProv = "41";		// 农行银企接口贷方省市代码
	String CrCur = "01";		// 农行银企接口贷方货币号
	String StartTime = "20110808163814568462";		// 农行银企接口末笔时间戳
	String CshDraFlag = "0";		// 农行银企接口钞汇标志 0-钞；1-汇
	String SpAccInd = "0";		// 农行银企接口借方户名校验标志0-不校验1-校验
	String ExchangeType = "000000";		// 农行银企接口合约类型
	String Postscript = "0";		// 农行银企接口附言
	String KftAccName = "快付通平台户名";		// 农行银企接口快付通平台户名
	String AgtDbInd = "0";		// 农行银企接口集中代理支付标志 0-否1-是
	String DbLogAccNo = "";		// 农行银企接口二级帐簿
	String ftpServer = "172.100.0.121";		// 农行银企CT服务器ftpIP
	String ftpPassword = "110620";		// 农行银企CT服务器ftp密码
	String ftpUser = "administrator";		// 农行银企CT服务器ftp用户
	String abcSendFile = "abcSendFile";		// 农行银企发送文件目录
	String abcRecvFile = "abcRecvFile";		// 农行银企接收文件目录
	String ActInf = "0";		// 农行银企到帐通知:0不通知;1通知付款人;2通知收款人;3全部通知
	String UrgencyFlag = "0";		// 农行银企加急标志:0-不加急;1-加急
	String BatchNum = "100000";		// 农行银企一个批量业务的最大交易笔数
	String AccStartTime = "20110803083736548838";		// 农行银企对账末笔时间戳

	public String getTransCode() {
		return TransCode;
	}

	public void setTransCode(final String transCode) {
		TransCode = transCode;
	}

	public String getChannelType() {
		return ChannelType;
	}

	public void setChannelType(final String channelType) {
		ChannelType = channelType;
	}

	public String getCorpNo() {
		return CorpNo;
	}

	public void setCorpNo(final String corpNo) {
		CorpNo = corpNo;
	}

	public String getOpNo() {
		return OpNo;
	}

	public void setOpNo(final String opNo) {
		OpNo = opNo;
	}

	public String getAuthNo() {
		return AuthNo;
	}

	public void setAuthNo(final String authNo) {
		AuthNo = authNo;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(final String className) {
		this.className = className;
	}

	public String getKftAccNo() {
		return KftAccNo;
	}

	public void setKftAccNo(final String kftAccNo) {
		KftAccNo = kftAccNo;
	}

	public String getKftProv() {
		return KftProv;
	}

	public void setKftProv(final String kftProv) {
		KftProv = kftProv;
	}

	public String getKftCur() {
		return KftCur;
	}

	public void setKftCur(final String kftCur) {
		KftCur = kftCur;
	}

	public String getSocketIP() {
		return SocketIP;
	}

	public void setSocketIP(final String socketIP) {
		SocketIP = socketIP;
	}

	public String getSocketPort() {
		return SocketPort;
	}

	public void setSocketPort(final String socketPort) {
		SocketPort = socketPort;
	}

	public String getSign() {
		return Sign;
	}

	public void setSign(final String sign) {
		Sign = sign;
	}

	public String getEncryptTag() {
		return encryptTag;
	}

	public void setEncryptTag(final String encryptTag) {
		this.encryptTag = encryptTag;
	}

	public String getConFlag() {
		return ConFlag;
	}

	public void setConFlag(final String conFlag) {
		ConFlag = conFlag;
	}

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

	public String getCrAccNo() {
		return CrAccNo;
	}

	public void setCrAccNo(final String crAccNo) {
		CrAccNo = crAccNo;
	}

	public String getCrProv() {
		return CrProv;
	}

	public void setCrProv(final String crProv) {
		CrProv = crProv;
	}

	public String getCrCur() {
		return CrCur;
	}

	public void setCrCur(final String crCur) {
		CrCur = crCur;
	}

	public String getStartTime() {
		return StartTime;
	}

	public void setStartTime(final String startTime) {
		StartTime = startTime;
	}

	public String getCshDraFlag() {
		return CshDraFlag;
	}

	public void setCshDraFlag(final String cshDraFlag) {
		CshDraFlag = cshDraFlag;
	}

	public String getSpAccInd() {
		return SpAccInd;
	}

	public void setSpAccInd(final String spAccInd) {
		SpAccInd = spAccInd;
	}

	public String getExchangeType() {
		return ExchangeType;
	}

	public void setExchangeType(final String exchangeType) {
		ExchangeType = exchangeType;
	}

	public String getPostscript() {
		return Postscript;
	}

	public void setPostscript(final String postscript) {
		Postscript = postscript;
	}

	public String getKftAccName() {
		return KftAccName;
	}

	public void setKftAccName(final String kftAccName) {
		KftAccName = kftAccName;
	}

	public String getAgtDbInd() {
		return AgtDbInd;
	}

	public void setAgtDbInd(final String agtDbInd) {
		AgtDbInd = agtDbInd;
	}

	public String getDbLogAccNo() {
		return DbLogAccNo;
	}

	public void setDbLogAccNo(final String dbLogAccNo) {
		DbLogAccNo = dbLogAccNo;
	}

	public String getFtpServer() {
		return ftpServer;
	}

	public void setFtpServer(final String ftpServer) {
		this.ftpServer = ftpServer;
	}

	public String getFtpPassword() {
		return ftpPassword;
	}

	public void setFtpPassword(final String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}

	public String getFtpUser() {
		return ftpUser;
	}

	public void setFtpUser(final String ftpUser) {
		this.ftpUser = ftpUser;
	}

	public String getAbcSendFile() {
		return abcSendFile;
	}

	public void setAbcSendFile(final String abcSendFile) {
		this.abcSendFile = abcSendFile;
	}

	public String getAbcRecvFile() {
		return abcRecvFile;
	}

	public void setAbcRecvFile(final String abcRecvFile) {
		this.abcRecvFile = abcRecvFile;
	}

	public String getActInf() {
		return ActInf;
	}

	public void setActInf(final String actInf) {
		ActInf = actInf;
	}

	public String getUrgencyFlag() {
		return UrgencyFlag;
	}

	public void setUrgencyFlag(final String urgencyFlag) {
		UrgencyFlag = urgencyFlag;
	}

	public String getBatchNum() {
		return BatchNum;
	}

	public void setBatchNum(final String batchNum) {
		BatchNum = batchNum;
	}

	public String getAccStartTime() {
		return AccStartTime;
	}

	public void setAccStartTime(final String accStartTime) {
		AccStartTime = accStartTime;
	}

}
