package com.lycheepay.clearing.adapter.banks.abc.http.b2c;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.hitrust.trustpay.client.TrxResponse;
import com.hitrust.trustpay.client.b2c.IdentityVerifyRequest;
import com.hitrust.trustpay.client.b2c.Order;
import com.hitrust.trustpay.client.b2c.OrderItem;
import com.hitrust.trustpay.client.b2c.PaymentRequest;
import com.lycheepay.clearing.adapter.banks.abc.http.AbcUtil;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.common.constant.CertificateType;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.NetDeductDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


/**
 * <P>农业银行网银B2C HTTP(页面)请求处理器</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 下午2:24:41
 */
@Service(ClearingAdapterAnnotationName.ABC_B2C_HTTP_PROCESSOR)
public class AbcB2CHttpProcessor extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	/**
	 * <p>农业银行B2C网银代扣</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午2:26:01
	 */
	public HttpReturnParam onlineDeduct(final HttpParam httpParam) throws BizException {
		final String logPrefix = httpParam.getChannelId() + ChannelId.getNameByValue(httpParam.getChannelId());
		final String logMsg = "进入" + logPrefix + "渠道Http业务处理。";
		Log4jUtil.info(logMsg);
		// 获取渠道对应参数
		final Map<String, String> channelParam = channelParmService.queryCodeParamsMapByChannelId(httpParam.getChannelId());
		if (channelParam == null) {
			throw new BizException("无法获取" + logPrefix + "渠道参数配置。");
		}
		return b2CPay(logPrefix, httpParam, channelParam);// 支付或担保支付或者充值
	}

	/**
	 * <p>农业银行B2C网银账户验证(PS.迁移前此接口未暴露调用,完全可以再路由上配置,但方法实现好)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午3:50:39
	 */
	public HttpReturnParam onlineAccountVerify(final HttpParam httpParam) throws BizException {
		final String logPrefix = httpParam.getChannelId() + ChannelId.getNameByValue(httpParam.getChannelId());
		final String logMsg = "进入" + logPrefix + "渠道Http业务处理。";
		Log4jUtil.info(logMsg);
		// 获取渠道对应参数
		final Map<String, String> channelParam = channelParmService.queryCodeParamsMapByChannelId(httpParam.getChannelId());
		if (channelParam == null) {
			throw new BizException("无法获取" + logPrefix + "渠道参数配置。");
		}
		return this.accountVerify(logPrefix, httpParam, channelParam);
	}

	/**
	 * B2C 支付\充值
	 * 
	 * @param httpParam
	 * @return
	 */
	private HttpReturnParam b2CPay(final String logPrefix, final HttpParam httpParam, Map<String, String> channelParam)
			throws BizException {
		String logMsg = "进入 " + logPrefix + " 支付业务处理。";
		Log4jUtil.info(logMsg);
		final AbcUtil abcUtil = new AbcUtil();
		channelParam = abcUtil.checkChannelParam(logPrefix, httpParam.getClearingTransType(), channelParam);
		// 1、生成订单对象 com.hitrust.trustpay.client.b2c.Order
		final Order order = new Order(); // 订单对象
		final String orderNo = sequenceManagerService.getAbcChannelSN(DateUtil.getCurrentDate());
		// 2、设定订单对象的属性
		order.setOrderNo(orderNo);// 单号流水);//订单编号
		String orderDesc = "";
		String orderDate = "";
		String orderTime = "";
		String ordernote = "";
		BigDecimal orderAmount = BigDecimal.ZERO;
		String sn = "";
		final String productID = channelParam.get("100010");
		String productName = "";
		// 支付
		logMsg = "获取 " + logPrefix + " 支付对象。";
		Log4jUtil.info(logMsg);
		final NetDeductDTO onlineDeduct = (NetDeductDTO) httpParam.getBizBean();
		if (onlineDeduct == null) {
			throw new BizException(logPrefix + " 获取到的支付对象为NULL。");
		}
		ObjectUtil.printPropertyString(logPrefix, onlineDeduct);
		orderDesc = onlineDeduct.getOrderRemark();
		orderDate = new SimpleDateFormat("yyyy/MM/dd").format(onlineDeduct.getCreatedTime());
		orderTime = new SimpleDateFormat("HH:mm:ss").format(onlineDeduct.getCreatedTime());

		ordernote = onlineDeduct.getOrderRemark();// 订单备注
		if (ordernote == null) {
			ordernote = onlineDeduct.getTxnId();
		}
		orderAmount = onlineDeduct.getAmount();
		sn = onlineDeduct.getTxnId();
		if (ClearingTransType.NET_DEDUCT_B2C_PAY.equals(httpParam.getClearingTransType())) {
			productName = channelParam.get("100011");
			// 支付 productName = channelParam.get("100011");
		} else if (ClearingTransType.NET_DEDUCT_B2C_RECHARGE.equals(httpParam.getClearingTransType())) {
			productName = channelParam.get("100012");
			// 充值productName = channelParam.get("100012");
		}
		if (orderDesc == null) {
			orderDesc = productName;
		}
		final BigDecimal maxAmount = new BigDecimal(channelParam.get("100005"));
		if (DecimalUtil.ge(orderAmount, maxAmount)) {
			logMsg = logPrefix + " 支付金额：" + String.format("%1$.2f", orderAmount) + "大于"
					+ String.format("%1$.2f", maxAmount) + "无法提交请求";
			Log4jUtil.error(logMsg);
			throw new BizException(logMsg);
		}
		order.setOrderDesc(orderDesc);// 订单说明
		order.setOrderDate(orderDate);// 订单日期
		order.setOrderTime(orderTime);// 订单时间
		order.setOrderAmount(DecimalUtil.formatToDouble(orderAmount));
		final String orderURL = httpParam.getRequestURL();
		order.setOrderURL(orderURL == null ? "" : orderURL); // 设定订单网址
		final String buyIP = httpParam.getRequestIp();
		order.setBuyIP(buyIP == null ? "" : buyIP); // 设定订单IP
		// //3、生成订单明细对象
		// com.hitrust.trustpay.client.b2c.OrderItem，并将订单明细加入订单中（可选信息）
		final OrderItem orderItem = new OrderItem();
		orderItem.setProductID(productID);
		orderItem.setProductName(productName);
		orderItem.setQty(1);
		orderItem.setUnitPrice(DecimalUtil.formatToDouble(orderAmount));
		ObjectUtil.printPropertyString(logPrefix, orderItem);
		order.addOrderItem(orderItem);
		ObjectUtil.printPropertyString(logPrefix, order);
		// 4、生成支付请求对象 com.hitrust.trustpay.client.b2c.PaymentRequest
		logMsg = logPrefix + " 生成支付请求对象paymentRequest。";
		Log4jUtil.info(logMsg);
		final PaymentRequest paymentRequest = new PaymentRequest(); // 5、设定支付请求对象的属性
		if (channelParam.get("100007").equals("1")) {
			paymentRequest.setResultNotifyURL(channelParam.get("100001")); // 设定支付结果回传网址
																			// （必要信息）如果支付结果通知方式选择了页面通知，此处填写就是支付结果回传网址；如果支付结果通知方式选择了服务器通知，此处填写的就是接收支付平台服务器发送响应信息的地
		} else {
			paymentRequest.setResultNotifyURL(channelParam.get("100002")); // 设定支付结果回传网址
																			// （必要信息）如果支付结果通知方式选择了页面通知，此处填写就是支付结果回传网址；如果支付结果通知方式选择了服务器通知，此处填写的就是接收支付平台服务器发送响应信息的地
		}
		paymentRequest.setOrder(order);// 设定支付请求的订单 （必要信息）
		paymentRequest.setProductType(channelParam.get("100004")); // 设定商品种类 （必要信息）
																	// PaymentRequest.PRD_TYPE_ONE：非实体商品，如服务、IP卡、下载MP3、...
																	// PaymentRequest.PRD_TYPE_TWO：实体商品
		paymentRequest.setPaymentType(channelParam.get("100006")); // 设定支付类型 1：农行卡支付 2：国际卡支付
																	// 3：农行贷记卡支付 A:支付方式合并
		paymentRequest.setNotifyType(channelParam.get("100007")); // 设定商户通知方式 0：URL页面通知 1：服务器通知
		paymentRequest.setPaymentLinkType(channelParam.get("100008"));// 设定支付接入方式 1：internet网络接入
																		// 2：手机网络接入 3:数字电视网络接入
																		// 4:智能客户端
		paymentRequest.setMerchantRemarks(ordernote); // 设定商户备注信息

		ObjectUtil.printPropertyString(logPrefix, paymentRequest);
		logMsg = logPrefix + " 向银行发起支付请求。流水号为：" + sn + " 订单号为：" + orderNo;
		Log4jUtil.info(logMsg);

		final TrxResponse trxResponse = paymentRequest.extendPostRequest(1);
		ObjectUtil.printPropertyString(logPrefix, trxResponse);
		final HttpReturnParam hrp = new HttpReturnParam();
		if (trxResponse.isSuccess()) {
			// 6、支付请求提交成功，将客户端导向支付页面
			try {
				billnoSnService.save(logPrefix, orderNo, httpParam);
				logMsg = logPrefix + " 支付请求提交成功，将客户端导向支付页面：" + trxResponse.getValue("PaymentURL");
				Log4jUtil.info(logMsg);
				// httpParam.getResponse().sendRedirect(trxResponse.getValue("PaymentURL"));
				// 改为返回重定向URL
				hrp.setAction(trxResponse.getValue("PaymentURL"));
			} catch (final Throwable t) {
				Log4jUtil.error(logPrefix + " 支付请求提交失败，Throwable出错：", t);
				throw new BizException(logPrefix + " 支付请求提交失败" + t.getMessage());
			}
		} else {
			logMsg = logPrefix + " 支付请求提交失败。错误码：" + trxResponse.getReturnCode() + " 错误描述："
					+ trxResponse.getErrorMessage();
			Log4jUtil.info(logMsg);
			throw new BizException(logMsg);
		}
		// 写交易流水和渠道流水对照表

		return hrp;
	}

	//

	// 1、取得身份验证请求所需要的信息
	// I 公民身份证
	// P 中国护照
	// S 军人身份证
	// J 警官证
	// K 户口簿
	// T 临时身份证
	// F 外国护照
	// D 港澳通行证
	// W 台胞通行证
	// R 离休干部荣誉证
	// B 军官退休证
	// A 文职干部退休证
	// C 军事院校学员证
	// E 武装警察身份证
	// G 军官证
	// H 文职干部证
	// L 军人士兵证
	// M 武警士兵证
	// U 其他证件
	/**
	 * <p>农业银行网银账户验证</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午3:39:29
	 */
	private HttpReturnParam accountVerify(final String logPrefix, final HttpParam httpParam,
			Map<String, String> channelParam) throws BizException {
		String logMsg = "";
		logMsg = "进入" + logPrefix + "网银账户验证业务处理。";
		Log4jUtil.info(logMsg);
		final AbcUtil abcUtil = new AbcUtil();
		channelParam = abcUtil.checkChannelParam(logPrefix, ClearingTransType.ONLINE_ACCOUNT_VERIFY, channelParam);
		final BankCardVerifyDTO accountVerifyBill = (BankCardVerifyDTO) httpParam.getBizBean();
		if (accountVerifyBill == null) {
			throw new BizException(logPrefix + "获取到的账户验证对象为NULL");
		}
		ObjectUtil.printPropertyString(logPrefix, accountVerifyBill);

		final String tCertificateType = this.changeCertificateType(accountVerifyBill.getCertificateType());// 证件类型
		final String tCertificateNo = accountVerifyBill.getCertificateNo();
		final String tBankCardNo = accountVerifyBill.getBankCardNo();
		final String tRequestDate = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
		final String tRequestTime = new SimpleDateFormat("HH:mm:ss").format(new Date());

		// 2、生成身份验证请求对象
		logMsg = logPrefix + "生成账户验证请求对象IdentityVerifyRequest";
		Log4jUtil.info(logMsg);
		final IdentityVerifyRequest tRequest = new IdentityVerifyRequest();
		tRequest.setBankCardNo(tBankCardNo); // 银行帐号 （必要信息）
		tRequest.setCertificateNo(tCertificateNo); // 证件号码 （必要信息）
		tRequest.setCertificateType(tCertificateType); // 证件类型 （必要信息）
		tRequest.setResultNotifyURL(channelParam.get("100002")); // 身份验证回传网址（必要信息）
		tRequest.setRequestDate(tRequestDate); // 验证请求日期 （必要信息 - YYYY/MM/DD）
		tRequest.setRequestTime(tRequestTime); // 验证请求时间 （必要信息 - HH:MM:SS）

		// 3、传送身份验证请求并取得支付网址
		logMsg = logPrefix + "向银行发起账户验证请求。";
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, tRequest);
		final TrxResponse tTrxResponse = tRequest.postRequest();
		ObjectUtil.printPropertyString(logPrefix, tTrxResponse);
		final HttpReturnParam hrp = new HttpReturnParam();
		if (tTrxResponse.isSuccess()) {
			// 4、身份验证请求提交成功，将客户端导向身份验证页面
			try {
				logMsg = logPrefix + "向银行发起账户验证请求成功，将界面导向界面：" + tTrxResponse.getValue("VerifyURL");
				Log4jUtil.info(logMsg);
				// httpParam.getResponse().sendRedirect(tTrxResponse.getValue("VerifyURL"));改为返回URL
				hrp.setAction(tTrxResponse.getValue("VerifyURL"));
			} catch (final Exception e) {
				logMsg = logPrefix + "将界面导向界面：" + tTrxResponse.getValue("VerifyURL") + "失败。" + e.getMessage();
				Log4jUtil.info(logMsg);
				throw new BizException(logMsg + "出错:" + e.getMessage());
			}
		} else {
			// 5、身份验证请求提交失败，商户自定后续动作
			logMsg = logPrefix + "向银行发起账户验证请求失败，ReturnCode:" + tTrxResponse.getReturnCode() + " ErrorMessage:"
					+ tTrxResponse.getErrorMessage();
			Log4jUtil.info(logMsg);
			throw new BizException(logMsg);
		}
		return hrp;
	}

	/**
	 * <p>证件类型转换(PS.迁移时问题:为什么需要写此无用的子方法)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午3:49:03
	 */
	private String changeCertificateType(final String certificateType) { // XXX Terry 这里做下标记，待完善
		if (certificateType.equals(CertificateType.IDENTITY_CARD)) {
			return "I";
		} else {
			return "I";
		}
	}

}
// @Override
// public HttpReturnParam process(final HttpParam httpParam) throws BizException {
// Map<String, String> channelParam = new Map<String, String>();
// String logPrefix = "";
// String logMsg = "";
// logPrefix = httpParam.getChannelId() + ChannelId.getNameByValue(httpParam.getChannelId());
// logMsg = "进入" + logPrefix + "渠道Http业务处理。";
// Log4jUtil.info(logMsg);
// // 获取渠道对应参数
// channelParam = channelParmService.getChannelParam(httpParam.getChannelId());
// if (channelParam == null) {
// throw new BizException("无法获取" + logPrefix + "渠道参数配置。");
// }
// if (httpParam.getChannelTransType().equals(ChannelTransType.Net_Bank_Pay)) {
// if (httpParam.getTransType().equals(ClearingTransType.Direct_Pay)
// || httpParam.getTransType().equals(ClearingTransType.Guarantee_Pay)
// || httpParam.getTransType().equals(ClearingTransType.Recharge)) {
// return this.b2CPay(logPrefix, httpParam, channelParam);// 支付或担保支付或者充值
// }
// throw new BizException(logPrefix + "错误的交易类型:" + httpParam.getChannelTransType() + ":"
// + httpParam.getTransType());
// } else if (httpParam.getChannelTransType().equals(ChannelTransType.Account_Verify_By_Html)) {
// if (httpParam.getTransType().equals(ClearingTransType.Account_Verify)) {
// return this.accountVerify(logPrefix, httpParam, channelParam);
// }
// throw new BizException(logPrefix + "错误的交易类型:" + httpParam.getChannelTransType() + ":"
// + httpParam.getTransType());
// } else if (httpParam.getChannelTransType().equals(ChannelTransType.Card_Tong_Sign)) { // 签约
// return this.agentSign(logPrefix, httpParam, channelParam);
// } else if (httpParam.getChannelTransType().equals(ChannelTransType.Card_Tong_Cancel)) { // 解约
// return this.agentUnsign(logPrefix, httpParam, channelParam);
// } else {
// throw new BizException(logPrefix + "错误的交易类型:" + httpParam.getChannelTransType() + ":"
// + httpParam.getTransType());
// }
// }

/**
 * // * 扣款解约 // * // * @param httpParam // * @return //
 */
// private HttpReturnParam agentUnsign(final String logPrefix, final HttpParam httpParam,
// final Map<String, String> channelParam) throws BizException {
// String logMsg = "";
// logMsg = "进入" + logPrefix + "扣款解约业务处理。";
// Log4jUtil.info(logMsg);
// // 问题1：订单号在本系统里没记录，也就没记录操作过程。
// // 问题2：回执在文档中无法找到
// // 问题3：签约时协议号没传到农行去，解约时需要将该协议号传到农行去解约，，，所以此处有矛盾
// ProtocolKftcard protocolKftcard = new ProtocolKftcard();
// protocolKftcard = (ProtocolKftcard) httpParam.getBizBean(); //
// if (protocolKftcard == null) {
// throw new BizException(logPrefix + "获取到的对象ProtocolKftcard为NULL。");
// }
// // 1、取得委托扣款解约请求所需要的信息
// final String tOrderNo = SequenceManager.getAbcChannelSN(DateUtil.getCurrentDate());
// final String tCertificateType = this.changeCertificateType(protocolKftcard.getCertifiType());//
// 证件类型
// final String tCertificateNo = protocolKftcard.getCertifiNo();
// String tResultNotifyURL = channelParam.get("100002");// 接收验证结果通知URL（必要信息）
// if (tResultNotifyURL == null || tResultNotifyURL.length() < 1) {
// logMsg = logPrefix +
// "无法获取渠道参数中的页面处理结果返回URL。默认填写为：http://www.lycheepay.com/paycore/abcHttpServlet";
// Log4jUtil.info(logMsg);
// tResultNotifyURL = "http://www.lycheepay.com/paycore/abcHttpServlet";
// }
// final String tRequestDate = new
// SimpleDateFormat("yyyy/MM/dd").format(protocolKftcard.getSignDate());
// final String tRequestTime = new
// SimpleDateFormat("HH:mm:ss").format(protocolKftcard.getSignDate());
// String tNotifyType = channelParam.get("100007");
// if (tNotifyType == null || tNotifyType.length() < 1) {
// logMsg = logPrefix + "无法获取渠道参数中的商户通知方式。默认填写为：1 服务器通知";
// Log4jUtil.info(logMsg);
// tNotifyType = "1";
// }
// final String tAgentSignNo = protocolKftcard.getProtocolno();
//
// // 2、生成委托扣款解约请求对象
// final B2CAgentUnsignContractRequest tRequest = new B2CAgentUnsignContractRequest();
// tRequest.setIOrderNo(tOrderNo);// 订单编号（必要信息）
// tRequest.setICertificateNo(tCertificateNo); // 证件号码 （必要信息）
// tRequest.setICertificateType(tCertificateType); // 证件类型 （必要信息）
// tRequest.setIResultNotifyURL(tResultNotifyURL); // 身份验证回传网址（必要信息）
// tRequest.setIRequestDate(tRequestDate); // 验证请求日期 （必要信息 - YYYY/MM/DD）
// tRequest.setIRequestTime(tRequestTime); // 验证请求时间 （必要信息 - HH:MM:SS）
// tRequest.setINotifyType(tNotifyType); // 通知方式
// tRequest.setIAgentSignNo(tAgentSignNo);// 协议号
//
// // 3、传送委托扣款解约请求并取得解约网址
// logMsg = logPrefix + "向银行发起委托扣款解约请求。订单号为:" + tOrderNo;
// Log4jUtil.info(logMsg);
// final TrxResponse tTrxResponse = tRequest.postRequest();
// final HttpReturnParam hrp = new HttpReturnParam();
// if (tTrxResponse.isSuccess()) {
// // 4、导向界面
// // try {
// logMsg = logPrefix + "向银行发起委托扣款解约请求成功。将界面导向:" + tTrxResponse.getValue("B2CAgentSignContractURL");
// Log4jUtil.info(logMsg);
// // httpParam.getResponse().sendRedirect(tTrxResponse.getValue("B2CAgentSignContractURL"));改为返回URL
// hrp.setAction(tTrxResponse.getValue("B2CAgentSignContractURL"));
// // } catch (IOException e) {
// // logMsg = logPrefix + "将界面导向:" + tTrxResponse.getValue("B2CAgentSignContractURL") +
// // "时出错。";
// Log4jUtil.error(logMsg);
// // throw new BizException(e);
// // }
// } else {
// logMsg = logPrefix + "向银行发起委托扣款解约请求失败。ReturnCode:" + tTrxResponse.getReturnCode() +
// " ErrorMessage:"
// + tTrxResponse.getErrorMessage();
// Log4jUtil.error(logMsg);
// throw new BizException(logMsg);
// }
//
// return hrp;
// }
//
// /**
// * 扣款签约
// *
// * @param httpParam
// * @return
// */
// private HttpReturnParam agentSign(final String logPrefix, final HttpParam httpParam,
// final Map<String, String> channelParam) throws BizException {
// String logMsg = "";
// logMsg = "进入" + logPrefix + "网银扣款签约业务处理。";
// Log4jUtil.info(logMsg);
// // 问题1：订单号在本系统里没记录，也就没记录操作过程。
// // 问题2：协议号没传到农行去，解约时需要将该协议号传到农行去解约，，，所以此处有矛盾
// // 问题3：签约回执在文档中找不到
// // 1、取得委托扣款签约请求所需要的信息
// ProtocolKftcard protocolKftcard = new ProtocolKftcard();
// protocolKftcard = (ProtocolKftcard) httpParam.getBizBean();
// if (protocolKftcard == null) {
// throw new BizException(logPrefix + "获取到的对象ProtocolKftcard为NULL。");
// }
// final String tOrderNo = SequenceManager.getAbcChannelSN(DateUtil.getCurrentDate());
// final String tCertificateType = this.changeCertificateType(protocolKftcard.getCertifiType());//
// 证件类型
// final String tCertificateNo = protocolKftcard.getCertifiNo();
// String tResultNotifyURL = channelParam.get("100002");// 接收验证结果通知URL（必要信息）
// if (tResultNotifyURL == null || tResultNotifyURL.length() < 1) {
// logMsg = logPrefix +
// "无法获取渠道参数中的页面处理结果返回URL。默认填写为：http://www.lycheepay.com/paycore/abcHttpServlet";
// Log4jUtil.info(logMsg);
// tResultNotifyURL = "http://www.lycheepay.com/paycore/abcHttpServlet";
// }
// final String tRequestDate = new
// SimpleDateFormat("yyyy/MM/dd").format(protocolKftcard.getSignDate());
// final String tRequestTime = new
// SimpleDateFormat("HH:mm:ss").format(protocolKftcard.getSignDate());
// // String tInvaidDate = request.getParameter("InvaidDate");
// // String tALimitAmt = request.getParameter("ALimitAmt");
// // String tADayLimitAmt = request.getParameter("ADayLimitAmt");
// String tNotifyType = channelParam.get("100007");
// if (tNotifyType == null || tNotifyType.length() < 1) {
// logMsg = logPrefix + "无法获取渠道参数中的商户通知方式。默认填写为：1 服务器通知";
// Log4jUtil.info(logMsg);
// tNotifyType = "1";
// }
//
// // 2、生成委托扣款签约请求对象
// logMsg = logPrefix + "向银行发起委托扣款签约请求。订单号为:" + tOrderNo;
// Log4jUtil.info(logMsg);
// final B2CAgentSignContractRequest tRequest = new B2CAgentSignContractRequest();
// tRequest.setIOrderNo(tOrderNo);// 订单编号（必要信息）
// tRequest.setICertificateNo(tCertificateNo); // 证件号码 （必要信息）
// tRequest.setICertificateType(tCertificateType); // 证件类型 （必要信息）
// tRequest.setIResultNotifyURL(tResultNotifyURL); // 身份验证回传网址（必要信息）
// tRequest.setIRequestDate(tRequestDate); // 验证请求日期 （必要信息 - YYYY/MM/DD）
// tRequest.setIRequestTime(tRequestTime); // 验证请求时间 （必要信息 - HH:MM:SS）
// // tRequest.setIInvaidDate(tInvaidDate);
// // tRequest.setIALimitAmt(tALimitAmt);
// // tRequest.setIADayLimitAmt(tADayLimitAmt);
// tRequest.setINotifyType(tNotifyType);
//
// // 3、传送委托扣款签约请求并取得签约网址
// logMsg = logPrefix + "向银行发起委托扣款签约请求。订单号为:" + tOrderNo;
// Log4jUtil.info(logMsg);
// final TrxResponse tTrxResponse = tRequest.postRequest();
// final HttpReturnParam hrp = new HttpReturnParam();
// if (tTrxResponse.isSuccess()) {
// // 4、导向委托扣款签约界面
// // try {
// logMsg = logPrefix + "向银行发起委托扣款签约请求成功。将界面导向:" + tTrxResponse.getValue("B2CAgentSignContractURL");
// Log4jUtil.info(logMsg);
// // httpParam.getResponse().sendRedirect(tTrxResponse.getValue("B2CAgentSignContractURL"));
// hrp.setAction(tTrxResponse.getValue("B2CAgentSignContractURL"));
// // } catch (IOException e) {
// // logMsg = logPrefix + "将界面导向:" + tTrxResponse.getValue("B2CAgentSignContractURL") +
// // "时出错。";
// Log4jUtil.error(logMsg);
// // throw new BizException("出错:" + e.getMessage());
// // }
// } else {
// // 5、失败操作
// logMsg = logPrefix + "向银行发起委托扣款签约请求失败。ReturnCode:" + tTrxResponse.getReturnCode() +
// " ErrorMessage:"
// + tTrxResponse.getErrorMessage();
// Log4jUtil.error(logMsg);
// throw new BizException("发送签约出错!ReturnCode:" + tTrxResponse.getReturnCode() + " ErrorMessage:"
// + tTrxResponse.getErrorMessage());
// }
//
// return hrp;
// }
