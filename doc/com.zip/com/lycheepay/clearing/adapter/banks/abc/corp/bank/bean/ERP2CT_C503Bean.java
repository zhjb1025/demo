package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_C503Bean {

	// ERP2CT_C503 查询单账户明细（C503）请求报文字段
	private String DbAccNo;	// 账号
	private String DbProv;	// 省市代码
	private String DbCur;	// 货币号
	private String StartTime;	// 末笔时间戳
	private String StartDate;	// 起始日期
	private String EndDate;	// 终止日期
	private String LastJrnNo;	// 末笔日志号

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

	public String getStartTime() {
		return StartTime;
	}

	public void setStartTime(final String startTime) {
		StartTime = startTime;
	}

	public String getStartDate() {
		return StartDate;
	}

	public void setStartDate(final String startDate) {
		StartDate = startDate;
	}

	public String getEndDate() {
		return EndDate;
	}

	public void setEndDate(final String endDate) {
		EndDate = endDate;
	}

	public String getLastJrnNo() {
		return LastJrnNo;
	}

	public void setLastJrnNo(final String lastJrnNo) {
		LastJrnNo = lastJrnNo;
	}

}
