package com.lycheepay.clearing.adapter.banks.abc.cross.service.channel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.cross.service.process.AbcCrossProcessService;
import com.lycheepay.clearing.adapter.banks.abc.cross.thread.AbcCrossThreadPool;
import com.lycheepay.clearing.adapter.banks.abc.cross.thread.AbcCrossWorkerWH14;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractUploadService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.UploadInfoDTO;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.ABC_CROSS_UPLOAD_SERVICE)
public class AbcCrossUploadService extends AbstractUploadService {
	
	@Autowired
	private AbcCrossProcessService abcCrossProcessService;
	
	@Autowired
	@Qualifier("jmsTemplateForMerchantResult")
	private JmsTemplate mqSender;

	@Override
	public ClearingResultDTO uploadMerchantInfo(UploadInfoDTO uploadInfoDTO) {
		Log4jUtil.setLogClass("ABC_CROSS", "UploadService");
		Log4jUtil.info("渠道入口-上传接口");
		
		AbcCrossThreadPool.launch(new AbcCrossWorkerWH14(abcCrossProcessService, mqSender, uploadInfoDTO));
		
		Log4jUtil.info("工作线程已提交");
		
		ClearingResultDTO result = new ClearingResultDTO();
		result.setChannelId(ChannelIdEnum.ABC_CROSS_PAY.getCode());
		result.setChannelResponseCode("0000");
		result.setChannelResponseMsg("异步处理");
		return result;
	}
}
