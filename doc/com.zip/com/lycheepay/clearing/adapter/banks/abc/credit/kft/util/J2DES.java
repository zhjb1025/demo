package com.lycheepay.clearing.adapter.banks.abc.credit.kft.util;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 双倍长密钥算法
 * 
 * @author aps-txy
 * @date 2011-11-1
 */
public class J2DES {

	static String DES = "DES/ECB/NoPadding";
	static String TriDes = "DESede/ECB/NoPadding";

	public static byte[] des_crypt(final byte key[], final byte data[]) {

		try {
			final KeySpec ks = new DESKeySpec(key);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(DES);
			c.init(Cipher.ENCRYPT_MODE, ky);
			return c.doFinal(data);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}
	}

	public static byte[] des_decrypt(final byte key[], final byte data[]) {

		try {
			final KeySpec ks = new DESKeySpec(key);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(DES);
			c.init(Cipher.DECRYPT_MODE, ky);
			return c.doFinal(data);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}
	}

	/**
	 * 
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 */
	public static byte[] trides_crypt(final byte key[], final byte data[]) {
		try {
			final byte[] k = new byte[24];

			int len = data.length;
			if (data.length % 8 != 0) {
				len = data.length - data.length % 8 + 8;
			}
			byte[] needData = null;
			if (len != 0) {
				needData = new byte[len];
			}

			for (int i = 0; i < len; i++) {
				needData[i] = 0x00;
			}

			System.arraycopy(data, 0, needData, 0, data.length);

			if (key.length == 16) {
				System.arraycopy(key, 0, k, 0, key.length);
				System.arraycopy(key, 0, k, 16, 8);
			} else {
				System.arraycopy(key, 0, k, 0, 24);
			}

			final KeySpec ks = new DESedeKeySpec(k);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(TriDes);
			c.init(Cipher.ENCRYPT_MODE, ky);
			return c.doFinal(needData);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}

	}

	/**
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 */
	public static byte[] trides_decrypt(final byte key[], final byte data[]) {
		try {
			final byte[] k = new byte[24];

			int len = data.length;
			if (data.length % 8 != 0) {
				len = data.length - data.length % 8 + 8;
			}
			byte[] needData = null;
			if (len != 0) {
				needData = new byte[len];
			}

			for (int i = 0; i < len; i++) {
				needData[i] = 0x00;
			}

			System.arraycopy(data, 0, needData, 0, data.length);

			if (key.length == 16) {
				System.arraycopy(key, 0, k, 0, key.length);
				System.arraycopy(key, 0, k, 16, 8);
			} else {
				System.arraycopy(key, 0, k, 0, 24);
			}
			final KeySpec ks = new DESedeKeySpec(k);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(TriDes);
			c.init(Cipher.DECRYPT_MODE, ky);
			return c.doFinal(needData);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}

	}

	public static void main(final String[] args) {

		final byte k1[] = { 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, (byte) 0x88 };
		final byte k2[] = { (byte) 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11 };
		final byte k24[] = new byte[24];
		System.arraycopy(k1, 0, k24, 0, 8);
		System.arraycopy(k2, 0, k24, 8, 8);
		System.arraycopy(k1, 0, k24, 16, 8);

		// byte data[] = //
		// hexToBytes("00000000" + "00000000" + "00000000" + "00000000"
		// + "0000c619" + "f4fb7bde" + "51309100" + "00110000"
		// + "00000000" + "00000000" + "00000000" + "00000000"
		// + "00000000" + "00000000" + "00000000" + "00000000"
		// + "00000000" + "00000000" + "00000000" + "00000000"
		// + "00000000" + "00000000" + "00000000" + "00000000"
		// + "00000000" + "00000000" + "00000000" + "00000000"
		// + "00000000" + "00000000" + "00000000" + "00000000");

		// data = new byte[8];
		// byte des_crypt[] = des_crypt(k1, data);
		// byte des_descrypt[] = des_decrypt(k2, des_crypt);
		// byte result[] = des_crypt(k1, des_descrypt);
		// byte result[] = trides_crypt(k24, data);
		// byte origin[] = trides_decrypt(k24, result);
		// System.out.println("Result = " + result);

		// String data_ = "3298DEEAB76C682D"; //51CE460DB5866E0B
		// String shiMi = "6E8F6B0EBF97B6830775BC67E33EC75D"; //51CE460DB5866E0B
		// try {
		// byte[] result_ = trides_decrypt(LoUtils.hexStr2Bytes(shiMi),
		// LoUtils.hexStr2Bytes(data_));
		// System.out.println(LoUtils.byte2HexStr(result_));
		// } catch (Exception e) {
		// Log4jUtil.error( e);
		// }
	}

	public static byte[] hexToBytes(final String str) {
		if (str == null) {
			return null;
		} else if (str.length() < 2) {
			return null;
		} else {
			final int len = str.length() / 2;
			final byte[] buffer = new byte[len];
			for (int i = 0; i < len; i++) {
				buffer[i] = (byte) Integer.parseInt(str.substring(i * 2, i * 2 + 2), 16);
			}
			return buffer;
		}
	}
}
