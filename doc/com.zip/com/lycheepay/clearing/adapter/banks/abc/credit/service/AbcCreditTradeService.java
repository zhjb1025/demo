package com.lycheepay.clearing.adapter.banks.abc.credit.service;

import java.util.Date;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.credit.kft.util.AbcCreditMsgUtilService;
import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.MsgPack4Abc;
import com.lycheepay.clearing.adapter.banks.abc.credit.socket.SendBySocket4Abc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.DecimalUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行信用卡交易服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 上午3:38:53
 */
@Service(ClearingAdapterAnnotationName.ABC_CREDIT_TRADE_SERVICE)
public class AbcCreditTradeService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CREDIT_MSG_UTIL_SERVICE)
	private AbcCreditMsgUtilService msgUtil4AbcService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	private static String channelId = ChannelIdEnum.ABC_CREDIT_CARD.getCode();

	/**
	 * <p>农业银行信用卡交易扣款消费(PS.单笔代扣)</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午3:40:45
	 */
	public ReturnState motoConsumeTrade(final Param param) throws BizException {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		ReturnState returnState = null;
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		MsgPack4Abc rqtMsgPack4Abc = null;
		try {
			Log4jUtil.info("农行信用卡组报文消费MOTOconsume开始-->>");
			rqtMsgPack4Abc = msgUtil4AbcService.createMOTOConsumeMsgPack4Abc(param);
			billnoSnService.saveBillnoSn(rqtMsgPack4Abc.getFieldContent11(), param);
			Log4jUtil.info("农行信用卡组报文消费MOTOconsume结束--<<");
			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			Log4jUtil.info("农行信用卡MOTO消费报文socket通信->发送->返回->解析开始-->>");
			byte[] backMsg = null;
			try {
				Log4jUtil.info("====================================================a");
				backMsg = sendBySocket4Abc.sendAndRecvDonotUnpackByte(socketIP.getParvalue(), socketPort.getParvalue(),
						rqtMsg);
				Log4jUtil.info("====================================================b");
			} catch (final BizException e) {
				Log4jUtil.info("====================================================aa");
				Log4jUtil.error(e);
				returnState = createFailedReturnState(param, null, rqtMsgPack4Abc, e);
				Log4jUtil.info("====================================================bb");
				return returnState;
			}
			MsgPack4Abc rspMsgPack4Abc = null;
			try {
				Log4jUtil.info("====================================================c");
				rspMsgPack4Abc = SendBySocket4Abc.unpackMsg(backMsg, socketIP.getParvalue());
				Log4jUtil.info("====================================================d");
			} catch (final BizException e) {
				Log4jUtil.info("====================================================cc");
				Log4jUtil.error(e);
				returnState = createFailedReturnState(param, null, rqtMsgPack4Abc, e);
				Log4jUtil.info("====================================================dd");
				return returnState;
			}

			Log4jUtil.info("农行信用卡MOTO消费报文socket通信->发送->返回->解析结束--<<");

			displayMsgPack4Abc(rqtMsgPack4Abc);
			Log4jUtil.info("====================================================");
			displayMsgPack4Abc(rspMsgPack4Abc);

			Log4jUtil.info("====================================================");
			Log4jUtil.info("====================================================");
			Log4jUtil.info("====================================================");
			Log4jUtil.info(rspMsgPack4Abc + "===================================================="
					+ rspMsgPack4Abc.getMsgType());
			if (null == rspMsgPack4Abc) {
				returnState = createFailedReturnState(param, rspMsgPack4Abc, rqtMsgPack4Abc, null);
			} else if ("0210".equals(rspMsgPack4Abc.getMsgType())) {
				returnState = createSuccessReturnState(param, rspMsgPack4Abc, rqtMsgPack4Abc);
			} else {
				Log4jUtil.info("============else========================================");
				returnState = createFailedReturnState(param, rspMsgPack4Abc, rqtMsgPack4Abc, null);
				Log4jUtil.info("============else========================================");
			}

			Log4jUtil.info("农行信用卡组return state结束3");
			return returnState;
		} catch (final BizException e) {
			if ("1234567".equals(e.getErrorCode())) {
				Log4jUtil.info("农行信用卡MOTO消费报文执行中，发现签到返回参数不是当天，中断");
				throw new BizException("1234567", "签到返回参数的日期不是今天");
			}
			return returnState;
		} catch (final Exception e) {
			final String logMsg = "农行信用卡MOTO消费报文执行中，发现未知异常，返回失败回执" + e.getMessage();
			Log4jUtil.info(logMsg);
			return returnState;
		}
	}

	/**
	 * <p>农行信用卡组报文签到</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午3:13:02
	 */
	public void signInTrade() {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		try {
			Log4jUtil.info("农行信用卡组报文签到signIn开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createSignInMsgPack4Abc();
			Log4jUtil.info("农行信用卡组报文签到signIn结束--<<");

			final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
			if (rqtMsgPack4Abc == null) {
				Log4jUtil
						.info("The request message is null,please check the reason -:), No message provide for socket!!!. Sign In Trade");
			}
			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			// MsgPack4Abc rspMsgPack4Abc =
			// sendBySocket4Abc.sendAndRecv(socketIP
			// .getParvalue(), socketPort.getParvalue(), rqtMsg);
			byte[] backMsg = null;
			try {
				Log4jUtil.info("农行信用卡联机签到报文socket通信->发送->返回->结束--<<");
				backMsg = sendBySocket4Abc.sendAndRecvDonotUnpackByte(socketIP.getParvalue(), socketPort.getParvalue(),
						rqtMsg);
				Log4jUtil.info("农行信用卡联机签到报文socket通信->发送->返回->结束--<<");
			} catch (final BizException e) {
				throw new BizException(e);
			}
			MsgPack4Abc rspMsgPack4Abc = null;
			try {
				Log4jUtil.info("农行信用卡联机签到报文解析开始--<<");
				rspMsgPack4Abc = SendBySocket4Abc.unpackMsg(backMsg, socketIP.getParvalue());
				Log4jUtil.info("农行信用卡联机签到报文解析结束--<<");
			} catch (final BizException e) {
				throw new BizException(e);
			}

			if (rqtMsgPack4Abc == null) {
				Log4jUtil
						.info("The response message is null,please check the reason -:), Analysis Messge failed!!!. Sign In Trade");
			}

			Log4jUtil.info("农行信用卡联机签到报文持久化开始-->>");
			final ChannelParm channelParm = new ChannelParm();
			ChannelParmId channelParmId = new ChannelParmId("5001030000", "200001");
			channelParm.setId(channelParmId);
			channelParm.setParname("凭证号批次号");
			channelParm.setParvalue(rspMsgPack4Abc.getFieldContent62());
			channelParm.setIfmodify("Y");
			channelParm.setUsercode("");
			channelParm.setUpdatetime(new Date());
			channelParm.setRemark("农行信用卡，签到报文成功后，返回码");
			saveChannelParm(channelParm);

			channelParmId = new ChannelParmId("5001030000", "200002");
			channelParm.setId(channelParmId);
			channelParm.setParname("POS流水号");
			channelParm.setParvalue(rspMsgPack4Abc.getFieldContent11());
			channelParm.setIfmodify("Y");
			channelParm.setUsercode("");
			channelParm.setUpdatetime(new Date());
			channelParm.setRemark("农行信用卡，签到报文成功后，返回码");
			saveChannelParm(channelParm);

			channelParmId = new ChannelParmId("5001030000", "200003");
			channelParm.setId(channelParmId);
			channelParm.setParname("工作密钥");
			channelParm.setParvalue(rspMsgPack4Abc.getFieldContent61());
			channelParm.setIfmodify("Y");
			channelParm.setUsercode("");
			channelParm.setUpdatetime(new Date());
			channelParm.setRemark("农行信用卡，签到报文成功后，返回码");
			saveChannelParm(channelParm);
			Log4jUtil.info("农行信用卡联机签到报文持久化结束--<<");

		} catch (final Exception e) {
			Log4jUtil.info("The exception happend at signInTrade -:),Unknow Exception!!!. Sign In Trade");
		}
	}

	public void saveChannelParm(final ChannelParm newChannelParm) {
		final Object o = channelParmService.queryByPrimaryKey(newChannelParm.getId());
		if (null == o) {
			channelParmService.save(newChannelParm);
		} else {
			final ChannelParm orgChannelParm = (ChannelParm) o;
			orgChannelParm.setParvalue(newChannelParm.getParvalue());
			channelParmService.update(orgChannelParm);
		}
	}

	/***
	 * 撤销
	 * 
	 * @param billnoSn
	 * @return
	 * @throws Exception
	 */
	public ReturnState cancelTrade(final BillnoSn billnoSn) throws Exception {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		final ReturnState returnState = new ReturnState();
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		// CorpBillnoSn cropBillnoSn= new CorpBillnoSn();
		// cropBillnoSn.saveBillnoSn(bankSendSn,param); //bankSendSn-渠道发送银行流水

		try {
			Log4jUtil.info("农行信用卡组撤销交易报文Cancel开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createCancelMsgPack4Abc(billnoSn);
			Log4jUtil.info("农行信用卡组撤销交易报文Cancel结束--<<");

			if (rqtMsgPack4Abc == null) {
				Log4jUtil
						.info("The request message is null,please check the reason -:), No message provide for socket!!!. Cancel Trade");
				return null;
			}

			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			Log4jUtil.info("农行信用卡撤销交易报文socket通信->发送->返回->解析开始-->>");

			// MsgPack4Abc rspMsgPack4Abc =
			// sendBySocket4Abc.sendAndRecv(socketIP
			// .getParvalue(), socketPort.getParvalue(), rqtMsg);
			byte[] backMsg = null;
			try {
				backMsg = sendBySocket4Abc.sendAndRecvDonotUnpackByte(socketIP.getParvalue(), socketPort.getParvalue(),
						rqtMsg);
			} catch (final BizException e) {
				throw new BizException(e);
			}
			MsgPack4Abc rspMsgPack4Abc = null;
			try {
				rspMsgPack4Abc = SendBySocket4Abc.unpackMsg(backMsg, socketIP.getParvalue());
			} catch (final BizException e) {
				throw new BizException(e);
			}
			Log4jUtil.info("农行信用卡撤销交易报文socket通信->发送->返回->解析结束--<<");

			displayMsgPack4Abc(rspMsgPack4Abc);
			Log4jUtil.info("====================================================");
			displayMsgPack4Abc(rspMsgPack4Abc);

			Log4jUtil.info("农行信用卡取渠道ID：" + billnoSn.getChannelid() + "，渠道返回码:" + rspMsgPack4Abc.getFieldContent39()
					+ ",对应的编码");
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(billnoSn
					.getChannelid().trim(), rspMsgPack4Abc.getFieldContent39().trim()));
			if (null == channelRtncode) {
				returnState.setChannelCode(TransReturnCode.code_9900);
				returnState.setReturnMsg(rspMsgPack4Abc.getFieldContent39());
			} else {
				returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
				returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			}
			Log4jUtil.info("农行信用卡获取的快付通返回码为：" + returnState.getChannelCode());
			// 处理返回
			final ReturnState rs = new ReturnState();
			if (!rspMsgPack4Abc.getFieldContent39().equals("00")) {// 退货成功
				rs.setReturnState(PayState.FAILED_STR);
				rs.setBankRetCode("9999");
				rs.setBankPostScript("");
				Log4jUtil.info("农行信用卡撤销cancel处理失败,应答码为：" + rspMsgPack4Abc.getFieldContent39());
			} else {
				rs.setReturnState(PayState.SUCCEED_STR);
				rs.setBankRetCode("00");
				Log4jUtil.info("农行信用卡撤销cancel处理成功,退款的[BillnosnSeq]为:" + billnoSn.getBillnosnSeq());
			}
			return returnState;
		} catch (final Exception e) {
			final String logMsg = "农行信用卡撤销Cancel报文执行中，发现未知异常，中断" + e.getMessage();
			Log4jUtil.info(logMsg);
			throw new Exception(e);
		}
	}

	/**
	 * <p>农行信用卡自适应退款:撤销交易</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午4:46:58
	 */
	public ReturnState cancelTrade(final BillnoSn billnoSn, final Param param) throws BizException {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		final ReturnState returnState = new ReturnState();
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		try {
			Log4jUtil.info("农行信用卡组撤销交易报文Cancel开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createCancelMsgPack4Abc(billnoSn);

			if (rqtMsgPack4Abc == null) {
				Log4jUtil
						.info("The request message is null,please check the reason -:), No message provide for socket!!!. Cancel Trade");
				return null;
			}
			billnoSnService.saveBillnoSn(rqtMsgPack4Abc.getFieldContent11(), param);

			Log4jUtil.info("农行信用卡组撤销交易报文Cancel结束--<<");

			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			Log4jUtil.info("农行信用卡撤销交易报文socket通信->发送->返回->解析开始-->>");

			byte[] backMsg = null;
			try {
				backMsg = sendBySocket4Abc.sendAndRecvDonotUnpackByte(socketIP.getParvalue(), socketPort.getParvalue(),
						rqtMsg);
			} catch (final BizException e) {
				throw new BizException(e);
			}
			MsgPack4Abc rspMsgPack4Abc = null;
			try {
				rspMsgPack4Abc = SendBySocket4Abc.unpackMsg(backMsg, socketIP.getParvalue());
			} catch (final BizException e) {
				throw new BizException(e);
			}
			Log4jUtil.info("农行信用卡撤销交易报文socket通信->发送->返回->解析结束--<<");

			displayMsgPack4Abc(rspMsgPack4Abc);
			Log4jUtil.info("====================================================");
			displayMsgPack4Abc(rspMsgPack4Abc);

			Log4jUtil.info("农行信用卡取渠道ID：" + billnoSn.getChannelid() + "，渠道返回码:" + rspMsgPack4Abc.getFieldContent39()
					+ ",对应的编码");
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(billnoSn
					.getChannelid().trim(), rspMsgPack4Abc.getFieldContent39().trim()));
			if (null == channelRtncode) {
				returnState.setChannelCode(TransReturnCode.code_9900);
				returnState.setReturnMsg(rspMsgPack4Abc.getFieldContent39());
			} else {
				returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
				returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			}
			Log4jUtil.info("农行信用卡获取的快付通返回码为：" + returnState.getChannelCode());
			// 处理返回
			// ReturnState rs = new ReturnState();
			if (!rspMsgPack4Abc.getFieldContent39().equals("00")) {// 退货成功
				returnState.setReturnState(PayState.FAILED_STR);
				returnState.setBankRetCode("9999");
				returnState.setBankPostScript("");
				Log4jUtil.info("农行信用卡撤销cancel处理失败,应答码为：" + rspMsgPack4Abc.getFieldContent39());
			} else {
				returnState.setReturnState(PayState.SUCCEED_STR);
				returnState.setBankRetCode("00");
				Log4jUtil.info("农行信用卡撤销cancel处理成功,退款的[BillnosnSeq]为:" + billnoSn.getBillnosnSeq());
			}
			returnState.setSn(param.getSn());
			billnoSnService.updateBillnoSn(param, returnState, billnoSn.getBillnosnSeq(),
					rqtMsgPack4Abc.getFieldContent62(), rqtMsgPack4Abc.getFieldContent14());
			return returnState;
		} catch (final Exception e) {
			final String logMsg = "农行信用卡撤销Cancel报文执行中，发现未知异常，中断" + e.getMessage();
			Log4jUtil.info(logMsg);
			throw new BizException(e);
		}
	}

	/**
	 * <p>农行信用卡自适应退款:退货交易</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午4:46:58
	 */
	public ReturnState rejectTrade(final BillnoSn billnoSn, final Param param) throws BizException {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		final ReturnState returnState = new ReturnState();
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		try {
			Log4jUtil.info("农行信用卡组报文退货reject开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createRejectMsgPack4Abc(billnoSn);
			billnoSnService.saveBillnoSn(rqtMsgPack4Abc.getFieldContent11(), param);
			Log4jUtil.info("农行信用卡组报文退货reject结束--<<");
			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			Log4jUtil.info("农行信用卡退货报文socket通信->发送->返回->解析开始-->>");
			// MsgPack4Abc rspMsgPack4Abc =
			// sendBySocket4Abc.sendAndRecv(socketIP
			// .getParvalue(), socketPort.getParvalue(), rqtMsg);
			byte[] backMsg = null;
			try {
				backMsg = sendBySocket4Abc.sendAndRecvDonotUnpackByte(socketIP.getParvalue(), socketPort.getParvalue(),
						rqtMsg);
			} catch (final BizException e) {
				throw new BizException(e);
			}
			MsgPack4Abc rspMsgPack4Abc = null;
			try {
				rspMsgPack4Abc = SendBySocket4Abc.unpackMsg(backMsg, socketIP.getParvalue());
			} catch (final BizException e) {
				throw new BizException(e);
			}

			Log4jUtil.info("农行信用卡退货报文socket通信->发送->返回->解析结束--<<");

			displayMsgPack4Abc(rspMsgPack4Abc);
			Log4jUtil.info("====================================================");
			displayMsgPack4Abc(rspMsgPack4Abc);

			Log4jUtil.info("农行信用卡取渠道ID：" + billnoSn.getChannelid() + "，渠道返回码:" + rspMsgPack4Abc.getFieldContent39()
					+ ",对应的编码");
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(billnoSn
					.getChannelid().trim(), rspMsgPack4Abc.getFieldContent39().trim()));
			if (null == channelRtncode) {
				returnState.setChannelCode(TransReturnCode.code_9900);
				returnState.setReturnMsg(rspMsgPack4Abc.getFieldContent39());
			} else {
				returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
				returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			}
			Log4jUtil.info("农行信用卡获取的快付通返回码为：" + returnState.getChannelCode());
			// 处理返回
			// ReturnState rs = new ReturnState();
			if (!rspMsgPack4Abc.getFieldContent39().equals("00")) {// 退货成功
				// rs.setReturnState(PayState.FAILED_TRN);
				// rs.setBankRetCode("9999");
				// rs.setBankPostScript("");
				returnState.setReturnState(PayState.FAILED_STR);
				returnState.setBankRetCode("9999");
				returnState.setBankPostScript("");
				Log4jUtil.info("农行信用卡退货处理失败,应答码为：" + rspMsgPack4Abc.getFieldContent39());
			} else {
				// rs.setReturnState(PayState.SUCCEED_RTN);
				// rs.setBankRetCode("00");
				returnState.setReturnState(PayState.SUCCEED_STR);
				returnState.setBankRetCode("00");
				Log4jUtil.info("农行信用卡退货处理成功,退款的[BillnosnSeq]为:" + billnoSn.getBillnosnSeq());
			}
			returnState.setSn(param.getSn());
			billnoSnService.updateBillnoSn(param, returnState, billnoSn.getBillnosnSeq(),
					rqtMsgPack4Abc.getFieldContent62(), rqtMsgPack4Abc.getFieldContent14());
			return returnState;
		} catch (final Exception e) {
			final String logMsg = "农行信用卡退货Reject报文执行中，发现未知异常，中断" + e.getMessage();
			Log4jUtil.info(logMsg);
			throw new BizException(e);
		}
	}

	/***
	 * 退货
	 * 
	 * @param billnoSn
	 * @return
	 * @throws Exception
	 */
	public ReturnState rejectTrade(final BillnoSn billnoSn) throws Exception {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		final ReturnState returnState = new ReturnState();
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		try {
			Log4jUtil.info("农行信用卡组报文退货reject开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createRejectMsgPack4Abc(billnoSn);
			// param, organizedSysreflectedSn, organnizedPzBatchId);
			Log4jUtil.info("农行信用卡组报文退货reject结束--<<");

			if (rqtMsgPack4Abc == null) {
				Log4jUtil
						.info("The request message is null,please check the reason -:), No message provide for socket!!!. Reject Trade");
				return null;
			}

			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			Log4jUtil.info("农行信用卡退货报文socket通信->发送->返回->解析开始-->>");
			// MsgPack4Abc rspMsgPack4Abc =
			// sendBySocket4Abc.sendAndRecv(socketIP
			// .getParvalue(), socketPort.getParvalue(), rqtMsg);
			byte[] backMsg = null;
			try {
				backMsg = sendBySocket4Abc.sendAndRecvDonotUnpackByte(socketIP.getParvalue(), socketPort.getParvalue(),
						rqtMsg);
			} catch (final BizException e) {
				throw new BizException(e);
			}
			MsgPack4Abc rspMsgPack4Abc = null;
			try {
				rspMsgPack4Abc = SendBySocket4Abc.unpackMsg(backMsg, socketIP.getParvalue());
			} catch (final BizException e) {
				throw new BizException(e);
			}

			Log4jUtil.info("农行信用卡退货报文socket通信->发送->返回->解析结束--<<");

			displayMsgPack4Abc(rspMsgPack4Abc);
			Log4jUtil.info("====================================================");
			displayMsgPack4Abc(rspMsgPack4Abc);

			Log4jUtil.info("农行信用卡取渠道ID：" + billnoSn.getChannelid() + "，渠道返回码:" + rspMsgPack4Abc.getFieldContent39()
					+ ",对应的编码");
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(billnoSn
					.getChannelid().trim(), rspMsgPack4Abc.getFieldContent39().trim()));
			if (null == channelRtncode) {
				returnState.setChannelCode(TransReturnCode.code_9900);
				returnState.setReturnMsg(rspMsgPack4Abc.getFieldContent39());
			} else {
				returnState.setChannelCode(channelRtncode.getKftRtncode());// 快付通银行返回对照码
				returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			}
			Log4jUtil.info("农行信用卡获取的快付通返回码为：" + returnState.getChannelCode());
			// 处理返回
			final ReturnState rs = new ReturnState();
			if (!rspMsgPack4Abc.getFieldContent39().equals("00")) {// 退货成功
				rs.setReturnState(PayState.FAILED_STR);
				rs.setBankRetCode("9999");
				rs.setBankPostScript("");
				Log4jUtil.info("农行信用卡退货处理失败,应答码为：" + rspMsgPack4Abc.getFieldContent39());
			} else {
				rs.setReturnState(PayState.SUCCEED_STR);
				rs.setBankRetCode("00");
				Log4jUtil.info("农行信用卡退货处理成功,退款的[BillnosnSeq]为:" + billnoSn.getBillnosnSeq());
			}
			return returnState;
		} catch (final Exception e) {
			final String logMsg = "农行信用卡退货Reject报文执行中，发现未知异常，中断" + e.getMessage();
			Log4jUtil.info(logMsg);
			throw new Exception(e);
		}
	}

	/**
	 * <p>农业信用卡自适应退款</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午4:46:06
	 */
	public ReturnState doAutoRealtimeRefund(final Param param) throws BizException {
		ReturnState rs = new ReturnState();
		final AutoRealTimeRefund autoRealTimeRefund = channelTransUtilService.getAutoRealTimeRefund(param);

		final String sn = autoRealTimeRefund.getOrgPaySn(); // 原交易流水

		Log4jUtil.info("农行信用卡 ---billnosn->》》》》berfore》》》》》");
		final BillnoSn billnoSn = billnoSnService.getBillnoSnBySnAndChanneId(autoRealTimeRefund.getOrgTransChannelId(),
				sn);
		Log4jUtil.info("农行信用卡 ---billnosn->》》》after》》》》》》" + billnoSn);
		AssertUtils
				.notNull(billnoSn, TransReturnCode.code_9108, "渠道流水对照表中没有找到原流水号:" + autoRealTimeRefund.getOrgPaySn());
		final String CreditBatchNo = billnoSn.getCreditbatchno();// 凭证批次号
		AssertUtils.notNull(CreditBatchNo, TransReturnCode.code_9108, "凭证批次号不能为空");

		Log4jUtil.info("农行信用卡 ---CreditBatchNo  ---- after》》》》》》" + CreditBatchNo);
		final ChannelParm pzSn = channelParmService.queryByPrimaryKey(new ChannelParmId("5001030000", "200001"));
		Log4jUtil.info("农行信用卡 --pzSn  ------------- after》》》》》》" + pzSn);
		if (CreditBatchNo.equals(pzSn.getParvalue())
				&& DecimalUtil.eq(autoRealTimeRefund.getRefundAmount(), billnoSn.getAmount())) {
			Log4jUtil.info("农行信用卡退款交易过程，撤销交易，billnosn->seq=" + billnoSn.getBillnosnSeq());
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_CANCLE);
			rs = cancelTrade(billnoSn, param);
		} else {
			Log4jUtil.info("农行信用卡退款交易过程，退货交易，billnosn->seq=" + billnoSn.getBillnosnSeq());
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_REFUND);
			rs = rejectTrade(billnoSn, param);
		}
		Log4jUtil.info("===Abc online AutoRealtimeRefund finish");
		return rs;
	}

	public ReturnState dueHedgingTrade(final Param param, final String organizedDealSn, final String organizedDealCode)
			throws BizException {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		ReturnState returnState = new ReturnState();
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		try {
			Log4jUtil.info("农行信用卡组报文自动冲正dueHedging开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createDueHedgingMsgPack4Abc(param, organizedDealSn,
					organizedDealCode);
			Log4jUtil.info("农行信用卡组报文自动冲正dueHedging结束--<<");

			if (rqtMsgPack4Abc == null) {
				Log4jUtil
						.info("The request message is null,please check the reason -:), No message provide for socket!!!. Due Hedging Trade");
				return null;
			}

			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");

			Log4jUtil.info("农行信用卡自动冲正报文socket通信->发送->返回->解析开始-->>");
			final MsgPack4Abc rspMsgPack4Abc = sendBySocket4Abc.sendAndRecv(socketIP.getParvalue(),
					socketPort.getParvalue(), rqtMsg);
			Log4jUtil.info("农行信用卡自动冲正报文socket通信->发送->返回->解析结束--<<");

			displayMsgPack4Abc(rspMsgPack4Abc);
			if ("0430".equals(rspMsgPack4Abc.getMsgType())) {
				returnState = createSuccessReturnState(param, rspMsgPack4Abc, rqtMsgPack4Abc);
			} else {
				returnState = createFailedReturnState(param, rspMsgPack4Abc, rqtMsgPack4Abc, null);
			}
			return returnState;
		} catch (final BizException e) {
			if ("1234567".equals(e.getErrorCode())) {
				Log4jUtil.info("农行信用卡冲正报文执行中，发现签到返回参数不是当天，中断");
				throw new BizException("1234567", "签到返回参数的日期不是今天");
			}
			return null;
		} catch (final Exception e) {
			final String logMsg = "农行信用卡冲正报文执行中，发现未知异常，中断" + e.getMessage();
			Log4jUtil.info(logMsg);
			return null;
		}
	}

	/**
	 * <p>农行信用卡结算通知/联机签退</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午3:13:31
	 */
	public void settleNoticeTrade(final String field48) throws BizException {
		ChannelParm socketIP = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100001"));
		ChannelParm socketPort = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100002"));
		final SendBySocket4Abc sendBySocket4Abc = new SendBySocket4Abc();
		try {
			Log4jUtil.info("农行信用卡组报文结算通知/联机签退SettleNotice开始-->>");
			final MsgPack4Abc rqtMsgPack4Abc = msgUtil4AbcService.createSettleNoticeMsgPack4Abc(field48);
			Log4jUtil.info("农行信用卡组报文结算通知/联机签退SettleNotice结束--<<");

			if (rqtMsgPack4Abc == null) {
				Log4jUtil.info("农行信用卡组报文结算通知/联机签退组装报文为null，请检查。。。。");
				throw new BizException("农行信用卡组报文结算通知/联机签退组装报文为null，请检查。。。。");
			}

			final byte[] rqtMsg = rqtMsgPack4Abc.getBytes();
			AbcCreditMsgUtilService.displayByteArray(rqtMsg, "发送到农行信用卡渠道的报文数据");
			Log4jUtil.info("农行信用卡结算通知/联机签退SettleNotice报文socket通信->发送->返回->解析开始-->>");
			final MsgPack4Abc rspMsgPack4Abc = sendBySocket4Abc.sendAndRecv(socketIP.getParvalue(),
					socketPort.getParvalue(), rqtMsg);
			Log4jUtil.info("农行信用卡结算通知/联机签退SettleNotice报文socket通信->发送->返回->解析结束--<<");
			displayMsgPack4Abc(rspMsgPack4Abc);
		} catch (final BizException e) {
			if ("1234567".equals(e.getErrorCode())) {
				Log4jUtil.info("农行信用卡结算通知/联机签退报文执行中，发现签到返回参数不是当天，中断");
				throw new BizException("1234567", "签到返回参数的日期不是今天");
			}
		} catch (final Exception e) {
			final String logMsg = "农行信用卡结算通知/联机签退报文执行中，发现未知异常，中断" + e.getMessage();
			Log4jUtil.info(logMsg);
		}
	}

	private ReturnState createSuccessReturnState(final Param param, final MsgPack4Abc rspMsgPack4Abc,
			final MsgPack4Abc rqtMsgPack4Abc) throws BizException {
		final ReturnState returnState = new ReturnState();
		// 写渠道流水对照表(billno_sn)
		final BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, rqtMsgPack4Abc.getFieldContent11());

		Log4jUtil.info("===1");
		ChannelRtncode channelRtncode  = channelRtncodeService.findById(new ChannelRtncodeId(param.getChannelId(), rspMsgPack4Abc
				.getFieldContent39()));
		Log4jUtil.info("===2");
		returnState.setChannelCode(TransReturnCode.code_9109);
		if (null == channelRtncode) {
			returnState.setChannelCode(TransReturnCode.code_9900);
		} else {
			returnState.setChannelCode(channelRtncode.getKftRtncode());//
			// 快付通银行返回对照码
			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
			returnState.setBankPostScript(channelRtncode.getChannelReamrk());
		}
		Log4jUtil.info("===3");
		// 组returnState
		if ("00".equals(rspMsgPack4Abc.getFieldContent39())) {
			returnState.setReturnState(PayState.SUCCEED_STR);
		} else {
			returnState.setReturnState(PayState.FAILED_STR);
		}
		Log4jUtil.info("===4");
		returnState.setBankRetCode(rspMsgPack4Abc.getFieldContent39());
		returnState.setCreditNo(rspMsgPack4Abc.getFieldContent37());
		returnState.setSn(rspMsgPack4Abc.getFieldContent11());
		// returnState.setChannelCode("");上面
		returnState.setCardType(param.getCardType());
		returnState.setReturnObj(null);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		returnState.setRelTranAmount(billnoSn.getAmount());
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		Log4jUtil.info("===5");
		Log4jUtil.info("===6" + rqtMsgPack4Abc.getFieldContent62());
		billnoSnService.updateBillnoSn(param, returnState, billnoSn.getBillnosnSeq(),
				rqtMsgPack4Abc.getFieldContent62(), rqtMsgPack4Abc.getFieldContent14());
		Log4jUtil.info("===7");
		return returnState;
	}

	private ReturnState createFailedReturnState(final Param param, final MsgPack4Abc rspMsgPack4Abc,
			final MsgPack4Abc rqtMsgPack4Abc, final BizException bizE) throws BizException {
		final ReturnState returnState = new ReturnState();
		Log4jUtil.info("====aaaa==================");
		if (bizE != null) {
			Log4jUtil.info("====bbbb==================");
			returnState.setChannelCode(bizE.getErrorCode());
			Log4jUtil.info("====cccc==================");
			if (bizE.getErrorCode().equals(TransReturnCode.code_9108)
					|| bizE.getErrorCode().equals(TransReturnCode.code_9108)) {// socket发送报文出错,或渠道发送业务前处理出错
				Log4jUtil.info("====dddd==================");

				Log4jUtil.info("socket发送报文出错,或渠道发送业务前处理出错:bizE.getErrorCode=" + bizE.getErrorCode());
				Log4jUtil.info("====eeeeeeee==================");

				returnState.setChannelCode(TransReturnCode.code_9108);
				Log4jUtil.info("====fffffffffffffffffff==================");

				returnState.setReturnMsg(bizE.getMessage());
				Log4jUtil.info("====ggggggggggggggggggggggggggggg==================");
				returnState.setReturnState(PayState.FAILED_STR);
				// returnState.setReturnMsg(bankSendSn);
				return returnState;
			} else if (bizE.getErrorCode().equals(

			TransReturnCode.code_9109)) {// socket接收回执出错
				Log4jUtil.info("====else if hhhhhhhhhhhhhhhhhhhhhhhhhhhh==================");
				returnState.setChannelCode(TransReturnCode.code_9109);
			}
			Log4jUtil.info("====111111==================" + bizE.getErrorCode());
			final BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, rqtMsgPack4Abc.getFieldContent11());
			returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
			returnState.setReturnMsg(bizE.getMessage());
			returnState.setReturnState(PayState.SUCCEED_STR);
			returnState.setCheckDate(billnoSn.getCheckDate());
			returnState.setRelTranAmount(billnoSn.getAmount());
		} else {
			Log4jUtil.info("====22222===biz is null===============");
			returnState.setChannelCode(TransReturnCode.code_9109);
			final BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, rqtMsgPack4Abc.getFieldContent11());
			returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
			returnState.setReturnMsg("biz is null");
			returnState.setReturnState(PayState.SUCCEED_STR);
			returnState.setCheckDate(billnoSn.getCheckDate());
			returnState.setRelTranAmount(billnoSn.getAmount());
		}
		return returnState;
	}

	public void displayMsgPack4Abc(final MsgPack4Abc msgPack4Abc) {
		Log4jUtil.info("===Abc online sign in return Filed 2：" + msgPack4Abc.getFieldContent2());
		Log4jUtil.info("===Abc online sign in return Filed 3：" + msgPack4Abc.getFieldContent3());
		Log4jUtil.info("===Abc online sign in return Filed 4：" + msgPack4Abc.getFieldContent4());

		Log4jUtil.info("===Abc online sign in return Filed 11：" + msgPack4Abc.getFieldContent11());
		Log4jUtil.info("===Abc online sign in return Filed 12：" + msgPack4Abc.getFieldContent12());
		Log4jUtil.info("===Abc online sign in return Filed 13：" + msgPack4Abc.getFieldContent13());
		Log4jUtil.info("===Abc online sign in return Filed 14：" + msgPack4Abc.getFieldContent14());

		Log4jUtil.info("===Abc online sign in return Filed 22：" + msgPack4Abc.getFieldContent22());
		Log4jUtil.info("===Abc online sign in return Filed 24：" + msgPack4Abc.getFieldContent24());
		Log4jUtil.info("===Abc online sign in return Filed 25：" + msgPack4Abc.getFieldContent25());

		Log4jUtil.info("===Abc online sign in return Filed 37：" + msgPack4Abc.getFieldContent37());
		Log4jUtil.info("===Abc online sign in return Filed 38：" + msgPack4Abc.getFieldContent38());
		Log4jUtil.info("===Abc online sign in return Filed 39：" + msgPack4Abc.getFieldContent39());

		Log4jUtil.info("===Abc online sign in return Filed 41：" + msgPack4Abc.getFieldContent41());
		Log4jUtil.info("===Abc online sign in return Filed 42：" + msgPack4Abc.getFieldContent42());
		Log4jUtil.info("===Abc online sign in return Filed 44：" + msgPack4Abc.getFieldContent44());
		Log4jUtil.info("===Abc online sign in return Filed 48：" + msgPack4Abc.getFieldContent48());
		Log4jUtil.info("===Abc online sign in return Filed 49：" + msgPack4Abc.getFieldContent49());
		Log4jUtil.info("===Abc online sign in return Filed 54：" + msgPack4Abc.getFieldContent54());
		Log4jUtil.info("===Abc online sign in return Filed 55：" + msgPack4Abc.getFieldContent55());
		Log4jUtil.info("===Abc online sign in return Filed 57：" + msgPack4Abc.getFieldContent57());

		Log4jUtil.info("===Abc online sign in return Filed 60：" + msgPack4Abc.getFieldContent60());
		Log4jUtil.info("===Abc online sign in return Filed 61：" + msgPack4Abc.getFieldContent61());
		Log4jUtil.info("===Abc online sign in return Filed 62：" + msgPack4Abc.getFieldContent62());
		Log4jUtil.info("===Abc online sign in return Filed 63：" + msgPack4Abc.getFieldContent63());
		Log4jUtil.info("===Abc online sign in return Filed 64：" + msgPack4Abc.getFieldContent64());
	}

}
