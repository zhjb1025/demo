package com.lycheepay.clearing.adapter.banks.abc.corp.kft.processor;

import java.io.File;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BFJRepULRequest;
import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.app.common.dto.ErrorResultBFJ;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.AbcCorpBFJParm;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.CorpAbcC503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_1908Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_1944Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_1972Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_2287Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_7506Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_7528Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C100Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C327Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_CFRA33Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_CQLA35Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_CQLA36Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_1908;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_1944;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_1972;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_2287;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_7506;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_7528;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C100;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C101;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C113;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C327;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C503;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_CFRA33;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_CQLA35;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_CQLA36;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean.AbcSRResp;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean.BatchBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcCorpAccountProcess;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcCorpBatchRetDealService;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.AbcCorpBatchService;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.Erp2CTPublicService;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.ParseAbcXmlService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BankInfoService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCityCodeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.BFJUtil;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.GeneratorAccountDetailFile;
import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.common.constant.AccountTransType;
import com.lycheepay.clearing.common.constant.AccountType;
import com.lycheepay.clearing.common.constant.BFJConstant;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ReportStatus;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.AccountHistoryTransDetailDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.common.model.ReportUploadInfo;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行银企直连请求处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 上午11:21:07
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_DIRECT_PROCESS)
public class AbcCorpDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CITY_CODE_SERVICE)
	private ChannelCityCodeService channelCityCodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_INFO_SERVICE)
	private BankInfoService bankInfoService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ERP2_CT_PUBLIC_SERVICE)
	private Erp2CTPublicService erp2ctPublicService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.PARSE_ABC_XML_SERVICE)
	private ParseAbcXmlService parseAbcXmlService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	private ERP2CT_1908 eRP2CT_1908;
	@Autowired
	private ERP2CT_1944 eRP2CT_1944;
	@Autowired
	private ERP2CT_1972 eRP2CT_1972;
	@Autowired
	private ERP2CT_2287 eRP2CT_2287;
	@Autowired
	private ERP2CT_7506 eRP2CT_7506;
	@Autowired
	private ERP2CT_7528 eRP2CT_7528;
	@Autowired
	private ERP2CT_C100 eRP2CT_C100;
	@Autowired
	private ERP2CT_C101 eRP2CT_C101;
	@Autowired
	private ERP2CT_C113 eRP2CT_C113;
	@Autowired
	private ERP2CT_C327 eRP2CT_C327;
	@Autowired
	private ERP2CT_C503 eRP2CT_C503;
	@Autowired
	private ERP2CT_CFRA33 eRP2CT_CFRA33;
	@Autowired
	private ERP2CT_CQLA35 eRP2CT_CQLA35;
	@Autowired
	private ERP2CT_CQLA36 eRP2CT_CQLA36;

	@Autowired
	@Qualifier("corpAbcBatchRetDealService")
	private AbcCorpBatchRetDealService abcCorpBatchRetDealService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_BATCH_SERVICE)
	private AbcCorpBatchService corpAbcBatchService;

	private static String channelId = ChannelIdEnum.ABC_CORP.getCode();

	private static String line = System.getProperty("line.separator"); // 回车换行符
	String Log_Text; // 保存错误信息，用于保存日志

	/**
	 * <p>农业银行银企直连实时代收</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午4:08:12
	 */
	public ReturnState directDeduct(final Param param) throws BizException {
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		Log4jUtil.info("进入" + logPrefix + "渠道业务处理。");
		// 单笔代扣（对私）（7528、C326）
		if (AccountType.PERSONAL.equals(param.getBorc())) {
			return send7528(param);		// 对私
		} else if (AccountType.COMPANY.equals(param.getBorc())) {
			return sendC327(param);		// 对公
		} else {
			throw new BizException(TransReturnCode.code_9108, "错误的个人企业标志： 	1个人 2企业  3不分" + param.getBorc()
					+ "; 农行银企[单笔代扣]必须分对公；对私交易");
		}
	}

	/**
	 * <p>农业银行银企直连实时代付</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午4:43:04
	 */
	public ReturnState directPay(final Param param) throws BizException {
		Log4jUtil.info("进入农行银企直连directPay");
		// 对私实时代付
		// 费用报销（2287）
		if (AccountType.PERSONAL.equals(param.getBorc())) {
			return send2287(param);		// 对私
		} else if (AccountType.COMPANY.equals(param.getBorc())) {
			return send1908(param);		// 对公[ 汇兑（1908）]
		} else {
			throw new BizException(TransReturnCode.code_9108, "错误的个人企业标志： 	1个人 2企业  3不分" + param.getBorc()
					+ "; 农行银企[实时代付]必须分对公；对私交易");
		}
	}

	// @Override
	// public ReturnState batchDeduct(final Param param) {
	// String logMsg = "";
	// String logPrefix = "";
	// logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
	// logMsg = "进入" + logPrefix + "渠道业务处理。";
	// Log4jUtil.info(logMsg);
	// return processBatch(logPrefix, param);
	// }
	//
	// @Override
	// public ReturnState batchPay(final Param param) {
	// String logMsg = "";
	// String logPrefix = "";
	// logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
	// logMsg = "进入" + logPrefix + "渠道业务处理。";
	// Log4jUtil.info(logMsg);
	// return processBatch(logPrefix, param);
	// }
	//
	// @Override
	// public ReturnState singleQuery(final Param param) {
	// String logMsg = "";
	// String logPrefix = "";
	// logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
	// logMsg = "进入" + logPrefix + "渠道业务处理。";
	// Log4jUtil.info(logMsg);
	// // 查询金融交易处理状态（1944）
	// return send1944(param);
	// }
	//
	// /**
	// * <p>批量查询交易</p>
	// *
	// * @param param
	// * @return
	// * @author 邱林 Leon.Qiu 2012-6-15 下午8:45:33
	// */
	// @Override
	// public ReturnState batchQuery(final Param param) {
	// String logMsg = "";
	// String logPrefix = "";
	// logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
	// logMsg = "进入" + logPrefix + "渠道业务处理。";
	// Log4jUtil.info(logMsg);
	// // 查询工资处理结果（1972）
	// return send1972(param);
	// }

	/**
	 * 单笔查询;查询金融交易处理状态（1944）
	 * 
	 */
	public String send1944(final String bankSendSn) throws BizException {
		Log4jUtil.info("____发起单笔查询业务 1944_____");

		// 组1944报文数据

		// 商户自定义序列号
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		// 得到公共报头 bean 数据
		ERP2CT_PublicBean eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("1944", abcReqSeqNo);
		final ERP2CT_1944Bean eRP2CT_1944Bean = new ERP2CT_1944Bean();
		eRP2CT_1944Bean.setSerialNo(bankSendSn);
		// 组数据成功后，发送 1944 报文,同时取得返回的 1944 报文resultXml
		final String resultXml = eRP2CT_1944.sendXMLFile(eRP2CT_PublicBean, eRP2CT_1944Bean);
		// 解释1944报文
		String result = parseAbcXmlService.process1944RtnXml(resultXml);
		return result;
	}

	/**
	 * 生成 对私单笔代收报文，并发送出去
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	private ReturnState send7528(final Param param) {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String DbCur = channelParms.get("100017");
		String KftProv = channelParms.get("100008");
		String KftCur = channelParms.get("100009");
		String ConFlag = channelParms.get("100014");
		String CshDraFlag = channelParms.get("100022");
		String SpAccInd = channelParms.get("100023");
		String ExchangeType = channelParms.get("100024");
		String Postscript = channelParms.get("100025");

		Log4jUtil.info("____________________发起实时代扣业务 send7528____________________");
		String abcReqSeqNo = "";
		final ERP2CT_7528Bean eRP2CT_7528Bean = new ERP2CT_7528Bean();
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		String resultXml = "";
		BillnoSn billnoSn = new BillnoSn();
		ReturnState returnState = new ReturnState();
		DeductDTO deductTradeDTO;
		try {
			String OtherBankAddrNo = "";// 对方开户行地区代码
			String OtherAcctNo = "";// 对方开户行账号
			// 生成农行银企流水
			abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
																							// 商户自定义序列号
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("7528", abcReqSeqNo);
			// 组7528报文数据
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);

			deductTradeDTO = (DeductDTO) param.getBizBean();
			AssertUtils.notNull(deductTradeDTO, TransReturnCode.code_9108, "DirectDeductChannelDTO不能为空");

			OtherAcctNo = AbcCorpAccountProcess.proSingleAccount(deductTradeDTO.getBankCardNo());		// 付款方账号
			OtherBankAddrNo = AbcCorpAccountProcess.proSingleAddrNo(deductTradeDTO.getBankCardNo());	// 付款方省市代码,如果是存折，就截取前2位
			// OtherBankAddrNo = paybill.getPayerbankaddrno(); // 付款方省市代码
			// OtherBankAddrNo = channelCityCodeDao.findSnByChannel(channelId, OtherBankAddrNo);
			// if(OtherBankAddrNo==null){
			// OtherBankAddrNo="41";
			// }

			eRP2CT_7528Bean.setAmt(String.format("%1$.2f", deductTradeDTO.getAmount()));// 金额
			// String.format("%1$.2f",
			// paybill.getChannelAmount())
			eRP2CT_7528Bean.setDbAccNo(OtherAcctNo);	// 借方账号（卡号）（付方）

			eRP2CT_7528Bean.setDbProv(OtherBankAddrNo);		// 借方账号省市代码（付方）
			eRP2CT_7528Bean.setDbCur(DbCur);		// 借方账号货币码（付方）

			eRP2CT_7528Bean.setCrAccNo(bankaccountBalance.getAccountNo());// 贷方账号（收方）
			// eRP2CT_7528Bean.setCrAccNo("026900049999999");//贷方账号
			// eRP2CT_7528Bean.setCrAccNo(paybill.getPayerbankcardno());//贷方账号

			eRP2CT_7528Bean.setCrProv(KftProv); // 贷方账号省市代码
			eRP2CT_7528Bean.setCrCur(KftCur);		// 贷方账号货币码
			eRP2CT_7528Bean.setCrLogAccNo(""); 		// 贷方多级帐簿,不赋值
			eRP2CT_7528Bean.setConFlag(ConFlag);	// 合约校验标志
			eRP2CT_7528Bean.setDbAccName(deductTradeDTO.getCardHolderName());	// 借方户名
			// eRP2CT_7528Bean.setDbAccName("深圳市罗湖区清水河街道办事处"); //借方户名

			eRP2CT_7528Bean.setCrAccName(bankaccountBalance.getAccountName());	// 贷方户名
			// eRP2CT_7528Bean.setCrAccName ("深圳市罗湖区清水河街道办事处"); //贷方户名
			// eRP2CT_7528Bean.setCrAccName (paybill.getPayerbankcardname()); //贷方户名

			eRP2CT_7528Bean.setCshDraFlag(CshDraFlag);	// 钞汇标志
			eRP2CT_7528Bean.setSpAccInd(SpAccInd); // 借方户名校验标志
			eRP2CT_7528Bean.setExchangeType(ExchangeType);// 合约类型
			eRP2CT_7528Bean.setPostscript(Postscript);// 附言

			// 发送业务前，写渠道流水对照表
			billnoSn = saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 0);
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9108);
		}
		try {
			// 组数据成功后，发送 7528 报文,同时取得返回的 7528 报文resultXml
			resultXml = eRP2CT_7528.sendXMLFile(eRP2CT_PublicBean, eRP2CT_7528Bean);
			// Thread.currentThread().sleep(1000*180); // 超时测试,测试完删除
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}

		try {
			// 解释7528报文，写返回的bean ReturnState
			returnState = parseAbcXmlService.processRtnXml(resultXml);
			returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
			returnState.setSn(billnoSn.getSn());
			returnState.setRelTranAmount(deductTradeDTO.getAmount()); // 实际扣款金额
			// String.format("%1$.2f",
			// paybill.getChannelAmount())
			// 发送业务后，更新渠道流水对照表
			saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 1);
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 生成 对公单笔代收报文，并发送报文
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	private ReturnState sendC327(final Param param) {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String DbCur = channelParms.get("100017");
		String CrProv = channelParms.get("100019");
		String CrCur = channelParms.get("100020");
		String ConFlag = channelParms.get("100014");
		String CshDraFlag = channelParms.get("100022");
		String ExchangeType = channelParms.get("100024");
		String Postscript = channelParms.get("100025");
		Log4jUtil.info("____________________发起实时代扣业务（对公） sendC327____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_C327Bean eRP2CT_C327Bean = new ERP2CT_C327Bean();
		String OtherBankAddrNo = "";// 对方开户行地区代码
		DeductDTO directDeduct;
		BillnoSn billnoSn;
		ReturnState returnState = new ReturnState();
		String abcReqSeqNo = "";
		String resultXml = "";
		try {
			// 生成农行银企流水
			abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
																							// 商户自定义序列号
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("C327", abcReqSeqNo);
			// 组C327报文数据
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);

			directDeduct = (DeductDTO) param.getBizBean();
			AssertUtils.notNull(directDeduct, TransReturnCode.code_9108, "DirectDeductChannelDTO不能为空");

			eRP2CT_C327Bean.setAmt(String.format("%1$.2f", directDeduct.getAmount()));// 金额
			eRP2CT_C327Bean.setDbAccNo(directDeduct.getBankCardNo());	// 借方账号（卡号）

			OtherBankAddrNo = directDeduct.getBankAreaCode();// 付款方省市代码
			OtherBankAddrNo = channelCityCodeService.findSnByChannel(channelId, OtherBankAddrNo);
			if (OtherBankAddrNo == null) {
				OtherBankAddrNo = "41";
			}
			eRP2CT_C327Bean.setDbProv(OtherBankAddrNo);	// 借方账号省市代码

			eRP2CT_C327Bean.setDbCur(DbCur);	// 借方账号货币码
			eRP2CT_C327Bean.setCrAccNo(bankaccountBalance.getAccountNo());// 贷方账号
			eRP2CT_C327Bean.setCrProv(CrProv); // 贷方账号省市代码
			eRP2CT_C327Bean.setCrCur(CrCur);		// 贷方账号货币码
			eRP2CT_C327Bean.setCrLogAccNo(""); 		// 贷方多级帐簿,不赋值
			eRP2CT_C327Bean.setConFlag(ConFlag);	// 合约校验标志
			eRP2CT_C327Bean.setDbAccName(directDeduct.getCardHolderName());	// 借方户名
			eRP2CT_C327Bean.setCrAccName(bankaccountBalance.getAccountName());	// 贷方户名
			eRP2CT_C327Bean.setCshDraFlag(CshDraFlag);	// 钞汇标志
			eRP2CT_C327Bean.setExchangeType(ExchangeType);// 合约类型
			eRP2CT_C327Bean.setPostscript(Postscript);// 附言

			// 发送业务前，写渠道流水对照表
			billnoSn = saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 0);

		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9108);
		}
		try {
			// 组数据成功后，发送 C327 报文,同时取得返回的 C327 报文resultXml
			resultXml = eRP2CT_C327.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C327Bean);
		} catch (final BizException e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(), e.getErrorCode());
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		try {
			returnState = parseAbcXmlService.processRtnXml(resultXml);
			returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
			returnState.setSn(billnoSn.getSn());
			returnState.setRelTranAmount(directDeduct.getAmount()); // 实际扣款金额
			// 发送业务后，更新渠道流水对照表
			saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 1);
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 生成 单笔代付(对私)报文，并发送出去[费用报销（2287）]
	 * 
	 */
	private ReturnState send2287(final Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String CrCur = channelParms.get("100020");
		String KftProv = channelParms.get("100008");
		String KftCur = channelParms.get("100009");

		Log4jUtil.info("____________________发起实时代付业务（对私） 2287____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_2287Bean eRP2CT_2287Bean = new ERP2CT_2287Bean();
		// 生成农行银企流水
		String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		BillnoSn billnoSn;
		ReturnState returnState = new ReturnState();

		String resultXml = "";
		BigDecimal DTranAmt = BigDecimal.ZERO; // 订单金额
		try {
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("2287", abcReqSeqNo);
			// 组2287报文数据

			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
			String CorpAcctNo = bankaccountBalance.getAccountNo();	// 企业帐号--对应渠道绑定的帐号
			String CorpAcctName = bankaccountBalance.getAccountName();// 企业帐号名--对应渠道绑定的帐号名
			PayOutDTO pay = (PayOutDTO) param.getBizBean();
			DTranAmt = pay.getAmount();
			String OtherAcctNo = pay.getBankCardNo();
			// OtherBankAddrNo=paybill.getPayeebankaddrno();
			// // 把平台代码转换成银行省市代码
			// OtherBankAddrNo=channelCityCodeDao.findSnByChannel(channelId, OtherBankAddrNo);

			eRP2CT_2287Bean.setAmt(DTranAmt.toString());// 金额
			eRP2CT_2287Bean.setBookingDate("");// 预约日期
			eRP2CT_2287Bean.setBookingTime("");// 预约时间
			eRP2CT_2287Bean.setBookingFlag("0");// 0-不预约 1-预约
			// eRP2CT_2287Bean.setBookingFlag("");//0-不预约 1-预约
			eRP2CT_2287Bean.setPostscript("");// 附言

			eRP2CT_2287Bean.setCrActCode("0000"); // #固定值 0000
			eRP2CT_2287Bean.setCshDraFlag("1");// #0 - 钞 1 - 汇
			eRP2CT_2287Bean.setVoucherType("0");  // # 固定值 0
			eRP2CT_2287Bean.setVoucherNo("0");  // # 固定值 0
			// eRP2CT_2287Bean.setCrActCode(""); // #固定值 0000
			// eRP2CT_2287Bean.setCshDraFlag("");// #0 - 钞 1 - 汇
			// eRP2CT_2287Bean.setVoucherType(""); //# 固定值 0
			// eRP2CT_2287Bean.setVoucherNo(""); //# 固定值 0

			// eRP2CT_2287Bean.setAgtDbInd(AgtDbInd); //参数表 0-否1-是
			// eRP2CT_2287Bean.setAgtDbProv(KftProv); //内部省市代码
			// eRP2CT_2287Bean.setAgtDbAccNo(CorpAcctNo);//内部账号
			// eRP2CT_2287Bean.setAgtDbCur(KftCur); //内部货币码
			// eRP2CT_2287Bean.setAgtDbName(CorpAcctName); //内部户名
			eRP2CT_2287Bean.setAgtDbInd("");  // 参数表 0-否1-是
			eRP2CT_2287Bean.setAgtDbProv("");  // 内部省市代码
			eRP2CT_2287Bean.setAgtDbAccNo("");// 内部账号
			eRP2CT_2287Bean.setAgtDbCur("");  	// 内部货币码
			eRP2CT_2287Bean.setAgtDbName("");  // 内部户名

			eRP2CT_2287Bean.setPostscriptRes("");	// 附言预留
			eRP2CT_2287Bean.setDbAccNo(CorpAcctNo);	// 借方账号
			eRP2CT_2287Bean.setDbProv(KftProv);		// 借方省市代码
			// eRP2CT_2287Bean.setDbAccNo("621801040002867"); //借方账号
			// eRP2CT_2287Bean.setDbProv("15"); //借方省市代码
			eRP2CT_2287Bean.setDbCur(KftCur);		// 借方货币号
			// eRP2CT_2287Bean.setDbLogAccNo(DbLogAccNo);//参数表
			eRP2CT_2287Bean.setDbLogAccNo("");// 参数表
			// ===========================
			// eRP2CT_2287Bean.setPostscriptRes(""); //附言预留
			// eRP2CT_2287Bean.setDbAccNo(""); //借方账号
			// eRP2CT_2287Bean.setDbProv(""); //借方省市代码
			// eRP2CT_2287Bean.setDbCur(""); //借方货币号
			// // eRP2CT_2287Bean.setDbLogAccNo(DbLogAccNo);//参数表
			// eRP2CT_2287Bean.setDbLogAccNo("");//参数表

			eRP2CT_2287Bean.setCrAccName(pay.getCardHolderName());//
			eRP2CT_2287Bean.setCrBankName("");//

			String OtherBankAddrNo = AbcCorpAccountProcess.proSingleAddrNo(OtherAcctNo);	// 对方账号省市代码
			OtherAcctNo = AbcCorpAccountProcess.proSingleAccount(OtherAcctNo);		// 对方账号

			// eRP2CT_2287Bean.setCrAccNo("41003600460011590"); //贷方账号
			// if(OtherBankAddrNo==null){
			// OtherBankAddrNo="41";
			// }
			eRP2CT_2287Bean.setCrAccNo(OtherAcctNo);	// 贷方账号（收方）
			eRP2CT_2287Bean.setCrProv(OtherBankAddrNo);	// 贷方省市代码（收方）
			// eRP2CT_2287Bean.setCrProv(""); //贷方省市代码(刘工说这个不用填)
			eRP2CT_2287Bean.setCrCur(CrCur);		// 贷方货币号
			eRP2CT_2287Bean.setConFlag("1"); // 贷方户名校验标志 0-否1-是

			// 发送业务前，写渠道流水对照表
			billnoSn = saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 0);
		} catch (final Exception e) {
			Log4jUtil.error("e1", e);
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9108);
		}

		try {
			// 组数据成功后，发送 2287 报文,同时取得返回的 2287 报文resultXml
			resultXml = eRP2CT_2287.sendXMLFile(eRP2CT_PublicBean, eRP2CT_2287Bean);
		} catch (final BizException e) {
			Log4jUtil.error("e2", e);
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(), e.getErrorCode());
		} catch (final Exception e) {
			Log4jUtil.error("e3", e);
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		try {
			// 解释2287报文，写返回的bean ReturnState
			returnState = parseAbcXmlService.processRtnXml(resultXml);
			returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
			returnState.setSn(billnoSn.getSn());
			returnState.setRelTranAmount(DTranAmt); // 实际扣款金额
			process9999Error(abcReqSeqNo, returnState);

			// 发送业务后，更新渠道流水对照表
			saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 1);
		} catch (final Exception e) {
			Log4jUtil.error("e4", e);
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 农行9999errorcode要发送查询获取真实结果
	 * 
	 * @param returnState
	 * @author 张凯锋
	 * @throws BizException
	 */
	private void process9999Error(String abcReqSeqNo, ReturnState returnState) {
		if ("9999".equals(returnState.getBankRetCode())) {
			try {
				Thread.sleep(3000);// 出现9999错误可能是网络问题，所以3s后发查询
				String result = send1944(abcReqSeqNo);
				if (PayState.SUCCEED_STR.equals(result)) {
					Log4jUtil.info("查询交易状态结果S");
					returnState.setChannelCode(TransReturnCode.code_0000);
					returnState.setBankRetCode("0000");// 银行返回代码
					returnState.setReturnState(PayState.SUCCEED_STR);
					returnState.setReturnMsg("交易成功");// 返回信息
					returnState.setBankPostScript("交易成功");// 返回扩展信息
				} else if (PayState.FAILED_STR.equals(result)) {
					Log4jUtil.info("查询交易状态结果F");
					returnState.setChannelCode(TransReturnCode.code_9900);
					returnState.setReturnState(PayState.FAILED_STR);
					returnState.setReturnMsg("交易失败");// 返回信息
					returnState.setBankPostScript("交易失败");// 返回扩展信息
				} else {
					Log4jUtil.info("查询交易状态结果未知");
				}
			} catch (Exception e) {
				Log4jUtil.error(e);
			}
		}
	}

	/**
	 * 生成 单笔代付(对公)报文[汇兑（1908）]，并发送出去
	 * 
	 */
	private ReturnState send1908(final Param param) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String DbProv = channelParms.get("100016");
		String DbCur = channelParms.get("100017");
		String CrCur = channelParms.get("100020");
		String ConFlag = channelParms.get("100014");
		String ExchangeType = channelParms.get("100024");
		String Postscript = channelParms.get("100025");
		String DbLogAccNo = channelParms.get("100028");
		String ActInf = channelParms.get("100034");
		String UrgencyFlag = channelParms.get("100035");
		Log4jUtil.info("____________________发起实时代付业务（对公） 1908____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_1908Bean eRP2CT_1908Bean = new ERP2CT_1908Bean();
		String abcReqSeqNo = "";
		BigDecimal DTranAmt = BigDecimal.ZERO;
		BillnoSn billnoSn;
		ReturnState returnState = new ReturnState();
		String resultXml = "";
		try {
			// 生成农行银企流水
			abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
																							// 商户自定义序列号
			// 得到公共报头 bean 数据
			eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("1908", abcReqSeqNo);
			// 组1908报文数据

			String OtherAcctNo; 	// 收款方账号
			String OtherAcctName; 	// 收款方户名
			String OtherBankNo; 	// 收款方行号
			String OtherBankName; 	// 收款方行名
			String BankType = "";	// 行别
			String bankName = "";		// 付款行行名
			String CustId = "";		// 客户ID
			final String CustAddress = "";		// 客户地址
			PayOutDTO pay = new PayOutDTO();
			pay = (PayOutDTO) param.getBizBean();
			DTranAmt = pay.getAmount();
			OtherAcctNo = pay.getBankCardNo();
			OtherAcctName = pay.getCardHolderName();
			OtherBankName = pay.getBankName();
			OtherBankNo = pay.getBankCode();
			BankType = pay.getBankType();
			CustId = pay.getAccountId();
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
			bankName = bankInfoService.getByAgencyNo(bankaccountBalance.getBankNo()).getAgencyName();

			// CustInfo custInfo = (CustInfo)custInfoDao.findById(CustId);
			// CustInfo custInfo = (CustInfo)custInfoDao.findById(id)
			// CustAddress = custInfo.getAddress();

			eRP2CT_1908Bean.setAmt(DTranAmt.toString());// 金额

			eRP2CT_1908Bean.setDbAccNo(bankaccountBalance.getAccountNo());// 借方帐号
			eRP2CT_1908Bean.setDbProv(DbProv);// 借方省市代码
			eRP2CT_1908Bean.setDbCur(DbCur);// 借方货币码
			eRP2CT_1908Bean.setDbLogAccNo(DbLogAccNo);// 二级帐簿

			eRP2CT_1908Bean.setCrAccNo(OtherAcctNo);// 贷方帐号
			eRP2CT_1908Bean.setCrProv("CrProv"); // 贷方省市代码 TODO 如果不是深圳，则要调用者提供
			eRP2CT_1908Bean.setCrCur(CrCur); // 贷方货币号
			eRP2CT_1908Bean.setCrLogAccNo(""); // 贷方二级帐簿,不赋值
			eRP2CT_1908Bean.setConFlag(ConFlag);// 贷方户名校验标志

			eRP2CT_1908Bean.setBookingDate("");// 预约日期
			eRP2CT_1908Bean.setBookingTime("");// 预约时间
			eRP2CT_1908Bean.setBookingFlag("0");// 不预约 1-预约

			eRP2CT_1908Bean.setExchangeType(ExchangeType); // 汇兑类型
			eRP2CT_1908Bean.setPostscript(Postscript);// 附言
			eRP2CT_1908Bean.setUrgencyFlag(UrgencyFlag);  // # 加急标志；0-不加急 1-加急

			// 农行他行标志：0农行；1他行(要求调用者提供)
			if (BankType.equals("1031000")) {
				eRP2CT_1908Bean.setOthBankFlag("0");  // 农行他行标志：0农行；1他行
			} else {
				eRP2CT_1908Bean.setOthBankFlag("1");  // 农行他行标志：0农行；1他行
			}
			eRP2CT_1908Bean.setOthCenterFlag("1");// 它中心标志（0异地；1同城）

			eRP2CT_1908Bean.setCrAccName(OtherAcctName);// 贷方户名
			eRP2CT_1908Bean.setCrBankName(OtherBankName);  // 贷方开户行行名
			eRP2CT_1908Bean.setCrBankNo(OtherBankNo);// 贷方行号

			eRP2CT_1908Bean.setDbBankName(bankName);	// 借方开户行行名 平台取行名，要关联行号表,待写
			eRP2CT_1908Bean.setDbAccName(bankaccountBalance.getAccountName());// 借方户名
			eRP2CT_1908Bean.setDbAddress("深圳市罗湖区清水河街道办事处");// TODO 怎么得到付款方地址（快付通地址）

			eRP2CT_1908Bean.setCrAddress(CustAddress);  // 收款方地址
			eRP2CT_1908Bean.setWhyUse("购买基金");  // 用途，可不赋值

			eRP2CT_1908Bean.setActInf(ActInf); // 到帐通知标志 0-不通知

			// 发送业务前，写渠道流水对照表
			billnoSn = saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 0);
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9108);
		}
		try {
			// 组数据成功后，发送 1908 报文,同时取得返回的 1908 报文resultXml
			resultXml = eRP2CT_1908.sendXMLFile(eRP2CT_PublicBean, eRP2CT_1908Bean);
		} catch (final BizException e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(), e.getErrorCode());
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		try {
			returnState = parseAbcXmlService.processRtnXml(resultXml);
			returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
			returnState.setSn(billnoSn.getSn());
			returnState.setRelTranAmount(DTranAmt); // 实际扣款金额

			// 发送业务后，更新渠道流水对照表
			saveOrUpdateBillnoSn(abcReqSeqNo, param, returnState, 1);
		} catch (final Exception e) {
			return channelTransUtilService.makeReturnState(channelId, abcReqSeqNo, e.getMessage(),
					TransReturnCode.code_9109);
		}
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 企业操作员签到（C100）
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState sendC100(final Param param) throws BizException {
		Log4jUtil.info("____________________发起操作员签到交易 C100____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_C100Bean eRP2CT_C100Bean = new ERP2CT_C100Bean();

		// 生成农行银企流水
		// String abcReqSeqNo = "abcC100_" + DateUtil.getDate(new Date()) +
		// pay_SequenceDao.nextVal("ABC_SN",12).toString(); //农行银企流水 商户自定义序列号
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		// 商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("C100", abcReqSeqNo);

		// 组C100报文数据
		// 获取 原交易ERP请求流水号 serialNo
		eRP2CT_C100Bean.setMsgPort("");
		eRP2CT_C100Bean.setOpNewPwd("");
		eRP2CT_C100Bean.setOpPwd("88888888");

		// 组数据成功后，发送 C100 报文,同时取得返回的 C100 报文resultXml
		final String resultXml = eRP2CT_C100.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C100Bean);
		// 解释C100报文，写返回的bean ReturnState
		ReturnState returnState = parseAbcXmlService.processC100RtnXml(resultXml);
		// returnState.setRelTranAmount(Double.parseDouble(amount)); //实际扣款金额
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 企业操作员签退（C101）
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState sendC101(final Param param) throws BizException {
		Log4jUtil.info("____________________发起操作员签退交易 C101____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();

		// 生成农行银企流水
		// String abcReqSeqNo = "abcC101_" + DateUtil.getDate(new Date()) +
		// pay_SequenceDao.nextVal("ABC_SN",12).toString(); //农行银企流水 商户自定义序列号
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		// 商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("C101", abcReqSeqNo);

		// 组数据成功后，发送 C101 报文,同时取得返回的 C101 报文resultXml
		final String resultXml = eRP2CT_C101.sendXMLFile(eRP2CT_PublicBean);
		// 解释C101报文，写返回的bean ReturnState
		ReturnState returnState = parseAbcXmlService.processRtnXml(resultXml);
		// returnState.setRelTranAmount(Double.parseDouble(amount)); //实际扣款金额
		// 组返回结果，并返回给调用者
		return returnState;
	}

	// ////////////////////////////////////////////////////////////////
	/**
	 * 查询帐户信息（C113）
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState sendC113(final Param param) throws BizException {
		Log4jUtil.info("____________________发起查询帐户信息 C113____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();

		// 生成农行银企流水
		// String abcReqSeqNo = "abcC113_" + DateUtil.getDate(new Date()) +
		// pay_SequenceDao.nextVal("ABC_SN",12).toString(); //农行银企流水 商户自定义序列号
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		// 商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("C113", abcReqSeqNo);

		// 组数据成功后，发送 C113 报文,同时取得返回的 C113 报文resultXml
		final String resultXml = eRP2CT_C113.sendXMLFile(eRP2CT_PublicBean);
		// 解释C113报文，写返回的bean ReturnState
		ReturnState returnState = parseAbcXmlService.processRtnXml(resultXml);
		// returnState.setRelTranAmount(Double.parseDouble(amount)); //实际扣款金额
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 查询单帐户余额（7506）
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public Balance send7506(String accountNo) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String KftProv = channelParms.get("100008");
		String KftCur = channelParms.get("100009");

		Log4jUtil.info("____________________发起查询单帐户余额交易 7506____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_7506Bean eRP2CT_7506Bean = new ERP2CT_7506Bean();

		// 生成农行银企流水
		// String abcReqSeqNo = "abc7506_" + DateUtil.getDate(new Date()) +
		// pay_SequenceDao.nextVal("ABC_SN",12).toString(); //农行银企流水 商户自定义序列号
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		// 商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("7506", abcReqSeqNo);

		// 组7506报文数据
		String qAccount = accountNo;
		if (StringUtils.isBlank(accountNo)) {
			BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
			qAccount = bankaccountBalance.getAccountNo();
		}
//		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		eRP2CT_7506Bean.setDbAccNo(qAccount);// 账号
		eRP2CT_7506Bean.setDbProv(KftProv); // 省市代码
		eRP2CT_7506Bean.setDbCur(KftCur);// 货币号

		// 组数据成功后，发送 7506 报文,同时取得返回的 7506 报文resultXml
		final String resultXml = eRP2CT_7506.sendXMLFile(eRP2CT_PublicBean, eRP2CT_7506Bean);
		// 解释7506报文，写返回的bean ReturnState
		Balance balance = parseAbcXmlService.process7506RtnXml(resultXml);
		// returnState.setRelTranAmount(Double.parseDouble(amount)); //实际扣款金额
		// 组返回结果，并返回给调用者
		return balance;
	}

	/**
	 * 保存或更新单笔交易记录到billno_sn表
	 * 
	 * @param abcReqSeqNo 银行订单号
	 * @param billnoSn 业务表对象
	 * @param param 交易参数
	 * @param returnState 返回状态 bean
	 * @param tag 保存更新标志 0保存记录 ； 1更新记录
	 * @throws BizException
	 */
	private BillnoSn saveOrUpdateBillnoSn(final String abcReqSeqNo, final Param param, final ReturnState returnState,
			final int tag) throws BizException {
		Log4jUtil.info("____________________新增或更新单笔交易记录到billno_sn表 saveOrUpdateBillnoSn 9.6____________________");
		BillnoSn billnoSn = new BillnoSn();
		if (tag == 0) { // 业务发送到银行前，保存记录到 billno_sn 表
			billnoSn = billnoSnService.saveBillnoSn(abcReqSeqNo, param);
		} else if (tag == 1) { // 业务发送成功后更新 billno_sn 表
			billnoSnService.updateBillnoSn(param, returnState, abcReqSeqNo);
		}
		Log4jUtil.info(line + "新增或更新单笔交易记录到billno_sn表完成");
		return billnoSn;
	}

	/**
	 * 批量查询;批量代收代付都可以查;查询工资处理结果（1972）
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	private ReturnState send1972(String channelBatchId) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ftpServer = channelParms.get("100029");
		String ftpPassword = channelParms.get("100030");
		String ftpUser = channelParms.get("100031");
		String abcRecvFile = channelParms.get("100033");
		Log4jUtil.info("____________________发起批量查询业务 1972____________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_1972Bean eRP2CT_1972Bean = new ERP2CT_1972Bean();

		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水,商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("1972", abcReqSeqNo);

		// 组1972报文数据
		// 获取 原交易ERP请求流水号(#原代发工资交易的请求号)
		eRP2CT_1972Bean.setCustomNo(channelBatchId);

		// 组数据成功后，发送 1972 报文,同时取得返回的 1972 报文resultXml
		String result1972Xml = eRP2CT_1972.sendXMLFile(eRP2CT_PublicBean, eRP2CT_1972Bean);
		// 解释1972报文，写返回的bean ReturnState
		ReturnState returnState = new ReturnState();
		returnState = parseAbcXmlService.process1972RtnXml(result1972Xml);

		if (returnState.getBankPostScript().equals("file")) {// 如果有返回文件
			final String batchFileName = (String) returnState.getReturnObj();
			// 1、如果返回文件，用FTP方式，取得CT服务器的文件
			final FtpManager ftpManager = new FtpManager();
			ftpManager.setServer(ftpServer);
			ftpManager.setPassword(ftpPassword);
			ftpManager.setUser(ftpUser);
			ftpManager.setFilename(batchFileName);
			// 如果文件夹不存在，创建文件夹
			if (FileProcess.createDir(abcRecvFile) == false) {
				throw new BizException(TransReturnCode.code_9109, "创建文件夹【" + abcRecvFile + "】 出错！！");
			}
			ftpManager.setLocalPath(abcRecvFile); // 下载到本地的文件夹
			ftpManager.setPath(""); // 远程目录，FTP用户的远程目录默认就是CT服务器存文件的目录
			ftpManager.getMyFile_actionPerformed();
			Log4jUtil.info("农行银企批量报文:" + batchFileName + "已下载到本地");

			final String trancode = returnState.getSn(); // 农行银企交易代码：代理收款（C410）或 代发工资（C405）
			// if(trancode.equals("C410")){ // 批量代付有多种 。。。。 所以不可以这样设置
			// tranType = TransType.Protocol_Debit_Batch;
			// } else if(trancode.equals("C405")){
			// tranType = TransType.Protocol_Debit_Batch; // 批量代付有多种 。。。。 所以不可以这样设置
			// }
			final String fullFileName = abcRecvFile + File.separator + batchFileName;
			Log4jUtil.info("1972 返回的文件（含相对路径）为：  " + fullFileName);
			// 用事务处理批量返回数据
			abcCorpBatchRetDealService.predeal(channelBatchId, fullFileName, returnState.getCheckDate());
			Log4jUtil.info("corpAbcBatchRetDealService.predeal()处理批量返回数据完成");
		}

		// returnState.setRelTranAmount(Double.parseDouble(amount)); //实际扣款金额
		// 组返回结果，并返回给调用者
		return returnState;
	}

	/**
	 * 【农行银企批量交易结果处理】 -- 批量交易结果数据下载,并更新批量交易记录
	 * 
	 * @throws BizException
	 */
	public void batchRetProcess() throws BizException {
		Log4jUtil.info("____________________农行银企批量交易结果处理 batchRetProcess 9.6____________________");
		// 1、查出未对账的批量交易的批次号list（条件是渠道ID;channelBatch.setState不等于03）
		// channelBatch.setState("03"); // 03：回执全部返回 取
		// customNo = (String)param.getBizBean();

		List<String> batchIdList = channelBatchService.getCorpBatchIdList(channelId);
		Log4jUtil.info(line + "农行银企要查询的批理业务交易结果的批次号start");
		for (int i = 0; i < batchIdList.size(); i++) {
			Log4jUtil.info(line + "批次号 " + (i + 1) + " : " + batchIdList.get(i));
		}
		Log4jUtil.info(line + "农行银企要查询的批理业务交易结果的批次号end");

		// 2、根据批量交易的批次号list，做批量交易结果 处理
		Log4jUtil.info(line + "农行银企批理交易结果处理开始");
		for (int i = 0; i < batchIdList.size(); i++) {
			this.send1972(batchIdList.get(i));
		}
		Log4jUtil.info(line + "农行银企批理交易结果处理完成");
	}

	/**
	 * 批量交易；批量重发交易
	 * 
	 * @param repeatSend
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	public BatchSendResult processBatch(final List<ChannelTempBill> payList, final boolean repeatSend)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.info("____________________发起批量交易 batchDistributeSend 9.6____________________");
		final BatchBean batchBean = corpAbcBatchService.sendBatch(payList);
		// 更新交易结果 2012年6月28日17:25:34挪到公共方法中处理
		// corpAbcBatchService.updateBatchSend(batchBean.getTrantype(),batchBean.getTotalReqSeqNo(),batchBean.getReturnState());
		BatchSendResult batchSendResult = new BatchSendResult();
		batchSendResult.setBankReturnCode(batchBean.getReturnState().getBankRetCode());
		batchSendResult.setBankReturnMsg(batchBean.getReturnState().getReturnMsg());
		batchSendResult.setStatus(batchBean.getReturnState().getReturnState());
		return batchSendResult;

	}

	public String queryAccountHistoryTransDetail(String date, String accountNo, String filePath) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String dbCur = channelParms.get("100017");
		String crProv = channelParms.get("100019");
		Log4jUtil.info("账户历史明细查询");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_C503Bean eRP2CT_C503Bean = new ERP2CT_C503Bean();

		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水,商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic("C503", abcReqSeqNo);
		if (StringUtils.isNotBlank(accountNo)) {
			eRP2CT_C503Bean.setDbAccNo(accountNo);
		} else {
			final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
			eRP2CT_C503Bean.setDbAccNo(bankaccountBalance.getAccountNo());
		}
		eRP2CT_C503Bean.setDbProv(crProv);
		eRP2CT_C503Bean.setStartDate(date);
		eRP2CT_C503Bean.setEndDate(date);
		eRP2CT_C503Bean.setDbCur(dbCur);
		eRP2CT_C503Bean.setLastJrnNo("");
		eRP2CT_C503Bean.setStartTime("");

		String result1972Xml = eRP2CT_C503.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C503Bean);

		Map<String, List> map = parseAbcXmlService.processRecvC503Xml(result1972Xml);
		List<CorpAbcC503Bean> corpAbcC503BeanList = map.get("corpAbcC503BeanList");
		List<AccountHistoryTransDetailDTO> list = new ArrayList<AccountHistoryTransDetailDTO>();
		for (int i = 0; i < corpAbcC503BeanList.size(); i++) {
			CorpAbcC503Bean c503Bean = corpAbcC503BeanList.get(i);
			AccountHistoryTransDetailDTO detailDTO = new AccountHistoryTransDetailDTO();
			detailDTO.setAccName1(c503Bean.getOppName());
			detailDTO.setAccNo1(c503Bean.getOppAccNo());
			detailDTO.setAmount(StringUtils.replaceOnce(c503Bean.getAmt(), "-", ""));
			detailDTO.setBalance(c503Bean.getBal());
			detailDTO.setCreditNo(c503Bean.getVoucherNo());
			detailDTO.setCreditType(c503Bean.getVoucherType());
			if (new BigDecimal(c503Bean.getAmt()).compareTo(BigDecimal.ZERO) == -1) {
				if("4".equals(c503Bean.getAmtIndex())){//发生额标志, 0:正常, 1:红字, 2:蓝字, 3:已抹, 4:抹帐
					detailDTO.setdORc(GeneratorAccountDetailFile.GET);
				}else{
					detailDTO.setdORc(GeneratorAccountDetailFile.PAY);
				}
			} else if (new BigDecimal(c503Bean.getAmt()).compareTo(BigDecimal.ZERO) == 1) {
				detailDTO.setdORc(GeneratorAccountDetailFile.GET);
			}
			detailDTO.setIndividual1(c503Bean.getAbs());
			detailDTO.setIndividual2(c503Bean.getCmt());
			detailDTO.setPaySeqNum(c503Bean.getCustRef());
			detailDTO.setTranDate(c503Bean.getTrDate());
			detailDTO.setTranTime(StringUtils.substring(c503Bean.getTimeStab(), 8, 14));
			if ("B867".equalsIgnoreCase(c503Bean.getAbs()) || "充保证金".equals(c503Bean.getCmt())) {
				detailDTO.setType(AccountTransType.batch_trans.getCode());
			} else if (StringUtils.isNotBlank(detailDTO.getPaySeqNum()) || "B866".equalsIgnoreCase(c503Bean.getAbs())) {
				detailDTO.setType(AccountTransType.single_trans.getCode());
			} else if (StringUtils.isBlank(detailDTO.getAccName1())
					&& StringUtils.indexOf(c503Bean.getCmt(), "服务费") != -1) {
				detailDTO.setType(AccountTransType.fee.getCode());
			} else if (StringUtils.isBlank(detailDTO.getAccName1()) && StringUtils.isBlank(detailDTO.getAccNo1())
					&& "1045".equals(c503Bean.getAbs())) {
				detailDTO.setType(AccountTransType.iint.getCode());
			} else {
				if (bankAccountBalanceService.selectAllSettlementAccountNo().containsKey(detailDTO.getAccNo1())) {
					detailDTO.setType(AccountTransType.zjdb.getCode());
				} else {
					detailDTO.setType(AccountTransType.others.getCode());
				}
			}
			list.add(detailDTO);
		}
		GeneratorAccountDetailFile.createReconciliationFile(filePath, eRP2CT_C503Bean.getDbAccNo(), date, list);
		return "S";
	}
	
	
	/**
	 * <p>验证备付金报表上报时间合法性</p>
	 * @param reportDate 报表日期 YYYYMMDD
	 * @throws BizException 
	 */
	public void verifyBFJReportUploadDate(String reportDate) throws BizException{
//		if(BFJUtil.getIntervalDays(reportDate) > AbcCorpBFJParm.REPORT_LATEST_UPLOAD_DAYS_PER_MONTH){ //每个月5号前必须上传上个月的报表(35天内)
//			final String errorMessage = "报表日期不合法,只能操作" + AbcCorpBFJParm.REPORT_LATEST_UPLOAD_DAYS_PER_MONTH + "天内的数据";
//			throw new BizException(errorMessage);
//		}
		//人行报表最晚上报时限检查
		int theLastDate = 0;
		int currentDate = Integer.parseInt(DateUtil.getCurrentDate());
		try {
			theLastDate = Integer.parseInt(BFJUtil.getNextMonthSpecifiedDate(DateUtil.getDate(reportDate,"yyyyMMdd"),  
					AbcCorpBFJParm.REPORT_LATEST_UPLOAD_DAYS_PER_MONTH));	//最迟上报时间为每个月的5号
		} catch (ParseException e) {
			Log4jUtil.error(e);
			throw new BizException("报表日期格式不正确,解析异常");
		}
		if(currentDate > theLastDate){
			String errorMessage = "请求拒绝,已超过农行报表最晚上报时限,每月" + AbcCorpBFJParm.REPORT_LATEST_UPLOAD_DAYS_PER_MONTH + "号前需上报上月数据";
			throw new BizException(errorMessage);
		}
	}
	
	public void uploadBFJReport(BFJRepULRequest req, ReportUploadInfo info) throws BizException {
		AbcSRResp resp = settleReportUploadNotice(req.getReportDate(), req.getFileName(), req.getFilePath(), req.getRows());
		if("0000".equals(resp.getRespCode())){
			Log4jUtil.info("上送报表文件成功");
			info.setStatus(ReportStatus.UPLOAD_SUCCESS);
			info.setBankSendSn(resp.getBankSendSn());
		}else{
			String errorMessage = "上送报表文件失败,原因: " + resp.getRespInfo() +" " + resp.getRxtInfo();
			Log4jUtil.error(errorMessage);
			throw new BizException(errorMessage);
		}
	}
	
	/**
	 * <p>上传人行监管报表(CFRA33)</p>
	 * @param serialDate 报表日期 YYYYMMDD
	 * @param fileName 文件名(不带路径)
	 * @param rows 文件行数(整数)
	 * @return
	 * @throws BizException 
	 * @throws InterruptedException 
	 */
	private AbcSRResp settleReportUploadNotice(String serialDate, String fileName, String localPath, int rows) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ftpServer = channelParms.get("100039");
		String ftpPassword = channelParms.get("100040");
		String ftpUser = channelParms.get("100041");
		String payComNo = channelParms.get("100038");	//支付机构签约编号
		
		Log4jUtil.info("____________________执行备付金文件上报请求CFRA33____________________");
		final File dir = new File(localPath);
		if (!dir.exists()) {
			throw new BizException(TransReturnCode.code_9108, "文件路径【" + localPath + "】 不存在！");
		}
		if (!localPath.endsWith(File.separator)) {
			localPath = localPath + File.separator;
		}
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水,商户自定义序列号
		
		//按农行要求重命名文件名(支付机构编号_报表日期_流水号)
		String newFileName = payComNo+"_"+serialDate+"_"+abcReqSeqNo;
//		renameFile(localPath, fileName, newFileName);
		
		final FtpManager ftpManager = new FtpManager();
		ftpManager.setServer(ftpServer);
		ftpManager.setPassword(ftpPassword);
		ftpManager.setUser(ftpUser);
		ftpManager.setFilename(fileName);
		ftpManager.setLocalPath(localPath); // 上传的本地文件夹目录
		ftpManager.setPath(""); // 远程目录，FTP用户的远程目录默认就是CT服务器存文件的目录
		ftpManager.putMyFile_actionPerformed(newFileName);
		Log4jUtil.info("农行备付金报表文件:" + newFileName + "已上传到CT服务器");

//		try {
//			Thread.sleep(1000);// 暂停1秒, 防止过快调用农行报表上报通知, 导致前置机获取不到文件
//		} catch (InterruptedException e) {
//			Log4jUtil.error(e);
//		}
		
		
//		final String fullFileName = localPath + File.separator + newFileName;
		
		// 得到公共报头 bean 数据
		ERP2CT_PublicBean eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic4SettlementReport("CFRA33", abcReqSeqNo);
		// 构建请求报文体
		final ERP2CT_CFRA33Bean eRP2CT_CFRA33Bean = new ERP2CT_CFRA33Bean();
		eRP2CT_CFRA33Bean.setBatchFileName(newFileName);
		eRP2CT_CFRA33Bean.setFileLineNum(rows);
		eRP2CT_CFRA33Bean.setSerialDate(serialDate);
		eRP2CT_CFRA33Bean.setPayComName(AbcCorpBFJParm.PAY_COM_NAME);	//支付机构名称 (可空)
		eRP2CT_CFRA33Bean.setFileSplit(AbcCorpBFJParm.FILE_SPLIT);	//文件列分隔符 (可空)
		eRP2CT_CFRA33Bean.setCorpType(AbcCorpBFJParm.CORP_TYPE);	//支付机构类型; 0-存管行; 1-合作行; (可空)
		eRP2CT_CFRA33Bean.setMode(AbcCorpBFJParm.MODE);	//判别模式; 0-非替代模式;1-替代模式;
		eRP2CT_CFRA33Bean.setFileFlag(AbcCorpBFJParm.HAS_FILE); //文件标志, 固定送1
		// 组装请求报文并发送
		String resultXml = eRP2CT_CFRA33.sendXMLFile(eRP2CT_PublicBean, eRP2CT_CFRA33Bean);

		AbcSRResp resp = parseAbcXmlService.processSettlementReportRtnXml(resultXml);
		
		resp.setBankSendSn(abcReqSeqNo);//将银行端交易流水带回
		resp.setRemoteFileName(newFileName);
		
		Log4jUtil.info("____________________备付金文件上报请求CFRA33执行结束____________________");
		
		return resp;
	}
	
	/**
	 * <p>按请求流水号查询人行监管报表处理状态(CQLA35)</p>
	 * @param serialNo 原交易请求流水
	 * @param reportDate 报表日期
	 * @return
	 * @throws BizException 
	 */
	
	public AbcSRResp settleReportProcessStatusQur(String serialNo, String serialDate) throws BizException {
		Log4jUtil.info("____________________执行备付金文件处理结果查询CQLA35____________________");
		Log4jUtil.info("查询的原交易流水:【{}】, 报表日期:【{}】", serialNo, serialDate);
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水,商户自定义序列号
		// 得到公共报头 bean 数据
		ERP2CT_PublicBean eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic4SettlementReport("CQLA35", abcReqSeqNo);
		// 构建请求报文体
		final ERP2CT_CQLA35Bean eRP2CT_CQLA35Bean = new ERP2CT_CQLA35Bean();
		eRP2CT_CQLA35Bean.setSerialDate(serialDate);
		eRP2CT_CQLA35Bean.setSerialNo(serialNo);
		// 组装请求报文并发送
		String resultXml = eRP2CT_CQLA35.sendXMLFile(eRP2CT_PublicBean, eRP2CT_CQLA35Bean);

		Log4jUtil.info("银行处理回执报文【{}】",resultXml);
		
		AbcSRResp resp = parseAbcXmlService.processSettlementReportRtnXml(resultXml);
		
		Log4jUtil.info("备付金文件处理结果,AbcSRResp【{}】",resp);
		
		Log4jUtil.info("____________________备付金文件处理结果查询请求CQLA35执行结束____________________");
		
		return resp;
	}
	
	/**
	 * <p>按请求流水号查询人行监管报表稽核结果(CQLA36)</p>
	 * @param serialNo 请求流水号(同报表上报请求流水)
	 * @param serialDate 报表日期 YYYYMMDD
	 * @param localPath	回执文件本地存放路径
	 * @return ErrorResultBFJ 回执结果DTO
	 * @throws BizException
	 */
	public ErrorResultBFJ queryBFJRepCheckResult(String serialNo, String serialDate, String localPath) throws BizException{
		//按请求流水号查询人行监管报表稽核结果
		AbcSRResp abcResp = settleReportCheckResultQur(serialNo, serialDate, localPath);
		//构建通用回执对象
		ErrorResultBFJ result = new ErrorResultBFJ();
		if("0000".equals(abcResp.getRespCode())){
			result.setChannelRtnStatus(BFJConstant.SUCCESS);
			result.setMark("成功");
		}else{
			result.setChannelRtnStatus(BFJConstant.FAILURE);
			result.setMark(abcResp.getRespInfo());
		}
//		result.setFileID(fileId);
		if(AbcCorpBFJParm.HAS_FILE.equals(abcResp.getFileFlag())){
			result.setFileFlag(BFJConstant.HASFILE);
			result.setResultFileName(abcResp.getBatchFileName());
			result.setResultFilePath(localPath);
		}
		result.setReportDate(serialDate);
		return result;
	}
	
	/**
	 * <p>按请求流水号查询人行监管报表稽核结果(CQLA36)</p>
	 * @param serialNo 原交易请求流水
	 * @param serialDate 查询报表日期
	 * @param localPath 本地文件存放路径 (从农行前置机将文件下载到本地共享目录)
	 */
	
	private AbcSRResp settleReportCheckResultQur(String serialNo, String serialDate, String localPath) throws BizException {
		Log4jUtil.info("____________________执行备付金文件报表稽核结果查询CQLA36____________________");
		Log4jUtil.info("查询的原交易流水:【{}】, 报表日期:【{}】, 文件本地存放路径:【{}】", serialNo, serialDate, localPath);
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水,商户自定义序列号
		// 得到公共报头 bean 数据
		ERP2CT_PublicBean eRP2CT_PublicBean = erp2ctPublicService.createErp2CTPublic4SettlementReport("CQLA36", abcReqSeqNo);
		// 构建请求报文体
		final ERP2CT_CQLA36Bean eRP2CT_CQLA36Bean = new ERP2CT_CQLA36Bean();
		eRP2CT_CQLA36Bean.setSerialDate(serialDate);
		eRP2CT_CQLA36Bean.setSerialNo(serialNo);
		eRP2CT_CQLA36Bean.setFileSplit(AbcCorpBFJParm.FILE_SPLIT);
		// 组装请求报文并发送
		String resultXml = eRP2CT_CQLA36.sendXMLFile(eRP2CT_PublicBean, eRP2CT_CQLA36Bean);

		AbcSRResp resp = parseAbcXmlService.processSettlementReportRtnXml(resultXml);
		
		if(resp != null){
			if("0000".equals(resp.getRespCode())){
				if(AbcCorpBFJParm.HAS_FILE.equals(resp.getFileFlag())){//有文件可以下载
					Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
					String ftpServer = channelParms.get("100039");
					String ftpPassword = channelParms.get("100040");
					String ftpUser = channelParms.get("100041");
					
					final File dir = new File(localPath);
					if (!dir.exists()) {
						throw new BizException(TransReturnCode.code_9108, "文件路径【" + localPath + "】 不存在！");
					}
					if (!localPath.endsWith(File.separator)) {
						localPath = localPath + File.separator;
					}
					final FtpManager ftpManager = new FtpManager();
					ftpManager.setServer(ftpServer);
					ftpManager.setPassword(ftpPassword);
					ftpManager.setUser(ftpUser);
					ftpManager.setFilename(resp.getBatchFileName());
					ftpManager.setLocalPath(localPath); // 下载的本地文件夹目录
					ftpManager.setPath(""); // 远程目录，FTP用户的远程目录默认就是CT服务器存文件的目录
					ftpManager.getMyFile_actionPerformed();
					Log4jUtil.info("农行备付金报表勾稽文件【{}】已下载到本地【{}】", resp.getBatchFileName(), localPath);
//					final String fullFileName = localPath + File.separator + fileName;
//					resp.setLocalPath(localPath);
				}else{
					Log4jUtil.info("勾稽结果文件不存在!");
				}
			}
		}
		
		Log4jUtil.info("____________________备付金文件报表稽核结果查询请求CQLA36执行结束____________________");
		
		return resp;
	}
}