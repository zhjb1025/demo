package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util;

public class RechargeToAbcBean {
	private double rechargeAmount = 0;;
	private String payerbankcardno = ""; // 商户对公账号
	private String payerbankcardName = ""; // 商户对公账号
	private String ordernote = "";

	public RechargeToAbcBean() {

	}

	public RechargeToAbcBean(double rechargeAmount, String payerbankcardno, String payerbankcardName) {
		super();
		this.rechargeAmount = rechargeAmount;
		this.payerbankcardno = payerbankcardno;
		this.payerbankcardName = payerbankcardName;
	}

	public double getRechargeAmount() {
		return rechargeAmount;
	}

	public void setRechargeAmount(double rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}

	public String getOrdernote() {
		return ordernote;
	}

	public void setOrdernote(String ordernote) {
		this.ordernote = ordernote;
	}

	public String getPayerbankcardno() {
		return payerbankcardno;
	}

	public void setPayerbankcardno(String payerbankcardno) {
		this.payerbankcardno = payerbankcardno;
	}

	public String getPayerbankcardName() {
		return payerbankcardName;
	}

	public void setPayerbankcardName(String payerbankcardName) {
		this.payerbankcardName = payerbankcardName;
	}

}
