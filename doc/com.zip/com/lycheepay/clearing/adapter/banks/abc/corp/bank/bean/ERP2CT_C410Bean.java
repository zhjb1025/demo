package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_C410Bean {

	// ERP2CT_C410 代理收款（C410） 请求报文字段
	private String Amt;  // 总金额
	private String FileFlag;  // 文件标志 #固定为1
	private String BookingDate;  // 预约日期
	private String BookingTime;  // 预约时间
	private String BookingFlag;  // 预约标志 #固定为0-不预约
	private String Postscript;  // 附言
	private String TotalNum;  // 总笔数
	private String DbAccName;  // 户名
	private String DbAccNo;  // 账号
	private String DbProv;  // 帐号省市代码
	private String DbCur;  // 货币码
	private String BatchFileName;  // 批量文件名

	public String getAmt() {
		return Amt;
	}

	public void setAmt(final String amt) {
		Amt = amt;
	}

	public String getFileFlag() {
		return FileFlag;
	}

	public void setFileFlag(final String fileFlag) {
		FileFlag = fileFlag;
	}

	public String getBookingDate() {
		return BookingDate;
	}

	public void setBookingDate(final String bookingDate) {
		BookingDate = bookingDate;
	}

	public String getBookingTime() {
		return BookingTime;
	}

	public void setBookingTime(final String bookingTime) {
		BookingTime = bookingTime;
	}

	public String getBookingFlag() {
		return BookingFlag;
	}

	public void setBookingFlag(final String bookingFlag) {
		BookingFlag = bookingFlag;
	}

	public String getPostscript() {
		return Postscript;
	}

	public void setPostscript(final String postscript) {
		Postscript = postscript;
	}

	public String getTotalNum() {
		return TotalNum;
	}

	public void setTotalNum(final String totalNum) {
		TotalNum = totalNum;
	}

	public String getDbAccName() {
		return DbAccName;
	}

	public void setDbAccName(final String dbAccName) {
		DbAccName = dbAccName;
	}

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

	public String getBatchFileName() {
		return BatchFileName;
	}

	public void setBatchFileName(final String batchFileName) {
		BatchFileName = batchFileName;
	}

}
