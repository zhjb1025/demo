package com.lycheepay.clearing.adapter.banks.abc.corp.kft.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_C503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.ERP2CT_PublicBean;
import com.lycheepay.clearing.adapter.banks.abc.corp.bank.util.ERP2CT_C503;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.Erp2CTPublicService;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.util.ParseAbcXmlService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.corp.NoticeBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.NoticeParam;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.CorpAccNoticeProcess;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行银企动帐通知服务处理</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 下午5:24:38
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_NOTICE_PROCESSOR)
public class AbcCorpNoticeProcessor extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ERP2_CT_PUBLIC_SERVICE)
	private Erp2CTPublicService erp2CTPublicService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.PARSE_ABC_XML_SERVICE)
	private ParseAbcXmlService parseAbcXmlService;
	@Autowired
	private ERP2CT_C503 eRP2CT_C503;

	private String channelId = ChannelIdEnum.ABC_CORP.getCode();

	/**
	 * <p>农业银行银企直连动帐通知服务</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-18 下午5:50:05
	 */
	public void notice(final NoticeParam nparam) throws ClearingAdapterBizCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String KftProv = channelParms.get("100008");
		String KftCur = channelParms.get("100009");
		String StartTime = channelParms.get("100021");
		Log4jUtil.info("____________________________ C503 到账通知 start ____________________________________");
		// Log4jUtil1.info("____________________________NEW C503 到账通知 start ____________________________________");
		ERP2CT_PublicBean eRP2CT_PublicBean = new ERP2CT_PublicBean();
		final ERP2CT_C503Bean eRP2CT_C503Bean = new ERP2CT_C503Bean();
		// 生成农行银企流水
		// String abcReqSeqNo = "abcC503_" + DateUtil.getDate(new Date()) +
		// pay_SequenceDao.nextVal("ABC_SN",12).toString(); //农行银企流水 商户自定义序列号
		final String abcReqSeqNo = sequenceManagerService.getCorpAbcSN(DateUtil.getCurrentDate());// 农行银企流水
		// 商户自定义序列号
		// 得到公共报头 bean 数据
		eRP2CT_PublicBean = erp2CTPublicService.createErp2CTPublic("C503", abcReqSeqNo);
		// 组503报文数据
		// 从参数表取得平台的账号；省市代码；货币单位；最后交易的时间截

		// } else if (nparam.getTag()==2){//标志：1-到账通知 2-自动对账
		// StartTime = channelParms.get("100021");
		// } else {
		// throw new BizException("nparam.getTag()标志错：1-到账通知  2-自动对账，用户传入的值是" + nparam.getTag() );
		// }

		// 做到账通知时，快付通平台账户信息使用充值的业务类型(TransType.Recharge)来取账户信息
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);

		eRP2CT_C503Bean.setDbAccNo(bankaccountBalance.getAccountNo());
		eRP2CT_C503Bean.setDbProv(KftProv);
		eRP2CT_C503Bean.setDbCur(KftCur);

		eRP2CT_C503Bean.setStartTime(StartTime.trim());// 末笔时间戳，用于增量查询

		eRP2CT_C503Bean.setStartDate(nparam.getNoticeDate());
		eRP2CT_C503Bean.setEndDate(nparam.getNoticeDate());
		// eRP2CT_C503Bean.setStartDate("20110420"); // TODO 测试完后删除
		// eRP2CT_C503Bean.setEndDate("20110420"); // TODO 测试完后删除
		eRP2CT_C503Bean.setLastJrnNo("");

		// 组数据成功后，发送 C503 报文,同时取得返回的 C503 报文resultXml
		final String resultXml = eRP2CT_C503.sendXMLFile(eRP2CT_PublicBean, eRP2CT_C503Bean);
		// 发送503报文到CT
		Log4jUtil.info("503报文resultXml:" + resultXml);

		// 解释C503报文，生成 noticeList
		Map<String, List> map = parseAbcXmlService.processRecvC503Xml(resultXml);
		ArrayList<NoticeBean> noticeList = (ArrayList<NoticeBean>) map.get("noticeList");
		for (final NoticeBean noticeBean : noticeList) {
			Log4jUtil.info("BankSn == " + noticeBean.getBankSn());
		}

		// 如果 noticeList.size() > 0 , 则调用平台的到账通知处理；否则不调用平台到账通知处理。
		if (noticeList.size() > 0) {
			// 得到 C503 的应答报文，调用公用到账通知处理方法
			Log4jUtil.info("农行银企到账通知查询到的记录数为:【" + noticeList.size() + "】条");
			CorpAccNoticeProcess.accNotice(noticeList);
		} else {
			Log4jUtil.info("农行银企到账通知查询记录数为0，没有到账数据");
		}
	}
}
