package com.lycheepay.clearing.adapter.banks.abc.cross;

public final class AbcCrossConstant {
	
	public static String STRING_MD5 = "md5";
	
	public static String TRAN_CODE_WH14 = "WH14";
	public static String TRAN_CODE_WH16 = "WH16";
	public static String TRAN_CODE_WH19 = "WH19";
	public static String PROC_CODE = "000000";
	
	public static String PARM_SYS_SOCKET_IP = "100001";
	public static String PARM_SYS_SOCKET_PORT = "100002";
	public static String PARM_SYS_FTP_IP = "100003";
	public static String PARM_SYS_FTP_PORT = "100004";
	public static String PARM_SYS_FTP_USER = "100005";
	public static String PARM_SYS_FTP_PWD = "100006";
	

	public static String PARM_USR_MD5_KEY = "100101";
	public static String PARM_USR_MER_ID = "100102";
	public static String PARM_USR_TERM_ID = "100103";
	public static String PARM_USR_FTP_LOCAL_PATH = "100104";
	public static String PARM_USR_FTP_REMOTE_PATH = "100105";
	
	
	public static String PARM_VAR_TRANTYPE = "100201";
	public static String PARM_VAR_PAYTYPE = "100202";
	public static String PARM_VAR_BIZTYPE = "100203";
	public static String PARM_VAR_REMITDEST = "100204";
	public static String PARM_VAR_PAYEETYPE = "100205";
	public static String PARM_VAR_ACCOUNTABD = "100206";
	public static String PARM_VAR_FEEPAYER = "100207";
	public static String PARM_VAR_SIGNIO = "100208";
	public static String PARM_VAR_BIZSORT = "100209";
	public static String PARM_VAR_REMITPURPOSE = "100210";
	public static String PARM_VAR_RECVBANKNO = "100211";
	public static String PARM_VAR_RECVDPBANKNO = "100212";
	public static String PARM_VAR_ACCOUNTNO = "100213";

}
