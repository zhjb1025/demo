package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean;

public class BatFileResultQueryRsp {
	String fileNameRcv = "";// 1 文件名
	String fileSize = "";// 2 文件大小
	String totalNum = "";// 3 总笔数
	String totalAmt = "";// 4 总金额
	String totalNumSuc = "";// 5 成功总笔数
	String totalAmtSuc = "";// 6 成功总金额
	String tranDate = "";// 7 交易日期
	String tranTime = "";// 8 交易时间
	String retCode = "";// 9 返回码
	String retMsg = "";// 10 返回信息

	String fileNameRcvPath = "";

	public String getFileNameRcv() {
		return fileNameRcv;
	}

	public void setFileNameRcv(final String fileNameRcv) {
		this.fileNameRcv = fileNameRcv;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(final String fileSize) {
		this.fileSize = fileSize;
	}

	public String getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(final String totalNum) {
		this.totalNum = totalNum;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(final String totalAmt) {
		this.totalAmt = totalAmt;
	}

	public String getTotalNumSuc() {
		return totalNumSuc;
	}

	public void setTotalNumSuc(final String totalNumSuc) {
		this.totalNumSuc = totalNumSuc;
	}

	public String getTotalAmtSuc() {
		return totalAmtSuc;
	}

	public void setTotalAmtSuc(final String totalAmtSuc) {
		this.totalAmtSuc = totalAmtSuc;
	}

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(final String tranDate) {
		this.tranDate = tranDate;
	}

	public String getTranTime() {
		return tranTime;
	}

	public void setTranTime(final String tranTime) {
		this.tranTime = tranTime;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(final String retCode) {
		this.retCode = retCode;
	}

	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(final String retMsg) {
		this.retMsg = retMsg;
	}

	public String getFileNameRcvPath() {
		return fileNameRcvPath;
	}

	public void setFileNameRcvPath(final String fileNameRcvPath) {
		this.fileNameRcvPath = fileNameRcvPath;
	}
}
