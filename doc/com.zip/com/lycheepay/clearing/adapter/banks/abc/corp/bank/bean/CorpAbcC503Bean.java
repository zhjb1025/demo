package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

/**
 * 银企直连到账通知统一封装Bean <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @version 1.0
 */
public class CorpAbcC503Bean {

	String Prov;// 省市代号
	String AccNo;// 账号
	String Ccy;// 货币码
	String TrDate;// 交易日期
	String TimeStab;// 交易时间戳
	String TrJrn;// 日志号
	String Name;// 户名
	String TrType;// 交易类别
	String TrFrom;// 交易来源
	String TrBankNo;// 交易行行号
	String AmtIndex;// 发生额标志
	String OppProv;// 对方账号省市代码
	String OppAccNo;// 对方账号
	String OppCcy;// 对方账号货币码
	String OppName;// 对方账号户名
	String OppBkName;// 对方账号开户行名
	String CshIndex;// 现转标志
	String ErrDate;// 错账日期
	String ErrVchNo;// 错账凭证号
	String Amt;// 交易金额
	String Bal;// 账户余额
	String PreAmt;// 上笔余额
	String TotChg;// 手续费总额
	String VoucherType;// 凭证种类
	String VoucherProv;// 凭证省市代码
	String VoucherBat;// 凭证批次号
	String VoucherNo;// 凭证号
	String CustRef;// 户参考号 ============== 这个就是 billnoSn 的Ban_Send_SN 发往银行端的流水
	String TrCode;// 交易码
	String Teller;// 柜员号
	String VchNo;// 传票号
	String Abs;// 摘要
	String Cmt;// 附言
	String SpFlag;// 特殊信息标志
	String FmtCode;// 格式码
	String SpecInfo;// 特殊信息

	public String getProv() {
		return Prov;
	}

	public void setProv(final String prov) {
		Prov = prov;
	}

	public String getAccNo() {
		return AccNo;
	}

	public void setAccNo(final String accNo) {
		AccNo = accNo;
	}

	public String getCcy() {
		return Ccy;
	}

	public void setCcy(final String ccy) {
		Ccy = ccy;
	}

	public String getTrDate() {
		return TrDate;
	}

	public void setTrDate(final String trDate) {
		TrDate = trDate;
	}

	public String getTimeStab() {
		return TimeStab;
	}

	public void setTimeStab(final String timeStab) {
		TimeStab = timeStab;
	}

	public String getTrJrn() {
		return TrJrn;
	}

	public void setTrJrn(final String trJrn) {
		TrJrn = trJrn;
	}

	public String getName() {
		return Name;
	}

	public void setName(final String name) {
		Name = name;
	}

	public String getTrType() {
		return TrType;
	}

	public void setTrType(final String trType) {
		TrType = trType;
	}

	public String getTrFrom() {
		return TrFrom;
	}

	public void setTrFrom(final String trFrom) {
		TrFrom = trFrom;
	}

	public String getTrBankNo() {
		return TrBankNo;
	}

	public void setTrBankNo(final String trBankNo) {
		TrBankNo = trBankNo;
	}

	public String getAmtIndex() {
		return AmtIndex;
	}

	public void setAmtIndex(final String amtIndex) {
		AmtIndex = amtIndex;
	}

	public String getOppProv() {
		return OppProv;
	}

	public void setOppProv(final String oppProv) {
		OppProv = oppProv;
	}

	public String getOppAccNo() {
		return OppAccNo;
	}

	public void setOppAccNo(final String oppAccNo) {
		OppAccNo = oppAccNo;
	}

	public String getOppCcy() {
		return OppCcy;
	}

	public void setOppCcy(final String oppCcy) {
		OppCcy = oppCcy;
	}

	public String getOppName() {
		return OppName;
	}

	public void setOppName(final String oppName) {
		OppName = oppName;
	}

	public String getOppBkName() {
		return OppBkName;
	}

	public void setOppBkName(final String oppBkName) {
		OppBkName = oppBkName;
	}

	public String getCshIndex() {
		return CshIndex;
	}

	public void setCshIndex(final String cshIndex) {
		CshIndex = cshIndex;
	}

	public String getErrDate() {
		return ErrDate;
	}

	public void setErrDate(final String errDate) {
		ErrDate = errDate;
	}

	public String getErrVchNo() {
		return ErrVchNo;
	}

	public void setErrVchNo(final String errVchNo) {
		ErrVchNo = errVchNo;
	}

	public String getAmt() {
		return Amt;
	}

	public void setAmt(final String amt) {
		Amt = amt;
	}

	public String getBal() {
		return Bal;
	}

	public void setBal(final String bal) {
		Bal = bal;
	}

	public String getPreAmt() {
		return PreAmt;
	}

	public void setPreAmt(final String preAmt) {
		PreAmt = preAmt;
	}

	public String getTotChg() {
		return TotChg;
	}

	public void setTotChg(final String totChg) {
		TotChg = totChg;
	}

	public String getVoucherType() {
		return VoucherType;
	}

	public void setVoucherType(final String voucherType) {
		VoucherType = voucherType;
	}

	public String getVoucherProv() {
		return VoucherProv;
	}

	public void setVoucherProv(final String voucherProv) {
		VoucherProv = voucherProv;
	}

	public String getVoucherBat() {
		return VoucherBat;
	}

	public void setVoucherBat(final String voucherBat) {
		VoucherBat = voucherBat;
	}

	public String getVoucherNo() {
		return VoucherNo;
	}

	public void setVoucherNo(final String voucherNo) {
		VoucherNo = voucherNo;
	}

	public String getCustRef() {
		return CustRef;
	}

	public void setCustRef(final String custRef) {
		CustRef = custRef;
	}

	public String getTrCode() {
		return TrCode;
	}

	public void setTrCode(final String trCode) {
		TrCode = trCode;
	}

	public String getTeller() {
		return Teller;
	}

	public void setTeller(final String teller) {
		Teller = teller;
	}

	public String getVchNo() {
		return VchNo;
	}

	public void setVchNo(final String vchNo) {
		VchNo = vchNo;
	}

	public String getAbs() {
		return Abs;
	}

	public void setAbs(final String abs) {
		Abs = abs;
	}

	public String getCmt() {
		return Cmt;
	}

	public void setCmt(final String cmt) {
		Cmt = cmt;
	}

	public String getSpFlag() {
		return SpFlag;
	}

	public void setSpFlag(final String spFlag) {
		SpFlag = spFlag;
	}

	public String getFmtCode() {
		return FmtCode;
	}

	public void setFmtCode(final String fmtCode) {
		FmtCode = fmtCode;
	}

	public String getSpecInfo() {
		return SpecInfo;
	}

	public void setSpecInfo(final String specInfo) {
		SpecInfo = specInfo;
	}

}
