package com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.util;

/**
 * 处理发送批量交易的总笔数；总金额数 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-kxj
 * @version 1.0
 */
public class SendResultBean {
	private String totalNum;// 总笔数
	private String totalAmt;// 总金额

	public String getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(final String totalNum) {
		this.totalNum = totalNum;
	}

	public String getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(final String totalAmt) {
		this.totalAmt = totalAmt;
	}
}
