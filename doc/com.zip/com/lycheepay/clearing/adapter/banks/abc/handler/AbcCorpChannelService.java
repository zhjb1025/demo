/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-2-13 上午10:57:42
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.handler;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.processor.AbcCorpDirectProcess;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.processor.AbcCorpNoticeProcessor;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.channel.param.NoticeParam;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P> 农业银行银企清算服务入口服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 上午11:07:43
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_CHANNEL_SERVICE)
public class AbcCorpChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_DIRECT_PROCESS)
	private AbcCorpDirectProcess abcCorpDirectProcess;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_NOTICE_PROCESSOR)
	private AbcCorpNoticeProcessor abcCorpNoticeProcessor;

	public final static String channelId = ChannelIdEnum.ABC_CORP.getCode();

	/**
	 * PS.农业银行银企直连实时代收
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) {
		Log4jUtil.setLogClass("ABC", "corp");
		Log4jUtil.info(deductDTO);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);

		try {
			dto = ChannelResultUtil.covertResultDTO(abcCorpDirectProcess.directDeduct(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;

	}

	/**
	 * PS.农业银行银企直连实时代付
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directPay(com.lycheepay.clearing.common.dto.trade.PayOutDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directPay(final PayOutDTO pay) {
		Log4jUtil.setLogClass("ABC", "corp");
		Log4jUtil.info(pay);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		param.setSn(pay.getTxnId());
		param.setCardType(pay.getBankCardType());
		param.setBorc(pay.getAccountType());
		param.setBizBean(pay);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_PAY);

		try {
			dto = ChannelResultUtil.covertResultDTO(abcCorpDirectProcess.directPay(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * <p>农行银企到账通知</p>
	 */
	public void notice(final String date) {
		Log4jUtil.setLogClass("ABC", "notice");
		
		final NoticeParam noticeParam = new NoticeParam();
		noticeParam.setChannelId(ChannelIdEnum.ABC_CORP.getCode()); // 农行银企的渠道
		noticeParam.setNoticeDate(date);
		
		try {
			abcCorpNoticeProcessor.notice(noticeParam);
		} catch (ClearingAdapterBizCheckedException e) {
			Log4jUtil.error(e);
		}
	}

	@Override
	public int getMaxNum() {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		return Integer.valueOf(channelParms.get("100036") == null ? "0 " : channelParms.get("100036"));
	}

	@Override
	public BatchSendResult processBatch(String channelBatchId, final List<ChannelTempBill> payList,
			final boolean repeatSend) {
		Log4jUtil.setLogClass("ABC", "corp");

		BatchSendResult batchSendResult = null;
		try {
			batchSendResult = abcCorpDirectProcess.processBatch(payList, repeatSend);
		} catch (Exception e) {
			Log4jUtil.error(e);
			return ChannelResultUtil.exceptionToResult(e, batchSendResult);
		}
		return batchSendResult;
	}

	/**
	 * <p>农行银企批量交易结果查询 定时任务处理</p>
	 * 
	 * @author 张凯锋(13816608861)
	 */
	@Override
	public void timeQueryBatchTransResult() {
		Log4jUtil.setLogClass("ABC", "timeQueryBatchTransResult");
		// 农行银企批量交易更新交易结果数据下载,并进行自动批量交易更新交易结果
		try {
			abcCorpDirectProcess.batchRetProcess();
		} catch (BizException e) {
			Log4jUtil.error("农行银企批量交易结果查询 定时任务处理出错：", e);
		}
	}

	@Override
	public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) {
		Log4jUtil.setLogClass("ABC", "query");
		String payState = PayState.UNKNOW_STR;
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		resultDTO.setChannelId(channelId);
		try {
			payState = abcCorpDirectProcess.send1944(billnoSn.getBankSendSn());
		} catch (BizException e) {
			Log4jUtil.error(e);
		}
		if (PayState.SUCCEED_STR.equals(payState)) {
			resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			resultDTO.setChannelResponseMsg("交易成功");
			resultDTO.setTxnStatus(PayState.SUCCEED_STR);
		} else if (PayState.FAILED_STR.equals(payState)) {
			resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			resultDTO.setChannelResponseMsg("交易失败");
			resultDTO.setTxnStatus(PayState.FAILED_STR);
		}else{
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg("未知");
			resultDTO.setTxnStatus(PayState.UNKNOW_STR);
		}
		return resultDTO;
	}

	/**
	 * 获取账户余额
	 * @return
	 * @author 张凯锋
	 */
	public Balance queryBanlance() {
		Balance balance = null;
		try {
			balance = abcCorpDirectProcess.send7506(null);
		} catch (BizException e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}
	
	public Balance queryBanlance(String accountNo) {
		Balance balance = null;
		try {
			balance = abcCorpDirectProcess.send7506(accountNo);
		} catch (BizException e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}

	/**
	 * 获取账户历史明细
	 * 
	 * @param date 查询日期
	 * @param accountNo 账号 ，如果过没有，默认为该渠道结算账户
	 * @param filePath 明细文件保存路径,比如//home/admin/sharedata/recon/historyDetail/
	 * @return
	 * @author 张凯锋
	 */
	public String queryAccountHistoryTransDetail(String date, String accountNo, String filePath) {
		String queryResult = null;
		try {
			queryResult = abcCorpDirectProcess.queryAccountHistoryTransDetail(date, accountNo, filePath);
		} catch (BizException e) {
			Log4jUtil.error(e);
			queryResult = e.getMessage();
		}
		return queryResult;
	}
}
