package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_1908Bean {

	// ERP2CT_1908 汇兑（1908） 请求报文字段
	private String Amt;  // 金额
	private String DbAccNo;  // 借方帐号
	private String DbProv;  // 借方省市代码
	private String DbCur;  // 借方货币码
	private String DbLogAccNo;  // 二级帐簿
	private String CrAccNo;  // 贷方帐号
	private String CrProv;  // 贷方省市代码
	private String CrCur;  // 贷方货币号
	private String CrLogAccNo;  // 贷方二级帐簿
	private String ConFlag;  // 贷方户名校验标志
	private String BookingDate;  // 预约日期
	private String BookingTime;  // 预约时间
	private String BookingFlag;  // 预约标志
	private String ExchangeType;  // 汇兑类型
	private String Postscript;  // 附言
	private String UrgencyFlag;  // 加急标志
	private String OthBankFlag;  // 它行标志
	private String OthCenterFlag;  // 它中心标志
	private String CrAccName;  // 贷方户名
	private String CrBankName;  // 贷方开户行行名
	private String CrBankNo;  // 贷方行号
	private String DbBankName;  // 借方开户行行名
	private String DbAccName;  // 借方户名
	private String DbAddress;  // 借方地址
	private String CrAddress;  // 贷方地址
	private String WhyUse;  // 用途
	private String ActInf;  // 到帐通知标志

	public String getAmt() {
		return Amt;
	}

	public void setAmt(final String amt) {
		Amt = amt;
	}

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

	public String getDbLogAccNo() {
		return DbLogAccNo;
	}

	public void setDbLogAccNo(final String dbLogAccNo) {
		DbLogAccNo = dbLogAccNo;
	}

	public String getCrAccNo() {
		return CrAccNo;
	}

	public void setCrAccNo(final String crAccNo) {
		CrAccNo = crAccNo;
	}

	public String getCrProv() {
		return CrProv;
	}

	public void setCrProv(final String crProv) {
		CrProv = crProv;
	}

	public String getCrCur() {
		return CrCur;
	}

	public void setCrCur(final String crCur) {
		CrCur = crCur;
	}

	public String getCrLogAccNo() {
		return CrLogAccNo;
	}

	public void setCrLogAccNo(final String crLogAccNo) {
		CrLogAccNo = crLogAccNo;
	}

	public String getConFlag() {
		return ConFlag;
	}

	public void setConFlag(final String conFlag) {
		ConFlag = conFlag;
	}

	public String getBookingDate() {
		return BookingDate;
	}

	public void setBookingDate(final String bookingDate) {
		BookingDate = bookingDate;
	}

	public String getBookingTime() {
		return BookingTime;
	}

	public void setBookingTime(final String bookingTime) {
		BookingTime = bookingTime;
	}

	public String getBookingFlag() {
		return BookingFlag;
	}

	public void setBookingFlag(final String bookingFlag) {
		BookingFlag = bookingFlag;
	}

	public String getExchangeType() {
		return ExchangeType;
	}

	public void setExchangeType(final String exchangeType) {
		ExchangeType = exchangeType;
	}

	public String getPostscript() {
		return Postscript;
	}

	public void setPostscript(final String postscript) {
		Postscript = postscript;
	}

	public String getUrgencyFlag() {
		return UrgencyFlag;
	}

	public void setUrgencyFlag(final String urgencyFlag) {
		UrgencyFlag = urgencyFlag;
	}

	public String getOthBankFlag() {
		return OthBankFlag;
	}

	public void setOthBankFlag(final String othBankFlag) {
		OthBankFlag = othBankFlag;
	}

	public String getOthCenterFlag() {
		return OthCenterFlag;
	}

	public void setOthCenterFlag(final String othCenterFlag) {
		OthCenterFlag = othCenterFlag;
	}

	public String getCrAccName() {
		return CrAccName;
	}

	public void setCrAccName(final String crAccName) {
		CrAccName = crAccName;
	}

	public String getCrBankName() {
		return CrBankName;
	}

	public void setCrBankName(final String crBankName) {
		CrBankName = crBankName;
	}

	public String getCrBankNo() {
		return CrBankNo;
	}

	public void setCrBankNo(final String crBankNo) {
		CrBankNo = crBankNo;
	}

	public String getDbBankName() {
		return DbBankName;
	}

	public void setDbBankName(final String dbBankName) {
		DbBankName = dbBankName;
	}

	public String getDbAccName() {
		return DbAccName;
	}

	public void setDbAccName(final String dbAccName) {
		DbAccName = dbAccName;
	}

	public String getDbAddress() {
		return DbAddress;
	}

	public void setDbAddress(final String dbAddress) {
		DbAddress = dbAddress;
	}

	public String getCrAddress() {
		return CrAddress;
	}

	public void setCrAddress(final String crAddress) {
		CrAddress = crAddress;
	}

	public String getWhyUse() {
		return WhyUse;
	}

	public void setWhyUse(final String whyUse) {
		WhyUse = whyUse;
	}

	public String getActInf() {
		return ActInf;
	}

	public void setActInf(final String actInf) {
		ActInf = actInf;
	}

}
