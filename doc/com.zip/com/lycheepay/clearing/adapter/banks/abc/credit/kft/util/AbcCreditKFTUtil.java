package com.lycheepay.clearing.adapter.banks.abc.credit.kft.util;

import java.util.Map;

import com.lycheepay.clearing.adapter.banks.abc.credit.kft.processor.AbcCreditCorpParam;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelParamUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


public class AbcCreditKFTUtil {
	public Map<String, String> checkChannelParam(final String logPrefix, final String type,
			final Map<String, String> channelParam, final AbcCreditCorpParam abcCreditCorpParam) throws BizException {
		String key = "";
		String keyName = "";
		String logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
		Log4jUtil.info(logMsg);
		// 开始对公共必须要检查的参数进行检查

		key = "100001";
		keyName = "IP地址";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

		key = "100002";
		keyName = "端口号";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

		// 设置到银行参数实体中
		abcCreditCorpParam.setIp(channelParam.get("100001"));
		abcCreditCorpParam.setPort(channelParam.get("100002"));

		// 对账。
		key = "100013";
		keyName = "ftpServer";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		key = "100014";
		keyName = "ftpUser";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		key = "100015";
		keyName = "ftpPassword";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		// key = "100016";
		// keyName = "ftpPath";
		// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName,
		// channelParam);

		abcCreditCorpParam.setFtpServer(channelParam.get("100013"));
		abcCreditCorpParam.setFtpUser(channelParam.get("100014"));
		abcCreditCorpParam.setFtpPassword(channelParam.get("100015"));
		abcCreditCorpParam.setFtpPath(channelParam.get("100016"));

		logMsg = logPrefix + "对渠道参数检查结束。";
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, abcCreditCorpParam);
		return channelParam;
	}
}
