package com.lycheepay.clearing.adapter.banks.abc.cross.dto;

import com.lycheepay.clearing.adapter.banks.abc.cross.AbcCrossConstant;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanBase;
import com.lycheepay.clearing.adapter.banks.abc.cross.dto.base.AbcCrossBeanField;


public class WH14RequestDTO extends AbcCrossBeanBase {

	public WH14RequestDTO() {
		super.addField(new AbcCrossBeanField("transCode", 4, true, ' '));
		super.addField(new AbcCrossBeanField("procCode", 6, true, ' '));
		super.addField(new AbcCrossBeanField("termID", 8, true, ' '));
		super.addField(new AbcCrossBeanField("merID", 10, true, ' '));
		super.addField(new AbcCrossBeanField("file", 50, true, ' '));
		super.addField(new AbcCrossBeanField(AbcCrossConstant.STRING_MD5, 32, true, ' '));

	}

	public String getTransCode() {
		return data.get("transCode");
	}

	public void setTransCode(String transCode) {
		data.put("transCode", transCode);
	}

	public String getProcCode() {
		return data.get("procCode");
	}

	public void setProcCode(String procCode) {
		data.put("procCode", procCode);
	}

	public String getTermID() {
		return data.get("termID");
	}

	public void setTermID(String termID) {
		data.put("termID", termID);
	}

	public String getMerID() {
		return data.get("merID");
	}

	public void setMerID(String merID) {
		data.put("merID", merID);
	}

	public String getFile() {
		return data.get("file");
	}

	public void setFile(String file) {
		data.put("file", file);
	}

}
