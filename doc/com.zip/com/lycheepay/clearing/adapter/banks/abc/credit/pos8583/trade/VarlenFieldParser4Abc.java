package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.trade;

import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.MsgField4Abc;


/**
 * 变长域解析器.
 * 
 * @author aps-wiz
 */
public class VarlenFieldParser4Abc extends FieldParser4Abc {
	// 长度标识.
	private final int lenOfLeaderLength;

	public VarlenFieldParser4Abc(final int lenOfLeaderLength) {
		this.lenOfLeaderLength = lenOfLeaderLength;
	}

	@Override
	protected boolean hasLeaderLength() {
		return true;
	}

	@Override
	public int getLenOfLeaderLength() {
		return lenOfLeaderLength;
	}

	/* (non-Javadoc)
	 * @see com.unibank.mp.trade.msg.parser.FieldParser#getNeedLength(com.unibank.mp.trade.msg.MsgField)
	 */
	@Override
	protected int getNeedLength(final MsgField4Abc field) {
		// 总长.
		final int origMsgLength = field.getOrigMsgLength();
		final int LEN_TAG = getLenOfLeaderLength();

		if (origMsgLength == 0) {
			return LEN_TAG;
		}

		// 先凑够长度标识.
		if (origMsgLength < LEN_TAG) {
			return LEN_TAG - origMsgLength;
		}

		// 已有完整的长度标识, 但无数据.
		if (origMsgLength == LEN_TAG) {
			return field.getShouldOrigValueLength();
		}

		// 有数据,但数据不全.
		final int shouldLength = LEN_TAG + field.getShouldOrigValueLength();
		if (origMsgLength < shouldLength) {
			return shouldLength - origMsgLength;
		}
		// 数据已接收完全, 不再需要.
		return 0;
	}
}
