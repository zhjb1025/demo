package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 处理农行银企批量业务返回的结果数据（批量收款；批量付款）
 * 
 * @author aps-kxj
 * 
 */
@Service("corpAbcBatchRetDealService")
public class AbcCorpBatchRetDealService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;

	private static final String channelId = ChannelIdEnum.ABC_CORP.getCode();

	/**
	 * 处理批量业务查询（1972）返回的数据（批量代收C410；批量代付C405）
	 * 
	 * @param channelBatchno 农行银企请求渠道流水号：代理收款（C410）或 代发工资（C405）
	 * @param batchFileName 批量结果文件（含相对路径）
	 * @throws BizException
	 */
	public void predeal(final String channelBatchno, final String batchFileName, final String checkDate)
			throws BizException {
		Log4jUtil.info("____________________发起批量交易结果处理 CorpAbcBatchRetDealService.predeal()____________________");
		// //////////////////////////
		// 2、处理返回的数据
		// a.读取文件，取得数据
		String custId = "";// 客户编号 C20
		String custName = "";// 客户姓名 C32
		String custAccount = "";// 客户账号 C30
		String amt = "";// 交易金额 N18.2
		String msg = "";// 摘要 C30
		String result = "";// 处理结果S-成功 E-失败
		String aBISCode = "";// ABIS交易码（或返回码） C6
		BigDecimal doubleAmt = BigDecimal.ZERO;// 交易金额 Double 类型

		// 统计合计数据，用于保存到 表
		Long sucessnum = 0L;          // SucessNum 成功总笔数
		Double sucessamount = 0.0;     // SucessAmount 成功总金额
		Long unsucessnum = 0L;        // UnSucessNum 失败总笔数
		Double unsucessamount = 0.0;   // UnSucessAmount 失败总金额
		BillnoSn billnoSn = new BillnoSn();

		String s = null; // 判断文件是否读完
		BufferedReader bufferedReader = null;
		try {
			// bufferedReader = new BufferedReader(new FileReader(batchFileName));
			final InputStreamReader reader = new InputStreamReader(new FileInputStream(batchFileName),
					Charset.forName("GBK"));
			bufferedReader = new BufferedReader(reader);
		} catch (final FileNotFoundException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "错误：找不到农行银企批量文件：" + batchFileName);
		}
		try {
			while ((s = bufferedReader.readLine()) != null) {
				final byte[] bytes = s.getBytes("GBK");
				custId = new String(bytes, 0, 20).trim();
				custName = new String(bytes, 20, 32, Charset.forName("GBK")).trim();
				custAccount = new String(bytes, 52, 30).trim();
				amt = new String(bytes, 82, 18).trim();
				doubleAmt = new BigDecimal(amt);
				msg = new String(bytes, 100, 30).trim();
				result = new String(bytes, 130, 1).trim(); // S-成功 E-失败
				aBISCode = new String(bytes, 131, 6).trim();

				// 对账方面，暂不考虑
				// AccBean accBean = new AccBean();

				// b.更新billnoSn表\Channel_Batch表
				// b1.查找billnoSn表的记录
				// String custId=""; 客户编号 C20 billnoSn.setOthercustId(OtherCust_Id);//对方客户编号
				// String custName=""; 客户姓名 C32 billnoSn.setOtheracctname(OtherAcctName);// 对方户名
				// String custAccount=""; 客户账号 C30 billnoSn.setOtheracctno(OtherAcctNo);// 对方帐号
				// String amt=""; 交易金额 N18.2 billnoSn.setAmount(DTranAmt); // 平台交易金额
				billnoSn = billnoSnService.corpAbcBatchFindUnique(channelId, channelBatchno, custId, custName,
						custAccount, amt);
				if (billnoSn == null) {
					Log4jUtil.error("在表 billnoSn 中找不到批量返回的交易记录，交易记录详细信息如下：" + "渠道ID：" + channelId + "渠道批次："
							+ channelBatchno + "对方客户编号：" + custId + "对方户名：" + custName + "对方帐号：" + custAccount
							+ "交易金额：" + amt);
					continue;
				}
				// 给 ChannelBatch 表做记录汇总
				if (result.equals("S")) {
					sucessnum = sucessnum + 1;          // SucessNum 成功总笔数
					sucessamount = sucessamount + Double.valueOf(amt);     // SucessAmount 成功总金额
					billnoSn.setChannelRtncode("0000"); // 渠道返回码
					billnoSn.setChannelRtnnote("S-成功"); // 渠道返回附言
					billnoSn.setPayState("1");// 成功1
				} else {
					unsucessnum = unsucessnum + 1;          // UnSucessNum 失败总笔数
					unsucessamount = unsucessamount + Double.valueOf(amt);     // UnSucessAmount 失败总金额
					billnoSn.setChannelRtncode(aBISCode); // 渠道返回码
					billnoSn.setChannelRtnnote("失败 " + msg); // 渠道返回附言
					billnoSn.setPayState("2");// 失败2
				}

				// b2.更新billnoSn表的STATE字段
				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
				billnoSn.setRecvTime(new Date()); // 返回时间
				billnoSn.setActualAmount(doubleAmt); // 渠道实际支付金额
				billnoSn.setCheckDate(checkDate); // 收到回执报文后更新
				billnoSnService.update(billnoSn);

			} // 循环结束
				// b3.更新ChannelBatch多个字段
			batchProcessResultNotice.process(channelId, channelBatchno, billnoSn.getTranType(), sucessnum,
					sucessamount, unsucessnum, unsucessamount);

		} catch (final IOException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "错误：读文件’" + batchFileName + "‘出错！");
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (final IOException e) {
					Log4jUtil.error("文件关闭异常！", e);
					throw new BizException(TransReturnCode.code_9109, "错误：文件’" + batchFileName + "关闭异常！");
				}
			}
		}
	}

}
