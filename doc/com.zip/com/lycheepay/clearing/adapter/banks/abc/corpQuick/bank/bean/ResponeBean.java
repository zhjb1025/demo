package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean;

public class ResponeBean {
	// 返回：
	// 序号 字段 长度 格式 说明
	String tranCode;// 1 交易码 4 0210
	String processCode;// 2 处理码 6 330000-身份验证
	String terminateCode;// 3 终端号 8
	String merchantCode;// 4 商户号 15
	String bizCode;// 5 业务代码 2
	String account;// 6 主账号 19 左对齐右补空格
	String amt;// 7 交易金额 12 以分为单位不含小数点长度不足左补零 000000010000为100.00
	String sysTrack;// 8 系统跟踪号 20
	String tranTime;// 9 交易时间 6 hhmmss
	String tranDate;// 10 交易日期 8 YYYYMMDD
	String settleDate;// 11 清算日期 8 YYYYMMDD
	String receiverTag;// 12 受理方标识码 11 01030000041
	String sysCode;// 13 系统参考号 20
	String cardValidDate;// 14 卡有效期 4 YYMM
	String authorCode;// 15 授权码 2
	String currencyCode;// 16 货币代码 3
	String retCode;// 17 返回码 2
	String appendData;// 18 附加响应数据 25 左对齐右补空格 如果为余额查询交易，并且账号为商户对公账号时，返回商户当天代付和退货可用余额（以分为单位不含小数点）。
	String appendAmt;// 19 附加金额 20 以分为单位不含小数点长度不足左补零 000000010000为100.00
	String md5Code;// 20 MD5密码 32

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(final String tranCode) {
		this.tranCode = tranCode;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(final String processCode) {
		this.processCode = processCode;
	}

	public String getTerminateCode() {
		return terminateCode;
	}

	public void setTerminateCode(final String terminateCode) {
		this.terminateCode = terminateCode;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(final String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public String getBizCode() {
		return bizCode;
	}

	public void setBizCode(final String bizCode) {
		this.bizCode = bizCode;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(final String account) {
		this.account = account;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(final String amt) {
		this.amt = amt;
	}

	public String getSysTrack() {
		return sysTrack;
	}

	public void setSysTrack(final String sysTrack) {
		this.sysTrack = sysTrack;
	}

	public String getTranTime() {
		return tranTime;
	}

	public void setTranTime(final String tranTime) {
		this.tranTime = tranTime;
	}

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(final String tranDate) {
		this.tranDate = tranDate;
	}

	public String getSettleDate() {
		return settleDate;
	}

	public void setSettleDate(final String settleDate) {
		this.settleDate = settleDate;
	}

	public String getReceiverTag() {
		return receiverTag;
	}

	public void setReceiverTag(final String receiverTag) {
		this.receiverTag = receiverTag;
	}

	public String getSysCode() {
		return sysCode;
	}

	public void setSysCode(final String sysCode) {
		this.sysCode = sysCode;
	}

	public String getCardValidDate() {
		return cardValidDate;
	}

	public void setCardValidDate(final String cardValidDate) {
		this.cardValidDate = cardValidDate;
	}

	public String getAuthorCode() {
		return authorCode;
	}

	public void setAuthorCode(final String authorCode) {
		this.authorCode = authorCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(final String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(final String retCode) {
		this.retCode = retCode;
	}

	public String getAppendData() {
		return appendData;
	}

	public void setAppendData(final String appendData) {
		this.appendData = appendData;
	}

	public String getAppendAmt() {
		return appendAmt;
	}

	public void setAppendAmt(final String appendAmt) {
		this.appendAmt = appendAmt;
	}

	public String getMd5Code() {
		return md5Code;
	}

	public void setMd5Code(final String md5Code) {
		this.md5Code = md5Code;
	}

}
