package com.lycheepay.clearing.adapter.banks.abc.cross.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * Copy From com.lycheepay.clearing.adapter.banks.abc.credit.socket.SendBySocket4Abc
 */
public class SocketConnector {
	private int timeout = 60000;// 单位毫秒，6000。 业务交易超时，，用于传输数据时
	private int connectOutTime = 60000;// 单位毫秒，6000。 用于刚开始建立链接时,一般不需要改变此值

	public int getConnectOutTime() {
		return connectOutTime;
	}

	public void setConnectOutTime(final int connectOutTime) {
		this.connectOutTime = connectOutTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(final int timeout) {
		this.timeout = timeout;
	}

	/**
	 * 连接服务器 socket
	 * 
	 * @param socketPort
	 * @param socketIp
	 * @throws BizException
	 */
	private Socket connect(final String socketIp, final String socketPort) throws BizException {
		Socket socket = null;
		AssertUtils.notNull(socketIp, TransReturnCode.code_9108, "SocketIP不能为空!");
		AssertUtils.notNull(socketPort, TransReturnCode.code_9108, "SocketPort不能为空!");
		try {
			socket = new Socket();
			final SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
			socket.connect(socketAddress, connectOutTime);
			socket.setSoTimeout(timeout);
			// socket = new Socket(socketIp, Integer.parseInt(socketPort));
			// socket.setSoTimeout(timeout);
			Log4jUtil.info("connected!");
		} catch (final Exception e) {
			// 链接不成功，抛错误代码为9103
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9103, "通讯异常,连接 socket server 失败！！" + e.getMessage());
			// throw new BizException(e, "连接 socket server 失败！！");
		}
		return socket;
	}

	/**
	 * 断开服务器 socket
	 * 
	 * @throws BizException
	 */
	private void disconnect(final Socket socket) throws BizException {
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (final Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "断开 socket server 失败！！");
		}
	}

	private byte[] bulidHeader(int len) {
		StringBuilder sb = new StringBuilder("0000");
		sb.append(len);
		return sb.substring(sb.length() - 4).getBytes();
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 * 
	 * 王瑞
	 */
	public byte[] sendAndRecv(final String socketIp, final String socketPort, final byte[] sendMsg) throws BizException {
		Socket socket = null;
		BufferedOutputStream dos = null;// 发送值
		byte[] header = bulidHeader(sendMsg.length);
		socket = connect(socketIp, socketPort);

		Log4jUtil.info("[socket]{}->{}", socket.getLocalSocketAddress(), socket.getRemoteSocketAddress());
		Log4jUtil.info("[header]" + new String(header));
		Log4jUtil.info("[sendMsg]" + new String(sendMsg));

		try {
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(header);
			dos.write(sendMsg);
			dos.flush();
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			this.disconnect(socket);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
			// throw new BizException(e, "发送报文数据出错" + e.getMessage());
		}
		try {
			final BufferedInputStream bf = new BufferedInputStream(socket.getInputStream());
			final byte[] byteLengths = new byte[4];
			bf.read(byteLengths, 0, 4);// 前四位为报文长度
			Log4jUtil.info("返回报文长度：" + StringUtil.byteToString(byteLengths));
			if (!StringUtil.isNumeric(StringUtil.byteToString(byteLengths))) {
				Log4jUtil.info("错误的报文。");
				throw new BizException(TransReturnCode.code_9109,
						TransReturnCode.getNameByValue(TransReturnCode.code_9109) + " 错误的报文长度。");
			}
			final int msgLength = Integer.parseInt(StringUtil.byteToString(byteLengths));// 报文长度
			int i = 0;// 写到contents里面的偏移量
			final byte[] contents = new byte[msgLength];
			while (i < msgLength) {
				Log4jUtil.info("第" + (i + 1) + "次读取报文。");
				final int offLength = msgLength - i;
				final int readBytes = bf.read(contents, i, offLength);// 读到的真实长度
				i = i + readBytes;
			}
			Log4jUtil.info("Socket中得到的返回报文内容：" + StringUtil.byteToString(byteLengths)
					+ StringUtil.byteToString(contents));
			bf.close();
			return contents;
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
			// throw new BizException(e, "接收报文数据出错" + e.getMessage());
		} finally {
			this.disconnect(socket);
		}
	}
}
