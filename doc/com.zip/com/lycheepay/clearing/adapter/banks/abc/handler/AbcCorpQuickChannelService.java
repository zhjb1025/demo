package com.lycheepay.clearing.adapter.banks.abc.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.abc.corpQuick.kft.processor.AbcCorpQuickDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行快捷支付服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-18 下午5:51:10
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_QUICK_CHANNEL_SERVICE)
public class AbcCorpQuickChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CORP_QUICK_DIRECT_PROCESS)
	private AbcCorpQuickDirectProcess abcCorpQuickDirectProcess;

	public final static String channelId = ChannelIdEnum.ABC_QUICK_PAY.getCode();

	/**
	 * PS.报文账户验证
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#accountVerify(com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO accountVerify(final BankCardVerifyDTO accountVerify) {
		Log4jUtil.setLogClass("ABC_QUICK", "accVerify");
		Log4jUtil.info(accountVerify);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.MSG_ACCOUNT_VERIFY);
		param.setBizBean(accountVerify);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.MSG_ACCOUNT_VERIFY);

		try {
			if(BankCardType.CREDIT_CARD.equals(accountVerify.getBankCardType())){
				dto = ChannelResultUtil.covertResultDTO(abcCorpQuickDirectProcess.creditCardAccountVerify(param), dto);
			}else{
				dto = ChannelResultUtil.covertResultDTO(abcCorpQuickDirectProcess.accountVerify(param), dto);
			}
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		return dto;
	}

	/**
	 * PS.实时代扣
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) {
		Log4jUtil.setLogClass("ABC_QUICK", "direct");
		Log4jUtil.info(deductDTO);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);

		try {
			dto = ChannelResultUtil.covertResultDTO(abcCorpQuickDirectProcess.directDeduct(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * PS.实时代付
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#directPay(com.lycheepay.clearing.common.dto.trade.PayOutDTO)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public ClearingResultDTO directPay(final PayOutDTO pay) {
		Log4jUtil.setLogClass("ABC_QUICK", "direct");
		Log4jUtil.info(pay);

		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		param.setSn(pay.getTxnId());
		param.setCardType(pay.getBankCardType());
		param.setBorc(pay.getAccountType());
		param.setBizBean(pay);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.REAL_TIME_PAY);

		try {
			dto = ChannelResultUtil.covertResultDTO(abcCorpQuickDirectProcess.directPay(param), dto);

		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	/**
	 * 自适应退款(自适应退款需要区分撤销和退货)
	 * 
	 * @author 邱林 Leon.Qiu 2012-10-14 下午2:21:05
	 */
	@Override
	public ClearingResultDTO autoRealtimeRefund(RefundDTO refund) {
		Log4jUtil.setLogClass("ABC_QUICK", "refund");
		Log4jUtil.info(refund);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		param.setSn(refund.getTxnId());
		param.setCardType(refund.getBankCardType());
		param.setBorc(refund.getAccountType());
		param.setBizBean(refund);

		ClearingResultDTO dto = new ClearingResultDTO();
		dto.setChannelId(channelId);
		dto.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);

		try {
			dto = ChannelResultUtil.covertResultDTO(abcCorpQuickDirectProcess.dealAutoRealtimeRefund(param), dto);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}

		Log4jUtil.info(dto);
		return dto;
	}

	@Override
	public int getMaxNum() {
		return 10000;
	}

	/**
	 * 批量交易
	 */
	@Override
	public BatchSendResult processBatch(String channelBatchId, List<ChannelTempBill> payList, boolean repeatSend) {
		Log4jUtil.setLogClass("ABC_QUICK", "batch");
		Log4jUtil.info(payList);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setBizBean(payList);
		param.setClearingTransType(payList.get(0).getTransType());

		BatchSendResult brs = new BatchSendResult();
		try {
			brs = ChannelResultUtil.covertResultDTO(
					abcCorpQuickDirectProcess.batchBizDeal(param, repeatSend, channelBatchId), brs);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, brs);
		}
		return brs;
	}

	/**
	 * 批量交易结果查询 定时任务处理
	 */
	@Override
	public void timeQueryBatchTransResult() {
		Log4jUtil.setLogClass("ABC_QUICK", "batchQuery");
		try {
			abcCorpQuickDirectProcess.batchRetProcess();
		} catch (BizException e) {
			Log4jUtil.error(e);
		}
	}
}
