package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <p>Description:处理农行的账号</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-kxj
 * @version 1.0
 */
public class AbcCorpAccountProcess {

	/**
	 * 处理农行的账号
	 * 
	 * @param oriAccount 转入的账号
	 * @throws BizException
	 * @return 处理完成后的账号
	 */
	public static String proAccount(final String oriAccount) {
		Log4jUtil.info("____________处理农行的账号:" + oriAccount + "____________");
		if (oriAccount.length() < 10) {
			Log4jUtil.info("账号:" + oriAccount + "长度小于10，不做账号处理，返回传入账号");
			return oriAccount;
		}
		String newAccount = "";
		// 处理原则
		// 1、卡是19位
		// 2、存折是17个数字
		// 3、卡就是95599，6228开头的
		if (oriAccount.length() == 19) {
			newAccount = oriAccount;
		} else if (oriAccount.contains("-")) {
			newAccount = oriAccount;
		} else {
			newAccount = oriAccount.substring(0, 2) + "-" + oriAccount.substring(2);
		}
		return newAccount;
	}

	/**
	 * 单笔 --- 如果是存折截取存折前两位作为省市代码，填写的账号不填账号的前两位(如果有-，也截掉-) 处理 单笔 的账户处理
	 * 
	 * @param oriAccount
	 * @return 根据 单笔 要求，处理后的账户
	 */
	public static String proSingleAccount(final String oriAccount) {
		Log4jUtil.info("____________处理农行单笔的账号:" + oriAccount + "____________");
		if (oriAccount.length() < 10) {
			Log4jUtil.info("账号:" + oriAccount + "长度小于10，不做单笔的账号的处理，返回传入账号");
			return oriAccount;
		}
		String newAccount = "";
		// 处理原则
		// 1、卡是19位
		// 2、存折是17个数字
		// 3、卡就是95599，6228开头的
		if (oriAccount.length() == 19) {
			newAccount = oriAccount;
		} else if (oriAccount.contains("-")) {
			newAccount = oriAccount.substring(oriAccount.indexOf("-") + 1);
		} else {
			newAccount = oriAccount.substring(2);
		}
		return newAccount;
	}

	/**
	 * 单笔 --- 如果是存折截取存折前两位作为省市代码，填写的账号不填账号的前两位 处理 单笔 的账户省市代码
	 * 
	 * @param oriAccount
	 * @return 根据 单笔 要求，处理后的账户省市代码
	 */
	public static String proSingleAddrNo(final String oriAccount) {
		Log4jUtil.info("____________处理农行单笔的省市代码，传入账号为:" + oriAccount + "____________");
		if (oriAccount.length() < 10) {
			Log4jUtil.info("账号:" + oriAccount + "长度小于10，不做单笔的账号的处理，返回空串");
			return "";
		}
		String newAccount = "";
		// 处理原则
		// 1、卡是19位
		// 2、存折是17个数字
		// 3、卡就是95599，6228开头的
		if (oriAccount.length() == 19) {
			newAccount = "";
		} else {
			newAccount = oriAccount.substring(0, 2);
		}
		return newAccount;
	}
}
