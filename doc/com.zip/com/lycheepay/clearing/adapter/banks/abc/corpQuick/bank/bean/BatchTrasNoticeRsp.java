package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.bean;

public class BatchTrasNoticeRsp {
	String backSeq;// 1 银行流水号 20 YYYYMMDD
	String tranDate;// 2 交易日期 8 YYYYMMDD
	String tranTime;// 3 交易时间 6 hhmmss
	String fileName;// 4 文件名 30
	String retCode;// 5 返回码 4
	String retMsg;// 6 返回信息 30

	public String getBackSeq() {
		return backSeq;
	}

	public void setBackSeq(final String backSeq) {
		this.backSeq = backSeq;
	}

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(final String tranDate) {
		this.tranDate = tranDate;
	}

	public String getTranTime() {
		return tranTime;
	}

	public void setTranTime(final String tranTime) {
		this.tranTime = tranTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(final String fileName) {
		this.fileName = fileName;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(final String retCode) {
		this.retCode = retCode;
	}

	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(final String retMsg) {
		this.retMsg = retMsg;
	}
}
