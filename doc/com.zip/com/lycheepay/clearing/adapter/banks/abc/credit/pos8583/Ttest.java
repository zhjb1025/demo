package com.lycheepay.clearing.adapter.banks.abc.credit.pos8583;


public class Ttest {

	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		// try {
		// MsgPack msgPack = new MsgPack();
		// String tpdu="6000000000";
		// MsgPackUtils.createTpduField(msgPack, ByteUtils.strToBcd(tpdu));
		//
		// String head="6001013000";
		// MsgPackUtils.createHeadField(msgPack, ByteUtils.strToBcd(head));
		//
		// String accountNo="100168";
		// MsgPackUtils.createAccountField(msgPack, accountNo);
		//
		// String msgType="0100";
		// MsgPackUtils.createMsgType(msgPack, msgType);
		//
		// System.out.println(msgPack.getBytes().length);
		// System.out.println(ByteUtils.bcdToStr(msgPack.getBytes()));
		// } catch (BizException e) {
		// Log4jUtil.error( e);
		// }
	}
}
