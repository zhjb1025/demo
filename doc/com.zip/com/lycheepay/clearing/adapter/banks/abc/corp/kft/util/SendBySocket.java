package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import org.apache.commons.io.IOUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.RunTime;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


public class SendBySocket {
	private int timeout = 60000;// 单位毫秒，6000。 业务交易超时，，用于传输数据时
	private int connectOutTime = 60000;// 单位毫秒，6000。 用于刚开始建立链接时,一般不需要改变此值
	private final int maxTryTime = 3;
	private int currentTryTime = 0;

	public int getConnectOutTime() {
		return connectOutTime;
	}

	public void setConnectOutTime(final int connectOutTime) {
		this.connectOutTime = connectOutTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(final int timeout) {
		this.timeout = timeout;
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public String sendAndRecv(final String socketIp, final String socketPort, final String sendMsg)
			throws BizException {
		Log4jUtil.info("socketIp:{},socketPort:{},sendMsg:{}", socketIp, socketPort, sendMsg);
		String xmlStr = "";
		BufferedOutputStream dos = null;// 发送值
		DataInputStream dis = null;// 返回值
		final RunTime time = new RunTime();
		Socket socket = connect(socketIp, socketPort);
		time.endAndStart("Socket链接耗时:");
		try {
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(sendMsg.getBytes("GBK"));
			dos.flush();
			time.endAndStart("Socket发送耗时:");
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			IOUtils.closeQuietly(dos);
			this.disconnect(socket);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
		}
		try {
			dis = new DataInputStream(socket.getInputStream());

			byte rcvLen[] = new byte[7];// 包头固定为7个字节长，第1字节为是否加密标志（0-不加密，1-加密）。后6个字节是数据包的长度，即将报文长度直接转为字符串存储，长度不足6位则右边用空格补足
			dis.read(rcvLen);
			String head = new String(rcvLen, "GBK").trim();// 包头
			Log4jUtil.info("head:{}", head);
			int len = Integer.valueOf(head.substring(1, head.length()));
			Log4jUtil.info("len:{}", len);
			if (len > 0) {
				byte rcvData[] = new byte[len];
				// dis.read(rcvData);// 接收返回报文的内容
				int readCount = 0; // 已经成功读取的字节的个数
				while (readCount < len) {
					Log4jUtil.info("readCount:{}", readCount);
					readCount += dis.read(rcvData, readCount, len - readCount);
					Log4jUtil.info("++readCount:" + readCount);
				}

				xmlStr = new String(rcvData, "GBK");
			}
			/*
			 * final char[] contenttsChar = new char[1024]; final BufferedReader bf = new
			 * BufferedReader(new InputStreamReader(dis, "GBK")); final StringBuffer sb = new
			 * StringBuffer(); int i = 0; while ((i = bf.read(contenttsChar)) != -1) {
			 * sb.append(contenttsChar, 0, i); } xmlStr = sb.toString();
			 */
			time.endAndStart("Socket接收耗时:");
			Log4jUtil.info("SocketProcess中得到的返回报文内容：" + xmlStr.trim());
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		} finally {
			IOUtils.closeQuietly(dos);
			IOUtils.closeQuietly(dis);
			this.disconnect(socket);
		}
		return xmlStr;
	}


	/**
	 * 连接服务器 socket
	 * 
	 * @param socketPort
	 * @param socketIp
	 * @throws ClearingAdapterBizCheckedException
	 */
	private Socket connect(final String socketIp, final String socketPort) throws BizException {
		Socket socket = new Socket();
		AssertUtils.notNull(socketIp, TransReturnCode.code_9108, "SocketIP不能为空");
		AssertUtils.notNull(socketPort, TransReturnCode.code_9108, "SocketPort不能为空");
		while (!socket.isConnected()) {
			try {
				currentTryTime++;
				Log4jUtil.info("进行第" + currentTryTime + "次链接。");
				socket = connect1(socketIp, socketPort);
			} catch (final Exception e) {
				// 若超过最大链接次数依然未成功，则抛异常
				try {
					Thread.sleep(1000);
				} catch (final InterruptedException e1) {
					Log4jUtil.error(e1.getMessage(), e);
				}
				if (currentTryTime >= maxTryTime) {
					throw new BizException(e, TransReturnCode.code_9103, e.getMessage());
				}
			}
		}
		return socket;
	}

	private Socket connect1(final String socketIp, final String socketPort) throws Exception {
		Socket socket = new Socket();
		final SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
		socket.connect(socketAddress, connectOutTime);
		socket.setSoTimeout(timeout);
		Log4jUtil.info("{}:{} connected!", socketIp, socketPort);
		return socket;
	}

	/**
	 * 断开服务器 socket
	 * 
	 * @throws BizException
	 */
	private void disconnect(final Socket socket) {
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (final IOException e) {
			Log4jUtil.error(e);
		}
	}

}
