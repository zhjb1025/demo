package com.lycheepay.clearing.adapter.banks.abc.credit.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.MsgPack4Abc;
import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.MsgPackUtils4Abc;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.RunTime;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农业银行银企直连socket发送使用方式</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 上午3:58:18
 */
public class SendBySocket4Abc {
	private int timeout = 60000;// 单位毫秒，6000。 业务交易超时，，用于传输数据时
	private int connectOutTime = 60000;// 单位毫秒，6000。 用于刚开始建立链接时,一般不需要改变此值

	public int getConnectOutTime() {
		return connectOutTime;
	}

	public void setConnectOutTime(final int connectOutTime) {
		this.connectOutTime = connectOutTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(final int timeout) {
		this.timeout = timeout;
	}

	public byte[] SendAndRecvByte(final String socketIp, final String socketPort, final byte[] sendMsg)
			throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:" + new String(sendMsg));
		Socket socket = null;
		BufferedOutputStream dos = null;// 发送值
		socket = connect(socketIp, socketPort);
		try {
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(sendMsg);
			dos.flush();
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			this.disconnect(socket);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
			// throw new BizException(e, "发送报文数据出错" + e.getMessage());
		}
		try {
			final BufferedInputStream bf = new BufferedInputStream(socket.getInputStream());
			final byte[] byteLengths = new byte[4];
			bf.read(byteLengths, 0, 4);// 前四位为报文长度
			Log4jUtil.info("返回报文长度：" + StringUtil.byteToString(byteLengths));
			if (!StringUtil.isNumeric(StringUtil.byteToString(byteLengths))) {
				Log4jUtil.info("错误的报文。");
				throw new BizException(TransReturnCode.code_9109,
						TransReturnCode.getNameByValue(TransReturnCode.code_9109) + " 错误的报文长度。");
			}
			final int msgLength = Integer.parseInt(StringUtil.byteToString(byteLengths));// 报文长度
			int i = 0;// 写到contents里面的偏移量
			final byte[] contents = new byte[msgLength];
			while (i < msgLength) {
				Log4jUtil.info("第：" + (i + 1) + "次读取报文。");
				final int offLength = msgLength - i;
				final int readBytes = bf.read(contents, i, offLength);// 读到的真实长度
				i = i + readBytes;
			}
			Log4jUtil.info("Socket中得到的返回报文内容：" + StringUtil.byteToString(byteLengths)
					+ StringUtil.byteToString(contents));
			bf.close();
			return contents;
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
			// throw new BizException(e, "接收报文数据出错" + e.getMessage());
		} finally {
			this.disconnect(socket);
		}
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public String sendAndRecv(final String socketIp, final String socketPort, final String sendMsg) throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:" + sendMsg);
		String rspmsg = "";
		Socket socket = null;
		BufferedOutputStream dos = null;// 发送值
		DataInputStream dis = null;// 返回值
		socket = connect(socketIp, socketPort);
		try {
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(sendMsg.getBytes("GBK"));
			dos.flush();
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			this.disconnect(socket);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
			// throw new BizException(e, "发送报文数据出错" + e.getMessage());
		}
		try {
			dis = new DataInputStream(socket.getInputStream());
			final char[] contenttsChar = new char[1024];
			final BufferedReader bf = new BufferedReader(new InputStreamReader(dis, "GBK"));
			final StringBuffer sb = new StringBuffer();
			int i = 0;
			while ((i = bf.read(contenttsChar)) != -1) {
				sb.append(contenttsChar, 0, i);
			}
			rspmsg = sb.toString();
			Log4jUtil.info("SocketProcess中得到的返回报文内容：" + rspmsg);
			dis.close();
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
			// throw new BizException(e, "接收报文数据出错" + e.getMessage());
		} finally {
			this.disconnect(socket);
		}
		return rspmsg;
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public MsgPack4Abc sendAndRecv(final String socketIp, final String socketPort, final byte[] sendMsg)
			throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:"
				+ MsgPackUtils4Abc.toHexString(sendMsg));
		Socket socket = connect(socketIp, socketPort);
		try {
			socket.getOutputStream().write(sendMsg);
			socket.getOutputStream().flush();
		} catch (final Exception e) {
			this.disconnect(socket);
			Log4jUtil.error(e);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
		}
		MsgPack4Abc pack = new MsgPack4Abc();
		try {
			final InputStream in = socket.getInputStream();
			final byte[] buffer = new byte[2048];
			while (true) {
				try {
					final int len = in.read(buffer);
					// 长度-1时,退出读.
					if (len == -1) {
						Log4jUtil.debug("读取长度-1");
						return pack;
					}
					final byte[] msg = ArrayUtils.subarray(buffer, 0, len);

					// byte[] msg =
					// MsgPackUtils4Abc.hexStringToBytes("00FD600000000008102038008002C0000E940000000053165048102551303031324A303033303931303334343033353331313030313100330138FDBF5BD6152ED86819290D0B499E5E9772D877E6EDADF99772D877E6EDADF90012303030303132303030303032015076657273696F6E31202076657273696F6E31202061626320202020202020202020202020202020202020202020202020202020202020202020202020CEF7CFE7C9D0B6BCC0F1C6B7B5EA20202020202020202020202020202020202020202020202020203533313100000000DDC0000000000000FC000000800000000000000000040202040200009999999900009999999901010000");

					// if (//XXX Leon Log4jUtilisDebugEnabled()) {
					Log4jUtil.info("从{}收到消息:{}", socketIp, MsgPackUtils4Abc.toHexString(msg));
					// break;
					// }
					try {
						pack = unpackMsg(pack, msg, socketIp);
					} catch (final Throwable e) {// 解包出错,清空未解析完成的包,等待下批数据;如下批数据不是从头开始,只能断开连接.
						Log4jUtil.error(e);
					}
				} catch (final SocketTimeoutException e) {
					Log4jUtil.error("读消息超时," + socketIp);
					throw e;
				}
			}
		} catch (final Exception e) {
			Log4jUtil.error(e, e);
		} finally {
			this.disconnect(socket);
		}
		return pack;
	}

	/**
	 * 解包.
	 * 
	 * @param pack 未完成的包.
	 * @param msg 网络一次读到的字节流,可能为多个消息包(包括不完整的)
	 * @throws BizException
	 */
	public static MsgPack4Abc unpackMsg(final MsgPack4Abc pack, final byte[] msg, final String socketIp)
			throws BizException {
		try {
			Log4jUtil.info("execute unpackMsg() 方法，解包开始。");
			if (null == msg) {
				return pack;
			}
			final int msgLen = msg.length;
			Log4jUtil.info("msgLen===" + msgLen);
			int unpackedLen = 0;
			while (unpackedLen < msgLen) {
				Log4jUtil.info(unpackedLen + "===" + msgLen);
				unpackedLen += pack.unpack4Abc(msg);
				// 解包完成, 派发消息包, 并初始化新的空包.
				if (pack.isFull()) {
					// if (Log4jUtil.isDebugEnabled()) {
					// Log4jUtil.debug(StringUtil.r(
					// "收到完整消息包并派发给处理线程,socketIp:{?},消息:{?}",
					// socketIp, MsgPackUtils4Abc.toHexString(pack)));
					// }
					Log4jUtil.info("收到完整消息包并派发给处理线程,socketIp:{},消息:{}", socketIp, MsgPackUtils4Abc.toHexString(pack));
					return pack;
				}
			}
			Log4jUtil.info("execute unpackMsg() 方法，解包完成。");
		} catch (final Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		}
		return pack;
	}

	/**
	 * 连接服务器 socket
	 * 
	 * @param socketPort
	 * @param socketIp
	 * @throws BizException
	 */
	private Socket connect(final String socketIp, final String socketPort) throws BizException {
		Socket socket = null;
		AssertUtils.notNull(socketIp, TransReturnCode.code_9108, "SocketIP不能为空!");
		AssertUtils.notNull(socketPort, TransReturnCode.code_9108, "SocketPort不能为空!");
		try {
			socket = new Socket();
			final SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
			socket.connect(socketAddress, connectOutTime);
			socket.setSoTimeout(timeout);
			// socket = new Socket(socketIp, Integer.parseInt(socketPort));
			// socket.setSoTimeout(timeout);
			Log4jUtil.info("connected!");
		} catch (final Exception e) {
			// 链接不成功，抛错误代码为9103
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9103, "通讯异常,连接 socket server 失败！！" + e.getMessage());
			// throw new BizException(e, "连接 socket server 失败！！");
		}
		return socket;
	}

	/**
	 * 断开服务器 socket
	 * 
	 * @throws BizException
	 */
	private void disconnect(final Socket socket) throws BizException {
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (final Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "断开 socket server 失败！！");
		}
	}

	public static void main(final String args[]) {
		final byte[] msg = MsgPackUtils4Abc
				.hexStringToBytes("00C260000000000210703805801AD0801516404117555501319502A0000000000000220009590923111121090201201401040000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000031303030303031393631324A323531324A3030333039313033343430333533313130303131244434414442444242443244374232424242344536443444413135360005A0020100000012303030303132303030303032822CDEDF5B049EA7");
		MsgPack4Abc pack = new MsgPack4Abc();
		try {
			pack = unpackMsg(msg, "999.999.999.999");
		} catch (final Throwable e) {// 解包出错,清空未解析完成的包,等待下批数据;如下批数据不是从头开始,只能断开连接.
			Log4jUtil.error(e);
		}
		System.out.println(pack);
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public byte[] sendAndRecvDonotUnpack(final String socketIp, final String socketPort, final byte[] sendMsg)
			throws BizException {

		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:" + sendMsg);
		Socket socket = null;
		socket = connect(socketIp, socketPort);
		try {
			socket.getOutputStream().write(sendMsg);
			socket.getOutputStream().flush();
		} catch (final Exception e) {
			this.disconnect(socket);
			Log4jUtil.error(e);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
		}
		byte[] msg = null;
		try {
			final InputStream in = socket.getInputStream();
			final byte[] buffer = new byte[2048];
			while (true) {
				try {
					final int len = in.read(buffer);
					// 长度-1时,退出读.
					if (len == -1) {
						Log4jUtil.debug("读取长度-1");
						return null;
					}
					msg = new byte[ArrayUtils.subarray(buffer, 0, len).length];
					msg = ArrayUtils.subarray(buffer, 0, len);

					Log4jUtil.info("SOCKET通信，从{}收到消息:{}", socketIp, MsgPackUtils4Abc.toHexString(msg));
				} catch (final SocketTimeoutException e) {
					Log4jUtil.error("读消息超时," + socketIp);
					throw e;
				}
			}
		} catch (final Exception e) {
			Log4jUtil.error(e, e);
		} finally {
			this.disconnect(socket);
		}
		return msg;

	}

	public byte[] sendAndRecvDonotUnpackByte(final String socketIp, final String socketPort, final byte[] sendMsg)
			throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:"
				+ MsgPackUtils4Abc.toHexString(sendMsg));
		Socket socket = null;
		BufferedOutputStream dos = null;// 发送值
		final RunTime time = new RunTime();
		socket = connect(socketIp, socketPort);
		try {
			time.endAndStart("Socket链接耗时:");
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(sendMsg);
			dos.flush();
			time.endAndStart("Socket发送耗时:");
		} catch (final Exception e) {
			Log4jUtil.info("socket发送报文过程中失败" + e.getMessage(), e);
			this.disconnect(socket);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
			// throw new BizException(e, "发送报文数据出错" + e.getMessage());
		}
		try {
			final BufferedInputStream bf = new BufferedInputStream(socket.getInputStream());
			final InputStream in = socket.getInputStream();
			final byte[] buffer = new byte[2048];
			final int len = in.read(buffer);
			// 长度-1时,退出读.
			if (len == -1) {
				Log4jUtil.info("读取长度-1,错误的报文。");
				throw new BizException(TransReturnCode.code_9109,
						TransReturnCode.getNameByValue(TransReturnCode.code_9109) + " 错误的报文长度。");
			}
			byte[] msg = new byte[ArrayUtils.subarray(buffer, 0, len).length];
			msg = ArrayUtils.subarray(buffer, 0, len);

			Log4jUtil.info("SOCKET通信，从{}收到消息:{}", socketIp, MsgPackUtils4Abc.toHexString(msg));
			// byte[] byteLengths = new byte[4];
			// bf.read(byteLengths, 0, 4);// 前四位为报文长度
			// Log4jUtil.info("返回报文长度：" + MsgPackUtils4Abc.toHexString(byteLengths));
			// Log4jUtil.info("返回报文长度：" +
			// MsgPackUtils4Abc.hexStringToBytes(byteLengths.toString()));
			// String lenStr=new
			// String(MsgPackUtils4Abc.hexStringToBytes(StringUtil.byteToString(byteLengths)));
			// if (!StringUtil.isNumeric(lenStr)) {
			// Log4jUtil.info("错误的报文。");
			// throw new BizException(TransReturnCode.code_9109,
			// TransReturnCode.code_9109.getName() + " 错误的报文长度。");
			// }
			// int msgLength = Integer.parseInt(lenStr);// 报文长度
			// int i = 0;// 写到contents里面的偏移量
			// byte[] contents = new byte[msgLength];
			// while (i < msgLength) {
			// Log4jUtil.info("第：" + (i + 1) + "次读取报文。");
			// int offLength = msgLength - i;
			// int readBytes = bf.read(contents, i, offLength);// 读到的真实长度
			// i = i + readBytes;
			// }
			time.endAndStart("Socket接收耗时:");
			bf.close();
			return msg;
		} catch (final Exception e) {
			Log4jUtil.info("socket接收报文过程中失败" + e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage() + "接受流读取出错！");
		} finally {
			this.disconnect(socket);
		}
	}

	/**
	 * 解包.
	 * 
	 * @param pack 未完成的包.
	 * @param msg 网络一次读到的字节流,可能为多个消息包(包括不完整的)
	 * @throws BizException
	 */
	public static MsgPack4Abc unpackMsg(final byte[] msg, final String socketIp) throws BizException {
		final MsgPack4Abc pack = new MsgPack4Abc();
		try {
			Log4jUtil.info("execute unpackMsg() 方法，解包开始。");
			if (null == msg) {
				return pack;
			}
			final int msgLen = msg.length;
			Log4jUtil.info("msgLen===" + msgLen);
			int unpackedLen = 0;
			while (unpackedLen < msgLen) {
				Log4jUtil.info(unpackedLen + "===" + msgLen);
				unpackedLen += pack.unpack4Abc(msg);
				// 解包完成, 派发消息包, 并初始化新的空包.
				if (pack.isFull()) {
					Log4jUtil.info("从地址socketIp:{},解析所有消息:{}", socketIp, MsgPackUtils4Abc.toHexString(pack));
					break;
				}
			}
			Log4jUtil.info("execute unpackMsg() 方法，解包完成。");
			return pack;
		} catch (final Exception e) {
			Log4jUtil.info("解包过程发生异常异常信息为" + e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		}
	}
}
