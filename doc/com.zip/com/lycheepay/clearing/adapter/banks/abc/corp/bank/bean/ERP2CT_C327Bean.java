package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_C327Bean {

	// ERP2CT_C327 单笔代扣（对公）（C327） 请求报文字段
	private String Amt; // 金额
	private String DbAccNo; // 借方账号（卡号）
	private String DbProv; // 借方账号省市代码
	private String DbCur; // 借方账号货币码
	private String CrAccNo; // 贷方账号
	private String CrProv; // 贷方账号省市代码
	private String CrCur; // 贷方账号货币码
	private String CrLogAccNo; // 贷方多级帐簿
	private String ConFlag; // 合约校验标志
	private String DbAccName; // 借方户名
	private String CrAccName; // 贷方户名
	private String CshDraFlag; // 钞汇标志
	private String ExchangeType; // 合约类型
	private String Postscript; // 附言

	public String getAmt() {
		return Amt;
	}

	public void setAmt(final String amt) {
		Amt = amt;
	}

	public String getDbAccNo() {
		return DbAccNo;
	}

	public void setDbAccNo(final String dbAccNo) {
		DbAccNo = dbAccNo;
	}

	public String getDbProv() {
		return DbProv;
	}

	public void setDbProv(final String dbProv) {
		DbProv = dbProv;
	}

	public String getDbCur() {
		return DbCur;
	}

	public void setDbCur(final String dbCur) {
		DbCur = dbCur;
	}

	public String getCrAccNo() {
		return CrAccNo;
	}

	public void setCrAccNo(final String crAccNo) {
		CrAccNo = crAccNo;
	}

	public String getCrProv() {
		return CrProv;
	}

	public void setCrProv(final String crProv) {
		CrProv = crProv;
	}

	public String getCrCur() {
		return CrCur;
	}

	public void setCrCur(final String crCur) {
		CrCur = crCur;
	}

	public String getCrLogAccNo() {
		return CrLogAccNo;
	}

	public void setCrLogAccNo(final String crLogAccNo) {
		CrLogAccNo = crLogAccNo;
	}

	public String getConFlag() {
		return ConFlag;
	}

	public void setConFlag(final String conFlag) {
		ConFlag = conFlag;
	}

	public String getDbAccName() {
		return DbAccName;
	}

	public void setDbAccName(final String dbAccName) {
		DbAccName = dbAccName;
	}

	public String getCrAccName() {
		return CrAccName;
	}

	public void setCrAccName(final String crAccName) {
		CrAccName = crAccName;
	}

	public String getCshDraFlag() {
		return CshDraFlag;
	}

	public void setCshDraFlag(final String cshDraFlag) {
		CshDraFlag = cshDraFlag;
	}

	public String getExchangeType() {
		return ExchangeType;
	}

	public void setExchangeType(final String exchangeType) {
		ExchangeType = exchangeType;
	}

	public String getPostscript() {
		return Postscript;
	}

	public void setPostscript(final String postscript) {
		Postscript = postscript;
	}

}
