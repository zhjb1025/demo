package com.lycheepay.clearing.adapter.banks.abc.credit.kft.processor;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.credit.service.AbcCreditChannelParmService;
import com.lycheepay.clearing.adapter.banks.abc.credit.service.AbcCreditTradeService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P> 农业银行信用卡银企直连处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 上午3:10:52
 */
@Service(ClearingAdapterAnnotationName.ABC_CREDIT_DIRECT_PROCESS)
public class AbcCreditDirectProcess extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.ABC_CREDIT_TRADE_SERVICE)
	private AbcCreditTradeService abcCreditTradeService;

	@Autowired
	@Qualifier((ClearingAdapterAnnotationName.ABC_CREDIT_CHANNEL_PARM_SERVICE))
	private AbcCreditChannelParmService abcCreditChannelParmService;

	// BatchRefundDistributeService batchRefundDistributeService = (BatchRefundDistributeService)
	// SpringContext
	// .getService("batchRefundDistributeService");

	/**
	 * <p>实时代扣</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午3:32:05
	 */
	public ReturnState directDeduct(final Param param) throws BizException {
		Log4jUtil.info("农行信用卡做消费开始(MOTO消费)");
		return doRealTimeAgentCollection(param);
	}

	/**
	 * <p>农业银行信用卡实时代扣</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午3:32:49
	 */
	public ReturnState doRealTimeAgentCollection(final Param param) throws BizException {
		ReturnState returnState = null;
		// MOTO消费
		try {
			returnState = motoConsume(param);

		} catch (final BizException e) {
			if ("1234567".equals(e.getErrorCode())) {
				Log4jUtil.info("农行信用卡MOTO消费报文执行中，发现签到返回参数不是当天，中断");
				Log4jUtil.info("农行信用卡重新做签到");
				try {
					signIn();
				} catch (final Exception signE) {
					throw new BizException("农行信用卡做MOTO消费报文发生异常" + e);
				}
				Log4jUtil.info("农行信用卡重新做MOTO消费报文开始");
				returnState = doRealTimeAgentCollection(param);
			} else {
				throw new BizException("农行信用卡做MOTO消费报文发生异常" + e);
			}
		}
		if (null == returnState) {
			Log4jUtil.info("农行信用卡做MOTO消费报文发生异常");
			throw new BizException("农行信用卡做MOTO消费报文发生异常");
		}

		Log4jUtil.info("农行信用卡做MOTO消费报文完成");
		// 检查是否有消息返回，否则直接调用冲正报文
		if (null == returnState.getBankRetCode()) {
			// 这里确定是为MOTO消费冲正
			try {
				returnState = dueHedging(param, returnState.getSn(), "00A000");
				returnState.setChannelCode(TransReturnCode.code_9900);
				returnState.setReturnState(PayState.FAILED_STR);
				Log4jUtil.info("农行信用卡MOTO消费报文执行无报文返回，完成自动冲正，并设置交易失败");
			} catch (final BizException e) {
				Log4jUtil.info("农行信用卡MOTO消费报文执行无报文返回，完成自动冲正过程中，失败");
			}
		}
		return returnState;
	}

	/**
	 * 农行信用卡自动冲正
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	private ReturnState dueHedging(final Param param, final String organizedDealSn, final String organizedDealCode)
			throws BizException {
		final ReturnState returnState = abcCreditTradeService
				.dueHedgingTrade(param, organizedDealSn, organizedDealCode);
		Log4jUtil.info("===Abc online dueHedging finish");
		return returnState;
	}

	/**
	 * <p>农行信用卡消费</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 上午3:35:58
	 */
	private ReturnState motoConsume(final Param param) throws BizException {
		final ReturnState returnState = abcCreditTradeService.motoConsumeTrade(param);
		Log4jUtil.info("===Abc online MOTOconsume finish");
		return returnState;
	}

	/**
	 * 农行信用卡自适应退款
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws Exception
	 */
	public ReturnState autoRealtimeRefund(final Param param) throws BizException {
		ReturnState returnState = null;
		try {
			returnState = abcCreditTradeService.doAutoRealtimeRefund(param);
			Log4jUtil.info("===Abc online AutoRealtimeRefund finish");

		} catch (final BizException e) {
			throw new BizException("农行信用卡做自适应退款报文发生异常" + e);
		}
		if (null == returnState) {
			Log4jUtil.info("农行信用卡做自适应退款报文发生异常");
			throw new BizException("农行信用卡做自适应退款报文发生异常");
		}
		return returnState;

	}

	/**
	 * 农行信用卡结算通知/联机签退
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	public void settleNotice(final String field48) throws BizException {
		abcCreditTradeService.settleNoticeTrade(field48);
		Log4jUtil.info("===Abc online settleNotice finish");
	}

	/**
	 * 农行信用卡联机签到
	 * 
	 * @param param
	 * @return 处理结果
	 * @throws BizException
	 */
	public void signIn() throws Exception {
		abcCreditTradeService.signInTrade();
		Log4jUtil.info("===Abc online sign in finish");
	}

	// /**
	// * 主处理方法
	// *
	// * @throws Exception
	// */
	// @Override
	// public ReturnState deal(final Param param) throws BizException {
	// logger.info("进入农行信用卡处理器" + param.getTransType() + ":" + param.getChannelTransType());
	// Log4jUtil.setLogClass("channelLog" + File.separator + channelId, channelId + "web");
	// if (param.getChannelTransType().equals(ChannelTransType.Real_Time_Agent_Collection)) { //
	// 单笔实时代扣
	// Log4jUtil.info("农行信用卡做消费开始(MOTO消费)");
	// return doRealTimeAgentCollection(param);
	// } else if (param.getChannelTransType().equals(ChannelTransType.PayRefund)) { // 交易退款与调账退款
	// Log4jUtil.info("农行信用卡做退款开始");
	// return doPayRefund(param);
	// } else if (param.getChannelTransType().equals(ChannelTransType.Auto_Realtime_Refund)) { //
	// 自适应实时退款
	// Log4jUtil.info("农行信用卡做自适应实时退款开始");
	// return doAutoRealtimeRefund(param);
	// } else {
	// throw new BizException("异常，发起的是农行不支付的业务类型：" + param.getChannelTransType());
	// }
	// }

	// public ReturnState doPayRefund(final Param param) throws BizException {
	// String logPrefix = "";
	// logPrefix = " " + param.getChannelId() + ChannelId.getNameByValue(param.getChannelId()) +
	// " ";
	// final String logMsg = logPrefix + "进入调账类批量退款处理";
	// Log4jUtil.info(logMsg);
	// List<String> channelBatchIdList;
	// try {
	// // 清分处理.成功后
	// // 批量退款表,状态为03已触发退款
	// // 产生渠道批量退款记录,状态为00待发送;
	// // 渠道退款流水,状态为03已触发退款
	// channelBatchIdList = batchRefundDistributeService.batchRefund(param, 1);
	// } catch (final Exception e) {
	// // 清分处理.失败后
	// // 批量退款表,状态为06-触发退款失败
	// // 没产生渠道批量退款记录,无状态
	// // 渠道退款流水,状态为02-未处理
	// if (param.getRepeatFlag().equals("N")) {
	// batchRefundDistributeService.updateBatchRefund(param);
	// }
	// throw new BizException(logPrefix + "批量退款处理失败。");
	// }
	// Log4jUtil.info("农行信用卡退款清分完毕");
	// // 获取清分包号list
	// final List<ReturnState> returnStateList = new ArrayList<ReturnState>();
	// ReturnState rssub = null;
	// // Boolean allSuccess = false;
	// if (channelBatchIdList != null) {
	// for (int i = 0; i < channelBatchIdList.size(); i++) {
	// try {// 批量转实时 包含以下步骤:1.发送到银行2.接收回执3.回执处理.
	// rssub = abcCreditTradeService.batchRefundByAPI(channelBatchIdList.get(i));
	// } catch (final Exception e) {
	// // 此异常表示没有成功发送到银行. 像这种情况是可以重发退款的.
	// // 批量退款表,状态为03- 已触发退款
	// // 渠道批量退款,09: 发送失败
	// // 渠道退款流水,状态为 03- 已触发退款
	// Log4jUtil.error(e);
	// rssub = new ReceiveParam();
	// rssub.setReturnState(PayState.FAILED_TRN);
	// rssub.setBankRetCode("9999");
	// rssub.setBankPostScript(e.getMessage());
	// abcCreditTradeService.updateChannelBatchRefundToFail(channelBatchIdList.get(i), rssub);
	// }
	// returnStateList.add(rssub);
	// }
	// }
	// final ReturnState rs = new ReturnState();
	// rs.setChannelCode("0000");
	// rs.setReturnState(PayState.SUCCEED_RTN);
	// rs.setReturnObj(returnStateList);
	//
	// Log4jUtil.info("农行信用卡退款处理完毕");
	// return rs;
	// }

	// /**
	// * 农行信用卡消费
	// *
	// * @param param
	// * @return 处理结果
	// * @throws BizException
	// */
	// @Deprecated()
	// public ReturnState consume(final Param param) {
	// abcCreditTradeService.consumeTrade(param);
	// // 组returnState
	// return null;
	// }
	//

}
