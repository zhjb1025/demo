package com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean;

import org.soofa.core.model.BaseObject;

/**
 * 农行备付金报表文件处理回执(涵盖CFRA33/CQLA35/CQLA36的回执字段)
 * @author KenHuang
 *
 */
public class AbcSRResp extends BaseObject{

	private static final long serialVersionUID = 4332546822341241384L;
	//公共属性
	private String RespCode;	//响应码
	private String TransCode;	//交易码
	private String RespInfo;	//返回信息
	private String RxtInfo;		//返回扩展信息
	private String RespDate;	//返回扩展日期
	private String RespTime;	//返回时间
	
	//CFRA33特有属性
	private String RespSeqNo; //应答流水号
	
	//CQLA35特有属性
	private String TransSta;
	private String RespPrvData;
	
	//CQLA36特有属性
	private String FileFlag;	//文件标识; 1:有文件(此标识判断的前提是返回码为0000)
	private String BatchFileName;	//文件名
	private String RecordNum; // 记录数
	private String FieldNum; //字段数
	private String RespSource;	// 返回来源,判断RespSource是否为0，非0表示该次1972请求失败
	private String ReqSeqNo; 	// 请求渠道流水号 ; 原交易请求流水; 
	
	
	
	//渠道送往银行端的交易流水 (自定义)
	private String bankSendSn;
	//上送到银行端/前置机的文件名
	private String remoteFileName;
	//上送到银行端/前置机的文件路径
//	private String remoteFilePath;
	
	public String getRespCode() {
		return RespCode;
	}
	public void setRespCode(String respCode) {
		RespCode = respCode;
	}
	public String getTransCode() {
		return TransCode;
	}
	public void setTransCode(String transCode) {
		TransCode = transCode;
	}
	public String getRespInfo() {
		return RespInfo;
	}
	public void setRespInfo(String respInfo) {
		RespInfo = respInfo;
	}
	public String getRxtInfo() {
		return RxtInfo;
	}
	public void setRxtInfo(String rxtInfo) {
		RxtInfo = rxtInfo;
	}
	public String getRespDate() {
		return RespDate;
	}
	public void setRespDate(String respDate) {
		RespDate = respDate;
	}
	public String getRespTime() {
		return RespTime;
	}
	public void setRespTime(String respTime) {
		RespTime = respTime;
	}
	public String getRespSeqNo() {
		return RespSeqNo;
	}
	public void setRespSeqNo(String respSeqNo) {
		RespSeqNo = respSeqNo;
	}
	public String getTransSta() {
		return TransSta;
	}
	public void setTransSta(String transSta) {
		TransSta = transSta;
	}
	public String getRespPrvData() {
		return RespPrvData;
	}
	public void setRespPrvData(String respPrvData) {
		RespPrvData = respPrvData;
	}
	public String getFileFlag() {
		return FileFlag;
	}
	public void setFileFlag(String fileFlag) {
		FileFlag = fileFlag;
	}
	public String getBatchFileName() {
		return BatchFileName;
	}
	public void setBatchFileName(String batchFileName) {
		BatchFileName = batchFileName;
	}
	public String getRecordNum() {
		return RecordNum;
	}
	public void setRecordNum(String recordNum) {
		RecordNum = recordNum;
	}
	public String getFieldNum() {
		return FieldNum;
	}
	public void setFieldNum(String fieldNum) {
		FieldNum = fieldNum;
	}
	public String getRespSource() {
		return RespSource;
	}
	public void setRespSource(String respSource) {
		RespSource = respSource;
	}
	public String getReqSeqNo() {
		return ReqSeqNo;
	}
	public void setReqSeqNo(String reqSeqNo) {
		ReqSeqNo = reqSeqNo;
	}
	public String getBankSendSn() {
		return bankSendSn;
	}
	public void setBankSendSn(String bankSendSn) {
		this.bankSendSn = bankSendSn;
	}
	public String getRemoteFileName() {
		return remoteFileName;
	}
	public void setRemoteFileName(String remoteFileName) {
		this.remoteFileName = remoteFileName;
	}
//	public String getRemoteFilePath() {
//		return remoteFilePath;
//	}
//	public void setRemoteFilePath(String remoteFilePath) {
//		this.remoteFilePath = remoteFilePath;
//	}
	
//	public String getLocalPath() {
//		return localPath;
//	}
//	public void setLocalPath(String localPath) {
//		this.localPath = localPath;
//	}
	
}
