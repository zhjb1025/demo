package com.lycheepay.clearing.adapter.banks.abc.corp.kft.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean.CorpAbcC503Bean;
import com.lycheepay.clearing.adapter.banks.abc.corp.kft.bean.AbcSRResp;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.channel.corp.NoticeBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.util.net.FtpManager;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>解释农行详细报文服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午3:46:23
 */
@Service(ClearingAdapterAnnotationName.PARSE_ABC_XML_SERVICE)
public class ParseAbcXmlService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	private static String channelId = ChannelIdEnum.ABC_CORP.getCode();
	private static String line = System.getProperty("line.separator"); // 回车换行符

	/**
	 * 对账查询
	 * 
	 * @param RecvC503Xml
	 * @return ReturnState
	 * @throws BizException
	 */
	public Map<String, List> processRecvC503Xml(final String RecvC503Xml) throws BizException {
		Map<String, List> map = new HashMap<>();
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String ftpServer = channelParms.get("100029");
		String ftpPassword = channelParms.get("100030");
		String ftpUser = channelParms.get("100031");
		String abcRecvFile = channelParms.get("100033");
		final String RecvC503XmlInfo = RecvC503Xml;
		Document document = null;
		try {
			document = DocumentHelper.parseText(RecvC503XmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
		}
		final List<NoticeBean> noticeList = new ArrayList<NoticeBean>();// noticeBean实体为元素的arrayList
		final List<CorpAbcC503Bean> corpAbcC503BeanList = new ArrayList<CorpAbcC503Bean>();// C503实体为元素的arrayList

		String RespCode = ""; // 返回码 ： 0000交易成功
		String RecordNum = ""; // 记录数
		String TransCode = "";// 交易代码
		String ReqSeqNo = "";// 请求方流水号
		String RespSource = "";// 返回来源
		String RespSeqNo = "";// 应答流水号
		String RespDate = "";// 返回日期
		String RespTime = "";// 返回时间
		String RespInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String FileFlag = "";// 数据文件标识
		String FieldNum = "";// 字段数
		String RespPrvData = "";// 私有数据区
		String BatchFileName = "";// 批量文件名

		// 获取应答报文公共字段
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/TransCode") != null) {
			TransCode = document.selectSingleNode("/ap/TransCode").getText();  // 交易代码
		}
		if (document.selectSingleNode("/ap/Cme/RecordNum") != null) {
			RecordNum = document.selectSingleNode("/ap/Cme/RecordNum").getText(); // 记录数
		}
		// 判断返回码和记录数，如果返回了交易明细数据 ，则做下面组装 noticeList 的操作
		if (RespCode.equals("0000") && Integer.parseInt(RecordNum) > 0) {
			if (document.selectSingleNode("/ap/ReqSeqNo") != null) {
				ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();  	// 请求方流水号
			}
			if (document.selectSingleNode("/ap/RespSource") != null) {
				RespSource = document.selectSingleNode("/ap/RespSource").getText();// 返回来源
			}
			if (document.selectSingleNode("/ap/RespSeqNo") != null) {
				RespSeqNo = document.selectSingleNode("/ap/RespSeqNo").getText();  // 应答流水号
			}
			if (document.selectSingleNode("/ap/RespDate") != null) {
				RespDate = document.selectSingleNode("/ap/RespDate").getText();    // 返回日期
			}
			if (document.selectSingleNode("/ap/RespTime") != null) {
				RespTime = document.selectSingleNode("/ap/RespTime").getText();    // 返回时间
			}
			if (document.selectSingleNode("/ap/RxtInfo") != null) {
				RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText();      // 返回扩展信息
			}
			if (document.selectSingleNode("/ap/FileFlag") != null) {
				FileFlag = document.selectSingleNode("/ap/FileFlag").getText();    // 数据文件标识
			}

			if (document.selectSingleNode("/ap/Cme/FieldNum") != null) {
				FieldNum = document.selectSingleNode("/ap/Cme/FieldNum").getText();   // 字段数
			}
			if (document.selectSingleNode("/ap/Cmp/RespPrvData") != null) {
				RespPrvData = document.selectSingleNode("/ap/Cmp/RespPrvData").getText(); // 私有数据区
			}
			if (document.selectSingleNode("/ap/Cmp/BatchFileName") != null) {
				BatchFileName = document.selectSingleNode("/ap/Cmp/BatchFileName").getText();// 批量文件名
			}

			Log4jUtil.info("C503 RespPrvData:" + RespPrvData);
			Log4jUtil.info("C503 BatchFileName:" + BatchFileName);

			ChannelParm channelParm = new ChannelParm();

			// C503报文明细要素共36项：
			String Prov = "";
			String AccNo = "";
			String Ccy = "";
			String TrDate = "";
			String TimeStab = " ";  // 交易时间戳，不可空字段，因此至少要保存一个空串
			String TrJrn = "";
			String Name = "";
			String TrType = "";
			String TrFrom = "";
			String TrBankNo = "";
			String AmtIndex = "";
			String OppProv = "";
			String OppAccNo = "";
			String OppCcy = "";
			String OppName = "";
			String OppBkName = "";
			String CshIndex = "";
			String ErrDate = "";
			String ErrVchNo = "";
			String Amt = "";
			String Bal = "";
			String PreAmt = "";
			String TotChg = "";
			String VoucherType = "";
			String VoucherProv = "";
			String VoucherBat = "";
			String VoucherNo = "";
			String CustRef = "";
			String TrCode = "";
			String Teller = "";
			String VchNo = "";
			String Abs = "";
			String Cmt = "";
			String SpFlag = "";
			String FmtCode = "";
			String SpecInfo = "";
			int intPos = 0;			// 字符串的位置
			String oneField = "";	// 取得单个字段的值

			// 处理对账的数据（分为：有文件 和 没有文件两种，如果没有文件，数据会保存在变量RespPrvData中）
			if (FileFlag.equals("1")) { // 以文件方式返回明细（即RespPrvData节点的内容放在文件中）,此时FileFlag=1
				// 1、下载CT服务器上的文件
				final FtpManager ftpManager = new FtpManager();
				ftpManager.setServer(ftpServer);
				ftpManager.setPassword(ftpPassword);
				ftpManager.setUser(ftpUser);
				ftpManager.setFilename(BatchFileName);
				ftpManager.setLocalPath(abcRecvFile); // 下载到本地的文件夹
				ftpManager.setPath(""); // 远程目录，就是FTP用户的默认目录
				ftpManager.getMyFile_actionPerformed();
				Log4jUtil.info("农行银企C503报文(对账报文):" + BatchFileName + "已下载到本地");

				// 2、把文件存内容入变量 RespPrvData 中
				RespPrvData = readFileByChars(abcRecvFile + File.separator + BatchFileName);
			}

			// 处理C503返回的报文，组调用‘对账’参数
			while (RespPrvData.length() > 100) {
				for (int j = 0; (j < 36); j++) {
					intPos = RespPrvData.indexOf("|");
					oneField = RespPrvData.substring(0, intPos);
					RespPrvData = RespPrvData.substring(intPos + 1);

					if (j == 0) {
						Prov = oneField;
					}// 省市代号
					else if (j == 1) {
						AccNo = oneField;
					}// 账号
					else if (j == 2) {
						Ccy = oneField;
					}// 货币码
					else if (j == 3) {
						TrDate = oneField;
					}// 交易日期
					else if (j == 4) {
						TimeStab = oneField;
					}// 交易时间戳
					else if (j == 5) {
						TrJrn = oneField;
					}// 日志号
					else if (j == 6) {
						Name = oneField;
					}// 户名
					else if (j == 7) {
						TrType = oneField;
					}// 交易类别
					else if (j == 8) {
						TrFrom = oneField;
					}// 交易来源
					else if (j == 9) {
						TrBankNo = oneField;
					}// 交易行行号
					else if (j == 10) {
						AmtIndex = oneField;
					}// 发生额标志
					else if (j == 11) {
						OppProv = oneField;
					}// 对方账号省市代码
					else if (j == 12) {
						OppAccNo = oneField;
					}// 对方账号
					else if (j == 13) {
						OppCcy = oneField;
					}// 对方账号货币码
					else if (j == 14) {
						OppName = oneField;
					}// 对方账号户名
					else if (j == 15) {
						OppBkName = oneField;
					}// 对方账号开户行名
					else if (j == 16) {
						CshIndex = oneField;
					}// 现转标志
					else if (j == 17) {
						ErrDate = oneField;
					}// 错账日期
					else if (j == 18) {
						ErrVchNo = oneField;
					}// 错账凭证号
					else if (j == 19) {
						Amt = oneField;
					}// 交易金额
					else if (j == 20) {
						Bal = oneField;
					}// 账户余额
					else if (j == 21) {
						PreAmt = oneField;
					}// 上笔余额
					else if (j == 22) {
						TotChg = oneField;
					}// 手续费总额
					else if (j == 23) {
						VoucherType = oneField;
					}// 凭证种类
					else if (j == 24) {
						VoucherProv = oneField;
					}// 凭证省市代码
					else if (j == 25) {
						VoucherBat = oneField;
					}// 凭证批次号
					else if (j == 26) {
						VoucherNo = oneField;
					}// 凭证号
					else if (j == 27) {
						CustRef = oneField;
					}// 户参考号 ============== 这个就是 billnoSn 的Ban_Send_SN 发往银行端的流水
					else if (j == 28) {
						TrCode = oneField;
					}// 交易码
					else if (j == 29) {
						Teller = oneField;
					}// 柜员号
					else if (j == 30) {
						VchNo = oneField;
					}// 传票号
					else if (j == 31) {
						Abs = oneField;
					}// 摘要
					else if (j == 32) {
						Cmt = oneField;
					}// 附言
					else if (j == 33) {
						SpFlag = oneField;
					}// 特殊信息标志
					else if (j == 34) {
						FmtCode = oneField;
					}// 格式码
					else if (j == 35) {
						SpecInfo = oneField;
					}// 特殊信息
					else {
					}
				}

				if (Amt.equals("Amt") == false) {
					if (Double.parseDouble(Amt) > 0 && OppAccNo.trim().length() > 0 && CustRef.trim().length() > 0
							&& OppName.trim().length() > 0 && TrBankNo.trim().length() > 0) {
						final NoticeBean noticeBean = new NoticeBean();
						// noticeBean.setBankType(payChannel.getChannelBankType());
						// //银行行别，现在这个字段没用，我用来做测试
						noticeBean.setBankSn(CustRef);	// 银行流水号
						noticeBean.setPayerBankCardNo(OppAccNo);	// 付款人帐号
						noticeBean.setPayerBankCardName(OppName);// 付款人户名
						noticeBean.setPayerBankCode(TrBankNo);	// 付款人开户银行行号
						noticeBean.setTradeAmount(Double.parseDouble(Amt));// 金额
						noticeBean.setBankType(TrDate); // 我用来做测试，存交易日期,BankType字段平台不再使用
						noticeList.add(noticeBean);
					}
					final CorpAbcC503Bean corpAbcC503Bean = new CorpAbcC503Bean();
					corpAbcC503Bean.setProv(Prov);// 省市代号
					corpAbcC503Bean.setAccNo(AccNo);// 账号
					corpAbcC503Bean.setCcy(Ccy);// 货币码
					corpAbcC503Bean.setTrDate(TrDate);// 交易日期
					corpAbcC503Bean.setTimeStab(TimeStab);// 交易时间戳
					corpAbcC503Bean.setTrJrn(TrJrn);// 日志号
					corpAbcC503Bean.setName(Name);// 户名
					corpAbcC503Bean.setTrType(TrType);// 交易类别
					corpAbcC503Bean.setTrFrom(TrFrom);// 交易来源
					corpAbcC503Bean.setTrBankNo(TrBankNo);// 交易行行号
					corpAbcC503Bean.setAmtIndex(AmtIndex);// 发生额标志
					corpAbcC503Bean.setOppProv(OppProv);// 对方账号省市代码
					corpAbcC503Bean.setOppAccNo(OppAccNo);// 对方账号
					corpAbcC503Bean.setOppCcy(OppCcy);// 对方账号货币码
					corpAbcC503Bean.setOppName(OppName);// 对方账号户名
					corpAbcC503Bean.setOppBkName(OppBkName);// 对方账号开户行名
					corpAbcC503Bean.setCshIndex(CshIndex);// 现转标志
					corpAbcC503Bean.setErrDate(ErrDate);// 错账日期
					corpAbcC503Bean.setErrVchNo(ErrVchNo);// 错账凭证号
					corpAbcC503Bean.setAmt(Amt);// 交易金额
					corpAbcC503Bean.setBal(Bal);// 账户余额
					corpAbcC503Bean.setPreAmt(PreAmt);// 上笔余额
					corpAbcC503Bean.setTotChg(TotChg);// 手续费总额
					corpAbcC503Bean.setVoucherType(VoucherType);// 凭证种类
					corpAbcC503Bean.setVoucherProv(VoucherProv);// 凭证省市代码
					corpAbcC503Bean.setVoucherBat(VoucherBat);// 凭证批次号
					corpAbcC503Bean.setVoucherNo(VoucherNo);// 凭证号
					corpAbcC503Bean.setCustRef(CustRef);// 户参考号 ============== 这个就是 billnoSn
														// 的Ban_Send_SN 发往银行端的流水
					corpAbcC503Bean.setTrCode(TrCode);// 交易码
					corpAbcC503Bean.setTeller(Teller);// 柜员号
					corpAbcC503Bean.setVchNo(VchNo);// 传票号
					corpAbcC503Bean.setAbs(Abs);// 摘要
					corpAbcC503Bean.setCmt(Cmt);// 附言
					corpAbcC503Bean.setSpFlag(SpFlag);// 特殊信息标志
					corpAbcC503Bean.setFmtCode(FmtCode);// 格式码
					corpAbcC503Bean.setSpecInfo(SpecInfo);// 特殊信息
					corpAbcC503BeanList.add(corpAbcC503Bean);
				}
			} // 结束循环，把 TimeStab 交易时间戳 写到数据库中
			channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100021"));
			channelParm.setParvalue(TimeStab);
			channelParmService.update(channelParm);
		} else if (RespCode.equals("2002")) {
			throw new BizException(TransReturnCode.code_9109, "农行银企对账查询出错，交易返回错误信息: " + RespInfo
					+ "操作员未签到，请做签到操作后再做其他交易");
		} else if (!(RespCode.equals("0000"))) {
			throw new BizException(TransReturnCode.code_9109, "农行银企对账查询出错，农行业务交易代码: " + TransCode + ";交易返回码： "
					+ RespCode + "；交易返回错误信息: "
					+ RespInfo);
		}
		for (int i = 0; i < noticeList.size(); i++) {
			// array_type array_element = noticeList[i];
			Log4jUtil.info(line + (i + 1) + " 交易日期: " + noticeList.get(i).getBankType());
			Log4jUtil.info(line + (i + 1) + " 银行流水号: " + noticeList.get(i).getBankSn());
			Log4jUtil.info(line + (i + 1) + " 付款人帐号: " + noticeList.get(i).getPayerBankCardNo());
			Log4jUtil.info(line + (i + 1) + " 付款人户名: " + noticeList.get(i).getPayerBankCardName());
			Log4jUtil.info(line + (i + 1) + " 付款人开户银行行号: " + noticeList.get(i).getPayerBankCode());
			Log4jUtil.info(line + (i + 1) + " 金额: " + noticeList.get(i).getTradeAmount());
			Log4jUtil.info(line + "________________________________________________________________");
		}
		Log4jUtil.info("________________________________C503所有记录（含收、付款记录）________________________________");
		for (int i = 0; i < corpAbcC503BeanList.size(); i++) {
			Log4jUtil.info("________________________________________________________________");
			Log4jUtil.info((i + 1) + ":省市代号        :" + corpAbcC503BeanList.get(i).getProv());// 省市代号
			Log4jUtil.info((i + 1) + ":账号            :" + corpAbcC503BeanList.get(i).getAccNo());// 账号
			Log4jUtil.info((i + 1) + ":货币码          :" + corpAbcC503BeanList.get(i).getCcy());// 货币码
			Log4jUtil.info((i + 1) + ":交易日期        :" + corpAbcC503BeanList.get(i).getTrDate());// 交易日期
			Log4jUtil.info((i + 1) + ":交易时间戳      :" + corpAbcC503BeanList.get(i).getTimeStab());// 交易时间戳
			Log4jUtil.info((i + 1) + ":日志号          :" + corpAbcC503BeanList.get(i).getTrJrn());// 日志号
			Log4jUtil.info((i + 1) + ":户名            :" + corpAbcC503BeanList.get(i).getName());// 户名
			Log4jUtil.info((i + 1) + ":交易类别        :" + corpAbcC503BeanList.get(i).getTrType());// 交易类别
			Log4jUtil.info((i + 1) + ":交易来源        :" + corpAbcC503BeanList.get(i).getTrFrom());// 交易来源
			Log4jUtil.info((i + 1) + ":交易行行号      :" + corpAbcC503BeanList.get(i).getTrBankNo());// 交易行行号
			Log4jUtil.info((i + 1) + ":发生额标志      :" + corpAbcC503BeanList.get(i).getAmtIndex());// 发生额标志
			Log4jUtil.info((i + 1) + ":对方账号省市代码:" + corpAbcC503BeanList.get(i).getOppProv());// 对方账号省市代码
			Log4jUtil.info((i + 1) + ":对方账号        :" + corpAbcC503BeanList.get(i).getOppAccNo());// 对方账号
			Log4jUtil.info((i + 1) + ":对方账号货币码  :" + corpAbcC503BeanList.get(i).getOppCcy());// 对方账号货币码
			Log4jUtil.info((i + 1) + ":对方账号户名    :" + corpAbcC503BeanList.get(i).getOppName());// 对方账号户名
			Log4jUtil.info((i + 1) + ":对方账号开户行名:" + corpAbcC503BeanList.get(i).getOppBkName());// 对方账号开户行名
			Log4jUtil.info((i + 1) + ":现转标志        :" + corpAbcC503BeanList.get(i).getCshIndex());// 现转标志
			Log4jUtil.info((i + 1) + ":错账日期        :" + corpAbcC503BeanList.get(i).getErrDate());// 错账日期
			Log4jUtil.info((i + 1) + ":错账凭证号      :" + corpAbcC503BeanList.get(i).getErrVchNo());// 错账凭证号
			Log4jUtil.info((i + 1) + ":交易金额        :" + corpAbcC503BeanList.get(i).getAmt());// 交易金额
			Log4jUtil.info((i + 1) + ":账户余额        :" + corpAbcC503BeanList.get(i).getBal());// 账户余额
			Log4jUtil.info((i + 1) + ":上笔余额        :" + corpAbcC503BeanList.get(i).getPreAmt());// 上笔余额
			Log4jUtil.info((i + 1) + ":手续费总额      :" + corpAbcC503BeanList.get(i).getTotChg());// 手续费总额
			Log4jUtil.info((i + 1) + ":凭证种类        :" + corpAbcC503BeanList.get(i).getVoucherType());// 凭证种类
			Log4jUtil.info((i + 1) + ":凭证省市代码    :" + corpAbcC503BeanList.get(i).getVoucherProv());// 凭证省市代码
			Log4jUtil.info((i + 1) + ":凭证批次号      :" + corpAbcC503BeanList.get(i).getVoucherBat());// 凭证批次号
			Log4jUtil.info((i + 1) + ":凭证号          :" + corpAbcC503BeanList.get(i).getVoucherNo());// 凭证号
			Log4jUtil.info((i + 1) + ":户参考号 	:" + corpAbcC503BeanList.get(i).getCustRef());// 户参考号
																								// ==============
																								// 这个就是
																								// billnoSn
																								// 的Ban_Send_SN
																								// 发往银行端的流水
			Log4jUtil.info((i + 1) + ":交易码          :" + corpAbcC503BeanList.get(i).getTrCode());// 交易码
			Log4jUtil.info((i + 1) + ":柜员号          :" + corpAbcC503BeanList.get(i).getTeller());// 柜员号
			Log4jUtil.info((i + 1) + ":传票号          :" + corpAbcC503BeanList.get(i).getVchNo());// 传票号
			Log4jUtil.info((i + 1) + ":摘要            :" + corpAbcC503BeanList.get(i).getAbs());// 摘要
			Log4jUtil.info((i + 1) + ":附言            :" + corpAbcC503BeanList.get(i).getCmt());// 附言
			Log4jUtil.info((i + 1) + ":特殊信息标志    :" + corpAbcC503BeanList.get(i).getSpFlag());// 特殊信息标志
			Log4jUtil.info((i + 1) + ":格式码          :" + corpAbcC503BeanList.get(i).getFmtCode());// 格式码
			Log4jUtil.info((i + 1) + ":特殊信息        :" + corpAbcC503BeanList.get(i).getSpecInfo());// 特殊信息
		}
		Log4jUtil.info("_______________________________ END _________________________________");

		Log4jUtil.info("________________________________C503交易码；金额；时间戳________________________________");
		for (int i = 0; i < corpAbcC503BeanList.size(); i++) {
			Log4jUtil.info("________________________________________________________________");
			Log4jUtil.info((i + 1) + ":交易码: " + corpAbcC503BeanList.get(i).getTrCode());// 交易码
			// Log4jUtil.info((i+1)+":金额: " +corpAbcC503BeanList.get(i).getAmt ()); //交易金额
			// Log4jUtil.info((i+1)+":交易时间戳: " +corpAbcC503BeanList.get(i).getTimeStab ());
			// //交易时间戳，不可空字段，因此至少要保存一个空串
		}
		Log4jUtil.info("_______________________________ END _________________________________");
		map.put("noticeList", noticeList);
		map.put("corpAbcC503BeanList", corpAbcC503BeanList);
		return map;
	}

	/**
	 * 通过农行应答报文公共字段,组返回的 ReturnState（大部分接口方法适用）
	 * 
	 * @param recvXmlInfo 农行银企返回的XML报文数据
	 * @return 平台要求的 ReturnState 实体
	 * @throws BizException
	 */
	public ReturnState processRtnXml(final String recvXmlInfo) throws BizException {
		// returnState.setReturnState(); //银行返回状态---超时：T、成功：S、失败：F
		// //银行返回的报文
		// returnState.setBankRetCode(); //银行返回代码
		// returnState.setReturnMsg(); //银行响应信息
		// returnState.setBankPostScript();//银行返回信息 ******* 农行银企返回公共包头中不提供这个信息
		// //处理后返回的状态
		// returnState.setSn(); //平台业务流水
		// returnState.setChannelCode(); //渠道返回给业务层状态码
		// returnState.setCardType(); //卡类型
		// returnState.setCheckDate(); //渠道结算日期
		// returnState.setRelTranAmount(); //实际扣款金额 ******* 农行银企返回公共包头中不提供这个信息（有些业务可在明细中得到）

		Document document = null;
		try {
			document = DocumentHelper.parseText(StringUtils.trim(recvXmlInfo));
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		String RespCode = "";		// 农行银企返回码 ： 0000交易成功
		String RespInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String ReqSeqNo = ""; 	// 平台业务流水
		String RespDate = "";  	// 返回日期
		String RetState = "";  // 成功、失败状态
		String ChannelCode = "";  // 平台返回码
		String JrnNo = "";  	// 农行银企返回的日志号

		// 获取应答报文公共字段
		String TransCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}
		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {	// 如果业务流水字段不为空，则返回给平台流水
			ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {	// 如果日期字段不为空，则返回给平台交易日期
			RespDate = document.selectSingleNode("/ap/RespDate").getText();
		}
		if (document.selectSingleNode("/ap/Channel/JrnNo") != null) {	// 银行返回的日志号，用来匹配C503返回的交易结果
			JrnNo = document.selectSingleNode("/ap/Channel/JrnNo").getText();
		}

		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, RespCode));
		if (channelRtncode == null) {
			if ("2287".equals(TransCode)) {// 如果付款返回结果未知，则当作异常成功
				ChannelCode = TransReturnCode.code_9109;
			} else {
				ChannelCode = TransReturnCode.code_9900;
			}
		} else {
			ChannelCode = channelRtncode.getKftRtncode();
			RespInfo = StringUtils.substring(channelRtncode.getChannelReamrk(), 0, 100); // 最长只有100，要截取长度
		}
		if (TransReturnCode.code_0000.equals(ChannelCode)) {
			RetState = PayState.SUCCEED_STR;
		} else if (TransReturnCode.code_9109.equals(ChannelCode)) {
			RetState = PayState.UNKNOW_STR;
		} else {
			RetState = PayState.FAILED_STR;
		}

		// 组返回的实体
		final ReturnState returnState = new ReturnState();
		returnState.setReturnState(RetState);
		returnState.setBankRetCode(RespCode);// 银行返回代码
		returnState.setReturnMsg(RespInfo);// 返回信息
		returnState.setBankPostScript(RxtInfo);// 返回扩展信息
		returnState.setSn(ReqSeqNo); // 请求方流水号ReqSeqNo（发业务时返回与平台的流水没有关系的东西，查询交易时返回渠道填写的‘请求方流水’）
										// 银行日志号JrnNo
		returnState.setChannelCode(ChannelCode);
		returnState.setCardType(BankCardType.DEBIT_CARD);  // 农行银企不分借记卡；贷记卡的；暂用贷记卡表示
		returnState.setReturnObj(JrnNo);	// 银行日志号JrnNo
		returnState.setCheckDate(RespDate); // 渠道结算日期
		returnState.setRelTranAmount(BigDecimal.ZERO);  // 银行返回金额设置为0(农行银企返回数据中不提供）
		return returnState;
	}
	
	public AbcSRResp processSettlementReportRtnXml(final String recvXmlInfo) throws BizException {
		Document document = null;
		try {
			document = DocumentHelper.parseText(StringUtils.trim(recvXmlInfo));
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企(备付金)返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		String RespCode = "";		// 农行银企返回码 ： 0000交易成功
		String RespInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String RespDate = "";  	// 返回日期
		String RespTime = "";	// 返回时间
		//CFRA33特有属性
		String RespSeqNo = ""; 	// 应答流水号
		//CQLA35特有属性
		String TransSta = "";
		String RespPrvData = "";
		//CQLA36特有属性
		String FileFlag = "";	//文件标识; 1:有文件(只有返回码为0000此字段才有意义)
		String BatchFileName = "";	//文件名
		String RecordNum = ""; // 记录数
		String FieldNum = ""; //字段数
		String RespSource = "";// 返回来源,判断RespSource是否为0，非0表示该次1972请求失败
		String ReqSeqNo = ""; 	// 请求渠道流水号 ; 原交易请求流水; 

		// 获取应答报文公共字段
		String TransCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {
			RespDate = document.selectSingleNode("/ap/RespDate").getText();
		}
		if (document.selectSingleNode("/ap/RespTime") != null) {
			RespTime = document.selectSingleNode("/ap/RespTime").getText();
		}
		
		//CFRA33特有属性
		if (document.selectSingleNode("/ap/RespSeqNo") != null) {
			RespSeqNo = document.selectSingleNode("/ap/RespSeqNo").getText();
		}

		//CQLA35特有属性
		if (document.selectSingleNode("/ap/Cmp/TransSta") != null) {
			TransSta = document.selectSingleNode("/ap/Cmp/TransSta").getText().replace("|", "");
		}
		if (document.selectSingleNode("/ap/Cmp/RespPrvData") != null) {
			RespPrvData = document.selectSingleNode("/ap/Cmp/RespPrvData").getText();
		}
		
		//CQLA36特有属性
		if (document.selectSingleNode("/ap/Cmp/BatchFileName") != null) {
			BatchFileName = document.selectSingleNode("/ap/Cmp/BatchFileName").getText();
		}
		if (document.selectSingleNode("/ap/FileFlag") != null) {
			FileFlag = document.selectSingleNode("/ap/FileFlag").getText();
		}
		if (document.selectSingleNode("/ap/Cme/RecordNum") != null) {
			RecordNum = document.selectSingleNode("/ap/Cme/RecordNum").getText(); // 记录数
		}
		if (document.selectSingleNode("/ap/Cme/FieldNum") != null) {
			FieldNum = document.selectSingleNode("/ap/Cme/FieldNum").getText();
		}
		if (document.selectSingleNode("/ap/RespSource") != null) {
			RespSource = document.selectSingleNode("/ap/RespSource").getText();
		}
		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {
			ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}

		// 组返回的实体
		final AbcSRResp abcSRResp = new AbcSRResp();
		abcSRResp.setTransCode(TransCode);
		abcSRResp.setRespCode(RespCode);
		abcSRResp.setRespInfo(RespSeqNo);
		abcSRResp.setRxtInfo(RxtInfo);
		abcSRResp.setRespDate(RespDate);
		abcSRResp.setRespTime(RespTime);
		abcSRResp.setRespSeqNo(RespSeqNo);
		abcSRResp.setTransSta(TransSta);
		abcSRResp.setRespPrvData(RespPrvData);
		abcSRResp.setBatchFileName(BatchFileName);
		abcSRResp.setRespInfo(RespInfo);
		abcSRResp.setFileFlag(FileFlag);
		abcSRResp.setRecordNum(RecordNum);
		abcSRResp.setFieldNum(FieldNum);
		abcSRResp.setRespSource(RespSource);
		abcSRResp.setReqSeqNo(ReqSeqNo);
		return abcSRResp;
	}

	/**
	 * 批量代扣；批量代付交易结果处理,组返回的 ReturnState（大部分接口方法适用）
	 * 
	 * @param recvXmlInfo 农行银企返回的XML报文数据
	 * @return 平台要求的 ReturnState 实体
	 * @throws BizException
	 */
	public String process1944RtnXml(final String recvXmlInfo) throws BizException {
		Document document = null;
		try {
			document = DocumentHelper.parseText(recvXmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		String respInfo = "";// 返回信息
		String rxtInfo = "";// 返回扩展信息
		String reqSeqNo = ""; 	// 请求渠道流水号 ; 批量代扣；批量代付交易的请求号
		String respDate = "";  	// 返回日期
		String result = "";  // 成功、失败状态
		String transSta = "";		// 流水状态

		// 获取应答报文公共字段
		String transCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		String respCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			respInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			rxtInfo = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}
		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {	// 如果业务流水字段不为空，则返回给平台流水
			reqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}
		if (document.selectSingleNode("/ap/Cmp/TransSta") != null) {	// 如果应答流水状态不为空,则用此返回信息
			transSta = document.selectSingleNode("/ap/Cmp/TransSta").getText();
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {	// 如果日期字段不为空，则返回给平台交易日期
			respDate = document.selectSingleNode("/ap/RespDate").getText();
		}
		if ("0000".equals(respCode)) {
			if ("4".equals(transSta)) {// 4 成功
				result = PayState.SUCCEED_STR;
			} else if ("5".equals(transSta)) {// 5 失败
				result = PayState.FAILED_STR;
			} else {// 1 待复核 2 待发送 3 正在发送 4 成功 5 失败 6 落地 7 预约 9 未知
				result = PayState.UNKNOW_STR;
			}
		} else {
			result = PayState.UNKNOW_STR;
		}

		return result;
	}

	/**
	 * 解释1972报文,组返回的 ReturnState
	 * 
	 * @param recvXmlInfo 农行银企返回的XML报文数据
	 * @return 平台要求的 ReturnState 实体
	 * @throws BizException
	 */
	public ReturnState process1972RtnXml(final String recvXmlInfo) throws BizException {
		// returnState.setReturnState(); //银行返回状态---超时：T、成功：S、失败：F
		// //银行返回的报文
		// returnState.setBankRetCode(); //银行返回代码
		// returnState.setReturnMsg(); //银行响应信息
		// returnState.setBankPostScript();//银行返回信息 ******* 农行银企返回公共包头中不提供这个信息
		// //处理后返回的状态
		// returnState.setSn(); //平台业务流水
		// returnState.setChannelCode(); //渠道返回给业务层状态码
		// returnState.setCardType(); //卡类型
		// returnState.setCheckDate(); //渠道结算日期
		// returnState.setRelTranAmount(); //实际扣款金额 ******* 农行银企返回公共包头中不提供这个信息（有些业务可在明细中得到）

		final ReturnState returnState = new ReturnState();

		Document document = null;
		try {
			document = DocumentHelper.parseText(recvXmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		String TransCode = "";	// 返回交易代码
		String RespCode = "";		// 农行银企返回码 ： 0000交易成功
		String RespInfo = "";		// 银行响应信息
		String RxtInfo = ""; 	// 银行返回附言设置为空串(农行银企返回数据中不提供）
		String ReqSeqNo = ""; 	// 平台业务流水
		String RespDate = "";  	// 返回日期
		String ReturnState = "";  // 成功、失败状态
		String ChannelCode = "";  // 平台返回码
		String RespSource = "";// 返回来源,判断RespSource是否为0，非0表示该次1972请求失败

		String FileFlag = "";		// 文件标志 #0-无文件 1-有文件(是否为1，为1则表示有结果文件，从Cmp/BatchFileName取得结果文件名)
		String BatchFileName = "";	// 文件名
		final String descriptionMsg = "";	// 描述信息
		final String succNum = "";	// 成功笔数
		final String succAmt = "";	// 成功金额
		final String hostState = "";// 主机返回状态
		final String processState = "";	// 处理状态
		String decription = ""; // 1972 返回的描述信息

		// 获取应答报文公共字段
		TransCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			decription = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}

		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {	// 如果业务流水字段不为空，则返回给平台流水
			ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}
		if (document.selectSingleNode("/ap/RespSource") != null) {	// 如果应答流水状态不为空,则用此返回信息
			RespSource = document.selectSingleNode("/ap/RespSource").getText();
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {	// 如果日期字段不为空，则返回给平台交易日期
			RespDate = document.selectSingleNode("/ap/RespDate").getText();
		}
		if (document.selectSingleNode("/ap/FileFlag") != null) {	// #0-无文件 1-有文件
			FileFlag = document.selectSingleNode("/ap/FileFlag").getText();
		}
		if (document.selectSingleNode("/ap/cmp/BatchFileName") != null) {	// 取得文件名
			BatchFileName = document.selectSingleNode("/ap/cmp/BatchFileName").getText();
		}

		// //////////////////////////////////////////////////
		if (document.selectSingleNode("/ap/Tulip/批处理/描述信息") != null) {	// 取得文件名
			decription = decription + document.selectSingleNode("/ap/Tulip/批处理/描述信息").getText();
		}
		// //////////////////////////////////////////////////

		// FileFlag
		if (RespCode.equals("0000")) {
			ReturnState = "S";
		} else {
			ReturnState = PayState.FAILED_STR;
		}
		ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回 9900 给平台
		channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, RespCode));
		if (channelRtncode == null) {
			ChannelCode = TransReturnCode.code_9900;
		} else {
			ChannelCode = channelRtncode.getKftRtncode();
			RespInfo = channelRtncode.getChannelReamrk();
		}

		if (RespSource.equals("0") == false) {
			RespSource = "该次1972请求失败";
		} else if (FileFlag.equals("1")) { // 如果1972业务有文件返回，取文件，再取文件数据，处理返回的数据
			// 1、得到文件名 BatchFileName
			BatchFileName = document.selectSingleNode("/ap/Cmp/BatchFileName").getText();
			// 如果文件名有值，则 返回扩展信息 返回"file"字符串，returnState.
			if (BatchFileName.length() > 1) {
				RxtInfo = "file"; // 如果有文件返回，这个字段只能赋值【file】，后续处理要用到此值
			}
		}

		if (FileFlag.equals("1")) { // 后面处理文件，这里不再处理
			// RxtInfo = "返回批量文件名为:" + BatchFileName;
			// 1、下载返回的文件
			// downLoadFile(BatchFileName);

			// 2、处理返回的批量结果

		} else {
			RxtInfo = "没有返回批量文件，返回的描述信息为：" + decription;
		}

		if (RespCode.equals("2002")) {
			RespInfo = RespInfo + "，操作员未签到，请做签到操作后再做其他交易";
		}

		// 组返回的实体
		returnState.setReturnState(ReturnState);// 成功、失败状态
		returnState.setBankRetCode(RespCode);// 银行返回代码
		returnState.setReturnMsg(RespInfo);// 返回信息
		returnState.setBankPostScript(RxtInfo);// 返回扩展信息;如果文件名有值，则 返回扩展信息 返回的是<文件名>
		returnState.setChannelCode(ChannelCode);// 平台返回码
		// returnState.setSn(ReqSeqNo); //平台业务流水
		returnState.setSn(TransCode.trim());// 返回业务类型
		returnState.setCardType(BankCardType.CREDIT_CARD);  // 农行银企不分借记卡；贷记卡的；暂用贷记卡表示
		returnState.setCheckDate(RespDate); // 渠道结算日期
		returnState.setRelTranAmount(BigDecimal.ZERO);  // 银行返回金额设置为0(农行银企返回数据中不提供）
		returnState.setReturnObj(BatchFileName);// 返回文件名
		// returnState.setBankPostScript(TransCode.trim());//返回业务类型
		// if (TransCode.trim().equals("C410")) {
		// returnState.setBankPostScript(TransCode.trim());//返回业务类型
		// } else if (TransCode.trim().equals("C410")) {
		// returnState.setBankPostScript("");//返回业务类型
		// }
		return returnState;
	}

	// ///////////////////////////////////////////////////////
	/**
	 * 通过农行应答报文公共字段,组返回的 ReturnState（大部分接口方法适用）
	 * 
	 * @param recvXmlInfo 农行银企返回的XML报文数据
	 * @return 平台要求的 ReturnState 实体
	 * @throws BizException
	 */
	public ReturnState processC100RtnXml(final String recvXmlInfo) throws BizException {

		final ReturnState returnState = new ReturnState();

		Document document = null;
		try {
			document = DocumentHelper.parseText(recvXmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		String TransCode = "";	// 返回交易代码
		String RespCode = "";		// 农行银企返回码 ： 0000交易成功
		String RespInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String ReqSeqNo = ""; 	// 平台业务流水
		String RespDate = "";  	// 返回日期
		String ReturnState = "";  // 成功、失败状态
		String ChannelCode = "";  // 平台返回码
		String AuthNo = "";		// 流水状态

		// 获取应答报文公共字段
		TransCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}
		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {	// 如果业务流水字段不为空，则返回给平台流水
			ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}
		if (document.selectSingleNode("/ap/AuthNo") != null) {	// 如果应答认证码不为空,则返回认证码信息
			AuthNo = document.selectSingleNode("/ap/AuthNo").getText();
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {	// 如果日期字段不为空，则返回给平台交易日期
			RespDate = document.selectSingleNode("/ap/RespDate").getText();
		}
		if (RespCode.equals("0000")) {
			ReturnState = "S";
		} else {
			ReturnState = PayState.FAILED_STR;
		}
		ChannelRtncode channelRtncode = null; // 通过对照表查找农行银企返回码的平台对照码，如果找不到，则返回 9900 给平台
		channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, RespCode));
		if (channelRtncode == null) {
			ChannelCode = TransReturnCode.code_9900;
		} else {
			ChannelCode = channelRtncode.getKftRtncode();
			RespInfo = channelRtncode.getChannelReamrk();
		}

		ChannelParm channelParm = new ChannelParm();
		channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(channelId, "100005"));
		channelParm.setParvalue(AuthNo);
		channelParmService.update(channelParm);

		// 组返回的实体
		returnState.setReturnState(ReturnState);
		returnState.setBankRetCode(RespCode);// 银行返回代码
		returnState.setReturnMsg("签到：" + RespInfo + "；签到的认证码：" + AuthNo);// 银行响应信息
		returnState.setBankPostScript(RxtInfo);// 返回扩展信息
		returnState.setChannelCode(ChannelCode);
		returnState.setSn(ReqSeqNo); // 平台业务流水
		returnState.setCardType(BankCardType.CREDIT_CARD);  // 农行银企不分借记卡；贷记卡的；暂用贷记卡表示
		returnState.setCheckDate(RespDate); // 渠道结算日期
		returnState.setRelTranAmount(BigDecimal.ZERO);  // 银行返回金额设置为0(农行银企返回数据中不提供）

		return returnState;
	}

	/**
	 * 查询单账户余额
	 * 
	 * @param recvXmlInfo
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 */
	public Balance process7506RtnXml(final String recvXmlInfo) throws BizException {
		Document document = null;
		try {
			document = DocumentHelper.parseText(recvXmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		// 获取应答报文公共字段
		String respInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String ReqSeqNo = ""; 	// 平台业务流水
		String RespDate = "";  	// 返回日期

		String transCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		String respCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			respInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}
		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {	// 如果业务流水字段不为空，则返回给平台流水
			ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {	// 如果日期字段不为空，则返回给平台交易日期
			RespDate = document.selectSingleNode("/ap/RespDate").getText();
		}

		// Cmp/DbProv 省市代码
		// Cmp/DbAccNo 账号
		// Cmp/DbCur 货币号
		// Corp/DbAccName 借方户名
		// Acc/Bal 帐户余额
		// Acc/AvailBal 帐户可用余额
		// Acc/FrzAmt 冻结金额
		// Acc/FrzBal 冻结余额
		// Acc/ValUDLmt 不定期可用限额
		// Acc/ValMonthLmt 月可用限额
		// Acc/ValDayLmt 日可用限额
		// Acc/LastAvailBal 昨日可用余额
		// Acc/LastBal 昨日余额
		// Acc/AccType 帐户类型
		// Acc/AccSts 帐户状态

		Balance balanceDTO = new Balance();
		if ("0000".equals(respCode)) {
			String balance = ""; // 帐户余额
			String availBal = ""; // 帐户可用余额
			String accNo = ""; // 借方账号
			if (document.selectSingleNode("/ap/Acc/Bal") != null) {
				balance = document.selectSingleNode("/ap/Acc/Bal").getText();     // 帐户余额
			}
			if (document.selectSingleNode("/ap/Acc/AvailBal") != null) {
				availBal = document.selectSingleNode("/ap/Acc/AvailBal").getText();    // 银行响应信息
			}
			if (document.selectSingleNode("/ap/Cmp/DbAccNo") != null) {
				accNo = document.selectSingleNode("/ap/Cmp/DbAccNo").getText();
			}
			Log4jUtil.info("农行银企账号:{}，余额:{},可用余额:{}", accNo, balance, availBal);
			balanceDTO.setAccNo(accNo);
			balanceDTO.setBalance(balance);
			balanceDTO.setAvailBanlace(availBal);
		} else {
			balanceDTO.setErrorMsg("返回码:" + respCode + "," + respInfo + ";" + RxtInfo);
		}
		return balanceDTO;

	}

	/**
	 * 以字符为单位读取文件，常用于读文本，数字等类型的文件
	 * 
	 * @param 文件名
	 * @return 文件内容
	 */
	public static String readFileByChars(final String fileName) {
		final File file = new File(fileName);
		String RetFileContent = ""; // 返回值，保存文件中数据
		Reader reader = null;
		try {
			Log4jUtil.info("以字符为单位读取农行银企对账文件，一次读一个字节：");
			reader = new InputStreamReader(new FileInputStream(file),Charset.forName("GBK"));
			int tempchar;
			final StringBuffer sb = new StringBuffer();
			while ((tempchar = reader.read()) != -1) {
				sb.append((char) tempchar);
			}

			RetFileContent = sb.toString();
		} catch (final Exception e) {
			Log4jUtil.error(e);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (final IOException e1) {
					Log4jUtil.error(e1);
				}
			}
		}
		return RetFileContent;
	}

	/**
	 * 通过农行应答报文公共字段,组返回的 批量业务 回执
	 * 
	 * @param recvXmlInfo 农行银企返回的XML报文数据
	 * @return 平台要求的 ReturnState 实体
	 * @throws BizException
	 */
	public ReturnState processBatchRtnXml(final String recvXmlInfo) throws BizException {
		final ReturnState returnState = new ReturnState();
		Document document = null;
		try {
			document = DocumentHelper.parseText(recvXmlInfo);
		} catch (final DocumentException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109, "农行银企返回报文转换为dom4j的document类型出错：" + e.getMessage());
		}

		String TransCode = "";	// 返回交易代码
		String RespCode = "";		// 农行银企返回码 ： 0000交易成功
		String RespInfo = "";// 返回信息
		String RxtInfo = "";// 返回扩展信息
		String ReqSeqNo = ""; 	// 平台业务流水
		String RespDate = "";  	// 返回日期
		String RetState = "";  // 成功、失败状态
		String ChannelCode = "";  // 平台返回码
		String JrnNo = "";  	// 农行银企返回的日志号

		// 获取应答报文公共字段
		TransCode = document.selectSingleNode("/ap/TransCode").getText();     // 返回交易代码
		RespCode = document.selectSingleNode("/ap/RespCode").getText();     // 返回码 ： 0000交易成功
		if (document.selectSingleNode("/ap/RespInfo") != null) {
			RespInfo = document.selectSingleNode("/ap/RespInfo").getText();    // 银行响应信息
		}
		if (document.selectSingleNode("/ap/RxtInfo") != null) {
			RxtInfo = document.selectSingleNode("/ap/RxtInfo").getText(); // 银行返回信息
		}
		if (document.selectSingleNode("/ap/ReqSeqNo") != null) {	// 如果业务流水字段不为空，则返回给平台流水
			ReqSeqNo = document.selectSingleNode("/ap/ReqSeqNo").getText();
		}
		if (document.selectSingleNode("/ap/RespDate") != null) {	// 如果日期字段不为空，则返回给平台交易日期
			RespDate = document.selectSingleNode("/ap/RespDate").getText();
		}
		if (RespCode.equals("0000") || RespCode.equals("0001") || RespCode.equals("0002") || RespCode.equals("0003")
				|| RespCode.equals("0004") || RespCode.equals("0005") || RespCode.equals("0006")
				|| RespCode.equals("0007") || RespCode.equals("0008") || RespCode.equals("0009")) {
			RetState = "S"; // 由于成功的返回结果有多种可能（如交易成功0000，交易落地0001，预约受理0002，等），约定这种情况下返回来源都为‘0’。
			RespInfo = ""; // 对于批量业务，发送成功，不返回 批量交易渠道批次表(Channel_Batch)表的字段“RetDesc 返回附言”的值。
		} else {
			RetState = PayState.FAILED_STR;
		}
		if (document.selectSingleNode("/ap/Channel/JrnNo") != null) {	// 银行返回的日志号，用来匹配C503返回的交易结果
			JrnNo = document.selectSingleNode("/ap/Channel/JrnNo").getText();
		}

		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, RespCode));
		if (channelRtncode == null) {
			ChannelCode = TransReturnCode.code_9900;
		} else {
			ChannelCode = channelRtncode.getKftRtncode();
			RespInfo = channelRtncode.getChannelReamrk();
		}

		if (RespCode.equals("2002")) {
			RespInfo = RespInfo + "，操作员未签到，请做签到操作后再做其他交易";
		}
		// 组返回的实体

		returnState.setReturnState(RetState);
		returnState.setBankRetCode(RespCode);// 银行返回代码
		returnState.setReturnMsg(RespInfo);// 返回信息
		returnState.setBankPostScript(RxtInfo);// 返回扩展信息
		returnState.setSn(ReqSeqNo); // 请求方流水号ReqSeqNo（发业务时返回与平台的流水没有关系的东西，查询交易时返回渠道填写的‘请求方流水’）
										// 银行日志号JrnNo
		returnState.setChannelCode(ChannelCode);
		returnState.setCardType(BankCardType.DEBIT_CARD);
		returnState.setReturnObj(JrnNo);	// 银行日志号JrnNo
		returnState.setCheckDate(RespDate); // 渠道结算日期
		returnState.setRelTranAmount(BigDecimal.ZERO);  // 银行返回金额设置为0(农行银企返回数据中不提供）
		return returnState;
	}

	// //////////////////////////////////////////////
}
