package com.lycheepay.clearing.adapter.banks.abc.corp.bank.bean;

public class ERP2CT_CFRA33Bean {
	// ERP2CT_CFRA33Bean 支付机构上传人行监管报表（CFRA33）请求报文字段
	private String BatchFileName; //文件名
	private String SerialDate;// 报表日期 YYYYMMDD
	private String ReqDate;//请求日期 YYYYMMDD
	private String PayComName; //支付机构名称 (可空)
	private String FileSplit; //文件列分隔符 (可空, 默认竖线)
	private String CorpType;	//支付机构类型; 0-存管行; 1-合作行; (可空)
	private String Mode;	//判别模式; 0-非替代模式;1-替代模式;
	private int FileLineNum; //文件行数
	private String FileFlag;	//文件标志, 固定送1
	
	public String getBatchFileName() {
		return BatchFileName;
	}
	public void setBatchFileName(String batchFileName) {
		BatchFileName = batchFileName;
	}
	public String getPayComName() {
		return PayComName;
	}
	public void setPayComName(String payComName) {
		PayComName = payComName;
	}
	public String getFileSplit() {
		return FileSplit;
	}
	public void setFileSplit(String fileSplit) {
		FileSplit = fileSplit;
	}
	public String getCorpType() {
		return CorpType;
	}
	public void setCorpType(String corpType) {
		CorpType = corpType;
	}
	public String getMode() {
		return Mode;
	}
	public void setMode(String mode) {
		Mode = mode;
	}
	public int getFileLineNum() {
		return FileLineNum;
	}
	public void setFileLineNum(int fileLineNum) {
		FileLineNum = fileLineNum;
	}
	public String getFileFlag() {
		return FileFlag;
	}
	public void setFileFlag(String fileFlag) {
		FileFlag = fileFlag;
	}
	public String getSerialDate() {
		return SerialDate;
	}
	public void setSerialDate(String serialDate) {
		SerialDate = serialDate;
	}
	public String getReqDate() {
		return ReqDate;
	}
	public void setReqDate(String reqDate) {
		ReqDate = reqDate;
	}
	
}
