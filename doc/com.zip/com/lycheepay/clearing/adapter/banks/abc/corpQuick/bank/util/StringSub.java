package com.lycheepay.clearing.adapter.banks.abc.corpQuick.bank.util;

import java.nio.charset.Charset;

import org.apache.commons.lang.StringUtils;


/**
 * 农行快捷渠道专用 <P>截取一定数量的字符串(包括中文),按字节截取而不出现中文截取一半乱码现象</P>
 * 
 * @author 汤兴友 xytang
 */
public class StringSub {

	/**
	 * 
	 * @param str
	 * @param length
	 * @return
	 * @author 汤兴友 xytang
	 */
	public static String toLengthNoPadding(String s, int charNumber) {
		if (s == null) {
			return "";
		}

		String str = StringUtils.substring(s, 0, charNumber / 2);

		if (charNumber < str.getBytes(Charset.forName("GBK")).length) {
			return new String(str.getBytes(Charset.forName("GBK")), 0, charNumber);
		} else {
			return str;
		}
	}

	/**
	 * @param args
	 * @author 汤兴友 xytang
	 */
	public static void main(String[] args) {
		String r = toLengthNoPadding("实时 代付实时", 8);
		System.out.println(r);
		System.out.println(r.getBytes(Charset.forName("GBK")).length);
	}
}
