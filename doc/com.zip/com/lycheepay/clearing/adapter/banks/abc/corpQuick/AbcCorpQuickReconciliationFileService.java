/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-7-17 下午2:24:53
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.abc.corpQuick;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.SftpUtilByPass;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>农行快捷对账文件服务类</P>
 * 
 * @author 汤兴友 xytang
 */
@Service(ClearingAdapterAnnotationName.ABC_CORP_QUICK_RECONCILIATION_FILE_SERVICE)
public class AbcCorpQuickReconciliationFileService implements ReconciliationFileServiceInner {
	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;

	/*
	 * (non-Javadoc)
	 * @see
	 * com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile
	 * (java.lang.String, java.lang.String, java.lang.String)
	 * @author 汤兴友 xytang
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {

		Log4jUtil.setLogClass("ABC_QUICK", "check");

		final String logPrefix = "农行快捷";

		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);

		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		
		try{
			Log4jUtil.info("-----------从sftp服务器下载对账文件开始-------");
			final String fileFullPathName = this.downloadCheckFile(queryDate, channelId);
			
			reconciliationFileDTOList = this.buildTransactionDataList(logPrefix,
					channelId, fileFullPathName, settleDate);
		}catch(Exception e){
			Log4jUtil.error(e);
		}

		Log4jUtil.info(logPrefix + "生成统一格式对账文件");

		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId,
				settleDate, reconciliationFileDTOList);

		return fileFullPath;
	}

	/*
	 * (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#
	 * convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * @author 汤兴友 xytang
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix, channelId,
				targetFilePath, queryDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * 从sftp服务器下载对账文件
	 * 
	 * @return
	 */
	private String downloadCheckFile(final String workDate, final String channelId)
			throws ClearingAdapterBizCheckedException {
		final Map<String, String> channelParam = channelParamService.queryCodeParamsMapByChannelId(channelId);
		final String merchantID = channelParam.get("200001"); // 商户号
		final String bizCode_02 = channelParam.get("200006"); // 业务代码

		final String sftpIP = channelParam.get("200014");
		final String sftpUser = channelParam.get("200015");
		final String sftpPwd = channelParam.get("200016");
		final String checkFileDir = channelParam.get("200017");
		final String localFileDir = channelParam.get("200020");

		Assert.notNull(sftpIP, "sftp服务器sftpIp不能为空");
		Assert.notNull(sftpPwd, "sftp客户端sftpCertPsw不能为空");
		Assert.notNull(sftpUser, "sftp服务器sftpUser不能为空");
		Assert.notNull(checkFileDir, "sftp服务器sftpPath不能为空");
		Assert.notNull(localFileDir, "对账文件本地端路径不能为空");

		final StringBuffer sb = new StringBuffer(merchantID).append("_").append(bizCode_02).append("_")
				.append(workDate).append(".txt");
		final String fileName = sb.toString();
		Log4jUtil.info("请求下载的对账文件名为：" + fileName);

		// String accPath = sysParmService.getParmValue(SysparmConst.CHANNEL_CHECK_FILE) + "accPath" + channelId +
		// File.separator;
		final SftpUtilByPass sf = new SftpUtilByPass(sftpIP, sftpUser, null, sftpPwd, 22);
		final ChannelSftp sftp = sf.connectByPasswd();
		String path = localFileDir + File.separator + fileName;
		sf.download(checkFileDir, fileName, path, sftp);
		sf.disconnect(sftp);

		return path;
	}

	/**
	 * 构建对账数据对象
	 * 
	 * @param checkParam
	 * @return
	 * @throws ClearingAdapterBizCheckedException
	 */
	private ArrayList<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String channelId,
			final String fileFullPathName, final String settleDate) throws ClearingAdapterBizCheckedException {
		String logMsg = logPrefix + "准备生成对账对象。";
		Log4jUtil.info(logMsg);

		final ArrayList<ReconciliationFileDTO> accBeanList = new ArrayList<ReconciliationFileDTO>();
		BufferedReader bufferedReader = null;
		try {
			// 统计合计数据
			int totalNum_ = 0; // 总笔数
			Double totalAmount_ = 0.00; // 总金额
			Double totalInAmt_ = 0.0; // 入账总金额
			Double totalOutAmt_ = 0.0; // 扣款总金额
			Double totalFee_ = 0.0; // 总手续费

			// 文件头：总笔数|入账总金额|扣款总金额|总手续费
			String totalNum = "", totalInAmt = "", totalOutAmt = "", totalFee = "";

			// 循环对文本逐行处理
			int currLine = 0;
			final String errMsg = "";
			String data = null;
			bufferedReader = new BufferedReader(new FileReader(fileFullPathName));

			try {
				// 文件头：总笔数|入账总金额|扣款总金额|总手续费|
				data = bufferedReader.readLine();
				final String[] e = data.split("\\|");
				totalNum = e[0].trim();
				totalInAmt = e[1].trim();
				totalOutAmt = e[2].trim();
				totalFee = e[3].trim();
				Log4jUtil.info("对账文件第1行文件内容为：{}", data);
				Log4jUtil.info("总笔数：{} 入账总金额：{} 扣款总金额：{} 总手续费：{}", totalNum, totalInAmt, totalOutAmt, totalFee);
			} catch (final IOException e1) {
				Log4jUtil.error(e1);
			}

			// 文件体：商户号|业务代码|终端号|功能码|交易日期|交易时间|终端流水号|商户平台流水号|
			// 银行系统参照号|银行结算日期|账号|交易金额|手续费|退款原消费银行系统参考号|
			final String custId = "";// 商户号
			final String condCode = "";// 业务代码
			final String termId = "";// 终端号
			String tranCode = "";// 功能码
			final String tranDate = "";// 交易日期
			final String tranTime = "";// 交易时间
			final String termserNum = "";// 系统跟踪号
			String resSn = "";// 商户平台流水号
			final String sysRefern = "";// 银行系统参考号
			final String workDate = "";// 银行结算日期
			final String cardNo = "";// 账号
			String amount = "";// 交易金额
			String fee = "";// 手续费
			final String osysRefern = "";// 退款原消费银行系统参考号
			final Double doubleAmt = 0.0;// 交易金额 Double 类型

			while ((data = bufferedReader.readLine()) != null) {
				final ReconciliationFileDTO dto = new ReconciliationFileDTO();
				currLine++; // 对账文件 行循环
				logMsg = logPrefix + "对账文件第 " + currLine + " 行文件内容为：" + data;
				Log4jUtil.info(logMsg);
				if (0 < data.trim().length()) {

					final String[] es = data.split("\\|");
					if (1 < es.length) {
						final String tradeDate = es[4].trim();// 交易日期时间
						if (!DateUtil.isValidDate(tradeDate, "yyyyMMdd")) {
							// 若不是合法交易时间，则直接跳过该行
							logMsg = logPrefix + "该行不是合法的交易数据。";
							Log4jUtil.info(logMsg);
							continue;
						}

						tranCode = es[3].trim();// 功能码
						resSn = es[6].trim();// 系统跟踪号 = BankSendSn
						amount = es[11].trim();// 交易金额
						fee = es[12].trim();// 交易金额

						totalAmount_ = totalAmount_ + Double.valueOf(amount) / 100;
						totalFee_ = totalFee_ + Double.valueOf(fee) / 100;

						if ("0200000000".equals(tranCode)) {
							dto.setPayGet(STR_GET);
							totalInAmt_ = totalInAmt_ + Double.valueOf(amount) / 100;
						} else if ("0220470000".equals(tranCode)) {
							dto.setPayGet(STR_PAY);
							totalOutAmt_ = totalOutAmt_ + Double.valueOf(amount) / 100;
						} else {
							continue;
						}

						dto.setCheckDate(settleDate);
						dto.setBankSendId(resSn); // 订单号
						dto.setTransDate(tradeDate); // 交易日期
						dto.setAmount(new BigDecimal(Double.parseDouble(amount) / 100));// 交易金额
						dto.setChannelId(channelId);

						// 交易状态 00-支付成功；01-支付失败；02-超时
						dto.setBankTransState("00");
						totalNum_++;

						final StringBuffer sb = new StringBuffer();
						sb.append("添加到accBeanList的第").append(totalNum_).append("条记录:").append(" checkDate:")
								.append(dto.getCheckDate()).append(" BankSendId:").append(dto.getBankSendId())
								.append(" TranDate:").append(dto.getTransDate()).append(" Amount:")
								.append(dto.getAmount().doubleValue());
						Log4jUtil.info(sb.toString());

						accBeanList.add(dto);
					}
				}
			}

			if (0 < errMsg.length()) {
				Log4jUtil.error(errMsg);
			}
			Log4jUtil.info(logPrefix + "本次共成功生成 " + totalNum_ + "行对账明细。总金额为：" + String.format("%1$.2f", totalAmount_));
		} catch (final Exception e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.PARSE_RECONCILIATION_FILE_FAILED, logPrefix
					+ "农行快捷系统对账失败,文件:[" + fileFullPathName + "]", e);
		} finally {
			try {
				if (null != bufferedReader) {
					bufferedReader.close();
				}// 关闭文件
			} catch (final Exception e) {
				Log4jUtil.error(logPrefix + "关闭文件流出错:" + e);
				throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, logPrefix
						+ "农行快捷系统对账失败,关闭文件流出错文件:[" + fileFullPathName + "]", e);
			}
		}
		return accBeanList;
	}

}
