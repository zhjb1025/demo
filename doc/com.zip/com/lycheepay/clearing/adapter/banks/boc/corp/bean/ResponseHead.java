/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午6:57:10
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>响应头</P>
 * 
 * @author 张凯锋
 */
public class ResponseHead {

	private String resultCode;	// 交易返回码
	private String resultDesc;	// 描述信息
	private String sendTimestamp;// SEND_TIMESTAMP 报文时间 DATETIME M 报文发送时间戳

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(final String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultDesc() {
		return resultDesc;
	}

	public void setResultDesc(final String resultDesc) {
		this.resultDesc = resultDesc;
	}

	public String getSendTimestamp() {
		return sendTimestamp;
	}

	public void setSendTimestamp(final String sendTimestamp) {
		this.sendTimestamp = sendTimestamp;
	}

	void setResponseHead(final Dom4jXMLMessage dom4jxml, final Node head) {
		resultCode = dom4jxml.getNodeText(head, "RESULT_CODE");
		resultDesc = dom4jxml.getNodeText(head, "RESULT_DESC");
		sendTimestamp = dom4jxml.getNodeText(head, "SEND_TIMESTAMP");
	}
}
