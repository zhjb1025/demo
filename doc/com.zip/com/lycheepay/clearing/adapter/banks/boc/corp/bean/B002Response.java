/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:33:42
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>单笔实时代付交易响应</P>
 * 
 * @author 张凯锋
 */
public class B002Response extends ResponseHead {

	private String accountDate;// 实际会计日期 DATE O 只有在后台业务子系统与主机系统发生实际账务才会填写主机账务返回的实际扣款日期
	private String transAmt;// 交易金额 MONEY O 请求报文中的金额
	private String handleFee;// 收取手续费 MONEY O 不收取时为0.00
	private String actualDeductAmt;// 实收金额 MONEY O 交易金额+实收金额
	private String handleFeeType;// 手续费扣取类型 HANDLE_FEE_TYPE O 见附录

	public B002Response(final byte[] respBytes) throws BizException {
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respBytes);
		final Node head = dom4jxml.getNode("/B002_RESPONSE/HEAD");
		setResponseHead(dom4jxml, head);
		final Node body = dom4jxml.getNode("/B002_RESPONSE/BODY");
		accountDate = dom4jxml.getNodeText(body, "ACCOUNT_DATE");
		transAmt = dom4jxml.getNodeText(body, "TRANS_AMT");
		handleFee = dom4jxml.getNodeText(body, "HANDLE_FEE");
		actualDeductAmt = dom4jxml.getNodeText(body, "ACTUAL_DEDUCT_AMT");
		handleFeeType = dom4jxml.getNodeText(body, "HANDLE_FEE_TYPE");
	}

	public String getAccountDate() {
		return accountDate;
	}

	public void setAccountDate(final String accountDate) {
		this.accountDate = accountDate;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(final String transAmt) {
		this.transAmt = transAmt;
	}

	public String getHandleFee() {
		return handleFee;
	}

	public void setHandleFee(final String handleFee) {
		this.handleFee = handleFee;
	}

	public String getActualDeductAmt() {
		return actualDeductAmt;
	}

	public void setActualDeductAmt(final String actualDeductAmt) {
		this.actualDeductAmt = actualDeductAmt;
	}

	public String getHandleFeeType() {
		return handleFeeType;
	}

	public void setHandleFeeType(final String handleFeeType) {
		this.handleFeeType = handleFeeType;
	}

}
