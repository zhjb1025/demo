/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-15 下午3:01:52
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.util.DateUtil;


/**
 * <P>批量代扣请求明细</P>
 * 
 * @author 张凯锋
 */
public class B004RequestDetail {

	private String transNo;// 交易流水号 TRANS_NO M 标识唯一交易
	private String transDate;// 交易日期 DATE M 交易日期,主要用于对账,交易重发(隔天)时,此日期必须等同于首次发送交易报文中的交易日期
	private String accountNo;// 借方账号 ACCOUNT_NO M 代收的客户帐号
	private String accountName;// 借方户名 ACCOUNT_NAME M 账户户名
	// private String provinceCode;// 省份代码 PROVINCE_CODE M 借方账号省份代码
	// private String bankName;// 开户行名 BANK_NAME O 借方账号开户银行行名
	// private String bankNo;// 开户行号 BANK_NO O 借方账号开户银行行号
	private String money;// 金额 MONEY M 交易金额
	private String idType;// 证件类型 ID_TYPE O 见附录
	private String idNo;// 证件号码 ID_NO O 具体证件号码
	private String agreementNo;// 协议号 AGREEMENT_NO O 客户协议号
	private String useItem;// 长度限制50字符.必填,需要输入该笔代收代付业务的款项用途.银行方给商户打印对账单时需要.
	private String postScript;// 附言 200 BYTE O 保留商户信息

	public B004RequestDetail(final String transNo, final String accountNo, final String accountName, final String money) {
		this.transNo = transNo;
		this.transDate = DateUtil.getPrettyDate(new Date());
		this.accountNo = accountNo;
		this.accountName = accountName;
		// this.provinceCode = provinceCode;
		// this.bankName = "";
		// this.bankNo = "";
		this.money = money;
		this.idType = "";
		this.idNo = "";
		this.agreementNo = "";
		this.useItem = "700";
		this.postScript = "";
	}

	/**
	 * <p>获取报文</p>
	 * 
	 * @return
	 * @author 张凯锋
	 */
	public String getXML() {
		final StringBuilder sb = new StringBuilder("<DETAIL>");
		sb.append("<TRANS_NO>").append(transNo).append("</TRANS_NO>");
		sb.append("<TRANS_DATE>").append(transDate).append("</TRANS_DATE>");
		sb.append("<ACCOUNT_NO>").append(accountNo).append("</ACCOUNT_NO>");
		sb.append("<ACCOUNT_NAME>").append(accountName).append("</ACCOUNT_NAME>");
		// sb.append("<PROVINCE_CODE>").append(provinceCode).append("</PROVINCE_CODE>");
		// sb.append("<BANK_NAME"+nil(bankName)+">").append(bankName).append("</BANK_NAME>");
		// sb.append("<BANK_NO"+nil(bankNo)+">").append(bankNo).append("</BANK_NO>");
		sb.append("<MONEY" + nil(money) + ">").append(money).append("</MONEY>");
		sb.append("<ID_TYPE" + nil(idType) + ">").append(idType).append("</ID_TYPE>");
		sb.append("<ID_NO" + nil(idNo) + ">").append(idNo).append("</ID_NO>");
		sb.append("<AGREEMENT_NO" + nil(agreementNo) + ">").append(agreementNo).append("</AGREEMENT_NO>");
		sb.append("<USE_ITEM" + nil(useItem) + ">").append(useItem).append("</USE_ITEM>");
		sb.append("<POST_SCRIPT" + nil(postScript) + ">").append(postScript).append("</POST_SCRIPT>");
		sb.append("</DETAIL>");
		return sb.toString();
	}

	public String getTransNo() {
		return transNo;
	}

	public void setTransNo(final String transNo) {
		this.transNo = transNo;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(final String transDate) {
		this.transDate = transDate;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(final String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(final String accountName) {
		this.accountName = accountName;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(final String money) {
		this.money = money;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(final String idType) {
		this.idType = idType;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(final String idNo) {
		this.idNo = idNo;
	}

	public String getAgreementNo() {
		return agreementNo;
	}

	public void setAgreementNo(final String agreementNo) {
		this.agreementNo = agreementNo;
	}

	public String getPostScript() {
		return postScript;
	}

	public void setPostScript(final String postScript) {
		this.postScript = postScript;
	}

	public static String nil(final String value) {
		return StringUtils.isNotBlank(value) ? "" : " xsi:nil=\"true\"";
	}

	public String getUseItem() {
		return useItem;
	}

	public void setUseItem(final String useItem) {
		this.useItem = useItem;
	}
}
