/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.util;

import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <P>中行网上银企报文HTTP方式发送</P>
 * @author #{杜波(15999653650)}
 */
@Service
public class BocInternetCorpHttpPostMessages {
	/**
	 * 
	 * <p>以HTTP方式发送中行网上银企报文</p>
	 * 
	 * @param messages 需要发送的报文
	 * @param sendUrl 发送URL
	 * @return
	 * @author 杜波(15999653650)
	 */
	public String sendHttpPostMessages(String messages, String sendUrl) throws BizException {
		Log4jUtil.info("开始执行 httpPostXml方法,sendUrl:{},messages:{}", sendUrl, messages);

		HttpURLConnection conn = null;
		PrintWriter out = null;
		try {
			URL url = new URL(sendUrl);
			conn = (HttpURLConnection) url.openConnection();
			conn.setReadTimeout(60000);
			conn.setDoOutput(true);
			conn.setRequestProperty("Pragma:", "no-cache");
			conn.setRequestProperty("Cache-Control", "no-cache");
			conn.setRequestProperty("Content-Type", "application/xml");
			out = new PrintWriter(conn.getOutputStream());

		} catch (Exception e) {
			Log4jUtil.error(e);
			IOUtils.closeQuietly(out);
			throw new BizException(e, TransReturnCode.code_9103, e.getMessage());
		}
		String retStr = "";
		try {
			if (out != null) {
				out.println(messages);
				out.flush();
			}
			retStr = IOUtils.toString(conn.getInputStream(), Charset.forName("UTF-8"));
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
		} finally {
			IOUtils.closeQuietly(out);
			if (conn != null) {
				try {
					conn.disconnect();
				} catch (Exception e) {
					Log4jUtil.error(e);
				}
			}
		}
		Log4jUtil.info("银行返回结果：{}", retStr);

		return retStr;
	}
}
