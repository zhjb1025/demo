/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-8-22 下午3:56:19
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.service;

import java.nio.charset.Charset;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpTransStatusQueryRequestBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpTransStatusQueryResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpHttpPostMessages;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpRequestMessagesConverter;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpResponseMessageConverter;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.common.constant.TransReturnCode;

/**
 * <P>中国银行网上银企交易状态查询业务</P>
 * @author 杜波(15999653650)
 */
@Service
public class BocInternetCorpTransStatusQueryService {
	@Autowired
	private BocInternetCorpSignInService bocInternetCorpSignInService;
	@Autowired
	private BocInternetCorpRequestMessagesConverter requestMessagesConverter;
	@Autowired
	private BocInternetCorpResponseMessageConverter responseMessageConverter;
	@Autowired
	private BocInternetCorpHttpPostMessages bocInternetCorpHttpPostMessages;
	/**
	 * 
	 * <p>获取中国银行网上银企交易状态查询信息</p>
	 * @param transStatusQueryRequestBean
	 * @param channelParamMap
	 * @return
	 * @throws ClearingAdapterBizCheckedException
	 * @author 杜波(15999653650)
	 */
	public BocInternetCorpTransStatusQueryResponseBean getTransStatusQueryMsg(BocInternetCorpTransStatusQueryRequestBean transStatusQueryRequestBean,
                                                                              Map<String, String> channelParamMap) throws ClearingAdapterBizCheckedException{
		BocInternetCorpTransStatusQueryResponseBean transStatusQueryResponseBean = new BocInternetCorpTransStatusQueryResponseBean();
		String sendMsg = requestMessagesConverter.getBocInternetCorpTransStatusQueryReqestXml(transStatusQueryRequestBean, channelParamMap);
		String responseMsg = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendMsg,channelParamMap.get("100006"));
		transStatusQueryResponseBean = responseMessageConverter.getBocInternetCorpTransStatusResponseMessage(responseMsg.getBytes(Charset.forName("UTF-8")));	
		
		//判断是否是由于未签到导致交易失败，如果是，则需要进行签到并重新交易
		if(transStatusQueryResponseBean.getRspcod()!=null&&channelParamMap.get("100012").indexOf(transStatusQueryResponseBean.getRspcod())>=0){
			BocInternetCorpSignInResponseBean signInResponseBean = bocInternetCorpSignInService.bocInternetCorpSignIn();
			if("B001".equalsIgnoreCase(signInResponseBean.getRspCod())){
				//重发当前报文
				 responseMsg = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendMsg,channelParamMap.get("100006"));
				transStatusQueryResponseBean = responseMessageConverter.getBocInternetCorpTransStatusResponseMessage(responseMsg.getBytes(Charset.forName("UTF-8")));	
			}else{
				throw new BizException(TransReturnCode.code_9108, "中行网上银企签到失败！");
			}
		}
		
		return transStatusQueryResponseBean;
	}
}
