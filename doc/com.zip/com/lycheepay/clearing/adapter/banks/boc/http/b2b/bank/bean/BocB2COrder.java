package com.lycheepay.clearing.adapter.banks.boc.http.b2b.bank.bean;

import java.util.HashMap;
import java.util.Map;

import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CPayBean;


/**
 * <P>中行B2C订单信息实体</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午4:50:00
 */
public class BocB2COrder {
	private String bocNo = "";// 商户号
	private String orderNo = "";// 订单号 商户系统产生的订单号；数字与26个英文字母以及中划线（-）和下划线（_）
	private String curCode = "001";// 目前只支持001-人民币固定填001
	private String orderAmount = "";// 订单总金额 格式： 不超过12位整数位+1位小数点+2位小数
									// 无效格式如123，.10，1.131,有效格式如1.10，0.10
	private String orderTime = "";// 支付交易的日期时间 14位
	private String orderNote = "";// 订单描述，要求如果全中文最多允许15个汉字长度
	private String orderUrl = "";// 通知商户URL varchar(200) 网关完成交易获得明确交易状态后向该URL发送通知
	private String signData = "";// 数字签名

	// bocNo=&orderNo=&curCode=&orderAmount=&orderTime=&orderNote=&orderUrl=&signData=
	public Map<String, String> creatBocB2BPayParam(final BocB2CPayBean bocB2CPayBean) {
		final Map<String, String> params = new HashMap<String, String>();
		params.put("bocNo", bocNo);
		params.put("orderNo", orderNo);
		params.put("curCode", curCode);
		params.put("orderAmount", orderAmount);
		params.put("orderTime", orderTime);
		params.put("orderNote", orderNote);
		params.put("orderUrl", orderUrl);
		params.put("signData", signData);
		return params;
	}

	public String getToBeSignedData() {
		// 商户签名数据串格式，各项数据用管道符分隔：
		// 商户号|商户订单号|订单币种|订单金额|订单时间bocNo|orderNo|curCode|orderAmount|orderTime
		final String toBeSignedString = bocNo + "|" + orderNo + "|" + curCode + "|" + orderAmount + "|" + orderTime;
		return toBeSignedString;
	}

	public String getBocNo() {
		return bocNo;
	}

	public void setBocNo(final String bocNo) {
		this.bocNo = bocNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(final String orderNo) {
		this.orderNo = orderNo;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(final String curCode) {
		this.curCode = curCode;
	}

	public String getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(final String orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(final String orderTime) {
		this.orderTime = orderTime;
	}

	public String getOrderNote() {
		return orderNote;
	}

	public void setOrderNote(final String orderNote) {
		this.orderNote = orderNote;
	}

	public String getOrderUrl() {
		return orderUrl;
	}

	public void setOrderUrl(final String orderUrl) {
		this.orderUrl = orderUrl;
	}

	public String getSignData() {
		return signData;
	}

	public void setSignData(final String signData) {
		this.signData = signData;
	}

}
