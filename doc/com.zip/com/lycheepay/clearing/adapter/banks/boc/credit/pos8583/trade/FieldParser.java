package com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.trade;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.banks.abc.credit.pos8583.IsoType;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.ByteUtils;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgField;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgFieldType;
import com.lycheepay.clearing.adapter.common.exception.RuntimeBizException;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 消息域解析.
 * 
 * @author aps-mhc
 */
public class FieldParser {
	private MsgFieldType fieldType;

	public void setFieldType(final MsgFieldType fieldType) {
		this.fieldType = fieldType;
	}

	public MsgFieldType getFieldType() {
		return fieldType;
	}

	/**
	 * 解析消息.
	 * 
	 * @param msg 消息来源
	 * @param startPos 开始位置.
	 * 
	 * @return 获取的长度.
	 */
	public int parse(final Map<String, MsgField> fields, final byte[] msg, int startPos) {
		if (ArrayUtils.isEmpty(msg) || startPos >= msg.length || isDone(fields)) {
			return 0;
		}
		final String fieldNo = fieldType.getNo();
		MsgField field = fields.get(fieldNo);

		if (field == null) {
			field = MsgField.create(fieldNo);
			field.setLenOfLeaderLength(getLenOfLeaderLength());
			field.setHasLeaderLength(hasLeaderLength());

			field.setContentType(fieldType.getContentType());
			fields.put(fieldNo, field);
		}

		// 需要的字节数, 已获取的字节数.
		int needCount = 0;
		int gotLen = 0;
		final int msgLen = msg.length;

		// 已取字节的次数, 超出一定次数后认为程序出错.
		int gotCount = 0;

		while ((needCount = getNeedLength(field)) > 0) {
			startPos += gotLen;

			final int canGetLen = getCanGetLen(msgLen, startPos, needCount);

			// 已无数据, 跳出, 等待下批数据.
			if (canGetLen == 0) {
				return gotLen;
			}

			// 可取得的消息片段.
			final byte[] gotByte = ArrayUtils.subarray(msg, startPos, startPos + canGetLen);
			field.setOrigMsg(ArrayUtils.addAll(field.getOrigMsg(), gotByte));

			if (fieldType.getContentType() == IsoType.BCD) {
				Log4jUtil.info("gotByte--->bcdToStr:" + ByteUtils.bcdToStr(gotByte));
			} else if (fieldType.getContentType() == IsoType.BINARY) {
				Log4jUtil.info("gotByte--->binaryToByteToStr:" + Arrays.toString(gotByte));
			} else if (fieldType.getContentType() == IsoType.ASCII) {
				Log4jUtil.info("gotByte--->asciiToStr:" + new String(gotByte, Charset.forName("GBK")));
			}

			gotLen += gotByte.length;
			// 超出100次仍不能解完本域,认为程序错误.
			if (gotCount++ > 100) {
				throw new RuntimeBizException("解包错误,域编号:" + fieldNo);
			}
		}
		return gotLen;
	}

	/**
	 * 本次应该取的字节的长度.
	 * 
	 * @param msgLen
	 * @param startPos
	 * @param needCount
	 * @return
	 */
	private int getCanGetLen(final int msgLen, final int startPos, final int needCount) {
		// msg足够, 取所需要的; msg不足, 取全部.
		if (startPos >= msgLen - 1) {
			return 0;
		}

		final int remainLen = msgLen - startPos;
		final boolean isEnough = remainLen >= needCount;

		return isEnough ? needCount : remainLen;
	}

	protected boolean hasLeaderLength() {
		return false;
	}

	/**
	 * 前导长度标识, 适用于可变长域.
	 * 
	 * @return
	 */
	public int getLenOfLeaderLength() {
		return 0;
	}

	/**
	 * 是否接收完成, 不再需要数据表示完成.
	 * 
	 * @param fields
	 * @return
	 */
	public boolean isDone(final Map<String, MsgField> fields) {
		final MsgField field = fields.get(fieldType.getNo());

		return isDone(field);
	}

	/**
	 * 是否接收完成, 不再需要数据表示完成.
	 * 
	 * @param fields
	 * @return
	 */
	public boolean isDone(final MsgField field) {
		if (field == null) {
			return false;
		}

		if (!fieldType.getNo().equals(field.getNo())) {
			throw new RuntimeBizException("解析器和报文域的错误匹配");
		}

		return getNeedLength(field) == 0;
	}

	/**
	 * 适用于定长域.
	 * 
	 * @param field
	 * @return
	 */
	protected int getNeedLength(final MsgField field) {
		return field.getMaxLength() - field.getOrigMsgLength();
	}
}
