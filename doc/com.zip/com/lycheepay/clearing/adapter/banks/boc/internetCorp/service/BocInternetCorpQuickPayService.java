/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-22 下午4:01:32
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.service;

import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayResponseMessagesBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpHttpPostMessages;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpRequestMessagesConverter;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpResponseMessageConverter;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.biz.GeneratorAccountDetailFile;
import com.lycheepay.clearing.common.constant.AccountTransType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.AccountHistoryTransDetailDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelBatch;
import com.lycheepay.clearing.common.model.ChannelBatchId;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P> 中国银行网上银企代发业务 </P>
 * 
 * @author #{杜波(15999653650)}
 */
@Service("bocInternetCorpQuickPayService")
public class BocInternetCorpQuickPayService {
	@Autowired
	private BillnoSnService billnoSnService;
	@Autowired
	private ChannelParmService channelParmService;
	@Autowired
	private ChannelBatchService channelBatchService;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager sequenceManager;
	@Autowired
	private BocInternetCorpSignInService bocInternetCorpSignInService;
	@Autowired
	private BankAccountBalanceService bankAccountBalanceService;
	@Autowired
	private BocInternetCorpHttpPostMessages bocInternetCorpHttpPostMessages;
	@Autowired
	private BocInternetCorpRequestMessagesConverter requestMessagesConverter;
	@Autowired
	private BocInternetCorpResponseMessageConverter responseMessageConverter;

	/**
	 * 
	 * <p> 中国银行网上银企代发业务 </p>
	 * 
	 * @param params
	 * @return
	 * @author #{杜波(15999653650)}
	 * @throws BizException
	 */
	@Transactional
	public BatchSendResult bocInternetCorpBatchPay(String channelBatchId, List<ChannelTempBill> payList)
			throws BizException {
		Log4jUtil.info("中国银行网上银企代发业务==");

		// List<ReturnState> returnStateList = new ArrayList<ReturnState>();
		// ReturnState returnState = new ReturnState();
		BatchSendResult batchSendResult = new BatchSendResult();
		if (payList != null && payList.size() > 0) {

			// 取得快付通平台的账户信息
			Log4jUtil.info("取得快付通平台的账户信息");
			BankaccountBalance bankaccountBalance = bankAccountBalanceService
					.getBankaccountBean(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
			if (bankaccountBalance == null) {
				Log4jUtil.info("快付通中-中行网上银企平台的账户信息有误！");
				throw new BizException(TransReturnCode.code_9108, "快付通中-中行网上银企平台的账户信息有误！");
			}
			// 获取去批信息，批总笔数，批总金额...
			Log4jUtil.info("获取去批信息，批总笔数，批总金额...");
			ChannelBatch channelBatch = channelBatchService.findById(new ChannelBatchId(ChannelIdEnum.BOC_CREDIT_REPAY
					.getCode(), channelBatchId));

			// 发送批量代付报文
			Log4jUtil.info("发送批量代付报文");
			BocInternetCorpQuickPayResponseMessagesBean responseMessagesBean = this
					.sendBocInternetCorpBatchPayMessages(payList, channelBatchId, bankaccountBalance, channelBatch);

			if (responseMessagesBean == null) {
				batchSendResult.setStatus(PayState.FAILED_STR);
				return batchSendResult;
			}
			// 检查总体响应状态
			// if ("B001".equalsIgnoreCase(responseMessagesBean.getRspcod())) {
			// batchSendResult.setBankReturnCode(responseMessagesBean.getRspcod());
			// batchSendResult.setBankReturnMsg(responseMessagesBean.getRspmsg());
			// } else {
			// throw new ClearingAdapterBizCheckedException(TransReturnCode.code_9900,
			// responseMessagesBean.getRspmsg());
			// }
			// 检查明细响应状态
			if ("B001".equalsIgnoreCase(responseMessagesBean.getRspcod())
					&& "B001".equalsIgnoreCase(responseMessagesBean.getSubRspcod())) {
				batchSendResult.setStatus(PayState.SUCCEED_STR);
			} else {
				batchSendResult.setStatus(PayState.FAILED_STR);
			}
			batchSendResult.setBankReturnCode(responseMessagesBean.getSubRspcod());
			batchSendResult.setBankReturnMsg(responseMessagesBean.getSubRspmsg());

			if (responseMessagesBean != null && responseMessagesBean.getObssid() != null
					&& responseMessagesBean.getInsid() != null) {
				Log4jUtil.info("保存响应报文回传的网银交易流水号(obssid)与客户业务编号(insid)");
				batchSendResult.setBankReturnBatchId(responseMessagesBean.getObssid() + "#" + responseMessagesBean.getInsid());
				// channelBatch.setBankBatchid(responseMessagesBean.getObssid() + "#" +
				// responseMessagesBean.getInsid());
				// channelBatchService.update(channelBatch);
			} else {
				Log4jUtil.info("中行网上银企代付响应报文有误--交易流水号(obssid)与客户业务编号(insid)为null");
				batchSendResult.setBankReturnMsg("中行网上银企代付响应报文有误--交易流水号(obssid)与客户业务编号(insid)为null");
				batchSendResult.setStatus(PayState.FAILED_STR);
			}
		}
		return batchSendResult;
	}

	/**
	 * 
	 * <p>发送代发报文</p>
	 * 
	 * @param paybillList
	 * @param channelBatchId
	 * @param bankaccountBalance
	 * @param channelBatch
	 * @param channelParam
	 * @return
	 * @author #{杜波(15999653650)}
	 * @throws BizException
	 */
	@Transactional
	public BocInternetCorpQuickPayResponseMessagesBean sendBocInternetCorpBatchPayMessages(
			List<ChannelTempBill> payList, String channelBatchId, BankaccountBalance bankaccountBalance,
			ChannelBatch channelBatch) throws BizException {
		// 保存批量代付渠道交易流水信息
		Log4jUtil.info("保存批量代付渠道交易流水信息");
		final List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>(payList.size());
		for (int i = 0; i < payList.size(); i++) {
			ChannelTempBill channelTempBill = payList.get(i);
			BillnoSn billnoSn = billnoSnService.toBillnoSn(channelTempBill, channelBatchId,
					sequenceManager.getBocInternetCorpBatchSeq(), i);
			billNoSnList.add(billnoSn);
		}
		billnoSnService.batchSave(billNoSnList);
		// 获取中行网上银企签到报文参数
		Log4jUtil.info(" 获取中行网上银企签到报文参数");
		Map<String, String> channelParamMap = channelParmService
				.queryCodeParamsMapByChannelId(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
		channelParamMap.put("trnId", sequenceManager.getBocInternetCorpSn());

		// 创建批量代付报文
		Log4jUtil.info(" 创建中行批量代付请求报文");
		String sendMsg = requestMessagesConverter.getBocInternetCorpQuickPayRequestXml(billNoSnList,
				bankaccountBalance, channelBatch, channelParamMap);

		// 发送报文
		Log4jUtil.info(" 发送中行批量代付请求报文");
		String receiveMessages = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendMsg,
				channelParamMap.get("100006"));

		// 解析回执
		Log4jUtil.info(" 解析中行批量代付响应报文");
		if (StringUtils.isNotBlank(receiveMessages)) {
			BocInternetCorpQuickPayResponseMessagesBean reqMsgBean = responseMessageConverter
					.getBocInternetCorpQuickPayResponseMessage(receiveMessages.getBytes(Charset.forName("UTF-8")));
			// 判断是否是由于未签到导致交易失败，如果是，则需要进行签到并重新交易
			if (reqMsgBean.getRspcod() != null && channelParamMap.get("100012").indexOf(reqMsgBean.getRspcod()) >= 0) {
				BocInternetCorpSignInResponseBean signInResponseBean = bocInternetCorpSignInService
						.bocInternetCorpSignIn();
				if ("B001".equalsIgnoreCase(signInResponseBean.getRspCod())) {
					channelParamMap = channelParmService.queryCodeParamsMapByChannelId(ChannelIdEnum.BOC_CREDIT_REPAY
							.getCode());
					channelParamMap.put("trnId", sequenceManager.getBocInternetCorpSn());
					// 创建批量代付报文
					Log4jUtil.info("二次创建中行批量代付请求报文");
					sendMsg = requestMessagesConverter.getBocInternetCorpQuickPayRequestXml(billNoSnList,
							bankaccountBalance, channelBatch, channelParamMap);

					// 重发报文
					receiveMessages = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendMsg,
							channelParamMap.get("100006"));
					return responseMessageConverter.getBocInternetCorpQuickPayResponseMessage(receiveMessages
							.getBytes(Charset.forName("UTF-8")));

				} else {
					throw new BizException(TransReturnCode.code_9108, "中行网上银企签到失败！");
				}
			} else {
				return reqMsgBean;
			}
		} else {
			Log4jUtil.info("中行网上银企代付(批量)响应报文错误！");
			throw new BizException(TransReturnCode.code_9109, "中行网上银企代付(批量)响应报文错误！");
		}
	}

	public String queryAccountHistoryTransDetail(String date, String accountNo, String filePath) throws BizException {
		String sendXMLTemplet = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><bocb2e version=\"120\" locale=\"zh_CN\"><head><termid>{0}</termid><trnid>{1}</trnid><custid>{2}</custid><cusopr>{3}</cusopr><trncod>b2e0044</trncod><token>{4}</token></head><trans><trn-b2e0044-rq><b2e0044-rq><ibknum>{5}</ibknum><actacn>{6}</actacn><datescope><from>{7}</from><to>{8}</to></datescope><amountscope><from>1</from><to>9999999999999</to></amountscope><begnum>{9}</begnum><recnum>50</recnum><direction>A</direction></b2e0044-rq></trn-b2e0044-rq></trans></bocb2e>";
		Map<String, String> channelParamMap = channelParmService
				.queryCodeParamsMapByChannelId(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
		String termId = channelParamMap.get("100001"); // termId
		String trnid = sequenceManager.getBocInternetCorpSn();// trnid
		String custId = channelParamMap.get("100002"); // custId
		String cusOpr = channelParamMap.get("100003"); // cusOpr
		String token = channelParamMap.get("100007");// token
		String ibknum = channelParamMap.get("100011");// ibknum
		String sendUrl = channelParamMap.get("100006");// URL
		String actacn = accountNo;
		if (StringUtils.isBlank(accountNo)) {
			BankaccountBalance bankaccountBalance = bankAccountBalanceService
					.getBankaccountBean(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
			actacn = bankaccountBalance.getAccountNo();
		}
		boolean hasNext = true;
		int nextPage = 1;

		List<AccountHistoryTransDetailDTO> list = new ArrayList<AccountHistoryTransDetailDTO>();
		while (hasNext) {
			String[] params = new String[] { termId, trnid, custId, cusOpr, token, ibknum, actacn, date, date,
					String.valueOf(nextPage) };
			String sendXML = MessageFormat.format(sendXMLTemplet, params);
			String responseMessages = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendXML, sendUrl);
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(responseMessages.getBytes(Charset.forName("UTF-8")));
			Node statusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0044-rs/status");
			String rspcod = dom4jxml.getNodeText(statusNode, "rspcod");
			String rspmsg = dom4jxml.getNodeText(statusNode, "rspmsg");
			if ("B002".equalsIgnoreCase(rspcod))
				nextPage += 50;
			else
				hasNext=false;
			if ("B001".equalsIgnoreCase(rspcod) || "B002".equalsIgnoreCase(rspcod)) {

				List<Node> nodeList = dom4jxml.getNodeList("/bocb2e/trans/trn-b2e0044-rs/b2e0044-rs");
				for (int i = 0; i < nodeList.size(); i++) {
					Node rsNode = nodeList.get(i);
					String direction = dom4jxml.getNodeText(rsNode, "direction");// 来往账标识（C-来账，D-往账）
					String txndate = dom4jxml.getNodeText(rsNode, "txndate");// 交易日期 YYYYMMDD
					String txntime = dom4jxml.getNodeText(rsNode, "txntime");// 交易时间 HH24MISS
					String txnamt = dom4jxml.getNodeText(rsNode, "txnamt");// 交易金额
					String acctbal = dom4jxml.getNodeText(rsNode, "acctbal");// 账户交易后余额
					String vchnum = dom4jxml.getNodeText(rsNode, "vchnum");// 凭证号
					String transid = dom4jxml.getNodeText(rsNode, "transid");// 凭证号
					String acsref = dom4jxml.getNodeText(rsNode, "acsref");// 摘要
					String furinfo = dom4jxml.getNodeText(rsNode, "furinfo");// 用途
					AccountHistoryTransDetailDTO detailDTO = new AccountHistoryTransDetailDTO();
					if ("C".equals(direction)) {
						detailDTO.setdORc(GeneratorAccountDetailFile.GET);
						detailDTO.setAccNo1(dom4jxml.getNodeText(rsNode, "fractn/actacn"));
						detailDTO.setAccName1(dom4jxml.getNodeText(rsNode, "fractn/acntname"));
					} else {
						detailDTO.setdORc(GeneratorAccountDetailFile.PAY);
						detailDTO.setAccNo1(dom4jxml.getNodeText(rsNode, "toactn/actacn"));
						detailDTO.setAccName1(dom4jxml.getNodeText(rsNode, "toactn/toname"));
					}
					detailDTO.setBalance(acctbal);
					detailDTO.setCreditNo(vchnum);
					detailDTO.setCreditType("");
					detailDTO.setAmount(txnamt);
					detailDTO.setIndividual1(acsref);
					detailDTO.setIndividual2(furinfo);
					detailDTO.setPaySeqNum(transid);
					detailDTO.setTranDate(txndate);
					detailDTO.setTranTime(txntime);
					if (bankAccountBalanceService.selectAllSettlementAccountNo().containsKey(detailDTO.getAccNo1())) {
						detailDTO.setType(AccountTransType.zjdb.getCode());
					} else if (StringUtils.isBlank(detailDTO.getAccNo1())
							&& StringUtils.isBlank(detailDTO.getAccName1())) {
						detailDTO.setType(AccountTransType.iint.getCode());
					} else if ("深圳金融联网络服务中心".equals(detailDTO.getAccName1())) {
						detailDTO.setType(AccountTransType.batch_trans.getCode());
					} else {
						detailDTO.setType(AccountTransType.single_trans.getCode());
					}

					list.add(detailDTO);
				}
			}
		}
		GeneratorAccountDetailFile.createReconciliationFile(filePath, actacn, date, list);
		return "S";
	}

}
