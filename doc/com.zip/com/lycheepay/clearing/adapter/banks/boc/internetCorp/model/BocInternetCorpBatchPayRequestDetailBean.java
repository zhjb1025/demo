package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import org.soofa.core.model.BaseObject;
/**
 * 
 * <P>中国银行网上银企快捷代发笔明细内容</P>
 * @author #{杜波(15999653650)}
 */
public class BocInternetCorpBatchPayRequestDetailBean extends BaseObject{

	private static final long serialVersionUID = -8851441530248407490L;
    /**
     * 收款行人行行号/收款省行标识
     */
	private String toibkn;
    /**
     * 收款行名
     */
	private String tobank;
    /**
     * 收款账号
     */
	private String toactn;
    /**
     * 货币
     */
	private String pydcur;
    /**
     * 笔金额
     */
	private String pydamt;
    /**
     * 收款人名称
     */
	private String toname;
    /**
     * 收款人证件类型
     */
	private String toidtp;
    /**
     * 收款人证件号
     */
	private String toidet;
    /**
     * 用途
     */
	private String furinfo;
	
    public String getToibkn() {
		return toibkn;
	}
	public void setToibkn(String toibkn) {
		this.toibkn = toibkn;
	}
	public String getTobank() {
		return tobank;
	}
	public void setTobank(String tobank) {
		this.tobank = tobank;
	}
	public String getToactn() {
		return toactn;
	}
	public void setToactn(String toactn) {
		this.toactn = toactn;
	}
	public String getPydcur() {
		return pydcur;
	}
	public void setPydcur(String pydcur) {
		this.pydcur = pydcur;
	}
	public String getPydamt() {
		return pydamt;
	}
	public void setPydamt(String pydamt) {
		this.pydamt = pydamt;
	}
	public String getToname() {
		return toname;
	}
	public void setToname(String toname) {
		this.toname = toname;
	}
	public String getToidtp() {
		return toidtp;
	}
	public void setToidtp(String toidtp) {
		this.toidtp = toidtp;
	}
	public String getToidet() {
		return toidet;
	}
	public void setToidet(String toidet) {
		this.toidet = toidet;
	}
	public String getFurinfo() {
		return furinfo;
	}
	public void setFurinfo(String furinfo) {
		this.furinfo = furinfo;
	}
	public String getReserve1() {
		return reserve1;
	}
	public void setReserve1(String reserve1) {
		this.reserve1 = reserve1;
	}
	public String getReserve2() {
		return reserve2;
	}
	public void setReserve2(String reserve2) {
		this.reserve2 = reserve2;
	}
	public String getReserve3() {
		return reserve3;
	}
	public void setReserve3(String reserve3) {
		this.reserve3 = reserve3;
	}
	public String getReserve4() {
		return reserve4;
	}
	public void setReserve4(String reserve4) {
		this.reserve4 = reserve4;
	}
	/**
     * 预留项1
     */
	private String reserve1;
    /**
     * 预留项2
     */
	private String reserve2;
    /**
     * 预留项3
     */
	private String reserve3;
    /**
     * 预留项4
     */
	private String reserve4;
}
