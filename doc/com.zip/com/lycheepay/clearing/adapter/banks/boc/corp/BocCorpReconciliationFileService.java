/*******************************************************************************
 * Project Key : CLEARING-ADAPTER
 * Create on 2012-6-13 上午10:35:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C004Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C004Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C004ResponseDetail;
import com.lycheepay.clearing.adapter.banks.boc.corp.tool.BocCodeUtils;
import com.lycheepay.clearing.adapter.banks.boc.corp.tool.SendBySocket4Boc;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企对账文件服务类</P>
 * 
 * @author 李斌 (13665100450)
 */
@Service(ClearingAdapterAnnotationName.BOC_CORP_RECONCILIATION_FILE_SERVICE)
public class BocCorpReconciliationFileService extends BaseService implements ReconciliationFileServiceInner {

	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager sequenceManager;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEND_BY_SOCKET_FOR_BOC)
	private SendBySocket4Boc sendBySocket4Boc;

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#getReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String getReconciliationFile(final String fileSavePath, final String channelId, final String settleDate)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "check");
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId,
				settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);

		// 创建请求报文
		final String reconciliationDate = queryDate.substring(0, 4) + "-" + queryDate.substring(4, 6) + "-"
				+ queryDate.substring(6);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + reconciliationDate);

		final Map<String, String> channelParms = channelParamService.queryCodeParamsMapByChannelId(ChannelId.ChannelIdEnum.BOC_CORP
				.getCode());
		final String ip = channelParms.get("100001");
		final String port = channelParms.get("100002");
		final byte[] key = BocCodeUtils.stringKeyToByteKey(channelParms.get("100003"));// DES密码
		final String sysCode = channelParms.get("100004");
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try{
			final C004Request c004Request = new C004Request(reconciliationDate);
			// 设置请求头信息
			c004Request.setSysCode(sysCode);
			c004Request.setMsgId(sequenceManager.getCorpBocMsgId());
			// c004Request.setMsgType("C004");// 中行代码，代表批量代扣
			c004Request.setSendTimestamp(DateUtil.getISO8601Fmt());
			// 生成报文
			final String sendXML = c004Request.getXML();
			Log4jUtil.info("生成对账交易查询报文：" + sendXML);

			final byte[] decodeBytes = sendBySocket4Boc.sendAndRecv(key, sendXML, ip, port, sysCode);
			final C004Response c004Response = new C004Response(decodeBytes);

			final List<C004ResponseDetail> details = c004Response.getDetails();

			reconciliationFileDTOList = buildTransactionDataList(logPrefix, details,
					channelId, queryDate);
		}catch(Exception e){
			Log4jUtil.error(e);
		}

		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * <p>构建交易数据对象列表</p>
	 * 
	 * @param logPrefix 日志前缀
	 * @param details 对账交易数据集合
	 * @param channelId 渠道ID
	 * @param reconciliationDate 对账日期
	 * @author 李斌(13665100450)
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix,
			final List<C004ResponseDetail> details, final String channelId, final String reconciliationDate) {
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		final String checkdate = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String tmt;
		Log4jUtil.info("对账交易查询结果数量：" + details.size());
		for (final C004ResponseDetail detail : details) {
			final ReconciliationFileDTO accBean = new ReconciliationFileDTO();
			accBean.setCheckDate(checkdate);	// 账务日期
			accBean.setBankSendId(detail.getTransNo());	// 渠道（银行）端的流水(订单号)
			accBean.setTransDate(reconciliationDate);
			accBean.setChannelId(channelId);
			if (StringUtils.isNotBlank(detail.getActualDeductAmt()))
				accBean.setAmount(new BigDecimal(detail.getActualDeductAmt()));// 交易金额
			tmt = detail.getTransMsgType();
			if ("B001".equalsIgnoreCase(tmt) || "B004".equalsIgnoreCase(tmt)) {
				accBean.setPayGet(STR_GET);// get代扣 pay为代付
			} else if ("B002".equalsIgnoreCase(tmt) || "B005".equalsIgnoreCase(tmt)) {
				accBean.setPayGet(STR_PAY);// get代扣 pay为代付
			} else {
				Log4jUtil.info("对账continue未被加入accBeanList的记录：" + detail);
				continue;
			}
			/*中行返回的交易状态
			原交易明确成功,且无冲正记录	S00
			原交易明确成功,虽有冲正记录但冲正明确失败	S01
			原交易明确失败(此状态下必无冲正记录)	S90
			原交易状态未明确	(需要人工处理)	S50
			原交易明确成功,虽有冲正记录,但冲正结果未明	S51
			原交易成功,且冲正明确成功	S99*/

			if ("S00".equals(detail.getTransStatus()) || "S01".equals(detail.getTransStatus())) {// 只对明确成功的
				accBean.setBankTransState("00");	// 交易状态 00-支付成功；01-支付失败；02-超时
				reconciliationFileDTOList.add(accBean);
			} else if ("S90".equals(detail.getTransStatus()) || "S99".equals(detail.getTransStatus())
					|| "S50".equals(detail.getTransStatus()) || "S51".equals(detail.getTransStatus())) {// 只对明确成功的
				accBean.setBankTransState("01");	// 交易状态 00-支付成功；01-支付失败；02-超时
				//目前生产验证发现,如果失败原因是'户名不符/户名不存在',返回的对账文件中,交易金额是不存在的,如果保存成对账记录,将导致核心对账不平帐,且无法调账,故针对交易金额为空的失败记录,不输出到对账文件中,让核心系统自动平账
				if(StringUtils.isNotBlank(detail.getActualDeductAmt())){reconciliationFileDTOList.add(accBean);}
			} else {
				Log4jUtil.info("中行银企对账，该记录状态不是S00,S01,S90,S50,S51,S99：" + detail);
			}
			Log4jUtil.info(detail.getTransStatus() + "=========" + accBean);
		}
		Log4jUtil.info("对账交易生成accBeanList数量：" + reconciliationFileDTOList.size());
		return reconciliationFileDTOList;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileService#convertToStandardReconciliationFile(java.lang.String, java.lang.String, java.lang.String)
	 * @author 李斌(13665100450)
	 */
	@Override
	public String convertToStandardReconciliationFile(final String targetFilePath, final String fileSavePath,
			final String channelId, final String settleDate) throws ClearingAdapterBizCheckedException {
		throw new UnsupportedOperationException();
	}

}
