/*******************************************************************************
 * Project Key : CPP
 * Create on 2012-8-2 下午7:27:54
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.credit.directnet;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.lang.ArrayUtils;
import org.soofa.remoting.ChannelConfig;
import org.soofa.remoting.ChannelState;
import org.soofa.remoting.Client;
import org.soofa.remoting.SoofaRemotingException;
import org.soofa.remoting.netty.NettyClient;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.LoUtils;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.MacUtil;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgField;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgFieldType;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterClientCheckedException;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.BankInteractiveParam;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.BankInteractiveParamProcess;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.ChannelFactoryDelegate;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.ChannelHandlerDelegate;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.ClientFlushService;
import com.lycheepay.clearing.common.constant.ChannelClientErrorCode.ChannelClientErrorCodeEnum;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行信用卡与银行交互Client</P>
 * 
 * @author 邱林 Leon.Qiu 2012-8-2 下午7:27:54
 */
@Service(ClearingAdapterAnnotationName.BOC_CREDIT_CLIENT)
public class BocCreditClient extends BaseWithoutAuditLogService implements DisposableBean, InitializingBean,
		ClientFlushService {

	@Autowired
	private BankInteractiveParamProcess bankInteractiveParamProcess;

	// 有锁进行控制client初始化有修改
	private Client client = null;

	// 因ChannelFactory的关闭有DirectMemory泄露，采用静态化规避
	private final static ChannelFactoryDelegate channelFactory = new ChannelFactoryDelegate();

	final ConcurrentMap<String, String> channelParams = new ConcurrentHashMap<String, String>(10);

	/**
	 * <p>取连接并且返回与银行交互的请求结果</p>
	 * 
	 * @param msgPack 与银行交互请求的消息报(针对8583pos报文)
	 * @return 返回解压好的8583pos报文
	 * @throws ClearingAdapterClientCheckedException
	 * @author 邱林 Leon.Qiu 2012-8-28 下午3:21:41
	 */
	public final MsgPack requestLink(final MsgPack msgPack) throws ClearingAdapterClientCheckedException {
		// 初始化一次client,参数不做修改的情况下从内存中获取client
		if (client == null) {
			// 加锁
			synchronized (BocCreditClient.class) {
				// 防止同时征用锁后处理
				if (client == null) {
					// 新建client并且初始化到内存中
					initClient();
				}
			}
		}
		MsgPack result = null;
		try {
			result = client.request(msgPack, false, MsgPack.class);
		} catch (final SoofaRemotingException e) {
			// 这里的异常必须区分几个状态
			// 连接上状态(isConnected)
			// 发送到银行(isSended)
			// 银行响应回执（接收到回执isReceived）
			// 之后关闭连接(isDisconnected)

			// // 初始状态,表示等待连接
			// waitForConnect,
			// // 表示已经与远端地址建立了连接
			// connected,
			// // 表示客户端开始向服务器端发送请求,但是还没发送完毕
			// // 此时如果出现异常,不确定是否能重新发送请求,除非服务器端在业务逻辑上可以处理重复的请求
			// sendRequest,
			// // 表示客户端向服务器端发送请求已经完成.
			// // 此时如果出现异常,将不能再重新发送,以免服务器端重复处理,除非服务器端在业务逻辑上可以处理重复的请求
			// sendRequestCompleted,
			// // 表示已经成功接受完对方发来的信息(不区分客户端还是服务器端)
			// // 在客户端表示已经接受完服务器端的响应,但是还没进行业务逻辑处理
			// // 在服务器端表示已经接受完客户端的请求,但是还没进行业务逻辑处理
			// messageReceived,
			// // 表示已经与远端地址断开了连接,任何操作都不能再进行
			// disconnected
			if (log.isErrorEnabled()) {
				log.error("调用中行银行请求失败:【ErrorCode】 :{}.【Message】 :{}", e.getMessage() + ".", e.getErrorCode(), e);
			}
			final ChannelState channelState = e.getChannelState();
			if (ChannelState.waitForConnect.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_CONNECT_FAILED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_UNSEND.getCode());
			} else if (ChannelState.connected.equals(channelState) || ChannelState.sendRequest.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_BEFORE_SENDED_OUT.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_UNSEND.getCode());
			}
			// 以下状态都已经发送到银行
			else if (ChannelState.sendRequestCompleted.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_SENDED_NO_REVEIVED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
			} else if (ChannelState.messageReceived.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_RECEIVED_UNDISCONNECTED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
			} else if (ChannelState.disconnected.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_RECEIVED_UNDISCONNECTED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
			}
		}
		String errorMsg = "";
		if (result != null) {
			if (log.isDebugEnabled()) {
				log.debug("调用中国银行信用卡渠道返回结果如下:{}", result.toString());
			}
			if (!validateMac(result)) {
				errorMsg = "调用中国银行信用卡渠道,响应报文中的MAC校验错误,报文被篡改!";
			}
		} else {
			errorMsg = "调用中国银行信用卡渠道,解包返回为空信息！";
		}
		if (org.apache.commons.lang.StringUtils.isNotBlank(errorMsg)) {
			throw new ClearingAdapterClientCheckedException(
					ChannelClientErrorCodeEnum.CLIENT_AFTER_DISCONNECT.getCode(), errorMsg,
					ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
		} else {
			return result;
		}
	}

	/**
	 * <p>初始化Client,分开控制Client有利于日后拆分银行划分包时便于管理</p>
	 * 
	 * @return 初始化好的Client
	 * @author 邱林 Leon.Qiu 2012-8-6 下午4:19:38
	 */
	public void initClient() {
		// 不能写把所有银行配置和coder在一起，不利于日后拆银行处理，必须反向调用各银行处理类,从银行处理类中获取参数,再由银行调用BankClinet初始化到map中
		// 内部映射的decoder和encoder不需要再次增加缓存及查询方法,由此方法进行控制
		final Map<String, String> regeisterBeanId = bankInteractiveParamProcess.regeisterBeanId(
				ChannelIdEnum.BOC_CREDIT_CARD.getCode(), ClearingAdapterAnnotationName.BOC_CREDIT_CLIENT);
		// 本地缓存map重新被加载,由于此方法已经加入类及锁不会导致线程不安全
		channelParams.putAll(regeisterBeanId);
		final BankInteractiveParam bip = getBankInterativeParam(regeisterBeanId);
		final ChannelConfig config = createChannelConfig(bip);
		client = new NettyClient(config, channelFactory, new BocCreditEncoder(bip), new BocCreditDecoder(),
				new ChannelHandlerDelegate());
	}

	/**
	 * <p>构建通道配置并返回此信息</p>
	 * 
	 * @param bip 与银行交互的配置信息
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:07:41
	 */
	private ChannelConfig createChannelConfig(final BankInteractiveParam bip) {
		final ChannelConfig config = new ChannelConfig();
		config.setPort(bip.getPort());
		config.setServerHostName(bip.getIp());
		config.setReadChannelBufferSize(bip.getReadChannelBufferSize() != 0 ? bip.getReadChannelBufferSize() : 8192);
		config.setConnectTimeoutMillis(bip.getConnectTimeoutMillis() != 0 ? bip.getConnectTimeoutMillis() : 60000);
		config.setWriteTimeoutMillis(bip.getWriteTimeoutMillis() != 0 ? bip.getWriteTimeoutMillis() : 6000);
		config.setReceiveTimeoutMillis(bip.getReceiveTimeoutMillis() != 0 ? bip.getReceiveTimeoutMillis() : 60000);
		return config;
	}

	/**
	 * <p>构建与银行交互的配置并返回此信息</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:14:49
	 */
	private BankInteractiveParam getBankInterativeParam(final Map<String, String> map) {
		final BankInteractiveParam param = new BankInteractiveParam();
		final String ip = map.get("100001");// Ip地址
		final String port = map.get("100002");// Port端口
		param.setIp(ip);
		param.setPort(Integer.valueOf(port));
		return param;
	}

	/**
	 * @see org.springframework.beans.factory.DisposableBean#destroy()
	 * @author 邱林 Leon.Qiu 2012-8-3 下午4:26:44
	 */
	@Override
	public void destroy() throws Exception {
		if (client != null) {
			client.close();
		}
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:15:31
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		initClient();
	}

	/**
	 * @see com.leon.remote.consumer.test.common.service.biz.net.ClientFlushService#flushClient()
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:37:41
	 */
	@Override
	public void flushClient() {
		synchronized (BocCreditClient.class) {
			// 防止同时征用加锁处理
			initClient();
		}
	}

	/**
	 * <p>校验响应报文的MAC是否为同样地址</p>
	 * 
	 * @param rspMsg 消费包
	 * @return 验证MAC地址结果 true同样地址,false篡改的地址
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-8-28 下午3:31:34
	 * @throws ClearingAdapterClientCheckedException
	 */
	private boolean validateMac(final MsgPack rspMsg) throws ClearingAdapterClientCheckedException {
		final String workKey = channelParams.get("100014");// 商户工作密钥
		boolean result = false;
		final MsgField macField = rspMsg.getField(MsgFieldType.FIELD_64.getNo());
		// 如果MAC为空则，不需要验证MAC
		if (macField == null || macField.getStringValue() == null || "".equals(macField.getStringValue())) {
			return true;
		}
		Log4jUtil.info("银行返回的MAC值为:" + LoUtils.byte2HexStr(macField.getOrigMsg()));
		byte[] macData;
		try {
			macData = packMacData(rspMsg);
		} catch (final BizException e) {
			throw new ClearingAdapterClientCheckedException(
					ChannelClientErrorCodeEnum.CLIENT_AFTER_DISCONNECT.getCode(), "调用中国银行信用卡渠道,响应报文中的MAC校验错误,报文被篡改!",
					ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
		}
		final String mac = MacUtil.getMacData(workKey, macData);
		// 只比较MAC前四字节
		String macSubStr = "";
		if (mac.length() >= 8) {
			macSubStr = mac.substring(0, 8);
		}
		String recvMacSubStr = "";
		if (LoUtils.byte2HexStr(macField.getOrigMsg()).length() >= 8) {
			recvMacSubStr = LoUtils.byte2HexStr(macField.getOrigMsg()).substring(0, 8);
		}
		if (macSubStr.equalsIgnoreCase(recvMacSubStr)) {
			result = true;
		}
		return result;
	}

	/**
	 * <p>组装需加密数据域为2,3,4,11,12,13,49,38,39,41</p>
	 * 
	 * @param msgPack pos8583的消息报
	 * @return 解压处理后域字段位图的Bytes数组
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-8-28 下午3:33:00
	 */
	public byte[] packMacData(final MsgPack msgPack) throws BizException {
		final byte[] bitBin = msgPack.getBitmap();
		byte[] res = new byte[] {};
		if (bitBin != null && bitBin.length >= 64) {
			if (bitBin[1] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_2.getNo()).getOrigValue());
			}
			if (bitBin[2] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_3.getNo()).getOrigValue());
			}
			if (bitBin[3] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_4.getNo()).getOrigValue());
			}
			if (bitBin[10] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_11.getNo()).getOrigValue());
			}
			if (bitBin[11] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_12.getNo()).getOrigValue());
			}
			if (bitBin[12] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_13.getNo()).getOrigValue());
			}
			if (bitBin[48] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_49.getNo()).getOrigValue());
			}
			if (bitBin[37] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_38.getNo()).getOrigValue());
			}
			if (bitBin[38] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_39.getNo()).getOrigValue());
			}
			if (bitBin[40] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_41.getNo()).getOrigValue());
			}
		}
		Log4jUtil.info("需要加密的MAC数据长度为:" + res.length);
		return res;
	}

}
