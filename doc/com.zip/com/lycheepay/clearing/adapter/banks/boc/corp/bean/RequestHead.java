/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午6:36:06
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import org.apache.commons.lang.StringUtils;


/**
 * <P>请求报文头</P>
 * 
 * @author 张凯锋
 */
public class RequestHead {
	private String sysCode = "";// 代收付系统别
	// private String msgType = "";// 此处是具体交易报文类型编码
	private String msgId = "";// 30位唯一报文流水号
	private String sendTimestamp = "";// 报文时间 DATETIME M 报文发送时间戳

	public String getHeadXML() {
		final StringBuilder sb = new StringBuilder("<HEAD>");
		sb.append("<SYS_CODE>").append(sysCode).append("</SYS_CODE>");
		// sb.append("<MSG_TYPE>").append(msgType).append("</MSG_TYPE>");
		sb.append("<MSG_ID>").append(msgId).append("</MSG_ID>");
		sb.append("<SEND_TIMESTAMP>").append(sendTimestamp).append("</SEND_TIMESTAMP>");
		sb.append("</HEAD>");
		return sb.toString();
	}

	public String getSysCode() {
		return sysCode;
	}

	public void setSysCode(final String sysCode) {
		this.sysCode = sysCode;
	}

	/*
		public String getMsgType() {
			return msgType;
		}

		public void setMsgType(String msgType) {
			this.msgType = msgType;
		}*/

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(final String msgId) {
		this.msgId = msgId;
	}

	public String getSendTimestamp() {
		return sendTimestamp;
	}

	public void setSendTimestamp(final String sendTimestamp) {
		this.sendTimestamp = sendTimestamp;
	}

	public static String nil(final String value) {
		return StringUtils.isNotBlank(value) ? "" : " xsi:nil=\"true\"";
	}
}
