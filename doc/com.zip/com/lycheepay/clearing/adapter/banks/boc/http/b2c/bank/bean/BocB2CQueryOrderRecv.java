package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

import java.util.ArrayList;


/**
 * 中行订单查询返回实体 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-cji
 * @version 1.0
 */
public class BocB2CQueryOrderRecv {
	private String merchantNo; 		// BOC商户ID
	private String exception;		// 失败错误码 处理成功时无此域；处理失败时，该域为具体的错误代码
	private ArrayList<BocB2CQueryOrderDetailRecv> orderTrans;

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(final String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getException() {
		return exception;
	}

	public void setException(final String exception) {
		this.exception = exception;
	}

	public ArrayList<BocB2CQueryOrderDetailRecv> getOrderTrans() {
		return orderTrans;
	}

	public void setOrderTrans(final ArrayList<BocB2CQueryOrderDetailRecv> orderTrans) {
		this.orderTrans = orderTrans;
	}

}
