package com.lycheepay.clearing.adapter.banks.boc.credit.kft.processor;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.soofa.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.credit.directnet.BocCreditClient;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.bean.BocCreditBean;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.BocCreditMsgUtilService;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.J2DES;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.LoUtils;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.MacUtil;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.BillnoSnTradeDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterClientCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.biz.ClearingResult;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelClientErrorCode;
import com.lycheepay.clearing.common.constant.ChannelClientErrorCode.ChannelClientErrorCodeEnum;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行信用卡交易服务处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午7:58:16
 */
@Service(ClearingAdapterAnnotationName.BOC_CREDIT_SERVICE)
public class BocCreditService extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_CREDIT_MSG_UTIL_SERVICE)
	private BocCreditMsgUtilService bocCreditMsgUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_CREDIT_CLIENT)
	private BocCreditClient bocCreditClinet;

	private final static String channelName = ChannelIdEnum.BOC_CREDIT_CARD.getDesc();

	private final static String channelId = ChannelIdEnum.BOC_CREDIT_CARD.getCode();

	/**
	 * 中行信用卡消费
	 * 
	 * @param param
	 * @param bankSendSn 渠道流水
	 * @return ReturnState
	 * @throws BizException
	 */
	public ReturnState dealConsume(final Param param, final String bankSendSn) throws BizException {

		MsgPack retConsumeMsgPack = new MsgPack();// 消费返回包
		// 创建消费并发送,发送超时，则发消费冲正，并返回失败信息
		MsgPack consumeMsgPack = bocCreditMsgUtilService.createConsume(param, bankSendSn);// 消费包
		try {
			retConsumeMsgPack = bocCreditMsgUtilService.sendMsg(consumeMsgPack);
			// 处理POS返回的处理码,如果为TRUE，则重新加载参数 2013年3月26日暂时注释
			// if (dealControlCode(channelId, bankSendSn, retConsumeMsgPack.getFieldContent3(),
			// retConsumeMsgPack.get61_1())) {
				// bocCreditMsgUtilService = new BocCreditMsgUtilService();
			// }
		} catch (final BizException e) {
			Log4jUtil.error(channelId + ": 消费发送出错,渠道流水号：" + bankSendSn, e);
			try {
				bocCreditMsgUtilService.sendMsg(bocCreditMsgUtilService.createFinishRush(param, retConsumeMsgPack,
						consumeMsgPack));// 消费冲正
			} catch (final BizException e1) {
				Log4jUtil.error(channelId + ": 冲正发送出错,渠道流水号：" + bankSendSn, e);
				throw e1;
			}
			throw e;
		}

		// 返回码为Z1 表示未签到
		if ("Z1".equals(retConsumeMsgPack.getFieldContent39())) {
			Log4jUtil.info("消费发送返回Z1需先签到开始......");
			this.signProcess(channelId, bankSendSn);
			Log4jUtil.info("消费发送返回Z1需先签到结束......");
			try {
				// bocCreditMsgUtilService = new BocCreditMsgUtilService();
				consumeMsgPack = bocCreditMsgUtilService.createConsume(param, bankSendSn);
				Log4jUtil.info("消费发送返回Z1,再次发送消费交易报文开始......");
				retConsumeMsgPack = bocCreditMsgUtilService.sendMsg(consumeMsgPack);
				Log4jUtil.info("消费发送返回Z1,再次发送消费交易报文结束......");

				// 处理POS返回的处理码,如果为TRUE，则重新加载参数
				// if (dealControlCode(channelId, bankSendSn, retConsumeMsgPack.getFieldContent3(),
				// retConsumeMsgPack.get61_1())) {
					// bocCreditMsgUtilService = new BocCreditMsgUtilService();
				// }

			} catch (final BizException e) {
				Log4jUtil.error("消费发送错误,开始消费冲正处理！渠道流水号：" + bankSendSn, e);
				try {
					bocCreditMsgUtilService.sendMsg(bocCreditMsgUtilService.createFinishRush(param, retConsumeMsgPack,
							consumeMsgPack));// 预授权冲正
				} catch (final Exception e1) {
					Log4jUtil.error("消费冲正失败！渠道流水号：" + bankSendSn, e);
					throw e;
				}
				throw e;
			}
		}
		final ReturnState returnState = new ReturnState();
		returnState.setBankRetCode(retConsumeMsgPack.getFieldContent39());// 银行返回代码
		returnState.setReturnMsg(retConsumeMsgPack.getFieldContent44());// 银行返回信息
		if (returnState.getReturnMsg() == null) {
			if (returnState.getBankRetCode() != null && returnState.getBankRetCode().equals("00")) {
				returnState.setReturnMsg("交易成功");
			} else {
				if ("91".equals(returnState.getBankRetCode())) {
					returnState.setReturnMsg("银行处理交易超时!");
				} else {
					returnState.setReturnMsg("银行返回码: " + returnState.getBankRetCode());
				}
			}
		}
		BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, bankSendSn);
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(param.getCardType()); // 卡类型
		// returnState.setCreditNo(retConsumeMsgPack.getFieldContent38());// 授权码
		Log4jUtil.info("retConsumeMsgPack.getFieldContent37() = " + retConsumeMsgPack.getFieldContent37()); // 银行返回的参考号（对账时用到）
		returnState.setCreditNo(retConsumeMsgPack.getFieldContent37());// 参考号
		final HashMap<String, Object> map = new HashMap<String, Object>();
		// map.put("validDate", consumeMsgPack.getFieldContent14());// 卡有效期
		// String cvv2 = "";
		// if (consumeMsgPack.getFieldContent48() != null) {
		// try {
		// final String f48 = consumeMsgPack.getFieldContent48();
		// cvv2 = f48.substring(f48.length() - 3, f48.length());
		// Log4jUtil.info("get cvv2 = " + cvv2);
		// } catch (final Exception e) {
		// Log4jUtil.info("get cvv2 failed: " + e.toString());
		// }
		// } else {
		// Log4jUtil.info("获取信用卡的cvv2码失败!");
		// }
		Log4jUtil.info("consumeMsgPack.getFieldContent12() = " + retConsumeMsgPack.getFieldContent12());
		Log4jUtil.info("consumeMsgPack.getFieldContent13() = " + retConsumeMsgPack.getFieldContent13());
		// map.put("cvv2", cvv2);
		if (retConsumeMsgPack.getFieldContent12() != null && !"".equals(retConsumeMsgPack.getFieldContent12())) {
			final String strDate = DateUtil.getCurrentDate();
			final String resDate = strDate.substring(0, 4) + retConsumeMsgPack.getFieldContent13()
					+ retConsumeMsgPack.getFieldContent12();
			Date date = new Date();
			try {
				date = DateUtil.getDate(resDate);
			} catch (final Exception e) {
				Log4jUtil.info(channelId + "：消费返回时日期转换错误。（" + resDate + "）");
			}
			map.put("recvTime", date);// 银行交易时间
			Log4jUtil.info(channelId + ": 消费银行返回日期为：" + date.toString());
		} else {
			Log4jUtil.info("银行返回时间失败"); // TODO
			map.put("recvTime", new Date());// 银行交易时间
		}
		Log4jUtil.info("");
		Log4jUtil.info("银行返回的批次号：retConsumeMsgPack.get61_1() = " + retConsumeMsgPack.get61_1());
		map.put("authorizationCode", retConsumeMsgPack.getFieldContent38());
		map.put("batchNo", retConsumeMsgPack.get61_1());

		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				retConsumeMsgPack.getFieldContent39()));
		Log4jUtil.info("channelRtncode = " + channelRtncode);
		if (channelRtncode != null) {
			Log4jUtil.info("channel_remark = " + channelRtncode.getChannelReamrk());
			if ("00".equals(retConsumeMsgPack.getFieldContent39())) {
				returnState.setReturnState(PayState.SUCCEED_STR);// 成功
				returnState.setReturnMsg("交易成功");
				returnState.setChannelCode(TransReturnCode.code_0000);
			} else {
				returnState.setReturnState(PayState.FAILED_STR);
				if (channelRtncode.getId() != null) {
					Log4jUtil.info("channel_remark = " + channelRtncode.getId().getChannelRtncode());
					returnState.setReturnMsg("交易失败, 银行返回码：" + channelRtncode.getId().getChannelRtncode() + "("
							+ channelRtncode.getChannelReamrk() + ")");
				} else {
					returnState.setReturnMsg("交易失败, 银行返回码:" + retConsumeMsgPack.getFieldContent39());
				}
				returnState.setChannelCode(channelRtncode.getKftRtncode());
			}
		} else {
			channelRtncode = new ChannelRtncode();
			returnState.setReturnState(PayState.FAILED_STR);
			channelRtncode.setChannelReamrk("交易失败，银行返回码：" + retConsumeMsgPack.getFieldContent39());
			channelRtncode.setKftRtncode(TransReturnCode.code_9900);
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		}
		returnState.setReturnObj(map);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		return returnState;
	}

	/**
	 * 中行信用卡分期付款消费
	 * 
	 * @param param
	 * @param bankSendSn 渠道流水
	 * @return ReturnState
	 * @throws BizException
	 */
	public ReturnState dealInstalmentConsume(final Param param, final String bankSendSn) throws BizException {

		MsgPack retConsumeMsgPack = new MsgPack();// 消费返回包
		String instalments = ((DeductDTO) param.getBizBean()).getInstalments();// 分期期数
		String instalmentsID = getInstalmentId(instalments);
		MsgPack consumeMsgPack = bocCreditMsgUtilService.createInstalmentConsume(param, bankSendSn, instalmentsID);// 消费包
		try {
			retConsumeMsgPack = bocCreditMsgUtilService.sendMsgForInstalments(consumeMsgPack);
			// 处理POS返回的处理码,如果为TRUE，则重新加载参数
			// if (dealControlCode(channelId, bankSendSn, retConsumeMsgPack.getFieldContent3(),
			// retConsumeMsgPack.get61_1())) {
				// bocCreditMsgUtilService = new BocCreditMsgUtilService();
			// }
		} catch (final BizException e) {
			Log4jUtil.error(channelId + ": 消费发送出错,渠道流水号：" + bankSendSn, e);
			try {
				bocCreditMsgUtilService.sendMsgForInstalments(bocCreditMsgUtilService.createFinishRushForInstalments(param,	retConsumeMsgPack,consumeMsgPack));// 消费冲正
			} catch (final BizException e1) {
				Log4jUtil.error(channelId + ": 冲正发送出错,渠道流水号：" + bankSendSn, e);
				throw e1;
			}
			throw e;
		}
		// 返回码为Z1 表示未签到
		if ("Z1".equals(retConsumeMsgPack.getFieldContent39())) {
			Log4jUtil.info("消费发送返回Z1需先签到开始......");
			this.signProcess(channelId, bankSendSn);
			Log4jUtil.info("消费发送返回Z1需先签到结束......");
			try {
				// bocCreditMsgUtilService = new BocCreditMsgUtilService();
				consumeMsgPack = bocCreditMsgUtilService.createConsume(param, bankSendSn);
				Log4jUtil.info("消费发送返回Z1,再次发送消费交易报文开始......");
				retConsumeMsgPack = bocCreditMsgUtilService.sendMsgForInstalments(consumeMsgPack);
				Log4jUtil.info("消费发送返回Z1,再次发送消费交易报文结束......");

				// 处理POS返回的处理码,如果为TRUE，则重新加载参数
				// if (dealControlCode(channelId, bankSendSn, retConsumeMsgPack.getFieldContent3(),
				// retConsumeMsgPack.get61_1())) {
					// bocCreditMsgUtilService = new BocCreditMsgUtilService();
				// }

			} catch (final BizException e) {
				Log4jUtil.error("消费发送错误,开始消费冲正处理！渠道流水号：" + bankSendSn, e);
				try {
					bocCreditMsgUtilService.sendMsgForInstalments(bocCreditMsgUtilService.createFinishRush(param,
							retConsumeMsgPack,
							consumeMsgPack));// 预授权冲正
				} catch (final Exception e1) {
					Log4jUtil.error("消费冲正失败！渠道流水号：" + bankSendSn, e);
					throw e;
				}
				throw e;
			}
		}
		final ReturnState returnState = new ReturnState();
		returnState.setBankRetCode(retConsumeMsgPack.getFieldContent39());// 银行返回代码
		returnState.setReturnMsg(retConsumeMsgPack.getFieldContent44());// 银行返回信息
		if (returnState.getReturnMsg() == null) {
			if (returnState.getBankRetCode() != null && returnState.getBankRetCode().equals("00")) {
				returnState.setReturnMsg("交易成功");
			} else {
				if ("91".equals(returnState.getBankRetCode())) {
					returnState.setReturnMsg("银行处理交易超时!");
				} else {
					returnState.setReturnMsg("银行返回码: " + returnState.getBankRetCode());
				}
			}
		}
		BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, bankSendSn);
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());// 渠道流水
		returnState.setSn(billnoSn.getSn());// 业务流水
		returnState.setBillnosnSeq(billnoSn.getBillnosnSeq());
		returnState.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		returnState.setCardType(param.getCardType()); // 卡类型
		// returnState.setCreditNo(retConsumeMsgPack.getFieldContent38());// 授权码
		Log4jUtil.info("retConsumeMsgPack.getFieldContent37() = " + retConsumeMsgPack.getFieldContent37()); // 银行返回的参考号（对账时用到）
		returnState.setCreditNo(retConsumeMsgPack.getFieldContent37());// 参考号
		final HashMap<String, Object> map = new HashMap<String, Object>();
		// map.put("validDate", consumeMsgPack.getFieldContent14());// 卡有效期
		// String cvv2 = "";
		// if (consumeMsgPack.getFieldContent48() != null) {
		// try {
		// final String f48 = consumeMsgPack.getFieldContent48();
		// cvv2 = f48.substring(f48.length() - 3, f48.length());
		// Log4jUtil.info("get cvv2 = " + cvv2);
		// } catch (final Exception e) {
		// Log4jUtil.info("get cvv2 failed: " + e.toString());
		// }
		// } else {
		// Log4jUtil.info("获取信用卡的cvv2码失败!");
		// }
		Log4jUtil.info("consumeMsgPack.getFieldContent12() = " + retConsumeMsgPack.getFieldContent12());
		Log4jUtil.info("consumeMsgPack.getFieldContent13() = " + retConsumeMsgPack.getFieldContent13());
		// map.put("cvv2", cvv2);
		if (retConsumeMsgPack.getFieldContent12() != null && !"".equals(retConsumeMsgPack.getFieldContent12())) {
			final String strDate = DateUtil.getCurrentDate();
			final String resDate = strDate.substring(0, 4) + retConsumeMsgPack.getFieldContent13()
					+ retConsumeMsgPack.getFieldContent12();
			Date date = new Date();
			try {
				date = DateUtil.getDate(resDate);
			} catch (final Exception e) {
				Log4jUtil.info(channelId + "：消费返回时日期转换错误。（" + resDate + "）");
			}
			map.put("recvTime", date);// 银行交易时间
			Log4jUtil.info(channelId + ": 消费银行返回日期为：" + date.toString());
		} else {
			Log4jUtil.info("银行返回时间失败"); // TODO
			map.put("recvTime", new Date());// 银行交易时间
		}
		Log4jUtil.info("");
		Log4jUtil.info("银行返回的批次号：retConsumeMsgPack.get61_1() = " + retConsumeMsgPack.get61_1());
		map.put("authorizationCode", retConsumeMsgPack.getFieldContent38());
		map.put("batchNo", retConsumeMsgPack.get61_1());
		map.put("instalmentsID", instalmentsID);

		ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				retConsumeMsgPack.getFieldContent39()));
		Log4jUtil.info("channelRtncode = " + channelRtncode);
		if (channelRtncode != null) {
			Log4jUtil.info("channel_remark = " + channelRtncode.getChannelReamrk());
			if ("00".equals(retConsumeMsgPack.getFieldContent39())) {
				returnState.setReturnState(PayState.SUCCEED_STR);// 成功
				returnState.setReturnMsg("交易成功;"
						+ getInstalmentsResult(retConsumeMsgPack.getFieldContent54(), instalments));
				returnState.setChannelCode(TransReturnCode.code_0000);
			} else {
				returnState.setReturnState(PayState.FAILED_STR);
				if (channelRtncode.getId() != null) {
					Log4jUtil.info("channel_remark = " + channelRtncode.getId().getChannelRtncode());
					returnState.setReturnMsg("交易失败, 银行返回码：" + channelRtncode.getId().getChannelRtncode() + "("
							+ channelRtncode.getChannelReamrk() + ")");
				} else {
					returnState.setReturnMsg("交易失败, 银行返回码:" + retConsumeMsgPack.getFieldContent39());
				}
				returnState.setChannelCode(channelRtncode.getKftRtncode());
			}
		} else {
			channelRtncode = new ChannelRtncode();
			returnState.setReturnState(PayState.FAILED_STR);
			channelRtncode.setChannelReamrk("交易失败，银行返回码：" + retConsumeMsgPack.getFieldContent39());
			channelRtncode.setKftRtncode(TransReturnCode.code_9900);
			returnState.setChannelCode(channelRtncode.getKftRtncode());
		}
		returnState.setReturnObj(map);
		returnState.setCheckDate(DateUtil.getCurrentDate());
		return returnState;
	}
	
	/**
	 * <p>获取分期计划ID</p>
	 * 
	 * @param instalments 分期期数
	 * @return
	 * @author 张凯锋
	 * @throws BizException
	 */
	private String getInstalmentId(String instalments) throws BizException {
		ChannelParm channelParm = channelParmService.queryByPrimaryKey(new ChannelParmId(ChannelIdEnum.BOC_CREDIT_CARD
				.getCode(), "200018"));
		Log4jUtil.info(channelParm);
		String instalmentIds = channelParm.getParvalue();
		String[] instalmentIdArrays = instalmentIds.split(";");
		String instalmentId = "";
		for (String item : instalmentIdArrays) {
			String[] namevalues = item.split("=");
			if (StringUtils.equals(namevalues[0], instalments)) {
				instalmentId = namevalues[1];
				break;
			}
		}
		AssertUtils.isBlank(instalmentId, TransReturnCode.code_9108, "未配置该分期数:" + instalments + "的计划Id");
		return instalmentId;
	}


	/**
	 * <p>根据返回的结果获取分期结果明细</p>
	 * @param field54 比如3091156D0000000000013092156D0000000000003090156D000000000000
	 * 54域说明：
	 * Position  Description
			0-1	 Account type defined in positions 3-4 or 5-6 of the processing code
			2-3  Amount type:	01 - ledger balance
								02 - available balance
								90 – 手续费金额
								91 – 分期首付金额
								92 – 分期月还款额
								93 – 扣减积分数
								94 – 剩余积分数
								95 – 授权交易金额
								96 – CASHBACK金额（暂不支持）
			4-6	 currency code of amount
			7	 ‘D’ - for debit amount or ‘C’ for credit amount
			8-19  Amount

	 * @return 分期结果明细
	 * @author 张凯锋
	 */
	public static String getInstalmentsResult(String field54, String instalments) {
		if(StringUtils.isBlank(field54))
			return "";
		StringBuilder sb = new StringBuilder("分期期数：");
		sb.append(instalments).append(";");
		for (int i = 0; i < field54.length() / 19; i++) {
			String amountType = field54.substring(i * 20 + 2, i * 20 + 4);
			String amount = field54.substring(i * 20 + 8, i * 20 + 20);
			Log4jUtil.info("amountType: {},amount:{}", amountType, amount);
			if ("91".equals(amountType)) {
				sb.append("分期首付金额:").append(new BigDecimal(amount).divide(new BigDecimal("100"))).append("元;");
			} else if ("92".equals(amountType)) {
				sb.append("分期月还款额:").append(new BigDecimal(amount).divide(new BigDecimal("100"))).append("元;");
			} else if ("90".equals(amountType)) {
				sb.append("手续费金额:").append(new BigDecimal(amount).divide(new BigDecimal("100"))).append("元;");
			} else if ("02".equals(amountType)) {
				sb.append("可用余额:").append(new BigDecimal(amount).divide(new BigDecimal("100"))).append("元;");
			} else if ("95".equals(amountType)) {
				sb.append("授权交易金额:").append(new BigDecimal(amount).divide(new BigDecimal("100"))).append("元;");
			}
		}
		return sb.toString();
	}

	public static void main(String[] args) throws BizException {
		System.out.println(getInstalmentsResult(
				"3091156D0000000000023092156D0000000000043090156D0000000000063095156D0000000005553002156D000000001555",
				"12"));
		// System.out.println(getInstalmentId("3"));
		// System.out.println(getInstalmentId("6"));
		// System.out.println(getInstalmentId("9"));
		// System.out.println(getInstalmentId("12"));
		// System.out.println(getInstalmentId("18"));
		// System.out.println(getInstalmentId("24"));
		// System.out.println(getInstalmentId("36"));
	}

	/**
	 * 仿POS签到处理
	 * 
	 * @param param
	 * @throws BizException
	 */
	public ReturnState signProcess(final String channelId, final String bankSendSn) throws BizException {

		// 签到并发送
		MsgPack signMsgPack = new MsgPack();// 签到包
		MsgPack retMsgPack = new MsgPack();// 签到返回包
		try {
			signMsgPack = bocCreditMsgUtilService.createSign(bankSendSn);
			retMsgPack = bocCreditMsgUtilService.sendMsg(signMsgPack);
		} catch (final Exception e) {
			// 发送超时,签到失败
			Log4jUtil.error(channelId + ":" + channelName + "签到失败," + bankSendSn, e);
			throw e;
		}
		// 获取应答码
		final String rspCode = retMsgPack.getFieldContent39();

		// 签到成功
		if ("00".equals(rspCode)) {

			// 更新批次号
			final String batchNo = retMsgPack.get61_1();
			String processCode = retMsgPack.getFieldContent3();// 处理码
			final ChannelParmId channelParmId = new ChannelParmId();
			channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			channelParmId.setCode("100009");
			ChannelParm channelParm = channelParmService.queryByPrimaryKey(channelParmId);
			Log4jUtil.info(channelId + ":" + channelName + "更新签到返回批次号" + batchNo + "开始");
			channelParm.setParvalue(batchNo);
			channelParmService.update(channelParm);
			Log4jUtil.info(channelId + ":" + channelName + "更新签到返回批次号结束");
			// 更新签到标志为已签到
			channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			channelParmId.setCode("100015");
			channelParm = channelParmService.queryByPrimaryKey(channelParmId);
			channelParm.setParvalue("1");
			Log4jUtil.info(channelId + ":" + channelName + "开始更新签到标志");
			channelParmService.update(channelParm);
			Log4jUtil.info(channelId + ":" + channelName + "结束更新签到标志");
			// 更新工作密钥与工作密钥的checkValue
			final String[] keys = MacUtil.getKey(retMsgPack);
			Log4jUtil.debug("keys:" + ArrayUtils.toString(keys));
			// 第六位为6 要求终端签到标志本位如果设定，要求终端应立即自动发起签到交易
			if ("6".equals(StringUtils.substring(processCode, 5, 6)) || keys == null || keys.length != 4) {
				Log4jUtil.debug("无key,不需保存");
				return null;
			} else {
				channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
				channelParmId.setCode("100014");
				channelParm = channelParmService.queryByPrimaryKey(channelParmId);

				final ChannelParm mainKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(
						ChannelIdEnum.BOC_CREDIT_CARD.getCode(), "100013"));
				AssertUtils.notNull(mainKeyParm, TransReturnCode.code_9108, "未得到主密钥");

				Log4jUtil.info(channelId + ":" + channelName + "签到返回的工作密钥是" + keys[2] + "验证值为" + keys[3]);
				channelParm.setParvalue(decryptWorkkey(mainKeyParm.getParvalue(), keys[2], keys[3]));// 工作密钥
				channelParmService.update(channelParm);

				channelParmId.setCode("100016");
				channelParm = channelParmService.queryByPrimaryKey(channelParmId);
				channelParm.setParvalue(keys[3]);// 工作密钥的checkValue
				channelParmService.update(channelParm);
			}

		} else {
			Log4jUtil.info(channelId + ":" + channelName + "签到失败,返回码是：" + rspCode);
			return null;
		}
		return new ReturnState();
	}

	/**
	 * 仿POS分期付款签到处理
	 * 
	 * @param param
	 * @throws BizException
	 */
	public ReturnState instalmentSignProcess(final String channelId, final String bankSendSn) throws BizException {

		// 签到并发送
		MsgPack signMsgPack = new MsgPack();// 签到包
		MsgPack retMsgPack = new MsgPack();// 签到返回包
		try {
			signMsgPack = bocCreditMsgUtilService.createInstalmentSign(bankSendSn);
			retMsgPack = bocCreditMsgUtilService.sendMsgForInstalments(signMsgPack);
		} catch (final Exception e) {
			// 发送超时,签到失败
			Log4jUtil.error(channelId + ":" + channelName + "签到失败," + bankSendSn, e);
			throw e;
		}
		// 获取应答码
		final String rspCode = retMsgPack.getFieldContent39();

		// 签到成功
		if ("00".equals(rspCode)) {

			// 更新批次号
			final String batchNo = retMsgPack.get61_1();
			String processCode = retMsgPack.getFieldContent3();// 处理码
			final ChannelParmId channelParmId = new ChannelParmId();
			channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			channelParmId.setCode("200009");
			ChannelParm channelParm = channelParmService.queryByPrimaryKey(channelParmId);
			Log4jUtil.info(channelId + ":" + channelName + "更新签到返回批次号" + batchNo + "开始");
			channelParm.setParvalue(batchNo);
			channelParmService.update(channelParm);
			Log4jUtil.info(channelId + ":" + channelName + "更新签到返回批次号结束");
			// 更新签到标志为已签到
			channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			channelParmId.setCode("200015");
			channelParm = channelParmService.queryByPrimaryKey(channelParmId);
			channelParm.setParvalue("1");
			Log4jUtil.info(channelId + ":" + channelName + "开始更新签到标志");
			channelParmService.update(channelParm);
			Log4jUtil.info(channelId + ":" + channelName + "结束更新签到标志");
			// 更新工作密钥与工作密钥的checkValue
			final String[] keys = MacUtil.getKey(retMsgPack);
			Log4jUtil.debug("keys:" + ArrayUtils.toString(keys));
			// 第六位为6 要求终端签到标志本位如果设定，要求终端应立即自动发起签到交易
			if ("6".equals(StringUtils.substring(processCode, 5, 6)) || keys == null || keys.length != 4) {
				Log4jUtil.debug("无key,不需保存");
				return null;
			} else {
				channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
				channelParmId.setCode("200014");// 工作密钥
				channelParm = channelParmService.queryByPrimaryKey(channelParmId);
				final ChannelParm mainKeyParm = channelParmService.queryByPrimaryKey(new ChannelParmId(
						ChannelIdEnum.BOC_CREDIT_CARD.getCode(), "200013"));
				AssertUtils.notNull(mainKeyParm, TransReturnCode.code_9108, "未得到主密钥");

				Log4jUtil.info(channelId + ":" + channelName + "签到返回的工作密钥是" + keys[2] + "验证值为" + keys[3]);
				channelParm.setParvalue(decryptWorkkey(mainKeyParm.getParvalue(), keys[2], keys[3]));// 工作密钥
				channelParmService.update(channelParm);

				channelParmId.setCode("200016");
				channelParm = channelParmService.queryByPrimaryKey(channelParmId);
				channelParm.setParvalue(keys[3]);// 工作密钥的checkValue
				channelParmService.update(channelParm);
			}

		} else {
			Log4jUtil.info(channelId + ":" + channelName + "签到失败,返回码是：" + rspCode);
			return null;
		}
		return new ReturnState();
	}

	/**
	 * 结算处理
	 * 
	 * @param bankSendSn 流水号
	 * @return
	 * @throws BizException
	 */
	public void check(final String bankSendSn) throws BizException {
		bocCreditMsgUtilService.sendMsg(bocCreditMsgUtilService.createCheck(bankSendSn));

	}

	/**
	 * 分期付款结算处理
	 * 
	 * @param bankSendSn 流水号
	 * @return
	 * @throws BizException
	 */
	public void instalmentCheck(final String bankSendSn) throws BizException {
		bocCreditMsgUtilService.sendMsgForInstalments(bocCreditMsgUtilService.createInstalmentCheck(bankSendSn));

	}

	/**
	 * 获取终端参数
	 * 
	 * @param bankSendSn 流水号
	 * @return
	 * @throws BizException
	 */
	public void downParameter() throws BizException {
		bocCreditMsgUtilService.sendMsg(bocCreditMsgUtilService.createDownParameter());

	}

	/**
	 * 
	 * @param param 基础平台传来的参数表
	 * @param bankSendSn 发往银行的流水
	 * @param billnoSn
	 * @param autoRealTimeRefund
	 * @return
	 * @throws BizException
	 */
	public ReturnState autoRealRefund(final Param param, final String bankSendSn,
			AutoRealTimeRefund autoRealTimeRefund, BillnoSn billnoSn) throws BizException {
		final String channelId = ChannelIdEnum.BOC_CREDIT_CARD.getCode();
		final String batchAndAuthorization = billnoSn.getCreditbatchno(); // 批次号
		String batchNo = null, authorizationCode = null;// cvv2 = null;
		if (batchAndAuthorization != null && batchAndAuthorization.length() >= 12) {
			batchNo = batchAndAuthorization.substring(0, 6);
			authorizationCode = batchAndAuthorization.substring(6, 12);
			// cvv2 = batchAndAuthorization.substring(12, 15);
		} else {
			Log4jUtil.error("获取原交易的批次号,授权码, CVV2码失败");
			throw new BizException(TransReturnCode.code_9108, "获取原交易的批次号,授权码, CVV2码失败");
		}
		Log4jUtil.info("billnoSn.getRecvTime() = " + billnoSn.getRecvTime()); // TODO
		String recvDate = "";
		try {
			recvDate = new SimpleDateFormat("MMddHHmmss").format(billnoSn.getRecvTime());
		} catch (final Exception e) {
			Log4jUtil.info("银行返回时间转换成MMddHHmmss失败, recvTime =  : billnoSn.getRecvTime() : " + e.toString());
		}

		Log4jUtil.info(autoRealTimeRefund.getRefundAmount() + "," + autoRealTimeRefund.getRevBankCardNo() + ","
				+ autoRealTimeRefund.getExpdate()); // TODO

		final BocCreditBean bocCredit = new BocCreditBean();
		bocCredit.setBankSendSn(bankSendSn);
		bocCredit.setBankRecvSn(billnoSn.getBankRecvSn());
		bocCredit.setAmount(autoRealTimeRefund.getRefundAmount());
		bocCredit.setBatchNo(batchNo);
		bocCredit.setAcctNo(autoRealTimeRefund.getRevBankCardNo());
		bocCredit.setValidDate(autoRealTimeRefund.getExpdate());
		bocCredit.setCvv2(autoRealTimeRefund.getCvv2());
		bocCredit.setBankDate(recvDate);
		bocCredit.setAuthorizationCode(authorizationCode);
		bocCredit.setOrgBankSendSn(billnoSn.getBankSendSn());
		String type = "";
		// 如果批次号与当前批次号相同，则发送撤销报文；如果批次号与当前批次号不同，则发送退货报文
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		Log4jUtil.info("原交易批次号：" + batchNo + "; 当前批次号：" + channelParms.get("100009"));
		MsgPack refundPack = new MsgPack(); // 自适应退款包
		MsgPack retRefundPack = new MsgPack(); // 返回的自适应退款包
		final ReturnState rs = new ReturnState();
		if (channelParms.get("100009").equals(batchNo)
				&& DateUtil.getCurrentDate().equals(new SimpleDateFormat("yyyyMMdd").format(billnoSn.getSendTime()))
				&& billnoSn.getAmount().equals(autoRealTimeRefund.getRefundAmount())) {
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_CANCLE);
			// 发送撤销报文
			type = "撤销";
			Log4jUtil.info("符合撤销条件，发送撤销报文");
			refundPack = bocCreditMsgUtilService.createCancel(bocCredit, channelParms,false);
			retRefundPack = bocCreditMsgUtilService.sendMsg(refundPack);
		} else {
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_REFUND);
			// 发送退货报文
			type = "退货";
			Log4jUtil.info("符合退货条件，发送退货报文");
			refundPack = bocCreditMsgUtilService.createReturn(bocCredit, channelParms,false);
			retRefundPack = bocCreditMsgUtilService.sendMsg(refundPack);
		}
		rs.setBankRetCode(retRefundPack.getFieldContent39());// 银行返回代码
		rs.setReturnMsg(retRefundPack.getFieldContent44());// 银行返回信息
		if ("00".equals(retRefundPack.getFieldContent39())) {
			Log4jUtil.info("渠道退款成功");
			rs.setReturnState(PayState.SUCCEED_STR);
			rs.setChannelCode(TransReturnCode.code_0000);
			rs.setReturnMsg(type + "成功");
			rs.setCreditNo(retRefundPack.getFieldContent37());
			rs.setBankRetBatchId(channelParms.get("100009") + retRefundPack.getFieldContent38());
		} else {
			ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
					retRefundPack.getFieldContent39()));
			Log4jUtil.info("退款失败");
			rs.setReturnState(PayState.FAILED_STR);
			rs.setBankRetCode(retRefundPack.getFieldContent39());
			if (channelRtncode != null) {
				rs.setChannelCode(channelRtncode.getKftRtncode());
				rs.setReturnMsg(channelRtncode.getChannelReamrk());
			} else {
				rs.setChannelCode(TransReturnCode.code_9900);
				rs.setReturnMsg("退款失败");
			}
		}
		return rs;
	}
	
	/**
	 * <p>分期消费的撤销</p>
	 * @param param
	 * @param bankSendSn
	 * @param autoRealTimeRefund
	 * @param billnoSn
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 */
	public ReturnState autoRealRefundInstalment(final Param param, final String bankSendSn,
			AutoRealTimeRefund autoRealTimeRefund, BillnoSn billnoSn) throws BizException {
		final String channelId = ChannelIdEnum.BOC_CREDIT_CARD.getCode();
		final String batchAndAuthorization = billnoSn.getCreditbatchno(); // 批次号
		String batchNo = null, authorizationCode = null;// cvv2 = null;
		if (batchAndAuthorization != null && batchAndAuthorization.length() >= 12) {
			batchNo = batchAndAuthorization.substring(0, 6);
			authorizationCode = batchAndAuthorization.substring(6, 12);
			// cvv2 = batchAndAuthorization.substring(12, 15);
		} else {
			Log4jUtil.error("获取原交易的批次号,授权码, CVV2码失败");
			throw new BizException(TransReturnCode.code_9108, "获取原交易的批次号,授权码, CVV2码失败");
		}
		Log4jUtil.info("billnoSn.getRecvTime() = " + billnoSn.getRecvTime()); // TODO
		String recvDate = "";
		try {
			recvDate = new SimpleDateFormat("MMddHHmmss").format(billnoSn.getRecvTime());
		} catch (final Exception e) {
			Log4jUtil.info("银行返回时间转换成MMddHHmmss失败, recvTime =  : billnoSn.getRecvTime() : " + e.toString());
		}

		Log4jUtil.info(autoRealTimeRefund.getRefundAmount() + "," + autoRealTimeRefund.getRevBankCardNo() + ","
				+ autoRealTimeRefund.getExpdate()); // TODO

		final BocCreditBean bocCredit = new BocCreditBean();
		bocCredit.setBankSendSn(bankSendSn);
		bocCredit.setBankRecvSn(billnoSn.getBankRecvSn());
		bocCredit.setAmount(autoRealTimeRefund.getRefundAmount());
		bocCredit.setBatchNo(batchNo);
		bocCredit.setAcctNo(autoRealTimeRefund.getRevBankCardNo());
		bocCredit.setValidDate(autoRealTimeRefund.getExpdate());
		bocCredit.setCvv2(autoRealTimeRefund.getCvv2());
		bocCredit.setBankDate(recvDate);
		bocCredit.setAuthorizationCode(authorizationCode);
		bocCredit.setOrgBankSendSn(billnoSn.getBankSendSn());
		String type = "";
		// 如果批次号与当前批次号相同，则发送撤销报文；如果批次号与当前批次号不同，则发送退货报文
		final Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		Log4jUtil.info("原交易批次号：" + batchNo + "; 当前批次号：" + channelParms.get("200009"));
		MsgPack refundPack = new MsgPack(); // 自适应退款包
		MsgPack retRefundPack = new MsgPack(); // 返回的自适应退款包
		final ReturnState rs = new ReturnState();
		if (channelParms.get("200009").equals(batchNo)
				&& DateUtil.getCurrentDate().equals(new SimpleDateFormat("yyyyMMdd").format(billnoSn.getSendTime()))
				&& billnoSn.getAmount().equals(autoRealTimeRefund.getRefundAmount())) {
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_CANCLE);
			// 发送撤销报文
			type = "撤销";
			Log4jUtil.info("符合撤销条件，发送撤销报文");
			refundPack = bocCreditMsgUtilService.createCancel(bocCredit, channelParms,true);
			retRefundPack = bocCreditMsgUtilService.sendMsgForInstalments(refundPack);
			rs.setBankRetCode(retRefundPack.getFieldContent39());// 银行返回代码
			rs.setReturnMsg(retRefundPack.getFieldContent44());// 银行返回信息
			if ("00".equals(retRefundPack.getFieldContent39())) {
				Log4jUtil.info("渠道退款成功");
				rs.setReturnState(PayState.SUCCEED_STR);
				rs.setChannelCode(TransReturnCode.code_0000);
				rs.setReturnMsg(type + "成功");
				rs.setCreditNo(retRefundPack.getFieldContent37());
				rs.setBankRetBatchId(channelParms.get("200009") + retRefundPack.getFieldContent38());
			} else {
				ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
						retRefundPack.getFieldContent39()));
				Log4jUtil.info("退款失败");
				rs.setReturnState(PayState.FAILED_STR);
				rs.setBankRetCode(retRefundPack.getFieldContent39());
				if (channelRtncode != null) {
					rs.setChannelCode(channelRtncode.getKftRtncode());
					rs.setReturnMsg(channelRtncode.getChannelReamrk());
				} else {
					rs.setChannelCode(TransReturnCode.code_9900);
					rs.setReturnMsg("退款失败");
				}
			}
		} else {
			rs.setClearingTransType(ClearingTransType.AUTO_REFUND_CREDIT_REFUND);
			// 发送退货报文
			// type = "退货";
			Log4jUtil.info("分期消费不支持线上退货，直接返回失败");
			// refundPack = bocCreditMsgUtilService.createReturn(bocCredit, channelParms,true);
			// retRefundPack = bocCreditMsgUtilService.sendMsgForInstalments(refundPack);
			rs.setBankRetCode("Z5");// 银行返回代码
			rs.setReturnMsg("分期消费不支持线上退货");// 银行返回信息
			rs.setReturnState(PayState.FAILED_STR);
			rs.setChannelCode(TransReturnCode.code_9900);
			rs.setReturnMsg("分期消费不支持线上退货");
			rs.setCreditNo(retRefundPack.getFieldContent37());
			rs.setBankRetBatchId(channelParms.get("200009"));
		}

		return rs;
	}

	/**
	 * 
	 * 用主密钥解工作密钥，形成明文密钥用于后期第64域生成
	 * 
	 * @param mainKey
	 * @param workKey
	 * @return workKey
	 * @throws BizException
	 */
	private String decryptWorkkey(final String mainKey, final String workKey, final String checkValue)
			throws BizException {
		final byte[] workKeyCrypt = J2DES.des_decrypt(LoUtils.hexStr2Bytes(mainKey), LoUtils.hexStr2Bytes(workKey));
		final String key = LoUtils.byte2HexStr(workKeyCrypt);
		Log4jUtil.info("工作密钥:{}单倍长密钥Des解码后明文：{}", workKey, key);
		return key;
	}

	/**
	 * 根据处理码进行维护 【4：表示自动结帐后终端批号更新及签到标志】 【5：表示手动结帐后终端批号更新标志】 【6：表示要求终端签到标志】
	 * 
	 * @param param
	 * @param bankSendSn
	 * @param code
	 * @return
	 * @throws BizException
	 */
	private boolean dealControlCode(final String channelId, final String bankSendSn, final String controlCode,
			final String batchNo) throws BizException {
		String code = "";

		if (controlCode != null && controlCode.length() == 6) {
			code = controlCode.substring(5, 6);
		}
		Log4jUtil.info("code = " + code); // TODO
		if ("4".equals(code) || "6".equals(code)) {
			Log4jUtil.info(channelId + ": 根据处理码（4/6）发起新的签到交易，以用于密钥交换。");
			// 签到
			this.signProcess(channelId, bankSendSn);
			return true;
		}
		if ("5".equals(code)) {
			Log4jUtil.info(channelId + ": 根据处理码（5）发起更新批次号。");
			ChannelParm channelParm = new ChannelParm();

			final ChannelParmId channelParmId = new ChannelParmId();
			channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			channelParmId.setCode("100009");
			channelParm = channelParmService.queryByPrimaryKey(channelParmId);
			channelParm.setParvalue(batchNo);
			channelParm.setUpdatetime(new Date());
			channelParmService.update(channelParm);
			return true;
		}
		return false;
	}

	/**
	 * <p>中行信用卡预授权</p>
	 * 
	 * @param dto 渠道流水交易的通用数据传输对象
	 * @param preAuth 信用卡预授权交易请求信息
	 * @param billnoSn 初始化的渠道流水信息
	 * @return 返回与银行交互后通讯信息
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-8-28 下午5:16:27
	 */
	public ClearingResult preAuth(BillnoSn billnoSn, BillnoSnTradeDTO dto, PreAuthDTO preAuth) throws BizException {
		final String channelId = dto.getChannelId();
		final ClearingResult result = new ClearingResult();
		final String bankSendSn = dto.getBankSendSn();
		MsgPack preAuthPack = new MsgPack();// 预授权包
		MsgPack rtnPreAuthPack = new MsgPack();// 预授权返回包
		try {
			preAuthPack = bocCreditMsgUtilService.createPreAuth(dto, preAuth);
		} catch (Exception e) {
			Log4jUtil.error("发送交易前,构建8583pos银行交互包出错:" + e.getMessage());
			result.setChannelId(channelId);
			result.setTxnStatus(PayState.FAILED_STR);
			result.setChannelResponseCode(ChannelClientErrorCodeEnum.CLIENT_UNSEND.getCode());
			result.setChannelResponseMsg("发送交易前,构建8583pos银行交互包出错");
			return result;
		}
		try {
			rtnPreAuthPack = bocCreditClinet.requestLink(preAuthPack);
		} catch (final ClearingAdapterClientCheckedException e) {
			Log4jUtil.info(channelId + ": 中行信用卡预授权报文发送出错,渠道流水号：" + bankSendSn + "错误信息：" + e.getMessage());
			ClearingAdapterClientCheckedException ce = (ClearingAdapterClientCheckedException) e;
			Log4jUtil.error("发送中行信用卡预授权报文处理出错BizException e.getMessage()：" + e.getMessage() + ", e.getErrorCode()："
					+ ce.getCode() + "[" + ChannelClientErrorCode.getNameByValue(ce.getCode() + "]"));
			result.setChannelId(channelId);
			result.setTxnStatus(PayState.FAILED_STR);
			result.setChannelResponseCode(ce.getCode());
			result.setChannelResponseMsg(ce.getMessage());
			return result;
		}
		return constructBankRtnInfo(billnoSn, rtnPreAuthPack);
	}

	/**
	 * <p>构建银行返回信息</p>
	 * 
	 * @param billnoSn 渠道流水信息
	 * @param msgPack 银行返回包信息
	 * @return 返回与银行交互后通讯信息
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-8-28 下午5:10:20
	 */
	private ClearingResult constructBankRtnInfo(BillnoSn billnoSn, MsgPack msgPack) throws BizException {
		final ClearingResult result = new ClearingResult();
		// 从msgPack中获取公共信息
		String rtnMsg = msgPack.getFieldContent44();// 银行返回信息
		String rtnCode = msgPack.getFieldContent39();// 银行返回代码
		String refNo = msgPack.getFieldContent37(); // 银行返回的参考号
		String batchNo = msgPack.get61_1();// 银行返回批次号
		String authCode = msgPack.getFieldContent38();// 授权响应码
		String posSysHourTime = msgPack.getFieldContent12();	// POS直连模块系统时的时间 6位hhmmss
		String posSysMD = msgPack.getFieldContent13();	// POS直连模块系统时的时间 4位MMDD
		// 构建returnState
		result.setTxnStatus(PayState.SUCCEED_STR);
		result.setChannelId(channelId);
		result.setPreAuthCode(authCode);// 中行预授权码
		result.setRelTranAmount(billnoSn.getAmount()); // 实际扣款金额
		result.setBankRtnCode(rtnCode);
		result.setBankRtnMsg(rtnMsg);
		result.setRetrievalRefNo(refNo);
		Log4jUtil.info(" 银行参考号retConsumeMsgPack.getFieldContent37() =" + refNo);
		Log4jUtil.info("POS直连模块系统时的时间hhmmss-consumeMsgPack.getFieldContent12() = " + posSysHourTime);
		Log4jUtil.info("POS直连模块系统时的时间 MMDD-consumeMsgPack.getFieldContent13() = " + posSysMD);
		Log4jUtil.info("银行返回的批次号：retConsumeMsgPack.get61_1() = " + batchNo);
		Log4jUtil.info("当前预授权的返回的授权码(38域)为：" + authCode);
		result.setCreditbatchno(batchNo + authCode);
		if (StringUtils.isNotBlank(posSysHourTime)) {
			final String resDate = DateUtil.getCurrentDate().substring(0, 4) + posSysMD + posSysHourTime;
			Date date = new Date();
			try {
				date = DateUtil.getDate(resDate);
			} catch (final Exception e) {
				Log4jUtil.info(channelId + "：消费返回时日期转换错误。（" + resDate + "）");
			}
			result.setRecvTime(date);// 银行交易时间
			Log4jUtil.info(channelId + ": 消费银行返回日期为：" + date.toString());
		} else {
			Log4jUtil.info("银行返回时间失败");
			result.setRecvTime(new Date());// 银行交易时间
		}
		if ("00".equals(rtnCode)) {
			result.setChannelResponseMsg("交易成功");
			result.setChannelResponseCode(TransReturnCode.code_0000);
		} else if ("91".equals(rtnCode)) {
			result.setChannelResponseMsg("银行处理交易超时!");
			result.setChannelResponseCode(TransReturnCode.code_9900);
		} else {
			ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, rtnCode));
			Log4jUtil.info("channelRtncode = " + channelRtncode);
			if (channelRtncode != null) {
				result.setChannelResponseMsg("交易失败, 银行返回码：" + channelRtncode.getId().getChannelRtncode() + "("
						+ channelRtncode.getChannelReamrk() + ")");
				result.setChannelResponseCode(channelRtncode.getKftRtncode());
			} else {
				Log4jUtil.info("交易失败，找不到对应的银行返回码：" + rtnCode);
				result.setChannelResponseCode(TransReturnCode.code_9900);
			}
		}
		result.setCheckDate(DateUtil.getCurrentDate());
		return result;
	}
}
