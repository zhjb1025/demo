package com.lycheepay.clearing.adapter.banks.boc.credit.kft.bean;

import java.math.BigDecimal;


/**
 * <P>中行信用卡实体</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午7:36:28
 */
public class BocCreditBean {
	private String acctNo; // 信用卡账号
	private BigDecimal amount = BigDecimal.ZERO; // 交易金额
	private String validDate; // 信用卡账号有效期
	private String cvv2; // 信用卡后3位
	private String bankSendSn; // 发往银行的交易流水号
	private String orgBankSendSn; // 原交易发往银行的流水(退货和撤销中用到)
	private String bankRecvSn; // 银行返回的交易流水号
	private String batchNo; // 批次号
	private String authorizationCode; // 消费交易中银行返回的授权码
	private String bankDate; // 银行返回的交易时间(MMddHHmmss)

	public String getAcctNo() {
		return acctNo;
	}

	public String getAuthorizationCode() {
		return authorizationCode;
	}

	public String getBankDate() {
		return bankDate;
	}

	public String getBankRecvSn() {
		return bankRecvSn;
	}

	public String getBankSendSn() {
		return bankSendSn;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public String getCvv2() {
		return cvv2;
	}

	public String getOrgBankSendSn() {
		return orgBankSendSn;
	}

	public String getValidDate() {
		return validDate;
	}

	public void setAcctNo(final String acctNo) {
		this.acctNo = acctNo;
	}

	public void setAuthorizationCode(final String authorizationCode) {
		this.authorizationCode = authorizationCode;
	}

	public void setBankDate(final String bankDate) {
		this.bankDate = bankDate;
	}

	public void setBankRecvSn(final String bankRecvSn) {
		this.bankRecvSn = bankRecvSn;
	}

	public void setBankSendSn(final String bankSendSn) {
		this.bankSendSn = bankSendSn;
	}

	public void setBatchNo(final String batchNo) {
		this.batchNo = batchNo;
	}

	public void setCvv2(final String cvv2) {
		this.cvv2 = cvv2;
	}

	public void setOrgBankSendSn(final String orgBankSendSn) {
		this.orgBankSendSn = orgBankSendSn;
	}

	public void setValidDate(final String validDate) {
		this.validDate = validDate;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(final BigDecimal amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "BocCreditBean [acctNo=" + acctNo + ", amount=" + amount + ", validDate=" + validDate + ", cvv2=" + cvv2
				+ ", bankSendSn=" + bankSendSn + ", orgBankSendSn=" + orgBankSendSn + ", bankRecvSn=" + bankRecvSn
				+ ", batchNo=" + batchNo + ", authorizationCode=" + authorizationCode + ", bankDate=" + bankDate + "]";
	}

}
