/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-14 下午3:52:08
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.tool;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B004Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B004RequestDetail;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B004Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B005Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B005RequestDetail;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B005Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C003Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C003ResponseDetail;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中行银企批量处理服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-26 上午11:30:18
 */
@Service(ClearingAdapterAnnotationName.BOC_CORP_BATCH_SERVICE)
public class BocCorpBatchService extends BaseWithoutAuditLogService {

	// 清算交易记录
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	// 渠道参数
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	// 清算返回码处理
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEND_BY_SOCKET_FOR_BOC)
	private SendBySocket4Boc bocSendBySocket;

	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;

	private static String channelId = ChannelIdEnum.BOC_CORP.getCode();

	/**
	 * <p>中国银行批量交易处理</p>
	 * 
	 * @param payList 待处理批量业务交易记录
	 * @return 银行返回交易状态(若需要returnCode则在子方法修改返回代码)
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-6-26 上午11:42:33
	 */
	public BatchSendResult sendBatchTransaction(String channelBatchId, List<ChannelTempBill> payList)
			throws BizException {
		final String transType = payList.get(0).getTransType();
		if (ClearingTransType.BATCH_PAY.equals(transType)) {// 付
			return processAndSendBatchPay(payList, channelBatchId, transType);
		} else if (ClearingTransType.BATCH_DEDUCT.equals(transType)) {// 收
			return processAndSendBatchDeduct(payList, channelBatchId, transType);
		}
		return new BatchSendResult();
	}

	/**
	 * <p>组装并发送批量代付报文</p>
	 * 
	 * @param payList 待处理批量代付的交易集合
	 * @param channelBatchId 批次ID
	 * @param transType 交易类型(批量代扣、批量代付)
	 * @return "S"代表成功,否则错误信息
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-6-26 下午3:00:25
	 */
	public BatchSendResult processAndSendBatchPay(final List<ChannelTempBill> payList, final String channelBatchId,
			final String transType) throws BizException {
		Log4jUtil.info("==进入批量代付报文组装");
		// 如果有记录，则执行批量交易
		final List<B005RequestDetail> details = new ArrayList<B005RequestDetail>();
		final List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>(payList.size());
		BigDecimal sum = BigDecimal.ZERO;
		int count = 0;
		for (final ChannelTempBill bill : payList) {
			Log4jUtil.info(bill);
			final B005RequestDetail b005RequestDetail = new B005RequestDetail(sequenceManagerService.getCorpBocSN(),
					bill.getBankAccountNo(), bill.getBankAccountHolder(), String.format("%1$.2f", bill.getAmount()));
			details.add(b005RequestDetail);
			sum = sum.add(bill.getAmount());
			billNoSnList.add(billnoSnService.toBillnoSn(bill, channelBatchId, b005RequestDetail.getTransNo(), count));
			count++;
		}
		billnoSnService.batchSave(billNoSnList);
		final String sumAmount = String.format("%1$.2f", sum);
		BatchSendResult batchSendResult = new BatchSendResult();
		B005Response b005Response = null;
		try {
			b005Response = batchPay(channelBatchId, String.valueOf(count), sumAmount, details);
			batchSendResult.setBankReturnCode(b005Response.getResultCode());
			batchSendResult.setBankReturnMsg(b005Response.getResultDesc());
			batchSendResult.setStatus(PayState.SUCCEED_STR);
			if ("R0000".equals(b005Response.getResultCode())) {
				batchSendResult.setStatus(PayState.SUCCEED_STR);
			} else {
				batchSendResult.setStatus(PayState.FAILED_STR);
			}
		} catch (final Exception e) {
			Log4jUtil.error("发送接收批量代付报文处理出错,批次号：" + channelBatchId + "，错误信息：" + e.getMessage(), e);
			throw e;
		}
		Log4jUtil.info(batchSendResult);
		return batchSendResult;
	}

	/**
	 * <p>发送中国银行批量代付报文B005</p>
	 * 
	 * @param packNo 批次号(包号)
	 * @param count 当前包总数
	 * @param sum 当前包总金额
	 * @param details 当钱包详细信息
	 * @return B005银行回应
	 * @author 邱林 Leon.Qiu 2012-6-26 下午2:59:14
	 * @throws BizException
	 */
	private B005Response batchPay(final String packNo, final String count, final String sum,
			final List<B005RequestDetail> details) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		byte[] key = BocCodeUtils.stringKeyToByteKey(channelParms.get("100003"));// DES密码
		String ip = channelParms.get("100001");
		String port = channelParms.get("100002");
		String sysCode = channelParms.get("100004");
		// 创建请求报文
		final B005Request b005Request = new B005Request(packNo, count, sum, details);
		// 设置请求头信息
		b005Request.setSysCode(sysCode);
		b005Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// b005Request.setMsgType("B005");// 中行代码，代表批量代扣
		b005Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		// 生成报文
		final String sendXML = b005Request.getXML();
		Log4jUtil.info("生成批量代付报文：" + sendXML);
		final byte[] decodeBytes = bocSendBySocket.sendAndRecv(key, sendXML, ip, port, sysCode);
		final B005Response b005Response = new B005Response(decodeBytes);
		return b005Response;
	}

	/**
	 * <p>组装并发送批量代扣报文</p>
	 * 
	 * @param payList 待处理批量代扣的交易集合
	 * @param channelBatchId 批次ID
	 * @param transType 交易类型(批量代扣、批量代付)
	 * @return S"代表成功,否则错误信息
	 * @author 邱林 Leon.Qiu 2012-6-26 下午3:09:49
	 * @throws BizException
	 */
	public BatchSendResult processAndSendBatchDeduct(final List<ChannelTempBill> payList, final String channelBatchId,
			final String transType) throws BizException {
		Log4jUtil.info("==进入批量代扣报文组装");
		// 如果有记录，则执行批量交易
		final List<B004RequestDetail> details = new ArrayList<B004RequestDetail>();
		final List<BillnoSn> billNoSnList = new ArrayList<BillnoSn>(payList.size());
		BigDecimal sum = BigDecimal.ZERO;
		int count = 0;
		for (final ChannelTempBill bill : payList) {
			Log4jUtil.info("批量查询bill：" + bill);
			final B004RequestDetail b004RequestDetail = new B004RequestDetail(sequenceManagerService.getCorpBocSN(),
					bill.getBankAccountNo(), bill.getBankAccountHolder(), String.format("%1$.2f", bill.getAmount()));
			details.add(b004RequestDetail);
			sum = sum.add(bill.getAmount());
			billNoSnList.add(billnoSnService.toBillnoSn(bill, channelBatchId, b004RequestDetail.getTransNo(), count));
			count++;
		}
		billnoSnService.batchSave(billNoSnList);
		final String sumAmount = String.format("%1$.2f", sum);
		BatchSendResult batchSendResult = new BatchSendResult();
		B004Response b004Response = null;
		try {
			b004Response = batchDeduct(channelBatchId, String.valueOf(count), sumAmount, details);
			batchSendResult.setBankReturnCode(b004Response.getResultCode());
			batchSendResult.setBankReturnMsg(b004Response.getResultDesc());
			if ("R0000".equals(b004Response.getResultCode())) {
				batchSendResult.setStatus(PayState.SUCCEED_STR);
			} else {
				batchSendResult.setStatus(PayState.FAILED_STR);
			}
			// updateBatchSend(channelBatchId, "S", b004Response.getResultCode(),
			// b004Response.getResultDesc());
			// return "S";
		} catch (final Exception e) {
			Log4jUtil.error("发送接收批量代扣报文处理出错,批次号：" + channelBatchId + "，错误信息：" + e.getMessage());
			throw e;
		}
		return batchSendResult;
	}

	/**
	 * <p>发送中国银行批量代收/扣报文B004</p>
	 * 
	 * @param packNo 批次号(包号)
	 * @param count 当前包总数
	 * @param sum 当前包总金额
	 * @param details 当钱包详细信息
	 * @return B004银行回应
	 * @author 邱林 Leon.Qiu 2012-6-26 下午2:59:14
	 * @throws BizException
	 */
	private B004Response batchDeduct(final String packNo, final String count, final String sum,
			final List<B004RequestDetail> details) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		byte[] key = BocCodeUtils.stringKeyToByteKey(channelParms.get("100003"));// DES密码
		String ip = channelParms.get("100001");
		String port = channelParms.get("100002");
		String sysCode = channelParms.get("100004");
		// 创建请求报文
		final B004Request b004Request = new B004Request(packNo, count, sum, details);
		// 设置请求头信息
		b004Request.setSysCode(sysCode);
		b004Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// b004Request.setMsgType("B004");// 中行代码，代表批量代扣
		b004Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		// 生成报文
		final String sendXML = b004Request.getXML();
		Log4jUtil.info("生成批量代扣报文：" + sendXML);
		final byte[] decodeBytes = bocSendBySocket.sendAndRecv(key, sendXML, ip, port, sysCode);
		final B004Response b004Response = new B004Response(decodeBytes);
		return b004Response;
	}

	/**
	 * <p>批量查询后更新表状态</p>
	 * 
	 * @param c003Response
	 * @author 张凯锋
	 * @throws BizException
	 */
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
	public String updateBillNoSnResult(String channelBatchId, C003Response c003Response) throws BizException {
		Log4jUtil.info(c003Response);
		String result = "";
		String resultCode = c003Response.getResultCode();
		Log4jUtil.info("==resultCode:" + resultCode);
		if ("R0000".equals(resultCode)) {
			// 1、更新billnosn
			Log4jUtil.info("==1、更新billnosn:");
			Long sucessnum = 0L;          // SucessNum 成功总笔数
			Double sucessamount = 0.0;     // SucessAmount 成功总金额
			Long unsucessnum = 0L;        // UnSucessNum 失败总笔数
			Double unsucessamount = 0.0;   // UnSucessAmount 失败总金额
			List<C003ResponseDetail> details = c003Response.getDetails();
			Log4jUtil.info("==details" + details.size());
			BillnoSn billnoSn = new BillnoSn();
			for (C003ResponseDetail detail : details) {
				billnoSn = billnoSnService.getBillnoSn(channelId, detail.getTransNo());
				Log4jUtil.info("==billnoSn" + billnoSn);
				if (billnoSn == null) {
					Log4jUtil.error("在表 billnoSn中找不到批量返回的交易记录，交易记录详细信息如下：" + "渠道ID：" + channelId + "渠道批次："
							+ channelBatchId + "交易金额：" + detail.getTransAmt());
					continue;
				}
				Log4jUtil.info("=1=更新==");
				// 给 ChannelBatch 表做记录汇总
				if ("S00".equals(detail.getTransStatus())) {
					sucessnum += 1;          // SucessNum 成功总笔数
					if (StringUtils.isNotBlank(detail.getTransAmt())) {
						billnoSn.setActualAmount(new BigDecimal(detail.getTransAmt())); // 渠道实际支付金额
						sucessamount += Double.valueOf(detail.getTransAmt()); // SucessAmount 成功总金额
					}
					billnoSn.setPayState("1");// 成功1
				} else {
					unsucessnum += 1;          // UnSucessNum 失败总笔数
					if (StringUtils.isNotBlank(detail.getTransAmt())) {
						unsucessamount += Double.valueOf(detail.getTransAmt()); // UnSucessAmount失败总金额
					} else {
						unsucessamount += billnoSn.getAmount().doubleValue();
					}
					billnoSn.setPayState("2");// 失败2
				}
				Log4jUtil.info("=2=更新==");
				billnoSn.setChannelRtncode(detail.getTransStatus()); // 渠道返回码
				billnoSn.setChannelRtnnote(detail.getTransDesc()); // 渠道返回附言
				billnoSn.setState(BillnoSnState.billnoRecv); // 02：业务回执已返回
				billnoSn.setRecvTime(new Date()); // 返回时间
				if (StringUtils.isNotBlank(detail.getAccountDate()))
					billnoSn.setCheckDate(detail.getAccountDate().replace("-", "")); // 收到回执报文后更新
				Log4jUtil.info("根据批量返回更新billnosn：" + billnoSn);
				Log4jUtil.info("=3=更新==");
				billnoSnService.update(billnoSn);
			}

			batchProcessResultNotice.process(channelId, channelBatchId, billnoSn.getTranType(), sucessnum,
					sucessamount, unsucessnum, unsucessamount);

			// 3、回调
			if (sucessnum == 0 && unsucessnum == 0) {
				Log4jUtil.info("中行银企批量结果查询到的结果为空，批次号：" + channelBatchId);
			}
			result = "中行银企正常处理完成，批次号：" + channelBatchId;
		} else {
			Log4jUtil.info("中行银企批量结果查询到的结果不成功，" + c003Response.getResultDesc() + "批次号：" + channelBatchId);
		}
		return result;
	}

}
