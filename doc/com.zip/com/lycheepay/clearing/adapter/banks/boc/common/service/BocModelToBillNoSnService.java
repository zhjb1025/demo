/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-13 下午2:53:05
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.common.service;

import java.util.Date;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;


/**
 * <P>中国银行数据模型转成清算流水数据模型服务类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午6:06:01
 */
@Service(ClearingAdapterAnnotationName.BOC_MODEL_TO_BILLNOSN_SERVICE)
public class BocModelToBillNoSnService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService bankAccountBalanceService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManager;

	/**
	 * <p>代扣对象转为BillnoSn对象，方便存储</p>
	 * 
	 * @param bankSendSn 给银行的订单号
	 * @param deductDTO 扣款DTO
	 * @return
	 * @author 张凯锋
	 */
	public BillnoSn b001(final String bankSendSn, final DeductDTO deductDTO, final String channelId) {
		String CorpAcctNo = ""; // 企业帐号 对应渠道绑定的帐号
		String CorpAcctName = ""; // 企业帐号名 对应渠道绑定的帐号名
		String CorpBankNo = ""; // 企业行号 对应渠道绑定帐号所属的行号
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		if (bankaccountBalance != null) {
			CorpAcctNo = bankaccountBalance.getAccountNo(); // 企业帐号--对应渠道绑定的帐号
			CorpAcctName = bankaccountBalance.getAccountName();// 企业帐号名--对应渠道绑定的帐号名
			CorpBankNo = bankaccountBalance.getBankNo(); // 企业行号--对应渠道绑定帐号所属的行号
		}
		final BillnoSn billnoSn = new BillnoSn();
		// 写交易流水和渠道流水对照表
		billnoSn.setBillnosnSeq(sequenceManager.getBillnoSnSeq());
		billnoSn.setSn(deductDTO.getTxnId());
		billnoSn.setTranType(ClearingTransType.REAL_TIME_DEDUCT);
		billnoSn.setChannelid(channelId);// 渠道Id
		billnoSn.setBankSendSn(bankSendSn); // 银行订单号
		billnoSn.setTranDate(DateUtil.getDate(new Date()));// 交易日期
		billnoSn.setAmount(deductDTO.getAmount()); // 平台交易金额
		billnoSn.setState(BillnoSnState.billnoSend); // 00：已发送
		billnoSn.setSendTime(new Date());
		billnoSn.setCorpacctno(CorpAcctNo); // 企业帐号 对应渠道绑定的帐号
		billnoSn.setCorpacctname(CorpAcctName);// 企业户名 对应渠道绑定的帐号名
		billnoSn.setCorpbankno(CorpBankNo);// 企业行号
		billnoSn.setOtheracctno(deductDTO.getBankCardNo());// 对方帐号
		billnoSn.setOtheracctname(deductDTO.getCardHolderName());// 对方户名
		billnoSn.setOtherbankno(deductDTO.getBankCode());// 对方行号
		billnoSn.setOtherbankaddrno(deductDTO.getBankAreaCode());// 对方开户行地区代码
		billnoSn.setOthercustId(deductDTO.getAccountId());// 对方客户编号
		billnoSn.setBankType(deductDTO.getBankType());// 行别(非空）
		billnoSn.setSrccustId("");// 发起方客户编号
		billnoSn.setOrderid(deductDTO.getBizTxnId());// 订单号
		billnoSn.setBankCardType(deductDTO.getBankCardType());
		return billnoSn;
	}

	/**
	 * <p>代付对象转为BillnoSn对象，方便存储</p>
	 * 
	 * @param transNo
	 * @param pay
	 * @return
	 * @author 张凯锋
	 */
	public BillnoSn b002(final String bankSendSn, final PayOutDTO pay, final String channelId) {
		String CorpAcctNo = ""; // 企业帐号 对应渠道绑定的帐号
		String CorpAcctName = ""; // 企业帐号名 对应渠道绑定的帐号名
		String CorpBankNo = ""; // 企业行号 对应渠道绑定帐号所属的行号
		final BankaccountBalance bankaccountBalance = bankAccountBalanceService.getBankaccountBean(channelId);
		if (bankaccountBalance != null) {
			CorpAcctNo = bankaccountBalance.getAccountNo(); // 企业帐号--对应渠道绑定的帐号
			CorpAcctName = bankaccountBalance.getAccountName();// 企业帐号名--对应渠道绑定的帐号名
			CorpBankNo = bankaccountBalance.getBankNo(); // 企业行号--对应渠道绑定帐号所属的行号
		}

		final BillnoSn billnoSn = new BillnoSn();
		// 写交易流水和渠道流水对照表
		billnoSn.setBillnosnSeq(sequenceManager.getBillnoSnSeq());
		billnoSn.setSn(pay.getTxnId());
		billnoSn.setChannelid(channelId);// 渠道Id
		billnoSn.setBankSendSn(bankSendSn); // 银行订单号
		billnoSn.setTranDate(DateUtil.getDate(new Date()));// 交易日期
		billnoSn.setAmount(pay.getAmount()); // 平台交易金额
		billnoSn.setTranType(ClearingTransType.REAL_TIME_PAY);
		billnoSn.setState(BillnoSnState.billnoSend); // 00：已发送
		billnoSn.setSendTime(new Date());
		billnoSn.setCorpacctno(CorpAcctNo); // 企业帐号 对应渠道绑定的帐号
		billnoSn.setCorpacctname(CorpAcctName);// 企业户名 对应渠道绑定的帐号名
		billnoSn.setCorpbankno(CorpBankNo);// 企业行号
		billnoSn.setOtheracctno(pay.getBankCardNo());// 对方帐号
		billnoSn.setOtheracctname(pay.getCardHolderName());// 对方户名
		billnoSn.setOtherbankno(pay.getBankCode());// 对方行号
		billnoSn.setOtherbankaddrno(pay.getBankAreaCode());// 对方开户行地区代码
		billnoSn.setOthercustId(pay.getAccountId());// 对方客户编号
		billnoSn.setBankType(pay.getBankType());// 行别(非空）
		billnoSn.setOrderid(pay.getBizTxnId());// 订单号
		billnoSn.setBankCardType(pay.getBankCardType());
		return billnoSn;
	}
}
