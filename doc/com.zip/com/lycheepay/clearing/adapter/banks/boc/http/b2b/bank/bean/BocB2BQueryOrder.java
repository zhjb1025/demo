package com.lycheepay.clearing.adapter.banks.boc.http.b2b.bank.bean;

import java.util.HashMap;
import java.util.Map;


/**
 * <P>中行B2B订单信息查询实体</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午4:44:21
 */
public class BocB2BQueryOrder {
	private final String bocNo = "";// 商户号
	private final String orderNos = "";// 订单号 商户系统产生的订单号；数字与26个英文字母以及中划线（-）和下划线（_）
	private final String signData = "";// 数字签名

	// bocNo=&orderNo=&curCode=&orderAmount=&orderTime=&orderNote=&orderUrl=&signData=
	public Map<String, String> creatBocB2BQueryOrderParam() {
		final Map<String, String> params = new HashMap<String, String>();
		params.put("bocNo", bocNo);
		params.put("orderNos", orderNos);
		params.put("signData", signData);
		return params;
	}

	public String getToBeSignedData() {
		// 商户签名数据串格式，各项数据用管道符分隔：
		// 商户号|商户订单号字符串
		// bocNo|orderNos
		final String toBeSignedString = bocNo + "|" + orderNos;
		return toBeSignedString;
	}

}
