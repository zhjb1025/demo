/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-10 上午11:35:26
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.tool;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;


/**
 * <P>DEFLATE压缩工具类</P>
 * 
 * @author 张凯锋
 */
public class Deflate {
	/**
	 * <p>压缩</p>
	 * 
	 * @param data
	 * @return
	 * @throws IOException
	 * @author 张凯锋
	 */
	public static byte[] compress(final byte[] data) throws IOException {
		final Deflater compresser = new Deflater();
		compresser.setInput(data);
		compresser.finish();
		final ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);
		final byte[] buffer = new byte[1024];
		while (!compresser.finished()) {
			final int bytesCompressed = compresser.deflate(buffer);
			bos.write(buffer, 0, bytesCompressed);
		}
		bos.close();
		return bos.toByteArray();
	}

	/**
	 * <p>解压</p>
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 * @author 张凯锋
	 */
	public static byte[] deCompress(final byte[] data) throws Exception {
		final Inflater decompresser = new Inflater();
		decompresser.setInput(data);
		final ByteArrayOutputStream bos = new ByteArrayOutputStream(data.length);
		final byte[] buffer = new byte[1024];
		while (!decompresser.finished()) {
			final int bytesCompressed = decompresser.inflate(buffer);
			bos.write(buffer, 0, bytesCompressed);
		}
		bos.close();
		return bos.toByteArray();
	}
}
