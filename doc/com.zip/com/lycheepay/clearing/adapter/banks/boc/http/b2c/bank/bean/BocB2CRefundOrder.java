package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

public class BocB2CRefundOrder {
	String merchantNo = "";// BOC商户ID
	String mRefundSeq = "";// 商户系统产生的交易流水号
	String curCode = "001";// 固定填001
	String refundAmount = "";// 退款金额 格式：整数位不前补零,小数位补齐2位 即：不超过10位整数位+1位小数点+2位小数
	// 无效格式如123，.10，1.1,有效格式如1.00，0.10
	String orderNo = ""; // 商户系统产生的订单号，原支付订单的商户订单号
	String signData = ""; // 商户签名数据串格式，各项数据用管道符分隔：

	// 商户号|商户退款交易流水号|退款币种|退款金额|商户订单号
	// merchantNo | mRefundSeq | curCode | refundAmount |orderNo

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(final String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getMRefundSeq() {
		return mRefundSeq;
	}

	public void setMRefundSeq(final String refundSeq) {
		mRefundSeq = refundSeq;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(final String curCode) {
		this.curCode = curCode;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(final String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(final String orderNo) {
		this.orderNo = orderNo;
	}

	public String getSignData() {
		return signData;
	}

	public void setSignData(final String signData) {
		this.signData = signData;
	}
}
