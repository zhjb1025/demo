package com.lycheepay.clearing.adapter.banks.boc.http.b2c.kft.processor;

//package com.lycheepay.clearing.adapter.banks.boc.b2c.kft.processor;
//
//import java.io.BufferedReader;
//import java.io.FileInputStream;
//import java.io.InputStreamReader;
//import java.nio.charset.Charset;
//import java.text.Format;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.channel.AccBean;
//import com.lycheepay.clearing.adapter.common.model.channel.param.CheckParam;
//import com.lycheepay.clearing.adapter.common.service.biz.PayChannelService;
//import com.lycheepay.clearing.adapter.common.service.channel.ICheckProcessor;
//import com.lycheepay.clearing.adapter.common.util.net.FileProcess;
//import com.lycheepay.clearing.common.constant.ChannelId;
//
//
///**
// * 
// * 中行银行对账处理器
// * 
// * @author
// * @history 2010-12-15
// * 
// */
//public class BocCheckProcessor implements ICheckProcessor {
//	private static PayChannelService payChannelDao = (PayChannelService) SpringContext.getService("payChannelDao");
//	private static AccUtilService accUtilService = (AccUtilService) SpringContext.getService("accUtilService");
//
//	// public static void main(String args[]) {
//	// CheckParam cparam = new CheckParam();
//	// cparam.setChannelId("1001050000");
//	// cparam.setCheckDate("20110429");
//	// cparam.setFileFullPathName("D:\\BALACCT_105584073990138_20110430_095845_068892.txt");
//	// BocCheckProcessor bocCheckProcessor = new BocCheckProcessor();
//	// try {
//	// bocCheckProcessor.deal(cparam);
//	// } catch (BizException e) {
//	// // TODO Auto-generated catch block
//	// Log4jUtil.error(e);
//	// }
//	// }
//
//	/**
//	 * 返回： 0--成功 ； 1--失败
//	 */
//	@Override
//	public int deal(final CheckParam cparam) throws BizException {
//		String logMsg = "";
//		String channelId = "";
//		String logPrefix = "";
//		channelId = cparam.getChannelId();
//		logPrefix = channelId + ChannelId.getNameByValue(channelId);
//		logMsg = "开始进行" + logPrefix + "的" + cparam.getCheckDate() + "对账处理。";
//		Log4jUtil.info(logMsg);
//		// 获取对账明细List
//		ArrayList<AccBean> accBeanList = new ArrayList<AccBean>();
//		accBeanList = this.getAccBeanList(logPrefix, cparam);
//		// 获取对账文件名
//		final String fileName = FileProcess.getFileNameAtPath(cparam.getFileFullPathName());
//		// 调用公用对账方法
//		Log4jUtil.info(logPrefix + "对账对象生成成功,开始调用公共对账处理。");
//		final int Ret = accUtilService.accCheck(accBeanList, cparam.getChannelId(), cparam.getCheckDate(), fileName);
//		if (Ret != 0) {
//			Log4jUtil.info(logPrefix + "对账出错！");
//		}
//		Log4jUtil.info(logPrefix + "对账完成！");
//		return Ret;
//	}
//
//	/**
//	 * 
//	 * @param logPrefix
//	 * @param checkParam
//	 * @return
//	 * @throws BizException
//	 */
//	private ArrayList getAccBeanList(final String logPrefix, final CheckParam checkParam) throws BizException {
//		String logMsg = "";
//		logMsg = logPrefix + "准备生成对账对象。";
//		Log4jUtil.info(logMsg);
//		final ArrayList<AccBean> accBeanList = new ArrayList<AccBean>();
//		BufferedReader bufferedReader = null;
//		try {
//			// 循环对文本逐行处理
//			int currLine = 0;
//			String data = null;
//			// bufferedReader = new BufferedReader(new BufferedReader(new
//			// FileReader(checkParam.getFileFullPathName())));
//			final InputStreamReader reader = new InputStreamReader(
//					new FileInputStream(checkParam.getFileFullPathName()), Charset.forName("GBK"));
//			bufferedReader = new BufferedReader(reader);
//			int i = 0; // ArrayList 记录数
//			Double amount = 0.00;
//			while ((data = bufferedReader.readLine()) != null) {
//				final AccBean accBean = new AccBean();
//				currLine++; // 对账文件 行循环
//				logMsg = logPrefix + "对账文件第 " + currLine + " 行文件内容为：" + data;
//				Log4jUtil.info(logMsg);
//				if (0 < data.trim().length()) {
//					/*	商户号 | 订单号 | 订单时间 | 支付时间 | 交易币种 | 交易金额 | 银行卡类别 | 银行订单流水号 | 订单状态 |				
//					104110059471225|SD20081102007|20081101153000|20081103105545|001|113.07|中行借记卡|5142|支付|
//					104110059471225|SD20081102008|20081101153000|20081103105631|001|113.08|中行借记卡|5161|支付|
//					104110059471225|nmg20081013008|20081102121212|20081103104636|001|13.70|中行信用卡（总行卡）|5041|支付|
//					104110059471225|nmg20081013009|20081102121212|20081103104750|001|13.80|中行信用卡（分行卡）|5061|支付|
//					104110059471225|nmg20081013010|20081102121212|20081103104851|001|13.90|中行借记卡|5082|支付|
//					104110059471225|tj20081102702|20081102121212|20081103111413|001|13.11|中行借记卡|5381|支付|
//					104110059471225|tj20081102703|20081102121212|20081103111459|001|14.11|中行借记卡|5402|支付|
//					104110059471225|tj20081102700|20081102121212|20081103111211|001|11.11|中行信用卡（分行卡）|5321|失败|*/
//					final String[] currentLineData = data.split("|");
//					if (1 < currentLineData.length) {
//						String tradeDate = currentLineData[3].trim();// 成功支付时间
//						if (!DateUtil.isValidDate(tradeDate, "yyyyMMddhhmmss")) {
//							// 若不是合法交易时间，则直接跳过该行
//							logMsg = logPrefix + "该行不是合法的交易数据。";
//							Log4jUtil.info(logMsg);
//							continue;
//						} else {
//							final Format format = new SimpleDateFormat("yyyyMMddhhmmss");
//							try {
//								tradeDate = DateUtil.getDate((Date) format.parseObject(tradeDate));
//							} catch (final ParseException e) {
//								Log4jUtil.error(e);
//								throw new BizException(e);
//							}
//						}
//						final String orderNo = currentLineData[1].trim();// 订单号
//						final String amtTrade = currentLineData[5].trim();// 交易金额
//						amount = amount + Double.valueOf(amtTrade);
//						final String retCode = currentLineData[8].trim();// 响应码
//						accBean.setCheckDate(checkParam.getCheckDate());
//						accBean.setBankSendSn(orderNo); // 订单号
//						accBean.setTranDate(tradeDate); // 交易日期
//						accBean.setTradeAmount(Double.parseDouble(amtTrade));// 交易金额
//						// 交易状态 00-支付成功；01-支付失败；02-超时
//						if (retCode.equals("成功")) {
//							accBean.setBankTradestate("00");
//						} else {
//							accBean.setBankTradestate("01");
//						}
//						i++;
//						logMsg = logPrefix + "将对账文件中第" + currLine + "行数据构造accBean，添加到accBeanList的第" + i + "条记录:";
//						logMsg = logMsg + " checkDate:" + accBean.getCheckDate() + " BankSendSn:"
//								+ accBean.getBankSendSn();
//						logMsg = logMsg + " TranDate:" + accBean.getTranDate() + " TradeAmount:"
//								+ accBean.getTradeAmount();
//						Log4jUtil.info(logMsg);
//						accBeanList.add(accBean);
//					}
//				}
//			}// while
//				Log4jUtil.info(logPrefix+"本次共成功生成 "+i+"行对账明细。总金额为："+
//				// String.format("%1$.2f", amount));
//		} catch (final Exception e) {
//			throw new BizException(logPrefix + "网银对账失败,文件:[" + checkParam.getFileFullPathName() + "]" + e);
//		} finally {
//			try {
//				if (null != bufferedReader) {
//					bufferedReader.close();
//				}// 关闭文件
//			} catch (final Exception e) {
//				Log4jUtil.error(logPrefix+"关闭文件流出错:"+e);
//				throw new BizException(logPrefix + "网银对账失败,关闭文件流出错文件:[" + checkParam.getFileFullPathName() + "]" + e);
//			}
//		}
//		return accBeanList;
//	}
// }
