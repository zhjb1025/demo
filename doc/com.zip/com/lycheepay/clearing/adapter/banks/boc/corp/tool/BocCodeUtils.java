package com.lycheepay.clearing.adapter.banks.boc.corp.tool;

import java.util.Arrays;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企直连报文加密解密工具类</P>
 * 
 * @author 张凯锋
 */
public class BocCodeUtils {

	public static byte[] stringKeyToByteKey(final String skey) {
		if (skey == null || "".equals(skey)) {
			return null;
		}
		final String[] skeyArray = skey.split(",");
		final byte[] bkey = new byte[skeyArray.length];
		for (int i = 0; i < skeyArray.length; i++) {
			bkey[i] = (byte) Integer.parseInt(skeyArray[i].trim());
		}
		return bkey;
	}

	/**
	 * <p>加密中行报文</p>
	 * 
	 * @param key DES密钥数组
	 * @param data 要加密的数据
	 * @param localSysCode 系统参数表中代码
	 * @return
	 * @throws Exception
	 * @author 张凯锋
	 */
	public static byte[] encode(final byte[] key, final byte[] data, final byte[] localSysCode) throws Exception {
		final byte[] desData = DES.crypt(key, data);
		final byte[] compressData = Deflate.compress(desData);
		final byte[] md5Data = MD5.encode(compressData);
		final byte[] all = ArrayUtils.addAll(md5Data, compressData);
		final byte[] allWithLength = ArrayUtils.addAll(intToByte(all.length), all);
		return ArrayUtils.addAll(localSysCode, allWithLength);
	}

	/**
	 * <p>解码中行报文</p>
	 * 
	 * @param key DES密钥数组
	 * @param data 要加密的数据
	 * @param localSysCode 系统参数表中代码
	 * @return
	 * @throws Exception
	 * @author 张凯锋
	 */
	public static byte[] decode(final byte[] key, final byte[] data, final String localSysCode) throws Exception {
		final byte[] sysCode = new byte[4];
		System.arraycopy(data, 0, sysCode, 0, 4);
		final String sysCodeStr = new String(sysCode);
		Log4jUtil.info("BocCorpChannelServiceImpl.sysCode：" + localSysCode);
		Log4jUtil.info("银行返回系统代码：" + sysCodeStr);
		if (!localSysCode.equals(sysCodeStr)) {
			throw new RuntimeException("银行返回系统代码不正确异常：" + sysCodeStr);
		}

		final byte[] rcode = new byte[2];
		System.arraycopy(data, 4, rcode, 0, 2);
		final String rcodeStr = new String(rcode);
		Log4jUtil.info("银行通道响应码：" + rcodeStr);
		if (!"00".equals(rcodeStr)) {
			throw new RuntimeException(rcodeStr + "|银行处理报文异常：" + getRcodeDesc(rcodeStr));
		}

		final byte[] len = new byte[4];
		System.arraycopy(data, 6, len, 0, 4);
		final int length = BocCodeUtils.byteToInt(len);
		Log4jUtil.info("标注报文长度：" + length);
		if (length == data.length - 10) {
			final byte[] md5 = new byte[16];
			System.arraycopy(data, 10, md5, 0, 16);
			final byte[] deflate = new byte[data.length - 26];
			System.arraycopy(data, 26, deflate, 0, data.length - 26);
			// 检查摘要信息
			if (!Arrays.toString(md5).equals(Arrays.toString(MD5.encode(deflate)))) {
				throw new RuntimeException("报文MD5不等");
			}
			final byte[] deCompress = Deflate.deCompress(deflate);
			return DES.decrypt(key, deCompress);
		} else {
			throw new RuntimeException("报文长度不等于报文头标注的长度");
		}
	}

	/**
	 * <p>TODO</p>
	 * 
	 * @param rcodeStr
	 * @return
	 * @author 张凯锋
	 */
	private static String getRcodeDesc(final String rcodeStr) {
		String result = "";
		if ("00".equals(rcodeStr)) {
			result = "正常处理";
		} else if ("01".equals(rcodeStr)) {
			result = "IO通道异常";
		} else if ("02".equals(rcodeStr)) {
			result = "报文长度标识非法";
		} else if ("03".equals(rcodeStr)) {
			result = "报文长度非法";
		} else if ("04".equals(rcodeStr)) {
			result = "MD5校验异常";
		} else if ("05".equals(rcodeStr)) {
			result = "Inflate解压异常";
		} else if ("06".equals(rcodeStr)) {
			result = "DES解密异常";
		} else if ("07".equals(rcodeStr)) {
			result = "流量过大";
		} else if ("08".equals(rcodeStr)) {
			result = "非法XML报文,未通过xsd验证";
		} else if ("99".equals(rcodeStr)) {
			result = "银行内部其它异常";
		}
		return result;
	}

	/**
	 * <p>int转为byte数组</p>
	 * 
	 * @param n
	 * @return
	 * @author 张凯锋
	 */
	static byte[] intToByte(final int n) {
		final byte[] intBytes = new byte[4];
		intBytes[0] = (byte) (n >> 24);
		intBytes[1] = (byte) (n >> 16);
		intBytes[2] = (byte) (n >> 8);
		intBytes[3] = (byte) (n >> 0);
		return intBytes;
	}

	/**
	 * <p>byte转为int</p>
	 * 
	 * @param b
	 * @return
	 * @author 张凯锋
	 */
	static int byteToInt(final byte[] byteVal) {
		int result = 0;
		for (int i = 0; i < byteVal.length; i++) {
			int tmpVal = (byteVal[i] << (8 * (3 - i)));
			switch (i) {
				case 0:
					tmpVal = tmpVal & 0xFF000000;
					break;
				case 1:
					tmpVal = tmpVal & 0x00FF0000;
					break;
				case 2:
					tmpVal = tmpVal & 0x0000FF00;
					break;
				case 3:
					tmpVal = tmpVal & 0x000000FF;
					break;
			}
			result = result | tmpVal;
		}
		return result;
	}

	public static void main(final String[] args) throws Exception {

		/*byte[] des = FileUtils.readFileToByteArray(new File("D:/ylSVN/银企接口/中行/boc_msg_test/test.des"));
		System.out.println(" des:"+Arrays.toString(des));
		byte[] deflate = FileUtils.readFileToByteArray(new File("D:/ylSVN/银企接口/中行/boc_msg_test/test.deflate"));
		System.out.println(" deflate:"+Arrays.toString(deflate));
		System.out.println(" md516 :"+DigestUtils.md5Hex(deflate));
		byte[] md5 = FileUtils.readFileToByteArray(new File("D:/ylSVN/银企接口/中行/boc_msg_test/test.md5"));
		System.out.println("e md5:"+Arrays.toString(md5));*/
		// byte[] end = FileUtils.readFileToByteArray(new
		// File("D:/ylSVN/银企接口/中行/boc_msg_test/test.end"));
		// System.out.println("e end:"+Arrays.toString(end));
		// byte[] key = new byte[] { 52, 55, 98, 25, 37, 124, 98, 121 };
		/*		String data = FileUtils.readFileToString(new File("D:/ylSVN/银企接口/中行/boc_msg_test/test.xml"));
		
		byte[] result = BocCodeUtils.encode(key, data.getBytes());
		System.out.println("a end:"+Arrays.toString(result));*/

		// Assert.assertArrayEquals(end, result);

		// System.out.print("解码前的报文："+data);
		// System.out.print("解码后的报文："+new String(BocCodeUtils.decode(key,end)));

		final int maxNum = 2000;
		if (maxNum != 0) {// 若最大数为0，则一次发送
			final int times = (int) Math.ceil(4001d / maxNum);
			System.out.println(times);
		}

	}

}
