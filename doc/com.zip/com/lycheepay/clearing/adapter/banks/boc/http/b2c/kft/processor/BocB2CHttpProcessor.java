package com.lycheepay.clearing.adapter.banks.boc.http.b2c.kft.processor;

//package com.lycheepay.clearing.adapter.banks.boc.b2c.kft.processor;
//
//import com.lycheepay.clearing.adapter.banks.boc.b2c.bank.bean.BocB2CParam;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.bank.bean.BocB2CPayBean;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.kft.util.BocHttpKFTUtilService;
//import com.lycheepay.clearing.adapter.common.constant.biz.ChannelTransType;
//import com.lycheepay.clearing.adapter.common.constant.biz.ClearingTransType;
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
//import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
//import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
//import com.lycheepay.clearing.adapter.common.service.biz.PayChannelService;
//import com.lycheepay.clearing.common.constant.ChannelId;
//import com.lycheepay.clearing.util.Log4jUtil;
//
//
///**
// * 
// * 中行银行B2C网银http请求处理器
// * 
// * @author aps-cji
// * @history 2010-2-25
// * 
// */
//public class BocB2CHttpProcessor {
//	private static ChannelParmDao channelParmDao = (ChannelParmDao) SpringContext.getService("channelParmDao");
//	private static PayChannelService payChannelDao = (PayChannelService) SpringContext.getService("payChannelDao");
//	private static BillnoSnService billnoSnService = (BillnoSnService) SpringContext.getService("billnoSnService");
//
//	@Override
//	public HttpReturnParam process(final HttpParam httpParam) throws BizException {
//		String channelId = "";
//		String logMsg = "";
//		Map<String, String> channelParam = new Map<String, String>();
//		channelId = httpParam.getChannelId();
//		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
//		logMsg = "进入" + logPrefix + "渠道Http业务处理。";
//		Log4jUtil.info(logMsg);
//		// 获取渠道对应参数
//		channelParam = (Map) channelParmDao.getChannelParam(httpParam.getChannelId());
//		if (channelParam == null) {
//			throw new BizException(logPrefix + "无法获取渠道参数配置。");
//		}
//		if (httpParam.getChannelTransType().equals(ChannelTransType.Net_Bank_Pay)) {
//			if (httpParam.getTransType().equals(ClearingTransType.Direct_Pay)
//					|| httpParam.getTransType().equals(ClearingTransType.Guarantee_Pay)
//					|| httpParam.getTransType().equals(ClearingTransType.Recharge)) {
//				return b2CPay(logPrefix, httpParam, channelParam);// 支付或担保支付、充值
//			}
//			throw new BizException(logPrefix + " 错误的交易类型:" + httpParam.getChannelTransType() + ":"
//					+ httpParam.getTransType());
//		} else {
//			throw new BizException(logPrefix + " 错误的交易类型:" + httpParam.getChannelTransType() + ":"
//					+ httpParam.getTransType());
//		}
//	}
//
//	private HttpReturnParam b2CPay(final String logPrefix, final HttpParam httpParam,
//			final Map<String, String> channelParam) throws BizException {
//		final String channelId = httpParam.getChannelId();
//		String logMsg = "";
//		logMsg = "进入" + logPrefix + "支付业务处理。";
//		Log4jUtil.info(logMsg);
//		final BocHttpKFTUtilService bocKFTUtil = new BocHttpKFTUtilService();
//		final BocB2CParam bocB2CParam = new BocB2CParam();
//		// 检查参数配置
//		bocKFTUtil.checkChannelParam(logPrefix, ChannelTransType.Net_Bank_Pay + "B2C", channelParam, bocB2CParam);
//		// 创建实体以及获取发送参数
//		final BocB2CPayBean bocB2CPayBean = new BocB2CPayBean();
//		final HttpReturnParam httpReturnParam = new HttpReturnParam();
//		bocKFTUtil.createBocB2COrderSendMsg(logPrefix, httpParam, bocB2CParam, bocB2CPayBean, httpReturnParam);
//		// ObjectUtil.printPropertyString(logPrefix, httpReturnParam);
//		billnoSnService.save(channelId, bocB2CPayBean.getOrderNo(), httpParam);
//		logMsg = logPrefix + "向银行发起支付请求。bankSendSn为：" + bocB2CPayBean.getOrderNo();
//		Log4jUtil.info(logMsg);
//		return httpReturnParam;
//	}
// }
