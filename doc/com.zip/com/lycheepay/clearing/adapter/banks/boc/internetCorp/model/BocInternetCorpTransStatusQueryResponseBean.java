/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-8-22 下午3:36:23
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import org.soofa.core.model.BaseObject;


/**
 * <P>中国银行网上银企交易状态查询响应参数</P>
 * 
 * @author 杜波(15999653650)
 */
public class BocInternetCorpTransStatusQueryResponseBean extends BaseObject {

	private static final long serialVersionUID = 787409719150647766L;
	/**
	 * 报文处理状态代码
	 */
	private String rspcod;
	/**
	 * 报文处理状态信息
	 */
	private String rspmsg;
	/**
	 * 交易处理状态：转账指令ID
	 */
	private String insid;
	/**
	 * 交易处理状态：网银交易流水号
	 */
	private String obssid;
	/**
	 * 交易处理状态代码
	 */
	private String subRspcod;
	/**
	 * 交易处理状态信息
	 */
	private String subRspmsg;

	public String getRspcod() {
		return rspcod;
	}

	public void setRspcod(String rspcod) {
		this.rspcod = rspcod;
	}

	public String getRspmsg() {
		return rspmsg;
	}

	public void setRspmsg(String rspmsg) {
		this.rspmsg = rspmsg;
	}

	public String getInsid() {
		return insid;
	}

	public void setInsid(String insid) {
		this.insid = insid;
	}

	public String getObssid() {
		return obssid;
	}

	public void setObssid(String obssid) {
		this.obssid = obssid;
	}

	public String getSubRspcod() {
		return subRspcod;
	}

	public void setSubRspcod(String subRspcod) {
		this.subRspcod = subRspcod;
	}

	public String getSubRspmsg() {
		return subRspmsg;
	}

	public void setSubRspmsg(String subRspmsg) {
		this.subRspmsg = subRspmsg;
	}

}
