/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-10 上午11:34:48
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.tool;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;


/**
 * <P>DES工具类</P>
 * 
 * @author 张凯锋
 */
public class DES {

	static String DES = "DES/ECB/PKCS5Padding";

	// static String DES = "DES/ECB/NoPadding";

	public static byte[] crypt(final byte key[], final byte data[]) throws Exception {
		final KeySpec ks = new DESKeySpec(key);
		final SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
		final SecretKey ky = kf.generateSecret(ks);
		final Cipher c = Cipher.getInstance(DES);
		c.init(Cipher.ENCRYPT_MODE, ky);
		return c.doFinal(data);
	}

	public static byte[] decrypt(final byte key[], final byte data[]) throws Exception {
		final KeySpec ks = new DESKeySpec(key);
		final SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
		final SecretKey ky = kf.generateSecret(ks);
		final Cipher c = Cipher.getInstance(DES);
		c.init(Cipher.DECRYPT_MODE, ky);
		return c.doFinal(data);
	}
}
