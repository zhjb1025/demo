package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.dom4j.Node;

import com.bocnet.common.security.PKCS7Tool;
import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CNoticeBean;
import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CParam;
import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CPayBean;
import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CQueryOrderDetailRecv;
import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CQueryOrderRecv;
import com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean.BocB2CQueryOrderSend;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * Description: Copyright: Copyright (c) 2011 Company: 雁联
 * 
 * @author aps-cji
 * @version 1.0
 */
public class BocUtil {
	/**
	 * 验签
	 * 
	 * @param rootCertificatePath 根证书路径
	 * @param signature 签名
	 * @param data 明文数据
	 * @param dn 银行签名证书DN，如果为空则不验证DN
	 * @throws BizException
	 */
	private void verify(final String rootCertificatePath, final String signature, final byte[] data, final String dn)
			throws Exception {
		final PKCS7Tool pKCS7Tool = PKCS7Tool.getVerifier(rootCertificatePath);
		pKCS7Tool.verify(signature, data, dn);
	}

	/**
	 * 加密
	 * 
	 * @param data 明文数据
	 * @param bocB2CParam 参数
	 * @return
	 * @throws Exception
	 */
	public String sign(final String data, final BocB2CParam bocB2CParam) throws Exception {
		Log4jUtil.info("对明文数据【" + data + "】进行加密。");
		final PKCS7Tool pkcs7Tool = PKCS7Tool.getSigner(bocB2CParam.getNKeyAdd(), bocB2CParam.getKeyStorePass(),
				bocB2CParam.getKeyPass());
		return pkcs7Tool.sign(data.getBytes());// 签名，返回signature：base64格式的签名结果
	}

	/**
	 * B2C通知结果验签
	 * 
	 * @param bocB2CNoticeBean
	 * @param bocB2CParam
	 * @throws Exception
	 */
	public void noticeVerify(final BocB2CNoticeBean bocB2CNoticeBean, final BocB2CParam bocB2CParam) throws Exception {
		final StringBuffer data = new StringBuffer("");// 明文数据
		data.append(bocB2CNoticeBean.getMerchantNo()).append("|");
		data.append(bocB2CNoticeBean.getOrderNo()).append("|");
		data.append(bocB2CNoticeBean.getOrderSeq()).append("|");
		data.append(bocB2CNoticeBean.getCardTyp()).append("|");
		data.append(bocB2CNoticeBean.getPayTime()).append("|");
		data.append(bocB2CNoticeBean.getOrderStatus()).append("|");
		data.append(bocB2CNoticeBean.getPayAmount());
		this.verify(bocB2CParam.getNKeyAdd(), bocB2CNoticeBean.getSignData(), data.toString().getBytes(),
				bocB2CParam.getDn());
	}

	/**
	 * 对B2C交易数据进行签名
	 * 
	 * @param bocB2CPayBean
	 * @param bocB2CParam
	 * @return
	 * @throws Exception
	 */
	public String getB2CPaySign(final BocB2CPayBean bocB2CPayBean, final BocB2CParam bocB2CParam) throws Exception {
		// 商户订单号|订单时间|订单币种|订单金额|商户号
		// orderNo|orderTime|curCode|orderAmount|merchantNo
		final StringBuffer sbData = new StringBuffer("");// 商户签名数据串格式，各项数据用管道符分隔：
		sbData.append(bocB2CPayBean.getOrderNo()).append("|");// 订单号
		sbData.append(bocB2CPayBean.getOrderTime()).append("|");// 订单时间
		sbData.append(bocB2CPayBean.getCurCode()).append("|");// 币种
		sbData.append(String.format("%1$.2f", bocB2CPayBean.getOrderAmount())).append("|");// 订单金额
		sbData.append(bocB2CPayBean.getMerchantNo());// 商户号
		return this.sign(sbData.toString(), bocB2CParam);
	}

	/**
	 * 根据实体，创建订单发送参数
	 * 
	 * @param BocB2CQueryOrderSend
	 * @param params
	 * @return
	 */
	public Map<String, String> creatBocB2CQueryOrderParam(final BocB2CQueryOrderSend bocB2CQueryOrderSend) {
		final Map<String, String> params = new HashMap<String, String>();
		params.put("merchantNo", bocB2CQueryOrderSend.getMerchantNo());
		params.put("orderNos", bocB2CQueryOrderSend.getOrderNos());
		params.put("signData", bocB2CQueryOrderSend.getSignData());
		return params;
	}

	/**
	 * 将订单查询解析转换为实体
	 * 
	 * @param data
	 * @return
	 * @throws BizException
	 */
	public void parsingQueryOrderXml(final byte[] data, final BocB2CQueryOrderRecv bocB2CQueryOrderRecv)
			throws Exception {
		final String logMsg = "";
		/*		<?xml version="1.0" encoding="utf-8" ?> 
		<res>
		    <header>
		         <merchantNo>104110041000000</merchantNo> 
		    </header>
		    <body>
		         <orderTrans>
		                  <orderNo>TEST0001</orderNo> 
		                  <orderSeq>1001</orderSeq> 
		                  <orderStatus>1</orderStatus> 
		                  <cardTyp>04</cardTyp> 
		                  <payTime>20090605000000</payTime> 
		                  <payAmount>200.12</payAmount> 
		         </orderTrans>
		         <orderTrans>
		                  <orderNo>TEST0009</orderNo> 
		                  <orderSeq>1009</orderSeq> 
		                  <orderStatus>1</orderStatus> 
		                  <cardTyp>04</cardTyp> 
		                  <payTime>20090609121212</payTime> 
		                  <payAmount>360.00</payAmount> 
		         </orderTrans>
		         ……
		         </body>
		*/

		/*	银行返回数据示例（未查询到任何订单信息）：
		 * 	<?xml version="1.0" encoding="utf-8" ?> 
				<res>
				    <header>
				         <merchantNo>104110041000000</merchantNo> 
				    </header>
				    <body/>
				</res>*/

		// 银行返回数据示例（上送信息有误）：
		/*		<?xml version="1.0" encoding="utf-8" ?> 
				<res>
				    <header>
				         <merchantNo>104110041000000</merchantNo> 
				         <exception>merchant is not existed</exception>
				    </header>
				    <body/>
				</res>*/
		// BocB2CQueryOrderRecv bocB2CQueryOrderRecv= new BocB2CQueryOrderRecv();
		final ArrayList<BocB2CQueryOrderDetailRecv> orderTrans = new ArrayList<BocB2CQueryOrderDetailRecv>();
		Dom4jXMLMessage dom4jxml = null;
		dom4jxml = Dom4jXMLMessage.parse(data);
		final Node header = dom4jxml.getNode("/res/header");
		bocB2CQueryOrderRecv.setMerchantNo(dom4jxml.getNodeText(header, "merchantNo"));
		bocB2CQueryOrderRecv.setException(dom4jxml.getNodeText(header, "exception"));
		final List<Node> orderTransNodes = dom4jxml.getNodeList("/res/body/orderTrans");
		// logMsg = "银行返回的订单查询回执中共包含 "+orderTransNodes.size()+" 条明细.开始解析明细数据。";
		Log4jUtil.error(logMsg);

		for (int i = 0; i < orderTransNodes.size(); i++) {
			final BocB2CQueryOrderDetailRecv orderDetail = new BocB2CQueryOrderDetailRecv();
			final Node orderTransNode = orderTransNodes.get(i);
			orderDetail.setOrderNo(dom4jxml.getNodeText(orderTransNode, "orderNo"));
			orderDetail.setOrderSeq(dom4jxml.getNodeText(orderTransNode, "orderSeq"));
			orderDetail.setOrderStatus(dom4jxml.getNodeText(orderTransNode, "orderStatus"));// 订单状态：
																							// 0：未处理
																							// 1：支付
																							// 2：撤销
																							// 3：退货
																							// 4：未明
																							// 5：失败
			orderDetail.setCardTyp(dom4jxml.getNodeText(orderTransNode, "cardTyp"));
			orderDetail.setPayTime(dom4jxml.getNodeText(orderTransNode, "payTime"));
			orderDetail.setPayAmount(dom4jxml.getNodeText(orderTransNode, "payAmount"));
			// logMsg = "第 "+(i+1)+" 条明细为：";
			// logMsg = logMsg+"orderNo："+ orderDetail.getOrderNo();
			// logMsg = logMsg+"orderSeq："+ orderDetail.getOrderSeq();
			// logMsg = logMsg+"orderStatus："+ orderDetail.getOrderStatus();
			// logMsg = logMsg+"cardTyp："+ orderDetail.getCardTyp();
			// logMsg = logMsg+"payTime："+ orderDetail.getPayTime();
			// logMsg = logMsg+"payAmount："+ orderDetail.getPayAmount();
			Log4jUtil.info(logMsg);
			orderTrans.add(orderDetail);
		}
		bocB2CQueryOrderRecv.setOrderTrans(orderTrans);
	}

	/**
	 * 根据实体，创建发送参数
	 * 
	 * @param bocB2CPayBean
	 * @param params
	 * @return
	 */
	public Map<String, String> creatBocB2CPayParam(final BocB2CPayBean bocB2CPayBean) {
		final Map<String, String> params = new HashMap<String, String>();
		params.put("merchantNo", bocB2CPayBean.getMerchantNo());
		params.put("payType", bocB2CPayBean.getPayType());
		params.put("orderNo", bocB2CPayBean.getOrderNo());
		params.put("curCode", bocB2CPayBean.getCurCode());
		params.put("orderAmount", String.format("%1$.2f", bocB2CPayBean.getOrderAmount()));
		params.put("orderTime", bocB2CPayBean.getOrderTime());
		params.put("orderNote", bocB2CPayBean.getOrderNote());
		params.put("orderUrl", bocB2CPayBean.getOrderUrl());
		params.put("signData", bocB2CPayBean.getSignData());
		return params;
	}

	/**
	 * 根据Servlet 收到的通知信息创建实体
	 * 
	 * @param request
	 * @return
	 */
	public BocB2CNoticeBean createBocB2CNoticeBean(final HttpServletRequest request,
			final BocB2CNoticeBean bocB2CNoticeBean) {
		bocB2CNoticeBean.setMerchantNo(request.getParameter("merchantNo"));
		bocB2CNoticeBean.setOrderNo(request.getParameter("orderNo"));
		bocB2CNoticeBean.setBankTranSeq(request.getParameter("bankTranSeq"));
		bocB2CNoticeBean.setCardTyp(request.getParameter("cardTyp"));
		bocB2CNoticeBean.setOrderIP(request.getParameter("orderIp"));
		bocB2CNoticeBean.setOrderRefer(request.getParameter("orderRefer"));
		bocB2CNoticeBean.setOrderSeq(request.getParameter("orderSeq"));
		bocB2CNoticeBean.setOrderStatus(request.getParameter("orderStatus"));
		bocB2CNoticeBean.setPayAmount(request.getParameter("payAmount"));
		bocB2CNoticeBean.setPayTime(request.getParameter("payTime"));
		bocB2CNoticeBean.setReturnActFlag(request.getParameter("returnActFlag"));
		bocB2CNoticeBean.setSignData(request.getParameter("signData"));
		return bocB2CNoticeBean;
	}
}
