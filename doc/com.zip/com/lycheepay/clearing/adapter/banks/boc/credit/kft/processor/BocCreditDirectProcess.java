package com.lycheepay.clearing.adapter.banks.boc.credit.kft.processor;

import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.BillnoSnTradeDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.AutoRealTimeRefund;
import com.lycheepay.clearing.adapter.common.model.biz.ClearingResult;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行信用卡银企直连处理类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午7:54:18
 */
@Service(ClearingAdapterAnnotationName.BOC_CREDIT_DIRECT_PROCESS)
public class BocCreditDirectProcess extends BaseWithoutAuditLogService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_CREDIT_SERVICE)
	private BocCreditService bocCreditService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	private static final String channelName = ChannelIdEnum.BOC_CREDIT_CARD.getDesc();
	private static final String channelId = ChannelIdEnum.BOC_CREDIT_CARD.getCode();

	/**
	 * <p>实时代扣</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午9:23:10
	 */
	public ReturnState directDeduct(final Param param) throws BizException {
		// 单笔实时代扣
		Log4jUtil.info("单笔实时代扣start...");
		final DeductDTO deductDTO = (DeductDTO) param.getBizBean(); // 代扣实体
		if (deductDTO != null && StringUtils.isNotBlank(deductDTO.getInstalments())) {
			return dealInstalmentConsume(param, deductDTO.getInstalments());
		} else {
			return dealConsume(param);
		}
	}

	/**
	 * 
	 * <p>中国银行信用卡分期付款消费</p>
	 * 
	 * @param param
	 * @param instalments
	 * @return
	 * @throws BizException
	 * @author 廖四发（13554889794）
	 */
	private ReturnState dealInstalmentConsume(final Param param,String instalments) throws BizException {
		Log4jUtil.info("渠道分期付款消费开始......");
		// 渠道发送流水
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);
		// 业务处理
		ReturnState returnState = bocCreditService.dealInstalmentConsume(param, bankSendSn);
		// 更新渠道流水对照表(billno_sn)
		HashMap<String, Object> map = (HashMap<String, Object>) returnState.getReturnObj();
		final String batchNo = (String) map.get("batchNo");
		final String authorizationCode = (String) map.get("authorizationCode");
		final String instalmentsID = (String) map.get("instalmentsID");
		Log4jUtil.info("当前消费的批次号为：" + batchNo);
		Log4jUtil.info("当前消费的返回的授权码(38域)为：" + authorizationCode);
		// 6位批次号+6位授权码+4位分期ID+2位分期数
		final String batchAndAuthorization = batchNo + authorizationCode + instalmentsID + instalments;
		Log4jUtil.info("returnState.getBillnosnSeq() = " + returnState.getBillnosnSeq());
		Log4jUtil.info("returnState.getSn() = " + returnState.getSn());
		billnoSnService.updateBillnoSn(returnState, returnState.getBillnosnSeq(), batchAndAuthorization, (Date) map.get("recvTime"));
		Log4jUtil.info("returnState.getChannelCode() = " + returnState.getChannelCode());
		Log4jUtil.info("渠道实时代扣结束......");
		return returnState;
	}

	/**
	 * <p>中国银行信用卡消费</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午9:23:20
	 */
	private ReturnState dealConsume(final Param param) throws BizException {
		Log4jUtil.info("渠道实时代扣开始......");
		// 渠道发送流水
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		// 写渠道流水对照表(billno_sn)
		billnoSnService.saveBillnoSn(bankSendSn, param);
		// 业务处理
		ReturnState returnState = bocCreditService.dealConsume(param, bankSendSn);
		// 更新渠道流水对照表(billno_sn)
		HashMap<String, Object> map = (HashMap<String, Object>) returnState.getReturnObj();
		final String batchNo = (String) map.get("batchNo");
		final String authorizationCode = (String) map.get("authorizationCode");
		Log4jUtil.info("当前消费的批次号为：" + batchNo);
		Log4jUtil.info("当前消费的返回的授权码(38域)为：" + authorizationCode);
		Log4jUtil.info("returnState.getBillnosnSeq() = " + returnState.getBillnosnSeq());
		Log4jUtil.info("returnState.getSn() = " + returnState.getSn());
		billnoSnService.updateBillnoSn(returnState, returnState.getBillnosnSeq(), batchNo + authorizationCode, (Date) map.get("recvTime"));
		Log4jUtil.info("returnState.getChannelCode() = " + returnState.getChannelCode());
		Log4jUtil.info("渠道实时代扣结束......");
		return returnState;
	}

	/**
	 * 处理结帐与签到
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public void dealSignIn(final String channelId) throws BizException {
		// 渠道发送流水
		String bankSendSn = sequenceManagerService.getBocCreditSN();
		// 结算
		Log4jUtil.info("中行信用卡渠道结帐开始..........");
		bocCreditService.check(bankSendSn);
		Log4jUtil.info("中行信用卡渠道结帐结束..........");
		bankSendSn = sequenceManagerService.getBocCreditSN();
		// 签到
		Log4jUtil.info("中行信用卡渠道签到开始..........");
		ReturnState signProcess = bocCreditService.signProcess(channelId, bankSendSn);
		if (signProcess == null)
			bocCreditService.signProcess(channelId, bankSendSn);// 第一次签到可能失败，做第二次签到
		Log4jUtil.info("中行信用卡渠道签到结束..........");

	}

	/**
	 * 处理结帐与签到
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 */
	public void dealInstalmentSignIn(final String channelId) throws BizException {
		// 渠道发送流水
		String bankSendSn = sequenceManagerService.getBocCreditSN();
		// 分期付款专用结算
		Log4jUtil.info("中行信用卡分期付款渠道结帐开始..........");
		bocCreditService.instalmentCheck(bankSendSn);
		Log4jUtil.info("中行信用卡分期付款渠道结帐结束..........");

		// 分期付款专用签到
		bankSendSn = sequenceManagerService.getBocCreditSN();
		Log4jUtil.info("中行信用卡分期付款渠道签到开始..........");
		ReturnState instalmentSignProcess = bocCreditService.instalmentSignProcess(channelId, bankSendSn);
		if (instalmentSignProcess == null)
			bocCreditService.instalmentSignProcess(channelId, bankSendSn);// 第一次签到可能失败，做第二次签到
		Log4jUtil.info("中行信用卡分期付款渠道签到结束..........");
	}

	/**
	 * <p>自适应退款</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-6-19 下午9:25:30
	 */
	public ReturnState autoRealRefund(final Param param) throws BizException {
		AutoRealTimeRefund autoRealTimeRefund = channelTransUtilService.getAutoRealTimeRefund(param);
		AssertUtils.notNull(autoRealTimeRefund.getOrgPaySn(), TransReturnCode.code_9108, "原交易流水不能为空");
		BillnoSn billnoSn = billnoSnService.getBySn(autoRealTimeRefund.getOrgPaySn());
		if (StringUtils.indexOf(billnoSn.getCreditbatchno(), "I") == -1) {// 不是分期
			return this.autoRealRefundConsumer(param, autoRealTimeRefund, billnoSn);
		} else {
			return this.autoRealRefundInstalmentConsume(param, autoRealTimeRefund, billnoSn);
		}
	}


	/**
	 * <p>普通消费交易自适应退款</p>
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 * @param billnoSn
	 * @param autoRealTimeRefund
	 */
	public ReturnState autoRealRefundConsumer(final Param param, AutoRealTimeRefund autoRealTimeRefund,
			BillnoSn billnoSn) throws BizException {
		Log4jUtil.info("进入消费自适应退款处理");
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		billnoSnService.saveBillnoSn(bankSendSn, param); // bankSendSn-渠道发送银行流水

		ReturnState returnState = bocCreditService.autoRealRefund(param, bankSendSn, autoRealTimeRefund, billnoSn);

		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);// bankSendSn-渠道发送银行流水
																		// returnState--各自组的返回给基础平台的
		Log4jUtil.info("消费自适应退款结束......");
		return returnState;
	}

	/**
	 * <p>分期消费退货</p>
	 * 
	 * @param param
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 * @param billnoSn
	 * @param autoRealTimeRefund
	 */
	public ReturnState autoRealRefundInstalmentConsume(final Param param, AutoRealTimeRefund autoRealTimeRefund,
			BillnoSn billnoSn) throws BizException {
		Log4jUtil.info("进入分期消费撤销处理");
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		billnoSnService.saveBillnoSn(bankSendSn, param); // bankSendSn-渠道发送银行流水

		ReturnState returnState = bocCreditService.autoRealRefundInstalment(param, bankSendSn, autoRealTimeRefund,
				billnoSn);

		billnoSnService.updateBillnoSn(param, returnState, bankSendSn);// bankSendSn-渠道发送银行流水
																		// returnState--各自组的返回给基础平台的
		Log4jUtil.info("分期消费撤销处理......");
		return returnState;
	}

	/**
	 * <p>中国银行信用卡预授权处理(此方法仅新建渠道流水信息、生成渠道流水号、调用预授权、更新渠道流水信息,其实调用步骤可写在本类中)</p>
	 * 
	 * @param preAuth 信用卡预授权交易请求信息
	 * @return 返回与银行交互后通讯信息
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-8-28 下午5:34:38
	 */
	public ClearingResult preAuth(PreAuthDTO preAuth) throws BizException {
		Log4jUtil.info("中国银行渠道预授权开始......");
		// 渠道发送流水
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		BillnoSnTradeDTO dto = new BillnoSnTradeDTO();
		dto.setBankCardType(BankCardType.CREDIT_CARD);
		dto.setBankSendSn(bankSendSn);
		dto.setChannelId(channelId);
		// 新建渠道流水信息
		BillnoSn billnoSn = billnoSnService.savePreAuth(dto, preAuth);
		// 调用预授权
		ClearingResult result = bocCreditService.preAuth(billnoSn, dto, preAuth);
		final String batchAndAuthorization = result.getCreditbatchno() + preAuth.getCvv2();
		result.setCreditbatchno(batchAndAuthorization);
		// 更新渠道流水表
		billnoSnService.updateBillnoSnByClearingResult(billnoSn, result);
		Log4jUtil.info("returnState.getChannelCode() = " + result.getChannelResponseCode());
		Log4jUtil.info("中国银行渠道预授权结束......");
		return result;
	}

}
