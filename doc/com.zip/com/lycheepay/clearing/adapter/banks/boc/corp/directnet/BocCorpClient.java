/*******************************************************************************
 * Project Key : CPP
 * Create on 2012-8-2 下午7:27:54
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.directnet;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Map;

import org.soofa.remoting.ChannelConfig;
import org.soofa.remoting.ChannelState;
import org.soofa.remoting.Client;
import org.soofa.remoting.SoofaRemotingException;
import org.soofa.remoting.netty.NettyClient;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterClientCheckedException;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.BankInteractiveParam;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.BankInteractiveParamProcess;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.ChannelFactoryDelegate;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.ChannelHandlerDelegate;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.ClientFlushService;
import com.lycheepay.clearing.common.constant.ChannelClientErrorCode.ChannelClientErrorCodeEnum;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企直连与银行交互Client</P>
 * 
 * @author 邱林 Leon.Qiu 2012-8-2 下午7:27:54
 */
@Service(ClearingAdapterAnnotationName.BOC_CORP_CLIENT)
public class BocCorpClient extends BaseWithoutAuditLogService implements DisposableBean, InitializingBean,
		ClientFlushService {

	@Autowired
	private BankInteractiveParamProcess bankInteractiveParamProcess;

	// 有锁进行控制client初始化有修改
	private Client client = null;

	// 因ChannelFactory的关闭有DirectMemory泄露，采用静态化规避
	private final static ChannelFactoryDelegate channelFactory = new ChannelFactoryDelegate();

	/**
	 * <p>获取连接并且返回与银行交互的请求结果</p>
	 * 
	 * @param sendInfo 与银行交互请求的XML报文
	 * @param resultClass 请求返回的结果class
	 * @return 与银行交互处理过的对象
	 * @author 邱林 Leon.Qiu 2012-8-6 下午4:21:43
	 * @throws ClearingAdapterClientCheckedException
	 */
	public final <T> T requestLink(final Object sendInfo, final Class<T> resultClass)
			throws ClearingAdapterClientCheckedException {
		// 用于构建中行银企特有的请求连接
		String requestInfo = "";
		try {
			final Method method = sendInfo.getClass().getMethod("getXML");
			requestInfo = (String) method.invoke(sendInfo);
			Log4jUtil.info("生成请求银行报文信息：" + requestInfo);
		} catch (final Exception e1) {
			throw new ClearingAdapterClientCheckedException(ChannelClientErrorCodeEnum.CLIENT_BEFORE_CONNECT.getCode(),
					e1.getMessage(), ChannelClientErrorCodeEnum.CLIENT_UNSEND.getCode());
		}
		// 初始化一次client,参数不做修改的情况下从内存中获取client
		if (client == null) {
			// 加锁
			synchronized (BocCorpClient.class) {
				// 防止同时征用锁后处理
				if (client == null) {
					// 新建client并且初始化到内存中
					initClient();
				}
			}
		}
		byte[] result = null;
		try {
			result = client.request(requestInfo, false, byte[].class);
		} catch (final SoofaRemotingException e) {
			// 这里的异常必须区分几个状态
			// 连接上状态(isConnected)
			// 发送到银行(isSended)
			// 银行响应回执（接收到回执isReceived）
			// 之后关闭连接(isDisconnected)

			// // 初始状态,表示等待连接
			// waitForConnect,
			// // 表示已经与远端地址建立了连接
			// connected,
			// // 表示客户端开始向服务器端发送请求,但是还没发送完毕
			// // 此时如果出现异常,不确定是否能重新发送请求,除非服务器端在业务逻辑上可以处理重复的请求
			// sendRequest,
			// // 表示客户端向服务器端发送请求已经完成.
			// // 此时如果出现异常,将不能再重新发送,以免服务器端重复处理,除非服务器端在业务逻辑上可以处理重复的请求
			// sendRequestCompleted,
			// // 表示已经成功接受完对方发来的信息(不区分客户端还是服务器端)
			// // 在客户端表示已经接受完服务器端的响应,但是还没进行业务逻辑处理
			// // 在服务器端表示已经接受完客户端的请求,但是还没进行业务逻辑处理
			// messageReceived,
			// // 表示已经与远端地址断开了连接,任何操作都不能再进行
			// disconnected
			log.error("调用中行银行请求失败:【ErrorCode】 :{}.【Message】 :{}" + e.getMessage() + ".", e.getErrorCode(), e);
			final ChannelState channelState = e.getChannelState();
			if (ChannelState.waitForConnect.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_CONNECT_FAILED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_UNSEND.getCode());
			} else if (ChannelState.connected.equals(channelState) || ChannelState.sendRequest.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_BEFORE_SENDED_OUT.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_UNSEND.getCode());
			}
			// 以下状态都已经发送到银行
			else if (ChannelState.sendRequestCompleted.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_SENDED_NO_REVEIVED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
			} else if (ChannelState.messageReceived.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_RECEIVED_UNDISCONNECTED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
			} else if (ChannelState.disconnected.equals(channelState)) {
				throw new ClearingAdapterClientCheckedException(
						ChannelClientErrorCodeEnum.CLIENT_RECEIVED_UNDISCONNECTED.getCode(), e.getMessage(),
						ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
			}
		}
		T parseResult = null;
		try {
			final Constructor<T> constructor = resultClass.getConstructor(byte[].class);
			parseResult = constructor.newInstance(result);
			if (log.isDebugEnabled()) {
				log.debug("调用中行银行请求结果如下:" + parseResult.toString());
			}
		} catch (final Exception e2) {
			throw new ClearingAdapterClientCheckedException(
					ChannelClientErrorCodeEnum.CLIENT_AFTER_DISCONNECT.getCode(), e2.getMessage(),
					ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode());
		}
		return parseResult;
	}

	/**
	 * <p>初始化Client,分开控制Client有利于日后拆分银行划分包时便于管理</p>
	 * 
	 * @return 初始化好的Client
	 * @author 邱林 Leon.Qiu 2012-8-6 下午4:19:38
	 */
	public void initClient() {
		// 不能写把所有银行配置和coder在一起，不利于日后拆银行处理，必须反向调用各银行处理类,从银行处理类中获取参数,再由银行调用BankClinet初始化到map中
		// 内部映射的decoder和encoder不需要再次增加缓存及查询方法,由此方法进行控制
		final Map<String, String> regeisterBeanId = bankInteractiveParamProcess.regeisterBeanId(
				ChannelIdEnum.BOC_CORP.getCode(), ClearingAdapterAnnotationName.BOC_CORP_CLIENT);
		final BankInteractiveParam bip = getBankInterativeParam(regeisterBeanId);
		final ChannelConfig config = createChannelConfig(bip);
		client = new NettyClient(config, channelFactory, new BocCorpEncoder(bip), new BocCorpDecoder(bip),
				new ChannelHandlerDelegate());
	}

	/**
	 * <p>构建通道配置并返回此信息</p>
	 * 
	 * @param bip 与银行交互的配置信息
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:07:41
	 */
	private ChannelConfig createChannelConfig(final BankInteractiveParam bip) {
		final ChannelConfig config = new ChannelConfig();
		config.setPort(bip.getPort());
		config.setServerHostName(bip.getIp());
		config.setReadChannelBufferSize(bip.getReadChannelBufferSize() != 0 ? bip.getReadChannelBufferSize() : 8192);
		config.setConnectTimeoutMillis(bip.getConnectTimeoutMillis() != 0 ? bip.getConnectTimeoutMillis() : 20000);
		config.setWriteTimeoutMillis(bip.getWriteTimeoutMillis() != 0 ? bip.getWriteTimeoutMillis() : 10000);
		config.setReceiveTimeoutMillis(bip.getReceiveTimeoutMillis() != 0 ? bip.getReceiveTimeoutMillis() : 15000);
		return config;
	}

	/**
	 * <p>构建与银行交互的配置并返回此信息</p>
	 * 
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:14:49
	 */
	private BankInteractiveParam getBankInterativeParam(final Map<String, String> map) {
		final BankInteractiveParam param = new BankInteractiveParam();
		final String ip = map.get("100001");// Ip地址
		final String port = map.get("100002");// Port端口
		final String des = map.get("100003");// DES密码
		final String sysCode = map.get("100004");// 系统返回码
		param.setIp(ip);
		param.setPort(Integer.valueOf(port));
		param.setCheckCode(sysCode);
		param.setDes(des);
		return param;
	}

	/**
	 * @see org.springframework.beans.factory.DisposableBean#destroy()
	 * @author 邱林 Leon.Qiu 2012-8-3 下午4:26:44
	 */
	@Override
	public void destroy() throws Exception {
		if (client != null) {
			client.close();
		}
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:15:31
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		initClient();
	}

	/**
	 * @see com.leon.remote.consumer.test.common.service.biz.net.ClientFlushService#flushClient()
	 * @author 邱林 Leon.Qiu 2012-8-7 下午3:37:41
	 */
	@Override
	public void flushClient() {
		synchronized (BocCorpClient.class) {
			// 防止同时征用加锁处理
			initClient();
		}
	}

}
