package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

public class BocB2CQueryOrderSend {
	private String merchantNo;
	private String orderNos;
	private String signData;

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(final String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getOrderNos() {
		return orderNos;
	}

	public void setOrderNos(final String orderNos) {
		this.orderNos = orderNos;
	}

	public String getSignData() {
		return signData;
	}

	public void setSignData(final String signData) {
		this.signData = signData;
	}

}
