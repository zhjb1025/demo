/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.internetCorp.constants.BocInternetCorpMessageConstants;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayQueryRequestBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInRequestBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpTransStatusQueryRequestBean;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelBatch;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 
 * <P>
 * 中国银行网上银企报文转换
 * </P>
 * 
 * @author #{杜波(15999653650)}
 */
@Service
public class BocInternetCorpRequestMessagesConverter {
	/**
	 * 
	 * <p>中国银行网上银企签到请求参数转换XML报文(b2e0001)</p>
	 * @param bocCreditSignInRequestBean
	 * @return
	 * @throws BizException
	 * @author #{杜波(15999653650)}
	 */
	public String getBocSignInRequestXml(BocInternetCorpSignInRequestBean bocCreditSignInRequestBean)
			throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			//创建中国银行网上银企签到XML报文，设置报文编码方式
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("bocb2e");
			dom4jxml.setEncoding("UTF-8");
			
			//声明报文根目录元素属性
			Element rootElement = dom4jxml.getRoot();
			rootElement.addAttribute("version", "120");
			rootElement.addAttribute("security", "true");
			rootElement.addAttribute("lang", "chs");
			
			//创建报文head部分,消息头
			Element headElement = dom4jxml.addNode(rootElement, "head", "");
			dom4jxml.addNode(headElement, "termid", bocCreditSignInRequestBean.getTermId());
			dom4jxml.addNode(headElement, "trnid",  bocCreditSignInRequestBean.getTrnId());
			dom4jxml.addNode(headElement, "custid", bocCreditSignInRequestBean.getCustId());
			dom4jxml.addNode(headElement, "cusopr", bocCreditSignInRequestBean.getCusOpr());
			dom4jxml.addNode(headElement, "trncod", BocInternetCorpMessageConstants.Sign_In);
			
			//创建报文trans部分，消息体
			Element transElement = dom4jxml.addNode(rootElement, "trans", "");
			Element trnElement = dom4jxml.addNode(transElement, "trn-b2e0001-rq", "");
			Element b2e0001RqElement = dom4jxml.addNode(trnElement, "b2e0001-rq", "");
			dom4jxml.addNode(b2e0001RqElement, "custdt",   bocCreditSignInRequestBean.getCustDt());
			dom4jxml.addNode(b2e0001RqElement, "oprpwd",   bocCreditSignInRequestBean.getOprPwd());
			Log4jUtil.info(dom4jxml);
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "中国银行网上银企签到请求参数转换XML报文出错==" + e.getMessage());
		}
		return dom4jxml.toString();
	}
    /**
     * 
     * <p>中国银行网上银企快捷代付请求参数转换XML报文(b2e0078)</p>
     * @param list
     * @param bankaccountBalance
     * @param channelBatch
     * @param channelParamMap
     * @return
     * @throws BizException
     * @author #{杜波(15999653650)}
     */
	public String getBocInternetCorpQuickPayRequestXml(List<BillnoSn> list,BankaccountBalance bankaccountBalance,
			ChannelBatch channelBatch, Map<String, String> channelParamMap) throws BizException {
		if(list==null||list.size()<=0) return null;
		//创建中国银行网上银企快捷代付XML报文，设置报文编码方式
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("bocb2e");
			dom4jxml.setEncoding("UTF-8");
			//声明报文根目录元素属性
			Element rootElement = dom4jxml.getRoot();
			rootElement.addAttribute("version", "120");
			rootElement.addAttribute("security", "true");
			rootElement.addAttribute("lang", "chs");
			//创建报文head部分,消息头
			Element headElement = dom4jxml.addNode(rootElement, "head", "");
			dom4jxml.addNode(headElement, "termid", channelParamMap.get("100001")); //termId
			dom4jxml.addNode(headElement, "trnid",  channelParamMap.get("trnId"));
			dom4jxml.addNode(headElement, "custid", channelParamMap.get("100002")); //custId
			dom4jxml.addNode(headElement, "cusopr", channelParamMap.get("100003")); //cusOpr
			dom4jxml.addNode(headElement, "trncod", BocInternetCorpMessageConstants.Batch_Pay); //trnCod
			//测试时可不用token
			dom4jxml.addNode(headElement, "token", channelParamMap.get("100007"));
			//创建报文trans部分，消息体
			Element transElement = dom4jxml.addNode(rootElement, "trans", "");
			Element trnElement = dom4jxml.addNode(transElement, "trn-b2e0078-rq", "");
			Element b2e0078RqElement = dom4jxml.addNode(trnElement, "b2e0078-rq", "");
			dom4jxml.addNode(b2e0078RqElement, "insid", String.valueOf(System.currentTimeMillis()));
			//付款人账户
			Element fractnElement = dom4jxml.addNode(b2e0078RqElement, "fractn", "");
			dom4jxml.addNode(fractnElement, "fribkn", channelParamMap.get("100011"));
			dom4jxml.addNode(fractnElement, "actacn", bankaccountBalance.getAccountNo());
			dom4jxml.addNode(fractnElement, "actnam", bankaccountBalance.getAccountName());
			//其他信息
			dom4jxml.addNode(b2e0078RqElement, "pybcur", "CNY");
			dom4jxml.addNode(b2e0078RqElement, "pybamt", String.valueOf(channelBatch.getTotalamount()));
			dom4jxml.addNode(b2e0078RqElement, "pybnum", String.valueOf(channelBatch.getTotalnum()));
			dom4jxml.addNode(b2e0078RqElement, "crdtyp", BocInternetCorpMessageConstants.Self_Bank);
			dom4jxml.addNode(b2e0078RqElement, "furinfo",BocInternetCorpMessageConstants.Batch_Refund_Furinfo);
			dom4jxml.addNode(b2e0078RqElement, "useinf", "");
			dom4jxml.addNode(b2e0078RqElement, "trfdate", new SimpleDateFormat("yyyyMMdd").format(new Date()));
			if (list != null && list.size() > 0) {
				for (BillnoSn billnoSn : list) {
					//笔明细内容(1..n)
					Element detailElement = dom4jxml.addNode(b2e0078RqElement, "detail", "");
					//中行信用卡联行号可以固定为10（总行），已与中行方面确认 2012/08/27
					dom4jxml.addNode(detailElement, "toibkn", "10");                                                      
					dom4jxml.addNode(detailElement, "tobank", billnoSn.getOtherbankaddrno());
					dom4jxml.addNode(detailElement, "toactn", billnoSn.getOtheracctno());
					dom4jxml.addNode(detailElement, "pydcur", "CNY");
					dom4jxml.addNode(detailElement, "pydamt", String.valueOf(billnoSn.getAmount()));
					dom4jxml.addNode(detailElement, "toname", billnoSn.getOtheracctname());
					dom4jxml.addNode(detailElement, "toidtp", "");
					dom4jxml.addNode(detailElement, "toidet", "");
					dom4jxml.addNode(detailElement, "furinfo",billnoSn.getBillnosnSeq());
					dom4jxml.addNode(detailElement, "reserve1", "");
					dom4jxml.addNode(detailElement, "reserve2", "");
					dom4jxml.addNode(detailElement, "reserve3", "");
					dom4jxml.addNode(detailElement, "reserve4", "");
				}
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "中国银行网上银企快捷代付请求参数转换XML报文出错==" + e.getMessage());
		}
		return dom4jxml.toString();
	}
	/**
	 * 
	 * <p>中国银行网上银企快捷代付查询请求参数转换XML报文(b2e0079)</p>
	 * @param queryRequestBean
	 * @param channelParamMap
	 * @return
	 * @throws BizException
	 * @author #{杜波(15999653650)}
	 */
	public String getBocInternetCorpQuickPayQueryReqestXml(BocInternetCorpQuickPayQueryRequestBean queryRequestBean,
			Map<String, String> channelParamMap) throws BizException {
		//创建中国银行网上银企快捷代付XML报文，设置报文编码方式
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("bocb2e");
			dom4jxml.setEncoding("UTF-8");
			//声明报文根目录元素属性
			Element rootElement = dom4jxml.getRoot();
			rootElement.addAttribute("version", "120");
			rootElement.addAttribute("security", "true");
			rootElement.addAttribute("lang", "chs");
			//创建报文head部分,消息头
			Element headElement = dom4jxml.addNode(rootElement, "head", "");
			dom4jxml.addNode(headElement, "termid", channelParamMap.get("100001"));
			dom4jxml.addNode(headElement, "trnid",  channelParamMap.get("trnId"));
			dom4jxml.addNode(headElement, "custid", channelParamMap.get("100002"));
			dom4jxml.addNode(headElement, "cusopr", channelParamMap.get("100003"));
			dom4jxml.addNode(headElement, "trncod", BocInternetCorpMessageConstants.Batch_Pay_Query);
			//测试时可不用token
			dom4jxml.addNode(headElement, "token", channelParamMap.get("100007"));
			//创建报文trans部分，消息体
			Element transElement = dom4jxml.addNode(rootElement, "trans", "");
			Element trnElement = dom4jxml.addNode(transElement, "trn-b2e0079-rq", "");
			Element b2e0079RqElement = dom4jxml.addNode(trnElement, "b2e0079-rq", "");
			dom4jxml.addNode(b2e0079RqElement, "insid",  queryRequestBean.getInsid());
			dom4jxml.addNode(b2e0079RqElement, "obssid", queryRequestBean.getObssid());
			dom4jxml.addNode(b2e0079RqElement, "begnum", queryRequestBean.getBegnum());
			dom4jxml.addNode(b2e0079RqElement, "recnum", queryRequestBean.getRecnum());
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "中国银行网上银企快捷代付查询请求参数转换XML报文出错==" + e.getMessage());
		}
		return dom4jxml.toString();
	}
	/**
	 * 
	 * <p>中国银行网上银企交易状态查询请求参数转换XML报文(b2e0007)</p>
	 * @param transStatusQueryRequestBean
	 * @param channelParamMap
	 * @return
	 * @throws ClearingAdapterBizCheckedException
	 * @author 杜波(15999653650)
	 */
	public String getBocInternetCorpTransStatusQueryReqestXml(
			BocInternetCorpTransStatusQueryRequestBean transStatusQueryRequestBean, Map<String, String> channelParamMap)
			throws BizException {
		//创建中国银行网上银企交易状态查询XML报文，设置报文编码方式
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("bocb2e");
			dom4jxml.setEncoding("UTF-8");
			//声明报文根目录元素属性
			Element rootElement = dom4jxml.getRoot();
			rootElement.addAttribute("version", "120");
			rootElement.addAttribute("security", "true");
			rootElement.addAttribute("lang", "chs");
			//创建报文head部分,消息头
			Element headElement = dom4jxml.addNode(rootElement, "head", "");
			dom4jxml.addNode(headElement, "termid", channelParamMap.get("100001"));
			dom4jxml.addNode(headElement, "trnid",  channelParamMap.get("trnId"));
			dom4jxml.addNode(headElement, "custid", channelParamMap.get("100002"));
			dom4jxml.addNode(headElement, "cusopr", channelParamMap.get("100003"));
			dom4jxml.addNode(headElement, "trncod", BocInternetCorpMessageConstants.BATCH_STATUS_QUERY);
			//测试时可不用token
			dom4jxml.addNode(headElement, "token", channelParamMap.get("100007"));
			//创建报文trans部分，消息体
			Element transElement = dom4jxml.addNode(rootElement, "trans", "");
			Element trnElement = dom4jxml.addNode(transElement, "trn-b2e0007-rq", "");
			Element b2e0079RqElement = dom4jxml.addNode(trnElement, "b2e0007-rq", "");
			dom4jxml.addNode(b2e0079RqElement, "insid",  transStatusQueryRequestBean.getInsid());
			dom4jxml.addNode(b2e0079RqElement, "obssid", transStatusQueryRequestBean.getObssid());
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9108, "中国银行网上银企交易状态查询请求参数转换XML报文出错==" + e.getMessage());
		}
		return dom4jxml.toString();
	}
	
}
