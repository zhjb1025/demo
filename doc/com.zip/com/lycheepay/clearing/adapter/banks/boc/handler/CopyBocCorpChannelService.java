/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午2:04:53
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.handler;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.boc.common.service.BocModelToBillNoSnService;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.A001Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.A001Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B001Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B001Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B002Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B002Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B003Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.B003Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C001Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C001Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C002Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C002Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C003Request;
import com.lycheepay.clearing.adapter.banks.boc.corp.bean.C003Response;
import com.lycheepay.clearing.adapter.banks.boc.corp.directnet.BocCorpClient;
import com.lycheepay.clearing.adapter.banks.boc.corp.tool.BocCorpBatchService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterClientCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.constant.ChannelClientErrorCode;
import com.lycheepay.clearing.common.constant.ChannelClientErrorCode.ChannelClientErrorCodeEnum;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企清算服务入口类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午5:38:10
 */
// @Service(ClearingAdapterAnnotationName.BOC_CORP_CHANNEL_SERVICE)
public class CopyBocCorpChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_CORP_CLIENT)
	public BocCorpClient bocCorpClient;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_MODEL_TO_BILLNOSN_SERVICE)
	private BocModelToBillNoSnService bocModelToBillNoSnService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_CORP_BATCH_SERVICE)
	private BocCorpBatchService bocCorpBatchService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_BATCH_SERVICE)
	private ChannelBatchService channelBatchService;

	private final String success = "R0000";
	private static String channelId = ChannelIdEnum.BOC_CORP.getCode();

	/**
	 * <p>链路探测，中银独有的，看和中银通讯是否正常</p>
	 * 
	 * @return 通畅 S 异常 异常信息
	 * @author 张凯锋
	 * @throws BizException
	 */
	public String detectLine() throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info("链路探测开始。。");
		final String testString = "测试链路是否通畅";
		// 创建请求报文
		final A001Request a001Request = new A001Request(testString);
		// 设置请求头信息
		a001Request.setSysCode(sysCode);
		a001Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// a001Request.setMsgType("A001");// 中行代码，代表链路探测
		a001Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		A001Response result = null;
		try {
			result = bocCorpClient.requestLink(a001Request, A001Response.class);
		} catch (final Exception e) {
			Log4jUtil.error("发送接收链路探测报文处理出错：" + e.getMessage());
			if (e instanceof ClearingAdapterBizCheckedException) {
				return "F：" + ChannelClientErrorCode.getNameByValue(((ClearingAdapterBizCheckedException) e).getCode());
			} else {
				return "F：" + e.getMessage();
			}
		}
		if (success.equals(result.getResultCode()) && testString.equals(result.getEhlo())) {
			return "S：" + result.getResultDesc();
		} else {
			return "F：" + result.getResultDesc();
		}
	}

	/**
	 * PS.实时代扣
	 * 
	 * @see com.lycheepay.settlecore.app.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.clearing.common.dto.trade.DeductDTO.common.dto.DirectDeductChannelDTO)
	 * @author 张凯锋
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) throws ClearingAdapterBizCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info(deductDTO);
		// 保存渠道流水信息
		final B001Request b001Request = new B001Request(sequenceManagerService.getCorpBocSN(),
				deductDTO.getBankCardNo(), deductDTO.getCardHolderName(), deductDTO.getAmount()
						.setScale(2, RoundingMode.HALF_UP).toString());
		BillnoSn b001 = bocModelToBillNoSnService.b001(b001Request.getTransNo(), deductDTO, channelId);
		String billnosnSeq = sequenceManagerService.getBillnoSnSeq();
		b001.setBillnosnSeq(billnosnSeq);
		billnoSnService.save(b001);
		// 设置请求头信息
		b001Request.setSysCode(sysCode);
		b001Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		b001Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		// 生成报文
		Log4jUtil.info("生成单笔代收发送信息：" + b001Request.toString());
		B001Response b001Response = null;
		try {
			b001Response = bocCorpClient.requestLink(b001Request, B001Response.class);
		} catch (final Exception e) {
			if (e instanceof ClearingAdapterClientCheckedException) {
				ClearingAdapterClientCheckedException ce = (ClearingAdapterClientCheckedException) e;
				Log4jUtil.error("发送接收单笔代收报文处理出错BizException e.getMessage()：" + e.getMessage() + ", e.getErrorCode()："
						+ ce.getCode() + "[" + ChannelClientErrorCode.getNameByValue(ce.getCode() + "]"));
				try {
					if (ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode().equals(ce.getStage())) {
						Log4jUtil.error("清算平台已向银行渠道发送完整信息后出现异常，开始调用冲正");
						Thread.sleep(5000);
						final B003Response sendReverse = sendReverse(b001Request.getTransNo(),
								b001Request.getAccountNo(), b001Request.getMoney());
						Log4jUtil.error("冲正结果, code:" + sendReverse.getResultCode() + ", desc: "
								+ sendReverse.getResultDesc());
					}
				} catch (final Exception e1) {
					Log4jUtil.error("b001Request冲正失败:" + e.getMessage());
					e1.printStackTrace();
				}
			} else {
				Log4jUtil.error("发送接收单笔代收报文处理出错：" + e.getMessage());
				return makeExceptionReturn("发送接收单笔代收报文处理出错：" + e.getMessage());
			}
			return makeExceptionReturn(e.getMessage());
		}
		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		if (!"R9000".equals(b001Response.getResultCode())) {// 未出现银行内部异常
			// 创建返回结果
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
					b001Response.getResultCode()));
			if (channelRtncode != null) {
				channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
				channelResultDTO.setChannelResponseMsg((success.equals(b001Response.getResultCode()) ? ""
						: channelRtncode.getChannelReamrk() + ", ") + b001Response.getResultDesc());
			} else {
				channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码
				// -- 交易异常
				channelResultDTO.setChannelResponseMsg(b001Response.getResultDesc());
			}
			channelResultDTO.setSettlementDate(StringUtils.replace(b001Response.getAccountDate(), "-", ""));
			// 更新渠道流水信息
			billnoSnService.update(billnosnSeq, b001Response.getResultCode(), b001Response.getResultDesc(),
					b001Response.getActualDeductAmt(), channelResultDTO.getChannelResponseCode());
		} else {// R9000 银行内部异常 由于服务器异常,不能明确该笔交易的准确结果,需要发起方继续发起查询报文或者重发相同原交易
			Log4jUtil.info("代扣返回ResultCode == R9000，调用单笔查询接口查询处理结果");
			try {
				final C002Response c002Response = this.singleQuery(b001Request.getTransNo());
				if (success.equals(c002Response.getResultCode())) {// 如果查询成功，则根据交易状态来判断交易是否成功
					Log4jUtil.info("代扣返回ResultCode == R9000，调用单笔查询接口查询处理结果" + c002Response.getResultCode());
					final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(
							channelId, c002Response.getTransStatus()));
					if (channelRtncode != null) {
						channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
						channelResultDTO.setChannelResponseMsg((success.equals(c002Response.getTransStatus()) ? ""
								: channelRtncode.getChannelReamrk() + ", ") + c002Response.getTransDesc());
					} else {
						channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码
						// --
						// 交易异常
						channelResultDTO.setChannelResponseMsg(c002Response.getTransDesc());
					}
					channelResultDTO.setSettlementDate(StringUtils.replace(c002Response.getAccountDate(), "-", ""));
					// 更新渠道流水信息
					billnoSnService.update(billnosnSeq, c002Response.getTransStatus(),
							channelResultDTO.getChannelResponseMsg(), c002Response.getActualDeductAmt(),
							channelResultDTO.getChannelResponseCode());
				} else {// 如果查询返回不成功，则使用b001交易返回结果

					final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(
							channelId, b001Response.getResultCode()));
					if (channelRtncode != null) {
						channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
						channelResultDTO.setChannelResponseMsg((success.equals(b001Response.getResultCode()) ? ""
								: channelRtncode.getChannelReamrk() + ", ") + b001Response.getResultDesc());
					} else {
						channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码
						// --
						// 交易异常
						channelResultDTO.setChannelResponseMsg(b001Response.getResultDesc());
					}
					channelResultDTO.setSettlementDate(StringUtils.replace(b001Response.getAccountDate(), "-", ""));
					// 更新渠道流水信息
					billnoSnService.update(billnosnSeq, b001Response.getResultCode(), b001Response.getResultDesc(),
							b001Response.getActualDeductAmt(), channelResultDTO.getChannelResponseCode());
				}
			} catch (final Exception e) {
				Log4jUtil.error("代收返回R9000银行内部错误，然后调用单笔查询接口查询，C002接口异常：" + e.getMessage());
				return makeExceptionReturn("代收返回R9000银行内部错误，然后调用单笔查询接口查询，C002接口异常：" + e.getMessage());
			}
		}
		channelResultDTO.setTxnStatus(PayState.SUCCEED_STR);
		channelResultDTO.setChannelId(channelId);
		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;

	}

	/**
	 * PS.实时代付
	 * 
	 * @see com.lycheepay.settlecore.app.common.service.channel.AbstractChannelService#directPay(com.lycheepay.clearing.common.dto.trade.PayOutDTO.common.dto.PayChannelDTO)
	 * @author 张凯锋
	 */
	@Override
	public ClearingResultDTO directPay(final PayOutDTO pay) throws ClearingAdapterBizCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info(pay);
		// 保存渠道流水信息
		final B002Request b002Request = new B002Request(sequenceManagerService.getCorpBocSN(), pay.getBankCardNo(),
				pay.getCardHolderName(), pay.getAmount().setScale(2, RoundingMode.HALF_UP).toString());
		BillnoSn b002 = bocModelToBillNoSnService.b002(b002Request.getTransNo(), pay, channelId);
		String billnosnSeq = sequenceManagerService.getBillnoSnSeq();
		b002.setBillnosnSeq(billnosnSeq);
		billnoSnService.save(b002);
		// b002Request.setProvinceCode("99");//深圳市
		// 设置请求头信息
		b002Request.setSysCode(sysCode);
		b002Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// b002Request.setMsgType("B002");//中行代码，代表单笔实时代收
		b002Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		// 生成报文
		// final String sendXML = b002Request.getXML();
		Log4jUtil.info("生成单笔代付发送信息：" + b002Request.toString());
		B002Response b002Response = null;
		try {
			b002Response = bocCorpClient.requestLink(b002Request, B002Response.class);

		} catch (final Exception e) {
			if (e instanceof ClearingAdapterClientCheckedException) {
				ClearingAdapterClientCheckedException ce = (ClearingAdapterClientCheckedException) e;
				Log4jUtil.error("发送接收单笔代收报文处理出错 e.getMessage()：" + e.getMessage() + ", e.getErrorCode()："
						+ ce.getCode() + "[" + ChannelClientErrorCode.getNameByValue(ce.getCode() + "]"));
				if (ChannelClientErrorCodeEnum.CLIENT_SENDED.getCode().equals(ce.getStage())) {
					Log4jUtil.error("清算平台已向银行渠道发送完整信息后出现异常，开始调用冲正");
					try {
						Thread.sleep(5000);
						final B003Response sendReverse = sendReverse(b002Request.getTransNo(),
								b002Request.getAccountNo(), b002Request.getMoney());
						Log4jUtil.error("冲正结果, code:" + sendReverse.getResultCode() + ", desc: "
								+ sendReverse.getResultDesc());
					} catch (final Exception e1) {
						Log4jUtil.error("b001Request冲正失败:" + e.getMessage());
						e1.printStackTrace();
					}
				}
			} else {
				Log4jUtil.error("发送接收单笔代收报文处理出错：" + e.getMessage());
				return makeExceptionReturn("发送接收单笔代收报文处理出错：" + e.getMessage());
			}
			return makeExceptionReturn(e.getMessage());
		}
		// 创建返回结果
		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();

		if (!"R9000".equals(b002Response.getResultCode())) {// 未出现银行内部异常
			final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
					b002Response.getResultCode()));
			if (channelRtncode != null) {
				channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
				channelResultDTO.setChannelResponseMsg((success.equals(b002Response.getResultCode()) ? ""
						: channelRtncode.getChannelReamrk() + ", ") + b002Response.getResultDesc());
			} else {
				channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码
				// -- 交易异常
				channelResultDTO.setChannelResponseMsg(b002Response.getResultDesc());
			}
			channelResultDTO.setSettlementDate(StringUtils.replace(b002Response.getAccountDate(), "-", ""));
			billnoSnService.update(billnosnSeq, b002Response.getResultCode(), b002Response.getResultDesc(),
					b002Response.getActualDeductAmt(), channelResultDTO.getChannelResponseCode());
		} else {// R9000 银行内部异常 由于服务器异常,不能明确该笔交易的准确结果,需要发起方继续发起查询报文或者重发相同原交易
			Log4jUtil.info("代付返回ResultCode == R9000，调用单笔查询接口查询处理结果");
			try {
				final C002Response c002Response = this.singleQuery(b002Request.getTransNo());
				if (success.equals(c002Response.getResultCode())) {// 如果查询成功，则根据交易状态来判断交易是否成功
					Log4jUtil.info("代付返回ResultCode == R9000，调用单笔查询接口查询处理结果" + c002Response.getResultCode());
					final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(
							channelId, c002Response.getTransStatus()));
					if (channelRtncode != null) {
						channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
						channelResultDTO.setChannelResponseMsg((success.equals(c002Response.getTransStatus()) ? ""
								: channelRtncode.getChannelReamrk() + ", ") + c002Response.getTransDesc());
					} else {
						channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码
						// 交易异常
						channelResultDTO.setChannelResponseMsg(c002Response.getTransDesc());
					}
					channelResultDTO.setSettlementDate(StringUtils.replace(c002Response.getAccountDate(), "-", ""));
					// 更新渠道流水信息
					billnoSnService.update(billnosnSeq, c002Response.getTransStatus(),
							channelResultDTO.getChannelResponseMsg(), c002Response.getActualDeductAmt(),
							channelResultDTO.getChannelResponseCode());
				} else {
					final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(
							channelId, b002Response.getResultCode()));
					if (channelRtncode != null) {
						channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
						channelResultDTO.setChannelResponseMsg((success.equals(b002Response.getResultCode()) ? ""
								: channelRtncode.getChannelReamrk() + ", ") + b002Response.getResultDesc());
					} else {
						channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码
						// --
						// 交易异常
						channelResultDTO.setChannelResponseMsg(b002Response.getResultDesc());
					}
					channelResultDTO.setSettlementDate(StringUtils.replace(b002Response.getAccountDate(), "-", ""));
					billnoSnService.update(billnosnSeq, b002Response.getResultCode(), b002Response.getResultDesc(),
							b002Response.getActualDeductAmt(), channelResultDTO.getChannelResponseCode());
				}

			} catch (final Exception e) {
				Log4jUtil.error("代收返回R9000银行内部错误，然后调用单笔查询接口查询，C002接口异常：" + e.getMessage());
				return makeExceptionReturn("代收返回R9000银行内部错误，然后调用单笔查询接口查询，C002接口异常：" + e.getMessage());
			}
		}
		channelResultDTO.setTxnStatus(PayState.SUCCEED_STR);
		channelResultDTO.setChannelId(channelId);

		Log4jUtil.info(channelResultDTO);

		// 更新渠道流水信息
		return channelResultDTO;
	}

	/**
	 * PS.报文账户验证
	 * 
	 * @see com.lycheepay.settlecore.app.common.service.channel.AbstractChannelService#accountVerify(com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO.common.dto.AccountVerifyChannelDTO)
	 * @author 张凯锋
	 */
	@Override
	public ClearingResultDTO accountVerify(final BankCardVerifyDTO accountVerify)
			throws ClearingAdapterBizCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info(accountVerify);
		// 创建请求报文
		final C001Request c001Request = new C001Request(accountVerify);
		// 快付通证件类型转成中行证件类型
		c001Request.setIdType(channelCertTypeService.getCertType(channelId, accountVerify.getCertificateType()));
		// 设置请求头信息
		c001Request.setSysCode(sysCode);
		c001Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// c001Request.setMsgType("C001");//中行代码，代表账户验证
		c001Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		// 生成报文
		// final String sendXML = c001Request.getXML();
		Log4jUtil.info("生成账户验证发送信息：" + c001Request.toString());
		C001Response c001Response = null;
		try {
			c001Response = bocCorpClient.requestLink(c001Request, C001Response.class);
		} catch (final Exception e) {
			Log4jUtil.error("发送接收账户验证报文处理出错：" + e.getMessage());
			return makeExceptionReturn(e.getMessage());
		}
		// 创建返回结果
		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		final ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
				c001Response.getResultCode()));
		if (channelRtncode != null) {
			channelResultDTO.setChannelResponseCode(channelRtncode.getKftRtncode());
			channelResultDTO.setChannelResponseMsg((success.equals(c001Response.getResultCode()) ? "" : channelRtncode
					.getChannelReamrk() + ", ")
					+ c001Response.getResultDesc());
		} else {
			channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码 --
			// 交易异常
			channelResultDTO.setChannelResponseMsg(c001Response.getResultDesc());
		}
		channelResultDTO.setTxnStatus(PayState.SUCCEED_STR);
		channelResultDTO.setChannelId(channelId);

		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	/**
	 * <p>针对异常（银行未返回正确的报文结果），返回处理结果</p>
	 * 
	 * @param message
	 * @return
	 * @author 张凯锋
	 */
	private ClearingResultDTO makeExceptionReturn(final String message) {
		final ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		// final String[] split = message.split("|");
		// if(split.length==2){
		// channelResultDTO.setBankResultCode(split[0]);
		// channelResultDTO.setBankPostScript(split[1]);
		// }
		channelResultDTO.setChannelResponseCode(TransReturnCode.code_9900);	// 平台中未有对应的状态码 --
		// 交易异常
		channelResultDTO.setChannelResponseMsg(message);
		channelResultDTO.setTxnStatus(PayState.FAILED_STR);
		channelResultDTO.setChannelId(channelId);
		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	/**
	 * <p>冲正service，因为多个接口调用，所以提取出来</p>
	 * 
	 * @param originalTransNo 原交易流水号
	 * @param accountNo 原交易账号
	 * @param money 原交易金额
	 * @return
	 * @author 张凯锋
	 * @throws BizException
	 */
	public B003Response sendReverse(final String originalTransNo, final String accountNo, final String money)
			throws ClearingAdapterClientCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		Log4jUtil.setLogClass("BOC", "corp");
		// 创建请求报文
		final B003Request b003Request = new B003Request(originalTransNo, accountNo, money);
		// 设置请求头信息
		b003Request.setSysCode(sysCode);
		b003Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// b003Request.setMsgType("B003");// 中行代码，代表账户验证
		b003Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		Log4jUtil.info("生成冲正信息：" + b003Request.toString());
		// 生成报文
		return bocCorpClient.requestLink(b003Request, B003Response.class);

	}

	/**
	 * 批量业务处理(批量代付、批量代扣)
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#processBatch(java.util.List,
	 *      boolean)
	 * @author 邱林 Leon.Qiu
	 */
	@Override
	public BatchSendResult processBatch(String channelBatchId, List<ChannelTempBill> payList, final boolean repeatSend)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info("参数List<ChannelTempBill> payList大小为：" + payList.size());
		// if (repeatSend) {// 批量重发
		// // TODO 待商议
		// } else {
		return bocCorpBatchService.sendBatchTransaction(channelBatchId, payList);
		// }
	}

	/**
	 * <p>单笔查询</p>
	 * 
	 * @param transNo 原交易流水号
	 * @return
	 * @author 张凯锋
	 * @throws BizException
	 */
	public C002Response singleQuery(final String transNo) throws ClearingAdapterClientCheckedException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		// 创建请求报文
		final C002Request c002Request = new C002Request(transNo);
		// 设置请求头信息
		c002Request.setSysCode(sysCode);
		c002Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
		// c002Request.setMsgType("C002");// 中行代码，代表单笔查询
		c002Request.setSendTimestamp(DateUtil.getISO8601Fmt());
		// 生成报文
		Log4jUtil.info("生成单笔查询信息：" + c002Request.toString());
		return bocCorpClient.requestLink(c002Request, C002Response.class);
	}

	/**
	 * <p>批量处理查询</p>
	 * 
	 * @author 张凯锋
	 * @throws BizException
	 */
	@Override
	public void timeQueryBatchTransResult() throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String sysCode = channelParms.get("100004");
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info("中行银企批量交易结果处理 batchQuery");
		String result = "";
		List<String> batchIdList = new ArrayList<String>();
		batchIdList = channelBatchService.getCorpBatchIdList(channelId);
		Log4jUtil.info("中行银企要查询的批理业务交易结果的批次号start");
		for (int i = 0; i < batchIdList.size(); i++) {
			Log4jUtil.info("批次号 " + (i + 1) + " : " + batchIdList.get(i));
		}
		Log4jUtil.info("中行银企要查询的批理业务交易结果的批次号end");
		Log4jUtil.info("中行银企批量处理结果报文查询交易开始");
		for (int i = 0; i < batchIdList.size(); i++) {
			final C003Request c003Request = new C003Request(batchIdList.get(i));
			// 设置请求头信息
			c003Request.setSysCode(sysCode);
			c003Request.setMsgId(sequenceManagerService.getCorpBocMsgId());
			c003Request.setSendTimestamp(DateUtil.getISO8601Fmt());
			// 生成报文
			Log4jUtil.info("生成批量查询信息：" + c003Request.toString());
			C003Response c003Response = null;
			try {
				c003Response = bocCorpClient.requestLink(c003Request, C003Response.class);
			} catch (final Exception e) {
				Log4jUtil.error(e);
				Log4jUtil.info("==中行批量处理结果报文查询交易异常：" + e.getMessage());
				result = e.getMessage();
				return;
			}
			result = bocCorpBatchService.updateBillNoSnResult(batchIdList.get(i), c003Response);
		}
		Log4jUtil.info("中行银企批量处理结果报文查询交易完成:" + result);
	}

	@Override
	public int getMaxNum() {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String maxNum = channelParms.get("100005");
		return Integer.valueOf(maxNum);
	}

}
