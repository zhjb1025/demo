package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

/**
 * 中行B2C支付订单实体 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-cji
 * @version 1.0
 */
public class BocB2CPayBean {
	private String merchantNo;// 商户代码
	private String payType;// 商户支付服务类型 1：网上购物 2：基金直销
	private String orderNo;// 商户订单号 19位
	private String curCode;// 币种 目前只支持001：人民币
	private Double orderAmount;// 交易金额
	private String orderTime;// 交易时间 YYYYMMDD24HHMMSS
	private String orderNote;// 订单描述
	private String orderUrl;// 处理结果返回的URL
	private String signData;// 商户签名数据串格式，各项数据用管道符分隔：商户订单号|订单时间|订单币种|订单金额|商户号orderNo|orderTime|curCode|orderAmount|merchantNo

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(final String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(final String payType) {
		this.payType = payType;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(final String orderNo) {
		this.orderNo = orderNo;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(final String curCode) {
		this.curCode = curCode;
	}

	public Double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(final Double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(final String orderTime) {
		this.orderTime = orderTime;
	}

	public String getOrderNote() {
		return orderNote;
	}

	public void setOrderNote(final String orderNote) {
		this.orderNote = orderNote;
	}

	public String getOrderUrl() {
		return orderUrl;
	}

	public void setOrderUrl(final String orderUrl) {
		this.orderUrl = orderUrl;
	}

	public String getSignData() {
		return signData;
	}

	public void setSignData(final String signData) {
		this.signData = signData;
	}
}
