/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:33:11
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

/**
 * <P>单笔实时冲正交易请求</P>
 * 
 * @author 张凯锋
 */
public class B003Request extends RequestHead {

	private String transNo;// 原交易流水号 TRANS_NO M 标识唯一交易
	private String accountNo;// 原交易账号 ACCOUNT_NO M 要冲正的原交易是代收时是借方账号要冲正的原交易是代付时是贷方账号
	private String money;// 原交易金额

	/**
	 * @param transNo 原交易流水号
	 * @param accountNo 原交易账号
	 * @param money 原交易金额
	 */
	public B003Request(final String transNo, final String accountNo, final String money) {
		this.transNo = transNo;
		this.accountNo = accountNo;
		this.money = money;
	}

	/**
	 * <p>组装发送报文</p>
	 * 
	 * @return
	 * @author 张凯锋
	 */
	public String getXML() {
		final StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
		sb.append("<B003_REQUEST xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.szboc.cn/projects/open/2012/UniformProxySystem\">");
		sb.append(getHeadXML());
		sb.append("<BODY>");
		sb.append("<TRANS_NO>").append(transNo).append("</TRANS_NO>");
		sb.append("<ACCOUNT_NO>").append(accountNo).append("</ACCOUNT_NO>");
		sb.append("<MONEY>").append(money).append("</MONEY>");
		sb.append("</BODY>");
		sb.append("</B003_REQUEST>");
		return sb.toString();
	}

	public String getTransNo() {
		return transNo;
	}

	public void setTransNo(final String transNo) {
		this.transNo = transNo;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(final String accountNo) {
		this.accountNo = accountNo;
	}

	public String getMoney() {
		return money;
	}

	public void setMoney(final String money) {
		this.money = money;
	}
}
