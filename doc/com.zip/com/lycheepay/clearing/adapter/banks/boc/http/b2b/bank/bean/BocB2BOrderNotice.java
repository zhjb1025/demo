package com.lycheepay.clearing.adapter.banks.boc.http.b2b.bank.bean;

/**
 * <P>中行B2B网关发送B2B支付结果通知实体(网关通过https方式post到商户)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午4:44:02
 */
public class BocB2BOrderNotice {
	private String tranSeq; 	// 交易流水 (网关交易流水号)
	private String tranCode; 	// 交易类型(B2B交易类型（支付）01:支付/04:联机退货
	private String orderSeq; 	// 订单流水(网关生成的订单流水号)
	private String bocNo; 		// 商户号(网关商户号) *
	private String orderNo; 	// 商户订单号(商户系统产生的订单号) *
	private String curCode;		// 订单币种 *
	private String orderAmount; // 订单金额 *
	private String feeAmount; 	// 交易费用 *
	private String tranTime; 	// 交易时间 *
	private String tranCur; 	// 交易币种 *
	private String tranAmount; 	// 交易金额(交易类型为支付时表示支付金额)
	private String tranStatus; 	// 交易状态(只有终态:1 成功/ 2失败)
	private String errMsg; 		// 失败原因
	private String signData; 	// 银行数字签名(tranSeq|tranCode|tranStatus|tranTime|tranAmount|feeAmount|bocNo|orderNo|curCode)

	/**
	 * 拼接要签名的字符串, 各项数据用管道符分隔
	 * 
	 * @return
	 */
	public String getToBeSignedStr() {
		final StringBuffer toBeSignedStr = new StringBuffer();
		toBeSignedStr.append(tranSeq).append("|").append(tranCode).append("|").append(tranStatus).append("|")
				.append(tranTime).append("|").append(tranAmount).append("|").append(feeAmount).append("|")
				.append(bocNo).append("|").append(orderNo).append("|").append(curCode);

		return toBeSignedStr.toString();
	}

	public String getTranSeq() {
		return tranSeq;
	}

	public void setTranSeq(final String tranSeq) {
		this.tranSeq = tranSeq;
	}

	public String getTranCode() {
		return tranCode;
	}

	public void setTranCode(final String tranCode) {
		this.tranCode = tranCode;
	}

	public String getOrderSeq() {
		return orderSeq;
	}

	public void setOrderSeq(final String orderSeq) {
		this.orderSeq = orderSeq;
	}

	public String getBocNo() {
		return bocNo;
	}

	public void setBocNo(final String bocNo) {
		this.bocNo = bocNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(final String orderNo) {
		this.orderNo = orderNo;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(final String curCode) {
		this.curCode = curCode;
	}

	public String getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(final String orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getFeeAmount() {
		return feeAmount;
	}

	public void setFeeAmount(final String feeAmount) {
		this.feeAmount = feeAmount;
	}

	public String getTranTime() {
		return tranTime;
	}

	public void setTranTime(final String tranTime) {
		this.tranTime = tranTime;
	}

	public String getTranCur() {
		return tranCur;
	}

	public void setTranCur(final String tranCur) {
		this.tranCur = tranCur;
	}

	public String getTranAmount() {
		return tranAmount;
	}

	public void setTranAmount(final String tranAmount) {
		this.tranAmount = tranAmount;
	}

	public String getTranStatus() {
		return tranStatus;
	}

	public void setTranStatus(final String tranStatus) {
		this.tranStatus = tranStatus;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(final String errMsg) {
		this.errMsg = errMsg;
	}

	public String getSignData() {
		return signData;
	}

	public void setSignData(final String signData) {
		this.signData = signData;
	}
}
