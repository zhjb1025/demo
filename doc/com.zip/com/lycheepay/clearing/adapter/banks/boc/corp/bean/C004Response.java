/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:35:19
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>单笔查询结果</P>
 * 
 * @author 张凯锋
 */
public class C004Response extends ResponseHead {

	private List<C004ResponseDetail> details = new ArrayList<C004ResponseDetail>();

	public C004Response() {
		super();
	}

	public C004Response(final byte[] respBytes) throws BizException {
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respBytes);
		final Node head = dom4jxml.getNode("/C004_RESPONSE/HEAD");
		setResponseHead(dom4jxml, head);
		final List<Node> nodes = dom4jxml.getNodeList("/C004_RESPONSE/BODY/DETAILS/DETAIL");
		for (int i = 0, len = nodes.size(); i < len; i++) {
			details.add(new C004ResponseDetail(dom4jxml, nodes.get(i)));
		}
	}

	public List<C004ResponseDetail> getDetails() {
		return details;
	}

	public void setDetails(final List<C004ResponseDetail> details) {
		this.details = details;
	}
}
