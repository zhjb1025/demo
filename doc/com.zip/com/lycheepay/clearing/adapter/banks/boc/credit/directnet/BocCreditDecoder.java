/*******************************************************************************
 * Project Key : CPP
 * Create on 2012-8-2 下午5:01:32
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.credit.directnet;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.soofa.remoting.Channel;
import org.soofa.remoting.Decoder;
import org.soofa.remoting.SoofaRemotingException;

import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.MacUtil;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企直连解码器</P>
 * 
 * @author 邱林 Leon.Qiu 2012-8-2 下午5:01:32
 */
public class BocCreditDecoder implements Decoder<MsgPack> {

	/**
	 * @see org.soofa.remoting.Decoder#decode(org.soofa.remoting.Channel, java.io.InputStream)
	 * @author 邱林 Leon.Qiu 2012-8-28 下午3:15:11
	 */
	@Override
	public MsgPack decode(final Channel channel, final InputStream stream) {
		Log4jUtil.setLogClass("BOC", "credit");
		byte[] result = null;
		try {
			result = IOUtils.toByteArray(stream);
		} catch (final IOException e) {
			throw new SoofaRemotingException(e.getMessage(), e);
		}
		return unpackMsg(result);
	}

	/**
	 * <p>对银行返回的信息进行解包</p>
	 * 
	 * @param msg 网络读到的字节流,完整的消息包
	 * @return 解压好的8583处理信息报或者抛出指定的异常信息
	 * @author 邱林 Leon.Qiu 2012-8-28 下午3:15:14
	 */
	private MsgPack unpackMsg(final byte[] msg) {
		Log4jUtil.info("execute unpackMsg() 方法，解包开始。");
		final MsgPack pack = new MsgPack();
		pack.unpack(msg);
		if (pack.isFull()) {
			try {
				Log4jUtil.debug(StringUtil.r("收到完整消息包并派发给处理线程,消息:{?}", MacUtil.toHexString(pack)));
			} catch (final BizException e) {
				throw new SoofaRemotingException("根据算法unpack解包失败!");
			}
			return pack;
		} else {
			throw new SoofaRemotingException("由于接收到不完整的包,unpack解包失败!");
		}
	}
}
