/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:33:42
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>单笔实时冲正交易响应</P>
 * 
 * @author 张凯锋
 */
public class B003Response extends ResponseHead {

	private String transNo;// 交易流水号 TRANS_NO O 冲正的交易流水号
	private String accountDate;// 实际扣账日期 DATE O 只有在后台业务子系统与主机系统发生实际账务才会填写主机账务返回的实际扣款日期

	/**
	 * <p>Method for constructor</p>
	 * 
	 * @param decodeBytes
	 * @throws BizException
	 */
	public B003Response(final byte[] respBytes) throws BizException {
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respBytes);
		final Node head = dom4jxml.getNode("/B003_RESPONSE/HEAD");
		setResponseHead(dom4jxml, head);
		final Node body = dom4jxml.getNode("/B003_RESPONSE/BODY");
		transNo = dom4jxml.getNodeText(body, "TRANS_NO");
		accountDate = dom4jxml.getNodeText(body, "ACCOUNT_DATE");
	}

	public String getTransNo() {
		return transNo;
	}

	public void setTransNo(final String transNo) {
		this.transNo = transNo;
	}

	public String getAccountDate() {
		return accountDate;
	}

	public void setAccountDate(final String accountDate) {
		this.accountDate = accountDate;
	}
}
