/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-29 上午10:11:57
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import java.util.List;

import org.soofa.core.model.BaseObject;

/**
 * <P>
 * 中国银行快捷支付业务明细查询响应
 * </P>
 * 
 * @author #{杜波(15999653650)}
 */
public class BocInternetCorpQuickPayQueryResponseBean extends BaseObject {

	private static final long serialVersionUID = -8237383572673844695L;
	/**
	 * 响应状态代码
	 */
	private String rspcod;
	/**
	 * 响应信息
	 */
	private String rspmsg;
	/**
	 * 网银交易流水号
	 */
	private String obssid;
	/**
	 * 指令ID
	 */
	private String insid;
	/**
	 * 付款账号
	 */
	private String actacn;
	/**
	 * 货币
	 */
	private String pybcur;
	/**
	 * 批总金额（只累加计算成功的笔金额）
	 */
	private String pybamt;
	/**
	 * 批总笔数
	 */
	private String pybnum;
	/**
	 * 类型，中行送7，他行送6；
	 */
	private String crdtyp;
	/**
	 * 摘要
	 */
	private String furinfo;
	/**
	 * 用途
	 */
	private String useinf;
	/**
	 * 要求付款日期
	 */
	private String trfdate;
	/**
	 * 笔明细状态
	 */
	private List<BocInternetCorpQuickPayQueryResponseDetailBean> list;

	public String getRspcod() {
		return rspcod;
	}

	public void setRspcod(String rspcod) {
		this.rspcod = rspcod;
	}

	public String getRspmsg() {
		return rspmsg;
	}

	public void setRspmsg(String rspmsg) {
		this.rspmsg = rspmsg;
	}

	public String getObssid() {
		return obssid;
	}

	public void setObssid(String obssid) {
		this.obssid = obssid;
	}

	public String getInsid() {
		return insid;
	}

	public void setInsid(String insid) {
		this.insid = insid;
	}

	public String getActacn() {
		return actacn;
	}

	public void setActacn(String actacn) {
		this.actacn = actacn;
	}

	public String getPybcur() {
		return pybcur;
	}

	public void setPybcur(String pybcur) {
		this.pybcur = pybcur;
	}

	public String getPybamt() {
		return pybamt;
	}

	public void setPybamt(String pybamt) {
		this.pybamt = pybamt;
	}

	public String getPybnum() {
		return pybnum;
	}

	public void setPybnum(String pybnum) {
		this.pybnum = pybnum;
	}

	public String getCrdtyp() {
		return crdtyp;
	}

	public void setCrdtyp(String crdtyp) {
		this.crdtyp = crdtyp;
	}

	public String getFurinfo() {
		return furinfo;
	}

	public void setFurinfo(String furinfo) {
		this.furinfo = furinfo;
	}

	public String getUseinf() {
		return useinf;
	}

	public void setUseinf(String useinf) {
		this.useinf = useinf;
	}

	public String getTrfdate() {
		return trfdate;
	}

	public void setTrfdate(String trfdate) {
		this.trfdate = trfdate;
	}

	public List<BocInternetCorpQuickPayQueryResponseDetailBean> getList() {
		return list;
	}

	public void setList(
			List<BocInternetCorpQuickPayQueryResponseDetailBean> list) {
		this.list = list;
	}

}
