package com.lycheepay.clearing.adapter.banks.boc.credit.kft.util;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;

import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


public class SendBySocket {
	private int timeout = 60000;// 单位毫秒，6000。 业务交易超时，，用于传输数据时
	private int connectOutTime = 60000;// 单位毫秒，6000。 用于刚开始建立链接时,一般不需要改变此值

	public int getConnectOutTime() {
		return connectOutTime;
	}

	public void setConnectOutTime(final int connectOutTime) {
		this.connectOutTime = connectOutTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(final int timeout) {
		this.timeout = timeout;
	}

	public static void main(String[] args) {// 该测试为打印发送报文域值 2013-7-17 zkf
		MsgPack pack = new MsgPack();
		String s = "00866000090000000802207024058004C1800D196228480120492682222027000000000000050020036114010012000908313534323436343830303135343431303434383138343831343031393800073932303335363701560015303030303031303031323030333631002030323030323030333538303830323135343234366AB5FA81BA340EBC";
		byte[] msg = LoUtils.hexStr2Bytes(s);
		final int msgLen = msg.length;
		int unpackedLen = 0;
		while (unpackedLen < msgLen) {
			System.out.println("=====msgLen=" + msgLen + "====unpackedLen=" + unpackedLen);
			unpackedLen += pack.unpack(msg);
			// 解包完成, 派发消息包, 并初始化新的空包.
			if (pack.isFull()) {
				System.out.println("解析完成");
				break;
			}
		}
	}

	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg 要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public MsgPack sendAndRecv(final String socketIp, final String socketPort, final byte[] sendMsg)
			throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg length:" + sendMsg.length);
		Socket socket = connect(socketIp, socketPort);
		try {
			socket.getOutputStream().write(sendMsg);
			socket.getOutputStream().flush();
		} catch (final Exception e) {
			this.disconnect(socket);
			Log4jUtil.error(e);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
		}
		try {
			// final InputStream in = socket.getInputStream();
			// final byte[] buffer = new byte[1024];
			// while (true) {
			// final int len = in.read(buffer);
			// // 长度-1时,退出读.
			// if (len == -1) {
			// Log4jUtil.debug("读取长度-1");
			// return pack;
			// }
			// final byte[] msg = ArrayUtils.subarray(buffer, 0, len);
			//
			// Log4jUtil.debug("从{?}收到消息:{?}", socketIp, MacUtil.toHexString(msg));
			// Log4jUtil.debug("从{?}收到消息:{?}", socketIp, Arrays.toString(msg));
			//
			// try {
			// pack = unpackMsg(pack, msg, socketIp);
			// } catch (final Throwable e) {// 解包出错,清空未解析完成的包,等待下批数据;如下批数据不是从头开始,只能断开连接.
			// Log4jUtil.error(e, e);
			// }
			// }
			byte[] msg = IOUtils.toByteArray(socket.getInputStream());
			Log4jUtil.debug("从{}收到消息:{}", socketIp, MacUtil.toHexString(msg));
			Log4jUtil.debug("从{}收到消息:{}", socketIp, Arrays.toString(msg));
			MsgPack pack = new MsgPack();
			pack = unpackMsg(pack, msg, socketIp);
			return pack;
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
		} finally {
			this.disconnect(socket);
		}
		// return pack;
	}

	/**
	 * 解包.
	 * 
	 * @param pack 未完成的包.
	 * @param msg 网络一次读到的字节流,可能为多个消息包(包括不完整的)
	 * @throws BizException
	 */
	private MsgPack unpackMsg(final MsgPack pack, final byte[] msg, final String socketIp) throws BizException {
		try {
			Log4jUtil.info("execute unpackMsg() 方法，解包开始。");
			if (null == msg) {
				return pack;
			}
			final int msgLen = msg.length;
			int unpackedLen = 0;
			while (unpackedLen < msgLen) {
				Log4jUtil.info("=====msgLen=" + msgLen + "===============unpackedLen=" + unpackedLen);
				unpackedLen += pack.unpack(msg);
				// 解包完成, 派发消息包, 并初始化新的空包.
				if (pack.isFull()) {
					Log4jUtil.debug(StringUtil.r("收到完整消息包并派发给处理线程,socketIp:{?},消息:{?}", socketIp,
							MacUtil.toHexString(pack)));
					return pack;
				}
			}
			Log4jUtil.info("execute unpackMsg() 方法，解包完成。");
		} catch (final Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9109, "通讯异常,连接 socket server 失败！！");
		}
		return pack;
	}

	/**
	 * 连接服务器 socket
	 * 
	 * @param socketPort
	 * @param socketIp
	 * @throws BizException
	 */
	private Socket connect(final String socketIp, final String socketPort) throws BizException {
		Socket socket = null;
		AssertUtils.notNull(socketIp, TransReturnCode.code_9108, "SocketIP不能为空!");
		AssertUtils.notNull(socketPort, TransReturnCode.code_9108, "SocketPort不能为空!");
		try {
			socket = new Socket();
			final SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
			socket.connect(socketAddress, connectOutTime);
			socket.setSoTimeout(timeout);
			Log4jUtil.info("connected!");
		} catch (final Exception e) {
			// 链接不成功，抛错误代码为9103
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9103, "通讯异常,连接 socket server 失败！！" + e.getMessage());
		}
		return socket;
	}

	/**
	 * 断开服务器 socket
	 * 
	 * @throws BizException
	 */
	private void disconnect(final Socket socket) throws BizException {
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (final Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "断开 socket server 失败！！");
		}
	}

}
