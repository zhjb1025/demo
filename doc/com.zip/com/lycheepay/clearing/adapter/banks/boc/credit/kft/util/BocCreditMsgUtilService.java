package com.lycheepay.clearing.adapter.banks.boc.credit.kft.util;

import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.soofa.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.credit.kft.bean.BocCreditBean;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.ByteUtils;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgField;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgFieldType;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPackUtils;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.BillnoSnTradeDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.channel.DeductPayReal;
import com.lycheepay.clearing.adapter.common.model.channel.PreAuthBean;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
import com.lycheepay.clearing.adapter.common.service.channel.ChannelTransUtilService;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.dto.preauth.PreAuthDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行信用卡消息处理工具服务
 * (严格区分Util与UtilsService,前者为简单的静态工具类,后者需要注入其他service，并且与数据库有交集;调用方可以明显区分,如果有Service,不允许new出该对象)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午8:49:21
 */
@Service(ClearingAdapterAnnotationName.BOC_CREDIT_MSG_UTIL_SERVICE)
public class BocCreditMsgUtilService extends BaseWithoutAuditLogService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_TRANS_UTIL_SERVICE)
	private ChannelTransUtilService channelTransUtilService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManagerService sequenceManagerService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;

	@Value(value = "${verifyFlag}")
	private String verifyFlag;

	private final String channelName = ChannelIdEnum.BOC_CREDIT_CARD.getDesc();
	private final String channelId = ChannelIdEnum.BOC_CREDIT_CARD.getCode();

	/**
	 * 预授权消息类型
	 */
	private static final String PRE_AUTH_MSG = "0100";
	/**
	 * 预授权处理吗
	 */
	private static final String PRE_AUTH_PROCESS_CODE = "030000";

	/**
	 * 创建签到
	 * 
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createSign(final String bankSendSn) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String batchNo = channelParms.get("100009");// 批次号
		String nii = channelParms.get("100017");// NII

		// 公共域验证
		validateField();

		// 组 报文
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0800");// 消息类型
		MsgPackUtils.createField3(msgPack, "990000");// 处理码
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码

		// 组装61自定义域 ：批次号 + 网络管理交易类型(001)
		byte[] field61B = ByteUtils.strToBcdRightSide("009");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, "001".getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		return msgPack;
	}

	/**
	 * 创建分期付款签到
	 * 
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createInstalmentSign(final String bankSendSn) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String clinetCode = channelParms.get("200005");// 终端代码
		String merchant = channelParms.get("200006");// 商户代码
		String batchNo = channelParms.get("200009");// 批次号
		String nii = channelParms.get("200017");// NII

		// 公共域验证
		validateField();

		// 组 报文
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0800");// 消息类型
		MsgPackUtils.createField3(msgPack, "990000");// 处理码
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码

		// 组装61自定义域 ：批次号 + 网络管理交易类型(001)
		byte[] field61B = ByteUtils.strToBcdRightSide("009");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, "001".getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		return msgPack;
	}

	/**
	 * 
	 * 创建消费
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createConsume(final Param param, final String bankSendSn) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String inputCode = channelParms.get("100003");// 服务点输入方式码
		String conCode = channelParms.get("100004");// 服务点条件码
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String currency = channelParms.get("100007");// 货币代码
		String operator = channelParms.get("100008");// 操作员代码
		String batchNo = channelParms.get("100009");// 批次号
		String workKey = channelParms.get("100014");// 商户工作密钥
		String nii = channelParms.get("100017");// NII
		// 公共域验证
		validateField();
		// 获取渠道通用交易实体
		final DeductPayReal debiPayReal = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debiPayReal);

		// 特殊域验证
		AssertUtils.checkLength(debiPayReal.getExpdate(), TransReturnCode.code_9108, channelName + "消费报文[14域]卡有效期", 4,
				4);
		AssertUtils.checkLength(debiPayReal.getOut_Account(), TransReturnCode.code_9108, channelName + "消费报文[2域]卡号", 1,
				19);

		// 报文组装
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		// MsgPackUtils.createAccountField(msgPack,
		// "4096660054759483");//主账号-信用卡卡号
		MsgPackUtils.createAccountField(msgPack, debiPayReal.getOut_Account());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "000000");// 交易处理码
		MsgPackUtils.createField4(msgPack, debiPayReal.getAmount_Num());// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		// MsgPackUtils.createField14(msgPack, "2103");//卡有效期

		MsgPackUtils.createField14(msgPack, debiPayReal.getExpdate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码(网银支付)
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码

		// 组装48自定义域 ：CVV2
		byte[] field48B = ByteUtils.strToBcdRightSide("007");
		field48B = ArrayUtils.addAll(field48B, ("9203" + debiPayReal.getCvv2()).getBytes());

		MsgPackUtils.createField48(msgPack, field48B);
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		field61B = ArrayUtils.addAll(field61B, bankSendSn.getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 获取需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		Log4jUtil.info("加密的MACKEY为:" + workKey);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC

		return msgPack;
	}

	/**
	 * 
	 * 创建分期付款消费
	 * 
	 * @param param 基础平台传给渠道的param
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createInstalmentConsume(final Param param, final String bankSendSn, String instalmentsID)
			throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String inputCode = channelParms.get("200003");// 服务点输入方式码
		String conCode = channelParms.get("200004");// 服务点条件码
		String clinetCode = channelParms.get("200005");// 终端代码
		String merchant = channelParms.get("200006");// 商户代码
		String currency = channelParms.get("200007");// 货币代码
		String operator = channelParms.get("200008");// 操作员代码
		String batchNo = channelParms.get("200009");// 批次号
		String workKey = channelParms.get("200014");// 商户工作密钥
		String nii = channelParms.get("200017");// NII
		// 公共域验证
		validateField();
		// 获取渠道通用交易实体
		final DeductPayReal debiPayReal = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debiPayReal);

		// 特殊域验证
		AssertUtils.checkLength(debiPayReal.getExpdate(), TransReturnCode.code_9108, channelName + "消费报文[14域]卡有效期", 4,
				4);
		AssertUtils.checkLength(debiPayReal.getOut_Account(), TransReturnCode.code_9108, channelName + "消费报文[2域]卡号", 1,
				19);

		// 报文组装
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		// MsgPackUtils.createAccountField(msgPack,
		// "4096660054759483");//主账号-信用卡卡号
		MsgPackUtils.createAccountField(msgPack, debiPayReal.getOut_Account());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "000000");// 交易处理码
		MsgPackUtils.createField4(msgPack, debiPayReal.getAmount_Num());// 交易金额
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		// MsgPackUtils.createField14(msgPack, "2103");//卡有效期

		MsgPackUtils.createField14(msgPack, debiPayReal.getExpdate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码(网银支付)
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码

		// 组装48自定义域
		final DeductDTO deductDTO = (DeductDTO) param.getBizBean(); // 代扣实体
		StringBuilder builder = new StringBuilder();
		// cvv2 7
		builder.append("9203").append(debiPayReal.getCvv2());
		// 分期标志位 7
		builder.append("9003905");
		// 分期ID + 分期数 10
		builder.append("9106").append(instalmentsID).append(StringUtils.leftPad(deductDTO.getInstalments(), 2, "0"));
		byte[] field48B = ByteUtils.strToBcdRightSide("024");
		field48B = ArrayUtils.addAll(field48B, builder.toString().getBytes());

		MsgPackUtils.createField48(msgPack, field48B);
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		field61B = ArrayUtils.addAll(field61B, bankSendSn.getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 获取需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		Log4jUtil.info("加密的MACKEY为:" + workKey);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC

		return msgPack;
	}

	/**
	 * <p>创建预授权消息包(已经舍弃使用param实体)</p>
	 * 
	 * @param dto 渠道流水交易的通用数据传输对象
	 * @param preAuth 信用卡预授权交易请求信息
	 * @return 预授权消息包
	 * @throws BizException
	 * @author 邱林 Leon.Qiu 2012-8-27 下午6:02:43
	 */
	public MsgPack createPreAuth(final BillnoSnTradeDTO dto, final PreAuthDTO preAuth) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String inputCode = channelParms.get("100003");// 服务点输入方式码
		String conCode = channelParms.get("100004");// 服务点条件码
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String currency = channelParms.get("100007");// 货币代码
		String operator = channelParms.get("100008");// 操作员代码
		String batchNo = channelParms.get("100009");// 批次号
		String workKey = channelParms.get("100014");// 商户工作密钥
		String nii = channelParms.get("100017");// NII
		// 公共域验证
		validateField();
		// 获取渠道通用交易实体
		final PreAuthBean bean = new PreAuthBean();
		channelTransUtilService.setPreAuthPoJo(dto, preAuth, bean);
		// 特殊域验证
		AssertUtils.checkLength(bean.getCreditCardEndDate(), "9303", channelName + "消费报文[14域]卡有效期", 4, 4);
		AssertUtils.checkLength(bean.getBankCardNo(), "9303", channelName + "消费报文[2域]卡号", 1, 19);
		// 报文组装
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, PRE_AUTH_MSG);// 消息类型
		MsgPackUtils.createAccountField(msgPack, bean.getBankCardNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, PRE_AUTH_PROCESS_CODE);// 交易处理码
		MsgPackUtils.createField4(msgPack, bean.getAmount());// 交易金额
		MsgPackUtils.createField11(msgPack, dto.getBankSendSn());// 流水号
		MsgPackUtils.createField14(msgPack, bean.getCreditCardEndDate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码(网银支付)
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码
		// 组装48自定义域 ：CVV2
		byte[] field48B = ByteUtils.strToBcdRightSide("007");
		field48B = ArrayUtils.addAll(field48B, ("9203" + bean.getCvv2()).getBytes());
		MsgPackUtils.createField48(msgPack, field48B);
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码
		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		field61B = ArrayUtils.addAll(field61B, dto.getBankSendSn().getBytes());
		MsgPackUtils.createField61(msgPack, field61B);
		// 获取需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		Log4jUtil.info("加密的MACKEY为:" + workKey);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC
		return msgPack;
	}

	/**
	 * 
	 * 创建 结帐
	 * 
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createCheck(final String bankSendSn) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String conCode = channelParms.get("100004");// 服务点条件码
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String batchNo = channelParms.get("100009");// 批次号
		String nii = channelParms.get("100017");// NII
		// 公共域验证
		validateField();

		// 报文组装
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0500");// 消息类型
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码(网银支付)
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码

		// 组装61自定义域 ：批次号
		byte[] field61B = ByteUtils.strToBcdRightSide("006");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 组装63自定义域 ：交易总计数据
		byte[] field63B = ByteUtils.strToBcdRightSide("030");
		field63B = ArrayUtils.addAll(field63B, "000".getBytes());
		field63B = ArrayUtils.addAll(field63B, "000000000000".getBytes());
		field63B = ArrayUtils.addAll(field63B, "000".getBytes());
		field63B = ArrayUtils.addAll(field63B, "000000000000".getBytes());
		MsgPackUtils.createField63(msgPack, field63B);

		return msgPack;
	}

	/**
	 * 
	 * 创建 分期付款结帐
	 * 
	 * @param bankSendSn 渠道流水
	 * @return
	 * @throws BizException
	 */
	public MsgPack createInstalmentCheck(final String bankSendSn) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String conCode = channelParms.get("200004");// 服务点条件码
		String clinetCode = channelParms.get("200005");// 终端代码
		String merchant = channelParms.get("200006");// 商户代码
		String batchNo = channelParms.get("200009");// 批次号
		String nii = channelParms.get("200017");// NII
		// 公共域验证
		validateField();

		// 报文组装
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0500");// 消息类型
		MsgPackUtils.createField11(msgPack, bankSendSn);// 流水号
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码(网银支付)
		MsgPackUtils.createField41(msgPack, clinetCode);// 终端代码
		MsgPackUtils.createField42(msgPack, merchant);// 商户代码

		// 组装61自定义域 ：批次号
		byte[] field61B = ByteUtils.strToBcdRightSide("006");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 组装63自定义域 ：交易总计数据
		byte[] field63B = ByteUtils.strToBcdRightSide("030");
		field63B = ArrayUtils.addAll(field63B, "000".getBytes());
		field63B = ArrayUtils.addAll(field63B, "000000000000".getBytes());
		field63B = ArrayUtils.addAll(field63B, "000".getBytes());
		field63B = ArrayUtils.addAll(field63B, "000000000000".getBytes());
		MsgPackUtils.createField63(msgPack, field63B);

		return msgPack;
	}

	/**
	 * <p>创建退货 主要是根据银行在代扣交易时候返回的检索参考号来退货</p>
	 * 
	 * @param bocCredit
	 * @param channelParms
	 * @param isInstalments 是否是分期消费
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 */
	public MsgPack createReturn(final BocCreditBean bocCredit, Map<String, String> channelParms, boolean isInstalments)
			throws BizException {
		String inputCode = isInstalments ? channelParms.get("200003") : channelParms.get("100003");// 服务点输入方式码
		String conCode = isInstalments ? channelParms.get("200004") : channelParms.get("100004");// 服务点条件码
		String clinetCode = isInstalments ? channelParms.get("200005") : channelParms.get("100005");// 终端代码
		String merchant = isInstalments ? channelParms.get("200006") : channelParms.get("100006");// 商户代码
		String currency = isInstalments ? channelParms.get("200007") : channelParms.get("100007");// 货币代码
		String operator = isInstalments ? channelParms.get("200008") : channelParms.get("100008");// 操作员代码
		String batchNo = isInstalments ? channelParms.get("200009") : channelParms.get("100009");// 批次号
		String workKey = isInstalments ? channelParms.get("200014") : channelParms.get("100014");// 商户工作密钥
		String nii = isInstalments ? channelParms.get("200017") : channelParms.get("100017");// NII

		Log4jUtil.info("bocCredit:" + bocCredit);
		AssertUtils.notNull(bocCredit.getAcctNo(), TransReturnCode.code_9108, "消费交易的信用卡号不能为NULL");
		AssertUtils.notNull(bocCredit.getAmount(), TransReturnCode.code_9108, "交易金额不能为NULL");
		AssertUtils.notNull(bocCredit.getBankSendSn(), TransReturnCode.code_9108, "银行流水不能为NULL");
		AssertUtils.notNull(bocCredit.getOrgBankSendSn(), TransReturnCode.code_9108, "原交易发往银行的流水不能为NULL");
		AssertUtils.notNull(bocCredit.getValidDate(), TransReturnCode.code_9108, "消费交易的信用卡有效期不能为NULL");
		AssertUtils.notNull(bocCredit.getCvv2(), TransReturnCode.code_9108, "消费交易的信用卡CVV2不能为NULL");
		AssertUtils.notNull(bocCredit.getBatchNo(), TransReturnCode.code_9108, "银行返回的授权码不能为NULL");
		AssertUtils.notNull(bocCredit.getAuthorizationCode(), TransReturnCode.code_9108, "银行返回消费交易的授权码不能为NULL");
		final MsgPack msgPack = new MsgPack();
		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0220");// 消息类型

		MsgPackUtils.createAccountField(msgPack, bocCredit.getAcctNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "270000");// 交易处理码
		MsgPackUtils.createField4(msgPack, bocCredit.getAmount().doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, bocCredit.getBankSendSn());// POS终端交易流水
		MsgPackUtils.createField14(msgPack, bocCredit.getValidDate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		MsgPackUtils.createField38(msgPack, bocCredit.getAuthorizationCode());// 原授权码
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		byte[] field48B = ByteUtils.strToBcdRightSide("007");
		// field48B=ArrayUtils.addAll(field48B, "9203239".getBytes());
		// field48B = ArrayUtils.addAll(field48B, ("9203" + "196").getBytes()); // TODO
		field48B = ArrayUtils.addAll(field48B, ("9203" + bocCredit.getCvv2()).getBytes());
		MsgPackUtils.createField48(msgPack, field48B); // TODO
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		// MsgPackUtils.createField61(msgPack,
		// "015"+batchNo+operator+bizBean.getBankSendSn());
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		// field61B = ArrayUtils.addAll(field61B, bocCredit.getBatchNo().getBytes());
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		field61B = ArrayUtils.addAll(field61B, bocCredit.getBankSendSn().getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 原交易的信息类型代码+原交易系统跟踪号+原交易的交易日期
		byte[] field62B = ByteUtils.strToBcdRightSide("020");
		field62B = ArrayUtils.addAll(field62B, "0200".getBytes());
		field62B = ArrayUtils.addAll(field62B, bocCredit.getOrgBankSendSn().getBytes());
		// field62B = ArrayUtils.addAll(field62B, bocCredit.getBankRecvSn().getBytes());
		field62B = ArrayUtils.addAll(field62B, bocCredit.getBankDate().getBytes());
		MsgPackUtils.createField62(msgPack, field62B);

		// 组装需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC

		return msgPack;
	}

	/**
	 * <p>创建撤销</p>
	 * 
	 * @param bocCredit
	 * @param channelParms
	 * @param isInstalments 是否是分期消费
	 * @return
	 * @throws BizException
	 * @author 张凯锋
	 */
	public MsgPack createCancel(final BocCreditBean bocCredit, Map<String, String> channelParms, boolean isInstalments)
			throws BizException {
		String inputCode = isInstalments ? channelParms.get("200003") : channelParms.get("100003");// 服务点输入方式码
		String conCode = isInstalments ? channelParms.get("200004") : channelParms.get("100004");// 服务点条件码
		String clinetCode = isInstalments ? channelParms.get("200005") : channelParms.get("100005");// 终端代码
		String merchant = isInstalments ? channelParms.get("200006") : channelParms.get("100006");// 商户代码
		String currency = isInstalments ? channelParms.get("200007") : channelParms.get("100007");// 货币代码
		String operator = isInstalments ? channelParms.get("200008") : channelParms.get("100008");// 操作员代码
		String batchNo = isInstalments ? channelParms.get("200009") : channelParms.get("100009");// 批次号
		String workKey = isInstalments ? channelParms.get("200014") : channelParms.get("100014");// 商户工作密钥
		Log4jUtil.info("创建撤销报文开始...");
		Log4jUtil.info("bocCredit:" + bocCredit);
		AssertUtils.notNull(bocCredit.getAcctNo(), TransReturnCode.code_9108, "消费交易的信用卡号不能为NULL");
		AssertUtils.notNull(bocCredit.getAmount(), TransReturnCode.code_9108, "交易金额不能为NULL");
		AssertUtils.notNull(bocCredit.getBankSendSn(), TransReturnCode.code_9108, "银行流水不能为NULL");
		AssertUtils.notNull(bocCredit.getOrgBankSendSn(), TransReturnCode.code_9108, "原交易发往银行的流水不能为NULL");
		AssertUtils.notNull(bocCredit.getValidDate(), TransReturnCode.code_9108, "消费交易的信用卡有效期不能为NULL");
		AssertUtils.notNull(bocCredit.getCvv2(), TransReturnCode.code_9108, "消费交易的信用卡CVV2不能为NULL");
		AssertUtils.notNull(bocCredit.getBankDate(), TransReturnCode.code_9108, "银行返回消费交易的时间不能为NULL");
		AssertUtils.notNull(bocCredit.getBatchNo(), TransReturnCode.code_9108, "银行返回的授权码不能为NULL");
		AssertUtils.notNull(bocCredit.getAuthorizationCode(), TransReturnCode.code_9108, "银行返回消费交易的授权码不能为NULL");
		final MsgPack msgPack = new MsgPack();

		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0200");// 消息类型
		MsgPackUtils.createAccountField(msgPack, bocCredit.getAcctNo());// 主账号-信用卡卡号
		MsgPackUtils.createField3(msgPack, "200000");// 交易处理码
		MsgPackUtils.createField4(msgPack, bocCredit.getAmount().doubleValue());// 交易金额
		MsgPackUtils.createField11(msgPack, bocCredit.getBankSendSn());// POS终端交易流水
		MsgPackUtils.createField14(msgPack, bocCredit.getValidDate());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		// MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		MsgPackUtils.createField38(msgPack, bocCredit.getAuthorizationCode());// 原授权码
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		byte[] field48B = ByteUtils.strToBcdRightSide("007");
		// field48B=ArrayUtils.addAll(field48B, "9203239".getBytes());
		// field48B = ArrayUtils.addAll(field48B, ("9203" + "196").getBytes()); // TODO
		field48B = ArrayUtils.addAll(field48B, ("9203" + bocCredit.getCvv2()).getBytes());
		MsgPackUtils.createField48(msgPack, field48B); // TODO
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		// field61B = ArrayUtils.addAll(field61B, bocCredit.getBatchNo().getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		field61B = ArrayUtils.addAll(field61B, bocCredit.getBankSendSn().getBytes());
		// field61B = ArrayUtils.addAll(field61B, "04".getBytes());
		// field61B = ArrayUtils.addAll(field61B, "中行信用卡".getBytes());
		// field61B = ArrayUtils.addAll(field61B, "中行中银卡".getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		byte[] field62B = ByteUtils.strToBcdRightSide("020");
		field62B = ArrayUtils.addAll(field62B, "0200".getBytes());
		field62B = ArrayUtils.addAll(field62B, bocCredit.getOrgBankSendSn().getBytes());
		// field62B = ArrayUtils.addAll(field62B, bocCredit.getBankRecvSn().getBytes());
		field62B = ArrayUtils.addAll(field62B, bocCredit.getBankDate().getBytes());
		MsgPackUtils.createField62(msgPack, field62B);

		// 组装需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC
		Log4jUtil.info("创建撤销报文结束");
		return msgPack;
	}

	/**
	 * 创建 冲正
	 * 
	 * @param param
	 * @param grantFinshMsg 银行返回的消费包
	 * @return
	 * @throws BizException
	 */
	public MsgPack createFinishRush(final Param param, final MsgPack grantFinshMsg, final MsgPack consumeMsgPack)
			throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String inputCode = channelParms.get("100003");// 服务点输入方式码
		String conCode = channelParms.get("100004");// 服务点条件码
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String currency = channelParms.get("100007");// 货币代码
		String operator = channelParms.get("100008");// 操作员代码
		String batchNo = channelParms.get("100009");// 批次号
		String workKey = channelParms.get("100014");// 商户工作密钥
		final MsgPack msgPack = new MsgPack();

		final DeductPayReal debiPayReal = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debiPayReal);

		// 组装需加密数据域为2,3,4,11,12,13,49,38,39,41
		Log4jUtil.info("创建冲正报文开始"); // TODO

		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, consumeMsgPack.getAccountNo());
		MsgPackUtils.createField3(msgPack, consumeMsgPack.getFieldContent3());// 交易处理码 同原交易
		MsgPackUtils.createField4(msgPack, consumeMsgPack.getAmount());// 交易金额
		Log4jUtil.info("grantFinshMsg.getFieldContent11() = " + consumeMsgPack.getFieldContent11()); // TODO
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		Log4jUtil.info("冲正流水号：" + bankSendSn);
		MsgPackUtils.createField11(msgPack, bankSendSn);// 不同原交易
		Log4jUtil.info("consumeMsgPack.getFieldContent14() = " + consumeMsgPack.getFieldContent14()); // TODO
		MsgPackUtils.createField14(msgPack, consumeMsgPack.getFieldContent14());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		Log4jUtil.info("grantFinshMsg.getFieldContent38() = " + grantFinshMsg.getFieldContent38()); // TODO
		MsgPackUtils.createField38(msgPack, StringUtils.isNotBlank(grantFinshMsg.getFieldContent38()) ? grantFinshMsg.getFieldContent38() : "      ");// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField37(msgPack, "000000000000"); // 参考号
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		byte[] field48B = ByteUtils.strToBcdRightSide("007");
		// field48B=ArrayUtils.addAll(field48B, "9203239".getBytes());
		field48B = ArrayUtils.addAll(field48B, ("9203" + debiPayReal.getCvv2()).getBytes());
		MsgPackUtils.createField48(msgPack, field48B);
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		Log4jUtil.info("msgPack.getFieldContent11() = " + msgPack.getFieldContent11());
		field61B = ArrayUtils.addAll(field61B, msgPack.getFieldContent11().getBytes());
		// field61B = ArrayUtils.addAll(field61B, "04".getBytes());
		// field61B = ArrayUtils.addAll(field61B, "中行中银卡".getBytes());
		// field61B = ArrayUtils.addAll(field61B, "中行信用卡".getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 原交易的信息类型代码+原交易系统跟踪号+原交易的交易日期
		byte[] field62B = ByteUtils.strToBcdRightSide("020");
		field62B = ArrayUtils.addAll(field62B, "0200".getBytes());
		// field62B = ArrayUtils.addAll(field62B, consumeMsgPack.getFieldContent11().getBytes());
		field62B = ArrayUtils.addAll(field62B, consumeMsgPack.getFieldContent11().getBytes());
		field62B = ArrayUtils.addAll(field62B, "0000000000".getBytes());// 冲正交易时原交易日期和时间送全0
		MsgPackUtils.createField62(msgPack, field62B);

		// 组装需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC
		Log4jUtil.info("创建冲正报文结束");

		return msgPack;
	}
	
	/**
	 * 创建 冲正
	 * 
	 * @param param
	 * @param grantFinshMsg 银行返回的消费包
	 * @return
	 * @throws BizException
	 */
	public MsgPack createFinishRushForInstalments(final Param param, final MsgPack grantFinshMsg, final MsgPack consumeMsgPack)
			throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String inputCode = channelParms.get("200003");// 服务点输入方式码
		String conCode = channelParms.get("200004");// 服务点条件码
		String clinetCode = channelParms.get("200005");// 终端代码
		String merchant = channelParms.get("200006");// 商户代码
		String currency = channelParms.get("200007");// 货币代码
		String operator = channelParms.get("200008");// 操作员代码
		String batchNo = channelParms.get("200009");// 批次号
		String workKey = channelParms.get("200014");// 商户工作密钥
		final MsgPack msgPack = new MsgPack();

		final DeductPayReal debiPayReal = new DeductPayReal();
		channelTransUtilService.setDeductPoJo(param, debiPayReal);

		// 组装需加密数据域为2,3,4,11,12,13,49,38,39,41
		Log4jUtil.info("创建冲正报文开始"); // TODO

		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0400");// 消息类型
		MsgPackUtils.createAccountField(msgPack, consumeMsgPack.getAccountNo());
		MsgPackUtils.createField3(msgPack, consumeMsgPack.getFieldContent3());// 交易处理码 同原交易
		MsgPackUtils.createField4(msgPack, consumeMsgPack.getAmount());// 交易金额
		Log4jUtil.info("grantFinshMsg.getFieldContent11() = " + consumeMsgPack.getFieldContent11()); // TODO
		final String bankSendSn = sequenceManagerService.getBocCreditSN();
		Log4jUtil.info("冲正流水号：" + bankSendSn);
		MsgPackUtils.createField11(msgPack, bankSendSn);// 不同原交易
		Log4jUtil.info("consumeMsgPack.getFieldContent14() = " + consumeMsgPack.getFieldContent14()); // TODO
		MsgPackUtils.createField14(msgPack, consumeMsgPack.getFieldContent14());// 卡有效期
		MsgPackUtils.createField22(msgPack, inputCode);// 服务点输入方式码
		MsgPackUtils.createField25(msgPack, conCode);// 服务点条件码
		Log4jUtil.info("grantFinshMsg.getFieldContent38() = " + grantFinshMsg.getFieldContent38()); // TODO
		MsgPackUtils.createField38(msgPack, StringUtils.isNotBlank(grantFinshMsg.getFieldContent38()) ? grantFinshMsg.getFieldContent38() : "      ");// 授权标识应答码，同原预授权交易
		MsgPackUtils.createField37(msgPack, "000000000000"); // 参考号
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
//		byte[] field48B = ByteUtils.strToBcdRightSide("007");
//		field48B = ArrayUtils.addAll(field48B, ("9203" + debiPayReal.getCvv2()).getBytes());0
		MsgPackUtils.createField48(msgPack, consumeMsgPack.getFieldContent48().getBytes());
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("015");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, operator.getBytes());
		Log4jUtil.info("msgPack.getFieldContent11() = " + msgPack.getFieldContent11());
		field61B = ArrayUtils.addAll(field61B, msgPack.getFieldContent11().getBytes());
		// field61B = ArrayUtils.addAll(field61B, "04".getBytes());
		// field61B = ArrayUtils.addAll(field61B, "中行中银卡".getBytes());
		// field61B = ArrayUtils.addAll(field61B, "中行信用卡".getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		// 原交易的信息类型代码+原交易系统跟踪号+原交易的交易日期
		byte[] field62B = ByteUtils.strToBcdRightSide("020");
		field62B = ArrayUtils.addAll(field62B, "0200".getBytes());
		// field62B = ArrayUtils.addAll(field62B, consumeMsgPack.getFieldContent11().getBytes());
		field62B = ArrayUtils.addAll(field62B, consumeMsgPack.getFieldContent11().getBytes());
		field62B = ArrayUtils.addAll(field62B, "0000000000".getBytes());// 冲正交易时原交易日期和时间送全0
		MsgPackUtils.createField62(msgPack, field62B);

		// 组装需要MAC加密的域
		final byte[] macData = packMacData(msgPack);
		MsgPackUtils.createMac(msgPack, macData, workKey);// MAC
		Log4jUtil.info("创建冲正报文结束");

		return msgPack;
	}

	/**
	 * 创建参数下载
	 * 
	 * @return
	 * @throws BizException
	 */
	public MsgPack createDownParameter() throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String currency = channelParms.get("100007");// 货币代码
		String batchNo = channelParms.get("100009");// 批次号
		String nii = channelParms.get("100017");// NII
		final MsgPack msgPack = new MsgPack();
		final String sn = sequenceManagerService.getBocCreditSN();

		createHeadMsg(msgPack);// 报文头
		MsgPackUtils.createMsgType(msgPack, "0800");// 消息类型
		MsgPackUtils.createField3(msgPack, "990000");// 交易处理码
		MsgPackUtils.createField11(msgPack, sn);// POS终端交易流水
		MsgPackUtils.createField24(msgPack, nii);// NII
		MsgPackUtils.createField41(msgPack, clinetCode);// 受卡机终端标识码
		MsgPackUtils.createField42(msgPack, merchant);// 受卡方标识码
		MsgPackUtils.createField49(msgPack, currency);// 交易货币代码

		// 组装61自定义域 ：批次号+操作员号+票据号
		byte[] field61B = ByteUtils.strToBcdRightSide("009");
		field61B = ArrayUtils.addAll(field61B, batchNo.getBytes());
		field61B = ArrayUtils.addAll(field61B, "090".getBytes());
		MsgPackUtils.createField61(msgPack, field61B);

		return msgPack;
	}

	/**
	 * 创建公共的8583报文头信息
	 * 
	 * @param msgPack
	 * @throws BizException
	 */
	public void createHeadMsg(final MsgPack msgPack) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String channelCode = channelParms.get("100010");// 渠道代码
		String fromAddress = channelParms.get("100011");// 源地址
		String toAddress = channelParms.get("100012");// 目地址
		MsgPackUtils.createTpduField(msgPack, ByteUtils.strToBcd("60" + toAddress + fromAddress));
		MsgPackUtils.createHeadField(msgPack, ByteUtils.strToBcd(channelCode));// 渠道代码
	}

	/**
	 * 向目标地址发送信息
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public MsgPack sendMsg(final MsgPack msgPack) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String socketIP = channelParms.get("100001"); // 中行socketIP
		String socketPort = channelParms.get("100002");// 中行socketPort
		// 加包头
		Log4jUtil.info("发送到" + channelName + "渠道的报文数据:" + ByteUtils.bcdToStr(msgPack.getBytes()));
		final SendBySocket sendBySocket = new SendBySocket();
		final MsgPack rspMsg = sendBySocket.sendAndRecv(socketIP, socketPort, msgPack.getBytes());
		// MAC校验
		if (!this.validateMac(rspMsg)) {
			if ("Y".equals(verifyFlag))// Y:验签
				throw new BizException(TransReturnCode.code_9109, "响应报文中的MAC校验错误,报文被篡改。");
		}
		return rspMsg;
	}

	/**
	 * 向目标地址发送信息 信用卡分期消费
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public MsgPack sendMsgForInstalments(final MsgPack msgPack) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String socketIP = channelParms.get("200001"); // 中行socketIP
		String socketPort = channelParms.get("200002");// 中行socketPort
		// 加包头
		Log4jUtil.info("发送到" + channelName + "渠道的报文数据:" + ByteUtils.bcdToStr(msgPack.getBytes()));
		final SendBySocket sendBySocket = new SendBySocket();
		final MsgPack rspMsg = sendBySocket.sendAndRecv(socketIP, socketPort, msgPack.getBytes());
		// MAC校验
		if (!this.validateMac(rspMsg)) {
			if ("Y".equals(verifyFlag))// Y:验签
				throw new BizException(TransReturnCode.code_9109, "响应报文中的MAC校验错误,报文被篡改。");
		}
		return rspMsg;
	}

	/**
	 * 组装需加密数据域为2,3,4,11,12,13,49,38,39,41
	 * 
	 * @param msgPack
	 * @return
	 * @throws BizException
	 */
	public byte[] packMacData(final MsgPack msgPack) throws BizException {

		final byte[] bitBin = msgPack.getBitmap();
		byte[] res = new byte[] {};
		if (bitBin != null && bitBin.length >= 64) {
			if (bitBin[1] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_2.getNo()).getOrigValue());
			}
			if (bitBin[2] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_3.getNo()).getOrigValue());
			}
			if (bitBin[3] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_4.getNo()).getOrigValue());
			}
			if (bitBin[10] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_11.getNo()).getOrigValue());
			}
			if (bitBin[11] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_12.getNo()).getOrigValue());
			}
			if (bitBin[12] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_13.getNo()).getOrigValue());
			}
			if (bitBin[48] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_49.getNo()).getOrigValue());
			}
			if (bitBin[37] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_38.getNo()).getOrigValue());
			}
			if (bitBin[38] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_39.getNo()).getOrigValue());
			}
			if (bitBin[40] == 1) {
				res = ArrayUtils.addAll(res, msgPack.getField(MsgFieldType.FIELD_41.getNo()).getOrigValue());
			}
		}
		Log4jUtil.info("需要加密的MAC数据长度为:" + res.length);

		return res;
	}

	/**
	 * 公共验证
	 * 
	 * @throws BizException
	 */
	private void validateField() throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String inputCode = channelParms.get("100003");// 服务点输入方式码
		String conCode = channelParms.get("100004");// 服务点条件码
		String clinetCode = channelParms.get("100005");// 终端代码
		String merchant = channelParms.get("100006");// 商户代码
		String currency = channelParms.get("100007");// 货币代码
		String operator = channelParms.get("100008");// 操作员代码
		String batchNo = channelParms.get("100009");// 批次号
		// 验证每个域的长度
		AssertUtils.checkLength(inputCode, "9303", channelName + "8583报文[22域]服务点输入方式码", 3, 3);
		AssertUtils.checkLength(conCode, "9303", channelName + "8583报文[25域]服务点条件码", 2, 2);
		AssertUtils.checkLength(clinetCode, "9303", channelName + "8583报文[41域]终端号", 1, 8);
		AssertUtils.checkLength(merchant, "9303", channelName + "8583报文[42域]商户代码", 1, 15);
		AssertUtils.checkLength(currency, "9303", channelName + "8583报文[49域]货币", 3, 3);
		AssertUtils.checkLength(batchNo, "9303", channelName + "8583报文[61.1域]批次号", 6, 6);
		AssertUtils.checkLength(operator, "9303", channelName + "8583报文[61.2域]操作员", 3, 3);
	}

	/**
	 * 校验响应报文中的MAC
	 * 
	 * @param rspMsg 消息包
	 * @return
	 * @throws BizException
	 */
	private boolean validateMac(final MsgPack rspMsg) throws BizException {
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		String workKey = channelParms.get("100014");// 商户工作密钥

		boolean result = false;
		final MsgField macField = rspMsg.getField(MsgFieldType.FIELD_64.getNo());

		// 如果MAC为空则，不需要验证MAC
		if (macField == null || macField.getStringValue() == null || "".equals(macField.getStringValue())) {
			return true;
		}
		Log4jUtil.info("银行返回的MAC值为:" + LoUtils.byte2HexStr(macField.getOrigMsg()));
		final byte[] macData = packMacData(rspMsg);

		final String mac = MacUtil.getMacData(workKey, macData);

		// 只比较MAC前四字节
		String macSubStr = "";
		if (mac.length() >= 8) {
			macSubStr = mac.substring(0, 8);
		}
		String recvMacSubStr = "";
		if (LoUtils.byte2HexStr(macField.getOrigMsg()).length() >= 8) {
			recvMacSubStr = LoUtils.byte2HexStr(macField.getOrigMsg()).substring(0, 8);
		}

		if (macSubStr.equalsIgnoreCase(recvMacSubStr)) {
			result = true;
		}

		return result;
	}
}
