/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-7 下午5:21:27
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.handler;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.credit.kft.processor.BocCreditDirectProcess;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.ClearingResult;
import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCancelDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompleteDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthCompletionCancelDTO;
import com.lycheepay.clearing.common.dto.preauth.PreAuthDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.RefundDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P> 中国银行信用卡银企清算服务入口类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午7:53:27
 */
@Service(ClearingAdapterAnnotationName.BOC_CREDIT_CHANNEL_SERVICE)
public class BocCreditChannelService extends AbstractChannelService {

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BOC_CREDIT_DIRECT_PROCESS)
	private BocCreditDirectProcess bocCreditDirectProcess;

	private static final String channelId = ChannelIdEnum.BOC_CREDIT_CARD.getCode();

	/* PS.实时代扣
	 * @see com.lycheepay.settlecore.app.common.service.channel.AbstractChannelService#directDeduct(com.lycheepay.settlecore.common.dto.DirectDeductChannelDTO)
	 * @author 张凯锋
	 */
	@Override
	public ClearingResultDTO directDeduct(final DeductDTO deductDTO) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "credit");
		Log4jUtil.info(deductDTO);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		param.setSn(deductDTO.getTxnId());
		param.setCardType(deductDTO.getBankCardType());
		param.setBorc(deductDTO.getAccountType());
		param.setBizBean(deductDTO);
		ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		ReturnState returnState;
		try {
			returnState = bocCreditDirectProcess.directDeduct(param);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, channelResultDTO);
		}

		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());

		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	/* (non-Javadoc)
	 * @see com.lycheepay.settlecore.app.common.service.channel.AbstractChannelService#autoRealtimeRefund(com.lycheepay.settlecore.common.dto.RefundChannelDTO)
	 * @author 张凯锋
	 */
	@Override
	public ClearingResultDTO autoRealtimeRefund(final RefundDTO refund) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "credit");
		Log4jUtil.info(refund);
		final Param param = new Param();
		param.setChannelId(channelId);
		param.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		param.setSn(refund.getTxnId());
		param.setBorc(refund.getBankCardType());
		param.setBizBean(refund);

		ClearingResultDTO channelResultDTO = new ClearingResultDTO();
		channelResultDTO.setChannelId(channelId);
		channelResultDTO.setClearingTransType(ClearingTransType.AUTO_REAL_TIME_REFUND);
		ReturnState returnState;
		try {
			returnState = bocCreditDirectProcess.autoRealRefund(param);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, channelResultDTO);
		}
		channelResultDTO.setChannelResponseCode(returnState.getChannelCode());
		channelResultDTO.setSettlementDate(returnState.getCheckDate());
		channelResultDTO.setChannelResponseMsg(returnState.getReturnMsg());
		channelResultDTO.setTxnStatus(returnState.getReturnState());

		Log4jUtil.info(channelResultDTO);
		return channelResultDTO;
	}

	/**
	 * <p>处理结帐与签到</p>
	 * 
	 * @author 张凯锋
	 */
	public void sign() {
		Log4jUtil.setLogClass("BOC", "creditSign");
		try {
			bocCreditDirectProcess.dealSignIn(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			Log4jUtil.info(DateUtil.getCurrentPrettyDateTime() + "中行信用卡渠道自动联机签到处理成功");
		} catch (final Exception e) {
			Log4jUtil.error(DateUtil.getCurrentPrettyDateTime() + "中行信用卡渠道自动联机签到处理失败", e);
		}
	}

	/**
	 * <p>分期处理结帐与签到</p>
	 * 
	 * @author 张凯锋
	 */
	public void signForInstalment() {
		Log4jUtil.setLogClass("BOC", "instalmentCreditSign");
		try {
			bocCreditDirectProcess.dealInstalmentSignIn(ChannelIdEnum.BOC_CREDIT_CARD.getCode());
			Log4jUtil.info(DateUtil.getCurrentPrettyDateTime() + "中行信用卡渠道分期付款专用签到处理成功");
		} catch (final Exception e) {
			Log4jUtil.error(DateUtil.getCurrentPrettyDateTime() + "中行信用卡渠道分期付款专用签到处理失败", e);
		}
	}

	/**
	 * 预授权
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#preAuth(com.lycheepay.clearing.common.dto.preauth.PreAuthDTO)
	 * @author 邱林 Leon.Qiu 2012-8-27 上午10:33:06
	 */
	@Override
	public ClearingResultDTO preAuth(PreAuthDTO preAuth) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "credit-preAuth");
		Log4jUtil.info(preAuth);
		ClearingResult result;
		ClearingResultDTO preAuthDTO = new ClearingResultDTO();
		try {
			result = bocCreditDirectProcess.preAuth(preAuth);
		} catch (final BizException e) {
			throw new ClearingAdapterBizCheckedException(BusinessCode.CHANNEL_EXCEPTION_INFO, null, e.getMessage());
		}
		Log4jUtil.info(result);
		BeanUtils.copyProperties(result, preAuthDTO);
		return preAuthDTO;
	}

	/**
	 * 预授权取消
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#preAuthCancel(com.lycheepay.clearing.common.dto.preauth.PreAuthCancelDTO)
	 * @author 邱林 Leon.Qiu 2012-8-27 上午10:33:17
	 */
	@Override
	public ClearingResultDTO preAuthCancel(PreAuthCancelDTO preAuthCancel) throws ClearingAdapterBizCheckedException {
		return null;
	}

	/**
	 * 预授权完成
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#preAuthComplete(com.lycheepay.clearing.common.dto.preauth.PreAuthCompleteDTO)
	 * @author 邱林 Leon.Qiu 2012-8-27 上午10:33:24
	 */
	@Override
	public ClearingResultDTO preAuthComplete(PreAuthCompleteDTO preAuthComplete)
			throws ClearingAdapterBizCheckedException {
		return null;
	}

	/**
	 * 预授权完成取消
	 * 
	 * @see com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService#preAuthCompletionCancel(com.lycheepay.clearing.common.dto.preauth.PreAuthCompletionCancelDTO)
	 * @author 邱林 Leon.Qiu 2012-8-27 上午10:33:31
	 */
	@Override
	public ClearingResultDTO preAuthCompletionCancel(PreAuthCompletionCancelDTO preAuthCompletionCancel)
			throws ClearingAdapterBizCheckedException {
		return null;
	}
}
