/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:35:19
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>通信链路探测交易响应</P>
 * 
 * @author 张凯锋
 */
public class A001Response extends ResponseHead {

	private String ehlo;

	public A001Response() {
		super();
	}

	public A001Response(final byte[] respBytes) throws BizException {
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respBytes);

		/*System.out.println(dom4jxml.getRoot().asXML());
		System.out.println(dom4jxml.getXmlDoc().asXML());
		System.out.println("======1========"+dom4jxml.getRoot().getNamespacePrefix());
		System.out.println("=======2======="+dom4jxml.getRoot().getNamespaceURI());
		
		System.out.println(dom4jxml.getXmlDoc().selectNodes("/A001_RESPONSE"));
		System.out.println(dom4jxml.getXmlDoc().selectSingleNode("//HEAD"));
		System.out.println(dom4jxml.getNode("//HEAD"));
		System.out.println(dom4jxml.getNode("//BODY"));
		*/
		final Node head = dom4jxml.getNode("/A001_RESPONSE/HEAD");
		setResponseHead(dom4jxml, head);
		final Node body = dom4jxml.getNode("/A001_RESPONSE/BODY");
		ehlo = dom4jxml.getNodeText(body, "EHLO");
	}

	public String getEhlo() {
		return ehlo;
	}

	public void setEhlo(final String ehlo) {
		this.ehlo = ehlo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * @author 张凯锋
	 */
	@Override
	public String toString() {
		return "A001Response [ehlo=" + ehlo + ", getResultCode()=" + getResultCode() + ", getResultDesc()="
				+ getResultDesc() + ", getSendTimestamp()=" + getSendTimestamp() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
