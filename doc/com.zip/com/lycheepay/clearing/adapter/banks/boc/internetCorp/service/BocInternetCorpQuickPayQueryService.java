/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-29 上午10:16:54
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.service;

import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayQueryRequestBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayQueryResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayQueryResponseDetailBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpTransStatusQueryRequestBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpTransStatusQueryResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpHttpPostMessages;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpRequestMessagesConverter;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpResponseMessageConverter;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.BatchProcessResultNotice;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelBatchService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.ChannelBatch;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行网上银企快捷代发业务查询</P>
 * 
 * @author #{杜波(15999653650)}
 */
@Service
public class BocInternetCorpQuickPayQueryService {
	@Autowired
	private ChannelBatchService channelBatchService;
	@Autowired
	private BillnoSnService billnoSnService;
	@Autowired
	private ChannelParmService channelParmService;
	@Autowired
	private BatchProcessResultNotice batchProcessResultNotice;
	@Autowired
	private BocInternetCorpSignInService bocInternetCorpSignInService;
	@Autowired
	private BocInternetCorpRequestMessagesConverter requestMessagesConverter;
	@Autowired
	private BocInternetCorpResponseMessageConverter responseMessageConverter;
	@Autowired
	private BocInternetCorpHttpPostMessages bocInternetCorpHttpPostMessages;
	@Autowired
	private BocInternetCorpTransStatusQueryService bocInternetCorpTransStatusQueryService;

	// 银行等交易序列
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager sequenceManager;

	/**
	 * 
	 * <p>获取中国银行网上银企快捷代发业务查询信息</p>
	 * 
	 * @param requestBean
	 * @return
	 * @author #{杜波(15999653650)}
	 * @throws BizException
	 */
	public void getQuickPayInfo() throws ClearingAdapterBizCheckedException {

		BocInternetCorpQuickPayQueryRequestBean queryRequestBean = new BocInternetCorpQuickPayQueryRequestBean();
		BocInternetCorpQuickPayQueryResponseBean queryResponseBean = new BocInternetCorpQuickPayQueryResponseBean();
		BocInternetCorpTransStatusQueryRequestBean transStatusQueryRequestBean = new BocInternetCorpTransStatusQueryRequestBean();
		BocInternetCorpTransStatusQueryResponseBean transStatusQueryResponseBean = new BocInternetCorpTransStatusQueryResponseBean();
		List<ChannelBatch> batchList = channelBatchService.getCorpBatchList(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
		
		Log4jUtil.info(" 获取中行网上银企参数");
		Map<String, String> channelParamMap = channelParmService.queryCodeParamsMapByChannelId(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());

		if (batchList != null && batchList.size() > 0) {
			Log4jUtil.info("batchList：" + batchList);
			for (int i = 0; i < batchList.size(); i++) {
				ChannelBatch channelBatch = batchList.get(i);
				
				//分组查询次数，中行快捷代发查询每次最多能查500笔
				int cycleNum = 1;
				//本次查询的交易起始位置
				Long beginNum = 1L;
				//查询记录数
				Long endNum = 1L;
				
				//中行快捷代发查询每次最多能查500笔，中行快捷代发每次最多能代发1000笔，所以分组查询最多两次就够了
				if(channelBatch.getTotalnum()<=500){
					endNum = channelBatch.getTotalnum();
				}else{
					cycleNum = 2;
					endNum = 500L;
				}
				
				//根据批次信息(channelBatch.getTotalnum())决定分次发送报文
				for(int j=0;j<cycleNum;j++){
					if(j!=0){
						beginNum = 501L;
						endNum = channelBatch.getTotalnum()-500L;
					}
					// 组装快捷代发业务查询Bean
					if (channelBatch.getBankBatchid() != null && channelBatch.getBankBatchid().length() > 0) {
						queryRequestBean.setObssid(channelBatch.getBankBatchid().split("#")[0]);
						queryRequestBean.setInsid(channelBatch.getBankBatchid().split("#")[1]);
						queryRequestBean.setBegnum(beginNum.toString());
						queryRequestBean.setRecnum(endNum.toString());
					} else {
						Log4jUtil.error(channelBatch.getId().getChannelBatchid() + "--Obssid&Insid有误！"+ channelBatch.getBankBatchid());
						continue;
					}

					channelParamMap.put("trnId", sequenceManager.getBocInternetCorpSn());
					
					//做快捷代发业务查询之前，先对交易状态进行查询
					transStatusQueryRequestBean.setInsid(channelBatch.getBankBatchid().split("#")[1]);
					transStatusQueryRequestBean.setObssid(channelBatch.getBankBatchid().split("#")[0]);
					transStatusQueryResponseBean = bocInternetCorpTransStatusQueryService.getTransStatusQueryMsg(transStatusQueryRequestBean, channelParamMap);
					if(transStatusQueryResponseBean!=null){
						if(!"B001".equalsIgnoreCase(transStatusQueryResponseBean.getSubRspcod())){
							Log4jUtil.error("中国银行网上银企交易状态查询信息----"+ transStatusQueryResponseBean.getSubRspmsg());
							break;
						}
					}else{
						Log4jUtil.error("中国银行网上银企交易状态查询信息有误！ ----"+ channelBatch.getBankBatchid());
						break;
					}
					
					
					// 组装查询报文
					Log4jUtil.info("组装查询报文");
					String sendMsg = requestMessagesConverter.getBocInternetCorpQuickPayQueryReqestXml(queryRequestBean,channelParamMap);

					// 发送快捷代发业务查询报文
					Log4jUtil.info("发送快捷代发业务查询报文");
					String receiveMessages;
					try {
						receiveMessages = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendMsg,channelParamMap.get("100006"));
					} catch (Exception e) {
						Log4jUtil.error("发送快捷代发业务查询报文有误！", e);
						continue;
					}

					// 解析响应报文，根据响应报文转换为对应的响应Bean
					Log4jUtil.info("解析查询响应报文，根据响应报文转换为对应的响应Bean");
					queryResponseBean = responseMessageConverter.getBocInternetCorpQuickPayQueryResponseMessage(receiveMessages.getBytes(Charset.forName("UTF-8")));
					if (queryResponseBean != null) {
						//判断是否是由于未签到导致交易失败，如果是，则需要进行签到并重新交易
						if (queryResponseBean.getRspcod() != null
								&& channelParamMap.get("100012").indexOf(queryResponseBean.getRspcod()) >= 0) {
							BocInternetCorpSignInResponseBean signInResponseBean = bocInternetCorpSignInService
									.bocInternetCorpSignIn();
							if ("B001".equalsIgnoreCase(signInResponseBean.getRspCod())) {

								// 重发当前报文
								try {
									receiveMessages = bocInternetCorpHttpPostMessages.sendHttpPostMessages(sendMsg,
											channelParamMap.get("100006"));
								} catch (Exception e) {
									Log4jUtil.error("发送快捷代发业务查询报文有误！", e);
									continue;
								}
								queryResponseBean = responseMessageConverter
										.getBocInternetCorpQuickPayQueryResponseMessage(receiveMessages
												.getBytes(Charset.forName("UTF-8")));
							} else {
								throw new BizException(TransReturnCode.code_9108, "中行网上银企签到失败！");
							}
						}
						List<BocInternetCorpQuickPayQueryResponseDetailBean> list = queryResponseBean.getList();
						if (list != null && list.size() > 0) {
							// 检查批总比数与实际解析出的笔数是否一致
							if (queryResponseBean.getPybnum() != null && queryResponseBean.getPybnum().length() > 0) {
								int totalNum = Integer.parseInt(queryResponseBean.getPybnum());
								if (totalNum != list.size()) {
									Log4jUtil.error("批总笔数与实际解析的数量不一致，Pybnum:" + queryResponseBean.getPybnum()+ ",list.size:" + list.size());
									continue;
								} else if (list.size() == 1) {
									BocInternetCorpQuickPayQueryResponseDetailBean queryResponseDetailBean = list
											.get(0);
									if ("B207".equalsIgnoreCase(queryResponseDetailBean.getRspcod())) {
										Log4jUtil.error("该批次代收代发业务尚未成功，bankBatchid:" + channelBatch.getBankBatchid());
										continue;
									} else {
										// 根据响应报文更新批量交易渠道批次表(channel_batch)与渠道交易流水对照表(billno_sn)
										Log4jUtil.info("根据响应报文更新批量交易渠道批次表(channel_batch)与渠道交易流水对照表(billno_sn)");
										this.updateTransState(queryResponseBean, channelBatch);
									}
								} else {
									// 根据响应报文更新批量交易渠道批次表(channel_batch)与渠道交易流水对照表(billno_sn)
									Log4jUtil.info("根据响应报文更新批量交易渠道批次表(channel_batch)与渠道交易流水对照表(billno_sn)");
									this.updateTransState(queryResponseBean, channelBatch);
								}
							}
						}else{
							Log4jUtil.error("queryResponseBean.getList()为空，后续不做任何处理");
						}
					} else {
						Log4jUtil.error("报文转换的queryResponseBean为空，后续不做任何处理");
					}
				}
			}
		}
	}

	/**
	 * <p>根据响应报文更新批量交易渠道状态</p>
	 * 
	 * @param batchDeductChannelDTO
	 * @param queryResponseBean
	 * @param channelBatch
	 * @param receiveMessages
	 * @return
	 * @author #{杜波(15999653650)}
	 * @throws BizException
	 */
	@Transactional
	public void updateTransState(BocInternetCorpQuickPayQueryResponseBean queryResponseBean, ChannelBatch channelBatch)
			throws BizException {
		// 根据响应报文更新批量交易渠道批次表(channel_batch)与渠道交易流水对照表(billno_sn)
		if (queryResponseBean != null) {
			List<BocInternetCorpQuickPayQueryResponseDetailBean> list = queryResponseBean.getList();
			if (list != null && list.size() > 0) {
				Log4jUtil.info("结果list:" + list.size());
				BillnoSn billnoSn = new BillnoSn();
				Long sucessnum = 0L;
				Double sucessamount = 0D;
				Long unsucessnum = 0L;
				Double unsucessamount = 0D;
				for (BocInternetCorpQuickPayQueryResponseDetailBean queryResponseDetail : list) {
					String responseCode = queryResponseDetail.getRspcod();
					String billnosnSeq = queryResponseDetail.getFurinfo();
					billnoSn.setBillnosnSeq(billnosnSeq);
					Log4jUtil.info("更新billno_sn表billnosnSeq：" + billnosnSeq);
					// 更新billno_sn状态
					if ("B001".equalsIgnoreCase(responseCode)) {
						billnoSn.setPayState("1");// 成功1 失败2
						sucessnum++;
						sucessamount += Double.parseDouble(queryResponseDetail.getPydamt());
					} else {
						unsucessnum++;
						unsucessamount += Double.parseDouble(queryResponseDetail.getPydamt());
						billnoSn.setPayState("2");// 成功1 失败2
					}
					billnoSn.setState(BillnoSnState.billnoRecv);
					billnoSn.setChannelRtncode(responseCode);
					billnoSn.setChannelRtnnote(queryResponseDetail.getRspmsg());
					billnoSn.setActualAmount(new BigDecimal(queryResponseDetail.getPydamt()));
					billnoSn.setRecvTime(new Date());
					billnoSnService.update(billnoSn);
				}
				batchProcessResultNotice.process(ChannelIdEnum.BOC_CREDIT_REPAY.getCode(), channelBatch.getId()
						.getChannelBatchid(), ClearingTransType.BATCH_PAY, sucessnum, sucessamount, unsucessnum,
						unsucessamount);
			} else {
				Log4jUtil.info("结果list:空");
				BillnoSn billnoSn = new BillnoSn();
				billnoSn.setState(BillnoSnState.billnoRecv);
				billnoSn.setChannelRtncode(queryResponseBean.getRspcod());
				billnoSn.setChannelRtnnote(queryResponseBean.getRspmsg());
				billnoSn.setRecvTime(new Date());
				billnoSn.setChannelid(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
				billnoSn.setChannelBatchno(channelBatch.getId().getChannelBatchid());
				billnoSn.setPayState("2");// 成功1 失败2
				billnoSnService.updateByChannelidAndChannelBatchno(billnoSn);
				Log4jUtil.info("所有失败后更新：" + billnoSn);
				batchProcessResultNotice.process(ChannelIdEnum.BOC_CREDIT_REPAY.getCode(), channelBatch.getId()
						.getChannelBatchid(), channelBatch.getTranType(), 0l, 0d, channelBatch.getTotalnum(),
						channelBatch.getTotalamount());
			}
		}
	}

}
