/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import org.soofa.core.model.BaseObject;

/**
 * 
 * <P>
 * 中国银行银企签退回应参数
 * </P>
 * 
 * @author #{杜波(15999653650)}
 */
public class BocInternetCorpSignInResponseBean extends BaseObject {

	private static final long serialVersionUID = -2806919287252730218L;
	
	/**
	 * 企业前置机ID
	 */
	private String termId;
	
	/**
	 * 客户端产生的报文编号
	 */
	private String trnId;
	
	/**
	 * 企业在中行网银系统的客户编码
	 */
	private String custId;
	
	/**
	 * 企业操作员代码
	 */
	private String cusOpr;
	
	/**
	 * 交易代码
	 */
	private String trnCod;
	
	/**
	 * 交易验证标识，签到时返回
	 */
	private String token;
	
	/**
	 * 服务端响应代码
	 */
	private String rspCod;
	
	/**
	 * 服务端错误信息
	 */
	private String errMsg;
	
	/**
	 * 服务端日期时间，YYYYMMDDHH24MISS
	 */
	private String serverDt;

	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public String getTrnId() {
		return trnId;
	}

	public void setTrnId(String trnId) {
		this.trnId = trnId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCusOpr() {
		return cusOpr;
	}

	public void setCusOpr(String cusOpr) {
		this.cusOpr = cusOpr;
	}

	public String getTrnCod() {
		return trnCod;
	}

	public void setTrnCod(String trnCod) {
		this.trnCod = trnCod;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRspCod() {
		return rspCod;
	}

	public void setRspCod(String rspCod) {
		this.rspCod = rspCod;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	public String getServerDt() {
		return serverDt;
	}

	public void setServerDt(String serverDt) {
		this.serverDt = serverDt;
	}

}
