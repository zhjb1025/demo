package com.lycheepay.clearing.adapter.banks.boc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;


/**
 * 63域.
 * 
 * @author aps-txy
 */
public class Field62 {
	private final byte[] value;
	private String str62_1;// 信息类型码 N4
	private String str62_2;// 系统跟踪号 N6
	private String str62_3;// 交易日期和时间 N10

	public Field62(final byte[] bcdValue) throws BizException {
		AssertUtils.notNull(bcdValue, "未指定域值");

		this.value = ByteUtils.bcdToStr(bcdValue).getBytes();
	}

	/**
	 * 信息类型码, 解码值第1位开始取4位.
	 * 
	 * @return
	 */
	public String get62_1() {
		if (str62_1 != null) {
			return str62_1;
		}

		final int startPos = 0;
		final int endPos = startPos + 4;
		str62_1 = new String(ArrayUtils.subarray(value, startPos, endPos));

		return str62_1;
	}

	/**
	 * 系统跟踪号, 解码值第5位开始取6位.
	 * 
	 * @return
	 */
	public String get62_2() {
		if (str62_2 != null) {
			return str62_2;
		}

		final int startPos = 4;
		final int endPos = startPos + 6;
		str62_2 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str62_2;
	}

	/**
	 * 交易日期和时间, 解码值第11位开始取10位.
	 * 
	 * @return
	 */
	public String get62_3() {
		if (str62_3 != null) {
			return str62_3;
		}

		final int startPos = 10;
		final int endPos = startPos + 10;
		str62_3 = new String(ArrayUtils.subarray(value, startPos, endPos));
		return str62_3;
	}
}
