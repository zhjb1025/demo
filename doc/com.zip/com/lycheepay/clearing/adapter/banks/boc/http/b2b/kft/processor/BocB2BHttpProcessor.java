package com.lycheepay.clearing.adapter.banks.boc.http.b2b.kft.processor;

//package com.lycheepay.clearing.adapter.banks.boc.b2b.kft.processor;
//
//import java.security.GeneralSecurityException;
//import java.util.HashMap;
//import java.util.Map;
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//
//import com.bocnet.common.security.PKCS7Tool;
//import com.lycheepay.clearing.adapter.banks.boc.b2b.bank.bean.BocB2BOrder;
//import com.lycheepay.clearing.adapter.banks.boc.b2b.bank.util.BocB2BUtil;
//import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
//import com.lycheepay.clearing.adapter.common.constant.biz.ChannelTransType;
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.channel.http.HttpParam;
//import com.lycheepay.clearing.adapter.common.model.channel.http.HttpReturnParam;
//import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
//import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
//import com.lycheepay.clearing.adapter.common.service.biz.PayChannelService;
//import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
//import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
//import com.lycheepay.clearing.common.constant.ChannelId;
//import com.lycheepay.clearing.util.DateUtil;
//import com.lycheepay.clearing.util.Log4jUtil;
//
//
///**
// * 中行B2B网银Http请求处理器 <p> Copyright: Copyright (c) 2011 </p> <p> Company: 雁联 </p>
// * 
// * @author aps-qjy
// * @version 1.0
// */
//public class BocB2BHttpProcessor {
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
//	private BillnoSnService billnoSnService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
//	private ChannelParmService channelParmService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
//	private SequenceManagerService sequenceManagerService;
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.PAY_CHANNEL_SERVICE)
//	private PayChannelService payChannelService;
//
//	public HttpReturnParam process(final HttpParam httpParam) throws BizException {
//		String channelId = "";
//		String logMsg = "";
//		Map<String, String> channelParm = new Map<String, String>();
//		channelId = httpParam.getChannelId();
//		final String logPrefix = channelId + " " + ChannelId.getNameByValue(channelId);
//		logMsg = "进入  " + logPrefix + " 渠道Http业务处理.";
//		Log4jUtil.info(logMsg);
//		channelParm = channelParmService.getChannelParam(channelId);
//		if (channelParm == null) {
//			Log4jUtil.error("无法获取" + channelId + ChannelId.getNameByValue(channelId) + "渠道参数配置!");
//			throw new BizException("无法获取" + logPrefix + "渠道参数配置!");
//		}
//		final String transType = httpParam.getTransType(); // 获取交易类型
//		final String channelTransType = httpParam.getChannelTransType(); // 获取渠道交易类型
//		if (httpParam.getChannelTransType().equals(ChannelTransType.Net_Bank_Pay)) {
//			if (transType.equals(TransType.Direct_Pay) || transType.equals(TransType.Guarantee_Pay)
//					|| transType.equals(TransType.Recharge)) {
//				return deal(httpParam, channelParm);
//			}
//			throw new BizException(logPrefix + " 交易类型错误: " + "渠道交易类型(" + channelTransType, "), 交易类型(" + transType + ")");
//		} else {
//			throw new BizException(logPrefix + " 渠道交易类型错误: " + "渠道交易类型(" + channelTransType, "), 交易类型(" + transType
//					+ ")");
//		}
//	}
//
//	/**
//	 * 中行B2B支付处理
//	 * 
//	 * @param httpParam Http参数
//	 * @param channelParm 渠道参数
//	 * @return HTTP调用时返回的参数
//	 * @throws BizException
//	 */
//	private HttpReturnParam deal(final HttpParam httpParam, final Map<String, String> channelParm)
//			throws BizException {
//		final String channelId = httpParam.getChannelId();
//		final String logPrefix = channelId + " " + ChannelId.getNameByValue(channelId);
//		Log4jUtil.info("进入" + logPrefix + "支付处理");
//		final String bankSendSn = sequenceManagerService.getBocChannelSN(DateUtil.getCurrentDate());
//		final BocB2BOrder bocB2BOrder = new BocB2BOrder();
//		final Paybill paybill = (Paybill) httpParam.getBizBean();
//
//		bocB2BOrder.setBocNo(channelParm.get("100001"));
//		bocB2BOrder.setOrderNo(bankSendSn);
//		bocB2BOrder.setCurCode(channelParm.get("100008")); // "001"
//		final java.text.DecimalFormat df = new java.text.DecimalFormat("0.00");// "00.00"小数点后面的0的个数表示小数点的个数
//		bocB2BOrder.setOrderAmount(df.format(paybill.getChannelAmount()));
//		bocB2BOrder.setOrderTime(DateUtil.getCurrentDateTime());
//		bocB2BOrder.setOrderUrl(channelParm.get("100003"));
//		bocB2BOrder.setOrderNote(paybill.getSn());
//		final String toBeSignedData = bocB2BOrder.getToBeSignedData();
//		Log4jUtil.info("要加签的数据为: " + toBeSignedData);
//
//		// 对发送数据加签
//		try {
//			final String keyStorePath = channelParm.get("100004");
//			final String keyStorePassword = channelParm.get("100005");
//			final String keyPassword = channelParm.get("100007");
//			final PKCS7Tool pkcs = PKCS7Tool.getSigner(keyStorePath, keyStorePassword, keyPassword);
//			bocB2BOrder.setSignData(pkcs.sign(toBeSignedData.getBytes()));
//			Log4jUtil.info("中行B2B数据签名: " + bocB2BOrder.getSignData());
//		} catch (final GeneralSecurityException e) {
//			Log4jUtil.error("中行B2B数据签名失败: GeneralSecurityException");
//			throw new BizException("中行B2B签名失败(GeneralSecurityException), 请查看中行B2B配置 是否正确!");
//		} catch (final Exception e) {
//			Log4jUtil.error("中行B2B数据签名失败, 请查看中行B2B配置 是否正确");
//			throw new BizException("中行B2B签名失败, 请查看中行B2B配置 是否正确!");
//		}
//
//		AssertUtils.notNull(bocB2BOrder.getBocNo(), "中行B2B渠道商户号获取失败");
//		AssertUtils.notNull(bocB2BOrder.getOrderNo(), "中行B2B渠道生成订单号失败,请查看数据库中是否有BOC_CHANNEL_SN的序列!");
//
//		Map<String, String> params = new HashMap<String, String>();
//		try {
//			params = BocB2BUtil.creatBocB2BOrderParam(bocB2BOrder);
//
//		} catch (final Exception e) {
//			throw new BizException("根据中行B2B订单实体，创建发送参数失败!");
//		}
//
//		final HttpReturnParam httpRtnParam = new HttpReturnParam();
//		httpRtnParam.setAction(channelParm.get("100002")); // https://ebspay.boc.cn:443/PGWProtal/B2BRecvOrder.do
//		httpRtnParam.setParams(params);
//
//		billnoSnService.save(logPrefix, bankSendSn, httpParam);
//		Log4jUtil.info(paybill.getSn() + " 支付流水,保存到渠道流水表成功!");
//		Log4jUtil.info("中行网银B2B http请求处理器 [写交易流水和渠道流水对照表]结束");
//
//		return httpRtnParam;
//	}
// }
