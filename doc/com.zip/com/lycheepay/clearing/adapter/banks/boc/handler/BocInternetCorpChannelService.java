/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-26 下午3:19:36
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.service.BocInternetCorpQuickPayQueryService;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.service.BocInternetCorpQuickPayService;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.service.BocInternetCorpSignInService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;
/**
 * 
 * <P>中国银行网上银企业务</P>
 * @author 杜波(15999653650)
 */
@Service(ClearingAdapterAnnotationName.BOC_INTERNET_CORP_CHANNEL_SERVICE)
public class BocInternetCorpChannelService extends AbstractChannelService {
	
	@Autowired
	private BocInternetCorpSignInService bocInternetCorpSignInService;
	@Autowired
	private BocInternetCorpQuickPayService bocInternetCorpQuickPayService;
	@Autowired
	private BocInternetCorpQuickPayQueryService bocInternetCorpQuickPayQueryService;
	/**
	 * <p>中国银行网上银企签到 定时触发</p>
	 * @author 杜波(15999653650)
	 * @throws BizException 
	 */
	public void sign() throws BizException {
		Log4jUtil.setLogClass("BOC", "InternetCorp");
		Log4jUtil.info("签到开始。。");
		bocInternetCorpSignInService.bocInternetCorpSignIn();
		Log4jUtil.info("签到结束。。");
	}
	@Override
	public int getMaxNum() {
		return 1000;
	}
	/**
	 * <p>中国银行网上银企快捷代发</p>
	 * @author 杜波(15999653650)
	 * @throws BizException 
	 */
	@Override
	public BatchSendResult processBatch(String channelBatchId, List<ChannelTempBill> payList, boolean repeatSend)throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "InternetCorpProcessBatch");
		BatchSendResult batchSendResult = null;
		try {
			batchSendResult = bocInternetCorpQuickPayService.bocInternetCorpBatchPay(channelBatchId, payList);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, batchSendResult);
		}
		return batchSendResult;
	}
	/**
	 * <p>中国银行网上银企快捷代发查询 定时触发</p>
	 * @author 杜波(15999653650)
	 * @throws BizException 
	 */
	@Override
	public void timeQueryBatchTransResult() throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("BOC", "InternetTimeQueryBatchTransResult");
		try {
			Log4jUtil.info("timeQueryBatchTransResult开始。。");
			bocInternetCorpQuickPayQueryService.getQuickPayInfo();
			Log4jUtil.info("timeQueryBatchTransResult结束。。");
		} catch (ClearingAdapterBizCheckedException e) {
			Log4jUtil.error(e);
			throw e;
		}
	}

	/**
	 * 获取账户余额
	 * 
	 * @return
	 * @author 张凯锋
	 */
	public Balance queryBanlance() {
		Balance balance = null;
		try {
			balance = bocInternetCorpSignInService.queryBanlance(null);
		} catch (BizException e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}
	
	public Balance queryBanlance(String accountNo) {
		Balance balance = null;
		try {
			balance = bocInternetCorpSignInService.queryBanlance(accountNo);
		} catch (BizException e) {
			Log4jUtil.error(e);
			balance = new Balance();
			balance.setErrorMsg(e.getMessage());
		}
		return balance;
	}

	/**
	 * 获取账户历史明细
	 * 
	 * @param date 查询日期
	 * @param accountNo 账号 ，如果过没有，默认为该渠道结算账户
	 * @param filePath 明细文件保存路径,比如//home/admin/sharedata/recon/historyDetail/
	 * @return
	 * @author 张凯锋
	 */
	public String queryAccountHistoryTransDetail(String date, String accountNo, String filePath) {
		String queryResult = null;
		try {
			queryResult = bocInternetCorpQuickPayService.queryAccountHistoryTransDetail(date, accountNo, filePath);
		} catch (BizException e) {
			Log4jUtil.error(e);
			queryResult = e.getMessage();
		}
		return queryResult;
	}
}
