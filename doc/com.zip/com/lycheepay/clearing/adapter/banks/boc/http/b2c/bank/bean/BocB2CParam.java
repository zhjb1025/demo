package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

public class BocB2CParam {
	private String payUrl;	 // 中行B2C支付跳转
	private String nKeyAdd;  // 中行B2C公钥位置
	private String pKeyAdd;  // 中行B2C银行私钥位置
	private String keyPass;	 // 中行B2C快付通商户私钥密码
	private String retUrl;  // 中行B2C处理结果返回的URL
	private String keyStorePass;  // 中行B2C证书密码
	private String queryOrderUrl;  // 中行B2C订单查询跳转
	private String className;  // 中行B2C接口内部实现类名
	private String payType;  // 中行B2C商户支付服务类型 1：网上购物 2：基金直销
	private String curCode;  // 中行B2C交易币种
	private String refundOrderUrl;  // 中行B2C退款申请跳转
	private String dn;				 // 中行证书DN

	public String getPayUrl() {
		return payUrl;
	}

	public void setPayUrl(final String payUrl) {
		this.payUrl = payUrl;
	}

	public String getNKeyAdd() {
		return nKeyAdd;
	}

	public void setNKeyAdd(final String keyAdd) {
		nKeyAdd = keyAdd;
	}

	public String getPKeyAdd() {
		return pKeyAdd;
	}

	public void setPKeyAdd(final String keyAdd) {
		pKeyAdd = keyAdd;
	}

	public String getKeyPass() {
		return keyPass;
	}

	public void setKeyPass(final String keyPass) {
		this.keyPass = keyPass;
	}

	public String getRetUrl() {
		return retUrl;
	}

	public void setRetUrl(final String retUrl) {
		this.retUrl = retUrl;
	}

	public String getKeyStorePass() {
		return keyStorePass;
	}

	public void setKeyStorePass(final String keyStorePass) {
		this.keyStorePass = keyStorePass;
	}

	public String getQueryOrderUrl() {
		return queryOrderUrl;
	}

	public void setQueryOrderUrl(final String queryOrderUrl) {
		this.queryOrderUrl = queryOrderUrl;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(final String className) {
		this.className = className;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(final String payType) {
		this.payType = payType;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(final String curCode) {
		this.curCode = curCode;
	}

	public String getRefundOrderUrl() {
		return refundOrderUrl;
	}

	public void setRefundOrderUrl(final String refundOrderUrl) {
		this.refundOrderUrl = refundOrderUrl;
	}

	public String getDn() {
		return dn;
	}

	public void setDn(final String dn) {
		this.dn = dn;
	}
}
