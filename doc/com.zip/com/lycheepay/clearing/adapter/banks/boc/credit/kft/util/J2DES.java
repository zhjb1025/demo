package com.lycheepay.clearing.adapter.banks.boc.credit.kft.util;

import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 双倍长密钥算法
 * 
 * @author aps-txy
 * @date 2011-11-1
 */
public class J2DES {

	static String DES = "DES/ECB/NoPadding";
	static String TriDes = "DESede/ECB/NoPadding";

	public static byte[] des_crypt(final byte key[], final byte data[]) {

		try {
			final KeySpec ks = new DESKeySpec(key);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(DES);
			c.init(Cipher.ENCRYPT_MODE, ky);
			return c.doFinal(data);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}
	}

	public static byte[] des_decrypt(final byte key[], final byte data[]) {

		try {
			final KeySpec ks = new DESKeySpec(key);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(DES);
			c.init(Cipher.DECRYPT_MODE, ky);
			return c.doFinal(data);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}
	}

	/**
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 */
	public static byte[] trides_crypt(final byte key[], final byte data[]) {
		try {
			final byte[] k = new byte[24];

			int len = data.length;
			if (data.length % 8 != 0) {
				len = data.length - data.length % 8 + 8;
			}
			byte[] needData = null;
			if (len != 0) {
				needData = new byte[len];
			}
			for (int i = 0; i < len; i++) {
				needData[i] = 0x00;
			}

			System.arraycopy(data, 0, needData, 0, data.length);

			if (key.length == 16) {
				System.arraycopy(key, 0, k, 0, key.length);
				System.arraycopy(key, 0, k, 16, 8);
			} else {
				System.arraycopy(key, 0, k, 0, 24);
			}

			final KeySpec ks = new DESedeKeySpec(k);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(TriDes);
			c.init(Cipher.ENCRYPT_MODE, ky);
			return c.doFinal(needData);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}

	}

	/**
	 * 双倍长密钥算法
	 * 
	 * @param key
	 * @param data
	 * @return
	 */
	public static byte[] trides_decrypt(final byte key[], final byte data[]) {
		try {
			final byte[] k = new byte[24];

			int len = data.length;
			if (data.length % 8 != 0) {
				len = data.length - data.length % 8 + 8;
			}
			byte[] needData = null;
			if (len != 0) {
				needData = new byte[len];
			}
			for (int i = 0; i < len; i++) {
				needData[i] = 0x00;
			}

			System.arraycopy(data, 0, needData, 0, data.length);

			if (key.length == 16) {
				System.arraycopy(key, 0, k, 0, key.length);
				System.arraycopy(key, 0, k, 16, 8);
			} else {
				System.arraycopy(key, 0, k, 0, 24);
			}
			final KeySpec ks = new DESedeKeySpec(k);
			final SecretKeyFactory kf = SecretKeyFactory.getInstance("DESede");
			final SecretKey ky = kf.generateSecret(ks);

			final Cipher c = Cipher.getInstance(TriDes);
			c.init(Cipher.DECRYPT_MODE, ky);
			return c.doFinal(needData);
		} catch (final Exception e) {
			Log4jUtil.error(e);
			return null;
		}

	}

	public static byte[] hexToBytes(final String str) {
		if (str == null) {
			return null;
		} else if (str.length() < 2) {
			return null;
		} else {
			final int len = str.length() / 2;
			final byte[] buffer = new byte[len];
			for (int i = 0; i < len; i++) {
				buffer[i] = (byte) Integer.parseInt(str.substring(i * 2, i * 2 + 2), 16);
			}
			return buffer;
		}
	}

	public static void main(final String[] args) {

		final byte[] b = des_crypt(LoUtils.hexStr2Bytes("FED3E075587FEC26"), LoUtils.hexStr2Bytes("F8A2022A61135EB6"));

		System.out.println(LoUtils.byte2HexStr(b));

	}
}
