/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.biz.RunTime;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.TransReturnCode.TransReturnCodeEnum;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.StringUtil;



/**
 * <P>中国银行网上银企Socket方式发送</P>
 * @author #{杜波(15999653650)}
 */
@Service
public class BocInternetCorpSocketMessages {
	private int timeout = 60000;         // 单位毫秒，6000。 业务交易超时，用于传输数据时
	private int connectOutTime = 60000;  // 单位毫秒，6000。 用于刚开始建立链接时,一般不需要改变此值
	private int maxTryTime = 3;
	private int currentTryTime = 0;

	public int getConnectOutTime() {
		return connectOutTime;
	}

	public void setConnectOutTime(int connectOutTime) {
		this.connectOutTime = connectOutTime;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * 
	 * <p>
	 * 通过Socket发送报文并取得回执
	 * </p>
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg
	 * @return
	 * @throws BizException
	 * @author #{杜波(15999653650)}
	 */
	public byte[] sendAndReceiveMessagesBySocket(String socketIp, String socketPort, byte[] sendMsg) throws ClearingAdapterBizCheckedException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg:" + new String(sendMsg,StringUtil.GBK));
		Socket socket = null;
		BufferedOutputStream dos = null;// 发送值
		RunTime time = new RunTime();
		socket = this.establishConnect(socketIp, socketPort);
		try {
			time.endAndStart("Socket链接耗时:");
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(sendMsg);
			dos.flush();
			time.endAndStart("Socket发送耗时:");
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			this.disconnect(socket);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108, TransReturnCode.code_9108 + e.getMessage());
			// throw new BizException(e, "发送报文数据出错" + e.getMessage());
		}
		try {
			BufferedInputStream bf = new BufferedInputStream(socket.getInputStream());
			byte[] byteLengths = new byte[4];
			bf.read(byteLengths, 0, 4);// 前四位为报文长度
			Log4jUtil.info("返回报文长度：" + StringUtil.byteToString(byteLengths));
			if (!StringUtil.isNumeric(StringUtil.byteToString(byteLengths))) {
				Log4jUtil.info("错误的报文。");
				throw new BizException(TransReturnCode.code_9109, TransReturnCodeEnum.code_9109.getDesc() + " 错误的报文长度。");
			}
			int msgLength = Integer.parseInt(StringUtil.byteToString(byteLengths));// 报文长度
			int i = 0;// 写到contents里面的偏移量
			byte[] contents = new byte[msgLength];
			while (i < msgLength) {
				Log4jUtil.info("第：" + (i + 1) + "次读取报文。");
				int offLength = msgLength - i;
				int readBytes = bf.read(contents, i, offLength);// 读到的真实长度
				i = i + readBytes;
			}
			time.endAndStart("Socket接收耗时:");
			Log4jUtil.info("Socket中得到的返回报文内容：" + StringUtil.byteToString(byteLengths) + StringUtil.byteToString(contents));
			bf.close();
			return contents;
		} catch (Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109, TransReturnCodeEnum.code_9109.getDesc()
					+ e.getMessage());
			// throw new BizException(e, "接收报文数据出错" + e.getMessage());
		} finally {
			this.disconnect(socket);
		}
	}

	/**
	 * 
	 * <p>
	 * 建立Socket连接
	 * </p>
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @return
	 * @author #{杜波(15999653650)}
	 * @throws ClearingAdapterBizCheckedException 
	 */
	private Socket establishConnect(String socketIp, String socketPort) throws ClearingAdapterBizCheckedException {
		Socket socket = new Socket();
		Assert.notNull(socketIp, TransReturnCode.code_9103, "SocketIP不能为空!");
		Assert.notNull(socketPort, TransReturnCode.code_9103, "SocketPort不能为空!");
		while (!socket.isConnected()) {
			try {
				currentTryTime++;
				Log4jUtil.info("进行第"+currentTryTime+"次链接。");
				socket = this.connectServer(socketIp, socketPort);
			} catch (Exception e) {
				//若超过最大链接次数依然未成功，则抛异常
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				if (currentTryTime >= maxTryTime) {
					throw new BizException(e, TransReturnCode.code_9103, "通讯异常,连接 socket server 失败！！" + e.getMessage());
				}
			}
		}
		return socket;
	}

	/**
	 * 
	 * <p>
	 * 连接服务器
	 * </p>
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @return
	 * @throws Exception
	 * @author #{杜波(15999653650)}
	 */
	private Socket connectServer(String socketIp, String socketPort) throws Exception {
		Socket socket = null;
		socket = new Socket();
		SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
		socket.connect(socketAddress, connectOutTime);  //连接指定的服务器并指定连接超时时间
		socket.setSoTimeout(timeout);                   //设置读取流超时时间
		Log4jUtil.info(socketIp+" "+socketPort+" connected!");
		return socket;
	}
	/**
	 * 断开服务器 socket
	 * 
	 * @throws BizException
	 * @author #{杜波(15999653650)}
	 */
	private void disconnect(Socket socket) throws BizException {
		try {
			if (socket != null)
				socket.close();
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "断开 socket server 失败！！");
		}
	}
}
