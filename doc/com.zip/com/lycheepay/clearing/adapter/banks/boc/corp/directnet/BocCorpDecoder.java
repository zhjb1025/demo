/*******************************************************************************
 * Project Key : CPP
 * Create on 2012-8-2 下午5:01:32
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.directnet;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.soofa.remoting.Channel;
import org.soofa.remoting.Decoder;
import org.soofa.remoting.SoofaRemotingException;

import com.lycheepay.clearing.adapter.banks.boc.corp.tool.DES;
import com.lycheepay.clearing.adapter.banks.boc.corp.tool.Deflate;
import com.lycheepay.clearing.adapter.banks.boc.corp.tool.MD5;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.BankInteractiveParam;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企直连解码器</P>
 * 
 * @author 邱林 Leon.Qiu 2012-8-2 下午5:01:32
 */
public class BocCorpDecoder implements Decoder<byte[]> {

	private static String localSysCode = "";
	private static String des = "";

	/**
	 * <p>Method for constructor</p>
	 * 
	 * @param config
	 */
	public BocCorpDecoder(final BankInteractiveParam config) {
		localSysCode = config.getCheckCode();
		des = config.getDes();
	}

	@Override
	public byte[] decode(final Channel channel, final InputStream stream) {
		final byte[] key = stringKeyToByteKey(des);// DES密码
		byte[] result = null;
		try {
			result = IOUtils.toByteArray(stream);
		} catch (final IOException e) {
			throw new SoofaRemotingException(e.getMessage(), e);
		}
		final byte[] sysCode = new byte[4];
		System.arraycopy(result, 0, sysCode, 0, 4);
		final String sysCodeStr = new String(sysCode);
		Log4jUtil.setLogClass("BOC", "corp");
		Log4jUtil.info("BocCorpChannelServiceImpl.sysCode：" + localSysCode);
		Log4jUtil.info("银行返回系统代码：" + sysCodeStr);
		if (!localSysCode.equals(sysCodeStr)) {
			throw new RuntimeException("银行返回系统代码不正确异常：" + sysCodeStr);
		}
		final byte[] rcode = new byte[2];
		System.arraycopy(result, 4, rcode, 0, 2);
		final String rcodeStr = new String(rcode);
		Log4jUtil.info("银行通道响应码：" + rcodeStr);
		if (!"00".equals(rcodeStr)) {
			throw new RuntimeException(rcodeStr + "|银行处理报文异常：" + getRcodeDesc(rcodeStr));
		}
		final byte[] len = new byte[4];
		System.arraycopy(result, 6, len, 0, 4);
		final int length = byteToInt(len);
		Log4jUtil.info("标注报文长度：" + length);
		byte[] decrypt = null;
		if (length == result.length - 10) {
			final byte[] md5 = new byte[16];
			System.arraycopy(result, 10, md5, 0, 16);
			final byte[] deflate = new byte[result.length - 26];
			System.arraycopy(result, 26, deflate, 0, result.length - 26);
			// 检查摘要信息
			byte[] deCompress;
			try {
				if (!Arrays.toString(md5).equals(Arrays.toString(MD5.encode(deflate)))) {
					throw new RuntimeException("报文MD5不等");
				}
				deCompress = Deflate.deCompress(deflate);
				decrypt = DES.decrypt(key, deCompress);
			} catch (final Exception e) {
				throw new RuntimeException("DES 解密错误");
			}
		} else {
			throw new RuntimeException("报文长度不等于报文头标注的长度");
		}
		// 替换掉 xmlns=\"http://www.szboc.cn/projects/open/2012/UniformProxySystem\"
		String rtnStr = new String(decrypt).replaceFirst("xmlns=\"http:.*\"\\s", "");
		Log4jUtil.info("银行处理返回报文：" + rtnStr);
		return rtnStr.getBytes();
	}

	private String getRcodeDesc(final String rcodeStr) {
		String result = "";
		if ("00".equals(rcodeStr)) {
			result = "正常处理";
		} else if ("01".equals(rcodeStr)) {
			result = "IO通道异常";
		} else if ("02".equals(rcodeStr)) {
			result = "报文长度标识非法";
		} else if ("03".equals(rcodeStr)) {
			result = "报文长度非法";
		} else if ("04".equals(rcodeStr)) {
			result = "MD5校验异常";
		} else if ("05".equals(rcodeStr)) {
			result = "Inflate解压异常";
		} else if ("06".equals(rcodeStr)) {
			result = "DES解密异常";
		} else if ("07".equals(rcodeStr)) {
			result = "流量过大";
		} else if ("08".equals(rcodeStr)) {
			result = "非法XML报文,未通过xsd验证";
		} else if ("99".equals(rcodeStr)) {
			result = "银行内部其它异常";
		}
		return result;
	}

	/**
	 * <p>Byte转Int</p>
	 * 
	 * @param byteVal
	 * @return
	 * @author 邱林 Leon.Qiu 2012-8-6 下午4:36:27
	 */
	private int byteToInt(final byte[] byteVal) {
		int result = 0;
		for (int i = 0; i < byteVal.length; i++) {
			int tmpVal = (byteVal[i] << (8 * (3 - i)));
			switch (i) {
				case 0:
					tmpVal = tmpVal & 0xFF000000;
					break;
				case 1:
					tmpVal = tmpVal & 0x00FF0000;
					break;
				case 2:
					tmpVal = tmpVal & 0x0000FF00;
					break;
				case 3:
					tmpVal = tmpVal & 0x000000FF;
					break;
			}
			result = result | tmpVal;
		}
		return result;
	}

	private static byte[] stringKeyToByteKey(final String skey) {
		if (skey == null || "".equals(skey)) {
			return null;
		}
		final String[] skeyArray = skey.split(",");
		final byte[] bkey = new byte[skeyArray.length];
		for (int i = 0; i < skeyArray.length; i++) {
			bkey[i] = (byte) Integer.parseInt(skeyArray[i].trim());
		}
		return bkey;
	}

}
