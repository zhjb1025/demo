package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

/**
 * 中行订单查询返回数据明细实体 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-cji
 * @version 1.0
 */
public class BocB2CQueryOrderDetailRecv {
	private String orderNo = "";// 商户订单号
	private String orderSeq = "";// 银行订单流水号
	private String orderStatus = "";// 订单状态
	private String cardTyp = "";// 银行卡类别
	private String payTime = "";// 支付时间
	private String payAmount = "";// 支付金额

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(final String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOrderSeq() {
		return orderSeq;
	}

	public void setOrderSeq(final String orderSeq) {
		this.orderSeq = orderSeq;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(final String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getCardTyp() {
		return cardTyp;
	}

	public void setCardTyp(final String cardTyp) {
		this.cardTyp = cardTyp;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(final String payTime) {
		this.payTime = payTime;
	}

	public String getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(final String payAmount) {
		this.payAmount = payAmount;
	}
}
