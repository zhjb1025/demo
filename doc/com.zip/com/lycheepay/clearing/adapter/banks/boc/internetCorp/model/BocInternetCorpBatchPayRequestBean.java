/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import java.util.List;

import org.soofa.core.model.BaseObject;
/**
 * 
 * <P>中国银行网上银企快捷代发业务</P>
 * @author #{杜波(15999653650)}
 */
public class BocInternetCorpBatchPayRequestBean extends BaseObject{

	private static final long serialVersionUID = -5212913178764091027L;
    /**
     * 指令ID，一条转账指令在客户端的唯一标识，建议企业按时间顺序生成且不超过12位
     */
	private String insid;
    /**
     * 联行号
     */
	private String fribkn;
    /**
     * 付款账号
     */
	private String actacn;
    /**
     * 付款人名称
     */
	private String actnam;
    /**
     * 货币
     */
	private String pybcur;
    /**
     * 批总金额
     */
	private String pybamt;
    /**
     * 批总笔数
     */
	private String pybnum;
    /**
     * 代发类型
     */
	private String crdtyp;
    /**
     * 摘要
     */
	private String furinfo;
    /**
     * 用途
     */
	private String useinf;
    /**
     * 要求的付款日期
     */
	private String trfdate;
    /**
     * 笔明细内容
     */
    private List<BocInternetCorpBatchPayRequestDetailBean> detailList;
    
	public String getInsid() {
		return insid;
	}
	public void setInsid(String insid) {
		this.insid = insid;
	}
	public String getFribkn() {
		return fribkn;
	}
	public void setFribkn(String fribkn) {
		this.fribkn = fribkn;
	}
	public String getActacn() {
		return actacn;
	}
	public void setActacn(String actacn) {
		this.actacn = actacn;
	}
	public String getActnam() {
		return actnam;
	}
	public void setActnam(String actnam) {
		this.actnam = actnam;
	}
	public String getPybcur() {
		return pybcur;
	}
	public void setPybcur(String pybcur) {
		this.pybcur = pybcur;
	}
	public String getPybamt() {
		return pybamt;
	}
	public void setPybamt(String pybamt) {
		this.pybamt = pybamt;
	}
	public String getPybnum() {
		return pybnum;
	}
	public void setPybnum(String pybnum) {
		this.pybnum = pybnum;
	}
	public String getCrdtyp() {
		return crdtyp;
	}
	public void setCrdtyp(String crdtyp) {
		this.crdtyp = crdtyp;
	}
	public String getFurinfo() {
		return furinfo;
	}
	public void setFurinfo(String furinfo) {
		this.furinfo = furinfo;
	}
	public String getUseinf() {
		return useinf;
	}
	public void setUseinf(String useinf) {
		this.useinf = useinf;
	}
	public String getTrfdate() {
		return trfdate;
	}
	public void setTrfdate(String trfdate) {
		this.trfdate = trfdate;
	}
	public List<BocInternetCorpBatchPayRequestDetailBean> getDetailList() {
		return detailList;
	}
	public void setDetailList(
			List<BocInternetCorpBatchPayRequestDetailBean> detailList) {
		this.detailList = detailList;
	}
}
