/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:33:11
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import java.util.List;

import org.apache.commons.lang.StringUtils;


/**
 * <P>批量代付交易请求</P>
 * 
 * @author 张凯锋
 */
public class B005Request extends RequestHead {

	private String packNo;// 此批次包号 PACK_NO M 包号 发起方自定义
	private String count;// 总个数 4 BYTE M 4位十进制数字 最大2000
	private String sum;// 总金额 MONEY M
	private List<B005RequestDetail> details;

	/**
	 * @param packNo 批次包号
	 * @param count 总个数
	 * @param sum 总金额
	 */
	public B005Request(final String packNo, final String count, final String sum, final List<B005RequestDetail> details) {
		this.packNo = StringUtils.leftPad(packNo, 20, "0");
		this.count = count;
		this.sum = sum;
		this.details = details;
	}

	/**
	 * <p>组装发送报文</p>
	 * 
	 * @return
	 * @author 张凯锋
	 */
	public String getXML() {
		final StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
		sb.append("<B005_REQUEST xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.szboc.cn/projects/open/2012/UniformProxySystem\">");
		sb.append(getHeadXML());
		sb.append("<BODY>");
		sb.append("<BATCH>");
		sb.append("<PACK_NO>").append(packNo).append("</PACK_NO>");
		sb.append("<COUNT>").append(count).append("</COUNT>");
		sb.append("<SUM>").append(sum).append("</SUM>");
		sb.append("</BATCH>");
		sb.append("<DETAILS>");
		for (int i = 0, len = details.size(); i < len; i++) {
			sb.append(details.get(i).getXML());
		}
		sb.append("</DETAILS>");
		sb.append("</BODY>");
		sb.append("</B005_REQUEST>");
		return sb.toString();
	}

	public String getPackNo() {
		return packNo;
	}

	public void setPackNo(final String packNo) {
		this.packNo = packNo;
	}

	public String getCount() {
		return count;
	}

	public void setCount(final String count) {
		this.count = count;
	}

	public String getSum() {
		return sum;
	}

	public void setSum(final String sum) {
		this.sum = sum;
	}

	public List<B005RequestDetail> getDetails() {
		return details;
	}

	public void setDetails(final List<B005RequestDetail> details) {
		this.details = details;
	}

}
