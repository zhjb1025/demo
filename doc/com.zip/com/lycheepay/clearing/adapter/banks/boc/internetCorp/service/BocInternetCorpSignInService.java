/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-22 下午4:01:32
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.service;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Map;

import org.dom4j.Node;
import org.soofa.aries.core.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInRequestBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpHttpPostMessages;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpRequestMessagesConverter;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.util.BocInternetCorpResponseMessageConverter;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.Balance;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParm;
import com.lycheepay.clearing.adapter.common.model.channel.param.ChannelParmId;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <P>中国银行网上银企签到业务</P>
 * 
 * @author #{杜波(15999653650)}
 */
@Service("bocInternetCorpSignInService")
public class BocInternetCorpSignInService {
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	@Autowired
	private BocInternetCorpResponseMessageConverter corpRespMsgConverter;
	@Autowired
	private BocInternetCorpHttpPostMessages bocCorpHttpPostMessages;
	@Autowired
	private BocInternetCorpRequestMessagesConverter bocMessagesConverter;
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager sequenceManager;
	@Autowired
	private BankAccountBalanceService bankAccountBalanceService;

	/**
	 * 
	 * <p>中国银行网上银企签到</p>
	 * 
	 * @return
	 * @author 杜波(15999653650)
	 * @throws UnsupportedEncodingException
	 */
	public BocInternetCorpSignInResponseBean bocInternetCorpSignIn() throws BizException {
		Log4jUtil.info("中行网上银企签到==");
		try {
			// 获取中行网上银企签到报文参数
			Map<String, String> channelParamMap = channelParmService
					.queryCodeParamsMapByChannelId(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());

			// 组装中行银企签到报文
			BocInternetCorpSignInRequestBean bocCorpSignInRequestBean = new BocInternetCorpSignInRequestBean();
			bocCorpSignInRequestBean.setTermId(channelParamMap.get("100001")); // termId
			bocCorpSignInRequestBean.setCustId(channelParamMap.get("100002")); // custId
			bocCorpSignInRequestBean.setCusOpr(channelParamMap.get("100003")); // cusOpr
			bocCorpSignInRequestBean.setOprPwd(channelParamMap.get("100005")); // oprPwd
			// 获取客户端时间日期时间
			bocCorpSignInRequestBean.setCustDt(DateUtil.getCurrentDateTime());
			bocCorpSignInRequestBean.setTrnId(sequenceManager.getBocInternetCorpSn());

			// 转换中行网上银企签到报文
			String signInMessage = bocMessagesConverter.getBocSignInRequestXml(bocCorpSignInRequestBean);

			// 发送中行网上银企签到报文
			String responseMessages = bocCorpHttpPostMessages.sendHttpPostMessages(signInMessage,
					channelParamMap.get("100006")); // signInUrl

			BocInternetCorpSignInResponseBean bocCorpSignInResponse = corpRespMsgConverter
						.getBocInternetCorpSignInResponseMessage(responseMessages.getBytes(Charset.forName("UTF-8")));

			// 更新签到信息.更新交易验证码及交易验证码生成时间(服务器端)
			if (bocCorpSignInResponse != null && bocCorpSignInResponse.getToken() != null
					&& bocCorpSignInResponse.getToken().length() > 0) {
				ChannelParm channelParm = new ChannelParm();
				ChannelParmId channelParmId = new ChannelParmId();
				channelParmId.setChannelid(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
				channelParm.setParvalue(bocCorpSignInResponse.getToken());
				channelParm.setParname("token");
				channelParm.setId(channelParmId);
				channelParm.setUpdatetime(new Date());
				// 更新签到信息
				channelParmService.updateByNameAndId(channelParm);
				channelParm.setParvalue(bocCorpSignInResponse.getServerDt());
				channelParm.setParname("tokenDate");
				channelParm.setId(channelParmId);
				channelParmService.updateByNameAndId(channelParm);
			}
			Log4jUtil.info("中行网上银企签到==" + bocCorpSignInResponse);
			return bocCorpSignInResponse;
		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, "签到失败" + e.getMessage());
		}

	}

	public Balance queryBanlance(String accountNo) throws BizException {
		String sendXMLTemplet = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><bocb2e version=\"120\" locale=\"zh_CN\"><head><termid>{0}</termid><trnid>{1}</trnid><custid>{2}</custid><cusopr>{3}</cusopr><trncod>b2e0005</trncod><token>{4}</token></head><trans><trn-b2e0005-rq><b2e0005-rq><account><ibknum>{5}</ibknum><actacn>{6}</actacn></account></b2e0005-rq></trn-b2e0005-rq></trans></bocb2e>";
		Map<String, String> channelParamMap = channelParmService
				.queryCodeParamsMapByChannelId(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
		String termId = channelParamMap.get("100001"); // termId
		String trnid = sequenceManager.getBocInternetCorpSn();// trnid
		String custId = channelParamMap.get("100002"); // custId
		String cusOpr = channelParamMap.get("100003"); // cusOpr
		String token = channelParamMap.get("100007");// token
		String ibknum = channelParamMap.get("100011");// ibknum
		String actacn = accountNo;
		if(StringUtils.isBlank(accountNo)){
			BankaccountBalance bankaccountBalance = bankAccountBalanceService
					.getBankaccountBean(ChannelIdEnum.BOC_CREDIT_REPAY.getCode());
			actacn = bankaccountBalance.getAccountNo();
		}

		String[] params = new String[] { termId, trnid, custId, cusOpr, token, ibknum, actacn };
		String sendXML = MessageFormat.format(sendXMLTemplet, params);

		String responseMessages = bocCorpHttpPostMessages.sendHttpPostMessages(sendXML, channelParamMap.get("100006"));
		Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(responseMessages.getBytes(Charset.forName("UTF-8")));
		Node statusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0005-rs/status");
		String rspcod = dom4jxml.getNodeText(statusNode, "rspcod");
		String rspmsg = dom4jxml.getNodeText(statusNode, "rspmsg");
		Balance balance = new Balance();
		if ("B001".equalsIgnoreCase(rspcod)) {
			Node trnNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0005-rs/b2e0005-rs/status");
			String rspcod1 = dom4jxml.getNodeText(trnNode, "rspcod");
			String rspmsg1 = dom4jxml.getNodeText(trnNode, "rspmsg");
			if ("B001".equalsIgnoreCase(rspcod1)) {
				Node balanceNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0005-rs/b2e0005-rs/balance");
				String bokbal = dom4jxml.getNodeText(balanceNode, "bokbal");
				String avabal = dom4jxml.getNodeText(balanceNode, "avabal");
				balance.setBalance(bokbal);
				balance.setAvailBanlace(avabal);
				balance.setAccNo(actacn);
				Log4jUtil.info("中行账号:{}，余额:{},可用余额:{}", actacn, bokbal, avabal);
			} else {
				balance.setErrorMsg(rspmsg1);
			}
		} else {
			balance.setErrorMsg(rspmsg);
		}
		return balance;
	}
}