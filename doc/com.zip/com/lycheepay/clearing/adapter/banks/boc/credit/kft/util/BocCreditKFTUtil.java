package com.lycheepay.clearing.adapter.banks.boc.credit.kft.util;

import java.util.Map;

import com.lycheepay.clearing.adapter.banks.boc.credit.kft.bean.BocCreditParam;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelParamUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.util.ObjectUtil;


public class BocCreditKFTUtil {
	public Map<String, String> checkChannelParam(final String logPrefix, final String type,
			final Map<String, String> channelParam, final BocCreditParam bocCreditParam)
			throws ClearingAdapterBizCheckedException {
		String key = "";
		String keyName = "";
		String logMsg = "";
		logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
		Log4jUtil.info(logMsg);

		// 设置到银行参数实体中
		key = "100001";
		keyName = "IP地址";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		bocCreditParam.setIp(channelParam.get("100001"));

		key = "100002";
		keyName = "端口号";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		bocCreditParam.setPort(channelParam.get("100002"));

		bocCreditParam.setInputCode(channelParam.get("100003"));
		bocCreditParam.setConCode(channelParam.get("100004"));
		bocCreditParam.setClinetCode(channelParam.get("100005"));
		bocCreditParam.setMerchant(channelParam.get("100006"));
		bocCreditParam.setCurrency(channelParam.get("100007"));
		bocCreditParam.setOpertor(channelParam.get("100008"));
		bocCreditParam.setBatchNo(channelParam.get("100009"));
		bocCreditParam.setChannelCode(channelParam.get("100010"));
		bocCreditParam.setFromAddress(channelParam.get("100011"));
		bocCreditParam.setToAddress(channelParam.get("100012"));
		bocCreditParam.setPwdKey(channelParam.get("100013"));
		bocCreditParam.setWorkKey(channelParam.get("100014"));
		bocCreditParam.setSignFlag(channelParam.get("100015"));
		bocCreditParam.setCheckValue(channelParam.get("100016"));
		bocCreditParam.setNii(channelParam.get("100017"));
		bocCreditParam.setTime(channelParam.get("900000"));

		// 对账。
		key = "100020";
		keyName = "ftpServer";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		key = "100021";
		keyName = "ftpUser";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
		key = "100022";
		keyName = "ftpPassword";
		ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);

		bocCreditParam.setFtpServer(channelParam.get("100020"));
		bocCreditParam.setFtpUser(channelParam.get("100021"));
		bocCreditParam.setFtpPassword(channelParam.get("100022"));
		bocCreditParam.setFtpPath(channelParam.get("100023"));

		logMsg = logPrefix + "对渠道参数检查结束。";
		Log4jUtil.info(logMsg);
		ObjectUtil.printPropertyString(logPrefix, bocCreditParam);
		return channelParam;
	}
}
