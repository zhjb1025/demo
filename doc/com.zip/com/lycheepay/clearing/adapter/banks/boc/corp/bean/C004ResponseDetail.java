/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-15 下午3:01:52
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>批量代付请求明细</P>
 * 
 * @author 张凯锋
 */
public class C004ResponseDetail {

	private String transNo;// 交易流水号 TRANS_NO M
	private String transStatus;// 原交易状态 4 BYTE M 见附录.
	private String transMsgType;// 原交易报文编码 TRANS_TYPE O 引用原交易的编码,可以根据此字段判断原交易的类型是单笔/批量,代收/代付
	private String transAmt;// 交易金额 MONEY O 请求报文中的金额
	private String handleFee;// 收取手续费 MONEY O 不收取时为0.00
	private String actualDeductAmt;// 实收金额 MONEY O 交易金额+实收金额
	private String handleFeeType;// 手续费扣取类型 HANDLE_FEE_TYPE O 见附录
	private String accountDate;// 实际会计日期 DATE O
	private String transDesc;// 状态详细描述 500 BYTE O 进一步文字描述

	public C004ResponseDetail(final Dom4jXMLMessage dom4jxml, final Node detail) {
		transNo = dom4jxml.getNodeText(detail, "TRANS_NO");
		transStatus = dom4jxml.getNodeText(detail, "TRANS_STATUS");
		transMsgType = dom4jxml.getNodeText(detail, "TRANS_MSG_TYPE");
		transAmt = dom4jxml.getNodeText(detail, "TRANS_AMT");
		handleFee = dom4jxml.getNodeText(detail, "HANDLE_FEE");
		actualDeductAmt = dom4jxml.getNodeText(detail, "ACTUAL_DEDUCT_AMT");
		handleFeeType = dom4jxml.getNodeText(detail, "HANDLE_FEE_TYPE");
		accountDate = dom4jxml.getNodeText(detail, "ACCOUNT_DATE");
		transDesc = dom4jxml.getNodeText(detail, "TRANS_DESC");

	}

	public String getTransNo() {
		return transNo;
	}

	public void setTransNo(final String transNo) {
		this.transNo = transNo;
	}

	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(final String transStatus) {
		this.transStatus = transStatus;
	}

	public String getTransMsgType() {
		return transMsgType;
	}

	public void setTransMsgType(final String transMsgType) {
		this.transMsgType = transMsgType;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(final String transAmt) {
		this.transAmt = transAmt;
	}

	public String getHandleFee() {
		return handleFee;
	}

	public void setHandleFee(final String handleFee) {
		this.handleFee = handleFee;
	}

	public String getActualDeductAmt() {
		return actualDeductAmt;
	}

	public void setActualDeductAmt(final String actualDeductAmt) {
		this.actualDeductAmt = actualDeductAmt;
	}

	public String getHandleFeeType() {
		return handleFeeType;
	}

	public void setHandleFeeType(final String handleFeeType) {
		this.handleFeeType = handleFeeType;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(final String transDesc) {
		this.transDesc = transDesc;
	}

	public String getAccountDate() {
		return accountDate;
	}

	public void setAccountDate(final String accountDate) {
		this.accountDate = accountDate;
	}

	@Override
	public String toString() {
		return "C004ResponseDetail [transNo=" + transNo + ", transStatus=" + transStatus + ", transMsgType="
				+ transMsgType + ", transAmt=" + transAmt + ", handleFee=" + handleFee + ", actualDeductAmt="
				+ actualDeductAmt + ", handleFeeType=" + handleFeeType + ", transDesc=" + transDesc + "]";
	}
}
