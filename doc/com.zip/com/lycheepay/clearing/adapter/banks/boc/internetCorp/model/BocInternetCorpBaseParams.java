/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import org.soofa.core.model.BaseObject;

/**
 * 
 * <P>
 * 中国银行网上银企基本参数
 * </P>
 * 
 * @author #{杜波(15999653650)}
 */
public class BocInternetCorpBaseParams extends BaseObject {

	private static final long serialVersionUID = 8414733725880687167L;
	/**
	 * 单位编码
	 */
	private String dptCode;
	/**
	 * 单位名称
	 */
	private String dptName;
	/**
	 * DES密码
	 */
	private String desPassWord;
	/**
	 * IP地址
	 */
	private String Ip;
	/**
	 * 端口号
	 */
	private String port;
	/**
	 * 交易地点
	 */
	private String transadd;
	/**
	 * 链接超时时间，毫秒
	 */
	private String timeOut;

	public String getDptCode() {
		return dptCode;
	}

	public void setDptCode(String dptCode) {
		this.dptCode = dptCode;
	}

	public String getDptName() {
		return dptName;
	}

	public void setDptName(String dptName) {
		this.dptName = dptName;
	}

	public String getDesPassWord() {
		return desPassWord;
	}

	public void setDesPassWord(String desPassWord) {
		this.desPassWord = desPassWord;
	}

	public String getIp() {
		return Ip;
	}

	public void setIp(String ip) {
		Ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getTransadd() {
		return transadd;
	}

	public void setTransadd(String transadd) {
		this.transadd = transadd;
	}

	public String getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(String timeOut) {
		this.timeOut = timeOut;
	}

}
