package com.lycheepay.clearing.adapter.banks.boc.http.b2c.kft.processor;

//package com.lycheepay.clearing.adapter.banks.boc.b2c.kft.processor;
//
//import java.io.IOException;
//import java.security.GeneralSecurityException;
//import java.util.ArrayList;
//import java.util.List;
//
//
//import org.dom4j.Node;
//import org.soofa.tx.service.BaseWithoutAuditLogService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.stereotype.Service;
//
//import com.bocnet.common.security.PKCS7Tool;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.bank.bean.BocB2CParam;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.bank.bean.BocB2CQueryOrderDetailRecv;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.bank.bean.BocB2CQueryOrderRecv;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.bank.bean.BocB2CQueryOrderSend;
//import com.lycheepay.clearing.adapter.banks.boc.b2c.kft.util.BocHttpKFTUtilService;
//import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
//import com.lycheepay.clearing.adapter.common.constant.biz.ChannelTransType;
//import com.lycheepay.clearing.adapter.common.constant.biz.ClearingTransType;
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.common.model.BillnoSn;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
//import com.lycheepay.clearing.adapter.common.model.channel.param.Param;
//import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
//import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
//import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
//import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
//import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
//import com.lycheepay.clearing.adapter.common.service.biz.PayChannelService;
//import com.lycheepay.clearing.adapter.common.service.biz.SequenceManagerService;
//import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
//import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
//import com.lycheepay.clearing.adapter.common.util.net.HttpClientAgent;
//import com.lycheepay.clearing.common.constant.ChannelId;
//import com.lycheepay.clearing.util.DateUtil;
//import com.lycheepay.clearing.util.Log4jUtil;
//
//
///**
// * <P>中国银行B2C HTTP(后台直接交互)请求处理类</P>
// * 
// * @author 邱林 Leon.Qiu 2012-6-19 下午9:37:32
// */
//@Service(ClearingAdapterAnnotationName.BOC_B2C_DIRECT_PROCESS)
//public class BocB2CDirectProcess extends BaseWithoutAuditLogService {
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
//	private BillnoSnService billnoSnService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
//	private ChannelParmService channelParmService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
//	private SequenceManagerService sequenceManagerService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
//	private BankAccountBalanceService bankAccountBalanceService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
//	private ChannelRtncodeService channelRtncodeService;
//
//	@Autowired
//	@Qualifier(ClearingAdapterAnnotationName.PAY_CHANNEL_SERVICE)
//	private PayChannelService payChannelService;
//
//	public ReturnState deal(final Param param) throws BizException {
//		String logMsg = "";
//		final String channelId = param.getChannelId();
//		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
//		logMsg = "进入" + channelId + "渠道业务处理。";
//		Log4jUtil.info(logMsg);
//		Map<String, String> channelParam = new Map<String, String>();
//		channelParam = (Map) channelParmService.getChannelParam(channelId);
//		// if (channelParam == null) throw new BizException(channelId + "无法获取渠道参数配置。");
//		if (param.getChannelTransType().equals(ChannelTransType.Qury_Single_Trans)) {
//			// 单笔查询
//			return this.queryOrder(logPrefix, param, channelParam);
//		} else if (param.getChannelTransType().equals(ChannelTransType.PayRefund)) { // 退货
//			if (param.getTransType().equals(ClearingTransType.NetPay_Refund)
//					|| param.getTransType().equals(ClearingTransType.Direct_Refund)) {
//				return this.batchRefund(param);
//			}
//			throw new BizException(logPrefix + "错误的业务类型:" + param.getChannelTransType() + ":" + param.getTransType());
//		} else {
//			throw new BizException("错误的业务类型:" + param.getChannelTransType() + ":" + param.getTransType());
//		}
//	}
//
//	/**
//	 * B2C批量退款、包括批量退款重发
//	 * 
//	 * @param param
//	 * @return ReturnState
//	 * @throws BizException
//	 */
//	private ReturnState batchRefund(final Param param) throws BizException {
//		final CreatBatchRefundFile creatBatchRefundFile = new CreatBatchRefundFile();
//		final String fileNamePrefix = param.getChannelId();
//		final ReturnState returnState = creatBatchRefundFile.batchRefund(param, fileNamePrefix, 4, "TXT", 5000);
//		return returnState;
//	}
//
//	/**
//	 * 订单查询
//	 * 
//	 * @param logPrefix
//	 * @param param 里面的bizBean为 String[]类型
//	 * @param channelParam
//	 * @return
//	 * @throws BizException
//	 */
//	private ReturnState queryOrder(final String logPrefix, final Param param,
//			Map<String, String> channelParam) throws BizException {
//		final String channelId = param.getChannelId();
//		String logMsg = "";
//		logMsg = "进入" + logPrefix + "订单查询处理。";
//		Log4jUtil.info(logMsg);
//		// 检查系统参数
//		final BocHttpKFTUtilService bocKFTUtil = new BocHttpKFTUtilService();
//		final BocB2CParam bocB2CParam = new BocB2CParam();
//		channelParam = bocKFTUtil.checkChannelParam(logPrefix, ChannelTransType.Qury_Single_Trans, channelParam,
//				bocB2CParam);
//		try {
//			// 创建发送实体、发送、接收
//			final BocB2CQueryOrderSend bocB2CQueryOrderSend = new BocB2CQueryOrderSend();
//			final BocB2CQueryOrderRecv bocB2CQueryOrderRecv = new BocB2CQueryOrderRecv();
//			bocKFTUtil.queryOder(logPrefix, param, bocB2CParam, bocB2CQueryOrderSend, bocB2CQueryOrderRecv);
//			if (bocB2CQueryOrderRecv.getException() != null && bocB2CQueryOrderRecv.getException().length() > 0) {
//				throw new BizException(bocB2CQueryOrderRecv.getException());
//			}
//			final ArrayList<BocB2CQueryOrderDetailRecv> orderTrans = bocB2CQueryOrderRecv.getOrderTrans();
//			// TODO:回调业务
//			final List<ReturnState> returnStateList = new ArrayList<ReturnState>();
//			for (final BocB2CQueryOrderDetailRecv orderDetail : orderTrans) {
//				final ReturnState returnState = new ReturnState();
//				returnState.setReturnState(PayState.SUCCEED_RTN);
//				final BillnoSn billnoSn = billnoSnService.getBillnoSn(channelId, orderDetail.getOrderNo());
//				if (billnoSn == null) {
//					Log4jUtil.error(logPrefix + "渠道ID[" + channelId + "]中的订单号" + orderDetail.getOrderNo()
//							+ "在渠道流水对照表中没有记录,抛弃该订单号。");
//					continue;
//				}
//				returnState.setSn(billnoSn.getSn());
//				final String bankRetCode = ChannelTransType.Qury_Single_Trans + orderDetail.getOrderStatus();
//				returnState.setBankRetCode(bankRetCode);// 银行返回状态
//				// 取得渠道返回信息，存入param.returnMsg 中
//				ChannelRtncode channelRtncode = null;
//				channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, bankRetCode));
//				if (channelRtncode == null) {
//					returnState.setReturnMsg("表  channel_rtncode 没有对应的返回信息");
//					returnState.setChannelCode(TransReturnCode.code_9900);
//				} else {
//					returnState.setReturnMsg(channelRtncode.getChannelReamrk());
//					returnState.setChannelCode(channelRtncode.getKftRtncode());
//				}
//				returnStateList.add(returnState);
//			}
//			final ReturnState returnState = new ReturnState();
//			returnState.setReturnObj(returnStateList);
//			return returnState;
//		} catch (final Exception e) {
//			Log4jUtil.error(e);
//			throw new BizException(logPrefix + "查询订单出错。" + e);
//		}
//	}
//
//	/**
//	 * 单笔退款
//	 * 
//	 * @param param
//	 * @return
//	 * @throws BizException
//	 */
//	private ReturnState refundOrder(final Param param, final Map<String, String> channelParam)
//			throws BizException {
//		final String channelId = param.getChannelId();
//		Log4jUtil.info("进入B2C网银退款处理。");
//		String merchantNo = "";// 商户号
//		String mRefundSeq = "";// 商户系统产生的交易流水号
//		String curCode = "";// 目前只支持001：人民币 固定填001
//		String refundAmount = "";// 退款金额 格式：整数位不前补零,小数位补齐2位
//									// 即：不超过10位整数位+1位小数点+2位小数
//									// 无效格式如123，.10，1.1,有效格式如1.00，0.10
//		String orderNo = ""; // 必填 商户系统产生的订单号，原支付订单的商户订单号
//		final String signData = "";// 必填 商户签名数据串格式，各项数据用管道符分隔：
//									// 商户号|商户退款交易流水号|退款币种|退款金额|商户订单号 merchantNo |
//									// mRefundSeq | curCode | refundAmount |orderNo
//		String sn = "";
//		merchantNo = payChannelService.findById(param.getChannelId()).getMerchantNo();// 商户代码
//		mRefundSeq = sequenceManagerService.getBocChannelSN(DateUtil.getCurrentDate());// 流水号
//		curCode = channelParam.get("100010");
//		if (param.getTransType().equals(ClearingTransType.Direct_Pay)
//				|| param.getTransType().equals(ClearingTransType.Guarantee_Pay)
//				|| param.getTransType().equals(ClearingTransType.Protocol_Debit_Real)) {
//			final Paybill paybill = (Paybill) param.getBizBean();
//			sn = paybill.getSn();
//			refundAmount = String.format("%1$.2f", paybill.getChannelAmount());
//		} else if (param.getTransType().equals(ClearingTransType.Recharge)) {
//			final Rechargebill rechargeBill = (Rechargebill) param.getBizBean();
//			sn = rechargeBill.getSn();
//			refundAmount = String.format("%1$.2f", rechargeBill.getAmount());
//		} else {
//			throw new BizException("错误的交易类型。");
//		}
//		orderNo = billnoSnService.findBankSendSnBySn(sn);
//		AssertUtils.notEmpty(orderNo, "查询不到发往银行的交易流水号！");
//
//		final StringBuffer sbData = new StringBuffer("");// 商户签名数据串格式，各项数据用管道符分隔：
//		sbData.append(merchantNo).append("|");
//		sbData.append(mRefundSeq).append("|");
//		sbData.append(curCode).append("|");
//		sbData.append(refundAmount).append("|");
//		sbData.append(orderNo);
//		// signData = this.sign(sbData.toString(),channelParam);
//		String refundOrderUrl = "";
//		refundOrderUrl = channelParam.get("100011");
//		AssertUtils.notEmpty(refundOrderUrl, "获取不到退款跳转网址，请检查渠道参数配置");
//
//		HttpClientAgent httpagent = null;
//		String sRetInfo = "";
//		try {
//			httpagent = new HttpClientAgent();
//			httpagent.setTimeout(30, 120);
//			httpagent.addParm("merchantNo", merchantNo);
//			httpagent.addParm("mRefundSeq", mRefundSeq);
//			httpagent.addParm("curCode", curCode);
//			httpagent.addParm("refundAmount", refundAmount);
//			httpagent.addParm("orderNo", orderNo);
//			httpagent.addParm("signData", signData);
//			httpagent.postUrl(refundOrderUrl);
//			sRetInfo = httpagent.getResponseBodyAsString();
//			Log4jUtil.info("接收到中行同步返回报文：" + sRetInfo);
//		} catch (final Exception e) {
//			Log4jUtil.error("向中行发送报文,产生异常",e);
//			throw new BizException("9001", e.getMessage());
//		} finally {
//			if (httpagent != null) {
//				httpagent.releaseConnection();
//			}
//		}
//
//		/*成功信息
//		 * <?xml version="1.0" encoding="utf-8" ?> 
//		 * <res> 
//		 *	 <header>
//		 *	 	<merchantNo>104110041000000</merchantNo>
//		 *		 <returnActFlag>3</returnActFlag>
//		 * 		<dealStatus>0</dealStatus> 
//		 * 		<bodyFlag>0</bodyFlag> 
//		 * 		<exception></exception>
//		 * 	</header>
//		 *  <body> 
//		 * 	 <orderTrans> 
//		 * 		<mRefundSeq>r0001</mRefundSeq>
//		 * 		<curCode>001</curCode> 
//		 * 		<refundAmount>180.00</refundAmount>
//		 * 		<orderNo>324322</orderNo> 
//		 * 		<orderSeq>1231</orderSeq>
//		 * 		<orderAmount>200.12</orderAmount>
//		 * 		<bankTranSeq>2010010111111111123456</bankTranSeq>
//		 * 		<tranTime>20090605000000</tranTime>
//		 * 		<signData>MIIEZgYJKoZIhvcNAQcCoIIEVzCCBFMCAQMxCTAHBgUrDgMCGjALBgkqhkiG9w0BBwGgggMdMIIDGTCCAgGgAwIBAgIQIbAY5mFnk0lHZcajtcSdEzANBgkqhkiG9w0BAQUFADBdMQswCQYDVQQGEwJDTjEWMBQGA1UEChMNQkFOSyBPRiBDSElOQTEQMA4GA1UECBMHQkVJSklORzEQMA43pV58B8IM=</signData>
//		 * 	</orderTrans> 
//		 * </body> 
//		 * </res>
//		 */
//
//		/*
//		 * 处理失败返回信息 <?xml version="1.0" encoding="utf-8" ?> <res> <header>
//		 * <merchantNo>104110041000000</merchantNo> <returnActFlag>3</returnActFlag>
//		 * <dealStatus>1</dealStatus> <bodyFlag>1</bodyFlag>
//		 * <exception>E00000014</exception> </header> <body/> </res>
//		 */
//		Dom4jXMLMessage dom4jxml = null;
//		try {
//			dom4jxml = Dom4jXMLMessage.parse(sRetInfo.getBytes());
//		} catch (final BizException e) {
//			Log4jUtil.error(e);
//			throw new BizException("出错:" + e.getMessage());
//		}
//		final Node header = dom4jxml.getNode("/res/header");
//		final String resmerchantNo = dom4jxml.getNodeText(header, "merchantNo");
//		if (!merchantNo.equals(resmerchantNo)) {
//			throw new BizException("商户号出错！");
//		}
//		final ReturnState returnState = new ReturnState();
//		returnState.setReturnState(PayState.SUCCEED_RTN);
//		returnState.setSn(sn);// 原交易流水
//		final String dealStatus = dom4jxml.getNodeText(header, "dealStatus");// 银行联机退款的处理状态
//		// 0：成功
//		// 1：失败
//		if ("0".equals(dealStatus)) {
//			// 成功，验签并检查要素
//			// 明文由管道符“|”分割： 商户号|商户退款交易流水号|退款金额|商户订单号|银行订单流水号|订单金额|银行交易流水号|银行交易时间|退款处理状态
//			// merchantNo|mRefundSeq|refundAmount|orderNo|orderSeq| orderAmount| bankTranSeq
//			// |tranTime|dealStatus
//
//			final Node orderTransNode = dom4jxml.getNode("/res/body/orderTrans");
//			final String resmRefundSeq = dom4jxml.getNodeText(orderTransNode, "mRefundSeq");// 原来发往银行流水号
//			final String rescurCode = dom4jxml.getNodeText(orderTransNode, "curCode");
//			final String resrefundAmount = dom4jxml.getNodeText(orderTransNode, "refundAmount");
//			final String resorderNo = dom4jxml.getNodeText(orderTransNode, "orderNo");
//			final String resorderSeq = dom4jxml.getNodeText(orderTransNode, "orderSeq");
//			final String resorderAmount = dom4jxml.getNodeText(orderTransNode, "orderAmount");
//			final String resbankTranSeq = dom4jxml.getNodeText(orderTransNode, "bankTranSeq");
//			final String restranTime = dom4jxml.getNodeText(orderTransNode, "tranTime");
//			final String ressignData = dom4jxml.getNodeText(orderTransNode, "signData");
//			if (!resmRefundSeq.equals(orderNo)) {
//				throw new BizException("返回流水号不正确");
//			}
//			final StringBuffer data = new StringBuffer("");// 商户签名数据串格式，各项数据用管道符分隔：
//			data.append(resmerchantNo).append("|");
//			data.append(resmRefundSeq).append("|");
//			data.append(resrefundAmount).append("|");
//			data.append(resorderNo).append("|");
//			data.append(resorderSeq).append("|");
//			data.append(resorderAmount).append("|");
//			data.append(resbankTranSeq).append("|");
//			data.append(restranTime).append("|");
//			data.append(dealStatus);
//
//			String rootCertificatePath = ""; // 根证书路径
//			final String dn = "";// 银行签名证书DN，如果为空则不验证DN
//			rootCertificatePath = channelParam.get("100002");
//			try {
//				final PKCS7Tool tool = PKCS7Tool.getVerifier(rootCertificatePath);
//				tool.verify(signData, data.toString().getBytes(), dn);
//			} catch (final GeneralSecurityException e1) {
//				e1.printStackTrace();
//			} catch (final IOException e) {
//				Log4jUtil.error(e);
//			}
//		}
//		final String bankRetCode = ChannelTransType.Qury_Single_Trans + dealStatus;
//		returnState.setBankRetCode(dealStatus);// 银行返回状态
//
//		// 取得渠道返回信息，存入param.returnMsg 中
//		ChannelRtncode channelRtncode = null;
//		channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId, bankRetCode));
//		if (channelRtncode == null) {
//			returnState.setReturnMsg("表  channel_rtncode 没有对应的返回信息");
//			returnState.setChannelCode(TransReturnCode.code_9900);
//		} else {
//			returnState.setReturnMsg(channelRtncode.getChannelReamrk());
//			returnState.setChannelCode(channelRtncode.getKftRtncode());
//		}
//		return returnState;
//	}
// }
