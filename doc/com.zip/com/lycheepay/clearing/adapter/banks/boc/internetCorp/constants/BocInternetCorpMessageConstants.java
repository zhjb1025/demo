/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-18 下午4:10:07
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.constants;

/**
 * <P>
 * 中国银行网上银企报文常量
 * </P>
 * 
 * @author #{杜波(15999653650)}
 */
public class BocInternetCorpMessageConstants {
	public static String Sign_In = "b2e0001";               // 中行网上银企签到
	public static String Batch_Pay = "b2e0078";             // 中行网上银企快捷代发
	public static String Batch_Pay_Query = "b2e0079";       // B2E0079是明细查询
	public static String BATCH_STATUS_QUERY = "b2e0007";    // B2E0007是交易状态查询用的，
	
	public static String Other_Bank = "6";                   // 他行
	public static String Self_Bank = "7";                  // 我行
	
	public static String Batch_Refund_Furinfo = "E1";       // 批量还款摘要
}
