package com.lycheepay.clearing.adapter.banks.boc.credit.kft.bean;

/**
 * <P>中行信用卡参数</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午7:36:50
 */
public class BocCreditParam {
	private String ip;
	private String port;
	private String workKey;
	private String inputCode;
	private String conCode;
	private String clinetCode;
	private String merchant;
	private String currency;
	private String opertor;
	private String batchNo;
	private String channelCode;
	private String signFlag;
	private String pwdKey;
	private String toAddress;
	private String checkValue;
	private String fromAddress;
	private String nii;
	private String ftpServer;
	private String ftpUser;
	private String ftpPassword;
	private String ftpPath;
	private String time;

	public String getTime() {
		return time;
	}

	public void setTime(final String time) {
		this.time = time;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(final String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(final String port) {
		this.port = port;
	}

	public String getWorkKey() {
		return workKey;
	}

	public void setWorkKey(final String workKey) {
		this.workKey = workKey;
	}

	public String getInputCode() {
		return inputCode;
	}

	public void setInputCode(final String inputCode) {
		this.inputCode = inputCode;
	}

	public String getConCode() {
		return conCode;
	}

	public void setConCode(final String conCode) {
		this.conCode = conCode;
	}

	public String getClinetCode() {
		return clinetCode;
	}

	public void setClinetCode(final String clinetCode) {
		this.clinetCode = clinetCode;
	}

	public String getMerchant() {
		return merchant;
	}

	public void setMerchant(final String merchant) {
		this.merchant = merchant;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(final String currency) {
		this.currency = currency;
	}

	public String getOpertor() {
		return opertor;
	}

	public void setOpertor(final String opertor) {
		this.opertor = opertor;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(final String batchNo) {
		this.batchNo = batchNo;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(final String channelCode) {
		this.channelCode = channelCode;
	}

	public String getSignFlag() {
		return signFlag;
	}

	public void setSignFlag(final String signFlag) {
		this.signFlag = signFlag;
	}

	public String getPwdKey() {
		return pwdKey;
	}

	public void setPwdKey(final String pwdKey) {
		this.pwdKey = pwdKey;
	}

	public String getToAddress() {
		return toAddress;
	}

	public void setToAddress(final String toAddress) {
		this.toAddress = toAddress;
	}

	public String getCheckValue() {
		return checkValue;
	}

	public void setCheckValue(final String checkValue) {
		this.checkValue = checkValue;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(final String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public String getNii() {
		return nii;
	}

	public void setNii(final String nii) {
		this.nii = nii;
	}

	public String getFtpPath() {
		return ftpPath;
	}

	public void setFtpPath(final String ftpPath) {
		this.ftpPath = ftpPath;
	}

	public String getFtpServer() {
		return ftpServer;
	}

	public void setFtpServer(final String ftpServer) {
		this.ftpServer = ftpServer;
	}

	public String getFtpUser() {
		return ftpUser;
	}

	public void setFtpUser(final String ftpUser) {
		this.ftpUser = ftpUser;
	}

	public String getFtpPassword() {
		return ftpPassword;
	}

	public void setFtpPassword(final String ftpPassword) {
		this.ftpPassword = ftpPassword;
	}

}
