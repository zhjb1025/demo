package com.lycheepay.clearing.adapter.banks.boc.http.b2c.kft.util;

import org.soofa.tx.service.BaseWithoutAuditLogService;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;


/**
 * <P>中国银行HTTP 快付通工具服务类
 * (严格区分Util与UtilsService,前者为简单的静态工具类,后者需要注入其他service，并且与数据库有交集;调用方可以明显区分,如果有Service,不允许new出该对象)</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午9:54:49
 */
@Service(ClearingAdapterAnnotationName.BOC_HTTP_KFT_UTIL_SERVICE)
public class BocHttpKFTUtilService extends BaseWithoutAuditLogService {
	// @Autowired
	// @Qualifier(ClearingAdapterAnnotationName.PAY_CHANNEL_SERVICE)
	// private PayChannelService payChannelService;
	//
	// @Autowired
	// @Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	// private SequenceManagerService sequenceManagerService;
	//
	// public String getMerID(final String logPrefix, final String channelID) throws BizException {
	// final String merID = payChannelService.findById(channelID).getMerchantNo();
	// if (merID == null || merID.length() < 1) {
	// throw new BizException(logPrefix + "根据支付渠道获取的商户代码非法；");
	// }
	// return null;
	// }
	//
	// /**
	// * 检查参数配置
	// *
	// * @param logPrefix
	// * @param type
	// * @param channelParam
	// * @return
	// * @throws BizException
	// */
	// public Map<String, String> checkChannelParam(final String logPrefix, final
	// String type,
	// final Map<String, String> channelParam, final BocB2CParam bocB2CParam) throws
	// BizException {
	// String key = "";
	// String defaultValue = "";
	// String keyName = "";
	// String logMsg = "";
	// logMsg = logPrefix + "开始对渠道参数进行必要性检查。";
	// Log4jUtil.info(logMsg);
	// if (type.equals(ChannelTransType.Net_Bank_Pay + "B2C")) {
	// // 网银支付
	// final String keyNamePrefix = "B2C";
	// key = "100001";
	// keyName = keyNamePrefix + "银行支付跳转地址";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setPayUrl(channelParam.get("100001"));
	// key = "100002";
	// keyName = keyNamePrefix + "公钥位置";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setNKeyAdd(channelParam.get("100002"));
	// key = "100004";
	// keyName = keyNamePrefix + "商户私钥密码";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setKeyPass(channelParam.get("100004"));
	// key = "100005";
	// keyName = keyNamePrefix + "处理结果返回的URL";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setRetUrl(channelParam.get("100005"));
	// key = "100006";
	// keyName = keyNamePrefix + "证书密码";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setKeyStorePass(channelParam.get("100006"));
	// key = "100003";
	// keyName = keyNamePrefix + "私钥路径";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setPKeyAdd(channelParam.get("100003"));
	// key = "100009";
	// keyName = keyNamePrefix + "商户支付服务类型";
	// defaultValue = "1";
	// ChannelParamUtil.checkParamAndPut(logPrefix, key, keyName, defaultValue, channelParam);
	// bocB2CParam.setPayType(channelParam.get("100009"));
	// } else if (type.equals(ChannelTransType.Net_Bank_Pay + "B2B")) {
	// // 检查B2B支付
	// final String keyNamePrefix = "B2B";
	// } else if (type.equals(ChannelTransType.Qury_Single_Trans)) {
	// // 订单查询
	// key = "100007";
	// keyName = "银行订单查询跳转地址";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setQueryOrderUrl(channelParam.get("100007"));
	// } else if (type.equals("B2CPayServlet")) {
	// final String keyNamePrefix = "B2C";
	// key = "100002";
	// keyName = keyNamePrefix + "公钥位置";
	// ChannelParamUtil.checkParamAndThrow(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setNKeyAdd(channelParam.get("100002"));
	// key = "100012";
	// keyName = keyNamePrefix + "中行证书DN";
	// ChannelParamUtil.checkParamAndSetNull(logPrefix, key, keyName, channelParam);
	// bocB2CParam.setDn(channelParam.get("100012"));
	// }
	// logMsg = logPrefix + "对渠道参数检查结束。";
	// Log4jUtil.info(logMsg);
	// return channelParam;
	// }
	//
	// /**
	// * 创建B2C发送实体，并获取发送参数
	// *
	// * @param logPrefix 日志前缀
	// * @param httpParam 业务实体
	// * @param bocB2CParam 中行参数
	// * @param bocB2CPayBean 发送实体
	// * @param httpReturnParam
	// * @return
	// * @throws BizException
	// */
	// public HttpReturnParam createBocB2COrderSendMsg(final String logPrefix, final HttpParam
	// httpParam,
	// final BocB2CParam bocB2CParam, final BocB2CPayBean bocB2CPayBean, final HttpReturnParam
	// httpReturnParam)
	// throws BizException {
	// String logMsg = "";
	// final BocUtil bocUtil = new BocUtil();
	// final String merchantNo = this.getMerID(logPrefix, httpParam.getChannelId());
	// bocB2CPayBean.setMerchantNo(merchantNo);
	// bocB2CPayBean.setPayType(bocB2CParam.getPayType());
	// bocB2CPayBean.setOrderNo(sequenceManagerService.getBocChannelSN(DateUtil.getCurrentDate()));
	// if (bocB2CPayBean.getOrderNo() == null || bocB2CPayBean.getOrderNo().length() < 1) {
	// throw new BizException(logPrefix + "获取的订单号为空；");
	// }
	// bocB2CPayBean.setCurCode(bocB2CParam.getCurCode());
	// bocB2CPayBean.setOrderTime(DateUtil.getCurrentDateTime());
	// bocB2CPayBean.setOrderUrl(bocB2CParam.getRetUrl());
	// if (httpParam.getTransType().equals(ClearingTransType.Direct_Pay)
	// || httpParam.getTransType().equals(ClearingTransType.Guarantee_Pay)) {
	// logMsg = "获取" + logPrefix + "支付对象。";
	// Log4jUtil.info(logMsg);
	// // 支付
	// Paybill paybill = new Paybill();
	// paybill = (Paybill) httpParam.getBizBean();
	// if (paybill == null) {
	// throw new BizException(logPrefix + "获取到的支付对象为NULL。");
	// }
	// bocB2CPayBean.setOrderAmount(paybill.getChannelAmount());
	// bocB2CPayBean.setOrderNote(paybill.getOrdernote());
	// } else if (httpParam.getTransType().equals(ClearingTransType.Recharge)) {
	// logMsg = "获取" + logPrefix + "充值对象。";
	// Log4jUtil.info(logMsg);
	// // 充值
	// final Rechargebill rechargeBill = (Rechargebill) httpParam.getBizBean();
	// if (rechargeBill == null) {
	// throw new BizException(logPrefix + "获取到的充值对象为NULL。");
	// }
	// bocB2CPayBean.setOrderAmount(rechargeBill.getAmount());
	// bocB2CPayBean.setOrderNote(rechargeBill.getNote());
	// }
	// Log4jUtil.info(logMsg);
	// try {
	// bocB2CPayBean.setSignData(bocUtil.getB2CPaySign(bocB2CPayBean, bocB2CParam));
	// } catch (final Exception e) {
	// Log4jUtil.error(e.getMessage(), e);
	// throw new BizException(logPrefix + "签名失败；" + e.getMessage());
	// }
	// ObjectUtil.printPropertyString(logPrefix, bocB2CPayBean);
	// httpReturnParam.setAction(bocB2CParam.getPayUrl());
	// httpReturnParam.setParams(bocUtil.creatBocB2CPayParam(bocB2CPayBean));
	// return httpReturnParam;
	// }
	//
	// /**
	// * 向银行发送订单查询，并且接收返回信息
	// *
	// * @param logPrefix 日志前缀
	// * @param param 业务实体
	// * @param bocB2CParam 发送参数
	// * @param bocB2CQueryOrderSend 发送实体
	// * @param bocB2CQueryOrderRecv 接收订单汇总实体
	// * @return
	// * @throws Exception
	// */
	// public void queryOder(final String logPrefix, final Param param, final BocB2CParam
	// bocB2CParam,
	// final BocB2CQueryOrderSend bocB2CQueryOrderSend, final BocB2CQueryOrderRecv
	// bocB2CQueryOrderRecv)
	// throws Exception {
	// String orderNos = "";
	// final String[] orderNo = (String[]) param.getBizBean();
	// for (final String element : orderNo) {
	// orderNos = orderNos + element + "|";
	// }
	// orderNos = orderNos.substring(0, (orderNos.length() - 1));
	// final BocUtil bocUtil = new BocUtil();
	// bocB2CQueryOrderSend.setMerchantNo(this.getMerID(logPrefix, param.getChannelId()));
	// bocB2CQueryOrderSend.setOrderNos(orderNos);
	// bocB2CQueryOrderSend.setSignData(bocUtil.sign(orderNos, bocB2CParam));
	// // 获取参数列表 这步有点无谓，但是为了保持银行代码方面的提取特意增加
	// final Map<String, String> params = bocUtil.creatBocB2CQueryOrderParam(bocB2CQueryOrderSend);
	// final Properties formProperties = new Properties();
	// for (final String string : params.keySet()) {
	// final String keyName = string;
	// final String keyValue = params.get(keyName);
	// formProperties.put(keyName, keyValue);
	// }
	// // 发送并接收xml报文
	// final byte[] xml = NetUtils.requestPostForm(bocB2CParam.getQueryOrderUrl(), formProperties);
	// // 解析xml报文为实体
	// bocUtil.parsingQueryOrderXml(xml, bocB2CQueryOrderRecv);
	// }
	//
	// public BocB2CRefundOrder createBocB2CRefundOrder(final String logPrefix, final String merID)
	// throws BizException {
	// return null;
	// }
}
