/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:35:19
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;


/**
 * <P>单笔查询结果</P>
 * 
 * @author 张凯锋
 */
public class C003Response extends ResponseHead {

	private String packNo;// 此批次包号 PACK_NO M 包号
	private String count;// 总个数 4 BYTE M 4位10进制数字最大2000
	private String sum;// 总金额 MONEY M 该包下所有交易的金额总和
	private List<C003ResponseDetail> details = new ArrayList<C003ResponseDetail>();

	public C003Response() {
		super();
	}

	public C003Response(final byte[] respBytes) throws BizException {
		final Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(respBytes);
		final Node head = dom4jxml.getNode("/C003_RESPONSE/HEAD");
		setResponseHead(dom4jxml, head);
		final Node batch = dom4jxml.getNode("/C003_RESPONSE/BODY/BATCH");
		packNo = dom4jxml.getNodeText(batch, "PACK_NO");
		count = dom4jxml.getNodeText(batch, "COUNT");
		sum = dom4jxml.getNodeText(batch, "SUM");
		final List<Node> nodes = dom4jxml.getNodeList("/C003_RESPONSE/BODY/DETAILS/DETAIL");
		for (int i = 0, len = nodes.size(); i < len; i++) {
			details.add(new C003ResponseDetail(dom4jxml, nodes.get(i)));
		}
	}

	public String getPackNo() {
		return packNo;
	}

	public void setPackNo(final String packNo) {
		this.packNo = packNo;
	}

	public String getCount() {
		return count;
	}

	public void setCount(final String count) {
		this.count = count;
	}

	public String getSum() {
		return sum;
	}

	public void setSum(final String sum) {
		this.sum = sum;
	}

	public List<C003ResponseDetail> getDetails() {
		return details;
	}

	public void setDetails(final List<C003ResponseDetail> details) {
		this.details = details;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * @author 张凯锋
	 */
	@Override
	public String toString() {
		return "C003Response [packNo=" + packNo + ", count=" + count + ", sum=" + sum + ", details=" + details
				+ ", ResultCode=" + getResultCode() + ", ResultDesc=" + getResultDesc() + ", sendTimestamp="
				+ getSendTimestamp() + ", toString=" + super.toString() + "]";
	}

}
