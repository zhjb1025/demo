/*******************************************************************************
 * Project Key : CPP
 * Create on 2012-8-2 下午5:01:32
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.credit.directnet;

import java.io.IOException;
import java.io.OutputStream;

import org.soofa.remoting.Channel;
import org.soofa.remoting.Encoder;
import org.soofa.remoting.SoofaRemotingException;

import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.ByteUtils;
import com.lycheepay.clearing.adapter.banks.boc.credit.pos8583.MsgPack;
import com.lycheepay.clearing.adapter.common.service.channel.directnet.BankInteractiveParam;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企直连编码器</P>
 * 
 * @author 邱林 Leon.Qiu 2012-8-2 下午5:01:32
 */
public class BocCreditEncoder implements Encoder {

	private static String localSysCode = "";
	private static String des = "";

	/**
	 * <p>Method for constructor</p>
	 * 
	 * @param config
	 */
	public BocCreditEncoder(final BankInteractiveParam config) {
		localSysCode = config.getCheckCode();
		des = config.getDes();
	}

	/**
	 * @see org.soofa.remoting.Encoder#encode(org.soofa.remoting.Channel, java.io.OutputStream,
	 *      java.lang.Object)
	 * @author 邱林 Leon.Qiu 2012-8-2 下午5:03:10
	 */
	@Override
	public void encode(final Channel channel, final OutputStream output, final Object msg) {
		byte[] bytes = null;
		try {
			bytes = ((MsgPack) msg).getBytes();
		} catch (final Exception e) {
			Log4jUtil.error(e);
			throw new SoofaRemotingException(e.getMessage(), e);
		}
		Log4jUtil.info("调用BocCreditClinet方法发送到,渠道的报文数据:" + ByteUtils.bcdToStr(bytes));
		try {
			output.write(bytes);
			output.flush();
		} catch (final IOException e) {
			throw new SoofaRemotingException(e.getMessage(), e);
		}
	}
}
