package com.lycheepay.clearing.adapter.banks.boc.credit.pos8583;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.LoUtils;
import com.lycheepay.clearing.adapter.banks.boc.credit.kft.util.MacUtil;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AmountUtils;


/**
 * 消息包工具.
 * 
 * @author aps-mhc
 */
public abstract class MsgPackUtils {

	/**
	 * 创建tpdu域.
	 */
	public static void createTpduField(final MsgPack msgPack, final byte[] b) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.TPDU;
		final MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(b);
		msgPack.put(field);
	}

	/**
	 * 创建head域.
	 */
	public static void createHeadField(final MsgPack msgPack, final byte[] b) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.HEAD;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(b);
		msgPack.put(field);
	}

	public static void resetMsgType(final MsgPack msgPack, final String newMsgType) {
		final MsgField field = msgPack.getField(MsgFieldType.MSG_TYPE.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
	}

	public static void createMsgType(final MsgPack msgPack, final String newMsgType) {
		final MsgFieldType fieldType = MsgFieldType.MSG_TYPE;
		final MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(ByteUtils.strToBcdRightSide(newMsgType));
		msgPack.put(field);
	}

	public static void createAccountField(final MsgPack msgPack, final String accountNo) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.FIELD_2;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		final int valueLen = accountNo.getBytes().length;
		final byte[] bcdAccountNo = ByteUtils.strToBcdLeftSide(accountNo);
		final byte[] bcdLen = ByteUtils.intToBcdRightSide(valueLen);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bcdAccountNo));

		msgPack.putBitmapField(field);
	}

	/**
	 * 交易处理码.
	 * 
	 * @param msgPack
	 * @param tradeDealCode
	 */
	public static void createField3(final MsgPack msgPack, final String tradeDealCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_3;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(tradeDealCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 创建第4域交易金额
	 * 
	 * @param msgPack
	 * @param amount 交易金额, 单位:元
	 */
	public static void createField4(final MsgPack msgPack, final Double amount) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_4;

		final long cent = (long) AmountUtils.format(amount * 100);
		String strAmount = Long.toString(cent);
		strAmount = StringUtils.leftPad(strAmount, fieldType.getMaxLength() * 2, '0'); // 补足编码前12位长度.
		final MsgField field = MsgField.create(fieldType.getNo());
		// 设置bcd编码的交易金额.
		final byte[] bcdAmount = ByteUtils.strToBcd(strAmount);
		field.setOrigMsg(bcdAmount);
		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡方系统跟踪号.
	 * 
	 * @param msgPack
	 * @param trackeCode
	 */
	public static void createField11(final MsgPack msgPack, final String trackeCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_11;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(trackeCode));
		msgPack.putBitmapField(field);
	}

	public static void createDefaultField12(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_12.getNo());
		final byte[] bcd = ByteUtils.strToBcd("000000");
		field.setOrigMsg(bcd);

		msgPack.putBitmapField(field);
	}

	public static void createDefaultField13(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_13.getNo());
		final byte[] bcd = ByteUtils.strToBcd("0000");
		field.setOrigMsg(bcd);

		msgPack.putBitmapField(field);
	}

	/**
	 * 卡有效期
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField14(final MsgPack msgPack, final String conditionCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_14;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcd(conditionCode));
		msgPack.putBitmapField(field);
	}

	public static void createField15(final MsgPack msgPack, final String conditionCode) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_15.getNo());
		final byte[] bcd = ByteUtils.strToBcd(conditionCode);
		field.setOrigMsg(bcd);

		msgPack.putBitmapField(field);
	}

	/**
	 * 服务点输入方式码.
	 * 
	 * @param msgPack
	 * @param inputModeCode
	 */
	public static void createField22(final MsgPack msgPack, final String inputModeCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_22;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(inputModeCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * NII
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField24(final MsgPack msgPack, final String inputModeCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_24;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(inputModeCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 服务点条件码.
	 * 
	 * @param msgPack
	 * @param conditionCode
	 */
	public static void createField25(final MsgPack msgPack, final String conditionCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_25;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdLeftSide(conditionCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 生成37检索参考号,加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField37(final MsgPack msgPack, final String rspCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_37;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成38授权标识应答码, 请求时，同原预授权交易,加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField38(final MsgPack msgPack, final String rspCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_38;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 生成39应答码域, 加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField39(final MsgPack msgPack, final String rspCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_39;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(rspCode.getBytes());

		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡机终端标识码.
	 * 
	 * @param msgPack
	 * @param terminalCode
	 */
	public static void createField41(final MsgPack msgPack, String terminalCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_41;
		final MsgField field = MsgField.create(fieldType.getNo());
		terminalCode = ByteUtils.rightPadSpaceByByte(terminalCode, 8);
		field.setOrigMsg(terminalCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 受卡方标识码.
	 * 
	 * @param msgPack
	 * @param merchantNo
	 */
	public static void createField42(final MsgPack msgPack, String merchantNo) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_42;
		final MsgField field = MsgField.create(fieldType.getNo());
		merchantNo = ByteUtils.rightPadSpaceByByte(merchantNo, 15);
		field.setOrigMsg(merchantNo.getBytes());
		msgPack.putBitmapField(field);
	}

	public static void createDefaultField44(final MsgPack msgPack) {
		final MsgField field = MsgField.create(MsgFieldType.FIELD_44.getNo());
		final byte[] bcdLen = ByteUtils.strToBcd("01");
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, "0".getBytes()));

		msgPack.putBitmapField(field);
	}

	/**
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField48(final MsgPack msgPack, final byte[] currencyCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_48;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(currencyCode);
		msgPack.putBitmapField(field);
	}

	/**
	 * 交易货币代码.
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField49(final MsgPack msgPack, final String currencyCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_49;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(ByteUtils.strToBcdRightSide(currencyCode));
		msgPack.putBitmapField(field);
	}

	/**
	 * 如果PIN或者MAC存在则必须存在
	 * 
	 * @param msgPack
	 * @param currencyCode
	 */
	public static void createField53(final MsgPack msgPack, final String currencyCode) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_53;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(currencyCode.getBytes());
		msgPack.putBitmapField(field);
	}

	/**
	 * 生成57自定义域, 加入到包中.
	 * 
	 * @param msgPack
	 * @param bytes
	 */
	public static void createField57(final MsgPack msgPack, final byte[] bytes) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_57;

		final MsgField field = MsgField.create(fieldType.getNo());
		field.setHasLeaderLength(true);
		field.setLenOfLeaderLength(fieldType.getParser().getLenOfLeaderLength());

		// 设置值.
		final int lenSize = field.getLenOfLeaderLength() * 2;
		final String lengthValue = StringUtils.leftPad(String.valueOf(bytes.length), lenSize, '0');
		final byte[] bcdLen = ByteUtils.strToBcd(lengthValue);
		field.setOrigMsg(ArrayUtils.addAll(bcdLen, bytes));

		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域61:交易类型码+批次号
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField61(final MsgPack msgPack, final byte[] customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_61;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue);
		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域:原交易的信息类型代码+原交易系统跟踪号+原交易的交易日期
	 * 
	 * @param msgPack TODO
	 * @param customValue
	 */
	public static void createField62(final MsgPack msgPack, final byte[] customValue) {

		final MsgFieldType fieldType = MsgFieldType.FIELD_62;

		final MsgField field = MsgField.create(fieldType.getNo());

		field.setOrigMsg(customValue);

		msgPack.putBitmapField(field);
	}

	/**
	 * 自定义域:63
	 * 
	 * @param msgPack
	 * @param customValue
	 */
	public static void createField63(final MsgPack msgPack, final byte[] customValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_63;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(customValue);
		msgPack.putBitmapField(field);
	}

	/**
	 * MAC.
	 * 
	 * @param msgPack
	 * @param macValue
	 */
	public static void createField64(final MsgPack msgPack, final String macValue) {
		final MsgFieldType fieldType = MsgFieldType.FIELD_64;
		final MsgField field = MsgField.create(fieldType.getNo());
		field.setOrigMsg(macValue.getBytes());
		msgPack.putBitmapField(field);
	}

	public static void resetTpduFrom(final MsgPack msgPack, final String from) throws BizException {
		if (StringUtils.isEmpty(from)) {
			return;
		}

		final Tpdu tpdu = msgPack.getTpdu();
		tpdu.setFrom(from);
		msgPack.setTpdu(tpdu);
	}

	public static void resetTpduTo(final MsgPack msgPack, final String to) throws BizException {
		if (StringUtils.isEmpty(to)) {
			return;
		}

		final Tpdu tpdu = msgPack.getTpdu();
		tpdu.setTo(to);
		msgPack.setTpdu(tpdu);
	}

	/**
	 * 复制源包中的域到目标包, 源包无指定域则不复制.
	 */
	public static void copyField(final MsgPack destPack, final MsgPack srcPack, final MsgFieldType fieldType) {
		final MsgField srcField = srcPack.getField(fieldType.getNo());

		if (srcField == null) {
			return;
		}

		final MsgField newField = srcField.clone();
		final int bitmapIndex = fieldType.getBitmapIndex();

		if (bitmapIndex >= 0) {
			destPack.putBitmapField(newField);
		} else {
			destPack.put(newField);
		}
	}

	/**
	 * 计算mac.
	 * 
	 * @param msgPack
	 * @param posIdPrefix 终端标识前置,用于加密机中识别终端密钥数据
	 * @throws BizException
	 */
	public static void createMac(final MsgPack msgPack, final byte[] macData, final String workKey) throws BizException {
		final MsgFieldType fieldType = MsgFieldType.FIELD_64;

		final String macString = MacUtil.getMacData(workKey, macData);

		final byte[] newMac = LoUtils.hexStr2Bytes(macString);
		final MsgField macField = MsgField.create(fieldType.getNo());

		macField.setOrigMsg(newMac);
		msgPack.putBitmapField(macField);
	}
}
