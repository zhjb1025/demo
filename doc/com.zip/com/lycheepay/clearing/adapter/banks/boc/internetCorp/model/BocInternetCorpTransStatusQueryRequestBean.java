/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-8-22 下午3:30:46
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.model;

import org.soofa.core.model.BaseObject;


/**
 * <P>中国银行网上银企交易状态查询请求参数</P>
 * 
 * @author 杜波(15999653650)
 */
public class BocInternetCorpTransStatusQueryRequestBean extends BaseObject {

	private static final long serialVersionUID = 5841498252714672660L;
	/**
	 * 转账指令ID
	 */
	private String insid;
	/**
	 * 网银交易流水号
	 */
	private String obssid;

	public String getInsid() {
		return insid;
	}

	public void setInsid(String insid) {
		this.insid = insid;
	}

	public String getObssid() {
		return obssid;
	}

	public void setObssid(String obssid) {
		this.obssid = obssid;
	}

}
