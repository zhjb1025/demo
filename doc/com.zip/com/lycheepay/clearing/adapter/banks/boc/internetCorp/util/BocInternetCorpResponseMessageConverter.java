/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-5-23 上午11:24:35
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.internetCorp.util;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Node;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayQueryResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayQueryResponseDetailBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpQuickPayResponseMessagesBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpSignInResponseBean;
import com.lycheepay.clearing.adapter.banks.boc.internetCorp.model.BocInternetCorpTransStatusQueryResponseBean;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;


@Service
public class BocInternetCorpResponseMessageConverter {
	/**
	 * 
	 * 处理中国银行网上银企签到响应报文
	 * 
	 * @param responseMessage 响应报文
	 * @return
	 * @author 杜波(15999653650)
	 * @throws Exception
	 */
	public BocInternetCorpSignInResponseBean getBocInternetCorpSignInResponseMessage(byte[] responseMessage)
			throws BizException {

		if (responseMessage != null && responseMessage.length > 0) {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(responseMessage);
			return this.parseXmlResponseMessageToSignInBean(dom4jxml);
		}
		return null;
	}

	/**
	 * 
	 * <p>解析签到响应报文</p>
	 * 
	 * @param dom4jxml
	 * @return
	 * @author #{杜波(15999653650)}
	 */
	public BocInternetCorpSignInResponseBean parseXmlResponseMessageToSignInBean(Dom4jXMLMessage dom4jxml)
			throws BizException {
		BocInternetCorpSignInResponseBean bocCorpSignInResponseBean = new BocInternetCorpSignInResponseBean();
		try {
			Node statusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0001-rs/status");
			bocCorpSignInResponseBean.setRspCod(dom4jxml.getNodeText(statusNode, "rspcod"));
			bocCorpSignInResponseBean.setErrMsg(dom4jxml.getNodeText(statusNode, "rspmsg"));

			if ("B001".equalsIgnoreCase(bocCorpSignInResponseBean.getRspCod())) {
				Node trnNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0001-rs");
				bocCorpSignInResponseBean.setServerDt(dom4jxml.getNodeText(trnNode, "serverdt"));
				bocCorpSignInResponseBean.setToken(dom4jxml.getNodeText(trnNode, "token"));
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "解析签到响应报文出错！" + e.getMessage());
		}
		return bocCorpSignInResponseBean;
	}

	/**
	 * 
	 * <p> 处理中国银行网上银企快捷代发响应报文 </p>
	 * 
	 * @param responseMessage 响应报文
	 * @return
	 * @author 杜波(15999653650)
	 */
	public BocInternetCorpQuickPayResponseMessagesBean getBocInternetCorpQuickPayResponseMessage(byte[] responseMessage)
			throws BizException {

		if (responseMessage != null && responseMessage.length > 0) {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(responseMessage);
			return this.parseXmlResponseMessageToQuickPayBean(dom4jxml);
		}
		return null;
	}

	/**
	 * 
	 * <p>解析快捷代发响应报文</p>
	 * 
	 * @param dom4jxml
	 * @return
	 * @author #{杜波(15999653650)}
	 */
	public BocInternetCorpQuickPayResponseMessagesBean parseXmlResponseMessageToQuickPayBean(Dom4jXMLMessage dom4jxml)
			throws BizException {

		BocInternetCorpQuickPayResponseMessagesBean quickPayResponseMessagesBean = new BocInternetCorpQuickPayResponseMessagesBean();
		try {
			Node statusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0078-rs/status");
			Node errorNode = dom4jxml.getNode("/bocb2e/trans/trn-b2eerror-rs/status");
			if (errorNode != null) {
				quickPayResponseMessagesBean.setRspcod(dom4jxml.getNodeText(errorNode, "rspcod"));
				quickPayResponseMessagesBean.setRspmsg(dom4jxml.getNodeText(errorNode, "rspmsg"));
			} else {
				quickPayResponseMessagesBean.setRspcod(dom4jxml.getNodeText(statusNode, "rspcod"));
				quickPayResponseMessagesBean.setRspmsg(dom4jxml.getNodeText(statusNode, "rspmsg"));
			}

			if ("B001".equalsIgnoreCase(quickPayResponseMessagesBean.getRspcod())) {
				Node subStatusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0078-rs/b2e0078-rs/status");

				if (subStatusNode != null) {
					quickPayResponseMessagesBean.setSubRspcod(dom4jxml.getNodeText(subStatusNode, "rspcod"));
					quickPayResponseMessagesBean.setSubRspmsg(dom4jxml.getNodeText(subStatusNode, "rspmsg"));
				} else if (errorNode != null) {
					quickPayResponseMessagesBean.setSubRspcod(dom4jxml.getNodeText(errorNode, "rspcod"));
					quickPayResponseMessagesBean.setSubRspmsg(dom4jxml.getNodeText(errorNode, "rspmsg"));
				} else {
					subStatusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0078-rs/status");
					quickPayResponseMessagesBean.setSubRspcod(dom4jxml.getNodeText(subStatusNode, "rspcod"));
					quickPayResponseMessagesBean.setSubRspmsg(dom4jxml.getNodeText(subStatusNode, "rspmsg"));
				}

				Node trnNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0078-rs/b2e0078-rs");
				quickPayResponseMessagesBean.setInsid(dom4jxml.getNodeText(trnNode, "insid"));
				quickPayResponseMessagesBean.setObssid(dom4jxml.getNodeText(trnNode, "obssid"));
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "解析快捷代发响应报文出错！" + e.getMessage());
		}
		return quickPayResponseMessagesBean;
	}

	/**
	 * 
	 * <p> 处理中国银行网上银企快捷代发查询响应报文 </p>
	 * 
	 * @param responseMessage 响应报文
	 * @return
	 * @author 杜波(15999653650)
	 */
	public BocInternetCorpQuickPayQueryResponseBean getBocInternetCorpQuickPayQueryResponseMessage(
			byte[] responseMessage) throws ClearingAdapterBizCheckedException {
		if (responseMessage != null && responseMessage.length > 0) {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(responseMessage);
			return this.parseXmlResponseMessageToQuickPayQueryBean(dom4jxml);
		}
		return null;
	}

	/**
	 * 
	 * <p>解析快捷代发查询响应报文</p>
	 * 
	 * @param dom4jxml
	 * @return
	 * @author #{杜波(15999653650)}
	 */
	public BocInternetCorpQuickPayQueryResponseBean parseXmlResponseMessageToQuickPayQueryBean(Dom4jXMLMessage dom4jxml)
			throws BizException {
		BocInternetCorpQuickPayQueryResponseBean quickPayQueryResponseBean = new BocInternetCorpQuickPayQueryResponseBean();
		List<BocInternetCorpQuickPayQueryResponseDetailBean> list = new ArrayList<BocInternetCorpQuickPayQueryResponseDetailBean>();
		try {

			// 报文整体信息
			Node statusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0079-rs/status");
			quickPayQueryResponseBean.setRspcod(dom4jxml.getNodeText(statusNode, "rspcod"));
			quickPayQueryResponseBean.setRspmsg(dom4jxml.getNodeText(statusNode, "rspmsg"));

			Node trnNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0079-rs");
			quickPayQueryResponseBean.setInsid(dom4jxml.getNodeText(trnNode, "insid"));
			quickPayQueryResponseBean.setObssid(dom4jxml.getNodeText(trnNode, "obssid"));
			quickPayQueryResponseBean.setActacn(dom4jxml.getNodeText(trnNode, "actacn"));
			quickPayQueryResponseBean.setPybcur(dom4jxml.getNodeText(trnNode, "pybcur"));
			quickPayQueryResponseBean.setPybamt(dom4jxml.getNodeText(trnNode, "pybamt"));
			quickPayQueryResponseBean.setPybnum(dom4jxml.getNodeText(trnNode, "pybnum"));
			quickPayQueryResponseBean.setCrdtyp(dom4jxml.getNodeText(trnNode, "crdtyp"));
			quickPayQueryResponseBean.setFurinfo(dom4jxml.getNodeText(trnNode, "furinfo"));
			quickPayQueryResponseBean.setUseinf(dom4jxml.getNodeText(trnNode, "useinf"));
			quickPayQueryResponseBean.setTrfdate(dom4jxml.getNodeText(trnNode, "trfdate"));
			if ("B001".equalsIgnoreCase(quickPayQueryResponseBean.getRspcod())) {

				// 解析笔明细
				List<Node> subNode = dom4jxml.getNodeList("/bocb2e/trans/trn-b2e0079-rs/b2e0079-rs");

				if (subNode != null && subNode.size() > 0) {
					for (int i = 0; i < subNode.size(); i++) {
						BocInternetCorpQuickPayQueryResponseDetailBean quickPayQueryResponseDetail = new BocInternetCorpQuickPayQueryResponseDetailBean();
						Node node = subNode.get(i);

						// 笔明细状态
						Node detailNode = node.selectSingleNode("./status");
						quickPayQueryResponseDetail.setRspcod(dom4jxml.getNodeText(detailNode, "rspcod"));
						quickPayQueryResponseDetail.setRspmsg(dom4jxml.getNodeText(detailNode, "rspmsg"));

						// 笔明细详细信息
						quickPayQueryResponseDetail.setToibkn(dom4jxml.getNodeText(node, "toibkn"));
						quickPayQueryResponseDetail.setTobank(dom4jxml.getNodeText(node, "tobank"));
						quickPayQueryResponseDetail.setToactn(dom4jxml.getNodeText(node, "toactn"));
						quickPayQueryResponseDetail.setToname(dom4jxml.getNodeText(node, "toname"));
						quickPayQueryResponseDetail.setPydcur(dom4jxml.getNodeText(node, "pydcur"));
						quickPayQueryResponseDetail.setPydamt(dom4jxml.getNodeText(node, "pydamt"));
						quickPayQueryResponseDetail.setToidtp(dom4jxml.getNodeText(node, "toidtp"));
						quickPayQueryResponseDetail.setToidet(dom4jxml.getNodeText(node, "toidet"));
						quickPayQueryResponseDetail.setFurinfo(dom4jxml.getNodeText(node, "furinfo"));
						quickPayQueryResponseDetail.setReserve1(dom4jxml.getNodeText(node, "reserve1"));
						quickPayQueryResponseDetail.setReserve2(dom4jxml.getNodeText(node, "reserve2"));
						quickPayQueryResponseDetail.setReserve3(dom4jxml.getNodeText(node, "reserve3"));
						quickPayQueryResponseDetail.setReserve4(dom4jxml.getNodeText(node, "reserve4"));

						list.add(quickPayQueryResponseDetail);
					}
				}
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "解析快捷代发查询响应报文出错！" + e.getMessage());
		}
		quickPayQueryResponseBean.setList(list);
		return quickPayQueryResponseBean;
	}

	/**
	 * 
	 * <p> 处理中国银行网上银企交易状态查询响应报文 </p>
	 * 
	 * @param responseMessage 响应报文
	 * @return
	 * @author 杜波(15999653650)
	 */
	public BocInternetCorpTransStatusQueryResponseBean getBocInternetCorpTransStatusResponseMessage(
			byte[] responseMessage) throws ClearingAdapterBizCheckedException {

		if (responseMessage != null && responseMessage.length > 0) {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(responseMessage);
			return this.parseXmlResponseMessageToTransStatusBean(dom4jxml);
		}
		return null;
	}

	/**
	 * 
	 * <p>解析交易状态查询响应报文</p>
	 * 
	 * @param dom4jxml
	 * @return
	 * @author #{杜波(15999653650)}
	 */
	public BocInternetCorpTransStatusQueryResponseBean parseXmlResponseMessageToTransStatusBean(Dom4jXMLMessage dom4jxml)
			throws BizException {

		BocInternetCorpTransStatusQueryResponseBean transStatusQueryResponseBean = new BocInternetCorpTransStatusQueryResponseBean();
		try {
			Node statusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0007-rs/status");
			Node errorNode = dom4jxml.getNode("/bocb2e/trans/trn-b2eerror-rs/status");
			if (errorNode != null) {
				transStatusQueryResponseBean.setRspcod(dom4jxml.getNodeText(errorNode, "rspcod"));
				transStatusQueryResponseBean.setRspmsg(dom4jxml.getNodeText(errorNode, "rspmsg"));
			} else {
				transStatusQueryResponseBean.setRspcod(dom4jxml.getNodeText(statusNode, "rspcod"));
				transStatusQueryResponseBean.setRspmsg(dom4jxml.getNodeText(statusNode, "rspmsg"));
			}

			if ("B001".equalsIgnoreCase(transStatusQueryResponseBean.getRspcod())) {
				Node subStatusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0007-rs/b2e0007-rs/status");

				if (subStatusNode != null) {
					transStatusQueryResponseBean.setSubRspcod(dom4jxml.getNodeText(subStatusNode, "rspcod"));
					transStatusQueryResponseBean.setSubRspmsg(dom4jxml.getNodeText(subStatusNode, "rspmsg"));
				} else if (errorNode != null) {
					transStatusQueryResponseBean.setSubRspcod(dom4jxml.getNodeText(errorNode, "rspcod"));
					transStatusQueryResponseBean.setSubRspmsg(dom4jxml.getNodeText(errorNode, "rspmsg"));
				} else {
					subStatusNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0007-rs/status");
					transStatusQueryResponseBean.setSubRspcod(dom4jxml.getNodeText(subStatusNode, "rspcod"));
					transStatusQueryResponseBean.setSubRspmsg(dom4jxml.getNodeText(subStatusNode, "rspmsg"));
				}

				Node trnNode = dom4jxml.getNode("/bocb2e/trans/trn-b2e0007-rs/b2e0007-rs");
				transStatusQueryResponseBean.setInsid(dom4jxml.getNodeText(trnNode, "insid"));
				transStatusQueryResponseBean.setObssid(dom4jxml.getNodeText(trnNode, "obssid"));
			}
		} catch (Exception e) {
			throw new BizException(e, TransReturnCode.code_9109, "解析交易状态查询响应报文出错！" + e.getMessage());
		}
		return transStatusQueryResponseBean;
	}
}
