package com.lycheepay.clearing.adapter.banks.boc.http.b2c.bank.bean;

/**
 * 中行B2C支付结果通知实体 <p>Description:</p> <p>Copyright: Copyright (c) 2011</p> <p>Company: 雁联</p>
 * 
 * @author aps-cji
 * @version 1.0
 */
public class BocB2CNoticeBean {
	private String merchantNo;// 商户号
	private String orderNo;// 订单号
	private String orderSeq;// 银行的订单流水号（银行产生的订单唯一标识）
	private String cardTyp;// 银行卡类别 01：中行借记卡
	// 02：中行信用卡，信用卡（分行卡）
	// 04：中行信用卡，信用卡（总行卡）
	// 11：银联借记卡
	// 21：VISA借记卡
	// 22：VISA信用卡
	// 31：MC 借记卡
	// 32：MC 信用卡
	// 42：运通卡
	// 52：大来卡
	// 62：JCB卡
	private String payTime;// 支付交易的日期时间
	private String orderStatus;// 订单状态：
	// 0：未处理
	// 1：支付
	// 2：撤销
	// 3：退货
	// 4：未明
	// 5：失败
	private String payAmount;// 支付金额
	private String orderIP;// 客户通过网银支付时的IP地址信息
	private String orderRefer;// 客户浏览器跳转至网银支付登录界面前所在页面的URL
	private String bankTranSeq;// 银行交易流水号 银行交易日期(8位)+POS终端号(8位)+POS流水号(6位)
	private String returnActFlag;// 银行返回的操作类型
	// 1：支付结果通知
	// 2：电话订单结果通知
	// 3：退款结果通知
	// 4：订单查询结果
	private String signData;// 网关签名数据串格式，各项数据用管道符分隔：

	// 商户号|商户订单号|银行订单流水号|银行卡类别|支付时间|订单状态|支付金额
	// merchantNo|orderNo|orderSeq|cardTyp|payTime|orderStatus|payAmount
	// end

	public String getOrderSeq() {
		return orderSeq;
	}

	public void setOrderSeq(final String orderSeq) {
		this.orderSeq = orderSeq;
	}

	public String getCardTyp() {
		return cardTyp;
	}

	public void setCardTyp(final String cardTyp) {
		this.cardTyp = cardTyp;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(final String payTime) {
		this.payTime = payTime;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(final String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(final String payAmount) {
		this.payAmount = payAmount;
	}

	public String getOrderIP() {
		return orderIP;
	}

	public void setOrderIP(final String orderIP) {
		this.orderIP = orderIP;
	}

	public String getOrderRefer() {
		return orderRefer;
	}

	public void setOrderRefer(final String orderRefer) {
		this.orderRefer = orderRefer;
	}

	public String getBankTranSeq() {
		return bankTranSeq;
	}

	public void setBankTranSeq(final String bankTranSeq) {
		this.bankTranSeq = bankTranSeq;
	}

	public String getReturnActFlag() {
		return returnActFlag;
	}

	public void setReturnActFlag(final String returnActFlag) {
		this.returnActFlag = returnActFlag;
	}

	public String getSignData() {
		return signData;
	}

	public void setSignData(final String signData) {
		this.signData = signData;
	}

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(final String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(final String orderNo) {
		this.orderNo = orderNo;
	}
}
