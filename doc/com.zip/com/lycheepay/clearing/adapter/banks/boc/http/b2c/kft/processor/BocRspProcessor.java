package com.lycheepay.clearing.adapter.banks.boc.http.b2c.kft.processor;

//package com.lycheepay.clearing.adapter.banks.boc.b2c.kft.processor;
//
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
//import com.lycheepay.clearing.adapter.common.model.channel.param.BaseParam;
//import com.lycheepay.clearing.adapter.common.model.channel.param.PayRspParam;
//import com.lycheepay.clearing.adapter.common.model.channel.param.ReturnState;
//import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
//
//
///**
// * 中行银行http支付回应处理
// * 
// * @author aps-lfm
// * @2010-12-20
// */
//public class BocRspProcessor implements IRspProcessor {
//
//	private static ChannelRtncodeService channelRtncodeDao = (ChannelRtncodeService) SpringContext
//			.getService("channelRtncodedao");
//
//	@Override
//	public ReturnState deal(final BaseParam param, final ReturnState state) throws BizException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public ReturnState dealHttp(final PayRspParam param) throws BizException {
//		// 中行网银支付返回状态 0：成功 1：不确定 2：失败 银行给商户发的信息中此项必为0，因为1，2都不发送
//		final ReturnState returnState = new ReturnState();
//		if (param.getTranResult().equals("1")) {
//			returnState.setReturnState(PayState.SUCCEED_RTN);
//		} else {
//			returnState.setReturnState(PayState.FAILED_TRN);
//		}
//		returnState.setReturnState(param.getReturnState());
//		returnState.setChannelCode(channelRtncodeDao.findById(
//				new ChannelRtncodeId(param.getChannelId(), param.getTranResult())).getKftRtncode());
//		returnState.setReturnMsg(param.getRemark());
//		returnState.setBankRetCode(param.getReturnState());
//		returnState.setSn(param.getSn());
//
//		return returnState;
//	}
//
// }
