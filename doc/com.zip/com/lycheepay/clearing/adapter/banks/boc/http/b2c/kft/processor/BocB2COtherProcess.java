package com.lycheepay.clearing.adapter.banks.boc.http.b2c.kft.processor;

//package com.lycheepay.clearing.adapter.banks.boc.b2c.kft.processor;
//
//import java.util.List;
//
//import com.lycheepay.clearing.adapter.common.exception.BizException;
//import com.lycheepay.clearing.common.model.BillnoSn;
//import com.lycheepay.clearing.adapter.common.model.biz.PayChannel;
//import com.lycheepay.clearing.adapter.common.service.biz.PayChannelService;
//import com.lycheepay.clearing.adapter.common.util.biz.AmountUtils;
//import com.lycheepay.clearing.common.constant.ChannelId;
//import com.lycheepay.clearing.util.Log4jUtil;
//
//
//public class BocB2COtherProcess implements IOtherProcess {
//	private static BillnoSnDao billnoSnDao = (BillnoSnDao) SpringContext.getService("billnoSnDao");
//	private static PayChannelService payChannelDao = (PayChannelService) SpringContext.getService("payChannelDao");
//	private static String line = System.getProperty("line.separator"); // 回车换行符
//
//	@Override
//	public Object deal(final String channelId, final Object object) throws BizException {
//		String logMsg = "";
//		String logPrefix = "";
//		logPrefix = channelId + ChannelId.getNameByValue(channelId);
//		logMsg = "进入 " + logPrefix + " 渠道业务处理。";
//		Log4jUtil.info(logMsg);
//		if (CBRFParam.class == object.getClass()) {
//			// 产生批量文件
//			return this.creatBatchRefundFile(logPrefix, object);
//		}
//		throw new BizException(logPrefix + " 错误的参数类型");
//	}
//
//	/**
//	 * 用于创建批量退款文件
//	 * 
//	 * @param logPrefix
//	 * @param object
//	 * @return
//	 * @throws BizException
//	 */
//	private Object creatBatchRefundFile(final String logPrefix, final Object object) throws BizException {
//		String logMsg = "";
//		final CBRFParam cBRFParam = (CBRFParam) object;
//		final String merId = ((PayChannel) payChannelDao.findById(cBRFParam.getChannelId())).getMerchantNo();
//		if (merId == null || merId.length() < 1) {
//			throw new BizException(logPrefix + "根据支付渠道获取的商户代码非法；");
//		}
//		final List<ChannelRefund> channelRefundList = cBRFParam.getChannelRefundList();
//		// 生成文件内容
//		Double iTotalAmount = 0.00;
//		int iTotalCount = 0;
//		final StringBuffer stringBuffer = new StringBuffer("");
//		// 银行订单流水号 | 商户号 | 订单号 | 订单日期 | 支付日期 | 币种 | 订单金额 | 退货金额 |
//		// 12345678901000|104110059471225|cc1100|20080901|20080910|001|11000.00|1000.00|
//		// 12345678902000|104110059471225|cc1200|20080904|20080920|001|22000.00|2000.00|
//		for (int j = 0; j < channelRefundList.size(); j++) {
//			String banSendSN;// 原业务发往银行的记录
//			final String bILLNoSeq = channelRefundList.get(j).getBillnoSeq();
//			final BillnoSn billnoSn = (BillnoSn) billnoSnDao.findById(bILLNoSeq);
//			if (billnoSn == null) {
//				logMsg = logPrefix + "在渠道流水对照表中没有记录bILLNoSeq:" + bILLNoSeq;
//				Log4jUtil.info(logMsg);
//				continue;
//			}
//			banSendSN = billnoSn.getBankSendSn();
//			stringBuffer.append(billnoSn.getBankRecvSn().trim()).append("|");
//			stringBuffer.append(merId).append("|");
//			stringBuffer.append(banSendSN).append("|");
//			stringBuffer.append(billnoSn.getTranDate()).append("|");
//			stringBuffer.append(billnoSn.getBankDate()).append("|");
//			stringBuffer.append("001").append("|");
//			stringBuffer.append(String.format("%1$.2f", billnoSn.getAmount())).append("|");
//			stringBuffer.append(String.format("%1$.2f", channelRefundList.get(j).getRefundAmount())).append("|");
//			if (j != (channelRefundList.size() - 1)) {
//				stringBuffer.append(line);
//			}
//			iTotalCount++;
//			logMsg = logPrefix + "添加退款明细：BankSendSn:" + banSendSN;
//			logMsg = logMsg + " Amount:" + String.format("%1$.2f", channelRefundList.get(j).getRefundAmount());
//			Log4jUtil.info(logMsg);
//			iTotalAmount = AmountUtils.add(iTotalAmount, channelRefundList.get(j).getRefundAmount());
//		}
//		logMsg = logPrefix + "生成批量退款文件。总笔数为：" + iTotalCount + " 总金额：" + String.format("%1$.2f", iTotalAmount);
//		Log4jUtil.info(logMsg);
//		return stringBuffer;
//	}
//
// }
