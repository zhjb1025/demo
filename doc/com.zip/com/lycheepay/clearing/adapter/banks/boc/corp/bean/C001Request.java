/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-4-11 下午4:34:59
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.boc.corp.bean;

import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;


/**
 * <P>账户验证请求</P>
 * 
 * @author 张凯锋
 */
public class C001Request extends RequestHead {

	private String accountNo = "";	// 账号
	private String accountName = "";	// 户名
	private String idType = "";	// 证件类型
	private String idNo = "";	// 证件号

	public C001Request(final BankCardVerifyDTO accountVerify) {
		accountNo = accountVerify.getBankCardNo();
		accountName = accountVerify.getCardHolderName();
		idType = "";
		idNo = accountVerify.getCertificateNo();
	}

	public String getXML() {
		final StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
		sb.append("<C001_REQUEST xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.szboc.cn/projects/open/2012/UniformProxySystem\">");
		sb.append(getHeadXML());
		sb.append("<BODY>");
		sb.append("<ACCOUNT_NO>").append(accountNo).append("</ACCOUNT_NO>");
		sb.append("<ACCOUNT_NAME>").append(accountName).append("</ACCOUNT_NAME>");
		sb.append("<ID_TYPE" + nil(idType) + ">").append(idType).append("</ID_TYPE>");
		sb.append("<ID_NO" + nil(idNo) + ">").append(idNo).append("</ID_NO>");
		sb.append("</BODY>");
		sb.append("</C001_REQUEST>");
		return sb.toString();
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(final String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(final String accountName) {
		this.accountName = accountName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(final String idType) {
		this.idType = idType;
	}

	public String getIdNo() {
		return idNo;
	}

	public void setIdNo(final String idNo) {
		this.idNo = idNo;
	}

}
