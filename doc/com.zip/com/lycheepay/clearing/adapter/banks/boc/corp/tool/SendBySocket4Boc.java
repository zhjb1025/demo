package com.lycheepay.clearing.adapter.banks.boc.corp.tool;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Arrays;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.adapter.common.util.biz.RunTime;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>中国银行银企socket发送连接工具类</P>
 * 
 * @author 邱林 Leon.Qiu 2012-6-19 下午5:57:43
 */
@Service(ClearingAdapterAnnotationName.SEND_BY_SOCKET_FOR_BOC)
public class SendBySocket4Boc {
	/**
	 * 发送数据到服务器, 再从服务器获取返回的数据
	 * 
	 * @param socketIp
	 * @param socketPort
	 * @param sendMsg要发送的报文
	 * @return socket 服务器返回的内容
	 * @throws BizException
	 */
	public byte[] sendAndRecv(final String socketIp, final String socketPort, final int timeout, final byte[] sendMsg)
			throws BizException {
		Log4jUtil.info("socketIp:" + socketIp + " :  socketPort:" + socketPort + " sendMsg长度:" + sendMsg.length);
		byte[] result = null;
		Socket socket = null;
		BufferedOutputStream dos = null;// 发送值
		final BufferedInputStream bf = null;
		final RunTime time = new RunTime();
		socket = connect(socketIp, socketPort, timeout);
		try {
			time.endAndStart("Socket链接耗时:");
			dos = new BufferedOutputStream(socket.getOutputStream());
			dos.write(sendMsg);
			dos.flush();
			time.endAndStart("Socket发送耗时:");
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			this.disconnect(dos, bf, socket);
			// 发送不成功，抛错误代码为9108
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
		}
		try {
			/*bf = new BufferedInputStream(socket.getInputStream());
			Log4jUtil.info("bf.available()：" + socket.getInputStream().available());
			System.out.println("bf.available()：" + bf.available());
			result = new byte[bf.available()];
			bf.read(result);*/
			/*ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int copycount = IOUtils.copy(socket.getInputStream(), baos);
			
			
			System.out.println("复制socket结果到输出流"+copycount);*/
			result = IOUtils.toByteArray(socket.getInputStream());
			// baos.close();
			time.endAndStart("Socket接收耗时:");
			Log4jUtil.info("SocketProcess中得到的返回报文内容长度：" + result.length);
		} catch (final Exception e) {
			Log4jUtil.error(e.getMessage(), e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
		} finally {
			this.disconnect(dos, bf, socket);
		}
		return result;
	}

	/**
	 * 连接服务器 socket
	 * 
	 * @param socketPort
	 * @param socketIp
	 * @throws BizException
	 */
	private Socket connect(final String socketIp, final String socketPort, final int timeout) throws BizException {
		Socket socket = new Socket();
		AssertUtils.notNull(socketIp, TransReturnCode.code_9108, "SocketIP不能为空!");
		AssertUtils.notNull(socketPort, TransReturnCode.code_9108, "SocketPort不能为空!");
		int currentTryTime = 0;
		final int maxTryTime = 3;// 重连接次数
		while (!socket.isConnected()) {
			try {
				currentTryTime++;
				Log4jUtil.info("进行第" + currentTryTime + "次链接。");
				socket = connect1(socketIp, socketPort, timeout);
			} catch (final Exception e) {
				// 若超过最大链接次数依然未成功，则抛异常
				try {
					Thread.sleep(1000);
				} catch (final InterruptedException e1) {
					e1.printStackTrace();
				}
				if (currentTryTime >= maxTryTime) {
					throw new BizException(e, TransReturnCode.code_9103, "通讯异常,连接 socket server 失败！！" + e.getMessage());
				}
			}
		}
		return socket;
	}

	private Socket connect1(final String socketIp, final String socketPort, final int timeout) throws Exception {
		final Socket socket = new Socket();
		final SocketAddress socketAddress = new InetSocketAddress(socketIp, Integer.parseInt(socketPort));
		final int connectOutTime = 60000;// 单位毫秒，6000。 用于刚开始建立链接时
		socket.connect(socketAddress, connectOutTime);
		socket.setSoTimeout(timeout);
		Log4jUtil.info("socketIp:{},socketPort:{} connected!", socketIp, socketPort);
		return socket;
	}

	/**
	 * 断开服务器 socket
	 * 
	 * @param bf
	 * @param dos
	 * 
	 * @throws BizException
	 */
	private void disconnect(final BufferedOutputStream dos, final BufferedInputStream bf, final Socket socket)
			throws BizException {
		try {
			if (dos != null) {
				dos.close();
			}
		} catch (final IOException e1) {
			e1.printStackTrace();
		}
		try {
			if (bf != null) {
				bf.close();
			}
		} catch (final IOException e1) {
			e1.printStackTrace();
		}
		try {
			if (socket != null) {
				socket.close();
			}
		} catch (final Exception e) {
			Log4jUtil.error(e);
		}
	}

	// public static void main(final String[] args) throws BizException {
	// final String s = "<?xml version=\"1.0\" encoding=\"GB2312\"?>" + "<TX>"
	// + "<REQUEST_SN>2012031500197266</REQUEST_SN>" + "<CUST_ID>P2100011312#</CUST_ID>"
	// + "<USER_ID>WLPT02</USER_ID>" + "<PASSWORD>999999</PASSWORD>" + "<TX_CODE>6W1303</TX_CODE>"
	// + "<LANGUAGE>CN</LANGUAGE>" + "<TX_INFO>" + "<ACC_NO1>44201501100059231878</ACC_NO1>"
	// + "<BILL_CODE>201106140002</BILL_CODE>" + "<ACC_NO2>4367427200412671265</ACC_NO2>"
	// + "<OTHER_NAME>赖四四</OTHER_NAME>" + "<AMOUNT>0.11</AMOUNT>" +
	// "<USEOF_CODE>99999999</USEOF_CODE>"
	// + "<FLOW_FLAG>0</FLOW_FLAG>" + "<REM1>01</REM1>" + "<REM2>20120315</REM2>" + "</TX_INFO>"
	// + "<SIGN_INFO></SIGN_INFO>" + "<SIGNCERT></SIGNCERT>" + "</TX>";
	// final SendBySocket socket = new SendBySocket();
	// System.out.println("fs：" + s);
	// System.out.println(socket.sendAndRecv("127.0.0.1", "15000", 60000, s.getBytes()).length);
	// // System.out.println(Charset.defaultCharset().displayName());
	// }

	/**
	 * <p>处理报文的发送接收，包括加密解密 默认超时时间为300秒</p>
	 * 
	 * @param key密钥
	 * @param sendXML发送报文
	 * @param ip socket地址
	 * @param port socket端口
	 * @param localSysCode 系统参数表中代码
	 * @return
	 * @author 张凯锋
	 * @throws BizException
	 */
	public byte[] sendAndRecv(final byte[] key, final String sendXML, final String ip, final String port,
			final String localSysCode) throws BizException {
		return this.sendAndRecv(key, sendXML, ip, port, 300000, localSysCode);
	}

	/**
	 * <p>处理报文的发送接收，包括加密解密</p>
	 * 
	 * @param key 密钥
	 * @param sendXML 发送报文
	 * @param timeout 业务交易超时时间
	 * @param ip socket地址
	 * @param port socket端口
	 * @param localSysCode 系统参数表中代码
	 * @return
	 * @author 张凯锋
	 * @throws BizException
	 */
	public byte[] sendAndRecv(final byte[] key, final String sendXML, final String ip, final String port,
			final int timeout, final String localSysCode) throws BizException {
		Log4jUtil.info("===加密发送数据");
		// 加密请求报文
		byte[] bytes = null;
		try {
			bytes = BocCodeUtils.encode(key, sendXML.getBytes(), localSysCode.getBytes());
		} catch (final Exception e) {
			Log4jUtil.error("===加密发送数据出错", e);
			throw new BizException(e, TransReturnCode.code_9108,
					TransReturnCode.getNameByValue(TransReturnCode.code_9108) + e.getMessage());
		}
		Log4jUtil.info("===加密发送数据完成，发送数据为：" + Arrays.toString(bytes));
		// 发送请求报文
		final byte[] resultBytes = this.sendAndRecv(ip, port, timeout, bytes);
		Log4jUtil.info("===接收到返回数据，长度:" + resultBytes.length);
		if (resultBytes.length == 0) {
			throw new BizException(TransReturnCode.code_9109, TransReturnCode.getNameByValue(TransReturnCode.code_9109)
					+ ",接收到返回数据，长度为0");

		}
		// 解密响应报文
		byte[] decodeBytes = null;
		try {
			Log4jUtil.info("====解压返回数据，解压前数据为：" + Arrays.toString(resultBytes));
			decodeBytes = BocCodeUtils.decode(key, resultBytes, localSysCode);
		} catch (final Exception e) {
			Log4jUtil.error("====解压返回数据出错", e);
			throw new BizException(e, TransReturnCode.code_9109,
					TransReturnCode.getNameByValue(TransReturnCode.code_9109) + e.getMessage());
		}
		final String result = new String(decodeBytes);
		Log4jUtil.info("解压后的返回报文：" + result);

		return result.replaceFirst("xmlns=\"http://www.szboc.cn/projects/open/2012/UniformProxySystem\"", "")
				.getBytes();
	}
}
