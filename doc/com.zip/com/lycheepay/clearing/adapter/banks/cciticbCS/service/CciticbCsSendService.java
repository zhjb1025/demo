package com.lycheepay.clearing.adapter.banks.cciticbCS.service;

//https一般来说有单项SSL和双向SSL连接之分。

//单项SSL连接，也就是只是客户端验证服务器证书。tomcat中clientAuth="false"的时候，HTTPS单向验证如下：

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import java.io.ByteArrayOutputStream;
import javax.annotation.PostConstruct;
import com.lycheepay.clearing.adapter.banks.cciticbCS.constant.Constants;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


//新HTTPS方法所需Jar包
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.contrib.ssl.AuthSSLProtocolSocketFactory;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.http.params.CoreConnectionPNames;

@Service
public class CciticbCsSendService {
	
		// 客户端信任的证书
//		private String sslTrustStore = null;
//		private String sslTrustStorePassword = null;
//		private String url = null;
//		private String sslKeyStore = null;
//		private String sslKeyStorePassword = null;
		
		public final static String channelId = ChannelIdEnum.CNCB_CS_CORP.getCode();
		
//		@Autowired
//		@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
//		private ChannelParmService channelParmService;

		// 初始化数据
//		@PostConstruct
//		public void init() throws Exception {
//			Log4jUtil.info("初始化CciticbCsHttps证书开始");
//			Map<String, String> channelParams = channelParmService.queryCodeParamsMapByChannelId(channelId);
//			this.sslTrustStore = channelParams.get(Constants.SSL_TRUST_STORE);
//			this.sslTrustStorePassword = channelParams.get(Constants.SSL_TRUST_STORE_PWD);
//			this.sslKeyStore = channelParams.get(Constants.SSL_KEY_STORE);
//			this.sslKeyStorePassword = channelParams.get(Constants.SSL_KEY_STORE_PWD);
//			this.url = channelParams.get(Constants.URL);
//			Log4jUtil.info("初始化CciticbCsHttps证书完成");
//		}

//		public String sendData(String data) throws BizException{
//			byte[] receivedDatab = null;
//			String receivedDatas = null;
//			// 设置系统证书库参数
//			System.setProperty("javax.net.ssl.keyStore", sslKeyStore);
//			System.setProperty("javax.net.ssl.keyStorePassword", sslKeyStorePassword);
//			// 设置系统信任证书库
//			System.setProperty("javax.net.ssl.trustStore", sslTrustStore);
//			System.setProperty("javax.net.ssl.trustStorePassword", sslTrustStorePassword);
//			//JDK1.7版本需要设置,否者ssl认证失败
//			System.setProperty("com.sun.net.ssl.enableECC", "false");
//			
//			Log4jUtil.info("javax.net.ssl.keyStore：【{}】", System.getProperty("javax.net.ssl.keyStore"));
//			Log4jUtil.info("javax.net.ssl.keyStorePassword：【{}】", System.getProperty("javax.net.ssl.keyStorePassword"));
//			Log4jUtil.info("javax.net.ssl.trustStore：【{}】", System.getProperty("javax.net.ssl.trustStore"));
//			Log4jUtil.info("javax.net.ssl.trustStorePassword：【{}】", System.getProperty("javax.net.ssl.trustStorePassword"));
//			
//			/*
//			// 报文加密
//			byte[] datacrypt = OLPdecrypt.sign_crypt(data.getBytes(), "654321", "J:\\workspaces\\client\\key\\CNCBclientPrivatekey.key", "J:\\workspaces\\client\\key\\CNCBclientCertificate.cer",
//					"J:\\workspaces\\client\\key\\CNCBtestCertificate.cer", true, false, true);
//
//			// 报文解密   其中CNCBtestCertificate.cer是中信银行端生成的证书
//			byte[] str = OLPdecrypt.decrypt_verify(send(Url, datacrypt), "654321", "J:\\workspaces\\client\\key\\CNCBclientPrivatekey.key", "J:\\workspaces\\client\\key\\CNCBtestCertificate.cer",
//					"GBK", true, false, true);*/
//			
//			Log4jUtil.info("发往中信长沙https请求报文内容：{}", data);
//			
//			byte[] sendData = null;
//			try {
//				sendData = data.getBytes(Constants.ENCODED_GBK);
//			} catch (UnsupportedEncodingException e) {
//				Log4jUtil.error(e);
//				throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
//			}
//			receivedDatab = send(url, sendData);
//			
//			try {
//				receivedDatas = new String(receivedDatab, Constants.ENCODED_GBK);
//			} catch (UnsupportedEncodingException e) {
//				Log4jUtil.error(e);
//				throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
//			}
//			
//			Log4jUtil.info("接收中信长沙https回执报文内容：{}", receivedDatas);
//			
//			return receivedDatas;
//		}
//
//		private static byte[] send(String sendurl, byte[] sendData) throws BizException {
//			
//			HostnameVerifier hv = new HostnameVerifier()
//			{
//				public boolean verify(String urlHostName, SSLSession session)
//				{
//					return true;
//				}
//			};
//			HttpsURLConnection connection = null;
////			Date current = new Date(System.currentTimeMillis());
////			System.out.println("begint to open connection at " + current);
//			try{
//				System.setProperty("java.protocol.handler.pkgs", "sun.net.www.protocol");
//				HttpsURLConnection.setDefaultHostnameVerifier(hv);
//				URL url = new URL(sendurl);
//				connection = (HttpsURLConnection) url.openConnection();
////				Date end = new Date(System.currentTimeMillis());
////				System.out.println("open connection ok at " + end + ",cost:" + (end.getTime() - current.getTime()));
//				connection.setRequestProperty("Content-Type", "text/xml");
//				connection.setDoOutput(true);
//				connection.setDoInput(true);
//				connection.setRequestMethod("POST");
//				connection.setUseCaches(false);
//				connection.setReadTimeout(30000);
//			}catch(Exception e){
//				Log4jUtil.error(e);
//				throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
//			}
//			
//			byte[] recvMsg = new byte[1024];
//			byte[] valiMsg = null;
//			ByteArrayOutputStream baos = null;
//			try{
////				current = new Date(System.currentTimeMillis());
////				System.out.println("[SSLIX]notifyEai,begint to write data at " + current);
//				OutputStream out = connection.getOutputStream();
//				out.write(sendData);
////				end = new Date(System.currentTimeMillis());
////				System.out.println("write data ok at " + end + ",cost:" + (end.getTime() - current.getTime()));
////				StringBuffer receivedData = new StringBuffer();
////				current = new Date(System.currentTimeMillis());
////				System.out.println("begint to read data at " + current);
//				
//				int readed = 0;
//				baos = new ByteArrayOutputStream();
//				while ((readed = connection.getInputStream().read(recvMsg)) != -1)
//				{
//					baos.write(recvMsg, 0, readed);
//				}
//				baos.flush();
//				valiMsg = baos.toByteArray();
////				System.out.println(valiMsg.length);
////				end = new Date(System.currentTimeMillis());
////				System.out.println("read data ok at " + end + ",cost:" + (end.getTime() - current.getTime()));
//
//				Integer statusCode = connection.getResponseCode();
//				Log4jUtil.info("收到https响应回执, statusCode【{}】", statusCode);
//				if (statusCode != HttpStatus.SC_OK) {
//					Log4jUtil.error("PostMethod failed, statusCode【{}】", statusCode);
//					throw new BizException(TransReturnCode.code_9109, "unable to get response,statusCode incorrect");
//				}
//				
//			}catch(Exception e){
//				Log4jUtil.error(e);
//				throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
//			}finally{
//				if(connection != null){
//					connection.disconnect();
//				}
//				IOUtils.closeQuietly(baos);
//			}
//
////			System.out.println(a.printTransMsg(valiMsg));
//
//			return valiMsg;
//		}
		
		
		public String sendData(String sendData, String sslTrustStorePath, String sslTrustStorePwd, String url) throws BizException
		{
			//JDK1.7版本需要设置,否者ssl认证失败
			System.setProperty("com.sun.net.ssl.enableECC", "false");
//			System.setProperty("java.protocol.handler.pkgs", "sun.net.www.protocol");
			
			Log4jUtil.info("发往中信长沙https请求报文内容：{}", sendData);
			
		    String receivedDatas = httpsPost(sendData, sslTrustStorePath, sslTrustStorePwd, url);
		    
		    Log4jUtil.info("接收中信长沙https回执报文内容：{}", receivedDatas);
		    
		    return receivedDatas;
		}
		
		@SuppressWarnings("deprecation")
		private String httpsPost(String postData, String sslTrustStorePath, String sslTrustStorePwd, String url)throws BizException {

			//Https请求对象初始化
			HttpClient client = null;
			Protocol authhttps = null;
			PostMethod postMethod = null;
			try{
				client = new HttpClient();
				client.getParams().setAuthenticationPreemptive(true);
				authhttps = new Protocol("https",
						new AuthSSLProtocolSocketFactory(new URL("file:"
								+ sslTrustStorePath),
								sslTrustStorePwd, new URL("file:"
										+ sslTrustStorePath),
										sslTrustStorePwd),
										new URL(url).getPort());
				Protocol.registerProtocol("https", authhttps);
				client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 18 * 1000); //设置连接超时时间18s
				client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 60 * 1000);//设置数据读取超时时间60s
//				client.getParams().setConnectionManagerTimeout(30 * 1000);	//设置连接池超时时间, 0.5分钟
//				client.getParams().setSoTimeout(60 * 1000);	//设置数据读取超时时间, 1分钟
				postMethod = new PostMethod(url);
				postMethod.setRequestHeader("Content-type", "text/xml; charset=GBK");
				postMethod.setRequestBody(postData);
			}catch(Exception e){
				Log4jUtil.error(e);
				throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
			}
			
			
			//接收Https请求回执
			try{
				Integer statusCode = client.executeMethod(postMethod);
				Log4jUtil.info("收到https响应回执, statusCode【{}】", statusCode);
				if (statusCode != HttpStatus.SC_OK) {
					Log4jUtil.error("PostMethod failed, statusCode【{}】", statusCode);
					throw new BizException(TransReturnCode.code_9109, "unable to get response,statusCode incorrect");
				}
				
				return new String(postMethod.getResponseBody(), Constants.ENCODED_GBK);
				
			}catch(Exception e){
				Log4jUtil.error(e);
				throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
			}finally{
				if(postMethod != null){
					postMethod.releaseConnection();
				}
			}
	  }
		
		
}
