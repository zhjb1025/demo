package com.lycheepay.clearing.adapter.banks.cciticbCS.model;

import org.soofa.core.model.BaseObject;

/**
 * 实时交易结果查询(0298)回执
 * @author huangxu
 *
 */
public class RT0298 extends BaseObject{
	
	private static final long serialVersionUID = -1919913217449020067L;
	
	private String stdProCode;	// 交易代码
	private String retCode;	// 返回码
	private String retMsg;	// 处理结果描述
	private String retCount;	// 记录条数
	private String retTxDate;	// 银行交易日期
	private String retTxTime;	// 银行交易时间
	private String bankReqId;	// 银行流水
	private String orderZt;	// 订单状态01 正常;25 失败;20 未明确;30 已撤销;40 此为冲正撤销交易，撤销成功  45 此为冲正撤销交易，撤销失败
	private String custNm;	// 客户名称
	private String requestId;	// 请求流水
	private String amount;	// 交易金额
	
	public String getStdProCode() {
		return stdProCode;
	}
	public void setStdProCode(String stdProCode) {
		this.stdProCode = stdProCode;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	public String getRetCount() {
		return retCount;
	}
	public void setRetCount(String retCount) {
		this.retCount = retCount;
	}
	public String getRetTxDate() {
		return retTxDate;
	}
	public void setRetTxDate(String retTxDate) {
		this.retTxDate = retTxDate;
	}
	public String getRetTxTime() {
		return retTxTime;
	}
	public void setRetTxTime(String retTxTime) {
		this.retTxTime = retTxTime;
	}
	public String getBankReqId() {
		return bankReqId;
	}
	public void setBankReqId(String bankReqId) {
		this.bankReqId = bankReqId;
	}
	public String getOrderZt() {
		return orderZt;
	}
	public void setOrderZt(String orderZt) {
		this.orderZt = orderZt;
	}
	public String getCustNm() {
		return custNm;
	}
	public void setCustNm(String custNm) {
		this.custNm = custNm;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
}
