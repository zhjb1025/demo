package com.lycheepay.clearing.adapter.banks.cciticbCS.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.lycheepay.clearing.adapter.banks.cciticbCS.constant.Constants;
import com.lycheepay.clearing.adapter.banks.jytpay.utils.FTPUtil;
import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterAppUncheckedException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
//import com.lycheepay.clearing.adapter.common.util.biz.Assert;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.adapter.common.constant.ExceptionCode;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.CCITICB_CS_RECON_FILE_SERVICE)
public class CciticbCsReconService  implements ReconciliationFileServiceInner{
	
	private static final String STR_GET = "get";
	private static final String STR_PAY = "pay";
	public final static String channelId = ChannelIdEnum.CNCB_CS_CORP.getCode();
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Override
	public String getReconciliationFile(String fileSavePath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CNCBCS", "recon");
		String fileFullPath = null;
		
		final String logPrefix = " " + channelId + ChannelId.getNameByValue(channelId) + " ";
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId, settleDate);
		List<ReconciliationFileDTO> reconciliationFileDTOList = null;
		try {
			
			Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
			final String ftpIP = channelParms.get(Constants.FTP_IP);
			final String ftpUser = channelParms.get(Constants.FTP_UESR);
			final String ftpPwd = channelParms.get(Constants.FTP_PWD);
			final int ftpPort = Integer.parseInt(channelParms.get(Constants.FTP_PORT));
			final String custCode = channelParms.get(Constants.CUST_COED);	//单位编码
			final String downLoadPath = channelParms.get(Constants.DOWNLOAD_PATH);
			final String localTmpPath = channelParms.get(Constants.LOCAL_TMP_PATH);
			
			final String reconFileName = custCode + "_DK_" + queryDate + ".TXT";	//代收对账文件名
			final String downLoadFile = downLoadPath + reconFileName;	//中信长沙FTP对账文件下载目录(含文件名)
			final String localTmpFile = localTmpPath + reconFileName;	//本地对账文件临时存放路径(含文件名)
			
			//FTP下载对账文件
			//以被动模式连接中信长沙FTP服务器下载对账文件，并保存在本地临时目录. 注意：由于当前渠道只有开通了代扣业务, 所以只获取代收对账文件
			FTPUtil ftp = new FTPUtil(ftpIP, ftpUser, ftpPwd, ftpPort);
			try {
				ftp.connectByPasswd();
				ftp.download(downLoadFile, localTmpFile);
			} catch (IOException e) {
				Log4jUtil.error(e);
				throw new ClearingAdapterBizCheckedException(BusinessCode.GET_RECONCILIATION_FILE_FAILED, "登陆FTP下载中信长沙对账文件出错");
			}finally{
				try {
					ftp.disconnect();
				} catch (IOException e) {
					Log4jUtil.error("关闭FTP连接异常, 错误信息:{}", e);
				}
			}
			//解析对账文件
			reconciliationFileDTOList = buildTransactionDataList(localTmpFile, channelId);
			Log4jUtil.info(logPrefix + "生成统一格式对账文件，对账文件总笔数reconciliationFileDTOList.size为：", reconciliationFileDTOList.size());
			
		} catch (Exception e) {
			Log4jUtil.error(e);
//			throw new BizException("系统异常,获取文件错误");
		}
		
		//转换成KFT自定义标准对账文件格式
		fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate, reconciliationFileDTOList);
		
		return fileFullPath;
	}
	
	private List<ReconciliationFileDTO> buildTransactionDataList(final String reconFile, final String channelId) throws ClearingAdapterBizCheckedException {
		if (!new File(reconFile).exists()) {
			Log4jUtil.info("中信长沙对账文件解析出错，错误信息： 找不到对账文件");
			throw new ClearingAdapterBizCheckedException(BusinessCode.FILE_NOT_FOUND, "中信长沙对账文件解析出错，错误信息： 找不到对账文件");
		}
		if (new File(reconFile).length() <= 0) {
			Log4jUtil.info("中信长沙对账文件解析出错，错误信息： 对账文件内容为空");
			throw new ClearingAdapterBizCheckedException(BusinessCode.INVALID_FILE, "中信长沙对账文件解析出错，错误信息：对账文件内容为空");
		}
		
		//	解析对账文件
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		BufferedReader in = null;
		// 循环对文本逐行处理
		int currLine = 0;
		String data = null;
		String[] currentLineData = null;
		
		//汇总数据
		String getSTotalNum = "";	//代扣成功总笔数
		String getSTotalAmount = "";	//代扣成功总金额
		String paySTotalNum = "";	//代付成功总笔数
		String paySTotalAmount = "";	//代付成功总金额
		
		try {
			in = new BufferedReader(new InputStreamReader(new FileInputStream(reconFile), Constants.ENCODED_GBK));
			data = in.readLine();	// 对账文件第一行，明细汇总信息
			
			//解析文件头的汇总信息
			currentLineData = data.split(Constants.RECON_FILE_SPLITE_FLAG);
			getSTotalNum = currentLineData[0];
			getSTotalAmount = currentLineData[1];
			paySTotalNum = currentLineData[2];
			paySTotalAmount = currentLineData[3];
			
			//解析文件明细
			while ((data = in.readLine()) != null) {
				if (0 < data.trim().length()) {
					currentLineData = data.split(Constants.RECON_FILE_SPLITE_FLAG);
					String bankSendSn = currentLineData[0];	//第三方交易流水
					String bankRecvSn = currentLineData[1];	//银行方交易流水
//					String otherAcctNo = currentLineData[2];	//对方银行账号(必填)
//					String otherAcctName = currentLineData[3];	//对方银行账号名称(必填)
					String amount = currentLineData[4];	//交易金额
					String tranType = currentLineData[5];	//借贷标识, C：贷, D：借(针对第三方)
					String transTime = currentLineData[6];	//交易时间yyyyMMddHHmmss
					String checkDate = 	currentLineData[7];	//清算日期YYYYMMDD
//					String orderNo = currentLineData[8];	//订单号
//					String abstractS = currentLineData[9];	//摘要
//					String remark = currentLineData[10];	//备注
					
					final ReconciliationFileDTO accBean = new ReconciliationFileDTO();
					accBean.setCheckDate(checkDate);// 对账日期
					accBean.setBankSendId(bankSendSn);
					accBean.setTransDate(transTime.substring(0,8));	// 交易日期
					accBean.setAmount(new BigDecimal(amount));// 交易金额
					accBean.setBankTransState("00");	//对账文件中只会出现成功的交易,故此处不对交易状态做判断,统一当成功,其实也没交易状态可以核对.
					accBean.setBankRecvSN(bankRecvSn);
					accBean.setPayGet("C".equalsIgnoreCase(tranType) ? STR_GET : STR_PAY);	//交易类型是中文描述
					accBean.setChannelId(channelId);
					reconciliationFileDTOList.add(accBean);
					
					currLine++; // 行循环
				}
			}//while end
			
			Log4jUtil.info("从中信长沙对账文件中共解析【{}】条交易明细", currLine);
			
		} catch (FileNotFoundException e) {
			Log4jUtil.error("指定中信长沙对账文件不存在!请检查此文件:[" + reconFile + "]是否存在?", e);
			throw new ClearingAdapterBizCheckedException(BusinessCode.FILE_NOT_FOUND, "指定中信长沙对账文件不存在!请检查此文件:["
					+ reconFile + "]是否存在?" + e);
		} catch (IOException e) {
			Log4jUtil.error("IOException", e);
			throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, "中信长沙对账文件,文件:[" + reconFile
					+ "]" + e);
		}finally {
			try {
				if (null != in) {
					in.close();
				}// 关闭文件
			} catch (final IOException e) {
				Log4jUtil.error("关闭文件流异常, 错误信息:{}", e);
				throw new ClearingAdapterAppUncheckedException(ExceptionCode.IO_EXCEPTION, "中信长沙对账文件,关闭文件流出错文件:["
						+ reconFile + "]" + e);
			}
		}
		
		Log4jUtil.info("中信长沙对账文件解析完成! 成功代收总笔数【{}】, 成功代收总金额【{}】, 成功代付总笔数【{}】, 成功代付总金额【{}】", 
				getSTotalNum, getSTotalAmount, paySTotalNum, paySTotalAmount);
		
		return reconciliationFileDTOList;
	}
	
	
	@Override
	public String convertToStandardReconciliationFile(String targetFilePath, String fileSavePath, String channelId,
			String settleDate) throws ClearingAdapterBizCheckedException {
		// 不支持
		return null;
	}
}
