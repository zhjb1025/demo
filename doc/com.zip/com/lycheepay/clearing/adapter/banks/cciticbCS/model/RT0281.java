package com.lycheepay.clearing.adapter.banks.cciticbCS.model;

import org.soofa.core.model.BaseObject;


/**
 * 签约交易(0281)回执
 * @author huangxu
 *
 */
public class RT0281 extends BaseObject{
	
	private static final long serialVersionUID = -842912579309738760L;
	private String stdProCode;	// 交易代码
	private String sdId;	//流水号(原请求号)
	private String retCode;	//返回码
	private String retMsg;	//返回描述
	
	public String getStdProCode() {
		return stdProCode;
	}
	public void setStdProCode(String stdProCode) {
		this.stdProCode = stdProCode;
	}
	public String getSdId() {
		return sdId;
	}
	public void setSdId(String sdId) {
		this.sdId = sdId;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}

}
