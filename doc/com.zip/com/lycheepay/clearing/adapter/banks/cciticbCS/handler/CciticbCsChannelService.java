package com.lycheepay.clearing.adapter.banks.cciticbCS.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.lycheepay.clearing.adapter.banks.cciticbCS.service.CciticbCsProcessService;
import com.lycheepay.clearing.adapter.banks.cciticbCS.service.CciticbCsProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 中信长沙本行交易渠道服务入口类
 * 
 * @author HuangXu
 *
 */
@Service(ClearingAdapterAnnotationName.CCITICB_CS_CHANNEL_SERVICE)
public class CciticbCsChannelService extends AbstractChannelService{
	
	@Autowired
	private CciticbCsProcessService cciticbCsProcessService;

	public final static String channelId = ChannelIdEnum.CNCB_CS_CORP.getCode();

	@Override
	public ClearingResultDTO directDeduct(DeductDTO deduct) {
		Log4jUtil.setLogClass("CNCBCS", "direct");
		Log4jUtil.info(deduct);
		ClearingResultDTO dto = null;
		try {
			dto = cciticbCsProcessService.directDeduct(deduct, channelId);
			dto.setChannelId(channelId);
			dto.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}
	
	@Override
	public ClearingResultDTO directPay(PayOutDTO pay) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CNCBCS", "direct");
		Log4jUtil.info(pay);
		ClearingResultDTO dto = null;
		try {
			dto = cciticbCsProcessService.directPay(pay, channelId);
			dto.setChannelId(channelId);
			dto.setClearingTransType(ClearingTransType.REAL_TIME_PAY);
		} catch (final Exception e) {
			return ChannelResultUtil.exceptionToResult(e, dto);
		}
		Log4jUtil.info(dto);
		return dto;
	}
	
	
	@Override
	public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) {
		Log4jUtil.setLogClass("CNCBCS", "query");
		Log4jUtil.info(billnoSn);
		ClearingResultDTO dto = null;
		try {
			dto = cciticbCsProcessService.querySingleRecord(billnoSn, channelId);
		} catch (BizException e) {
			Log4jUtil.error(e);
			return null;
		}
		Log4jUtil.info(dto);
		return dto;
	}
}
