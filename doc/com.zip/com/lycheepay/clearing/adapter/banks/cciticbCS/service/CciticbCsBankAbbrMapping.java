package com.lycheepay.clearing.adapter.banks.cciticbCS.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class CciticbCsBankAbbrMapping {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	private Map<String, String> bankAbbr = new HashMap<String, String>();
	
	@PostConstruct
	public synchronized void init() {
		bankAbbr.put("3051000", "CMBC");
		bankAbbr.put("3065810", "GDB");
		bankAbbr.put("1021000", "ICBC");
		bankAbbr.put("1031000", "ABC");
		bankAbbr.put("1041000", "BOC");
		bankAbbr.put("1051000", "CCB");
		bankAbbr.put("3011000", "BCOM");
		bankAbbr.put("0025840", "PSBC");
		bankAbbr.put("3085840", "CMB");
		bankAbbr.put("3031000", "CEBB");
		bankAbbr.put("3091000", "CIB");
		bankAbbr.put("3135840", "SPABANK");
		bankAbbr.put("3021000", "ECITIC");
		bankAbbr.put("3041000", "HXB");
		bankAbbr.put("3102900", "SPDB");
		bankAbbr.put("3135841", "SHB");
		bankAbbr.put("3131000", "BOB");
		bankAbbr.put("4025840", "SZRCB");
		//bankName.put("", "兰州银行");
		logger.info("中信长沙跨行交易银行代码映射初始化完成,共{}条", bankAbbr.size());
		for (Map.Entry<String, String> entry : bankAbbr.entrySet()) {
			logger.info("bankCode:{}, BankAbbr:{}", entry.getKey(), entry.getValue());
		}
	}

	public Map<String, String> getBankAbbr() {
		return bankAbbr;
	}
}
