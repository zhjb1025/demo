package com.lycheepay.clearing.adapter.banks.cciticbCS.model;

import org.soofa.core.model.BaseObject;

/**
 * 跨行代扣交易回执实体类
 * @author HuangXu
 *
 */
public class RTMultiBank extends BaseObject{

	private static final long serialVersionUID = 8743297739731092734L;
	
	private String merchantId;
	private String requestId;
	private String returnCode;	//返回码, 000000-处理成功，结果以支付状态为准。其他信息提示码，提示各类处理失败信息
	private String message;	//返回码信息提示
	private String payNo;	//订单流水号
	private String ordSts;	//订单支付状态, P：支付处理中，需要通过查询接口查询扣款结果, S：支付完成, F：支付失败
	private String agrNo;	//签约协议号
	private String bnkMsgData;	//银行返回错误描述
	
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getPayNo() {
		return payNo;
	}
	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}
	public String getOrdSts() {
		return ordSts;
	}
	public void setOrdSts(String ordSts) {
		this.ordSts = ordSts;
	}
	public String getAgrNo() {
		return agrNo;
	}
	public void setAgrNo(String agrNo) {
		this.agrNo = agrNo;
	}
	public String getBnkMsgData() {
		return bnkMsgData;
	}
	public void setBnkMsgData(String bnkMsgData) {
		this.bnkMsgData = bnkMsgData;
	}
	
}
