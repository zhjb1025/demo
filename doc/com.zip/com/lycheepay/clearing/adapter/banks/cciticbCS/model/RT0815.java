package com.lycheepay.clearing.adapter.banks.cciticbCS.model;

import org.soofa.core.model.BaseObject;

/**
 * 实时扣款交易(0815)回执
 * @author huangxu
 *
 */
public class RT0815 extends BaseObject{

	private static final long serialVersionUID = -3706036474779308699L;
	
	private String stdProCode;	//请求交易代码
	private String retCode;	//返回码
	private String retMsg;	//返回描述
	private String retTxDate;	//银行交易日期
	private String retTxTime;	//银行交易时间
	private String bankReqId;	//银行流水号
	private String orderZt;	//订单状态
	private String requestId;	//请求流水号
	
	public String getStdProCode() {
		return stdProCode;
	}
	public void setStdProCode(String stdProCode) {
		this.stdProCode = stdProCode;
	}
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	public String getRetTxDate() {
		return retTxDate;
	}
	public void setRetTxDate(String retTxDate) {
		this.retTxDate = retTxDate;
	}
	public String getRetTxTime() {
		return retTxTime;
	}
	public void setRetTxTime(String retTxTime) {
		this.retTxTime = retTxTime;
	}
	public String getBankReqId() {
		return bankReqId;
	}
	public void setBankReqId(String bankReqId) {
		this.bankReqId = bankReqId;
	}
	public String getOrderZt() {
		return orderZt;
	}
	public void setOrderZt(String orderZt) {
		this.orderZt = orderZt;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

}
