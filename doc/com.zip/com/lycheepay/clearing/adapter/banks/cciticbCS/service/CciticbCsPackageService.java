package com.lycheepay.clearing.adapter.banks.cciticbCS.service;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.lycheepay.clearing.adapter.banks.cciticbCS.constant.Constants;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT0281;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT0298;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT0815;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT9138;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RTMultiBank;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RTMultiBankTradeQur;
import com.lycheepay.clearing.adapter.banks.yspay.utils.CommonUntils;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.model.biz.BankaccountBalance;
import com.lycheepay.clearing.adapter.common.service.biz.BankAccountBalanceService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelCertTypeService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.adapter.common.util.biz.StringUtil;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;

/**
 * 打包/解包服务类
 * @author HuangXu
 *
 */
@Service
public class CciticbCsPackageService {
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_CERT_TYPE_SERVICE)
	private ChannelCertTypeService channelCertTypeService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_ACCOUNT_BALANCE_SERVICE)
	private BankAccountBalanceService babService;
	
	@Autowired
	CciticbCsBankAbbrMapping bankAbbrMapping;
	
	static final String channelId = ChannelIdEnum.CNCB_CS_CORP.getCode();
	
	/**
	 * 本行代扣请求
	 * @param bankSendSn 渠道交易流水
	 * @param txdate 请求日期,此处将请求日期提取出来,只要是便于后面调用单笔交易查询传入此参数
	 * @param deduct 代扣请求对象实体
	 * @return
	 */
	public String packageDirectDeductXml(String bankSendSn, String txdate, DeductDTO deduct){
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String custCode = channelParms.get(Constants.CUST_COED);
		final String custId = channelParms.get(Constants.CUST_ID);
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点ROOT	
		Element rootElement = document.addElement("ROOT");
		// 创建子节点
		rootElement.addElement("stdprocode").setText(Constants.STD_CD_DEDUCT); // 交易代码
		rootElement.addElement("custcode").setText(custCode);	//单位编码(银行提供)
//		rootElement.addElement("version").setText(Constants.VERSION);	//版本号
		rootElement.addElement("posid").setText("");	//终端号
		rootElement.addElement("requestId").setText(bankSendSn);	//请求流水号
		rootElement.addElement("txdate").setText(txdate);	//请求日期
		rootElement.addElement("txtime").setText(DateUtil.getCurrentTime());	//请求时间
		rootElement.addElement("ordercode").setText(bankSendSn);	//订单号
		rootElement.addElement("pooltype").setText("");	//归集类型, 第三方或银行定义
		rootElement.addElement("merchantId").setText(deduct.getCorpAccountId());	//代理商编号
		rootElement.addElement("custid").setText(custId);	//第三方在银行开立的商户号 (由银行定义 )
		rootElement.addElement("custnm").setText(deduct.getCardHolderName());	//客户名
		rootElement.addElement("custacctnum").setText(deduct.getBankCardNo());	//客户账号
		
		//PS: 证件类型和证件号码可以为空
		String certType = channelCertTypeService.getCertType(channelId, deduct.getCertificateType());
		rootElement.addElement("certtype").setText(StringUtils.isNotBlank(certType) ? certType : "0");	//证件类型, 默认身份证
		
		rootElement.addElement("certnum").setText(deduct.getCertificateNo());	//证件号码
		rootElement.addElement("custpswd").setText("");	//账户密码
		rootElement.addElement("stdtrack2").setText("");	//第二磁道信息
		rootElement.addElement("stdtrack3").setText("");	//第三磁道信息
		rootElement.addElement("amount").setText(deduct.getAmount().toString());	//交易金额(元)
		//摘要
		String orderNote = StringUtils.isBlank(deduct.getOrderNote())?"":deduct.getOrderNote();
		rootElement.addElement("remark1").setText(orderNote);	//备用1
		rootElement.addElement("remark2").setText("");	//备用2
		rootElement.addElement("remark3").setText("");	//备用3
		
		return rootElement.asXML();
	}
	
	/**
	 * 单笔实时代付
	 * @param bankSendSn 渠道交易流水
	 * @param txdate 请求日期,此处将请求日期提取出来,主要是便于后面调用单笔交易查询传入此参数,格式:yyyymmdd
	 * @param pay 代付请求对象实体
	 * @return
	 */
	public String packageDirectPayXml(String bankSendSn, String txdate, PayOutDTO pay){
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String custCode = channelParms.get(Constants.CUST_COED);
		final String custId = channelParms.get(Constants.CUST_ID);
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点ROOT	
		Element rootElement = document.addElement("ROOT");
		// 创建子节点
		rootElement.addElement("stdprocode").setText(Constants.STD_CD_PAY); // 交易代码
		rootElement.addElement("custcode").setText(custCode);	//单位编码(银行提供)
//		rootElement.addElement("version").setText(Constants.VERSION);	//版本号
		rootElement.addElement("posid").setText("");	//终端号
		rootElement.addElement("txdate").setText(txdate);	//请求日期
		rootElement.addElement("txtime").setText(DateUtil.getCurrentTime());	//请求时间
		rootElement.addElement("ordercode").setText(bankSendSn);	//订单号Max(20)
		rootElement.addElement("requestId").setText(bankSendSn);	//请求流水Max(30)
		rootElement.addElement("pooltype").setText("");	//业务类型,第三方或银行定义
		rootElement.addElement("custid").setText(custId);	//商户号
		rootElement.addElement("merchantId").setText(pay.getCorpAccountId());	//代理商户号
		rootElement.addElement("fkacctno").setText("");	//付款账号,若为空,默认双方约定的账号
		rootElement.addElement("custnm").setText(pay.getCardHolderName());	//客户名称
		rootElement.addElement("custacctnum").setText(pay.getBankCardNo());	//客户账号
		rootElement.addElement("certtype").setText("");	//证件类型
		rootElement.addElement("certnum").setText("");	//证件号码,含有该字段就校验,无此字段则无需校验
		rootElement.addElement("amount").setText(pay.getAmount().toString());	//余额
		rootElement.addElement("remark1").setText("收款");	//备用1,会体现在网银摘要中
		rootElement.addElement("remark2").setText("");	//备用2
		rootElement.addElement("remark3").setText("");	//备用3
		
		return rootElement.asXML();
	}
	
	/**
	 * 实时交易结果查询
	 * @param bankSendSn 银行交易流水
	 * @param orgOrderDate 原交易订单日期yyyymmdd
	 * @param orgOrderCode 原交易订单号
	 * @param orgReqId 原交易请求流水号
	 * @return
	 */
	public String packageRTTradeResultQurXml(String bankSendSn, String orgOrderDate, String orgOrderCode, String orgReqId){
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String custCode = channelParms.get(Constants.CUST_COED);
		final String custId = channelParms.get(Constants.CUST_ID);
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点ROOT
		Element rootElement = document.addElement("ROOT");
		// 创建子节点
		rootElement.addElement("stdprocode").setText(Constants.STD_CD_RT_TRADE_REST_QUR); // 交易代码
		rootElement.addElement("custcode").setText(custCode);	//单位编码(银行提供)
//		rootElement.addElement("version").setText(Constants.VERSION);	//版本号
		rootElement.addElement("posid").setText(bankSendSn);	//终端号
		rootElement.addElement("requestId").setText(bankSendSn);	//请求流水号
		rootElement.addElement("txdate").setText(DateUtil.getCurrentDate());	//请求日期
		rootElement.addElement("txtime").setText(DateUtil.getCurrentTime());	//请求时间
		rootElement.addElement("merchantId").setText(Constants.DEF_MER_ID);	//代理商编号
		rootElement.addElement("custid").setText(custId);	//商户号
		rootElement.addElement("orderdate").setText(orgOrderDate);	//原交易订单日期
		rootElement.addElement("ordercode").setText(orgOrderCode);	//原交易订单号
		rootElement.addElement("orgrequestId").setText(orgReqId);	//需查询的原请求流水号
		rootElement.addElement("remark1").setText("");	//备用1
		rootElement.addElement("remark2").setText("");	//备用2
		rootElement.addElement("remark3").setText("");	//备用3
		
		return rootElement.asXML();
	}
	
	/**
	 * 签约请求报文
	 * @param bankSendSn
	 * @param deduct
	 * @return
	 */
	public String packageContractSignXml(String bankSendSn, DeductDTO deduct){
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String custCode = channelParms.get(Constants.CUST_COED);
		final String custId = channelParms.get(Constants.CUST_ID);
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点ROOT	
		Element rootElement = document.addElement("ROOT");
		// 创建子节点
		rootElement.addElement("stdprocode").setText(Constants.STD_CD_CONTRACT_SIGN); // 交易代码
		rootElement.addElement("custcode").setText(custCode);	//单位编码(银行提供)
		rootElement.addElement("merchantId").setText(deduct.getCorpAccountId());	//代理商编号
//		rootElement.addElement("version").setText(Constants.VERSION);	//版本号
		rootElement.addElement("posid").setText("");	//终端号
		rootElement.addElement("sdid").setText(bankSendSn);	//流水号
		rootElement.addElement("custid").setText(custId);	//第三方在银行开立的商户号 (由银行定义 )
		rootElement.addElement("custnm").setText(deduct.getCardHolderName());	//客户名称
		rootElement.addElement("custacctnum").setText(deduct.getBankCardNo());	//客户账号
		
		String certType = channelCertTypeService.getCertType(channelId, deduct.getCertificateType());
		rootElement.addElement("certtype").setText(StringUtils.isNotBlank(certType) ? certType : "0");	//证件类型, 默认身份证
		
		rootElement.addElement("certnum").setText(deduct.getCertificateNo());	//身份证号码
		rootElement.addElement("moblnum").setText(StringUtils.isBlank(deduct.getPhoneNumber())?"":deduct.getPhoneNumber());	//手机号码
		rootElement.addElement("custpswd").setText("");	//账户密码
		rootElement.addElement("stdtrack2").setText("");	//第二磁道信息,送该域则校验
		rootElement.addElement("stdtrack3").setText("");	//第三磁道信息,送该域则校验
		rootElement.addElement("opendt").setText(DateUtil.getCurrentDate());	//签约日期yyyymmdd
		rootElement.addElement("txdate").setText(DateUtil.getCurrentDate());	//请求日期yyyymmdd
		rootElement.addElement("txtime").setText(DateUtil.getCurrentTime());	//请求时间hhmmss
		rootElement.addElement("remark1").setText("");	//备用1
		rootElement.addElement("remark2").setText("");	//备用2
		rootElement.addElement("remark3").setText("");	//备用3
		
		return rootElement.asXML();
	}
	
	
	/**
	 * 实时余额查询(可以查个人账户余额)
	 * @return
	 */
	public String balanceQueryXml(String bankSendSn){
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String custCode = channelParms.get(Constants.CUST_COED);
		final String custId = channelParms.get(Constants.CUST_ID);
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点ROOT	
		Element rootElement = document.addElement("ROOT");
		// 创建子节点
		rootElement.addElement("stdprocode").setText(Constants.STD_CD_BALANCE_QUERY); // 交易代码
		rootElement.addElement("custcode").setText(custCode);	//单位编码(银行提供)
		rootElement.addElement("merchantId").setText(Constants.DEF_MER_ID);	//代理商编号
//		rootElement.addElement("version").setText(Constants.VERSION);	//版本号
		rootElement.addElement("posid").setText("");	//终端号
		rootElement.addElement("requestId").setText(bankSendSn);	//请求流水号
		rootElement.addElement("txdate").setText(DateUtil.getCurrentDate());	//请求日期
		rootElement.addElement("txtime").setText(DateUtil.getCurrentTime());	//请求时间
		rootElement.addElement("custid").setText(custId);	//商户号
		
		BankaccountBalance bankaccountBean = babService.getBankaccountBean(channelId);
		String accNo = bankaccountBean.getAccountNo();
		String accNm = bankaccountBean.getAccountName();
		rootElement.addElement("custnm").setText(accNo);	//客户账号
		rootElement.addElement("custacctnum").setText(accNm);	//客户名称
		rootElement.addElement("certtype").setText("");	//证件类型,第三方对公账户查询需要证件类型?待确认
		rootElement.addElement("certnum").setText("");	//身份证号码,第三方对公账户查询需要证件类型?待确认
		rootElement.addElement("custpswd").setText("");	//账户密码
		rootElement.addElement("stdtrack2").setText("");	//第二磁道信息
		rootElement.addElement("stdtrack3").setText("");	//第三磁道信息
		rootElement.addElement("remark1").setText("");	//备用1
		rootElement.addElement("remark2").setText("");	//备用2
		rootElement.addElement("remark3").setText("");	//备用3
		
		return rootElement.asXML();
	}
	
	
	
	/**
	 * 解析实时交易结果查询(0298)回执报文
	 * @param rtMsg 请求结果报文
	 * @return
	 * @throws BizException 
	 * @throws UnsupportedEncodingException 
	 */
	public RT0298 parse0298Result(String rtMsg) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(rtMsg.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109,"银行回执报文编码转换异常");
		}// 解析应答报文
		final Node nodeRoot = dom4jxml.getNode("/ROOT");
		String stdprocode = dom4jxml.getNodeText(nodeRoot, "stdprocode");// 交易代码
		String retcode = dom4jxml.getNodeText(nodeRoot, "retcode");// 返回码
		String retmsg = dom4jxml.getNodeText(nodeRoot, "retmsg");// 处理结果描述
		String retcount = dom4jxml.getNodeText(nodeRoot, "retcount");// 记录条数

		String rettxdate = "";
		String rettxtime = "";
		String bankreqid = "";
		String orderzt = "";
		String custnm = "";
		String requestid = "";
		String amount = "";
		
		List<Node> nodeList = dom4jxml.getNodeList("/ROOT/LIST/ROWS");
		if (nodeList != null && !nodeList.isEmpty()) {
			Node node = nodeList.get(0);// 因为是单笔处理，所以只有一笔
			rettxdate = dom4jxml.getNodeText(node, "rettxdate");// 银行交易日期
			rettxtime = dom4jxml.getNodeText(node, "rettxtime");// 银行交易时间
			bankreqid = dom4jxml.getNodeText(node, "bankreqid");// 银行流水
			orderzt = dom4jxml.getNodeText(node, "orderzt");// 订单状态01 正常;25 失败;20 未明确;30 已撤销;40 此为冲正撤销交易，撤销成功  45 此为冲正撤销交易，撤销失败
			custnm = dom4jxml.getNodeText(node, "custnm");// 客户名称
			requestid = dom4jxml.getNodeText(node, "requestid");// 请求流水
			amount = dom4jxml.getNodeText(node, "amount");// 交易金额
		}
		
		RT0298 result = new RT0298();
		result.setStdProCode(stdprocode);
		result.setRetCode(retcode);
		result.setRetMsg(retmsg);
		result.setRetCount(retcount);
		result.setRetTxDate(rettxdate);
		result.setRetTxTime(rettxtime);
		result.setBankReqId(bankreqid);
		result.setOrderZt(orderzt);
		result.setCustNm(custnm);
		result.setRequestId(requestid);
		result.setAmount(amount);
		
		return result;
	}
	
	
	/**
	 * 解析签约交易(0281)回执结果
	 * @return
	 */
	public RT0281 parse0281Result(String rtMsg) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(rtMsg.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109,"银行回执报文编码转换异常");
		}// 解析应答报文
		
		final Node nodeRoot = dom4jxml.getNode("/ROOT");
		String stdprocode = dom4jxml.getNodeText(nodeRoot, "stdprocode");
		String sdid = dom4jxml.getNodeText(nodeRoot, "sdid");
		String retcode = dom4jxml.getNodeText(nodeRoot, "retcode");
		String retmsg = dom4jxml.getNodeText(nodeRoot, "retmsg");
		
		RT0281 result = new RT0281();
		result.setStdProCode(stdprocode);
		result.setSdId(sdid);
		result.setRetCode(retcode);
		result.setRetMsg(retmsg);
		
		return result;
	}
	
	
	/**
	 * 解析实时扣款交易(0815)回执结果
	 * @return
	 */
	public RT0815 parse0815Result(String rtMsg) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(rtMsg.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109,"银行回执报文编码转换异常");
		}// 解析应答报文
		
		final Node nodeRoot = dom4jxml.getNode("/ROOT");
		String stdprocode = dom4jxml.getNodeText(nodeRoot, "stdprocode");
		String retcode = dom4jxml.getNodeText(nodeRoot, "retcode");
		String retmsg = dom4jxml.getNodeText(nodeRoot, "retmsg");
		String rettxdate = dom4jxml.getNodeText(nodeRoot, "rettxdate");
		String rettxtime = dom4jxml.getNodeText(nodeRoot, "rettxtime");
		String bankreqid = dom4jxml.getNodeText(nodeRoot, "bankreqid");
		String orderzt = dom4jxml.getNodeText(nodeRoot, "orderzt");
		String requestid = dom4jxml.getNodeText(nodeRoot, "requestid");
		
		RT0815 result = new RT0815();
		result.setStdProCode(stdprocode);
		result.setRetCode(retcode);
		result.setRetMsg(retmsg);
		result.setRetTxDate(rettxdate);
		result.setRetTxTime(rettxtime);
		result.setBankReqId(bankreqid);
		result.setOrderZt(orderzt);
		result.setRequestId(requestid);
		
		return result;
	}
	
	
	/**
	 * 解析单笔实时代付交易(9138)回执结果
	 * @param bankSendSn 渠道交易流水
	 * @param txdate 请求日期,此处将请求日期提取出来,只要是便于后面调用单笔交易查询传入此参数
	 * @param pay 代付请求对象实体
	 * @return
	 */
	public RT9138 parse9138Result(String rtMsg)throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(rtMsg.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109,"银行回执报文编码转换异常");
		}// 解析应答报文
		
		final Node nodeRoot = dom4jxml.getNode("/ROOT");
		String stdprocode = dom4jxml.getNodeText(nodeRoot, "stdprocode");
		String retcode = dom4jxml.getNodeText(nodeRoot, "retcode");
		String retmsg = dom4jxml.getNodeText(nodeRoot, "retmsg");
		String rettxdate = dom4jxml.getNodeText(nodeRoot, "rettxdate");
		String rettxtime = dom4jxml.getNodeText(nodeRoot, "rettxtime");
		String bankreqid = dom4jxml.getNodeText(nodeRoot, "bankreqid");
		String orderzt = dom4jxml.getNodeText(nodeRoot, "orderzt");
		String requestId = dom4jxml.getNodeText(nodeRoot, "requestId");
		String bankkkamt = dom4jxml.getNodeText(nodeRoot, "bankkkamt");
		
		RT9138 result = new RT9138();
		result.setStdProCode(stdprocode);
		result.setRetCode(retcode);
		result.setRetMsg(retmsg);
		result.setRetTxDate(rettxdate);
		result.setRetTxTime(rettxtime);
		result.setBankReqId(bankreqid);
		result.setOrderZt(orderzt);
		result.setRequestId(requestId);
		result.setBankkkAmt(bankkkamt);
		
		return result;
	}
	
	/**
	 * 跨行代扣请求
	 * @param bankSendSn
	 * @param deduct
	 * @return
	 */
	public String packageMultiBankDeductXml(String bankSendSn, DeductDTO deduct, Map<String, String> channelParms){
		
		final String merchantID = channelParms.get(Constants.CROSS_BANK_MERCHANT_ID);	//商户编号: 收付通平台给商户分配的唯一标识
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点root	
		Element rootElement = document.addElement("root");
		// 创建head节点
		Element head = rootElement.addElement("head");
		head.addElement("merchantId").setText(merchantID); // 商户编号
		head.addElement("requestId").setText(bankSendSn);	//商户请求号
		head.addElement("transactionCode").setText(Constants.STD_CD_MULTI_BANK_DEDUCT);	//交易代码
		// 创建body节点
		Element body = rootElement.addElement("body");
		body.addElement("amount").setText(CommonUntils.parseYuan2Fen(deduct.getAmount())); // 交易金额(分)
		body.addElement("orderDate").setText(DateUtil.getCurrentDate()); // 订单提交日期
		body.addElement("orderId").setText(bankSendSn); // 商户订单号
		body.addElement("period").setText("30"); // 有效期数量,和有效期单位组合使用
		body.addElement("periodUnit").setText("00"); // 有效期单位,和有效期数量组合使用,以上为30分钟. 00:分,01:小时,02:日,03:月
		//PS:跨行代扣报文中的可空字段,可以填空值'',但是字段必须有
		body.addElement("merchantAbbr").setText(""); // 商户展示名称(没有就填'1')
		body.addElement("productDesc").setText(""); // 商品描述(没有就填'01')
		body.addElement("productId").setText(""); // 商品编号(没有就填'01')
		body.addElement("productName").setText(""); // 商品名称(没有就填'01')
		body.addElement("productNum").setText(""); // 商品数量
		body.addElement("agrNo").setText(""); // 签约协议号
		body.addElement("cardName").setText(deduct.getCardHolderName()); // 银行卡用户名
		body.addElement("cardNo").setText(deduct.getBankCardNo()); // 银行卡号
		body.addElement("idNo").setText(deduct.getCertificateNo()); // 身份证号码
		body.addElement("mobileNo").setText(StringUtil.isBlank(deduct.getPhoneNumber())?"":deduct.getPhoneNumber()); // 手机号
		
		String bankAbbr = StringUtils.isBlank(bankAbbrMapping.getBankAbbr().get(deduct.getBankType()))?"":bankAbbrMapping.getBankAbbr().get(deduct.getBankType());
		body.addElement("bankAbbr").setText(bankAbbr); // 银行代码
		body.addElement("crdUsrProv").setText(""); // 银行卡归属省
		body.addElement("crdProvNm").setText(""); // 银行卡归属省名称
		body.addElement("crdUsrCity").setText(""); // 银行卡归属市
		body.addElement("crdCityNm").setText(""); // 银行卡归属市名称
		body.addElement("notifyUrl").setText(""); // 后台通知URL
		body.addElement("reserved1").setText("1"); // 保留字段1
		body.addElement("reserved2").setText("2"); // 保留字段2
		
		return rootElement.asXML();
	}
	
	public RTMultiBank parseCrossBankDeductResult(String rtMsg) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(rtMsg.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109,"银行回执报文编码转换异常");
		}// 解析应答报文
		
		final Node nodeHead = dom4jxml.getNode("/root/head");
		String merchantId = dom4jxml.getNodeText(nodeHead, "merchantId");	//商户编号
		String requestId = dom4jxml.getNodeText(nodeHead, "requestId");	//商户请求号
		
		final Node nodeBody = dom4jxml.getNode("/root/body");	
		String returnCode = dom4jxml.getNodeText(nodeBody, "returnCode");	//返回码, 000000-处理成功，结果以支付状态为准。其他信息提示码，提示各类处理失败信息
		String message = dom4jxml.getNodeText(nodeBody, "message");	//返回码信息提示
		String payNo = dom4jxml.getNodeText(nodeBody, "payNo");	//订单流水号
		String ordSts = dom4jxml.getNodeText(nodeBody, "ordSts");	//订单支付状态, P：支付处理中，需要通过查询接口查询扣款结果, S：支付完成, F：支付失败
		String agrNo = dom4jxml.getNodeText(nodeBody, "agrNo");	//签约协议号
		String bnkMsgData = dom4jxml.getNodeText(nodeBody, "bnkMsgData");	//银行返回错误描述
		
		RTMultiBank result = new RTMultiBank();
		result.setMerchantId(merchantId);
		result.setRequestId(requestId);
		result.setReturnCode(returnCode);
		result.setMessage(message);
		result.setPayNo(payNo);
		result.setOrdSts(ordSts);
		result.setAgrNo(agrNo);
		result.setBnkMsgData(bnkMsgData);
		
		return result;
	}
	
	/**
	 * 组装跨行实时交易结果查询请求报文
	 * @param bankSendSn 渠道交易流水(结合商户号生成)
	 * @param orgOrderId 原跨行交易请求订单号
	 * @param channelParms 渠道基本参数配置
	 * @return
	 */
	public String packageMBRTTradeResultQurXml(String bankSendSn, String orgOrderId, Map<String, String> channelParms){
		
		final String merchantId = channelParms.get(Constants.CROSS_BANK_MERCHANT_ID);
		
		Document document = DocumentHelper.createDocument();
		document.setXMLEncoding("GBK");
		// 创建根节点root
		Element rootElement = document.addElement("root");
		//创建head节点
		Element headElement = rootElement.addElement("head");
		headElement.addElement("merchantId").setText(merchantId); // 商户号
		headElement.addElement("requestId").setText(bankSendSn); // 商户请求号
		headElement.addElement("transactionCode").setText(Constants.STD_CD_MULTI_BANK_TRADE_REST_QUR); // 交易代码
		
		//创建body节点
		Element bodyElement = rootElement.addElement("body");
		bodyElement.addElement("orderId").setText(orgOrderId);	//单位编码(银行提供)
		
		return rootElement.asXML();
	}
	
	public RTMultiBankTradeQur parseMultiBankTradeQurResult(String rtMsg) throws BizException{
		Dom4jXMLMessage dom4jxml = null;
		try {
			dom4jxml = Dom4jXMLMessage.parse(rtMsg.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			Log4jUtil.error(e);
			throw new BizException(TransReturnCode.code_9109,"银行回执报文编码转换异常");
		}// 解析应答报文
		
		//报文头
		final Node headRoot = dom4jxml.getNode("/root/head");
		String merchantId = dom4jxml.getNodeText(headRoot, "merchantId");// 商户号
		
		//报文体
		final Node bodyRoot = dom4jxml.getNode("/root/body");
		String returnCode = dom4jxml.getNodeText(bodyRoot, "returnCode");// 返回码
		String message = dom4jxml.getNodeText(bodyRoot, "message");// 返回信息
		String payNo = dom4jxml.getNodeText(bodyRoot, "payNo");// 平台流水号
		String amount = dom4jxml.getNodeText(bodyRoot, "amount");// 订单金额
		String bankAbbr = dom4jxml.getNodeText(bodyRoot, "bankAbbr");// 银行
		String mobile = dom4jxml.getNodeText(bodyRoot, "mobile");// 用户手机号
		String orderId = dom4jxml.getNodeText(bodyRoot, "orderId");// 商户订单号
		String payDate = dom4jxml.getNodeText(bodyRoot, "payDate");// 支付日期
		String status = dom4jxml.getNodeText(bodyRoot, "status");// 订单状态
		String refundAmount = dom4jxml.getNodeText(bodyRoot, "refundAmount");// 退款总金额
		String orderDate = dom4jxml.getNodeText(bodyRoot, "orderDate");// 商户订单日期
		String agrNo = dom4jxml.getNodeText(bodyRoot, "agrNo");// 签约协议号
		
		RTMultiBankTradeQur result = new RTMultiBankTradeQur();
		result.setMerchantId(merchantId);
		result.setReturnCode(returnCode);
		result.setMessage(message);
		result.setPayNo(payNo);
		result.setAmount(amount);
		result.setBankAbbr(bankAbbr);
		result.setMobile(mobile);
		result.setOrderId(orderId);
		result.setPayDate(payDate);
		result.setStatus(status);
		result.setRefundAmount(refundAmount);
		result.setOrderDate(orderDate);
		result.setAgrNo(agrNo);
		
		return result;
	}
}
