package com.lycheepay.clearing.adapter.banks.cciticbCS.service;

import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT0281;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT0298;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT0815;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RT9138;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RTMultiBank;
import com.lycheepay.clearing.adapter.banks.cciticbCS.model.RTMultiBankTradeQur;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.CciticbCsSignInfoService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.util.biz.AssertUtils;
import com.lycheepay.clearing.common.constant.PayState;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.common.model.CciticbCsSignInfo;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;
import com.lycheepay.clearing.adapter.banks.cciticbCS.constant.Constants;

/**
 * 中信长沙银企处理类
 * 
 * @author 黄旭
 */
@Service
public class CciticbCsProcessService {
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager seqService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CCITICB_CS_SIGN_SERVICE)
	private CciticbCsSignInfoService cciticbCsSignInfoService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParmService;
	
	@Autowired
	CciticbCsPackageService packageService;
	
	@Autowired
	CciticbCsSendService cciticbCsSendService;
	
//	static final String channelId = ChannelIdEnum.CNCB_CS_CORP.getCode();
	
	private static final int MAX_MERCHANT_ID = 12;	//中信长沙可支持的最大代理商户号长度(12位)
	
	/**
	 * 单笔实时代扣
	 * 
	 * @param deduct
	 * @return
	 * @author 黄旭
	 * @throws BizException 
	 */
	public ClearingResultDTO directDeduct(DeductDTO deduct, final String channelId) throws BizException {
		if("3021000".equals(deduct.getBankType())){	//本行代扣交易
			return this.innerBankDeduct(deduct, channelId);
		}else{	//跨行代扣交易
			return this.multiBankDeduct(deduct, channelId);
		}
	}
	
	
	/**
	 * 中信长沙本行代扣
	 * @param deduct
	 * @return
	 * @throws BizException
	 */
	private ClearingResultDTO innerBankDeduct(DeductDTO deduct, final String channelId) throws BizException{
		
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String sslTrustStorePath = channelParms.get(Constants.SSL_TRUST_STORE);
		final String sslTrustStorePwd = channelParms.get(Constants.SSL_TRUST_STORE_PWD);
		final String url = channelParms.get(Constants.URL);
		
		String bankSendSn = seqService.getCciticbCsSn();
		
		// 1. 写渠道流水对照表(billno_sn)
		BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, deduct);
		
		//查询当前用户是否已经签约
		AssertUtils.notNull(deduct.getCorpAccountId(), TransReturnCode.code_9108, "商户号不允许为空");
		
		boolean firstSign = false;
		
		String cciticbCsMerId = "";	//代理商编号, 代理商在第三方的唯一编号, 由第三方自行定义
		if(deduct.getCorpAccountId().length() > MAX_MERCHANT_ID){	//中信长沙代理商户号最长位数为12位,KFT商户号目前为16位,需截取
			cciticbCsMerId = deduct.getCorpAccountId().substring(deduct.getCorpAccountId().length() - MAX_MERCHANT_ID, deduct.getCorpAccountId().length());
		}else{
			cciticbCsMerId = deduct.getCorpAccountId();
		}
		//中信的协议签约只关注代理商编号+卡号,故协议检查只通过这两个要素查询即可,其他元素备用
		CciticbCsSignInfo signInfo = cciticbCsSignInfoService.selectSignInfoByMainElement(cciticbCsMerId, deduct.getBankCardNo());
		if(signInfo == null){	//协议不存在
			RT0281 signResult = this.signContract(deduct, bankSendSn, channelId);
			
			Log4jUtil.info("协议签约结果【{}】", signResult);
			
			if("0000".equals(signResult.getRetCode())||"2001".equals(signResult.getRetCode())){	//签约成功 或者 银行已经存在此签约记录(2001),均保存数据至本地数据库
				CciticbCsSignInfo tmpSign = new CciticbCsSignInfo();
				tmpSign.setSn(seqService.getCciticbCsSignSeq());
				tmpSign.setBankSendSn(signResult.getSdId());	//签约请求流水
				tmpSign.setMerchantId(cciticbCsMerId);
				tmpSign.setNm(deduct.getCardHolderName());
				tmpSign.setAcctNum(deduct.getBankCardNo());
				tmpSign.setCertType(deduct.getCertificateType());
				tmpSign.setCertNum(deduct.getCertificateNo());
				tmpSign.setMoblNum(deduct.getPhoneNumber());
				tmpSign.setOpenDt(DateUtil.getCurrentDate());
				tmpSign.setCreateTime(new Date());
				tmpSign.setUpdateTime(new Date());
				cciticbCsSignInfoService.saveSignInfo(tmpSign);
				firstSign = true;
			}else{	//签约不成功,无法进行下一步扣款,故建议直接以失败返回
				//更新billNoSn
				BillnoSn updateBillnoSn = new BillnoSn();
				updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
				updateBillnoSn.setChannelRtncode(StringUtils.trim(signResult.getRetCode()));
				updateBillnoSn.setChannelRtnnote(signResult.getRetMsg());
				updateBillnoSn.setRecvTime(new Date());
				updateBillnoSn.setState(BillnoSnState.billnoRecv);
				updateBillnoSn.setPayState(String.valueOf(PayState.getRtnStrByPayState(PayState.FAILED_STR)));
				billnoSnService.update(updateBillnoSn);
				
				ClearingResultDTO resultDTO = new ClearingResultDTO();
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelResponseMsg(signResult.getRetMsg());
				
				return resultDTO;
			}
		}
		
		if(firstSign){	//已经完成签约，需更新Billno_sn表中记录
			bankSendSn = seqService.getCciticbCsSn();	//重新生成交易请求所需的交易流水
			BillnoSn billnoSn = new BillnoSn();
			billnoSn.setBankSendSn(bankSendSn);
			billnoSn.setSendTime(new Date());
			billnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
			billnoSnService.update(billnoSn);
		}
		
		// 组装代扣交易请求报文
		final String txdate = billNoSn.getTranDate();
		String req = Constants.XML_HEAD + packageService.packageDirectDeductXml(bankSendSn, txdate, deduct);
		// 发送交易请求
		String rsp = cciticbCsSendService.sendData(req, sslTrustStorePath, sslTrustStorePwd, url);
		//解析报文回执
		RT0815 rt0815 = packageService.parse0815Result(rsp);

		String thirdVoucher = "";// 银行流水号, 就是客户自己账户上流水一样, 便查
		String bankRtnCode = "";	//银行返回码
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		if("0000".equals(rt0815.getRetCode())){	//交易请求成功
			if(Constants.RC_SUCCESS.equals(rt0815.getOrderZt())){	//交易成功
				resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			}else if(Constants.RC_FAILURE.equals(rt0815.getOrderZt())){	//交易失败
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			}else{	//交易未知
//				this.queryRTTradeResult(resultDTO, txdate, bankSendSn, bankSendSn);	//单笔交易结果查询
				resultDTO.setTxnStatus(PayState.UNKNOW_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		}else{	//交易请求失败
			resultDTO.setTxnStatus(PayState.FAILED_STR);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
		}

		//公共返回部分,统一赋值
		resultDTO.setChannelResponseMsg(rt0815.getRetMsg());
		thirdVoucher = rt0815.getBankReqId();
		bankRtnCode = rt0815.getRetCode();
		
		// 3. 更新渠道流水对照表(billno_sn)
		BillnoSn updateBillnoSn = new BillnoSn();
		updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
		updateBillnoSn.setChannelRtncode(StringUtils.trim(bankRtnCode));
		updateBillnoSn.setRecvTime(new Date());
		updateBillnoSn.setBankRecvSn(thirdVoucher);
		updateBillnoSn.setState(BillnoSnState.billnoRecv);
		updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
		updateBillnoSn.setChannelRtnnote(resultDTO.getChannelResponseMsg());
		billnoSnService.update(updateBillnoSn);

		return resultDTO;
	}
	
	/**
	 * 中信长沙跨行代扣
	 * @param deduct
	 * @return
	 * @throws BizException
	 */
	private ClearingResultDTO multiBankDeduct(DeductDTO deduct, final String channelId) throws BizException {
		//获取渠道基础参数配置
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String merchantID = channelParms.get(Constants.CROSS_BANK_MERCHANT_ID);
		final String sslTrustStorePath = channelParms.get(Constants.MULTI_BANK_SSL_TRUST_STORE);
		final String sslTrustStorePwd = channelParms.get(Constants.MULTI_BANK_SSL_TRUST_STORE_PWD);
		final String url = channelParms.get(Constants.MULTI_BANK_URL);
		
		//获取渠道交易请求流水(商户号+流水)
		String bankSendSn = merchantID + seqService.getCciticbCsSn();
		// 1. 写渠道流水对照表(billno_sn)
		BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, deduct);
		//组装交易请求报文(完整)
		String req = Constants.XML_HEAD + packageService.packageMultiBankDeductXml(bankSendSn, deduct, channelParms);
		// 发送交易请求
		String rsp = cciticbCsSendService.sendData(req, sslTrustStorePath, sslTrustStorePwd, url);
		
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		String bankRtnCode = "";	//银行返回码
		//解析报文回执
		RTMultiBank rtMultiBank = packageService.parseCrossBankDeductResult(rsp);
		if("000000".equals(rtMultiBank.getReturnCode())){	//交易请求处理成功
			if("S".equals(rtMultiBank.getOrdSts())){	//S：支付完成
				resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				resultDTO.setChannelResponseMsg("支付完成");
			}else if("F".equals(rtMultiBank.getOrdSts())){	//F：支付失败
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelResponseMsg("支付失败");
			}else{	//P：支付处理中，需要通过查询接口查询扣款结果(银行建议30分钟后查询,交易后马上查询,不保证一定能查询到终态)
				/**
				 * 订单状态说明: 
				 * 出现处理中的情况一般是银行端未返回结果给平台.
				 * 平台会有系统轮训去银行查询处理结果,每15分钟一次,一笔订单一天内会查5次(参数可配置).
				 * 只要银行返回处理结果,平台就会同步更新状态.
				 */
				resultDTO.setTxnStatus(PayState.UNKNOW_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				resultDTO.setChannelResponseMsg("支付处理中");
//				try{
//					for (int i = 0; i < 13; i++) {
//						if (TransReturnCode.code_9109.equals(resultDTO.getChannelResponseCode())) {
//							try {
//								Thread.sleep(2000);
//							} catch (InterruptedException e) {
//								Log4jUtil.error(e);
//							}
//							this.queryMBRTTradeResult(resultDTO, bankSendSn);
//						} else {
//							break;
//						}
//					}
//				}catch(Exception biz){
//					Log4jUtil.error(biz);
//					throw new BizException(biz, TransReturnCode.code_9109, biz.getMessage());//对于付款交易, 如果查询交易状态时发生异常, 当异常成功处理, 以保证资金安全.
//				}
				
			}
			//如果银行有返回错误描述,则使用银行的错误描述.测试环境下看是没有错误描述返回的.
			if(!StringUtils.isBlank(rtMultiBank.getBnkMsgData())){resultDTO.setChannelResponseMsg(rtMultiBank.getBnkMsgData());}
			bankRtnCode = rtMultiBank.getOrdSts();
		}else{	//交易请求处理失败
			resultDTO.setTxnStatus(PayState.FAILED_STR);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			bankRtnCode = rtMultiBank.getReturnCode();
			//如果银行有返回错误描述,则使用银行的错误描述.
			if(!StringUtils.isBlank(rtMultiBank.getBnkMsgData())){
				resultDTO.setChannelResponseMsg(rtMultiBank.getBnkMsgData());
			}else{
				resultDTO.setChannelResponseMsg(rtMultiBank.getMessage());
			}
		}
		
		// 3. 更新渠道流水对照表(billno_sn)
		BillnoSn updateBillnoSn = new BillnoSn();
		updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
		updateBillnoSn.setChannelRtncode(StringUtils.trim(bankRtnCode));
		updateBillnoSn.setRecvTime(new Date());
//		updateBillnoSn.setBankRecvSn(thirdVoucher);	//由于银行返回的订单流水为50字节,超出billno_sn中定义的长度,故暂不保存
		updateBillnoSn.setState(BillnoSnState.billnoRecv);
		updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
		updateBillnoSn.setChannelRtnnote(resultDTO.getChannelResponseMsg());
		billnoSnService.update(updateBillnoSn);
		
		return resultDTO;
	}
	
	/**
	 * 单笔实时代付
	 * @param pay
	 * @return
	 * @throws BizException
	 */
	public ClearingResultDTO directPay(PayOutDTO pay,  final String channelId) throws BizException {
		
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String sslTrustStorePath = channelParms.get(Constants.SSL_TRUST_STORE);
		final String sslTrustStorePwd = channelParms.get(Constants.SSL_TRUST_STORE_PWD);
		final String url = channelParms.get(Constants.URL);
		
		String bankSendSn = seqService.getCciticbCsSn();
		// 1. 写渠道流水对照表(billno_sn)
		BillnoSn billNoSn = billnoSnService.saveBillnoSn(bankSendSn, channelId, pay);
		// 组装交易请求报文
		final String txdate = billNoSn.getTranDate();	//请求日期,单独在请求报文组装方法外生成,后面用于交易结果查询,格式:yyyymmdd
		String req = packageService.packageDirectPayXml(bankSendSn, txdate, pay);
		// 发送交易请求
		String rsp = cciticbCsSendService.sendData(req, sslTrustStorePath, sslTrustStorePwd, url);
		//解析报文回执
		RT9138 rt9138 = packageService.parse9138Result(rsp);

		String thirdVoucher = "";// 银行流水号, 就是客户自己账户上流水一样，便查
		String bankRtnCode = "";	//银行返回码
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		if("0000".equals(rt9138.getRetCode())){	//交易请求成功
			if(Constants.RC_SUCCESS.equals(rt9138.getOrderZt())){	//交易成功(正常)
				resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
			}else if(Constants.RC_FAILURE.equals(rt9138.getOrderZt())){	//交易失败(失败)
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			}else{	//交易未知(未明确)
//				this.queryRTTradeResult(resultDTO, txdate, bankSendSn, bankSendSn);	//单笔交易结果查询
				resultDTO.setTxnStatus(PayState.UNKNOW_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			}
		}else{	//交易请求失败
			resultDTO.setTxnStatus(PayState.FAILED_STR);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
		}

		//公共返回部分,统一赋值
		resultDTO.setChannelResponseMsg(rt9138.getRetMsg());
		thirdVoucher = rt9138.getBankReqId();
		bankRtnCode = rt9138.getRetCode();
		
		// 3. 更新渠道流水对照表(billno_sn)
		BillnoSn updateBillnoSn = new BillnoSn();
		updateBillnoSn.setBillnosnSeq(billNoSn.getBillnosnSeq());
		updateBillnoSn.setChannelRtncode(StringUtils.trim(bankRtnCode));
		updateBillnoSn.setRecvTime(new Date());
		updateBillnoSn.setBankRecvSn(thirdVoucher);
		updateBillnoSn.setState(BillnoSnState.billnoRecv);
		updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
		updateBillnoSn.setChannelRtnnote(resultDTO.getChannelResponseMsg());
		billnoSnService.update(updateBillnoSn);
		return resultDTO;
	}
	
	/**
	 * 单笔交易结果查询(只能查询代扣/代付交易,可查询历史记录)
	 * @param billnoSn
	 * @return
	 */
	public ClearingResultDTO querySingleRecord(BillnoSn billnoSn,  final String channelId) throws BizException{
		ClearingResultDTO resultDTO = new ClearingResultDTO();
		if("3021000".equals(billnoSn.getBankType())){	//本行代扣交易结果查询
			this.queryRTTradeResult(channelId, resultDTO, billnoSn.getTranDate(), billnoSn.getBankSendSn(), billnoSn.getBankSendSn());
		}else{	//跨行代扣交易结果查询
			this.queryMBRTTradeResult(channelId, resultDTO, billnoSn.getBankSendSn());
		}
		return resultDTO;
	}
	
	/**
	 * 查询单笔实时交易结果
	 * @param resultDTO 
	 * @param orgOrderDate 原交易请求日期
	 * @param orgOrderCode 原交易请求订单号
	 * @param orgReqId 原交易请求流水
	 * @throws BizException 
	 */
	private void queryRTTradeResult(final String channelId, ClearingResultDTO resultDTO, String orgOrderDate, String orgOrderCode, String orgReqId) throws BizException{
		
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String sslTrustStorePath = channelParms.get(Constants.SSL_TRUST_STORE);
		final String sslTrustStorePwd = channelParms.get(Constants.SSL_TRUST_STORE_PWD);
		final String url = channelParms.get(Constants.URL);
		
		//获取交易查询请求流水
		String bankSendSn = seqService.getCciticbCsSn();
		//构建交易结果查询请求报文
		String req = packageService.packageRTTradeResultQurXml(bankSendSn, orgOrderDate, orgOrderCode, orgReqId);
		// 发送交易请求
		String rsp = cciticbCsSendService.sendData(req, sslTrustStorePath, sslTrustStorePwd, url);
		//解析报文回执
		RT0298 rt0298 = packageService.parse0298Result(rsp);
		if("0000".equals(rt0298.getRetCode())){	//交易查询请求成功
			if(Constants.RC_SUCCESS.equals(rt0298.getOrderZt())){	//交易成功
				resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				resultDTO.setChannelResponseMsg("交易成功");
			}else if(Constants.RC_FAILURE.equals(rt0298.getOrderZt())){	//交易失败
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelResponseMsg("交易失败");
			}else{	//交易结果未知(20未明确; 30已撤销; 40此为冲正撤销交易,撤销成功; 45此为冲正撤销交易,撤销失败)
				resultDTO.setTxnStatus(PayState.UNKNOW_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				resultDTO.setChannelResponseMsg(this.ibOrderStatus2Desc(rt0298.getRetCode()));
			}
		}else if("0100".equals(rt0298.getRetCode())){	//0100:未找到交易,当交易失败
			resultDTO.setTxnStatus(PayState.FAILED_STR);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
			resultDTO.setChannelResponseMsg(rt0298.getRetMsg());
		}else{		//交易查询请求失败,必须以未知返回
			resultDTO.setTxnStatus(PayState.UNKNOW_STR);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg(rt0298.getRetMsg());
		}
	}
	
	/**
	 * 查询跨行单笔实时交易结果
	 * @param resultDTO 查询结果实体类
	 * @param orgOrderId 原交易订单号
	 * @throws BizException 
	 */
	private void queryMBRTTradeResult(final String channelId, ClearingResultDTO resultDTO, String orgOrderId) throws BizException{
		//获取渠道基础参数配置
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String merchantID = channelParms.get(Constants.CROSS_BANK_MERCHANT_ID);
		final String sslTrustStorePath = channelParms.get(Constants.MULTI_BANK_SSL_TRUST_STORE);
		final String sslTrustStorePwd = channelParms.get(Constants.MULTI_BANK_SSL_TRUST_STORE_PWD);
		final String url = channelParms.get(Constants.MULTI_BANK_URL);
		
		//获取交易查询请求流水
		String bankSendSn = merchantID + seqService.getCciticbCsSn();
		//构建交易结果查询请求报文
		String req = Constants.XML_HEAD + packageService.packageMBRTTradeResultQurXml(bankSendSn, orgOrderId, channelParms);
		// 发送交易请求
		String rsp = cciticbCsSendService.sendData(req, sslTrustStorePath, sslTrustStorePwd, url);
		//解析报文回执
		RTMultiBankTradeQur result = packageService.parseMultiBankTradeQurResult(rsp);
		
		if("000000".equals(result.getReturnCode())){	//表示查询成功
			if("S".equals(result.getStatus())){	//支付完成
				resultDTO.setTxnStatus(PayState.SUCCEED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				resultDTO.setChannelResponseMsg(result.getMessage());
			}else if("F".equals(result.getStatus())){	//支付失败
				resultDTO.setTxnStatus(PayState.FAILED_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelResponseMsg(result.getMessage());
			}else{	//P:支付处理中,E:订单过期 ,R:全额退款,RP:退款处理中,其他,都当交易结果未知处理
				resultDTO.setTxnStatus(PayState.UNKNOW_STR);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				resultDTO.setChannelResponseMsg(this.mbOrderStatus2Desc(result.getStatus()));
			}
		}else{	//交易查询请求失败,必须以未知返回
			resultDTO.setTxnStatus(PayState.UNKNOW_STR);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg(result.getMessage());
		}
	}
	
	/**
	 * 签约交易(首次代扣时需签约)
	 * @throws BizException 
	 */
	public RT0281 signContract(DeductDTO deduct, String bankSendSn, final String channelId) throws BizException{
		
		Map<String, String> channelParms = channelParmService.queryCodeParamsMapByChannelId(channelId);
		final String sslTrustStorePath = channelParms.get(Constants.SSL_TRUST_STORE);
		final String sslTrustStorePwd = channelParms.get(Constants.SSL_TRUST_STORE_PWD);
		final String url = channelParms.get(Constants.URL);
		
		//获取交易查询请求流水
		if(StringUtils.isBlank(bankSendSn)){
			bankSendSn = seqService.getCciticbCsSn();
		}
		//构建交易结果查询请求报文
		String req = packageService.packageContractSignXml(bankSendSn, deduct);
		// 发送交易请求
		String rsp = cciticbCsSendService.sendData(req, sslTrustStorePath, sslTrustStorePwd, url);
		//解析报文回执
		RT0281 rt0281 = packageService.parse0281Result(rsp);
		
		return rt0281;
//		ClearingResultDTO resultDTO = new ClearingResultDTO();
//		if("0000".equals(rt0281.getRetCode())){	//签约成功
//			resultDTO.setTxnStatus(PayState.SUCCEED_STR);
//			resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
//			resultDTO.setChannelResponseMsg(rt0281.getRetMsg());
//			resultDTO.setPreAuthCode(bankSendSn);
//		}else{	//签约失败
//			resultDTO.setTxnStatus(PayState.FAILED_STR);
//			resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
//			resultDTO.setChannelResponseMsg(rt0281.getRetMsg());
//			resultDTO.setPreAuthCode(bankSendSn);
//		}
//		return resultDTO;
	}
	
	/**
	 * 订单状态转换成描述(跨行交易)
	 */
	private String mbOrderStatus2Desc(String status){
		switch(status){
			case "P": return "支付处理中";
			case "S": return "支付完成";
			case "E": return "订单过期";
			case "R": return "全额退款";
			case "F": return "支付失败";
			case "RP": return "退款处理中";
			default : return "支付处理中";
		}
		
	}
	
	/**
	 * 订单状态转换成描述(本行交易)
	 */
	private String ibOrderStatus2Desc(String status){
		switch(status){
			case "20": return "未明确";
			case "30": return "已撤销";
			case "40": return "此为冲正撤销交易,撤销成功";
			case "45": return "此为冲正撤销交易,撤销失败)";
			default : return "未明确";
		}
		
	}
}
