package com.lycheepay.clearing.adapter.banks.cciticbCS.constant;

public class Constants {
	/**
	 * 常量--交易代码
	 */
	public static final String STD_CD_DEDUCT = "0815";	//实时代扣交易代码
	
	public static final String STD_CD_CONTRACT_SIGN = "0281";	//协议签约交易代码(首次代扣交易必备)
	public static final String STD_CD_BALANCE_QUERY = "0901";	//实时余额查询
	public static final String STD_CD_PAY = "9138";	//实时代付交易代码
	public static final String STD_CD_RT_TRADE_REST_QUR = "0298";	//实时交易结果查询代码
	public static final String VERSION = "2.0.0";	//版本号
	public static final String RC_SUCCESS = "01";	//交易成功
	public static final String RC_FAILURE = "25";	//交易失败
	
	public static final String DEF_MER_ID = "48245840";	//代理商户ID,自定义,用于交易结果查询
	
	public static final String ENCODED_GBK = "GBK";
	
	public static final String XML_HEAD = "<?xml version=\"2.0.0\" encoding=\"GBK\"?>";
	
	/**
	 * 渠道基础参数
	 */
	public static final String CUST_COED = "100001";	//单位编码(由银行定义)
	public static final String CUST_ID = "100002";	//第三方在银行开立的商户号 (由银行定义 )
	
	/**
	 * 证书配置
	 */
	public static final String SSL_TRUST_STORE = "100003";
	public static final String SSL_TRUST_STORE_PWD = "100004";
	
	public static final String SSL_KEY_STORE = "100005";
	public static final String SSL_KEY_STORE_PWD = "100006";
	
	/**
	 * 交易请求地址
	 */
	public static final String URL = "100007";	//专线地址
	
	public static final String FTP_IP = "100008";	//FTP地址
	public static final String FTP_UESR = "100009";	//FTP登陆用户名
	public static final String FTP_PWD = "100010";	//FTP登陆密码
	public static final String FTP_PORT = "100011";	//FTP端口
	public static final String DOWNLOAD_PATH = "100012";	//FTP文件下载路径
	public static final String LOCAL_TMP_PATH = "100013";	//本地存放路径
	
	public final static String RECON_FILE_SPLITE_FLAG = "\\|";
	
	
	/**
	 *跨行代扣渠道参数配置
	 */
	public static final String CROSS_BANK_MERCHANT_ID = "100014";	//收付通平台给商户分配的唯一标识(由银行定义)
	
	public static final String STD_CD_MULTI_BANK_DEDUCT = "03029138";	//跨行代扣交易代码
	
	public static final String STD_CD_MULTI_BANK_TRADE_REST_QUR = "03020901";	//跨行代扣订单查询交易代码
	
	public static final String MULTI_BANK_SSL_TRUST_STORE = "100015";
	public static final String MULTI_BANK_SSL_TRUST_STORE_PWD = "100016";
	public static final String MULTI_BANK_URL = "100017";	//专线地址
	
	public static final String MULTI_BANK_RECON_FILE_SPLITE_FLAG = "\\,";
}
