package com.lycheepay.clearing.adapter.banks.cciticbCS.model;

import org.soofa.core.model.BaseObject;

/**
 * 跨行交易结果查询实体类
 * @author HuangXu
 *
 */
public class RTMultiBankTradeQur extends BaseObject{
	
	private static final long serialVersionUID = 2369019535181102571L;
	
	private String merchantId;	//商户号
	private String returnCode;	//返回码
	private String message;	//返回信息
	private String payNo;	//平台流水号
	private String amount;	//订单金额
	private String bankAbbr;	//银行
	private String mobile;	//用户手机号
	private String orderId;	//商户订单号
	private String payDate;	//支付日期
	private String status;	//订单状态
	private String refundAmount;	//退款总金额
	private String orderDate;	//商户订单日期
	private String agrNo;	//签约协议号
	
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getPayNo() {
		return payNo;
	}
	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getBankAbbr() {
		return bankAbbr;
	}
	public void setBankAbbr(String bankAbbr) {
		this.bankAbbr = bankAbbr;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getPayDate() {
		return payDate;
	}
	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getAgrNo() {
		return agrNo;
	}
	public void setAgrNo(String agrNo) {
		this.agrNo = agrNo;
	}
	
}
