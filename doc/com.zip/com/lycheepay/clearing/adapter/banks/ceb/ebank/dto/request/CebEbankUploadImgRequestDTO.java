package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankUploadImgRequestDTO extends CebEbankRequestDTO {

	public CebEbankUploadImgRequestDTO() {
		super();
		super.addItem("LoginID", null);
		super.addItem("PassWord", null);
		super.addItem("ServerIp", null);
		super.addItem("PortCode", null);
		super.addItem("FilePath", null);
		super.addItem("FileName", null);
		super.addItem("IndexFileName", null);
		super.addItem("SignForIdCard", null);
		super.addItem("TrsType", null);
		super.addItem("Reserve1", null);
		super.addItem("Reserve2", null);
		super.addItem("Reserve3", null);
		super.addItem("Reserve4", null);
		super.addItem("Reserve5", null);
	}
	
	public String getLoginID() {
		return data.get("LoginID");
	}

	public void setLoginID(String LoginID) {
		data.put("LoginID", LoginID);
	}

	public String getPassWord() {
		return data.get("PassWord");
	}

	public void setPassWord(String PassWord) {
		data.put("PassWord", PassWord);
	}

	public String getServerIp() {
		return data.get("ServerIp");
	}

	public void setServerIp(String ServerIp) {
		data.put("ServerIp", ServerIp);
	}

	public String getPortCode() {
		return data.get("PortCode");
	}

	public void setPortCode(String PortCode) {
		data.put("PortCode", PortCode);
	}

	public String getFilePath() {
		return data.get("FilePath");
	}

	public void setFilePath(String FilePath) {
		data.put("FilePath", FilePath);
	}

	public String getFileName() {
		return data.get("FileName");
	}

	public void setFileName(String FileName) {
		data.put("FileName", FileName);
	}

	public String getIndexFileName() {
		return data.get("IndexFileName");
	}

	public void setIndexFileName(String IndexFileName) {
		data.put("IndexFileName", IndexFileName);
	}

	public String getSignForIdCard() {
		return data.get("SignForIdCard");
	}

	public void setSignForIdCard(String SignForIdCard) {
		data.put("SignForIdCard", SignForIdCard);
	}

	public String getTrsType() {
		return data.get("TrsType");
	}

	public void setTrsType(String TrsType) {
		data.put("TrsType", TrsType);
	}
	
	public String getReserve1() {
		return data.get("Reserve1");
	}

	public void setReserve1(String Reserve1) {
		data.put("Reserve1", Reserve1);
	}
	
	public String getReserve2() {
		return data.get("Reserve2");
	}

	public void setReserve2(String Reserve2) {
		data.put("Reserve2", Reserve2);
	}
	
	public String getReserve3() {
		return data.get("Reserve3");
	}

	public void setReserve3(String Reserve3) {
		data.put("Reserve3", Reserve3);
	}

	public String getReserve4() {
		return data.get("Reserve4");
	}

	public void setReserve4(String Reserve4) {
		data.put("Reserve4", Reserve4);
	}
	
	public String getReserve5() {
		return data.get("Reserve5");
	}

	public void setReserve5(String Reserve5) {
		data.put("Reserve5", Reserve5);
	}
}
