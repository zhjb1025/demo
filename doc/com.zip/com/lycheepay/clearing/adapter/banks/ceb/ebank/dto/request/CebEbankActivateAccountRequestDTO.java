package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankActivateAccountRequestDTO extends CebEbankRequestDTO {

	public CebEbankActivateAccountRequestDTO() {
		super();
		super.addItem("BusinessType", null);
		super.addItem("CheckResult", null);
		super.addItem("CifClientId", null);
		super.addItem("CifName", null);
		super.addItem("IdNo", null);
		super.addItem("IdType", null);
		super.addItem("Remark1", null);
		super.addItem("Remark2", null);
		super.addItem("Remark3", null);
		super.addItem("Remark4", null);
		super.addItem("Remark5", null);
	}

	public String getBusinessType() {
		return data.get("BusinessType");
	}

	public void setBusinessType(String BusinessType) {
		data.put("BusinessType", BusinessType);
	}
	
	public String getCheckResult() {
		return data.get("CheckResult");
	}

	public void setCheckResult(String CheckResult) {
		data.put("CheckResult", CheckResult);
	}
	
	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}
	
	public String getCifName() {
		return data.get("CifName");
	}

	public void setCifName(String CifName) {
		data.put("CifName", CifName);
	}
	
	public String getIdNo() {
		return data.get("IdNo");
	}

	public void setIdNo(String IdNo) {
		data.put("IdNo", IdNo);
	}
	

	public String getIdType() {
		return data.get("IdNo");
	}

	public void setIdType(String IdType) {
		data.put("IdType", IdType);
	}

	public String getRemark1() {
		return data.get("Remark1");
	}

	public void setRemark1(String Remark1) {
		data.put("Remark1", Remark1);
	}

	public String getRemark2() {
		return data.get("Remark2");
	}

	public void setRemark2(String Remark2) {
		data.put("Remark2", Remark2);
	}

	public String getRemark3() {
		return data.get("Remark3");
	}

	public void setRemark3(String Remark3) {
		data.put("Remark3", Remark3);
	}

	public String getRemark4() {
		return data.get("Remark4");
	}

	public void setRemark4(String Remark4) {
		data.put("Remark4", Remark4);
	}

	public String getRemark5() {
		return data.get("Remark5");
	}

	public void setRemark5(String Remark5) {
		data.put("Remark5", Remark5);
	}

}
