package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

/**
 * 调用光大电子账户明细查询接口
 * 响应dto
 * @author 王瑞
 *
 */
public class CebEbankAccountDetailResponseDTO extends CebEbankResponseDTO{
	
	public CebEbankAccountDetailResponseDTO(){
		super.list=new ArrayList<Map<String,String>>();
	}

	public String getTotNum(){
		return data.get("TotNum");
	}
	public void setTotalNum(String TotNum){
		data.put("TotNum", TotNum);
	}
	public String getRetNum(){
		return data.get("RetNum");
	}
	public void setRetNum(String RetNum){
		data.put("RetNum", RetNum);
	}
	public String getReserve9(){
		return data.get("Reserve9");
	}
	public void setReserve9(String Reserve9){
		data.put("Reserve9", Reserve9);
	}
	public String getReserve10(){
		return data.get("Reserve10");
	}
	public void setReserve10(String Reserve10){
		data.put("Reserve10", Reserve10);
	}
	
	public List<Map<String, String>> getList() {
		return list;
	}
	public void setList(List<Map<String, String>> list) {
		this.list = list;
	}
	
}
