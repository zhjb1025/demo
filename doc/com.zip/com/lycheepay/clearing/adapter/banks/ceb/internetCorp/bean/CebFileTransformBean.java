package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import java.io.File;

import org.soofa.core.model.BaseObject;


/**
 * 
 * <P>光大银行代扣交易文件上传下载基类</P>
 * 
 * @author 肖武胜 wsxiao 2013-7-11
 */
public abstract class CebFileTransformBean extends BaseObject {
	private static final long serialVersionUID = -1885223834959082657L;
	/**
	 * 文件换行符
	 */
	protected String line_separator = "\n";// 文件必须为UNIX格式文件，所以换行符为\n
	private String jiambz = "0";// 加密标志
	private String danwbh = "00000000";// 单位编号 目前为：00000000
	private String ywzlbh = "0169";// 业务种类编号 0008：代发工资 0092：其他代发 0169：本行批量代扣
	private String khzhlx = "0";// 客户账号类型 0：对公账号 A：一次性代销账序号 B：丁种账序号
	private String kehuzh = "";// 客户账号 一般是对公账号
	private String huobdh = "01";// 货币代号 01：人民币
	private String chuibz = "0";// 钞汇标志 0：钞 1：汇
	private String zhhuxz = "0001";// 账户性质 一般是'0001'
	private String shofbz = "2";// 代发代扣标志 1：代发 2：代扣
	private String zongje = "";// 总金额
	private String bishuu = "";// 总笔数，最多一万笔(含一万笔)
	private String ruzhrq = "";// 入账日期 如:20050501

	/**
	 * 
	 * <p>将文件内容解析成javaBean</p>
	 * 
	 * @param file
	 * @author 肖武胜 wsxiao 2013-7-11
	 */
	public abstract void parseFile(File file) throws Exception;

	/**
	 * 
	 * <p>将javaBean格式化文件格式</p>
	 * 
	 * @param fileNamePrefix 文件名前缀
	 * @author 肖武胜 wsxiao 2013-7-11
	 */
	public abstract File format2File(String localPath, String fileName) throws Exception;

	/**
	 * 返回 加密标志
	 */
	public String getJiambz() {
		return this.jiambz;
	}

	/**
	 * 设置 加密标志
	 */
	public void setJiambz(String jiambz) {
		this.jiambz = jiambz;
	}

	/**
	 * 返回 单位编号 目前为：00000000
	 */
	public String getDanwbh() {
		return this.danwbh;
	}

	/**
	 * 设置 单位编号 目前为：00000000
	 */
	public void setDanwbh(String danwbh) {
		this.danwbh = danwbh;
	}

	/**
	 * 返回 业务种类编号 0008：代发工资 0092：其他代发 0169：本行批量代扣
	 */
	public String getYwzlbh() {
		return this.ywzlbh;
	}

	/**
	 * 设置 业务种类编号 0008：代发工资 0092：其他代发 0169：本行批量代扣
	 */
	public void setYwzlbh(String ywzlbh) {
		this.ywzlbh = ywzlbh;
	}

	/**
	 * 返回 客户账号类型 0：对公账号 A：一次性代销账序号 B：丁种账序号
	 */
	public String getKhzhlx() {
		return this.khzhlx;
	}

	/**
	 * 设置 客户账号类型 0：对公账号 A：一次性代销账序号 B：丁种账序号
	 */
	public void setKhzhlx(String khzhlx) {
		this.khzhlx = khzhlx;
	}

	/**
	 * 返回 客户账号 一般是对公账号
	 */
	public String getKehuzh() {
		return this.kehuzh;
	}

	/**
	 * 设置 客户账号 一般是对公账号
	 */
	public void setKehuzh(String kehuzh) {
		this.kehuzh = kehuzh;
	}

	/**
	 * 返回 货币代号 01：人民币
	 */
	public String getHuobdh() {
		return this.huobdh;
	}

	/**
	 * 设置 货币代号 01：人民币
	 */
	public void setHuobdh(String huobdh) {
		this.huobdh = huobdh;
	}

	/**
	 * 返回 钞汇标志 0：钞 1：汇
	 */
	public String getChuibz() {
		return this.chuibz;
	}

	/**
	 * 设置 钞汇标志 0：钞 1：汇
	 */
	public void setChuibz(String chuibz) {
		this.chuibz = chuibz;
	}

	/**
	 * 返回 账户性质 一般是'0001'
	 */
	public String getZhhuxz() {
		return this.zhhuxz;
	}

	/**
	 * 设置 账户性质 一般是'0001'
	 */
	public void setZhhuxz(String zhhuxz) {
		this.zhhuxz = zhhuxz;
	}

	/**
	 * 返回 代发代扣标志 1：代发 2：代扣
	 */
	public String getShofbz() {
		return this.shofbz;
	}

	/**
	 * 设置 代发代扣标志 1：代发 2：代扣
	 */
	public void setShofbz(String shofbz) {
		this.shofbz = shofbz;
	}

	/**
	 * 返回 总金额
	 */
	public String getZongje() {
		return this.zongje;
	}

	/**
	 * 设置 总金额
	 */
	public void setZongje(String zongje) {
		this.zongje = zongje;
	}

	/**
	 * 返回 总笔数，最多一万笔(含一万笔)
	 */
	public String getBishuu() {
		return this.bishuu;
	}

	/**
	 * 设置 总笔数，最多一万笔(含一万笔)
	 */
	public void setBishuu(String bishuu) {
		this.bishuu = bishuu;
	}

	/**
	 * 返回 入账日期 如:20050501
	 */
	public String getRuzhrq() {
		return this.ruzhrq;
	}

	/**
	 * 设置 入账日期 如:20050501
	 */
	public void setRuzhrq(String ruzhrq) {
		this.ruzhrq = ruzhrq;
	}

}