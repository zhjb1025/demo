/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-7-6 下午2:36:00
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import org.soofa.core.model.BaseObject;


/**
 * <P>光大银行网上银企单笔转账查证响应Bean</P>
 * 
 * @author 杜波(15999653650)
 */
public class CebInternetCorpDirectPayQueryRspBean extends BaseObject {

	private static final long serialVersionUID = -4164601282180460422L;
	/**
	 * 光大银行报文公共SystemHead部分
	 */
	private CebInternetCorpCommonMsgBean cebInternetCorpCommonMsgBean;
	/**
	 * 交易码
	 */
	private String transCode;
	/**
	 * 银企通流水号,与上送不一样
	 */
	private String batchID;
	/**
	 * 请求日期
	 */
	private String jnlDate;
	/**
	 * 请求时间
	 */
	private String jnlTime;
	/**
	 * 预留字段
	 */
	private String headResponse1;
	/**
	 * 预留字段
	 */
	private String headResponse2;
	/**
	 * 预留字段
	 */
	private String headResponse3;
	/**
	 * 响应码元素返回交易处理状态码
	 */
	private String returnCode;
	/**
	 * 响应信息元素交易处理状态中文信息
	 */
	private String returnMsg;
	/**
	 * 错误详细信息
	 */
	private String error;
	/**
	 * 备注
	 */
	private String returnNote;
	/**
	 * 银企通子流水号,与上送不一样
	 */
	private String clientPatchID;
	/**
	 * 本次交易成功/失败标志
	 */
	private String nowFlag;
	/**
	 * 单笔转账成功/失败标志(要查证的交易的状态)
	 */
	private String tranferFlag;
	/**
	 * 转帐类型
	 */
	private String transferType;
	/**
	 * 帐户号
	 */
	private String accountNo;
	/**
	 * 汇入帐户名称/收款人帐户名称
	 */
	private String toAccountName;
	/**
	 * 汇入帐户号/收款人帐户号
	 */
	private String toAccountNo;
	/**
	 * 余额/发生额
	 */
	private String amount;
	/**
	 * 汇入省市
	 */
	private String toLocation;
	/**
	 * 支票号
	 */
	private String checkNo;
	/**
	 * 支票密码
	 */
	private String checkPassword;
	/**
	 * 加急标志
	 */
	private String isUrgent;
	/**
	 * 转帐用途
	 */
	private String note;
	/**
	 * 用途备注
	 */
	private String noteOther;
	/**
	 * 收款账户对公对私标志
	 */
	private String perOrEnt;
	/**
	 * 循环域预留字
	 */
	private String contentRespond1;
	/**
	 * 循环域预留字
	 */
	private String contentRespond2;
	/**
	 * 循环域预留字
	 */
	private String contentRespond3;
	/**
	 * 循环域预留字
	 */
	private String contentRespond4;
	/**
	 * 循环域预留字
	 */
	private String contentRespond5;

	public CebInternetCorpCommonMsgBean getCebInternetCorpCommonMsgBean() {
		return cebInternetCorpCommonMsgBean;
	}

	public void setCebInternetCorpCommonMsgBean(CebInternetCorpCommonMsgBean cebInternetCorpCommonMsgBean) {
		this.cebInternetCorpCommonMsgBean = cebInternetCorpCommonMsgBean;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getBatchID() {
		return batchID;
	}

	public void setBatchID(String batchID) {
		this.batchID = batchID;
	}

	public String getJnlDate() {
		return jnlDate;
	}

	public void setJnlDate(String jnlDate) {
		this.jnlDate = jnlDate;
	}

	public String getJnlTime() {
		return jnlTime;
	}

	public void setJnlTime(String jnlTime) {
		this.jnlTime = jnlTime;
	}

	public String getHeadResponse1() {
		return headResponse1;
	}

	public void setHeadResponse1(String headResponse1) {
		this.headResponse1 = headResponse1;
	}

	public String getHeadResponse2() {
		return headResponse2;
	}

	public void setHeadResponse2(String headResponse2) {
		this.headResponse2 = headResponse2;
	}

	public String getHeadResponse3() {
		return headResponse3;
	}

	public void setHeadResponse3(String headResponse3) {
		this.headResponse3 = headResponse3;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public String getReturnNote() {
		return returnNote;
	}

	public void setReturnNote(String returnNote) {
		this.returnNote = returnNote;
	}

	public String getClientPatchID() {
		return clientPatchID;
	}

	public void setClientPatchID(String clientPatchID) {
		this.clientPatchID = clientPatchID;
	}

	public String getNowFlag() {
		return nowFlag;
	}

	public void setNowFlag(String nowFlag) {
		this.nowFlag = nowFlag;
	}

	public String getTranferFlag() {
		return tranferFlag;
	}

	public void setTranferFlag(String tranferFlag) {
		this.tranferFlag = tranferFlag;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getToAccountName() {
		return toAccountName;
	}

	public void setToAccountName(String toAccountName) {
		this.toAccountName = toAccountName;
	}

	public String getToAccountNo() {
		return toAccountNo;
	}

	public void setToAccountNo(String toAccountNo) {
		this.toAccountNo = toAccountNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getCheckNo() {
		return checkNo;
	}

	public void setCheckNo(String checkNo) {
		this.checkNo = checkNo;
	}

	public String getCheckPassword() {
		return checkPassword;
	}

	public void setCheckPassword(String checkPassword) {
		this.checkPassword = checkPassword;
	}

	public String getIsUrgent() {
		return isUrgent;
	}

	public void setIsUrgent(String isUrgent) {
		this.isUrgent = isUrgent;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getNoteOther() {
		return noteOther;
	}

	public void setNoteOther(String noteOther) {
		this.noteOther = noteOther;
	}

	public String getPerOrEnt() {
		return perOrEnt;
	}

	public void setPerOrEnt(String perOrEnt) {
		this.perOrEnt = perOrEnt;
	}

	public String getContentRespond1() {
		return contentRespond1;
	}

	public void setContentRespond1(String contentRespond1) {
		this.contentRespond1 = contentRespond1;
	}

	public String getContentRespond2() {
		return contentRespond2;
	}

	public void setContentRespond2(String contentRespond2) {
		this.contentRespond2 = contentRespond2;
	}

	public String getContentRespond3() {
		return contentRespond3;
	}

	public void setContentRespond3(String contentRespond3) {
		this.contentRespond3 = contentRespond3;
	}

	public String getContentRespond4() {
		return contentRespond4;
	}

	public void setContentRespond4(String contentRespond4) {
		this.contentRespond4 = contentRespond4;
	}

	public String getContentRespond5() {
		return contentRespond5;
	}

	public void setContentRespond5(String contentRespond5) {
		this.contentRespond5 = contentRespond5;
	}

}
