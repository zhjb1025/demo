/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-26 下午3:14:31
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ceb.handler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.dto.BatchSendResult;
import com.lycheepay.clearing.adapter.banks.ceb.internetCorp.CebInternetCorpChannelProcessor;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.ChannelTempBill;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>光大银行银企 </P>
 * 
 * @author 杜波(15999653650)
 */
@Service(ClearingAdapterAnnotationName.CEB_INTERNET_CORP_CHANNEL_SERVICE)
public class CebInternetCorpChannelService extends AbstractChannelService {
	private static String channelId = ChannelIdEnum.CEB_CORP.getCode();
	@Autowired
	private CebInternetCorpChannelProcessor cebInternetCorpChannelProcessor;

	/**
	 * 单笔实时付款
	 */
	@Override
	public ClearingResultDTO directPay(PayOutDTO payOutDTO) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CEB", "corp");
		ClearingResultDTO resultDTO = null;
		try {
			resultDTO = cebInternetCorpChannelProcessor.directPay(payOutDTO);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, resultDTO);
		}
		Log4jUtil.info(resultDTO);
		return resultDTO;
	}

	/**
	 * 单笔实时扣款
	 */
	@Override
	public ClearingResultDTO directDeduct(DeductDTO deduct) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CEB", "corp");
		Log4jUtil.info(deduct);
		ClearingResultDTO resultDTO = null;
		try {
			resultDTO = cebInternetCorpChannelProcessor.directDeduct(deduct);
			resultDTO.setChannelId(channelId);
			resultDTO.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		} catch (Exception e) {
			return ChannelResultUtil.exceptionToResult(e, resultDTO);
		}
		return resultDTO;
	}

	@Override
	public BatchSendResult processBatch(String channelBatchId, List<ChannelTempBill> payList, boolean repeatSend)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CEB", "batchDirect");
		Log4jUtil.info("渠道ID【{}】,交易类型【批量交易】,渠道批次号【{}】 开始处理 ", channelId, channelBatchId);

		BatchSendResult batchSendResult = null;
		try {
			batchSendResult = cebInternetCorpChannelProcessor.processBatch(channelBatchId, payList, repeatSend);
		} catch (Exception e) {
			Log4jUtil.error("批量代扣异常：", e);
			return ChannelResultUtil.exceptionToResult(e, batchSendResult);
		}
		Log4jUtil.info("渠道ID【{}】,交易类型【批量代扣交易】,渠道批次号【{}】 结束处理 ", channelId, channelBatchId);
		return batchSendResult;
	}

	@Override
	public void timeQueryBatchTransResult() throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CEB", "BatchQueryResult");
		Log4jUtil.info("渠道ID【{}】,交易类型【批量交易查询】 开始处理 ", channelId);

		try {
			cebInternetCorpChannelProcessor.batchRetProcess();
		} catch (BizException e) {
			Log4jUtil.error("批量交易查询异常：", e);
		}

		Log4jUtil.info("渠道ID【{}】,交易类型【批量交易查询】 结束处理 ", channelId);
	}

	@Override
	public int getMaxNum() {
		return 1000;
	}

}
