package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

public class CebEbankTradeDetailResponseDTO extends CebEbankResponseDTO {
	public String getCoPatrnerJnlNo() {
		return data.get("CoPatrnerJnlNo");
	}

	public void setCoPatrnerJnlNo(String coPatrnerJnlNo) {
		data.put("CoPatrnerJnlNo", coPatrnerJnlNo);
	}

	public String getTrsState() {
		return data.get("TrsState");
	}

	public void setTrsState(String TrsState) {
		data.put("TrsState", TrsState);
	}

	public String getReserve1() {
		return data.get("Reserve1");
	}

	public void setReserve1(String reserve1) {
		data.put("Reserve1", reserve1);
	}

	public String getReserve2() {
		return data.get("Reserve2");
	}

	public void setReserve2(String reserve2) {
		data.put("Reserve2", reserve2);
	}
	
	public String getReserve3() {
		return data.get("Reserve3");
	}

	public void setReserve3(String reserve3) {
		data.put("Reserve3", reserve3);
	}
	
	public String getReserve4() {
		return data.get("Reserve4");
	}

	public void setReserve4(String reserve4) {
		data.put("Reserve4", reserve4);
	}
	
	public String getReserve5() {
		return data.get("Reserve5");
	}

	public void setReserve5(String reserve5) {
		data.put("Reserve5", reserve5);
	}
}
