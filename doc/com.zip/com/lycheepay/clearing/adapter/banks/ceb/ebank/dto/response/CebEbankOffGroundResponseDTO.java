package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

public class CebEbankOffGroundResponseDTO extends CebEbankResponseDTO {

	public String getTransOutType() {
		return data.get("TransOutType");
	}

	public void setTransOutType(String TransOutType) {
		data.put("TransOutType", TransOutType);
	}

	public String getCoPatrnerJnlNo() {
		return data.get("CoPatrnerJnlNo");
	}

	public void setCoPatrnerJnlNo(String CoPatrnerJnlNo) {
		data.put("CoPatrnerJnlNo", CoPatrnerJnlNo);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getAmount() {
		return data.get("Amount");
	}

	public void setAmount(String Amount) {
		data.put("Amount", Amount);
	}

	public String getCebTrsTime() {
		return data.get("CebTrsTime");
	}

	public void setCebTrsTime(String CebTrsTime) {
		data.put("CebTrsTime", CebTrsTime);
	}

	public String getTrsType() {
		return data.get("TrsType");
	}

	public void setTrsType(String TrsType) {
		data.put("TrsType", TrsType);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getCifName() {
		return data.get("CifName");
	}

	public void setCifName(String CifName) {
		data.put("CifName", CifName);
	}

	public String getRemark() {
		return data.get("Remark");
	}

	public void setRemark(String Remark) {
		data.put("Remark", Remark);
	}

	public String getGatherAcNo() {
		return data.get("GatherAcNo");
	}

	public void setGatherAcNo(String GatherAcNo) {
		data.put("GatherAcNo", GatherAcNo);
	}

	public String getGatherName() {
		return data.get("GatherName");
	}

	public void setGatherName(String GatherName) {
		data.put("GatherName", GatherName);
	}

	public String getReserve1() {
		return data.get("Reserve1");
	}

	public void setReserve1(String Reserve1) {
		data.put("Reserve1", Reserve1);
	}

	public String getReserve2() {
		return data.get("Reserve2");
	}

	public void setReserve2(String Reserve2) {
		data.put("Reserve2", Reserve2);
	}

	public String getReserve3() {
		return data.get("Reserve3");
	}

	public void setReserve3(String Reserve3) {
		data.put("Reserve3", Reserve3);
	}
}
