package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base;

import java.util.List;
import java.util.Map;

public abstract class CebEbankResponseDTO extends CebEbankBaseDTO {

	/**
	 * 响应中的HEAD参数信息
	 * @author 王瑞
	 */
	public CebEbankResponseDTO() {
		super.addItem("ReqJnlNo", null);
		super.addItem("ResJnlNo", null);
		super.addItem("ResTime", null);
		super.addItem("ResCode", null);
		super.addItem("ResMsg", null);
	}
	
	//特别注意：凡是使用到list的子类，在构造时必须实例化list，否则会抛出异常
	public List<Map<String,String>> list;

	public String getReqJnlNo() {
		return data.get("ReqJnlNo");
	}

	public void setReqJnlNo(String ReqJnlNo) {
		data.put("ReqJnlNo", ReqJnlNo);
	}

	public String getResJnlNo() {
		return data.get("ResJnlNo");
	}

	public void setResJnlNo(String ResJnlNo) {
		data.put("ResJnlNo", ResJnlNo);
	}

	public String getResTime() {
		return data.get("ResTime");
	}

	public void setResTime(String ResTime) {
		data.put("ResTime", ResTime);
	}

	public String getResCode() {
		return data.get("ResCode");
	}

	public void setResCode(String ResCode) {
		data.put("ResCode", ResCode);
	}

	public String getResMsg() {
		return data.get("ResMsg");
	}

	public void setResMsg(String ResMsg) {
		data.put("ResMsg", ResMsg);
	}

}
