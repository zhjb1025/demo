package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;
/**
 * 
 *  对账文件返回dto
 *
 */
public class CebEbankObtainReconciliactionResponseDTO extends
		CebEbankResponseDTO {

	public String getFileName() {
		return data.get("FileName");
	}

	public void setFileName(String fileName) {
		data.put("FileName", fileName);
	}

	public String getFilePath() {                                            
		return data.get("FilePath");
	}

	public void setFilePath(String filePath) {
		data.put("FilePath", filePath);
	}

	public String getTotNum() {
		return data.get("TotNum");
	}

	public void setTotNum(String totNum) {
		data.put("TotNum", totNum);
	}

	public String getSign() {
		return data.get("Sign");
	}

	public void setSign(String sign) {
		data.put("Sign", sign);
	}

}
