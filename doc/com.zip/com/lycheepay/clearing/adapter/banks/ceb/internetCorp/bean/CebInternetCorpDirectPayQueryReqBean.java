/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-7-6 下午2:36:57
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import org.soofa.core.model.BaseObject;


/**
 * <P>光大银行网上银企单笔转账查证请求Bean</P>
 * 
 * @author 杜波(15999653650)
 */
public class CebInternetCorpDirectPayQueryReqBean extends BaseObject {

	private static final long serialVersionUID = 9188825067802793245L;
	/**
	 * 光大银行报文公共SystemHead部分
	 */
	private CebInternetCorpCommonMsgBean cebInternetCorpCommonMsgBean;
	/**
	 * 交易码
	 */
	private String transCode;
	/**
	 * 交易流水号
	 */
	private String batchID;
	/**
	 * 请求日期
	 */
	private String jnlDate;
	/**
	 * 请求时间
	 */
	private String jnlTime;
	/**
	 * 客户端批内序号/客户交易号
	 */
	private String clientPatchID;
	/**
	 * 单笔转账时送的BatchID
	 */
	private String clientBchID;
	/**
	 * 单笔转账时的ClientPatchID
	 */
	private String clientPchID;

	public CebInternetCorpCommonMsgBean getCebInternetCorpCommonMsgBean() {
		return cebInternetCorpCommonMsgBean;
	}

	public void setCebInternetCorpCommonMsgBean(CebInternetCorpCommonMsgBean cebInternetCorpCommonMsgBean) {
		this.cebInternetCorpCommonMsgBean = cebInternetCorpCommonMsgBean;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getBatchID() {
		return batchID;
	}

	public void setBatchID(String batchID) {
		this.batchID = batchID;
	}

	public String getJnlDate() {
		return jnlDate;
	}

	public void setJnlDate(String jnlDate) {
		this.jnlDate = jnlDate;
	}

	public String getJnlTime() {
		return jnlTime;
	}

	public void setJnlTime(String jnlTime) {
		this.jnlTime = jnlTime;
	}

	public String getClientPatchID() {
		return clientPatchID;
	}

	public void setClientPatchID(String clientPatchID) {
		this.clientPatchID = clientPatchID;
	}

	public String getClientBchID() {
		return clientBchID;
	}

	public void setClientBchID(String clientBchID) {
		this.clientBchID = clientBchID;
	}

	public String getClientPchID() {
		return clientPchID;
	}

	public void setClientPchID(String clientPchID) {
		this.clientPchID = clientPchID;
	}
}
