/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-29 下午3:37:03
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import org.soofa.core.model.BaseObject;


/**
 * <P>光大银行报文公共SystemHead部分</P>
 * 
 * @author 杜波(15999653650)
 */
public class CebInternetCorpCommonMsgBean extends BaseObject {

	private static final long serialVersionUID = 7411445240150676834L;
	private String language;
	private String encodeing;
	private String version;
	private String serviceName;
	private String cifNo;
	private String userId;
	private String syMacFlag;
	private String mac;
	private String syPinFlag;
	private String pinSeed;
	private String licenseId;
	private String flag;
	private String note;

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getEncodeing() {
		return encodeing;
	}

	public void setEncodeing(String encodeing) {
		this.encodeing = encodeing;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getCifNo() {
		return cifNo;
	}

	public void setCifNo(String cifNo) {
		this.cifNo = cifNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSyMacFlag() {
		return syMacFlag;
	}

	public void setSyMacFlag(String syMacFlag) {
		this.syMacFlag = syMacFlag;
	}

	public String getMac() {
		return mac;
	}

	public void setMac(String mac) {
		this.mac = mac;
	}

	public String getSyPinFlag() {
		return syPinFlag;
	}

	public void setSyPinFlag(String syPinFlag) {
		this.syPinFlag = syPinFlag;
	}

	public String getPinSeed() {
		return pinSeed;
	}

	public void setPinSeed(String pinSeed) {
		this.pinSeed = pinSeed;
	}

	public String getLicenseId() {
		return licenseId;
	}

	public void setLicenseId(String licenseId) {
		this.licenseId = licenseId;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

}
