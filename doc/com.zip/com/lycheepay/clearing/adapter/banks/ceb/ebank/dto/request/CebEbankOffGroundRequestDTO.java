package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankOffGroundRequestDTO extends CebEbankRequestDTO {

	public CebEbankOffGroundRequestDTO() {
		super();
		super.addItem("TransOutType", null);
		super.addItem("CoPatrnerJnlNo", null);
		super.addItem("CifClientId", null);
		super.addItem("TrsDate", null);
		super.addItem("Amount", null);
		super.addItem("Currency", null);
		super.addItem("TrsType", null);
		super.addItem("Remark", null);
		super.addItem("SubMerchant", null);
		super.addItem("ConCenFinNo", null);
		super.addItem("GatherAcNo", null);
		super.addItem("GatherName", null);
		super.addItem("Reserve1", null);
		super.addItem("Reserve2", null);
		super.addItem("Reserve3", null);
	}

	public String getTransOutType() {
		return data.get("TransOutType");
	}

	public void setTransOutType(String TransOutType) {
		data.put("TransOutType", TransOutType);
	}

	public String getCoPatrnerJnlNo() {
		return data.get("CoPatrnerJnlNo");
	}

	public void setCoPatrnerJnlNo(String CoPatrnerJnlNo) {
		data.put("CoPatrnerJnlNo", CoPatrnerJnlNo);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getTrsDate() {
		return data.get("TrsDate");
	}

	public void setTrsDate(String TrsDate) {
		data.put("TrsDate", TrsDate);
	}

	public String getAmount() {
		return data.get("Amount");
	}

	public void setAmount(String Amount) {
		data.put("Amount", Amount);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getTrsType() {
		return data.get("TrsType");
	}

	public void setTrsType(String TrsType) {
		data.put("TrsType", TrsType);
	}

	public String getRemark() {
		return data.get("Remark");
	}

	public void setRemark(String Remark) {
		data.put("Remark", Remark);
	}

	public String getConCenFinNo() {
		return data.get("ConCenFinNo");
	}

	public void setConCenFinNo(String ConCenFinNo) {
		data.put("ConCenFinNo", ConCenFinNo);
	}

	public String getGatherAcNo() {
		return data.get("GatherAcNo");
	}

	public void setGatherAcNo(String GatherAcNo) {
		data.put("GatherAcNo", GatherAcNo);
	}

	public String getGatherName() {
		return data.get("GatherName");
	}

	public void setGatherName(String GatherName) {
		data.put("GatherName", GatherName);
	}

	public String getSubMerchant() {
		return data.get("SubMerchant");
	}

	public void setSubMerchant(String SubMerchant) {
		data.put("SubMerchant", SubMerchant);
	}
}
