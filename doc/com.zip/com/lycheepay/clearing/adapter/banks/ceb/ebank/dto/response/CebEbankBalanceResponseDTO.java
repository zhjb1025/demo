package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

public class CebEbankBalanceResponseDTO extends CebEbankResponseDTO {

	public String getAcNoBlance() {
		return data.get("AcNoBlance");
	}

	public void setAcNoBlance(String AcNoBlance) {
		data.put("AcNoBlance", AcNoBlance);
	}

	public String getAvailBlance() {
		return data.get("AvailBlance");
	}

	public void setAvailBlance(String AvailBlance) {
		data.put("AvailBlance", AvailBlance);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

}
