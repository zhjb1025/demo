/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-26 下午3:14:31
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ceb.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ceb.quickPayment.CebQuickPaymentChannelProcessor;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.adapter.common.util.biz.ChannelResultUtil;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.dto.trade.BankCardVerifyDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * <P>光大银行快捷 </P>
 * 
 * @author 潘谦
 */
@Service(ClearingAdapterAnnotationName.CEB_QUICK_PAYMENT_CHANNEL_SERVICE)
public class CebQuickPaymentChannelService extends AbstractChannelService {
	private static String channelId = ChannelIdEnum.CEB_QUICK_PAY.getCode();
	
	@Autowired
	private CebQuickPaymentChannelProcessor cebQuickPaymentChannelProcessor;


	/**
	 * 单笔实时扣款
	 */
	@Override
	public ClearingResultDTO directDeduct(DeductDTO deduct) {
		Log4jUtil.setLogClass("CEB_QUICK", "quick");
		Log4jUtil.info(deduct);
		ClearingResultDTO resultDTO = null;
		try {
			resultDTO = cebQuickPaymentChannelProcessor.directDeduct(deduct);
		} catch (Exception e) {
			resultDTO = ChannelResultUtil.exceptionToResult(e, resultDTO);
		}finally {
			if (resultDTO == null)
				resultDTO = new ClearingResultDTO();
			resultDTO.setChannelId(channelId);
			resultDTO.setClearingTransType(ClearingTransType.REAL_TIME_DEDUCT);
		}
		return resultDTO;
	}

	/**
	 * 单笔实时查询
	 */
	@Override
	public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) {
		Log4jUtil.setLogClass("CEB_QUICK", "query");
		Log4jUtil.info(billnoSn);
		ClearingResultDTO resultDTO = null;
		try {
			resultDTO = cebQuickPaymentChannelProcessor.querySingleRecord(billnoSn);
		} catch (Exception e) {
			resultDTO = ChannelResultUtil.exceptionToResult(e, resultDTO);
		}finally {
			if (resultDTO == null)
				resultDTO = new ClearingResultDTO();
			resultDTO.setChannelId(channelId);
		}
		return resultDTO;
	}
	
	/**
	 * 账户验证
	 */
	@Override
	public ClearingResultDTO accountVerify(BankCardVerifyDTO bankCardVerifyDTO) {
		Log4jUtil.setLogClass("CEB_QUICK", "valid");
		Log4jUtil.info(bankCardVerifyDTO);
		ClearingResultDTO resultDTO = null;
		try {
			resultDTO = cebQuickPaymentChannelProcessor.accountVerify(bankCardVerifyDTO);
		} catch (Exception e) {
			resultDTO = ChannelResultUtil.exceptionToResult(e, resultDTO);
		}finally {
			if (resultDTO == null)
				resultDTO = new ClearingResultDTO();
			resultDTO.setChannelId(channelId);
			resultDTO.setClearingTransType(ClearingTransType.MSG_ACCOUNT_VERIFY);
		}
		return resultDTO;
	}
}
