package com.lycheepay.clearing.adapter.banks.ceb.ebank;
/**
 * 一帐通光大交易类型常量
 * @author 杨开宇
 *
 */
public class CebEbankTransTypeConstant {
	
	public static final String RECHARGE="0";	//充值
	public static final String REBATE_T0="1";	//返利T+0
	public static final String REFUND="2";	//退款
	public static final String CONSUMPTION="3";	//消费
	public static final String WITHDRAWALS="4";	//提现
	public static final String REBATE_T1="5";		//返利T+1
	public static final String WHOLE="9";		//全部
	
	
	

}
