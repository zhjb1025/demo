package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankCloseAccountRequestDTO extends CebEbankRequestDTO{

	public CebEbankCloseAccountRequestDTO() {
		super();
		super.addItem("CifClientId", null);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}
}
