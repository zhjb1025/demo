package com.lycheepay.clearing.adapter.banks.ceb.ebank.service.bank;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.gnete.security.crypt.CryptException;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.CebEbankConstant;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.http.CebEbankHttpConnector;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.util.security.PfxSignVerify;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;

@Service
public class CebEbankService {
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;
	
	/**
	 * 
	 * <p>银行通信服务的主方法</p>
	 * @param req 通用类型
	 * @param resp 适配类型
	 * @return resp
	 * @author 王瑞
	 * @throws BizException 
	 */
	public <T extends CebEbankResponseDTO> T transfer(CebEbankRequestDTO req, T resp) throws BizException {
		try {
			CebEbankHttpConnector conn  = new CebEbankHttpConnector(
					getParams(CebEbankConstant.PARM_SYS_URL),Integer.parseInt(getParams(CebEbankConstant.PARM_SYS_HTTPS_PORT)),
					Integer.parseInt(getParams(CebEbankConstant.PARM_SYS_CONN_TIMEOUT)),Integer.parseInt(getParams(CebEbankConstant.PARM_SYS_SO_TIMEOUT))
			);
			
			//签名 加密
			sign(req);
			
			Log4jUtil.info("[PARM]{}", req.getContentMap());
			
			//连接请求接口
			String result = conn.connect(req.getContentMap());
			
			//转换结果对象
			convertXml2Dto(result,resp);
		} catch (GeneralSecurityException e) {
			throw new BizException(TransReturnCode.code_9900, e.getMessage());
		} catch (IOException e) {
			throw new BizException(TransReturnCode.code_9109, e.getMessage());			
		} catch (Exception e) {
			throw new BizException(TransReturnCode.code_9900, e.getMessage());
		}
		return resp;
	}

	@SuppressWarnings("unchecked")
	private void convertXml2Dto(String xml, CebEbankResponseDTO dto) throws BizException{
		try {
			Log4jUtil.info("[XML]<--{}\n{}", dto.getClass().getName(), xml);
			Document document = DocumentHelper.parseText(xml);
			Node head = document.selectSingleNode("/Message/Head");
			Node body = document.selectSingleNode("/Message/Body");
			dto.setReqJnlNo(getNodeText(head.selectSingleNode("ReqJnlNo")));
			dto.setResJnlNo(getNodeText(head.selectSingleNode("ResJnlNo")));
			dto.setResCode(getNodeText(head.selectSingleNode("ResCode")));
			dto.setResMsg(getNodeText(head.selectSingleNode("ResMsg")));
			dto.setResTime(getNodeText(head.selectSingleNode("ResTime")));
			if(body != null){
				List<Node> list = body.selectNodes("./*");
				for(Node node : list){
					if("List".equals(node.getName())){
						//含有List的处理
						List<Node> details = node.selectNodes("Map");
						for(Node datail: details){
							HashMap<String,String> map = new HashMap<String,String>();
							List<Node> items = datail.selectNodes("./*");
							for(Node item: items){
								map.put(item.getName(), item.getText());
							}
							dto.list.add(map);
						}
					}else{
						dto.addItem(node.getName(), node.getText());
					}
				}
			}
		}
		catch(DocumentException e){
			throw new BizException(TransReturnCode.code_9109, e.getMessage());
		}
		Log4jUtil.info("[XML]-->\n{}", dto);
	}
	
	public String sign(byte[] b) throws BizException{
		try {
			Log4jUtil.info("[Sign]<--{}", new String(b));
			String signB64 = PfxSignVerify.signMsg_Base64(b, getParams(CebEbankConstant.PARM_SYS_PFX_PATH), getParams(CebEbankConstant.PARM_SYS_PFX_PWD));
			Log4jUtil.info("[Sign]-->{}", signB64);
			return signB64;
		} catch (CryptException e) {
			throw new BizException(TransReturnCode.code_9900, e.getMessage());
		}
	}
	
	/**
	 * 
	 * <p>签名 加密</p>
	 * @param dto
	 * @return
	 * @throws BizException
	 */
	private String sign(CebEbankRequestDTO dto) throws BizException{
		try {
			String dataStr = dto.buildData();
			Log4jUtil.info("[Sign]<--{}", dataStr);
			String signB64 = PfxSignVerify.signMsg_Base64(dataStr, getParams(CebEbankConstant.PARM_SYS_PFX_PATH), getParams(CebEbankConstant.PARM_SYS_PFX_PWD));
			dto.setSign(signB64);
			Log4jUtil.info("[Sign]-->{}", signB64);
			return signB64;
		} catch (CryptException e) {
			throw new BizException(TransReturnCode.code_9900, e.getMessage());
		}
	}
	
	private String getParams(String param){
		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(ChannelIdEnum.CEB_EBANK_PAY.getCode());
		return params.get(param);
	}
	
	private String getNodeText(Node node){
		return node == null ? "" : node.getText();
	}
}
