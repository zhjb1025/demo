package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankClearanceRequestDTO extends CebEbankRequestDTO {

	public CebEbankClearanceRequestDTO() {
		super();
		super.addItem("CifClientId", null);
		super.addItem("ChannelSeq", null);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getChannelSeq() {
		return data.get("ChannelSeq");
	}

	public void setChannelSeq(String ChannelSeq) {
		data.put("ChannelSeq", ChannelSeq);
	}

}
