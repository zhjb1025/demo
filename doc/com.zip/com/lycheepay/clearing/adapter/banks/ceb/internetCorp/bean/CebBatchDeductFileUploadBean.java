package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.lycheepay.clearing.adapter.banks.ceb.internetCorp.util.CommonFunction;
import com.lycheepay.clearing.util.DateUtil;


/**
 * 
 * <P>光大银行批量代扣文件上传转换JavaBean</P>
 * 
 * @author 肖武胜 wsxiao 2013-7-11
 */
public class CebBatchDeductFileUploadBean extends CebFileTransformBeanAdaptor {
	private static final long serialVersionUID = -8891134617491693695L;
	private List<DeductDetailInfo> list = Collections.emptyList();

	@Override
	public File format2File(String localPath, String fileName) throws Exception {
		StringBuilder sb = new StringBuilder(super.packageFileHead());
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				DeductDetailInfo deductInfo = list.get(i);
				sb.append(deductInfo.getAccountNo()).append("|");
				sb.append(deductInfo.getAmount()).append("|");
				sb.append(deductInfo.getAccountName()).append("|");
				sb.append(deductInfo.getNote()).append("|");
				sb.append(deductInfo.getCertificateNo()).append("|");
				if (i < list.size() - 1)
					sb.append(line_separator);
			}
		}
		return CommonFunction.createTextFile(localPath, fileName, sb.toString());
	}

	public static void main(String[] args) throws Exception {
		CebBatchDeductFileUploadBean bean = new CebBatchDeductFileUploadBean();
		bean.setRuzhrq(DateUtil.getCurrentDate());
		DeductDetailInfo info = new DeductDetailInfo("1111111111111111111111", "4.68", "凤飞飞", "更改", "610222211111111");
		List<DeductDetailInfo> list = new ArrayList<DeductDetailInfo>();
		list.add(info);
		bean.setList(list);
		bean.setKehuzh("55555555555555555");
		File file = bean.format2File("E:", "ceb.txt");
		System.out.println("生成上传文件：" + file.getAbsolutePath());
	}

	public List<DeductDetailInfo> getList() {
		return list;
	}

	public void setList(List<DeductDetailInfo> list) {
		this.list = list;
		if (this.list != null && list.size() > 0) {
			super.setBishuu(String.valueOf(list.size()));
			BigDecimal totalAmount = new BigDecimal("0.00");
			for (DeductDetailInfo deductInfo : list) {
				totalAmount = totalAmount.add(CommonFunction.parse2BigDecimal(deductInfo.getAmount()));
			}
			super.setZongje(CommonFunction.parse2String(totalAmount));
		}
	}
}
