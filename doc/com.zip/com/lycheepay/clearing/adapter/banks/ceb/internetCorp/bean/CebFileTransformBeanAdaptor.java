package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Method;

import org.apache.commons.lang.StringUtils;


/**
 * 
 * <P>光大银行代扣交易文件上传下载基类适配器</P>
 * 
 * @author 肖武胜 wsxiao 2013-7-12
 */
public class CebFileTransformBeanAdaptor extends CebFileTransformBean {

	private static final long serialVersionUID = -6425378820588120112L;

	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void parseFile(File file) throws Exception {
		if (file != null) {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line = null;
			String[] heads = null;
			String headKey = null;
			try {
				Class clasz = this.getClass();
				while (StringUtils.isNotBlank(line = br.readLine())) {
					if (line.startsWith("-"))// 头已经解析完退出
						break;
					heads = StringUtils.splitPreserveAllTokens(line, ":");
					if (heads != null && heads.length > 1) {
						headKey = heads[0].toLowerCase();
						if (headKey != null && headKey.length() > 1) {
							Method method = clasz.getMethod(
									"set" + headKey.substring(0, 1).toUpperCase() + headKey.substring(1),
									java.lang.String.class);
							method.invoke(this, heads[1].trim());
						}
					}
				}
			} finally {
				if (br != null)
					br.close();
			}
		}
	}

	@Override
	public File format2File(String localPath, String fileName) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * 
	 * <p>组装文件头</p>
	 * 
	 * @return
	 * @author 肖武胜 wsxiao 2013-7-12
	 */
	protected String packageFileHead() {
		StringBuilder sb = new StringBuilder();
		sb.append("JIAMBZ:").append(getJiambz()).append(line_separator);
		sb.append("DANWBH:").append(getDanwbh()).append(line_separator);
		sb.append("YWZLBH:").append(getYwzlbh()).append(line_separator);
		sb.append("KHZHLX:").append(getKhzhlx()).append(line_separator);
		sb.append("KEHUZH:").append(getKehuzh()).append(line_separator);
		sb.append("HUOBDH:").append(getHuobdh()).append(line_separator);
		sb.append("CHUIBZ:").append(getChuibz()).append(line_separator);
		sb.append("ZHHUXZ:").append(getZhhuxz()).append(line_separator);
		sb.append("SHOFBZ:").append(getShofbz()).append(line_separator);
		sb.append("ZONGJE:").append(getZongje()).append(line_separator);
		sb.append("BISHUU:").append(getBishuu()).append(line_separator);
		sb.append("RUZHRQ:").append(getRuzhrq()).append(line_separator);
		sb.append("-----------------------").append(line_separator);
		return sb.toString();
	}

}
