package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

public class CebEbankActivateAccountResponseDTO extends CebEbankResponseDTO {

	public String getDealResult() {
		return data.get("DealResult");
	}

	public void setDealResult(String DealResult) {
		data.put("DealResult", DealResult);
	}
	
	

}
