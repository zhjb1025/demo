package com.lycheepay.clearing.adapter.banks.ceb.ebank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.service.process.CebEbankProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractEAccountService;
import com.lycheepay.clearing.common.dto.eaccount.EAccountActivateDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountActivateResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountAllDetailQueryDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountAllDetailResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountBalanceDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountBalanceResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountClearanceDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountClearanceResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountDetailQueryDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountDetailQueryResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountRegisterDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountRegisterResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUnregisterDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUnregisterResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUploadImgDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUploadImgResultDTO;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.CEB_EBANK_EACCOUNT_SERVICE)
public class CebEbankEAccountService extends AbstractEAccountService {
	
	private void logger() {
		Log4jUtil.setLogClass("CEB", "EAccountService");
	}

	@Autowired
	CebEbankProcessService cebEbankProcessService;
	
	@Override
	public EAccountRegisterResultDTO registerAccount(EAccountRegisterDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户渠道开户入口-参数:{}", dto);
		EAccountRegisterResultDTO ret = cebEbankProcessService.openAccount(dto);
		Log4jUtil.info("光大开放平台电子账户渠道开户出口-返回:{}", ret);
		return ret;
	}
	
	@Override
	public EAccountUnregisterResultDTO unRegisterAccount(EAccountUnregisterDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户渠道销户入口-参数:{}", dto);
		EAccountUnregisterResultDTO ret = cebEbankProcessService.closeAccount(dto);
		Log4jUtil.info("光大开放平台电子账户渠道销户出口-返回:{}", ret);
		return ret;
	}

	@Override
	public EAccountClearanceResultDTO settlementInterest(EAccountClearanceDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户结息提现入口-参数:{}", dto);
		EAccountClearanceResultDTO ret = cebEbankProcessService.clearance(dto);
		Log4jUtil.info("光大开放平台电子账户结息提现出口-返回:{}", ret);
		return ret;
	}

	@Override
	public EAccountBalanceResultDTO queryBalance(EAccountBalanceDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户渠道余额查询入口-参数:{}", dto);
		EAccountBalanceResultDTO ret = cebEbankProcessService.balance(dto);
		Log4jUtil.info("光大开放平台电子账户渠道余额查询出口-返回:{}", ret);
		return ret;
	}

	@Override
	public EAccountDetailQueryResultDTO queryTradeDetail(EAccountDetailQueryDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户渠道交易明细查询入口-参数:{}", dto);
		EAccountDetailQueryResultDTO ret = cebEbankProcessService.queryTradeDetail(dto);
		Log4jUtil.info("光大开放平台电子账户渠道交易明细查询出口-返回:{}", ret);
		return ret;
	}

	@Override
	public EAccountUploadImgResultDTO uploadImageData(EAccountUploadImgDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户影像资料上传入口-参数:{}", dto);
		EAccountUploadImgResultDTO ret = cebEbankProcessService.uploadImage(dto);
		Log4jUtil.info("光大开放平台电子账户影像资料上传出口-返回:{}", ret);
		return ret;
	}

	@Override
	public EAccountAllDetailResultDTO queryAccountDetail(EAccountAllDetailQueryDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户所有明细查询入口-参数:{}", dto);
		EAccountAllDetailResultDTO ret = cebEbankProcessService.queryAccountDetail(dto);
		Log4jUtil.info("光大开放平台电子账户所有明细查询出口-返回:{}", ret);
		return ret;
	}

	/** 
	 * @see com.lycheepay.clearing.adapter.app.common.service.EAccountService#activateAccount(com.lycheepay.clearing.common.dto.eaccount.EAccountRegisterDTO)
	 */
	@Override
	public EAccountActivateResultDTO activateAccount(EAccountActivateDTO dto) {
		logger();
		Log4jUtil.info("光大开放平台电子账户渠道开户入口-参数:{}", dto);
		EAccountActivateResultDTO ret = cebEbankProcessService.activateAccount(dto);
		Log4jUtil.info("光大开放平台电子账户渠道开户出口-返回:{}", ret);
		return ret;
	}
}
