package com.lycheepay.clearing.adapter.banks.ceb.ebank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.RuntimeBizException;
import com.lycheepay.clearing.adapter.common.mapper.EBankReconReqRecordMapper;
import com.lycheepay.clearing.adapter.common.model.biz.EBankReconReqRecord;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.CEB_BANK_GET_RECON_FILE_SERVICE_HELPER)
public class CebEbankReconServiceHelper {

	@Autowired
	private EBankReconReqRecordMapper eBankReconReqRecordMapper;
	
	public EBankReconReqRecord getEBankReconReqRecord(EBankReconReqRecord record){
		Log4jUtil.info("===========CebEbankReconServiceHelper  getEBankReconReqRecord start==========");
		List<EBankReconReqRecord> records = new ArrayList<>();
		try{
			records = eBankReconReqRecordMapper.selectByCondition(record);
			if(records.size()==0){
				return null;
			}
			Log4jUtil.info("CebEbankReconServiceHelper  getEBankReconReqRecord records.size=="+records.size());
		}catch (Exception e) {
			Log4jUtil.error("getEBankReconReqRecord error",e);
			return null;
		}
		Log4jUtil.info("===========CebEbankReconServiceHelper  getEBankReconReqRecord end==========");
		return records.get(0);
	}
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, timeout = 3)
	public void insertSelective(EBankReconReqRecord record){
		try{
			eBankReconReqRecordMapper.insertSelective(record);
		}catch (Exception e) {
			Log4jUtil.error("CebEbankReconServiceHelper insertSelective error", e);
			throw e;
		}
		
	}
	
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED, timeout = 3)
	public int updateByPrimaryKeySelective(EBankReconReqRecord record){
		int count = 0;
		try{
			count = eBankReconReqRecordMapper.updateByPrimaryKeySelective(record);
			if(count!=1){
				Log4jUtil.info("eBankReconReqRecordMapper.updateByPrimaryKeySelective count : "+count);
				throw new RuntimeBizException("eBankReconReqRecordMapper.updateByPrimaryKeySelective error");
			}
		}catch (Exception e) {
			Log4jUtil.error("CebEbankReconServiceHelper updateByPrimaryKeySelective error", e);
			throw e;
		}
		return count;
	}
}
