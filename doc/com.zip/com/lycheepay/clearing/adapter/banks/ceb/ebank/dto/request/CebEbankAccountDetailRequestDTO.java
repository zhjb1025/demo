package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

/**
 * 
 * 交易查询dto
 * 
 */
public class CebEbankAccountDetailRequestDTO extends CebEbankRequestDTO {

	public CebEbankAccountDetailRequestDTO() {
		super();
		super.addItem("Reserve1", "");
		super.addItem("Reserve2", "");
		super.addItem("Reserve3", "");
		super.addItem("Reserve4", "");
		super.addItem("Reserve5", "");
		super.addItem("Reserve6", "");
		super.addItem("Reserve7", "");
		super.addItem("Reserve8", "");
	}

	public String getBeginDate() {
		return data.get("BeginDate");
	}

	public void setBeginDate(String BeginDate) {
		data.put("BeginDate", BeginDate);
	}

	public String getEndDate() {
		return data.get("EndDate");
	}

	public void setEndDate(String EndDate) {
		data.put("EndDate", EndDate);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getStartItem() {
		return data.get("StartItem");
	}

	public void setStartItem(String StartItem) {
		data.put("StartItem", StartItem);
	}

	public String getItemNum() {
		return data.get("ItemNum");
	}

	public void setItemNum(String ItemNum) {
		data.put("ItemNum", ItemNum);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getReserve1() {
		return data.get("Reserve1");
	}

	public void setReserve1(String Reserve1) {
		data.put("Reserve1", Reserve1);
	}

	public String getReserve2() {
		return data.get("Reserve2");
	}

	public void setReserve2(String Reserve2) {
		data.put("Reserve2", Reserve2);
	}

	public String getReserve3() {
		return data.get("Reserve3");
	}

	public void setReserve3(String Reserve3) {
		data.put("Reserve3", Reserve3);
	}

	public String getReserve4() {
		return data.get("Reserve4");
	}

	public void setReserve4(String Reserve4) {
		data.put("Reserve4", Reserve4);
	}

	public String getReserve5() {
		return data.get("Reserve5");
	}

	public void setReserve5(String Reserve5) {
		data.put("Reserve5", Reserve5);
	}

	public String getReserve6() {
		return data.get("Reserve6");
	}

	public void setReserve6(String Reserve6) {
		data.put("Reserve6", Reserve6);
	}

	public String getReserve7() {
		return data.get("Reserve7");
	}

	public void setReserve7(String Reserve7) {
		data.put("Reserve7", Reserve7);
	}

	public String getReserve8() {
		return data.get("Reserve8");
	}

	public void setReserve8(String Reserve8) {
		data.put("Reserve8", Reserve8);
	}

}
