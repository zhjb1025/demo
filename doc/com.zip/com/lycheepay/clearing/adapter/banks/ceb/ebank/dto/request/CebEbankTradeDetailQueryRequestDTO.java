package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;


import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

/**
 * 调用光大电子账户明细查询接口
 * 查询用户光大电子账户的明细请求dto
 * @author 杨开宇
 *
 */
public class CebEbankTradeDetailQueryRequestDTO extends CebEbankRequestDTO {
	
	
	
	public CebEbankTradeDetailQueryRequestDTO() {
		super();
		super.addItem("Reserve1", null);
		super.addItem("Reserve2", null);
		super.addItem("Reserve3", null);
	}
	public String getBeginDate(){
		return data.get("BeginDate");
	}
	public void setBeginDate(String BeginDate){
		data.put("BeginDate", BeginDate);
	}
	public String getEndDate(){
		return data.get("EndDate");
	}
	public void setEndDate(String EndDate){
		data.put("EndDate", EndDate);
	}
	public String getCifClientId(){
		return data.get("CifClientId");
	}
	public void setCifClientId(String CifClientId){
		data.put("CifClientId", CifClientId);
	}
	public String getStartItem(){
		return data.get("StartItem");
	}
	public void setStartItem(String StartItem){
		data.put("StartItem", StartItem);
	}
	public String getItemNum(){
		return data.get("ItemNum");
	}
	public void setItemNum(String ItemNum){
		data.put("ItemNum", ItemNum);
	}
	public String getTrsType(){
		return data.get("TrsType");
	}
	public void setTrsType(String TrsType){
		data.put("TrsType", TrsType);
	}
	public String getCurrency(String Currency){
		return data.get("Currency");
	}
	public void setCurrency(String Currency){
		data.put("Currency", Currency);
	}

	
	
	
}
