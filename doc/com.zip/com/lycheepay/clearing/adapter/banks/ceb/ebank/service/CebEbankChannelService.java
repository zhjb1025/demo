package com.lycheepay.clearing.adapter.banks.ceb.ebank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.service.process.CebEbankProcessService;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.service.channel.AbstractChannelService;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.DirectTradeOffGroundDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.CEB_EBANK_CHANNEL_SERVICE)
public class CebEbankChannelService extends AbstractChannelService {
	
	@Autowired
	CebEbankProcessService cebEbankProcessService;
	
	private void logger(){
		Log4jUtil.setLogClass("CEB", "ChannelService");
	}

	@Override
	public ClearingResultDTO directDeduct(DeductDTO deduct) throws ClearingAdapterBizCheckedException {
		logger();
		Log4jUtil.info("光大开放平台普通渠道扣款入口-参数:{}", deduct);
		ClearingResultDTO ret = cebEbankProcessService.deduct(deduct);
		Log4jUtil.info("光大开放平台普通渠道扣款出口-返回:{}", deduct);
		return ret;
	}

	@Override
	public ClearingResultDTO directPay(PayOutDTO pay) throws ClearingAdapterBizCheckedException {
		logger();
		Log4jUtil.info("光大开放平台普通渠道付款入口-参数:{}", pay);
		ClearingResultDTO ret = cebEbankProcessService.payOut(pay);
		Log4jUtil.info("光大开放平台普通渠道付款出口-返回:{}", pay);
		return ret;
	}

	@Override
	public ClearingResultDTO directTradeOffGround(DirectTradeOffGroundDTO directTradeDTO) throws ClearingAdapterBizCheckedException {
		logger();
		Log4jUtil.info("光大开放平台普通渠道不落地入口-参数:{}", directTradeDTO);
		ClearingResultDTO ret = cebEbankProcessService.offGround(directTradeDTO);
		Log4jUtil.info("光大开放平台普通渠道不落地出口-返回:{}", directTradeDTO);
		return ret;
	}

	@Override
	public ClearingResultDTO querySingleRecord(BillnoSn billnoSn) {
		logger();
		Log4jUtil.info("光大开放平台普通渠道交易查询入口-参数:{}", billnoSn);
		ClearingResultDTO ret = cebEbankProcessService.getQueryTradeState(billnoSn);
		Log4jUtil.info("光大开放平台普通渠道交易查询出口-返回:{}", billnoSn);
		return ret;
	}
}
