package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

public class CebEbankClearanceResponseDTO extends CebEbankResponseDTO {

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getAmount() {
		return data.get("Amount");
	}

	public void setAmount(String Amount) {
		data.put("Amount", Amount);
	}

	public String getInterest() {
		return data.get("Interest");
	}

	public void setInterest(String Interest) {
		data.put("Interest", Interest);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getChannelSeq() {
		return data.get("ChannelSeq");
	}

	public void setChannelSeq(String ChannelSeq) {
		data.put("ChannelSeq", ChannelSeq);
	}

}
