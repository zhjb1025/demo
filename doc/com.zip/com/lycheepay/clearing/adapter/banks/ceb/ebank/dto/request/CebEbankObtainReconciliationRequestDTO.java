package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

/**
 * 
 * 对账文件请求dto
 * 
 */
public class CebEbankObtainReconciliationRequestDTO extends CebEbankRequestDTO {

	public String getServiceId() {
		return data.get("ServiceId");
	}

	public void setServiceId(String serviceId) {
		data.put("ServiceId", serviceId);
	}

	public String getQryDate() {
		return data.get("QryDate");
	}

	public void setQryDate(String qryDate) {
		data.put("QryDate", qryDate);
	}

}
