package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

public class CebEbankDeductResponseDTO extends CebEbankResponseDTO {

	public String getAmount() {
		return data.get("Amount");
	}

	public void setAmount(String Amount) {
		data.put("Amount", Amount);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getChannelSeq() {
		return data.get("ChannelSeq");
	}

	public void setChannelSeq(String ChannelSeq) {
		data.put("ChannelSeq", ChannelSeq);
	}

	public String getCifName() {
		return data.get("CifName");
	}

	public void setCifName(String CifName) {
		data.put("CifName", CifName);
	}

	public String getWDAcNo() {
		return data.get("WDAcNo");
	}

	public void setWDAcNo(String WDAcNo) {
		data.put("WDAcNo", WDAcNo);
	}

	public String getWDBankNo() {
		return data.get("WDBankNo");
	}

	public void setWDBankNo(String WDBankNo) {
		data.put("WDBankNo", WDBankNo);
	}

	public String getWDBankName() {
		return data.get("WDBankName");
	}

	public void setWDBankName(String WDBankName) {
		data.put("WDBankName", WDBankName);
	}

}
