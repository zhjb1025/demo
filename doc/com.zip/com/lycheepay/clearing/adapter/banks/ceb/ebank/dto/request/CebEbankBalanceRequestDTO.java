package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankBalanceRequestDTO extends CebEbankRequestDTO {

	public CebEbankBalanceRequestDTO() {
		super();
		super.addItem("CifClientId", null);
		super.addItem("IdNo", null);
		super.addItem("IdType", null);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getIdNo() {
		return data.get("IdNo");
	}

	public void setIdNo(String IdNo) {
		data.put("IdNo", IdNo);
	}

	public String getIdType() {
		return data.get("IdType");
	}

	public void setIdType(String IdType) {
		data.put("IdType", IdType);
	}
}
