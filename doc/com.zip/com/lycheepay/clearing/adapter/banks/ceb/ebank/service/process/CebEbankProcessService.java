package com.lycheepay.clearing.adapter.banks.ceb.ebank.service.process;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.CebEbankConstant;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.CebEbankTransTypeConstant;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankAccountDetailRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankActivateAccountRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankBalanceRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankClearanceRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankCloseAccountRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankDeductRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankObtainReconciliationRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankOffGroundRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankOpenAccountRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankPayOutRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankTradeDetailQueryRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankTradeDetailRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankUploadImgRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankAccountDetailResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankActivateAccountResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankBalanceResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankClearanceResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankCloseAccountResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankDeductResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankObtainReconciliactionResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankOffGroundResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankOpenAccountResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankPayOutResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankTradeDetailQueryResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankTradeDetailResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankUploadImgResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.service.CebEbankReconServiceHelper;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.service.bank.CebEbankService;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.constant.biz.BillnoSnState;
import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.mapper.EAccountClientMapper;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncode;
import com.lycheepay.clearing.adapter.common.model.biz.ChannelRtncodeId;
import com.lycheepay.clearing.adapter.common.model.biz.EAccountClient;
import com.lycheepay.clearing.adapter.common.model.biz.EBankReconReqRecord;
import com.lycheepay.clearing.adapter.common.service.biz.BankTypeInfoService;
import com.lycheepay.clearing.adapter.common.service.biz.BillnoSnService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelParmService;
import com.lycheepay.clearing.adapter.common.service.biz.ChannelRtncodeService;
import com.lycheepay.clearing.adapter.common.service.biz.SequenceManager;
import com.lycheepay.clearing.adapter.common.util.SftpUtil;
import com.lycheepay.clearing.common.constant.BankCardType;
import com.lycheepay.clearing.common.constant.CertificateType;
import com.lycheepay.clearing.common.constant.ChannelId.ChannelIdEnum;
import com.lycheepay.clearing.common.constant.ClearingTransType;
import com.lycheepay.clearing.common.constant.PayState.TxnStatus;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.common.constant.YztTransType;
import com.lycheepay.clearing.common.dto.eaccount.EAccountActivateDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountActivateResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountAllDetailQueryDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountAllDetailResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountAllDetailResultItemDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountBalanceDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountBalanceResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountClearanceDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountClearanceResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountDetailQueryDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountDetailQueryResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountDetailQueryResultDateDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountImgDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountRegisterDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountRegisterResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUnregisterDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUnregisterResultDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUploadImgDTO;
import com.lycheepay.clearing.common.dto.eaccount.EAccountUploadImgResultDTO;
import com.lycheepay.clearing.common.dto.trade.ClearingResultDTO;
import com.lycheepay.clearing.common.dto.trade.DeductDTO;
import com.lycheepay.clearing.common.dto.trade.DirectTradeOffGroundDTO;
import com.lycheepay.clearing.common.dto.trade.PayOutDTO;
import com.lycheepay.clearing.common.model.BankTypeInfo;
import com.lycheepay.clearing.common.model.BillnoSn;
import com.lycheepay.clearing.util.DateUtil;
import com.lycheepay.clearing.util.Log4jUtil;

@Service
public class CebEbankProcessService {

	private final String channelId = ChannelIdEnum.CEB_EBANK_PAY.getCode();
	private final String successCode = "000000";

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_PARM_SERVICE)
	private ChannelParmService channelParamService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.CHANNEL_RTNCODE_SERVICE)
	private ChannelRtncodeService channelRtncodeService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.SEQUENCE_MANAGER_SERVICE)
	private SequenceManager seqService;

	@Autowired
	private EAccountClientMapper clientMapper;

	@Autowired
	private CebEbankService cebEbankService;

	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BILLNO_SN_SERVICE)
	private BillnoSnService billnoSnService;
	
	@Autowired
	@Qualifier(ClearingAdapterAnnotationName.BANK_TYPE_INFO_SERVICE)
	private BankTypeInfoService bankTypeInfoService;

	@Autowired
	private CebEbankReconServiceHelper cebEbankReconServiceHelper;

	/**
	 * 开户
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public EAccountRegisterResultDTO openAccount(EAccountRegisterDTO dto) {
		CebEbankOpenAccountRequestDTO req = new CebEbankOpenAccountRequestDTO();
		EAccountRegisterResultDTO ret = new EAccountRegisterResultDTO();

		req.setBankAcNo(dto.getBankAccountNo());
		req.setBankCardPhoneCode(dto.getBankCardPhoneCode());
		req.setBankCardType(BankCardType.CREDIT_CARD.equals(dto.getBankCardType()) ? "0" : "1");
		
		BankTypeInfo bankTypeInfo = bankTypeInfoService.findById(dto.getBankType());
		
		if(bankTypeInfo==null) {
			ret.setChannelResponseCode(TransReturnCode.code_9900);
			ret.setChannelResponseMsg("不存在的银行编码，暂不支持");
			return ret;
		}
		req.setBankName(bankTypeInfo.getBankTypeName());
		
		req.setCifAddr(dto.getCustAddress());
		req.setCifClientId(dto.getAccountId());
		req.setCifEnName(dto.getCustEngName());
		req.setCifIdExpiredDate(dto.getCustIdExp());
		req.setCifName(dto.getCustName());
		req.setCifPhoneCode(dto.getCustPhone());
		req.setCifPostCode(dto.getCustZipCode());
		req.setIdNo(dto.getCustIdNo());
		req.setIdType(convertIdType(dto.getCustIdType()));
		req.setSubBranchName(dto.getSubBranchName());
		req.setOpenChannel(dto.getOpenChannel());
		req.setNetCheckFlag(dto.getNetCheckFlag());
		
		req.setOperateType("0");// 0开户

		fillHeadInfo(req, CebEbankConstant.STR_REQID_OPENACCOUNT);
		
		try {
			CebEbankOpenAccountResponseDTO resp = cebEbankService.transfer(req, new CebEbankOpenAccountResponseDTO());

			if (isSuccessResponse(resp)) {
				
				/*
				 * 如果成功 则保存到数据库中
				 */
				EAccountClient model = new EAccountClient();
				model.setId(getSequence());
				model.setAccount_id(dto.getAccountId());
				model.setCert_expired_date(dto.getCustIdExp());
				model.setCert_no(dto.getCustIdNo());
				model.setCert_type(dto.getCustIdType());
				model.setCust_address(dto.getCustAddress());
				model.setCust_en_name(dto.getCustEngName());
				model.setCust_name(dto.getCustName());
				model.setCust_post_code(dto.getCustZipCode());
				model.setEbank_account_no(resp.getEAcNo());
				model.setEbank_type(dto.getEbankType());
				model.setMerchant_id(dto.getMerchantId());
				model.setMobile_phone(dto.getCustPhone());
				model.setStatus(CebEbankConstant.STR_ACCOUNT_STATUS_VAILD); //激活
				clientMapper.insert(model);
				
				ret.setChannelResponseCode(TransReturnCode.code_0000);
				ret.setChannelResponseMsg(resp.getResMsg());
				ret.setEbankAccountNo(resp.getEAcNo());
			} else {
				
				/*
				 * 读取数据库返回码
				 */
				ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
						resp.getResCode()));
				if (channelRtncode != null) {
					ret.setChannelResponseCode(channelRtncode.getKftRtncode());
					ret.setChannelResponseMsg(channelRtncode.getChannelReamrk());
				} else {
					ret.setChannelResponseCode(TransReturnCode.code_9900);
					ret.setChannelResponseMsg(resp.getResMsg());
				}
				
				ret.setChannelResponseCode(TransReturnCode.code_9900);
				ret.setChannelResponseMsg(resp.getResMsg());
			}
		} catch (BizException e) {
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		} catch (Exception e) {
			ret.setChannelResponseCode(TransReturnCode.code_9900);
			ret.setChannelResponseMsg(e.getMessage());
		}
		ret.setOrderNo(dto.getOrderNo());
		Log4jUtil.info("[开户返回结果]{}", ret);
		return ret;
	}

	/**
	 * 销户
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public EAccountUnregisterResultDTO closeAccount(EAccountUnregisterDTO dto) {
		CebEbankCloseAccountRequestDTO req = new CebEbankCloseAccountRequestDTO();
		EAccountUnregisterResultDTO ret = new EAccountUnregisterResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getEbankType(), dto.getEbankAccountNo(), dto.getMerchantId());

			req.setCifClientId(model.getAccount_id());

			fillHeadInfo(req, CebEbankConstant.STR_REQID_CLOSEACCOUNT);

			CebEbankCloseAccountResponseDTO resp = cebEbankService.transfer(req, new CebEbankCloseAccountResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				model.setStatus(CebEbankConstant.STR_ACCOUNT_STATUS_INVAILD);
				clientMapper.update(model);
				respCode = TransReturnCode.code_0000;
			}

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}

		ret.setOrderNo(dto.getOrderNo());
		Log4jUtil.info("[销户返回结果]{}", ret);
		return ret;
	}

	/**
	 * 付款 - 电子账户转入
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public ClearingResultDTO payOut(PayOutDTO dto) {
		CebEbankPayOutRequestDTO req = new CebEbankPayOutRequestDTO();
		ClearingResultDTO ret = new ClearingResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getBankType(), dto.getBankCardNo(), dto.getCorpAccountId());

			req.setCifClientId(model.getAccount_id());
			req.setAmount(dto.getAmount().toString());
			req.setCoPatrnerJnlNo(seqService.getCebEbankSendSeq());
			req.setCurrency(CebEbankConstant.STR_TRANS_CURRENCY);
			req.setRemark(dto.getOrderNote());
			req.setTrsDate(DateUtil.getCurrentDate());
			req.setTrsType(CebEbankTransTypeConstant.RECHARGE);

			BillnoSn record = billnoSnService.saveBillnoSn(req.getCoPatrnerJnlNo(), channelId, dto);

			fillHeadInfo(req, CebEbankConstant.STR_REQID_PAYOUT);

			CebEbankPayOutResponseDTO resp = cebEbankService.transfer(req, new CebEbankPayOutResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				record.setActualAmount(new BigDecimal(resp.getAmount()));
				respCode = TransReturnCode.code_0000;
			}

			record.setBankRecvSn(resp.getReserve1());
			record.setOthercustId(resp.getEbankJnlNo());
			ret.setTxnStatus(returnTxnStatus(resp.getResCode()));
			record.setPayState(String.valueOf(ret.getTxnStatus()));

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
			ret.setChannelId(channelId);

			billnoSnService.updateBillnoSn(record, resp.getResCode(), resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setTxnStatus(returnTxnStatus(e.getErrorCode()));
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}

		Log4jUtil.info("[付款返回结果]{}", ret);
		return ret;
	}

	/**
	 * 扣款 - 电子账户转出-归集转出
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public ClearingResultDTO deduct(DeductDTO dto) {
		CebEbankOffGroundRequestDTO req = new CebEbankOffGroundRequestDTO();
		ClearingResultDTO ret = new ClearingResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getBankType(), dto.getBankCardNo(), dto.getCorpAccountId());

			req.setTransOutType("2");// 归集
			req.setCifClientId(model.getAccount_id());
			req.setAmount(dto.getAmount().toString());
			req.setCoPatrnerJnlNo(seqService.getCebEbankSendSeq());
			req.setCurrency(CebEbankConstant.STR_TRANS_CURRENCY);
			req.setRemark(dto.getOrderNote());
			req.setTrsDate(DateUtil.getCurrentDate());
			req.setTrsType(CebEbankTransTypeConstant.CONSUMPTION);

			BillnoSn record = billnoSnService.saveBillnoSn(req.getCoPatrnerJnlNo(), channelId, dto);

			fillHeadInfo(req, CebEbankConstant.STR_REQID_OFFGROUND);

			CebEbankOffGroundResponseDTO resp = cebEbankService.transfer(req, new CebEbankOffGroundResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				record.setActualAmount(new BigDecimal(resp.getAmount()));
				record.setOtheracctname(resp.getCifName());
				respCode = TransReturnCode.code_0000;
			}

			record.setBankRecvSn(resp.getReserve1());
			ret.setTxnStatus(returnTxnStatus(resp.getResCode()));
			record.setPayState(String.valueOf(ret.getTxnStatus()));

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
			ret.setChannelId(channelId);

			billnoSnService.updateBillnoSn(record, resp.getResCode(), resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setTxnStatus(returnTxnStatus(e.getErrorCode()));
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		Log4jUtil.info("[不落地返回结果]{}", ret);
		return ret;
	}

	/**
	 * 不落地 - 电子账户转出-定向转出
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public ClearingResultDTO offGround(DirectTradeOffGroundDTO dto) {
		CebEbankOffGroundRequestDTO req = new CebEbankOffGroundRequestDTO();
		ClearingResultDTO ret = new ClearingResultDTO();

		try
		{
			//Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
			
			EAccountClient model = findEAccountClient(dto.getPayerBankType(), dto.getPayerBankCardNo(), dto.getCorpAccountId());
			req.setTransOutType("1");// 定向

			Map<String, String> subMerchantInfo = clientMapper.selectSubMerchantCode(dto.getPayeeBankType(), dto.getPayeeBankCardNo());
			if (subMerchantInfo == null || subMerchantInfo.size() == 0)
				throw new BizException(BusinessCode.FAILED_TO_FIND_CHANNEL_SERVICE_INFO, "定向转出未找到二级商户编号");

			Log4jUtil.info("定向转出加载二级商户信息：{}", subMerchantInfo);

			req.setSubMerchant(subMerchantInfo.get("SUBMERCHANT_CODE"));
			req.setGatherName(subMerchantInfo.get("BANK_NAME"));
			req.setGatherAcNo(dto.getPayeeBankCardNo());
			req.setCifClientId(model.getAccount_id());
			req.setAmount(dto.getAmount().toString());
			req.setCoPatrnerJnlNo(seqService.getCebEbankSendSeq());
			req.setCurrency(CebEbankConstant.STR_TRANS_CURRENCY);
			req.setRemark(dto.getOrderNote());
			req.setTrsDate(DateUtil.getCurrentDate());
			req.setTrsType(CebEbankTransTypeConstant.CONSUMPTION);

			BillnoSn record = billnoSnService.saveBillnoSn(req.getCoPatrnerJnlNo(), channelId, dto);

			fillHeadInfo(req, CebEbankConstant.STR_REQID_OFFGROUND);

			CebEbankOffGroundResponseDTO resp = cebEbankService.transfer(req, new CebEbankOffGroundResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				record.setActualAmount(new BigDecimal(resp.getAmount()));
				record.setOtheracctname(resp.getCifName());
				respCode = TransReturnCode.code_0000;
			}

			record.setBankRecvSn(resp.getReserve1());
			ret.setTxnStatus(returnTxnStatus(resp.getResCode()));
			record.setPayState(String.valueOf(ret.getTxnStatus()));

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
			ret.setChannelId(channelId);

			billnoSnService.updateBillnoSn(record, resp.getResCode(), resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setTxnStatus(returnTxnStatus(e.getErrorCode()));
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		Log4jUtil.info("[不落地返回结果]{}", ret);
		return ret;
	}

	/**
	 * 结息
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public EAccountClearanceResultDTO clearance(EAccountClearanceDTO dto) {
		CebEbankClearanceRequestDTO req = new CebEbankClearanceRequestDTO();
		EAccountClearanceResultDTO ret = new EAccountClearanceResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getBankType(), dto.getBankCardNo(), dto.getCorpAccountId());

			req.setCifClientId(model.getAccount_id());
			req.setChannelSeq(seqService.getCebEbankSendSeq());

			BillnoSn record = billnoSnService.saveBillnoSn(req.getChannelSeq(), channelId, dto);

			fillHeadInfo(req, CebEbankConstant.STR_REQID_CLEARANCE);

			CebEbankClearanceResponseDTO resp = cebEbankService.transfer(req, new CebEbankClearanceResponseDTO());
			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				ret.setAmount(new BigDecimal(resp.getAmount()));
				ret.setInterest(new BigDecimal(resp.getInterest()));
				ret.setCurrency(resp.getCurrency());
				// 响应分别返回金额和利息，保存记录里为总金额。
				BigDecimal amount = new BigDecimal(resp.getAmount());
				amount = amount.add(new BigDecimal(resp.getInterest()));
				record.setAmount(amount);
				record.setActualAmount(amount);
				respCode = TransReturnCode.code_0000;
			}

			record.setBankRecvSn(resp.getChannelSeq());
			ret.setTxnStatus(returnTxnStatus(resp.getResCode()));
			record.setPayState(String.valueOf(ret.getTxnStatus()));

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());

			billnoSnService.updateBillnoSn(record, resp.getResCode(), resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setTxnStatus(returnTxnStatus(e.getErrorCode()));
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		Log4jUtil.info("[结息返回结果]{}", ret);
		return ret;
	}

	/**
	 * 余额
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public EAccountBalanceResultDTO balance(EAccountBalanceDTO dto) {
		CebEbankBalanceRequestDTO req = new CebEbankBalanceRequestDTO();
		EAccountBalanceResultDTO ret = new EAccountBalanceResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getEbankType(), dto.getEbankAccountNo(), dto.getMerchantId());

			req.setCifClientId(model.getAccount_id());

			fillHeadInfo(req, CebEbankConstant.STR_REQID_BALANCE);

			CebEbankBalanceResponseDTO resp = cebEbankService.transfer(req, new CebEbankBalanceResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				ret.setAvailBanlace(new BigDecimal(resp.getAvailBlance()));
				ret.setBalance(new BigDecimal(resp.getAcNoBlance()));
				ret.setCurrency(resp.getCurrency());
				respCode = TransReturnCode.code_0000;
			}

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
			ret.setOrderNo(dto.getOrderNo());
		}
		catch (BizException e)
		{
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		Log4jUtil.info("[余额返回结果]{}", ret);
		return ret;
	}

	/**
	 * 上传
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public EAccountUploadImgResultDTO uploadImage(EAccountUploadImgDTO dto) {
		CebEbankUploadImgRequestDTO req = new CebEbankUploadImgRequestDTO();
		EAccountUploadImgResultDTO ret = new EAccountUploadImgResultDTO();
		String currentDateTime = DateUtil.getCurrentDateTime();
		String dataFileName = String.format("P_%s", currentDateTime);
		String indexFileName = String.format("I_%s", currentDateTime);

		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		try
		{
			// 保存关系
			ArrayList<EAccountImgDTO> all = new ArrayList<EAccountImgDTO>();
			// 保存文件列表
			ArrayList<String> files = new ArrayList<String>();

			// 处理
			for (EAccountImgDTO img : dto.getList())
			{
				all.add(img);
				files.add(img.getIdHeadsPicPath());
				files.add(img.getIdTailsPicPath());
			}

			// 路径
			String dataPath = getTempPath(params.get(CebEbankConstant.PARM_SYS_TEMP_PATH), dataFileName, "zip");
			String listPath = getTempPath(params.get(CebEbankConstant.PARM_SYS_TEMP_PATH), indexFileName, "txt");
			String okPath = getTempPath(params.get(CebEbankConstant.PARM_SYS_TEMP_PATH), indexFileName, "ok");
			Log4jUtil.info("[影像文件上传压缩渠道包]:{}-{}-{}", dataPath, listPath, okPath);

			// 打包
			String userID = params.get(CebEbankConstant.PARM_VAR_USERID);
			zipMultiFile(files.toArray(new String[files.size()]), dataPath, userID);

			// 清单
			ByteArrayOutputStream bout = new ByteArrayOutputStream();

			FileOutputStream fout = new FileOutputStream(listPath);
			PrintWriter writer = new PrintWriter(bout);
			writer.print(all.size());
			writer.print('|');
			writer.print(userID);
			writer.print('|');
			for (int i = 0; i < all.size(); i++)
			{
				EAccountImgDTO item = all.get(i);
				writer.println();
				writer.print(item.getAccountId());
				writer.print('|');
				writer.print(loadGDFileName(userID, item.getIdHeadsPicPath()));
				writer.print('|');
				writer.print(loadGDFileName(userID, item.getIdTailsPicPath()));
				writer.print('|');
			}
			writer.close();
			bout.writeTo(fout);
			fout.close();

			// 交互
			req.setFileName(getTempPath("", dataFileName, "zip"));
			req.setIndexFileName(getTempPath("", indexFileName, "txt"));
			req.setFilePath(params.get(CebEbankConstant.PARM_SYS_FILE_PATH));
			req.setLoginID(params.get(CebEbankConstant.PARM_SYS_SFTP_USER));
			req.setPassWord(params.get(CebEbankConstant.PARM_SYS_SFTP_PWD));
			req.setPortCode(params.get(CebEbankConstant.PARM_SYS_SFTP_PORT_OUT));
			req.setServerIp(params.get(CebEbankConstant.PARM_SYS_SFTP_IP_OUT));
			req.setSignForIdCard(cebEbankService.sign(bout.toByteArray()));
			req.setTrsType("S");// S:SFTP

			fillHeadInfo(req, CebEbankConstant.STR_UPLOAD_IMAGE);

			CebEbankUploadImgResponseDTO resp = cebEbankService.transfer(req, new CebEbankUploadImgResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				respCode = TransReturnCode.code_0000;

				// OK文件
				createOKFile(okPath, resp.getItem("SignForIdCard"));

				// 上传到服务器
				uploadFile2SFTP(dataPath, listPath, okPath);
			}

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
			ret.setOrderNo(dto.getOrderNo());

		}
		catch (BizException e)
		{
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
			Log4jUtil.error("[影像文件上报-异常]{}:{}", e);
		}
		catch (IOException e)
		{
			ret.setChannelResponseCode(TransReturnCode.code_9109);
			ret.setChannelResponseMsg(e.getMessage());
			Log4jUtil.error("[影像文件上报-异常]{}:{}", e);
		}
		return ret;
	}

	private void createOKFile(String fileName, String Content) throws IOException {
		Log4jUtil.info("[影像文件上报-生成OK文件]{}:{}", fileName, Content);
		FileOutputStream fout = null;
		PrintWriter writer = null;
		try
		{
			fout = new FileOutputStream(fileName);
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			writer = new PrintWriter(bout);
			writer.print(Content);

			writer.flush();
			bout.writeTo(fout);
		}
		catch (Exception ex)
		{
			Log4jUtil.error("[影像文件上报-生成OK文件]--异常", ex);
		}
		finally
		{
			if (writer != null)
				writer.close();
			if (fout != null)
				fout.close();
		}
	}

	private String loadGDFileName(String userID, String filePath) {
		int start = filePath.indexOf("cert/") + 5;
		int end = filePath.indexOf("/", start);
		File file = new File(filePath);

		return String.format("%s_%s_%s", userID, filePath.substring(start, end), file.getName());
	}

	private void zipMultiFile(String[] filepath, String zippath, String userID) throws IOException {

		File zipFile = new File(zippath);
		InputStream input = null;
		ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(zipFile));
		for (int i = 0; i < filepath.length; i++)
		{
			String fp = filepath[i];
			File file = new File(fp);
			if (file.isFile())
			{
				input = new FileInputStream(file);
				zipOut.putNextEntry(new ZipEntry(loadGDFileName(userID, fp)));
				int filesize = input.available();
				int count = 0;
				while (filesize > count)
				{
					byte[] b = new byte[1024];
					int c = input.read(b);
					zipOut.write(b, 0, c);
					count += c;
				}
				input.close();
			}
		}

		zipOut.close();
		Log4jUtil.info("[影像文件上传压缩渠道包]:{}", zippath);
	}

	/**
	 * @param dto
	 *            电子账户查询dto
	 * @return EaDqr 电子账户查询响应结果dto
	 * @author 杨开宇
	 * @throws Exception
	 */
	public EAccountDetailQueryResultDTO queryTradeDetail(EAccountDetailQueryDTO dto) {
		Log4jUtil.info("...............光大查询电子账户明细开始....................");
		Log4jUtil.info("[查询光大电子账户明细:入参]{}", dto);

		CebEbankTradeDetailQueryRequestDTO adqReq = new CebEbankTradeDetailQueryRequestDTO();
		EAccountDetailQueryResultDTO eaDqr = new EAccountDetailQueryResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getEbankType(), dto.getEbankAccountNo(), dto.getMerchantId());

			adqReq.setBeginDate(dto.getBeginDate()); // 起始日期
			adqReq.setCifClientId(model.getAccount_id()); // 接入方客户标识号
			adqReq.setCurrency(dto.getCurrency()); // 币种
			adqReq.setEndDate(dto.getEndDate()); // 终止日期
			adqReq.setItemNum(dto.getItemNum()); // 每页显示的笔数
			adqReq.setStartItem(dto.getStartItem()); // 查询起始笔数
			adqReq.setTrsType(transferCebTransType(dto.getBizTransType())); // 交易类型

			fillHeadInfo(adqReq, CebEbankConstant.STR_REQID_DETAIL);
			Log4jUtil.info("[光大电子账户明细查询接口请求参数:]{}" + adqReq);

			CebEbankTradeDetailQueryResponseDTO adqResp = cebEbankService.transfer(adqReq, new CebEbankTradeDetailQueryResponseDTO());

			String respCode = adqResp.getResCode();

			Log4jUtil.info("[光大电子账户明细查询接口响应参数:]{}" + adqResp);

			if (isSuccessResponse(adqResp))
			{// 如果请求响应成功
				// 得到光大账户明细查询返回的
				eaDqr.setTotalNum(adqResp.getTotNum()); // 明细查询结果总记录数
				eaDqr.setReturnNum(adqResp.getRetNum()); // 明细查询结果本次记录数
				List<Map<String, String>> resultList = adqResp.getList(); // 明细查询结果中的list

				List<EAccountDetailQueryResultDateDTO> list = new ArrayList<EAccountDetailQueryResultDateDTO>();
				if (resultList != null && resultList.size() > 0)
				{
					for (Map<String, String> resultMap : resultList)
					{
						EAccountDetailQueryResultDateDTO dqr = new EAccountDetailQueryResultDateDTO();
						dqr.setSeqNo(resultMap.get("CoPatrnerJnlNo")); // 渠道流水号
						dqr.setTransTime(resultMap.get("TrsTime")); // 交易时间
						dqr.setBalance(new BigDecimal(resultMap.get("AcNoBlance"))); // 交易后余额
						dqr.setAmount(new BigDecimal(resultMap.get("Amount"))); // 交易金额
						dqr.setCurrency(resultMap.get("Currency")); // 币种
						dqr.setTransType(transferTransType(resultMap.get("TrsType"))); // 交易类型
						dqr.setTransDate(resultMap.get("TrsDate")); // 交易日期
						dqr.setRemark(resultMap.get("Remark")); // 摘要
						dqr.setDirection(convertDirection(resultMap.get("CreOrDeb"))); // 交易方向
						list.add(dqr);
					}
					eaDqr.setData(list); // 明细查询结果中的详情list

				}
				respCode = TransReturnCode.code_0000;
			}
			eaDqr.setChannelResponseCode(respCode);
			eaDqr.setChannelResponseMsg(adqResp.getResMsg());
		}
		catch (BizException e)
		{
			eaDqr.setChannelResponseCode(e.getErrorCode());
			eaDqr.setChannelResponseMsg(e.getMessage());
		}

		Log4jUtil.info("[光大电子账户明细查询接口返回对象:]{}" + eaDqr);
		return eaDqr;
	}

	/**
	 * 所有明细查询
	 * 
	 * @author 王瑞
	 * @param dto
	 * @return
	 */
	public EAccountAllDetailResultDTO queryAccountDetail(EAccountAllDetailQueryDTO dto) {
		CebEbankAccountDetailRequestDTO req = new CebEbankAccountDetailRequestDTO();
		EAccountAllDetailResultDTO ret = new EAccountAllDetailResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getEbankType(), dto.getEbankAccountNo(), dto.getMerchantId());

			req.setBeginDate(dto.getBeginDate()); // 起始日期
			req.setCifClientId(model.getAccount_id()); // 接入方客户标识号
			req.setCurrency(dto.getCurrency()); // 币种
			req.setEndDate(dto.getEndDate()); // 终止日期
			req.setItemNum(dto.getItemNum()); // 每页显示的笔数
			req.setStartItem(dto.getStartItem()); // 查询起始笔数

			fillHeadInfo(req, CebEbankConstant.STR_REQID_RECORD);

			CebEbankAccountDetailResponseDTO resp = cebEbankService.transfer(req, new CebEbankAccountDetailResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{// 如果请求响应成功
				// 得到光大账户明细查询返回的
				ret.setTotalNum(resp.getTotNum()); // 明细查询结果总记录数
				ret.setReturnNum(resp.getRetNum()); // 明细查询结果本次记录数
				List<Map<String, String>> resultList = resp.getList(); // 明细查询结果中的list

				List<EAccountAllDetailResultItemDTO> list = new ArrayList<EAccountAllDetailResultItemDTO>();
				if (resultList != null && resultList.size() > 0)
				{
					EAccountAllDetailResultItemDTO item;
					Map<String, String> bankCoreMapper = loadTradeIDMapper(resultList);
					String kftBankTradeId;

					for (Map<String, String> resultMap : resultList)
					{
						// 通过银行核心流水转化成快付通交易ID
						kftBankTradeId = bankCoreMapper.get(resultMap.get("Reserve1"));
						item = new EAccountAllDetailResultItemDTO();
						item.setTradeId(kftBankTradeId);
						item.setBankCoreNo(resultMap.get("Reserve1"));

						// 如果快付通交易ID不为空则表示交易时通过接口发起的，对手方信息为快付通则不行透传，否则需要透传对手方信息
						if (StringUtils.isEmpty(kftBankTradeId))
						{
							item.setHolderNo(resultMap.get("Reserve2"));
							item.setHolderName(resultMap.get("Reserve3"));
						}

						item.setBankCardType(BankCardType.EACCOUNT);
						item.seteAccountNo(resultMap.get("AcNo")); // 账号
						item.setTransTime(resultMap.get("TrsTime")); // 交易时间
						item.setBalance(new BigDecimal(resultMap.get("Balance"))); // 交易后余额

						item.setInAmount(formatAmount(resultMap.get("TrsInAmount")));// 收入金额
						item.setOutAmount(formatAmount(resultMap.get("TrsOutAmount"))); // 支出金额
						item.setRemark(resultMap.get("Remark")); // 摘要
						list.add(item);
					}
					ret.setData(list); // 明细查询结果中的详情list
				}

				ret.setStatus(1);
				respCode = TransReturnCode.code_0000;
			}
			else
			{
				ret.setStatus(2);
			}
			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setStatus(2);
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		return ret;
	}

	private BigDecimal formatAmount(String amount) {
		if (StringUtils.isEmpty(amount))
			return null;

		return new BigDecimal(amount.replaceAll(",", "").trim());
	}

	/**
	 * 请求生成对账文件 根据银行返回的交易记录中的银行核心流水，转换成KFT银行的交易ID
	 * 
	 * @param bankResultList
	 * @return
	 */
	public Map<String, String> loadTradeIDMapper(List<Map<String, String>> bankResultList) {

		List<String> bankCoreNos = new ArrayList<String>(bankResultList.size());
		for (Map<String, String> bankResult : bankResultList)
		{
			bankCoreNos.add(bankResult.get("Reserve1"));
		}

		return billnoSnService.loadBankCoreSNMapper(channelId, bankCoreNos);
	}

	/**
	 * 下载对账文件
	 * 
	 * @author 王瑞
	 * @param dto
	 *            只需要传入QryDate属性
	 * @return
	 */
	public CebEbankObtainReconciliactionResponseDTO queryReconFile(CebEbankObtainReconciliationRequestDTO req,
			EBankReconReqRecord inserRecord) {
		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		CebEbankObtainReconciliactionResponseDTO resp = new CebEbankObtainReconciliactionResponseDTO();

		try
		{
			req.setServiceId(CebEbankConstant.STR_SERVICEID_RECON);

			fillHeadInfo(req, CebEbankConstant.STR_REQID_RECON);
			insertRecord(req, inserRecord);

			resp = cebEbankService.transfer(req, resp);

			// downloadFile2SFTP(resp.getFileName());//resp.getFilePath()无作用

			resp.setFilePath(params.get(CebEbankConstant.PARM_SYS_TEMP_PATH));

		}
		catch (BizException e)
		{
			resp.setResCode(e.getErrorCode());
			resp.setResMsg(e.getMessage());
		}
		return resp;
	}

	private void insertRecord(final CebEbankObtainReconciliationRequestDTO req, EBankReconReqRecord inserRecord) {
		inserRecord.setServiceId(req.getServiceId());
		inserRecord.setQryDate(req.getQryDate());
		inserRecord.setReqId(req.getReqId());
		inserRecord.setReqJnlNo(req.getReqJnlNo());
		inserRecord.setReqTime(req.getReqTime());
		inserRecord.setUserId(req.getUserId());
		inserRecord.setStatus((short) CebEbankConstant.EBANK_RECON_FILE_STATUS_WAITING);
		inserRecord.setCreateDate(new Date());
		cebEbankReconServiceHelper.insertSelective(inserRecord);
	}

	/**
	 * 光大交易类型转化为内部类型(in)
	 * 
	 * @param type
	 *            光大交易类型
	 * @author 杨开宇
	 * @return
	 * @throws BizException
	 */
	private String transferTransType(String cebType) throws BizException {
		switch (cebType)
		{
			case CebEbankTransTypeConstant.RECHARGE:
				return YztTransType.RECHARGE;
			case CebEbankTransTypeConstant.WITHDRAWALS:
				return YztTransType.WITHDRAWALS;
			case CebEbankTransTypeConstant.REBATE_T0:
			case CebEbankTransTypeConstant.REBATE_T1:
				return YztTransType.GIFT;
			case CebEbankTransTypeConstant.WHOLE:
				return YztTransType.WHOLE;
			case CebEbankTransTypeConstant.REFUND:
			case CebEbankTransTypeConstant.CONSUMPTION:
				return YztTransType.OTHER;
			default:
				throw new BizException(TransReturnCode.code_9900, "不支持此交易类型！");
		}
	}

	/**
	 * 转换为光大交易类型(out)
	 * 
	 * @author 杨开宇
	 * @param YztTransType
	 *            我们系统中交易类型
	 * @throws BizException
	 */
	public String transferCebTransType(String TranType) throws BizException {
		switch (TranType)
		{
			case YztTransType.WHOLE:
				return CebEbankTransTypeConstant.WHOLE;
			case YztTransType.WITHDRAWALS:
				return CebEbankTransTypeConstant.WITHDRAWALS;
			case YztTransType.RECHARGE:
				return CebEbankTransTypeConstant.RECHARGE;
			default:
				throw new BizException(TransReturnCode.code_9900, "不支持此交易类型");
		}
	}

	/**
	 * 用来向光大查询交易处理方法
	 */
	public ClearingResultDTO getQueryTradeState(BillnoSn billnoSn) {
		Log4jUtil.setLogClass("CEB", "CebEbankProcessService");
		Log4jUtil.info("[getQueryTradeStat:入参]{}", billnoSn);
		String channelId = ChannelIdEnum.CEB_EBANK_PAY.getCode();
		ClearingResultDTO resultDTO = new ClearingResultDTO();

		try
		{
			CebEbankTradeDetailRequestDTO req = new CebEbankTradeDetailRequestDTO();
			req.setCoPatrnerJnlNo(billnoSn.getBankSendSn());
			req.setTrsDate(billnoSn.getTranDate());
			req.setReserve1(null);
			req.setReserve2(null);
			// req.setReserve3(null);
			// req.setReserve4(null);
			// req.setReserve5(null);
			fillHeadInfo(req, CebEbankConstant.STR_REQID_QUERY_JNL);
			Log4jUtil.info("[getQueryTradeStat:req]{}", req.toString());
			CebEbankTradeDetailResponseDTO resp = new CebEbankTradeDetailResponseDTO();
			resp = cebEbankService.transfer(req, resp);

			Log4jUtil.info("[getQueryTradeStat:resp]{}", resp.toString());

			resultDTO.setChannelId(channelId);

			BillnoSn updateBillnoSn = new BillnoSn();
			// 000212 交易不存在
			if ("000212".equals(resp.getResCode()))
			{
				resultDTO.setTxnStatus(String.valueOf(TxnStatus.FAILED));
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelResponseMsg("交易不存在");
				updateBillnoSn(billnoSn, resultDTO, updateBillnoSn);
				return resultDTO;
			}
			// TrsState：交易状态（0：成功、1：失败、2：未明 3:超出查证时间范围）
			else if ("0".equals(resp.getTrsState()))
			{
				resultDTO.setTxnStatus(String.valueOf(TxnStatus.SUCCEED));
				resultDTO.setChannelResponseCode(TransReturnCode.code_0000);
				resultDTO.setChannelResponseMsg("交易成功");
			}
			else if ("1".equals(resp.getTrsState()))
			{
				resultDTO.setTxnStatus(String.valueOf(TxnStatus.FAILED));
				resultDTO.setChannelResponseCode(TransReturnCode.code_9900);
				resultDTO.setChannelResponseMsg("交易失败");
			}
			else
			{
				resultDTO.setTxnStatus(TxnStatus.UNKNOW);
				resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
				resultDTO.setChannelResponseMsg("未知");
			}

			if (resultDTO.getTxnStatus() != TxnStatus.UNKNOW && StringUtils.isNotBlank(resp.getReserve1()))
			{// 未知状态时记录不作修改

				updateBillnoSn.setBankRecvSn(resp.getReserve1());

				updateBillnoSn(billnoSn, resultDTO, updateBillnoSn);
			}
		}
		catch (Exception ex)
		{
			Log4jUtil.error("[getQueryTradeStat:error", ex);
			resultDTO.setChannelResponseCode(TransReturnCode.code_9109);
			resultDTO.setChannelResponseMsg(ex.getMessage());
		}
		Log4jUtil.info("[getQueryTradeStat:Return]{}", resultDTO);
		return resultDTO;
	}

	private void updateBillnoSn(BillnoSn billnoSn, ClearingResultDTO resultDTO, BillnoSn updateBillnoSn) {
		updateBillnoSn.setBillnosnSeq(billnoSn.getBillnosnSeq());
		updateBillnoSn.setRecvTime(new Date());
		updateBillnoSn.setState(BillnoSnState.billnoRecv);
		updateBillnoSn.setPayState(String.valueOf(resultDTO.getTxnStatus()));
		billnoSnService.update(updateBillnoSn);
		Log4jUtil.info("[getQueryTradeStat:DB]{}", updateBillnoSn);
	}

	/**
	 * 用于填充报文头信息的公共方法
	 * 
	 * @author 王瑞
	 * @param dto
	 *            需要填充的请求DTO
	 * @param reqID
	 *            从CebEbankConstant中选择STR_REQID前缀的服务类型
	 */
	private void fillHeadInfo(CebEbankRequestDTO dto, String reqID) {
		Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dto.setReqId(reqID);
		dto.setReqJnlNo(seqService.getCebEbankSendSeq());
		dto.setReqTime(sdf.format(new Date()));
		dto.setUserId(params.get(CebEbankConstant.PARM_VAR_USERID));
	}

	/**
	 * 查询电子账户映射关系
	 * 
	 * @author 王瑞
	 * @param bankType
	 *            行别
	 * @param accountNo
	 *            账号
	 * @param merchantID
	 *            商户号
	 * @return 返回映射关系实体，查找不到为NULL
	 * @throws BizException
	 */
	private EAccountClient findEAccountClient(String bankType, String accountNo, String merchantID) throws BizException {
		EAccountClient client = new EAccountClient();
		client.setEbank_type(bankType);
		client.setEbank_account_no(accountNo);
		client.setMerchant_id(merchantID);
		client = clientMapper.selectByAccount(client);
		if (client == null)
		{
			throw new BizException(TransReturnCode.code_9900, "无此电子账户对应的客户资料");
		}
		else
		{
			return client;
		}
	}

	/**
	 * 转换为光大的证件类型
	 * 
	 * @author 王瑞
	 * @param idType
	 *            CertificateType中的证件类型
	 * @return
	 */
	private String convertIdType(String idType) {
		switch (idType)
		{
			case CertificateType.IDENTITY_CARD:
				return "P00";
			default:
				// 目前只支持身份证
				return "P00";
		}
	}

	/**
	 * 判断光大的响应头是否为成功
	 * 
	 * @author 王瑞
	 * @param resp
	 *            光大响应实体
	 * @return
	 */
	private boolean isSuccessResponse(CebEbankResponseDTO resp) {
		return successCode.equals(resp.getResCode());
	}

	/**
	 * 判断响应码状态返回失败或未知状态
	 * 
	 * @author 王瑞
	 * @param respCode
	 *            响应码
	 * @return
	 */
	private int returnTxnStatus(String respCode) {
		switch (respCode)
		{
			case successCode:// 成功
				return TxnStatus.SUCCEED;
			case "KFTSYS_CHANNEL_00009109":// 内部处理错误或超时
			case "000260":// 交易未明
			case "000002":// 交易超时
				return TxnStatus.UNKNOW;
			default:// 失败
				return TxnStatus.FAILED;
		}
	}

	/**
	 * 生成一个时间+序列的字符串
	 * 
	 * @author 王瑞
	 * @return
	 */
	private String getSequence() {
		StringBuilder sb = new StringBuilder();
		sb.append(seqService.getCebEbankSendSeq());
		sb.delete(0, 14);
		sb.insert(0, new Date().getTime());
		return sb.toString();
	}

	/**
	 * 生成临时文件路径
	 * 
	 * @author 王瑞
	 * @return
	 */
	private String getTempPath(String dir, String name, String fix) {
		StringBuilder sb = new StringBuilder();
		sb.append(dir);
		sb.append(name);
		sb.append('.');
		sb.append(fix);
		return sb.toString();
	}

	/**
	 * 上传SFTP
	 * 
	 * @author 王瑞
	 * @param filePath
	 *            本地文件路径
	 * @throws BizException
	 */
	private void uploadFile2SFTP(String... filePath) throws BizException {
		try
		{
			Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
			SftpUtil sf = new SftpUtil(params.get(CebEbankConstant.PARM_SYS_SFTP_IP_IN), params.get(CebEbankConstant.PARM_SYS_SFTP_USER),
					params.get(CebEbankConstant.PARM_SYS_SFTP_PWD), Integer.parseInt(params.get(CebEbankConstant.PARM_SYS_SFTP_PORT_IN)));
			ChannelSftp sftp = sf.connectByPasswd();
			Log4jUtil.info("--Sftp服务器上行目录：{}", params.get(CebEbankConstant.PARM_SYS_FILE_PATH));
			for (String filepath : filePath)
			{
				Log4jUtil.info("--发送文件本地路径：{} ", filepath);
				sf.upload(params.get(CebEbankConstant.PARM_SYS_FILE_PATH), filepath, sftp);
			}
			sf.disconnect(sftp);
			Log4jUtil.info("--文件已上传到服务器");
		}
		catch (Exception e)
		{
			Log4jUtil.error("--文件上传发生错误");
			throw new BizException(e, TransReturnCode.code_9109, "SFTP异常");
		}
	}

	/**
	 * 下载SFTP
	 * 
	 * @author 王瑞
	 * @param filePath
	 *            远程文件路径
	 * @throws BizException
	 */
	public void downloadFile2SFTP(String... filePath) throws BizException {
		try
		{
			Map<String, String> params = channelParamService.queryCodeParamsMapByChannelId(channelId);
			SftpUtil sf = new SftpUtil(params.get(CebEbankConstant.PARM_SYS_SFTP_IP_IN), params.get(CebEbankConstant.PARM_SYS_SFTP_USER),
					params.get(CebEbankConstant.PARM_SYS_SFTP_PWD), Integer.parseInt(params.get(CebEbankConstant.PARM_SYS_SFTP_PORT_IN)));
			ChannelSftp sftp = sf.connectByPasswd();
			Log4jUtil.info("--Sftp服务器下行目录：{}", params.get(CebEbankConstant.PARM_SYS_TEMP_PATH));
			for (String filepath : filePath)
			{
				Log4jUtil.info("--接收文件远程文件名：{} ", filepath);
				int last = filepath.lastIndexOf(File.separator);
				String path = null;
				String name = null;
				if (last > 0)
				{
					path = filepath.substring(0, last);
					name = filepath.substring(last + 1);
				}
				else
				{
					path = "." + File.separator;
					name = filepath;
				}
				sf.download(params.get(CebEbankConstant.PARM_SYS_FILE_PATH), name, params.get(CebEbankConstant.PARM_SYS_TEMP_PATH) + name,
						sftp);
				Log4jUtil.info("--文件已下载到服务器:" + path);
			}
			sf.disconnect(sftp);
		}
		catch (Exception e)
		{
			Log4jUtil.error("--文件下载发生错误", e);
			throw new BizException(e, TransReturnCode.code_9109, "SFTP异常");
		}
	}

	private String convertDirection(String CreOrDeb) throws BizException {
		if (CebEbankConstant.STR_DIRECTION_DEB.equals(CreOrDeb))
		{
			return ClearingTransType.REAL_TIME_PAY;
		}
		else if (CebEbankConstant.STR_DIRECTION_CRE.equals(CreOrDeb))
		{
			return ClearingTransType.REAL_TIME_DEDUCT;
		}
		else
		{
			throw new BizException(TransReturnCode.code_9900, "未知的交易方向");
		}
	}

	/**
	 * 普通提现，遗留代码
	 * 
	 * @param dto
	 * @return
	 */
	public ClearingResultDTO withdraw(DeductDTO dto) {
		CebEbankDeductRequestDTO req = new CebEbankDeductRequestDTO();
		ClearingResultDTO ret = new ClearingResultDTO();

		try
		{
			EAccountClient model = findEAccountClient(dto.getBankType(), dto.getBankCardNo(), dto.getCorpAccountId());

			req.setCifClientId(model.getAccount_id());
			req.setAmount(dto.getAmount().toString());
			req.setChannelSeq(seqService.getCebEbankSendSeq());
			req.setCurrency(CebEbankConstant.STR_TRANS_CURRENCY);
			req.setRemark(dto.getOrderNote());
			req.setTrsDate(DateUtil.getCurrentDate());
			req.setWDType("0");// 0对公账户

			BillnoSn record = billnoSnService.saveBillnoSn(req.getChannelSeq(), channelId, dto);

			fillHeadInfo(req, CebEbankConstant.STR_REQID_DEDUCT);

			CebEbankDeductResponseDTO resp = cebEbankService.transfer(req, new CebEbankDeductResponseDTO());

			String respCode = resp.getResCode();

			if (isSuccessResponse(resp))
			{
				record.setActualAmount(new BigDecimal(resp.getAmount()));
				record.setOtheracctname(resp.getCifName());
				respCode = TransReturnCode.code_0000;
			}

			record.setBankRecvSn(resp.getChannelSeq());
			ret.setTxnStatus(returnTxnStatus(resp.getResCode()));
			record.setPayState(String.valueOf(ret.getTxnStatus()));

			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
			ret.setChannelId(channelId);

			billnoSnService.updateBillnoSn(record, resp.getResCode(), resp.getResMsg());
		}
		catch (BizException e)
		{
			ret.setTxnStatus(returnTxnStatus(e.getErrorCode()));
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		Log4jUtil.info("[收款返回结果]{}", ret);
		return ret;
	}

	/**
	 * <p>认证激活账户</p>
	 * @param dto
	 * @return
	 */
	public EAccountActivateResultDTO activateAccount(EAccountActivateDTO dto) {
		CebEbankActivateAccountRequestDTO req = new CebEbankActivateAccountRequestDTO();
		EAccountActivateResultDTO ret = new EAccountActivateResultDTO();

		/*
		 * 设置激活参数
		 */
		req.setBusinessType("2");
		req.setCheckResult("0");
		req.setCifClientId(dto.getAccountId());
		req.setCifName(dto.getCustName());
		req.setIdNo(dto.getCustIdNo());
		req.setIdType(convertIdType(dto.getCustIdType()));
		fillHeadInfo(req, CebEbankConstant.STR_REQID_ACTIVATEACCOUNT);

		try {
			
			//执行
			CebEbankActivateAccountResponseDTO resp = cebEbankService.transfer(req, new CebEbankActivateAccountResponseDTO());

			String respCode = resp.getResCode();

			EAccountClient model = new EAccountClient();
			model.setAccount_id(dto.getAccountId());
			model.setEbank_account_no(dto.getEbankAccountNo());
			model.setEbank_type(dto.getEbankType());
			
			/*
			 * 如果返回结果真确 且表示激活或不需要激活
			 * 则修改数据库对应数据未 激活状态
			 */
			if (isSuccessResponse(resp)
					&& (CebEbankConstant.DEAL_RESULT_ACTIVATE.equals(resp.getDealResult()) || CebEbankConstant.DEAL_RESULT_SUCCESS
							.equals(resp.getDealResult()))) {
				model.setStatus(CebEbankConstant.STR_ACCOUNT_STATUS_VAILD);
				clientMapper.update(model);
				respCode = TransReturnCode.code_0000;
			} else {
				ChannelRtncode channelRtncode = channelRtncodeService.findById(new ChannelRtncodeId(channelId,
						resp.getResCode()));
				if (channelRtncode != null) {
					
					/*
					 * 获得数据库中返回结果
					 * 其中包括可能为正确的结果 不需要激活
					 */
					ret.setChannelResponseCode(channelRtncode.getKftRtncode());
					ret.setChannelResponseMsg(channelRtncode.getChannelReamrk());
					respCode = ret.getChannelResponseCode();
				} else {
					ret.setChannelResponseCode(TransReturnCode.code_9900);
					ret.setChannelResponseMsg(resp.getResMsg());
					respCode = TransReturnCode.code_9900;
				}
				
				if(TransReturnCode.code_0000.equals(respCode)) {
					model.setStatus(CebEbankConstant.STR_ACCOUNT_STATUS_VAILD);
				} else {
					model.setStatus(CebEbankConstant.STR_ACCOUNT_STATUS_INVAILD);
				}
				
				clientMapper.update(model);
			}
			
			ret.setChannelResponseCode(respCode);
			ret.setChannelResponseMsg(resp.getResMsg());
		} catch (BizException e) {
			ret.setChannelResponseCode(e.getErrorCode());
			ret.setChannelResponseMsg(e.getMessage());
		}
		
		ret.setOrderNo(dto.getOrderNo());
		Log4jUtil.info("[认证激活返回结果]{}", ret);
		return ret;
	}
}
