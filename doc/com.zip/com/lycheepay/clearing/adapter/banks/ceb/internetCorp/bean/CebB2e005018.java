package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import java.nio.charset.Charset;

import org.apache.commons.lang.StringUtils;
import org.dom4j.Element;
import org.dom4j.Node;

import com.lycheepay.clearing.adapter.common.exception.BizException;
import com.lycheepay.clearing.adapter.common.util.biz.Dom4jXMLMessage;
import com.lycheepay.clearing.common.constant.TransReturnCode;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <P>光大银行 本行批量代扣批次号明细查询（b2e005018）</P>
 * 
 * @author 肖武胜 wsxiao 2013-7-15
 */
public class CebB2e005018 extends CebInternetCorpCommonMsgBean {
	private static final long serialVersionUID = 4795439630376468532L;

	private String transCode = "";// 交易码
	private String batchID = "";// 交易流水号, 上送报文为BatchID防止重复提交用
	private String jnlDate = "";// 请求日期
	private String jnlTime = "";// 请求时间

	private String clientPatchID = "";// 客户端批内序号/客户交易号
	private String batchNo = "";// 本行批量代扣批次号
	/*************** 响应信息 ****************/
	private String resBatchID = "";// 银企通流水号,与上送不一样
	private String resJnlDate = "";// 请求日期
	private String resJnlTime = "";// 请求时间
	private String response1 = "";// 预留字段1
	private String response2 = "";// 预留字段2
	private String response3 = "";// 预留字段3

	private String returnCode = "";// 响应码元素返回交易处理状态码
	private String returnMsg = "";// 响应信息元素交易处理状态中文信息
	private String returnNote = "";// 备注
	private String resClientPatchID;// 银企通子流水号,与上送不一样
	private String error = "";// 错误描述

	private String sucesFileName = "";// 成功文件名
	private String failFileName = "";// 失败文件名
	private String respond1 = "";// 循环域预留字段1
	private String respond2 = "";// 循环域预留字段2
	private String respond3 = "";// 循环域预留字段3
	private String respond4 = "";// 循环域预留字段4
	private String respond5 = "";// 循环域预留字段5

	public String packageMsg() throws BizException {
		Dom4jXMLMessage dom4jxml = new Dom4jXMLMessage();
		try {
			dom4jxml = Dom4jXMLMessage.createDom4jXMLMessage("Transaction");
			dom4jxml.setEncoding("GBK");

			Element rootElement = dom4jxml.getRoot();

			Element systemHeadElement = dom4jxml.addNode(rootElement, "SystemHead", "");
			dom4jxml.addNode(systemHeadElement, "Language", getLanguage());
			dom4jxml.addNode(systemHeadElement, "Encodeing", getEncodeing());
			dom4jxml.addNode(systemHeadElement, "Version", "");
			dom4jxml.addNode(systemHeadElement, "ServiceName", "");
			dom4jxml.addNode(systemHeadElement, "CifNo", getCifNo());
			dom4jxml.addNode(systemHeadElement, "UserID", getUserId());
			dom4jxml.addNode(systemHeadElement, "SyMacFlag", "");
			dom4jxml.addNode(systemHeadElement, "MAC", "");
			dom4jxml.addNode(systemHeadElement, "SyPinFlag", "");
			dom4jxml.addNode(systemHeadElement, "PinSeed", "");
			dom4jxml.addNode(systemHeadElement, "LicenseId", "");
			dom4jxml.addNode(systemHeadElement, "Flag", "");
			dom4jxml.addNode(systemHeadElement, "Note", "");

			Element transHeadElement = dom4jxml.addNode(rootElement, "TransHead", "");
			dom4jxml.addNode(transHeadElement, "TransCode", getTransCode());
			dom4jxml.addNode(transHeadElement, "BatchID", getBatchID());
			dom4jxml.addNode(transHeadElement, "JnlDate", getJnlDate());
			dom4jxml.addNode(transHeadElement, "JnlTime", getJnlTime());

			Element transContentElement = dom4jxml.addNode(rootElement, "TransContent", "");
			Element reqDataElement = dom4jxml.addNode(transContentElement, "ReqData", "");
			dom4jxml.addNode(reqDataElement, "ClientPatchID", getClientPatchID());
			dom4jxml.addNode(reqDataElement, "BatchNo", getBatchNo());

		} catch (Exception e) {
			Log4jUtil.error(e);
			throw new BizException(e, TransReturnCode.code_9108, e.getMessage());
		}
		return dom4jxml.toString();
	}

	public void unPackageMsg(byte[] msg) throws BizException {
		if (msg == null || msg.length <= 0) {
			Log4jUtil.error("msg为空" + msg);
			throw new BizException(TransReturnCode.code_9109, "msg为空");
		}
		String temp = new String(msg, Charset.forName("GBK")).replaceAll("transaction", "Transaction");
		temp = temp.replaceFirst("<Transaction .*>", "<Transaction>");

		if (StringUtils.isNotBlank(temp)) {
			Dom4jXMLMessage dom4jxml = Dom4jXMLMessage.parse(temp.getBytes(Charset.forName("GBK")));

			try {
				// 判断是否为错误报文，若是，获取错误信息返回
				Node errorNode = dom4jxml.getNode("/Transaction/error");
				if (errorNode != null) {
					Node transactionNode = dom4jxml.getNode("/Transaction");
					setReturnCode(dom4jxml.getNodeText(transactionNode, "ReturnCode"));
					setReturnMsg(dom4jxml.getNodeText(transactionNode, "ReturnMsg"));
					setError(dom4jxml.getNodeText(transactionNode, "error"));
					return;
				}

				Node systemHeadNode = dom4jxml.getNode("/Transaction/SystemHead");
				setLanguage(dom4jxml.getNodeText(systemHeadNode, "Language"));
				setEncodeing(dom4jxml.getNodeText(systemHeadNode, "Encodeing"));
				setVersion(dom4jxml.getNodeText(systemHeadNode, "Version"));
				setServiceName(dom4jxml.getNodeText(systemHeadNode, "ServiceName"));
				setCifNo(dom4jxml.getNodeText(systemHeadNode, "CifNo"));
				setUserId(dom4jxml.getNodeText(systemHeadNode, "UserId"));
				setSyMacFlag(dom4jxml.getNodeText(systemHeadNode, "SyMacFlag"));
				setMac(dom4jxml.getNodeText(systemHeadNode, "MAC"));
				setSyPinFlag(dom4jxml.getNodeText(systemHeadNode, "SyPinFlag"));
				setPinSeed(dom4jxml.getNodeText(systemHeadNode, "PinSeed"));
				setLicenseId(dom4jxml.getNodeText(systemHeadNode, "LicenseId"));
				setFlag(dom4jxml.getNodeText(systemHeadNode, "Flag"));
				setNote(dom4jxml.getNodeText(systemHeadNode, "Note"));

				Node transHeadNode = dom4jxml.getNode("/Transaction/TransHead");
				setTransCode(dom4jxml.getNodeText(transHeadNode, "TransCode"));
				setResBatchID(dom4jxml.getNodeText(transHeadNode, "BatchID"));
				setJnlDate(dom4jxml.getNodeText(transHeadNode, "JnlDate"));
				setJnlTime(dom4jxml.getNodeText(transHeadNode, "JnlTime"));
				setResponse1(dom4jxml.getNodeText(transHeadNode, "response1"));
				setResponse2(dom4jxml.getNodeText(transHeadNode, "response2"));
				setResponse3(dom4jxml.getNodeText(transHeadNode, "response3"));

				Node transContentNode = dom4jxml.getNode("/Transaction/TransContent");
				setReturnCode(dom4jxml.getNodeText(transContentNode, "ReturnCode"));
				setReturnMsg(dom4jxml.getNodeText(transContentNode, "ReturnMsg"));
				setReturnNote(dom4jxml.getNodeText(transContentNode, "ReturnNote"));
				setResClientPatchID(dom4jxml.getNodeText(transContentNode, "ClientPatchID"));

				Node respDataNode = dom4jxml.getNode("/Transaction/TransContent/RespData");
				setSucesFileName(dom4jxml.getNodeText(respDataNode, "SucesFileName"));
				setFailFileName(dom4jxml.getNodeText(respDataNode, "FailFileName"));
				setRespond1(dom4jxml.getNodeText(respDataNode, "respond1"));
				setRespond2(dom4jxml.getNodeText(respDataNode, "respond2"));
				setRespond3(dom4jxml.getNodeText(respDataNode, "respond3"));
				setRespond4(dom4jxml.getNodeText(respDataNode, "respond4"));
				setRespond5(dom4jxml.getNodeText(respDataNode, "respond5"));
			} catch (Exception e) {
				Log4jUtil.error(e);
				throw new BizException(e, TransReturnCode.code_9109, e.getMessage());
			}
		}
	}

	/**
	 * 返回 交易码
	 */
	public String getTransCode() {
		return this.transCode;
	}

	/**
	 * 设置 交易码
	 */
	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	/**
	 * 返回 交易流水号, 上送报文为BatchID防止重复提交用
	 */
	public String getBatchID() {
		return this.batchID;
	}

	/**
	 * 设置 交易流水号, 上送报文为BatchID防止重复提交用
	 */
	public void setBatchID(String batchID) {
		this.batchID = batchID;
	}

	/**
	 * 返回 请求日期
	 */
	public String getJnlDate() {
		return this.jnlDate;
	}

	/**
	 * 设置 请求日期
	 */
	public void setJnlDate(String jnlDate) {
		this.jnlDate = jnlDate;
	}

	/**
	 * 返回 请求时间
	 */
	public String getJnlTime() {
		return this.jnlTime;
	}

	/**
	 * 设置 请求时间
	 */
	public void setJnlTime(String jnlTime) {
		this.jnlTime = jnlTime;
	}

	/**
	 * 返回 客户端批内序号客户交易号
	 */
	public String getClientPatchID() {
		return this.clientPatchID;
	}

	/**
	 * 设置 客户端批内序号客户交易号
	 */
	public void setClientPatchID(String clientPatchID) {
		this.clientPatchID = clientPatchID;
	}

	/**
	 * 返回 本行批量代扣批次号
	 */
	public String getBatchNo() {
		return this.batchNo;
	}

	/**
	 * 设置 本行批量代扣批次号
	 */
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	/**
	 * 返回 银企通流水号,与上送不一样
	 */
	public String getResBatchID() {
		return this.resBatchID;
	}

	/**
	 * 设置 银企通流水号,与上送不一样
	 */
	public void setResBatchID(String resBatchID) {
		this.resBatchID = resBatchID;
	}

	/**
	 * 返回 请求日期
	 */
	public String getResJnlDate() {
		return this.resJnlDate;
	}

	/**
	 * 设置 请求日期
	 */
	public void setResJnlDate(String resJnlDate) {
		this.resJnlDate = resJnlDate;
	}

	/**
	 * 返回 请求时间
	 */
	public String getResJnlTime() {
		return this.resJnlTime;
	}

	/**
	 * 设置 请求时间
	 */
	public void setResJnlTime(String resJnlTime) {
		this.resJnlTime = resJnlTime;
	}

	/**
	 * 返回 预留字段1
	 */
	public String getResponse1() {
		return this.response1;
	}

	/**
	 * 设置 预留字段1
	 */
	public void setResponse1(String response1) {
		this.response1 = response1;
	}

	/**
	 * 返回 预留字段2
	 */
	public String getResponse2() {
		return this.response2;
	}

	/**
	 * 设置 预留字段2
	 */
	public void setResponse2(String response2) {
		this.response2 = response2;
	}

	/**
	 * 返回 预留字段3
	 */
	public String getResponse3() {
		return this.response3;
	}

	/**
	 * 设置 预留字段3
	 */
	public void setResponse3(String response3) {
		this.response3 = response3;
	}

	/**
	 * 返回 响应码元素返回交易处理状态码
	 */
	public String getReturnCode() {
		return this.returnCode;
	}

	/**
	 * 设置 响应码元素返回交易处理状态码
	 */
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	/**
	 * 返回 响应信息元素交易处理状态中文信息
	 */
	public String getReturnMsg() {
		return this.returnMsg;
	}

	/**
	 * 设置 响应信息元素交易处理状态中文信息
	 */
	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	/**
	 * 返回 备注
	 */
	public String getReturnNote() {
		return this.returnNote;
	}

	/**
	 * 设置 备注
	 */
	public void setReturnNote(String returnNote) {
		this.returnNote = returnNote;
	}

	/**
	 * 返回 银企通子流水号,与上送不一样
	 */
	public String getResClientPatchID() {
		return this.resClientPatchID;
	}

	/**
	 * 设置 银企通子流水号,与上送不一样
	 */
	public void setResClientPatchID(String resClientPatchID) {
		this.resClientPatchID = resClientPatchID;
	}

	/**
	 * 返回 错误描述
	 */
	public String getError() {
		return this.error;
	}

	/**
	 * 设置 错误描述
	 */
	public void setError(String error) {
		this.error = error;
	}

	/**
	 * 返回 成功文件名
	 */
	public String getSucesFileName() {
		return this.sucesFileName;
	}

	/**
	 * 设置 成功文件名
	 */
	public void setSucesFileName(String sucesFileName) {
		this.sucesFileName = sucesFileName;
	}

	/**
	 * 返回 失败文件名
	 */
	public String getFailFileName() {
		return this.failFileName;
	}

	/**
	 * 设置 失败文件名
	 */
	public void setFailFileName(String failFileName) {
		this.failFileName = failFileName;
	}

	/**
	 * 返回 循环域预留字段1
	 */
	public String getRespond1() {
		return this.respond1;
	}

	/**
	 * 设置 循环域预留字段1
	 */
	public void setRespond1(String respond1) {
		this.respond1 = respond1;
	}

	/**
	 * 返回 循环域预留字段2
	 */
	public String getRespond2() {
		return this.respond2;
	}

	/**
	 * 设置 循环域预留字段2
	 */
	public void setRespond2(String respond2) {
		this.respond2 = respond2;
	}

	/**
	 * 返回 循环域预留字段3
	 */
	public String getRespond3() {
		return this.respond3;
	}

	/**
	 * 设置 循环域预留字段3
	 */
	public void setRespond3(String respond3) {
		this.respond3 = respond3;
	}

	/**
	 * 返回 循环域预留字段4
	 */
	public String getRespond4() {
		return this.respond4;
	}

	/**
	 * 设置 循环域预留字段4
	 */
	public void setRespond4(String respond4) {
		this.respond4 = respond4;
	}

	/**
	 * 返回 循环域预留字段5
	 */
	public String getRespond5() {
		return this.respond5;
	}

	/**
	 * 设置 循环域预留字段5
	 */
	public void setRespond5(String respond5) {
		this.respond5 = respond5;
	}

}