package com.lycheepay.clearing.adapter.banks.ceb.ebank;

public final class CebEbankConstant {
	
	public static String PARM_SYS_URL = "100001";
	public static String PARM_SYS_HTTPS_PORT = "100002";
	public static String PARM_SYS_CONN_TIMEOUT = "100003";
	public static String PARM_SYS_SO_TIMEOUT = "100004";
	public static String PARM_SYS_PFX_PATH = "100005";
	public static String PARM_SYS_PFX_PWD = "100006";
	
	public static String PARM_SYS_SFTP_IP_IN = "100007";
	public static String PARM_SYS_SFTP_IP_OUT = "100008";
	public static String PARM_SYS_SFTP_PORT_IN = "100009";
	public static String PARM_SYS_SFTP_PORT_OUT = "100010";
	public static String PARM_SYS_SFTP_USER = "100011";
	public static String PARM_SYS_SFTP_PWD = "100012";
	public static String PARM_SYS_FILE_PATH = "100013";
	public static String PARM_SYS_TEMP_PATH = "100014";
	
	public static String PARM_VAR_USERID = "200001";
	
	/**
	 * 开户 更改为监管
	 */
	public static String STR_REQID_OPENACCOUNT = "BCifAcctNoOpen";
	
	/**
	 * 激活账户
	 */
	public static String STR_REQID_ACTIVATEACCOUNT = "BAccActivate";
	
	/**
	 * 销户
	 */
	public static String STR_REQID_CLOSEACCOUNT = "BCifAcNoCancel";
	/**
	 * 结息
	 */
	public static String STR_REQID_CLEARANCE = "BFinEndAndGAmount";
	/**
	 * 转出
	 */
	public static String STR_REQID_PAYOUT = "BTrsIn";
	/**
	 * 提现
	 */
	public static String STR_REQID_DEDUCT = "EComGAmount";
	/**
	 * 转入
	 */
	public static String STR_REQID_OFFGROUND = "BTrsOut";
	/**
	 * 余额
	 */
	public static String STR_REQID_BALANCE = "BCifAcNoAmount";
	/**
	 * 明细
	 */
	public static String STR_REQID_DETAIL = "BCifAcTrsList";
	/**
	 * 所有明细
	 */
	public static String STR_REQID_RECORD = "BCifAcTrsDtlList";
	/**
	 * 查询
	 */
	public static String STR_REQID_QUERY = "BTrsVeriAmount";
	
	/**
	 * 查询(返流水)
	 */
	public static String STR_REQID_QUERY_JNL = "BTrsVeriAmountJnl";
	/**
	 * 对账
	 */
	public static String STR_REQID_RECON = "BFinFundServiceReq";
	/**
	 * 对账
	 */
	public static String STR_SERVICEID_RECON = "BMerCheckFileReq";
	/**
	 * 上传
	 */
	public static String STR_UPLOAD_IMAGE = "BIdInteractive";

	public static String STR_ACCOUNT_STATUS_INVAILD = "0";
	public static String STR_ACCOUNT_STATUS_VAILD = "1";
	
	/**
	 *  账户激活成功
	 */
	public static String DEAL_RESULT_SUCCESS = "0";
	
	/**
	 * 账户激活失败
	 */
	public static String DEAL_RESULT_UNSUCCESS = "1";
	
	/**
	 * 账户无需激活
	 */
	public static String DEAL_RESULT_ACTIVATE = "2";
	
	public static String STR_DIRECTION_DEB = "0";
	public static String STR_DIRECTION_CRE = "1";
	
	public static String STR_TRANS_CURRENCY = "CNY";
	
	public static final int EBANK_RECON_FILE_STATUS_WAITING = 0;//未请求
	public static final int EBANK_RECON_FILE_STATUS_DO_SUCCESS = 1;//已生成标准对账文件
	public static final int EBANK_RECON_FILE_STATUS_REQ_SUSSCESS = 2;//已请求光大生成对账文件
	public static final int EBANK_RECON_FILE_STATUS_REQ_FAILED = 3;//请求失败
}
