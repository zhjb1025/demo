/*******************************************************************************
 * Project Key : #{issue-key}
 * Create on 2012-6-29 下午5:29:37
 * Copyright (c) 2008 - 2011.深圳市快付通金融网络科技服务有限公司版权所有. 粤ICP备10228891号
 * 注意：本内容仅限于深圳市快付通金融网络科技服务有限公司内部传阅，禁止外泄以及用于其他的商业目的
 ******************************************************************************/
package com.lycheepay.clearing.adapter.banks.ceb.constants;


/**
 * <P>光大银行网上银企公用常量</P>
 * @author 杜波(15999653650)
 */
public class CebInternetCorpChannelConstants {
	public static String Ceb_Internet_Corp_B2E004001 = "/ent/b2e004001.do?usrID=2000013811&userPassword=123456&Sigdata=1";
	public static String Ceb_Internet_Corp_B2E004003 = "/ent/b2e004003.do?userPassword=123456";
}
