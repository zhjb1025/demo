package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankOpenAccountRequestDTO extends CebEbankRequestDTO {

	public CebEbankOpenAccountRequestDTO() {
		super();
		super.addItem("BankAcNo", null);
		super.addItem("BankCardPhoneCode", null);
		super.addItem("BankCardType", null);
		super.addItem("BankName", null);
		super.addItem("CifAddr", null);
		super.addItem("CifClientId", null);
		super.addItem("CifEnName", null);
		super.addItem("CifIdExpiredDate", null);
		super.addItem("CifName", null);
		super.addItem("CifPhoneCode", null);
		super.addItem("CifPostCode", null);
		super.addItem("IdNo", null);
		super.addItem("IdType", null);
		super.addItem("OperateType", null);
		super.addItem("Remark1", null);
		super.addItem("Remark2", null);
		super.addItem("Remark3", null);
		super.addItem("Remark4", null);
		super.addItem("Remark5", null);
		super.addItem("Remark6", null);
		super.addItem("Remark7", null);
		super.addItem("Remark8", null);
		super.addItem("Remark9", null);
		super.addItem("Remark10", null);
		super.addItem("SubBranchName", null);
		super.addItem("NetCheckFlag", null);
		super.addItem("OpenChannel", null);
	}
	
	public String getNetCheckFlag() {
		return data.get("NetCheckFlag");
	}

	public void setNetCheckFlag(String NetCheckFlag) {
		data.put("NetCheckFlag", NetCheckFlag);
	}

	public String getOpenChannel() {
		return data.get("OpenChannel");
	}

	public void setOpenChannel(String OpenChannel) {
		data.put("OpenChannel", OpenChannel);
	}
	
	public String getBankAcNo() {
		return data.get("BankAcNo");
	}

	public void setBankAcNo(String bankAcNo) {
		data.put("BankAcNo", bankAcNo);
	}
	
	public String getSubBranchName() {
		return data.get("SubBranchName");
	}

	public void setSubBranchName(String SubBranchName) {
		data.put("SubBranchName", SubBranchName);
	}

	public String getBankCardPhoneCode() {
		return data.get("BankCardPhoneCode");
	}

	public void setBankCardPhoneCode(String bankCardPhoneCode) {
		data.put("BankCardPhoneCode", bankCardPhoneCode);
	}

	public String getBankCardType() {
		return data.get("BankCardType");
	}

	public void setBankCardType(String bankCardType) {
		data.put("BankCardType", bankCardType);
	}

	public String getBankName() {
		return data.get("BankName");
	}

	public void setBankName(String bankName) {
		data.put("BankName", bankName);
	}


	public String getCifAddr() {
		return data.get("CifAddr");
	}

	public void setCifAddr(String CifAddr) {
		data.put("CifAddr", CifAddr);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getCifEnName() {
		return data.get("CifEnName");
	}

	public void setCifEnName(String CifEnName) {
		data.put("CifEnName", CifEnName);
	}

	public String getCifIdExpiredDate() {
		return data.get("CifIdExpiredDate");
	}

	public void setCifIdExpiredDate(String CifIdExpiredDate) {
		data.put("CifIdExpiredDate", CifIdExpiredDate);
	}

	public String getCifName() {
		return data.get("CifName");
	}

	public void setCifName(String CifName) {
		data.put("CifName", CifName);
	}

	public String getCifPhoneCode() {
		return data.get("CifPhoneCode");
	}

	public void setCifPhoneCode(String CifPhoneCode) {
		data.put("CifPhoneCode", CifPhoneCode);
	}

	public String getCifPostCode() {
		return data.get("CifPostCode");
	}

	public void setCifPostCode(String CifPostCode) {
		data.put("CifPostCode", CifPostCode);
	}

	public String getIdNo() {
		return data.get("IdNo");
	}

	public void setIdNo(String IdNo) {
		data.put("IdNo", IdNo);
	}

	public String getIdType() {
		return data.get("IdType");
	}

	public void setIdType(String IdType) {
		data.put("IdType", IdType);
	}

	public String getOperateType() {
		return data.get("OperateType");
	}

	public void setOperateType(String OperateType) {
		data.put("OperateType", OperateType);
	}

	public String getRemark1() {
		return data.get("Remark1");
	}

	public void setRemark1(String Remark1) {
		data.put("Remark1", Remark1);
	}

	public String getRemark2() {
		return data.get("Remark2");
	}

	public void setRemark2(String Remark2) {
		data.put("Remark2", Remark2);
	}

	public String getRemark3() {
		return data.get("Remark3");
	}

	public void setRemark3(String Remark3) {
		data.put("Remark3", Remark3);
	}

	public String getRemark4() {
		return data.get("Remark4");
	}

	public void setRemark4(String Remark4) {
		data.put("Remark4", Remark4);
	}

	public String getRemark5() {
		return data.get("Remark5");
	}

	public void setRemark5(String Remark5) {
		data.put("Remark5", Remark5);
	}

}
