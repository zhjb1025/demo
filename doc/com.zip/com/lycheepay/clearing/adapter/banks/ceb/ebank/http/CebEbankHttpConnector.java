package com.lycheepay.clearing.adapter.banks.ceb.ebank.http;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;

import com.lycheepay.clearing.util.Log4jUtil;

//@SuppressWarnings("deprecation")
public final class CebEbankHttpConnector {

	private String url;
	private int port;
	private int connTimeout;
	private int soTimeout;

	/**
	 * 使用HTTPS协议时，port参数必须输入。
	 * 
	 * @param url
	 *            URL地址
	 * @param port
	 *            安全协议端口
	 */
	public CebEbankHttpConnector(String url, int port, int connTimeout, int soTimeout) {
		this.url = url;
		this.port = port;
		this.connTimeout = connTimeout;
		this.soTimeout = soTimeout;
	}

	public String connect(Map<String, String> param) throws GeneralSecurityException, IOException {
		HttpClient httpclient = new DefaultHttpClient();

		Log4jUtil.info("[HTTP]URL({})", this.url);
		// 安全协议自适应加载
		if (url.startsWith("https"))
		{
			Log4jUtil.info("[HTTP]SSL:{}", this.port);

			// Secure Protocol implementation.
			SSLContext ctx = SSLContext.getInstance("TLSv1.1");
			// Implementation of a trust manager for X509 certificates
			X509TrustManager tm = new X509TrustManager() {

				public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {

				}

				public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			// 安全协议注册
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, new X509HostnameVerifier(){

				@Override
				public boolean verify(String hostname, SSLSession session) {
					// TODO Auto-generated method stub
					return true;
				}

				@Override
				public void verify(String host, SSLSocket ssl)
						throws IOException {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void verify(String host, X509Certificate cert)
						throws SSLException {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void verify(String host, String[] cns,
						String[] subjectAlts) throws SSLException {
					// TODO Auto-generated method stub
					
				}

            });
			ClientConnectionManager ccm = httpclient.getConnectionManager();
			
			// register https protocol in httpclient's scheme registry
			SchemeRegistry sr = ccm.getSchemeRegistry();
			sr.register(new Scheme("https", port, ssf));
		}

		// 转换对象为参数
		ArrayList<NameValuePair> pairList = new ArrayList<NameValuePair>();
		for (Entry<String, String> item : param.entrySet())
		{
			pairList.add(new BasicNameValuePair(item.getKey(), item.getValue()));
		}

		// HTTP请求过程
		HttpPost httpPost = new HttpPost(url);
		httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, connTimeout);// 连接时间
		httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, soTimeout);// 数据传输时间
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(pairList, "UTF-8");// 设置FORM模式
		Log4jUtil.info("[HTTP]-->\n{}", EntityUtils.toString(entity));
		httpPost.setEntity(entity);
		Log4jUtil.info("[HTTP]开始发送请求-------", this.url);
		HttpResponse response = httpclient.execute(httpPost);
		Log4jUtil.info("[HTTP]结束发送请求-------", this.url);
		StatusLine status = response.getStatusLine();
		String result = null;
		Log4jUtil.info("[HTTP]<->{}", status.getStatusCode());
		if (status.getStatusCode() == HttpStatus.SC_OK)
		{
			result = EntityUtils.toString(response.getEntity());
		}
		else
		{
			throw new IOException(status.getStatusCode() + status.getReasonPhrase());
		}
		
		Log4jUtil.info("[HTTP]<--\n{}", result);
		return result;
	}
}
