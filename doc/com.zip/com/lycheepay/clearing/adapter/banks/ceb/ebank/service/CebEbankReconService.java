package com.lycheepay.clearing.adapter.banks.ceb.ebank.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.soofa.tx.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lycheepay.clearing.adapter.app.common.service.ReconciliationFileServiceInner;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.CebEbankConstant;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request.CebEbankObtainReconciliationRequestDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response.CebEbankObtainReconciliactionResponseDTO;
import com.lycheepay.clearing.adapter.banks.ceb.ebank.service.process.CebEbankProcessService;
import com.lycheepay.clearing.adapter.common.constant.BusinessCode;
import com.lycheepay.clearing.adapter.common.constant.ClearingAdapterAnnotationName;
import com.lycheepay.clearing.adapter.common.dto.ReconciliationFileDTO;
import com.lycheepay.clearing.adapter.common.exception.ClearingAdapterBizCheckedException;
import com.lycheepay.clearing.adapter.common.model.biz.EBankReconReqRecord;
import com.lycheepay.clearing.adapter.common.util.net.ReconciliationFileUtil;
import com.lycheepay.clearing.common.constant.ChannelId;
import com.lycheepay.clearing.util.Log4jUtil;

@Service(ClearingAdapterAnnotationName.CEB_EBANK_RECONCILIATION_FILE_SERVICE)
public class CebEbankReconService extends BaseService implements ReconciliationFileServiceInner {
	private static final String STR_PAY = "pay";
	private static final String STR_GET = "get";
	@Autowired
	private CebEbankProcessService cebEbankProcessService;
	@Autowired
	private CebEbankReconServiceHelper cebEbankReconServiceHelper;
	private String logPrefix = "光大一帐通";

	@Override
	public String getReconciliationFile(String fileSavePath, String channelId, String settleDate) throws ClearingAdapterBizCheckedException {
		Log4jUtil.setLogClass("CEB", "ReconService");
		EBankReconReqRecord queryRecode = new EBankReconReqRecord();
		queryRecode.setQryDate(settleDate);
		EBankReconReqRecord record = cebEbankReconServiceHelper.getEBankReconReqRecord(queryRecode);
		String fileFullPath = null;
		// 记录请求响应信息
		if (record == null)
		{
			// 当日第一次请求，请求光大生成，光大的对账文件
			try{
				sendRequestToGetReconFile(fileSavePath, channelId, settleDate);
			}catch(Exception e){
				Log4jUtil.error(e);
				//如果调用下载光大对账文件异常,则直接生成空文件返回
				List<ReconciliationFileDTO> reconDetail = new ArrayList<ReconciliationFileDTO>();
				fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate, reconDetail);
			}
			return fileFullPath;
		}
		//以下这条语句基本没有实际的意义,不会使用到,可以考虑删除.
		fileFullPath = record.getFilePath() + File.separator + record.getReconFileName();
		switch (record.getStatus().intValue())
		{
			case CebEbankConstant.EBANK_RECON_FILE_STATUS_WAITING:
				// 判断生成对账文件请求未发出，请求光大生成对账文件
				try{
					sendRequestToGetReconFile(fileSavePath, channelId, settleDate);
				}catch(Exception e){
					Log4jUtil.error(e);
					//如果调用下载光大对账文件异常,则直接生成空文件返回
					List<ReconciliationFileDTO> reconDetail = new ArrayList<ReconciliationFileDTO>();
					fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate, reconDetail);
				}
				return fileFullPath;
			case CebEbankConstant.EBANK_RECON_FILE_STATUS_REQ_FAILED:
				// 判断生成对账文件请求未发出，请求光大生成对账文件
				try{
					sendRequestToGetReconFile(fileSavePath, channelId, settleDate);
				}catch(Exception e){
					Log4jUtil.error(e);
					//如果调用下载光大对账文件异常,则直接生成空文件返回
					List<ReconciliationFileDTO> reconDetail = new ArrayList<ReconciliationFileDTO>();
					fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate, reconDetail);
				}
				return fileFullPath;
			case CebEbankConstant.EBANK_RECON_FILE_STATUS_REQ_SUSSCESS:
				// 判断对账文件已发出，检测文件是否生成，文件生成则转换未标准对账文件
				fileFullPath = createReconfile(fileFullPath, settleDate, channelId, fileSavePath, record);
				break;
			case CebEbankConstant.EBANK_RECON_FILE_STATUS_DO_SUCCESS:
				// 已生成标准对账文件，直接返回
				Log4jUtil.info("Reconfile has existed");
				fileFullPath = loadReconFilePath(fileSavePath, channelId, settleDate);
				break;
			default:
				// 未知
				Log4jUtil.info("unknown status : " + record.getStatus());
				return null;
		}
		
		return fileFullPath;
	}

	private String loadReconFilePath(String fileSavePath, final String channelId, final String settleDate) {
		if (!fileSavePath.endsWith(File.separator))
		{
			fileSavePath = fileSavePath + File.separator;
		}
		fileSavePath = fileSavePath + channelId + File.separator + settleDate + File.separator;
		final String fileFullPath = fileSavePath + settleDate + "Accfile.txt";
		Log4jUtil.info("文件保存目录:" + fileSavePath);

		return fileFullPath;
	}

	private String createReconfile(String fileFullPath, String settleDate, String channelId, String fileSavePath, EBankReconReqRecord record)
			throws ClearingAdapterBizCheckedException {
		Log4jUtil.info(logPrefix + "createReconfile begin, fileSavePath {}", fileSavePath);
		cebEbankProcessService.downloadFile2SFTP(record.getReconFileName());
		File file = new File(fileFullPath);
		if (!file.exists())
		{
			Log4jUtil.info("{} not exist", fileFullPath);
		}
		final List<ReconciliationFileDTO> reconciliationFileDTOList = this.buildTransactionDataList(logPrefix, settleDate, fileFullPath,
				channelId);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		String filePath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, settleDate, reconciliationFileDTOList);
		// 更新记录状态
		EBankReconReqRecord updateRecord = new EBankReconReqRecord();
		updateRecord.setStatus((short) CebEbankConstant.EBANK_RECON_FILE_STATUS_DO_SUCCESS);
		updateRecord.setId(record.getId());
		cebEbankReconServiceHelper.updateByPrimaryKeySelective(updateRecord);

		return filePath;
	}

	// 对光大发出生成对账文件请求
	private CebEbankObtainReconciliactionResponseDTO sendRequestToGetReconFile(String fileSavePath, String channelId, String settleDate)
			throws ClearingAdapterBizCheckedException {
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, fileSavePath, channelId, settleDate);
		Log4jUtil.info(logPrefix + "本次对账日期为：" + queryDate);
		// 生成下载交易记录请求对象
		final CebEbankObtainReconciliationRequestDTO req = new CebEbankObtainReconciliationRequestDTO();
		req.setQryDate(settleDate); // 设定查询日期（必要信息）
		Log4jUtil.info(logPrefix + "发送对账单下载请求到银行。");
		CebEbankObtainReconciliactionResponseDTO resp = new CebEbankObtainReconciliactionResponseDTO();
		// 插入请求记录
		EBankReconReqRecord inserRecord = new EBankReconReqRecord();
		// 传送商户对账单下载请求并取得对账单
		resp = cebEbankProcessService.queryReconFile(req, inserRecord);
		Log4jUtil.info(logPrefix + "成功收到银行resp{}", resp);
		// 更新请求结果

		if ("000000".equals(resp.getResCode()))
		{
			EBankReconReqRecord updateRecord = getUpdateRecord(resp, inserRecord);
			updateRecord.setStatus((short) CebEbankConstant.EBANK_RECON_FILE_STATUS_REQ_SUSSCESS);
			cebEbankReconServiceHelper.updateByPrimaryKeySelective(updateRecord);
			Log4jUtil.info(logPrefix + "成功收到银行返回的对账单对象TrxResponse。");
		}
		else
		{
			final String errorMsg = logPrefix + "未知情况!ReturnCode:" + resp.getResCode() + " ErrorMessage:" + resp.getResMsg();
			Log4jUtil.error(errorMsg);
			EBankReconReqRecord updateRecord = getUpdateRecord(resp, inserRecord);
			updateRecord.setStatus((short) CebEbankConstant.EBANK_RECON_FILE_STATUS_REQ_FAILED);
			cebEbankReconServiceHelper.updateByPrimaryKeySelective(updateRecord);
			throw new ClearingAdapterBizCheckedException(BusinessCode.GET_RECONCILIATION_FILE_FAILED, errorMsg);
		}
		return resp;
	}

	private EBankReconReqRecord getUpdateRecord(CebEbankObtainReconciliactionResponseDTO resp, EBankReconReqRecord inserRecord) {
		EBankReconReqRecord updateRecord = new EBankReconReqRecord();
		updateRecord.setResJnlNo(resp.getResJnlNo());
		updateRecord.setReconFileName(resp.getFileName());
		updateRecord.setFilePath(resp.getFilePath());
		updateRecord.setTotNum(resp.getTotNum());
		updateRecord.setResTime(resp.getResTime());
		updateRecord.setResCode(resp.getResCode());
		updateRecord.setResMsg(resp.getResMsg());
		updateRecord.setId(inserRecord.getId());
		return updateRecord;
	}

	@Override
	public String convertToStandardReconciliationFile(String targetFilePath, String fileSavePath, String channelId, String settleDate)
			throws ClearingAdapterBizCheckedException {
		final String logPrefix = channelId + ChannelId.getNameByValue(channelId);
		final String queryDate = ReconciliationFileUtil.verifyInputParameters(logPrefix, targetFilePath, channelId, settleDate);
		Log4jUtil.info(logPrefix + "清算日期为：" + queryDate);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = buildTransactionDataList(logPrefix, channelId, targetFilePath,
				queryDate);
		Log4jUtil.info(logPrefix + "生成统一格式对账文件");
		final String fileFullPath = ReconciliationFileUtil.createReconciliationFile(fileSavePath, channelId, queryDate,
				reconciliationFileDTOList);
		return fileFullPath;
	}

	/**
	 * <p>
	 * 构建交易数据对象列表
	 * </p>
	 * 
	 * @param tRecords
	 * @param reconciliationDate
	 * @param channelId
	 * @throws ClearingAdapterBizCheckedException
	 */
	private List<ReconciliationFileDTO> buildTransactionDataList(final String logPrefix, final String settleDate,
			final String fileFullPathName, final String channelId) throws ClearingAdapterBizCheckedException {
		String logMsg = logPrefix + "准备生成对账对象。";
		Log4jUtil.info(logMsg);
		final List<ReconciliationFileDTO> reconciliationFileDTOList = new ArrayList<ReconciliationFileDTO>();
		BufferedReader bufferedReader = null;

		// 循环对文本逐行处理
		int currLine = 0;
		String data = null;
		String resSn = "";// 商户平台流水号
		String amount = "";// 交易金额
		int totalNum_ = 0; // 总笔数
		String payGet = "";
		try
		{
			bufferedReader = new BufferedReader(new FileReader(fileFullPathName));
			while ((data = bufferedReader.readLine()) != null)
			{
				final ReconciliationFileDTO dto = new ReconciliationFileDTO();
				currLine++; // 对账文件 行循环
				logMsg = logPrefix + "对账文件第 " + currLine + " 行文件内容为：" + data;
				Log4jUtil.info(logMsg);
				if (0 < data.trim().length())
				{
					final String[] es = data.split("\\|\\+\\|");
					if (1 < es.length)
					{
						final String tradeDate = es[1].trim().replace("-", "");// 交易日期时间
						if (!isValidDate(tradeDate, "yyyyMMdd"))
						{
							// 若不是合法交易时间，则直接跳过该行
							logMsg = logPrefix + "该行不是合法的交易数据。";
							Log4jUtil.info(logMsg);
							continue;
						}
						resSn = es[0].trim();// 系统跟踪号 = BankSendSn
						amount = es[3].trim();
						payGet = es[2].trim();
						dto.setCheckDate(settleDate);
						dto.setBankSendId(resSn); // 订单号
						dto.setTransDate(tradeDate); // 交易日期
						dto.setAmount(new BigDecimal(amount));// 交易金额
						dto.setChannelId(channelId);

						// 交易状态 00-支付成功；01-支付失败；02-超时
						if ("S".equals(es[4]))
						{
							dto.setBankTransState("00");
						}
						else if ("F".equals(es[4]))
						{
							dto.setBankTransState("01");
						}
						else
						{
							dto.setBankTransState("02");
						}

						if (CebEbankConstant.STR_REQID_PAYOUT.equals(payGet))
						{
							dto.setPayGet(STR_PAY);
						}
						else if (CebEbankConstant.STR_REQID_OFFGROUND.equals(payGet))
						{
							dto.setPayGet(STR_GET);
						}
						totalNum_++;

						final StringBuffer sb = new StringBuffer();
						sb.append("添加到accBeanList的第").append(totalNum_).append("条记录:").append(" checkDate:").append(dto.getCheckDate())
								.append(" BankSendId:").append(dto.getBankSendId()).append(" TranDate:").append(dto.getTransDate())
								.append(" Amount:").append(dto.getAmount().doubleValue());
						Log4jUtil.info(sb.toString());

						reconciliationFileDTOList.add(dto);
					}
				}

			}
		}
		catch (Exception e)
		{
			Log4jUtil.error("buildTransactionDataList error", e);

		}
		return reconciliationFileDTOList;
	}

	public boolean isValidDate(final String dateStr, final String pattern) {
		final SimpleDateFormat df = new SimpleDateFormat(pattern);
		df.setLenient(false);// 来强调严格遵守该格式
		try
		{
			df.parse(dateStr);
		}
		catch (final ParseException e)
		{
			return false;
		}
		return true;
	}

}
