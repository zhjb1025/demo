package com.lycheepay.clearing.adapter.banks.ceb.internetCorp.bean;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.lycheepay.clearing.adapter.banks.ceb.internetCorp.util.CommonFunction;
import com.lycheepay.clearing.util.Log4jUtil;


/**
 * 
 * <P>光大银行批量代扣文件下载成功交易JavaBean</P>
 * 
 * @author 肖武胜 wsxiao 2013-7-12
 */
public class CebBatchDeductFileDownloadBean extends CebFileTransformBeanAdaptor {
	private static final long serialVersionUID = -7162367298499213743L;
	private List<DetailResult> list = Collections.emptyList();

	@Override
	public void parseFile(File file) throws Exception {
		Log4jUtil.info("解析文件名:{}，文件大小:{}", file.getName(), file.length());
		super.parseFile(file);
		if (file != null) {
			BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file),
					Charset.forName("GBK")));
			String line = null;
			String[] succInfo = null;
			List<DetailResult> ls = new ArrayList<DetailResult>();
			try {
				while (StringUtils.isNotBlank(line = br.readLine())) {
					if (line.matches("^\\d+[|]\\d+[|]\\d+[.]\\d{2}[|].+[|].+[|].*[|].*[|]$")) {
						succInfo = StringUtils.splitPreserveAllTokens(line, "|");
						ls.add(new DetailResult(succInfo[0], succInfo[1], succInfo[2], succInfo[3], succInfo[4],
								succInfo[5], succInfo[6]));
					}
				}
				this.setList(ls);
			} finally {
				if (br != null)
					br.close();
			}
		}
	}

	public DetailResult getDeductInfoById(String id) {
		if (CommonFunction.isEmpty(list)) {
			return null;
		}
		for (DetailResult detailResult : list) {
			if (detailResult.getId().equals(id)) {
				return detailResult;
			}
		}
		return null;
	}

	public List<DetailResult> getList() {
		return list;
	}

	public void setList(List<DetailResult> list) {
		this.list = list;
		if (this.list != null && list.size() > 0) {
			super.setBishuu(String.valueOf(list.size()));
			BigDecimal totalAmount = new BigDecimal("0.00");
			for (DetailResult detailResult : list) {
				totalAmount = totalAmount.add(CommonFunction.parse2BigDecimal(detailResult.getAmount()));
			}
			super.setZongje(CommonFunction.parse2String(totalAmount));
		}
	}
}