package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankResponseDTO;

/**
 * 调用光大电子账户明细查询接口
 * 响应dto
 * @author 杨开宇
 *
 */
public class CebEbankTradeDetailQueryResponseDTO extends CebEbankResponseDTO{
	
	public CebEbankTradeDetailQueryResponseDTO(){
		super.list=new ArrayList<Map<String,String>>();
	}

	public String getTotNum(){
		return data.get("TotNum");
	}
	public void setTotalNum(String TotNum){
		data.put("TotNum", TotNum);
	}
	public String getRetNum(){
		return data.get("RetNum");
	}
	public void setRetNum(String RetNum){
		data.put("RetNum", RetNum);
	}
	public String getReserve6(){
		return data.get("Reserve6");
	}
	public void setReserve6(String Reserve6){
		data.put("Reserve6", Reserve6);
	}
	public String getReserve7(){
		return data.get("Reserve7");
	}
	public void setReserve7(String Reserve7){
		data.put("Reserve7", Reserve7);
	}
	public List<Map<String, String>> getList() {
		return list;
	}
	public void setList(List<Map<String, String>> list) {
		this.list = list;
	}
	
	
	
}
