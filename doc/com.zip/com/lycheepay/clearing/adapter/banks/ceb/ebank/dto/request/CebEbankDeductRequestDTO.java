package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankDeductRequestDTO extends CebEbankRequestDTO {

	public CebEbankDeductRequestDTO() {
		super();
		super.addItem("Amount", null);
		super.addItem("CifClientId", null);
		super.addItem("Currency", null);
		super.addItem("ChannelSeq", null);
		super.addItem("TrsDate", null);
		super.addItem("WDType", null);
		super.addItem("Remark", null);
		super.addItem("WDName", null);
		super.addItem("IdType", null);
		super.addItem("IdNo", null);
		super.addItem("WDAcNo", null);
		super.addItem("WDBankNo", null);
		super.addItem("WDInnerBankFlag", null);
		super.addItem("Reserve1", null);
		super.addItem("Reserve2", null);
		super.addItem("Reserve3", null);
	}

	public String getAmount() {
		return data.get("Amount");
	}

	public void setAmount(String Amount) {
		data.put("Amount", Amount);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getChannelSeq() {
		return data.get("ChannelSeq");
	}

	public void setChannelSeq(String ChannelSeq) {
		data.put("ChannelSeq", ChannelSeq);
	}

	public String getTrsDate() {
		return data.get("TrsDate");
	}

	public void setTrsDate(String TrsDate) {
		data.put("TrsDate", TrsDate);
	}

	public String getWDType() {
		return data.get("WDType");
	}

	public void setWDType(String WDType) {
		data.put("WDType", WDType);
	}

	public String getRemark() {
		return data.get("Remark");
	}

	public void setRemark(String Remark) {
		data.put("Remark", Remark);
	}

}
