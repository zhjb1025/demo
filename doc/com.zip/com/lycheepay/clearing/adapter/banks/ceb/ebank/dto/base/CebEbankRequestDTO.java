package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base;

public abstract class CebEbankRequestDTO extends CebEbankBaseDTO {

	/**
	 * 请求中的公共参数信息
	 * @author 王瑞
	 */
	public CebEbankRequestDTO() {
		super.addItem("ReqId", null);
		super.addItem("ReqJnlNo", null);
		super.addItem("ReqTime", null);
		super.addItem("UserId", null);
		//Sign参数在计算签名后插入
	}

	public String getReqJnlNo() {
		return data.get("ReqJnlNo");
	}

	public void setReqJnlNo(String ReqJnlNo) {
		data.put("ReqJnlNo", ReqJnlNo);
	}

	public String getReqTime() {
		return data.get("ReqTime");
	}

	public void setReqTime(String ReqTime) {
		data.put("ReqTime", ReqTime);
	}

	public String getUserId() {
		return data.get("UserId");
	}

	public void setUserId(String UserId) {
		data.put("UserId", UserId);
	}

	public String getReqId() {
		return data.get("ReqId");
	}

	public void setReqId(String ReqId) {
		data.put("ReqId", ReqId);
	}
	
	public void setSign(String Sign){
		data.put("Sign", Sign);
	}

}
