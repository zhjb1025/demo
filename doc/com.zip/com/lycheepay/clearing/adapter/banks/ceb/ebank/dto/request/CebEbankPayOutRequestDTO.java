package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

public class CebEbankPayOutRequestDTO extends CebEbankRequestDTO {

	public CebEbankPayOutRequestDTO() {
		super();
		super.addItem("CoPatrnerJnlNo", null);
		super.addItem("TrsDate", null);
		super.addItem("CifClientId", null);
		super.addItem("Amount", null);
		super.addItem("TrsType", null);
		super.addItem("Currency", null);
		super.addItem("Remark", null);
		super.addItem("Reserve1", null);
		super.addItem("Reserve2", null);
		super.addItem("Reserve3", null);
	}

	public String getCoPatrnerJnlNo() {
		return data.get("CoPatrnerJnlNo");
	}

	public void setCoPatrnerJnlNo(String CoPatrnerJnlNo) {
		data.put("CoPatrnerJnlNo", CoPatrnerJnlNo);
	}

	public String getTrsDate() {
		return data.get("TrsDate");
	}

	public void setTrsDate(String TrsDate) {
		data.put("TrsDate", TrsDate);
	}

	public String getCifClientId() {
		return data.get("CifClientId");
	}

	public void setCifClientId(String CifClientId) {
		data.put("CifClientId", CifClientId);
	}

	public String getAmount() {
		return data.get("Amount");
	}

	public void setAmount(String Amount) {
		data.put("Amount", Amount);
	}

	public String getTrsType() {
		return data.get("TrsType");
	}

	public void setTrsType(String TrsType) {
		data.put("TrsType", TrsType);
	}

	public String getCurrency() {
		return data.get("Currency");
	}

	public void setCurrency(String Currency) {
		data.put("Currency", Currency);
	}

	public String getRemark() {
		return data.get("Remark");
	}

	public void setRemark(String Remark) {
		data.put("Remark", Remark);
	}

	public String getReserve1() {
		return data.get("Reserve1");
	}

	public void setReserve1(String Reserve1) {
		data.put("Reserve1", Reserve1);
	}

	public String getReserve2() {
		return data.get("Reserve2");
	}

	public void setReserve2(String Reserve2) {
		data.put("Reserve2", Reserve2);
	}

	public String getReserve3() {
		return data.get("Reserve3");
	}

	public void setReserve3(String Reserve3) {
		data.put("Reserve3", Reserve3);
	}

}
