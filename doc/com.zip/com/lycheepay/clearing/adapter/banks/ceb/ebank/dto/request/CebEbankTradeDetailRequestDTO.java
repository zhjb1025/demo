package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.request;

import com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base.CebEbankRequestDTO;

/**
 * 
 * 交易查询dto
 * 
 */
public class CebEbankTradeDetailRequestDTO extends CebEbankRequestDTO {

	public String getCoPatrnerJnlNo() {
		return data.get("CoPatrnerJnlNo");
	}

	public void setCoPatrnerJnlNo(String coPatrnerJnlNo) {
		data.put("CoPatrnerJnlNo", coPatrnerJnlNo);
	}

	public String getTrsDate() {
		return data.get("TrsDate");
	}

	public void setTrsDate(String trsDate) {
		data.put("TrsDate", trsDate);
	}

	public String getReserve1() {
		return data.get("Reserve1");
	}

	public void setReserve1(String reserve1) {
		data.put("Reserve1", reserve1);
	}

	public String getReserve2() {
		return data.get("Reserve2");
	}

	public void setReserve2(String reserve2) {
		data.put("Reserve2", reserve2);
	}
	
	public String getReserve3() {
		return data.get("Reserve3");
	}

	public void setReserve3(String reserve3) {
		data.put("Reserve3", reserve3);
	}
	
	public String getReserve4() {
		return data.get("Reserve4");
	}

	public void setReserve4(String reserve4) {
		data.put("Reserve4", reserve4);
	}
	
	public String getReserve5() {
		return data.get("Reserve5");
	}

	public void setReserve5(String reserve5) {
		data.put("Reserve5", reserve5);
	}
}
