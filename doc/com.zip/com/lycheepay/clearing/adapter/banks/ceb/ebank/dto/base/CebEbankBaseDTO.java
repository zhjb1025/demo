package com.lycheepay.clearing.adapter.banks.ceb.ebank.dto.base;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

/**
 * 光大银行对接使用的DTO基类
 * @author 王瑞
 *
 */
public abstract class CebEbankBaseDTO {

	//数据结构，HTTP基于STRING模式
	protected final Map<String, String> data;
	
	//默认使用自然排序(忽略大小写)
	protected CebEbankBaseDTO(){
		this.data = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
	}
	
	//如果子类有特殊要求可自行构造
	protected CebEbankBaseDTO(Map<String, String> map){
		this.data = map;
	}
	
	public void addItem(String key,String value){
		data.put(key, value);
	}
	
	public String getItem(String key){
		return data.get(key);
	}
	
	public Map<String, String> getContentMap(){
		return data;
	}
	
	public int getFieldCount(){
		return data.size();
	}
	
	public String buildData(){
		fuckNull();
		StringBuilder sb = new StringBuilder();
		String remark10 = null;
		for(Entry<String,String> e : data.entrySet()){
			/*if("OpenChannel".equals(e.getKey()))
				continue;*/
			
			/*
			 * 处理Remark10的顺序
			 * 由于按照字母顺序Remark10在Remark2之前，而接口要求必须在Remark9后面
			 * 
			 */
			if("Remark10".equals(e.getKey())) {
				remark10 = e.getValue();
				continue;
			}
			
			sb.append(e.getKey());
			sb.append('=');
			sb.append(e.getValue());
			sb.append('&');
			
			/*
			 * 补上remark10 添加到Remark9后面
			 */
			if(remark10!=null && "Remark9".equals(e.getKey())) {
				sb.append("Remark10");
				sb.append('=');
				sb.append(remark10);
				sb.append('&');
			}
		}
		if(sb.length() > 0){
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}
	
	private void fuckNull(){
		for(Entry<String,String> e : data.entrySet()){
			if(e.getValue() == null){
				e.setValue("");
			}
		}
	}

	@Override
	public String toString() {
		return buildData().replace("&", "\n");
	}
	
}
